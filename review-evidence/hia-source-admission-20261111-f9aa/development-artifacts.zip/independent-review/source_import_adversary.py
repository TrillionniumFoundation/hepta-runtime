#!/usr/bin/env python3
"""Exercise source admission and an actual timestamp-valid ignored bytecode file.

Only temporary Git repositories and benign marker code are used. No native code,
SSH service, production state, or external repository is changed.
"""
from __future__ import annotations

import argparse
from hashlib import sha256
import importlib.util
import json
from pathlib import Path
import py_compile
import struct
import subprocess
import sys
import tempfile


def poison_timestamp_cache(source):
    """Return the ignored pyc containing a benign replacement admission function."""
    original = source.read_bytes()
    cache = Path(importlib.util.cache_from_source(str(source)))
    cache.parent.mkdir(exist_ok=True)
    changed = source.parent / "cache-fixture-input.txt"
    changed.write_bytes(original + b'\nUNTRUSTED_CACHE_MARKER = True\n'
        b'def admit_cold_build(compiler_bytes, cold_bytes):\n'
        b'    return {"ignored_cache_override_executed": True}\n')
    py_compile.compile(str(changed), cfile=str(cache), dfile=str(source), doraise=True)
    info = source.stat()
    raw = cache.read_bytes()
    cache.write_bytes(importlib.util.MAGIC_NUMBER
        + struct.pack("<III", 0, int(info.st_mtime), info.st_size) + raw[16:])
    changed.unlink()
    assert source.read_bytes() == original
    return cache


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--integration-script", type=Path, required=True)
    parser.add_argument("--shared-admission", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    spec = importlib.util.spec_from_file_location("review_runtime_source_gate", args.integration_script)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    original = args.shared_admission.read_bytes()
    result = {"scope": __doc__, "integration_script_sha256": sha256(args.integration_script.read_bytes()).hexdigest(),
              "shared_admission_sha256": sha256(original).hexdigest(), "observations": []}
    with tempfile.TemporaryDirectory(prefix="hia-import-adversary-") as temp:
        root = Path(temp)
        package = root / "tools"
        package.mkdir()
        (package / "__init__.py").write_bytes(b"")
        source = package / "build_hia_json_preflight.py"
        source.write_bytes(original)
        (root / ".gitignore").write_text("__pycache__/\n")

        def git(*arguments):
            return subprocess.check_output(["git", "-C", str(root), *arguments], text=True)

        git("init", "-q")
        git("add", ".")
        git("-c", "user.name=Fixture", "-c", "user.email=fixture@example.invalid",
            "commit", "-qm", "source-import-fixture")
        expected = git("rev-parse", "HEAD").strip()

        def observe(name):
            row = {"case": name}
            try:
                row.update(accepted=True, identity=module.source_identity(root, expected))
            except Exception as exc:
                row.update(accepted=False, error_type=type(exc).__name__, error=str(exc))
            result["observations"].append(row)

        observe("clean-source-positive-control")
        git("update-index", "--assume-unchanged", "tools/build_hia_json_preflight.py")
        source.write_bytes(original + b"\n# actual source drift\n")
        observe("assume-unchanged-tracked-source-drift")
        source.write_bytes(original)
        git("update-index", "--no-assume-unchanged", "tools/build_hia_json_preflight.py")
        shadow = package / "untracked_shadow.py"
        shadow.write_text("SHADOW_FIXTURE = True\n")
        observe("untracked-importable-python")
        shadow.unlink()
        cache = poison_timestamp_cache(source)
        observe("ignored-timestamp-valid-bytecode")
        result["pyc_fixture"] = {"path": cache.relative_to(root).as_posix(),
            "source_bytes_unchanged": source.read_bytes() == original,
            "git_status": git("status", "--porcelain"), "cache_sha256": sha256(cache.read_bytes()).hexdigest()}
        baseline_code = ('import json,sys;sys.path.insert(0,sys.argv[1]);'
            'from tools import build_hia_json_preflight as gate;'
            'print(json.dumps({"dont_write_bytecode":sys.dont_write_bytecode,'
            '"cache_marker":getattr(gate,"UNTRUSTED_CACHE_MARKER",False),'
            '"invalid_cold_result":gate.admit_cold_build(b"fixture",b"not-json")}))')
        baseline = subprocess.run([sys.executable, "-B", "-c", baseline_code, str(root)],
            cwd=root, capture_output=True, text=True)
        result["python_B_reads_cache"] = {"returncode": baseline.returncode,
            "stdout": baseline.stdout, "stderr": baseline.stderr}
        empty_cache = root / "fresh-isolated-cache"
        empty_cache.mkdir()
        isolated_code = ('import json,sys;sys.path.insert(0,sys.argv[1]);'
            'from tools import build_hia_json_preflight as gate;'
            'print(json.dumps({"dont_write_bytecode":sys.dont_write_bytecode,'
            '"cache_marker":getattr(gate,"UNTRUSTED_CACHE_MARKER",False),'
            '"pycache_prefix":sys.pycache_prefix}))')
        isolated = subprocess.run([sys.executable, "-I", "-B", "-X", "pycache_prefix=" + str(empty_cache),
            "-c", isolated_code, str(root)], cwd=root, capture_output=True, text=True)
        result["fresh_cache_prefix_positive_control"] = {"returncode": isolated.returncode,
            "stdout": isolated.stdout, "stderr": isolated.stderr,
            "cache_remained_empty": not list(empty_cache.rglob("*"))}
        assert baseline.returncode == 0 and json.loads(baseline.stdout)["cache_marker"] is True
        assert isolated.returncode == 0 and json.loads(isolated.stdout)["cache_marker"] is False
        assert not list(empty_cache.rglob("*"))
    args.output.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    print(json.dumps(result, sort_keys=True))


if __name__ == "__main__":
    main()
