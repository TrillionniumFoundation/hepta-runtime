"""Bounded Linux host-owned regions crossing a trusted synchronous C ABI.

This is a hosted memory boundary, not a new Core typing theorem or a device
driver. No arbitrary pointer/fd is imported or exported. Fixed-size memfd data
is borrowed under one shared-read/exclusive-write gate and kernel protections.
Native code is pinned and mapping-checked by the existing HIA native boundary.
An uncertain call retains its mapping, code and lease until its actual owned
worker is joined. Only a reviewed no-escape FFI contract makes that join a
quiescence witness. MMIO, DMA, detached native work and hostile FFI are excluded.
"""
from __future__ import annotations

from collections import deque
import copy
import ctypes
from dataclasses import dataclass
from hashlib import sha256
import mmap
import os
from pathlib import Path
import platform
import re
import secrets
import threading
import time

from .hia_native_differential import _pin_native_artifact
from .native_mapping_identity import verify_loaded_symbols
from .hia_adaptive import _NativeRelease


PROFILE="hepta.hia.host-memfd-region-linux-x86_64.v1"
MAX_REGION_BYTES=1024*1024
MAX_REGIONS=16
MAX_LIBRARIES=16
_REGISTRY_LOCK=threading.RLock()
_REGIONS={}
_LIBRARIES={}


def _retire_registered_owner(registry, owner):
    """Retire only this owner, even when its exposed identity label changed.

    Registry bounds are at most sixteen, so identity lookup is bounded.
    Never let a mutable token select another retained native owner.
    """
    with _REGISTRY_LOCK:
        key=next((token for token, registered in registry.items() if registered is owner),None)
        if key is not None:
            del registry[key]


_IDENT=re.compile(r"[A-Za-z_][A-Za-z_0-9]{0,127}\Z")


class HostRegionRejected(ValueError):
    pass


class HostRegionUncertain(RuntimeError):
    pass


def _reject(message):
    raise HostRegionRejected("E_HIA_HOST_REGION: "+message)


def _host():
    if (platform.system()!="Linux" or platform.machine() not in {"x86_64","amd64"}
            or not hasattr(os,"memfd_create") or ctypes.sizeof(ctypes.c_void_p)!=8 or ctypes.sizeof(ctypes.c_size_t)!=8):
        _reject("actual Linux x86_64 memfd host required")


@dataclass(frozen=True)
class TrustedRegionContract:
    """Reviewed host assertion, explicitly not a proof about arbitrary C.

    Every entry has ABI int(uint8_t*,size_t,uint64_t,uint64_t*), returns zero on
    success, observes its declared region permission, stays within the supplied
    extent, and retains neither pointer after return. It creates no detached
    work using either pointer. A false assertion is outside the safety profile.
    """
    entries: tuple
    synchronous_no_escape: bool

    def admitted(self):
        if type(self) is not TrustedRegionContract or self.synchronous_no_escape is not True:
            _reject("reviewed synchronous no-escape FFI contract required; unknown retention is denied")
        if type(self.entries) is not tuple or not 1<=len(self.entries)<=16:
            _reject("bounded exact native entry inventory required")
        result={}
        for row in self.entries:
            if (type(row) is not tuple or len(row)!=2 or type(row[0]) is not str
                    or _IDENT.fullmatch(row[0]) is None or row[0] in result
                    or type(row[1]) is not str or row[1] not in {"read","write"}):
                _reject("invalid reviewed native permission inventory")
            result[row[0]]=row[1]
        return result


class NativeRegionLibrary:
    """Retained sealed code, with actual loaded-symbol identity admission."""
    def __init__(self,path,expected_sha256,contract):
        _host()
        if type(expected_sha256) is not str or re.fullmatch(r"[0-9a-f]{64}",expected_sha256) is None:
            _reject("explicit reviewed artifact SHA-256 required")
        if type(contract) is not TrustedRegionContract: _reject("exact trusted FFI contract required")
        self._permissions=contract.admitted()
        self._lock=threading.RLock();self._active=0;self._closed=False
        self._retirement_uncertain=False
        self._token=secrets.token_hex(16);self._release=_NativeRelease(None,None)
        self._debts=[];self._symbols={};self._mapping=None
        self.artifact_sha256=expected_sha256
        with _REGISTRY_LOCK:
            # Global owner tokens are registry keys, not advisory labels.
            # Reject malformed entropy or collision before replacing a retained owner.
            if (type(self._token) is not str or re.fullmatch(r"[0-9a-f]{32}",self._token) is None
                    or self._token in _LIBRARIES):
                _reject("malformed or duplicate library identity")
            if len(_LIBRARIES)>=MAX_LIBRARIES: _reject("native library retention budget exhausted")
            _LIBRARIES[self._token]=self

        def close_input(fd):
            release=_NativeRelease(None,fd);release.attempt()
            if not release.complete:
                self._debts.append(release)
                _reject("input descriptor close uncertain; never retry numeric descriptor")
        try:
            raw,_,fd=_pin_native_artifact(Path(path),maximum_bytes=1024*1024,close_owner=close_input)
            self._release.fd=fd
            if sha256(raw).hexdigest()!=expected_sha256: _reject("pinned native bytes differ from reviewed artifact")
            library=ctypes.CDLL("/proc/self/fd/"+str(fd),mode=os.RTLD_NOW|os.RTLD_LOCAL)
            self._release.library=library
            for name in self._permissions:
                fn=getattr(library,name)
                fn.argtypes=[ctypes.c_void_p,ctypes.c_size_t,ctypes.c_uint64,ctypes.POINTER(ctypes.c_uint64)]
                fn.restype=ctypes.c_int
                self._symbols[name]=fn
            self._release.functions=self._symbols
            self._mapping=verify_loaded_symbols(fd,self._symbols)
        except BaseException:
            self._closed=True;self._release.attempt()
            if self._release.complete and not self._debts:
                _retire_registered_owner(_LIBRARIES,self)
            raise

    def _acquire(self,symbol):
        if type(symbol) is not str: _reject("built-in native symbol name required")
        with self._lock:
            if self._closed or self._retirement_uncertain or symbol not in self._symbols: _reject("native library closed, pin retirement uncertain or entry not admitted")
            # The same open descriptor and loader reference remain retained.
            verify_loaded_symbols(self._release.fd,{symbol:self._symbols[symbol]})
            self._active+=1
            return self._symbols[symbol],self._permissions[symbol]

    def _finish(self):
        with self._lock:
            if self._active<=0: _reject("native call accounting underflow")
            self._active-=1

    def __copy__(self): _reject("native library owners cannot be copied")
    def __deepcopy__(self,memo): self.__copy__()

    def snapshot(self):
        with self._lock:
            return {"artifact_sha256":self.artifact_sha256,"active_calls":self._active,
                "closed":self._closed,"retirement_uncertain":self._retirement_uncertain,
                "loaded_mapping":copy.deepcopy(self._mapping),
                "release":self._release.snapshot(),"unresolved_input_closes":len(self._debts),
                "trusted_contract":"synchronous bounded access; no pointer retention or detached native work"}

    def close(self):
        with self._lock:
            if self._active or self._retirement_uncertain:
                _reject("native code pin retained or retirement receipt uncertain")
            self._closed=True;result=self._release.attempt()
            if not self._release.complete or self._debts: _reject("native retirement uncertain; work permanently denied")
            _retire_registered_owner(_LIBRARIES,self)
            return result


@dataclass(frozen=True)
class _LeaseGrant:
    """Owner-retained authority: mutable lease fields never define access."""
    mode: str
    offset: int
    length: int
    generation: int
    internal: bool


class RegionLease:
    """An identity-checked capability; reads return copies, never a raw view."""
    def __init__(self,owner,mode,offset,length,generation,internal=False):
        self._owner=owner;self._mode=mode;self._offset=offset;self._length=length
        self._generation=generation;self._token=secrets.token_hex(16)
        self._closed=False;self._internal=internal

    def read(self): return self._owner._read(self)
    def write(self,data): return self._owner._write(self,data)
    def close(self): return self._owner._release_lease(self)
    def __enter__(self):
        with self._owner._lock: self._owner._validate_lease(self)
        return self
    def __exit__(self,*unused): self.close()
    def __copy__(self): _reject("region leases cannot be copied")
    def __deepcopy__(self,memo): self.__copy__()


class HostRegion:
    """Finite whole-region RW leases, real page protection and join recovery.

    A lock serializes admission, generation changes and host-copy operations.
    Native reads may overlap; any native/host writer excludes every other
    lease. Lease release followed by subsequent admission is the synchronization
    order. Native entries must obey the reviewed contract. C atomics or devices
    outside this region are not governed by this memory model.
    """
    def __init__(self,length,*,max_leases=16,max_native_calls=8):
        _host()
        if type(length) is not int or not 1<=length<=MAX_REGION_BYTES: _reject("region extent outside 1..1MiB")
        if type(max_leases) is not int or not 1<=max_leases<=64: _reject("lease budget outside 1..64")
        if type(max_native_calls) is not int or not 1<=max_native_calls<=max_leases: _reject("native call budget exceeds lease budget")
        self._lock=threading.RLock();self._token=secrets.token_hex(16)
        self._length=length;self._mapped=((length+mmap.PAGESIZE-1)//mmap.PAGESIZE)*mmap.PAGESIZE
        self._max_leases=max_leases;self._max_calls=max_native_calls
        self._generation=0;self._state="initializing";self._reason=None
        self._leases={};self._lease_grants={};self._jobs={};self._events=deque(maxlen=256);self._sequence=0
        self._fd=None;self._memory=None;self._address=None;self._permission="none"
        self._release_attempted=False;self._release_report={};self._unprovable_quiescence=False
        with _REGISTRY_LOCK:
            # A duplicate or malformed token must never hide the prior owner
            # or allow retained memfd debt to escape the bounded registry.
            if (type(self._token) is not str or re.fullmatch(r"[0-9a-f]{32}",self._token) is None
                    or self._token in _REGIONS):
                _reject("malformed or duplicate region identity")
            if len(_REGIONS)>=MAX_REGIONS: _reject("retained region budget exhausted, including quarantine")
            _REGIONS[self._token]=self
        try:
            import fcntl
            self._fd=os.memfd_create("hepta-host-region",os.MFD_CLOEXEC|os.MFD_ALLOW_SEALING)
            os.ftruncate(self._fd,self._mapped)
            self._memory=mmap.mmap(self._fd,self._mapped,flags=mmap.MAP_SHARED,prot=mmap.PROT_READ|mmap.PROT_WRITE)
            view=ctypes.c_ubyte.from_buffer(self._memory);self._address=ctypes.addressof(view);del view
            # Existing mapping remains writable; no future fd writes/writable
            # mappings or extent changes are admitted after these actual seals.
            required=0x0001|0x0002|0x0004|0x0010
            fcntl.fcntl(self._fd,getattr(fcntl,"F_ADD_SEALS",1033),required)
            self._seals=fcntl.fcntl(self._fd,getattr(fcntl,"F_GET_SEALS",1034))
            if self._seals&required!=required: _reject("kernel refused fixed extent/future-write seals")
            info=os.fstat(self._fd);self._identity=(info.st_dev,info.st_ino,info.st_size)
            self._protect("none");self._state="ready";self._event("created")
        except BaseException:
            self._state="permanent_deny";self._close_storage_once()
            raise

    def _event(self,kind,**fields):
        self._sequence+=1
        self._events.append({"sequence":self._sequence,"kind":kind,"generation":self._generation,**fields})

    def __copy__(self): _reject("region owners cannot be copied")
    def __deepcopy__(self,memo): self.__copy__()

    def _protect(self,permission):
        flags={"none":0,"read":mmap.PROT_READ,"write":mmap.PROT_READ|mmap.PROT_WRITE}[permission]
        libc=ctypes.CDLL(None,use_errno=True);fn=libc.mprotect
        fn.argtypes=[ctypes.c_void_p,ctypes.c_size_t,ctypes.c_int];fn.restype=ctypes.c_int
        if fn(self._address,self._mapped,flags)!=0:
            self._state="permanent_deny";self._reason="page permission transition unconfirmed"
            raise HostRegionRejected("E_HIA_HOST_REGION: mprotect failed errno="+str(ctypes.get_errno()))
        self._permission=permission

    def _ready(self,generation):
        if type(generation) is not int or generation!=self._generation: _reject("stale or inexact generation fence")
        if self._state!="ready": _reject("region is "+self._state)

    def _borrow(self,mode,generation,offset,length,internal):
        self._ready(generation)
        if type(mode) is not str or mode not in {"read","write"}: _reject("exact read/write permission required")
        if length is None: length=self._length-offset if type(offset) is int else None
        if (type(offset) is not int or type(length) is not int or offset<0 or length<0
                or offset>self._length or length>self._length-offset): _reject("borrow extent outside owned region")
        if len(self._leases)>=self._max_leases: _reject("lease budget exhausted")
        if self._leases and (mode=="write" or any(g.mode=="write" for g in self._lease_grants.values())):
            _reject("shared-read/exclusive-write conflict")
        # Mint the lease identity before changing kernel page permissions:
        # a failed identity source must leave no writable unowned mapping.
        lease=RegionLease(self,mode,offset,length,generation,internal)
        # An unexpected entropy collision must not replace a live grant.
        # This is checked before mprotect or any owner registry mutation;
        # never guess that a repeated/malformed capability can be recovered.
        token=lease._token
        if (type(token) is not str or re.fullmatch(r"[0-9a-f]{32}",token) is None
                or token in self._leases or token in self._lease_grants):
            _reject("malformed or duplicate lease identity")
        # The lease has not escaped to a caller. If registry or receipt
        # bookkeeping fails after mprotect, retract every partial grant
        # before returning the exception. No unowned accessible page may
        # survive a failed public or native-call admission.
        try:
            if not self._leases: self._protect(mode)
            self._leases[lease._token]=lease
            self._lease_grants[lease._token]=_LeaseGrant(mode,offset,length,generation,internal)
            self._event("borrowed",mode=mode,offset=offset,length=length)
        except BaseException:
            if self._leases.get(lease._token) is lease:
                self._leases.pop(lease._token)
                self._lease_grants.pop(lease._token,None)
            lease._closed=True
            if not self._leases:
                # A rollback mprotect can fail before or after the kernel
                # transition. The original borrowed receipt was already
                # unconfirmed: never leave an unowned page ready for reuse.
                try:
                    self._protect("none")
                except BaseException as revoke_error:
                    self._unprovable_quiescence=True
                    if self._state=="permanent_deny":
                        # The real mprotect error changes state before raising;
                        # _quarantine only fences generations from ready.
                        self._generation+=1
                    try:
                        self._quarantine("borrow rollback page revocation unconfirmed",permanent=True)
                    except BaseException as receipt_error:
                        raise HostRegionUncertain(
                            "borrow rollback and quarantine receipts unconfirmed; permanently denied"
                        ) from receipt_error
                    raise HostRegionUncertain(
                        "borrow rollback page revocation unconfirmed; permanently denied"
                    ) from revoke_error
            raise
        return lease

    def borrow(self,mode,*,generation,offset=0,length=None):
        with self._lock: return self._borrow(mode,generation,offset,length,False)

    def _validate_lease(self,lease):
        # Registry identity alone is insufficient: the public Python handle
        # can have its mode, extent, generation or internal flag reassigned.
        # Never use those mutable fields as authority after admission.
        if (type(lease) is not RegionLease or lease._owner is not self
                or type(lease._token) is not str or lease._closed is not False
                or self._leases.get(lease._token) is not lease):
            _reject("lease is closed, forged or foreign")
        grant=self._lease_grants.get(lease._token)
        if grant is None or (type(lease._mode) is not str or type(lease._offset) is not int
                or type(lease._length) is not int or type(lease._generation) is not int
                or type(lease._internal) is not bool
                or (lease._mode,lease._offset,lease._length,lease._generation,lease._internal)
                != (grant.mode,grant.offset,grant.length,grant.generation,grant.internal)):
            _reject("lease attributes differ from the immutable owner grant")
        self._ready(grant.generation)
        return grant

    def _read(self,lease):
        with self._lock:
            grant=self._validate_lease(lease)
            return bytes(self._memory[grant.offset:grant.offset+grant.length])

    def _write(self,lease,data):
        if type(data) is not bytes: _reject("host write requires immutable bytes")
        with self._lock:
            grant=self._validate_lease(lease)
            if grant.mode!="write" or len(data)!=grant.length: _reject("write permission or exact extent missing")
            try:
                self._memory[grant.offset:grant.offset+grant.length]=data
            except BaseException as error:
                # Even a lost result receipt can mean that some or all bytes
                # reached the real mapping. Keep the exclusive lease owned,
                # revoke this generation and require quiescent zeroing before
                # any subsequent host/native read or native invocation.
                try:
                    self._quarantine("host write outcome unconfirmed")
                except BaseException as quarantine_error:
                    # _quarantine itself permanently denies a lost receipt.
                    raise HostRegionUncertain(
                        "host write and quarantine receipts unconfirmed; permanently denied"
                    ) from quarantine_error
                raise HostRegionUncertain(
                    "host write result unconfirmed; quiescent recovery required"
                ) from error

    def _release_lease(self,lease,*,internal=False):
        with self._lock:
            if type(lease) is not RegionLease or lease._owner is not self:
                _reject("foreign lease release")
            # A presented token is mutable, unlike the owner's registered
            # object identity.  Use its fast path only after identity checks;
            # bounded identity lookup lets close()/__exit__ retire the exact
            # original grant even if the caller altered the token.  Never use
            # a spoofed token to retire any other live lease.
            token=lease._token
            if type(token) is not str or self._leases.get(token) is not lease:
                token=next((key for key,active in self._leases.items() if active is lease),None)
            if token is None:
                if lease._closed is True: return
                _reject("lease release authority missing")
            grant=self._lease_grants.get(token)
            if grant is None or grant.internal and not internal:
                _reject("lease release authority missing")
            del self._leases[token]
            del self._lease_grants[token]
            lease._closed=True
            if not self._leases:
                try:
                    self._protect("none")
                except BaseException as error:
                    # The grant is already retired, but mprotect may have
                    # failed before *or after* changing physical page rights.
                    # An ambiguous last-lease revocation may not leave the old
                    # generation ready or permit later unmapping/recovery.
                    self._unprovable_quiescence=True
                    if self._state=="permanent_deny":
                        # _protect marks kernel failure permanent before
                        # throwing; still revoke the prior generation fence.
                        self._generation+=1
                    try:
                        self._quarantine("last-lease page revocation unconfirmed",permanent=True)
                    except BaseException as receipt_error:
                        raise HostRegionUncertain(
                            "last-lease page revocation and quarantine unconfirmed; permanently denied"
                        ) from receipt_error
                    raise HostRegionUncertain(
                        "last-lease page revocation unconfirmed; permanently denied"
                    ) from error
            try:
                self._event("released",mode=grant.mode)
            except BaseException as error:
                # The grant was retired, but its public release receipt may
                # have failed before or after append. Never leave this
                # generation ready for a subsequent native admission.
                try:
                    self._quarantine("lease release receipt unconfirmed",
                                     permanent=self._state=="permanent_deny")
                except BaseException as quarantine_error:
                    # Neither release nor quarantine can be receipted. Deny
                    # permanently rather than guessing audit completeness.
                    self._unprovable_quiescence=True
                    self._state="permanent_deny"
                    self._reason="lease and quarantine receipts unconfirmed"
                    raise HostRegionUncertain(
                        "lease and quarantine receipts unconfirmed; permanently denied"
                    ) from quarantine_error
                raise HostRegionUncertain(
                    "lease release unconfirmed; quiescent recovery required"
                ) from error

    def _quarantine(self,reason,*,permanent=False):
        if self._state not in {"quarantined","permanent_deny"}:
            self._generation+=1
        self._state="permanent_deny" if permanent or self._state=="permanent_deny" else "quarantined"
        self._reason=reason
        try:
            self._event("quarantined",reason=reason,permanent=permanent)
        except BaseException as error:
            # The quarantine may have been appended or lost entirely. Its
            # receipt is a production authority boundary, not advisory
            # telemetry: never allow this epoch to be recovered or unmapped
            # on an unconfirmed quarantine transition.
            self._unprovable_quiescence=True
            self._state="permanent_deny"
            self._reason="quarantine receipt unconfirmed"
            raise HostRegionUncertain(
                "quarantine receipt unconfirmed; permanently denied"
            ) from error

    def call(self,library,symbol,*,generation,argument=0,offset=0,length=None,timeout=1.0):
        if type(library) is not NativeRegionLibrary: _reject("owned reviewed native library required")
        if type(argument) is not int or not 0<=argument<2**64: _reject("exact uint64 native argument required")
        if type(timeout) not in {int,float} or not 0<timeout<=10: _reject("native join timeout outside (0,10]")
        function,mode=library._acquire(symbol)
        lease=None
        try:
            with self._lock:
                if len(self._jobs)>=self._max_calls: _reject("native call budget exhausted")
                lease=self._borrow(mode,generation,offset,length,True)
                # Before thread.start() the C entry cannot have run. Release
                # newly admitted state on a *prestart* host exception; do not
                # confuse it with an ambiguous start() outcome below.
                token=None
                try:
                    grant=self._lease_grants[lease._token]
                    native_address=self._address+grant.offset
                    native_length=grant.length
                    # Validate the candidate BEFORE assigning it to the cleanup
                    # key: on rejection the prestart handler must not pop an
                    # existing live worker with the same injected identity.
                    candidate=secrets.token_hex(16)
                    if (type(candidate) is not str or re.fullmatch(r"[0-9a-f]{32}",candidate) is None
                            or candidate in self._jobs):
                        _reject("malformed or duplicate native job identity")
                    token=candidate
                    job={"lease":lease,"library":library,"done":threading.Event(),"uncertain":False,"result":None,"error":None,"finalized":False}
                    def worker():
                        try:
                            output=ctypes.c_uint64()
                            code=function(native_address,native_length,argument,ctypes.byref(output))
                            job["result"]=(code,output.value)
                        except BaseException as error:
                            job["error"]={"type":type(error).__name__,"message":str(error)}
                        finally: job["done"].set()
                    thread=threading.Thread(target=worker,name="hia-region-"+token[:8],daemon=False)
                    job["thread"]=thread;self._jobs[token]=job
                except BaseException:
                    # No thread.start() attempt. A release receipt may itself
                    # fail *after* revoking a lease. Keep the epoch quarantined,
                    # but still settle the code pin acquired for this call:
                    # there is provably no worker that can execute it.
                    if token is not None: self._jobs.pop(token,None)
                    try:
                        self._release_lease(lease,internal=True)
                    except BaseException as error:
                        try:
                            self._quarantine("prestart lease retirement unconfirmed",
                                             permanent=self._state=="permanent_deny")
                        finally:
                            # The outer handler must balance library._active
                            # even when lease/event retirement throws.
                            lease=None
                        raise HostRegionUncertain(
                            "prestart lease retirement unconfirmed; region quarantined"
                        ) from error
                    lease=None
                    raise
                try: thread.start()
                except BaseException:
                    # start may have taken effect before raising. No successful
                    # call admission or guessed thread death can reclaim data.
                    job["uncertain"]=True;self._unprovable_quiescence=True
                    self._quarantine("worker launch outcome uncertain",permanent=True)
                    raise HostRegionUncertain("native worker launch uncertain; region retained permanently")
        except BaseException:
            if lease is None:
                try:
                    library._finish()
                except BaseException as error:
                    # Even a provably unstarted call can lose its code-owner
                    # retirement receipt before or after the active decrement.
                    # Neither retry a numeric pin nor permit an unconfirmed
                    # code owner to unload or admit new calls.
                    with library._lock:
                        library._retirement_uncertain=True
                    with self._lock:
                        self._unprovable_quiescence=True
                        self._quarantine("prestart native code pin release unconfirmed",
                                         permanent=True)
                    raise HostRegionUncertain(
                        "prestart native code pin retirement unconfirmed; permanently denied"
                    ) from error
            else:
                with self._lock:
                    self._quarantine("native call admission interrupted",permanent=self._unprovable_quiescence)
            raise
        try: thread.join(float(timeout))
        except BaseException as error:
            with self._lock:
                job["uncertain"]=True;self._quarantine("worker join interrupted")
            raise HostRegionUncertain("owned native join was interrupted; region quarantined") from error
        with self._lock:
            if job["finalized"]:
                # Recovery may have joined this worker while its original
                # caller was descheduled. Never revoke the recovered epoch.
                raise HostRegionUncertain("old native call was retired by recovery; result is not committed")
            if thread.is_alive() or not job["done"].is_set():
                job["uncertain"]=True;self._quarantine("native call timed out or completion unconfirmed")
                raise HostRegionUncertain("native call outcome uncertain; mapping/code/lease retained")
            uncertain=(job["uncertain"] or job["error"] is not None or job["result"] is None
                       or job["result"][0]!=0 or self._generation!=generation or self._state!="ready")
            if uncertain: self._quarantine("native call failed or its generation was revoked")
            try:
                self._finalize_job(token,job)
                if uncertain: raise HostRegionUncertain("native call did not commit; quiescent recovery required")
                self._event("native_returned",symbol=symbol)
            except HostRegionUncertain:
                raise
            except BaseException as error:
                # A joined C worker is not a committed result when its lease,
                # finalization or return receipt is unconfirmed. Deny every
                # new native entry until quiescent recovery zeroes the epoch.
                self._quarantine("native completion evidence unconfirmed",
                                 permanent=self._unprovable_quiescence)
                raise HostRegionUncertain(
                    "native completion unconfirmed; quiescent recovery required"
                ) from error
            return job["result"][1]

    def _finalize_job(self,token,job):
        if job["finalized"]: return
        if job["thread"].is_alive() or not job["done"].is_set(): _reject("cannot retire a live or unconfirmed native worker")
        # In-memory stage flags keep a completed worker owned across a
        # receipt fault, so recover() can finish the exact same joined job.
        # This is NOT a durable journal or a crash-recovery guarantee.
        if not job.get("lease_retired",False):
            self._release_lease(job["lease"],internal=True)
            job["lease_retired"]=True
        if not job.get("library_retired",False):
            # A failed _finish() may already have decremented the reference.
            # Do not make a second ambiguous release or unmap the code.
            if job.get("library_finish_attempted",False):
                self._unprovable_quiescence=True
                self._quarantine("native code release outcome uncertain",permanent=True)
                _reject("native code release outcome uncertain; never retry")
            job["library_finish_attempted"]=True
            try:
                job["library"]._finish()
            except BaseException as error:
                # A joined worker does not prove that its code pin was
                # retired. _finish may raise before or after decrementing the
                # active count. Even a zero count cannot authorize dlclose or
                # reuse by a different HostRegion without a receipt.
                with job["library"]._lock:
                    job["library"]._retirement_uncertain=True
                self._unprovable_quiescence=True
                self._quarantine("joined native code pin retirement unconfirmed",
                                 permanent=True)
                raise HostRegionUncertain(
                    "joined native code pin retirement unconfirmed; permanently denied"
                ) from error
            job["library_retired"]=True
        if not job.get("join_receipted",False):
            self._event("worker_join_confirmed")
            job["join_receipted"]=True
        if self._jobs.get(token) is not job:
            self._unprovable_quiescence=True
            self._quarantine("native job identity lost during finalization",permanent=True)
            _reject("native job identity lost during finalization")
        del self._jobs[token]
        job["finalized"]=True

    def _recover_protect(self,permission):
        """Recovery has no live lease: a lost mprotect result is irreversible debt.

        The caller cannot distinguish a failed transition from a completed
        kernel transition followed by an unreceipted host observation. Keep
        the mapping/code retained, revoke the generation and never retry an
        ambiguous writable page as a fresh recovery or a close().
        """
        try:
            self._protect(permission)
        except BaseException as error:
            self._unprovable_quiescence=True
            # _quarantine does not advance the generation a second time
            # when the owner is already quarantined or permanent_deny.
            self._generation+=1
            try:
                self._quarantine("recovery page "+permission+" transition unconfirmed",
                                 permanent=True)
            except BaseException as receipt_error:
                raise HostRegionUncertain(
                    "recovery mprotect and quarantine receipts unconfirmed; permanently denied"
                ) from receipt_error
            raise HostRegionUncertain(
                "recovery mprotect outcome unconfirmed; permanently denied"
            ) from error

    def recover(self,*,timeout=0.0):
        if type(timeout) not in {int,float} or not 0<=timeout<=10: _reject("recovery wait outside [0,10]")
        with self._lock:
            if self._state!="quarantined" or self._unprovable_quiescence: _reject("recovery has no admissible quarantined state")
            jobs=list(self._jobs.items())
        deadline=time.monotonic()+float(timeout)
        for _,job in jobs:
            try: job["thread"].join(max(0,deadline-time.monotonic()))
            except BaseException as error:
                with self._lock: self._quarantine("recovery join unconfirmed")
                raise HostRegionUncertain("recovery could not confirm owned worker join") from error
        with self._lock:
            if self._state!="quarantined" or self._unprovable_quiescence: _reject("recovery state changed")
            if any(job["thread"].is_alive() or not job["done"].is_set() for job in self._jobs.values()):
                _reject("native worker still live; quiescence not established")
            for token,job in list(self._jobs.items()):
                job["uncertain"]=True
                self._finalize_job(token,job)
            if self._leases: _reject("external leases still retained; quiescence not established")
            self._recover_protect("write")
            try:
                # A partial or post-write mmap error is not a zeroing receipt.
                # All workers have been joined and the owner lock is held;
                # restore PROT_NONE before exposing any failure to a caller.
                self._memory[:]=b"\0"*self._mapped
            except BaseException as error:
                try:
                    self._protect("none")
                except BaseException as revoke_error:
                    # _protect itself marks permanent_deny on mprotect failure.
                    # An uncertain write *and* revoke must never be retried.
                    self._unprovable_quiescence=True
                    raise HostRegionUncertain(
                        "recovery zeroing and page revocation unconfirmed; permanently denied"
                    ) from revoke_error
                self._reason="recovery memory zeroing receipt unconfirmed"
                raise HostRegionUncertain(
                    "recovery zeroing unconfirmed; region remains quarantined"
                ) from error
            self._recover_protect("none")
            # Do not expose a new ready generation until the recovery
            # completion receipt has actually succeeded. An audit failure,
            # including a post-append failure, must keep the epoch fenced.
            self._generation+=1
            try:
                self._event("recovered_zeroed",quiescence="all owned workers joined and no retained leases")
                # Even after the audit event, a failed /proc mapping observation
                # or result snapshot must not expose a ready generation.
                # Finish every potentially failing result operation while the
                # owner is still quarantined and the page is PROT_NONE.
                receipt=self.snapshot()
                receipt["state"]="ready";receipt["reason"]=None
            except BaseException as error:
                self._reason="recovery completion or result receipt unconfirmed"
                raise HostRegionUncertain(
                    "recovery completion unconfirmed; region remains quarantined"
                ) from error
            self._state="ready";self._reason=None
            return receipt

    def _observed_permissions(self):
        if self._address is None or self._release_report.get("mapping")=="closed": return None
        with open("/proc/self/maps","rb") as stream: raw=stream.read(16*1024*1024+1)
        if len(raw)>16*1024*1024: _reject("mapping inventory exceeds observation bound")
        for line in raw.splitlines():
            fields=line.split(None,5)
            low,high=(int(x,16) for x in fields[0].split(b"-"))
            if low<=self._address and self._address+self._mapped<=high:
                return fields[1].decode()
        return None

    def snapshot(self):
        with self._lock:
            return {"profile":PROFILE,"state":self._state,"reason":self._reason,"generation":self._generation,
                "length":self._length,"mapped_bytes":self._mapped,"kernel_seals":getattr(self,"_seals",None),
                "permission":self._permission,"observed_mapping_permissions":self._observed_permissions(),
                "read_leases":sum(g.mode=="read" for g in self._lease_grants.values()),
                "write_leases":sum(g.mode=="write" for g in self._lease_grants.values()),"native_jobs":len(self._jobs),
                "live_native_workers":sum(j["thread"].is_alive() for j in self._jobs.values()),
                "events":copy.deepcopy(list(self._events)),"release":dict(self._release_report),
                "claims":{"arbitrary_foreign_pointer_safe":False,"mmio_dma_supported":False,
                    "whole_language_concurrency_proved":False,"native_contract_assumed":True}}

    def _close_storage_once(self):
        if self._release_attempted: return
        self._release_attempted=True
        self._release_report={"mapping":"not_acquired" if self._memory is None else "unknown",
                              "fd":"not_acquired" if self._fd is None else "unknown"}
        if self._memory is not None:
            try: self._memory.close();self._release_report["mapping"]="closed"
            except BaseException as error: self._release_report["mapping_error"]=str(error)
        if self._fd is not None:
            try: os.close(self._fd);self._release_report["fd"]="closed"
            except BaseException as error: self._release_report["fd_error"]=str(error)
        if all(self._release_report[k] in {"closed","not_acquired"} for k in ("mapping","fd")):
            self._state="closed"
            _retire_registered_owner(_REGIONS,self)
        else: self._state="permanent_deny"

    def close(self):
        with self._lock:
            if self._jobs or self._leases or self._unprovable_quiescence: _reject("unconfirmed calls or retained leases forbid unmapping")
            if self._state!="closed": self._generation+=1
            self._close_storage_once()
            if self._state!="closed": _reject("region release uncertain; no numeric handle retry")
            return dict(self._release_report)


def retained_host_regions():
    """Bounded ownership debt, without exporting a raw fd or address."""
    with _REGISTRY_LOCK:
        regions=list(_REGIONS.values());libraries=list(_LIBRARIES.values())
    return {"regions":[r.snapshot() for r in regions],"libraries":[l.snapshot() for l in libraries],
            "max_regions":MAX_REGIONS,"max_region_bytes":MAX_REGION_BYTES,"max_libraries":MAX_LIBRARIES}
