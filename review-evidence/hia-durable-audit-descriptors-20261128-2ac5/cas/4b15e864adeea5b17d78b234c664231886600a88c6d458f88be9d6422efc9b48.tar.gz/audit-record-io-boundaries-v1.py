from pathlib import Path
import subprocess,sys,os,json,hashlib,time,traceback
B=Path("/home/qian-qi/hia-runtime-durable-requests-20261128-2ac5");S=B/"source";Q=B/"qualification/audit-record-io-boundaries-v1";Q.mkdir(parents=True,exist_ok=False)
os.umask(0o022);SHA=lambda raw:hashlib.sha256(raw).hexdigest()
names=["scripts/author_durable_common.py","scripts/author_durable_audit_record_io.py","scripts/durable_audit_record_io_source.py.txt","native/durable_audit_record_io.hepta","native/durable_audit_record_io_composition.json","native/durable_audit_record.hepta","native/durable_audit_record_composition.json","native/request_storage_json.hepta","scripts/hia_native_build.py","scripts/hia_native_loader.py","scripts/prepare_durable_audit_record_io_reference.py","scripts/qualify_durable_audit_record_io.py","src/mcp/runtime/request_audit.rs","scripts/qualify_durable_audit_record_io_boundaries.py"]
def pins():return{n:dict(bytes=len(raw),sha256=SHA(raw))for n in names for raw in[(S/n).read_bytes()]}
before=pins();(Q/"source-before.json").write_text(json.dumps(before,sort_keys=True,indent=2)+"\n")
start=time.monotonic();report=dict(state="RUNNING",started_ns=time.time_ns());(Q/"terminal.json").write_text(json.dumps(report)+"\n")
try:
 assert json.loads((B/"qualification/audit-record-io-native-v2/terminal.json").read_bytes())["state"]=="PASS"
 manifest=B/"build/modules/durable-audit-record-io-v2/manifest.json";record=B/"build/modules/durable-audit-record/manifest.json"
 assert SHA(manifest.read_bytes())=="3014e93e83ef368f5e7e1bb8e152cc2ec8849fd4d90776ae70a0796b232dbd1b"
 assert SHA(record.read_bytes())=="74157806c4151c906499d2dd9be51d537f85d00795dd2490f36c32ba9c0375b6"
 assert before["native/durable_audit_record_io.hepta"]["sha256"]=="0e7e9dcb4f77b2f31ce64c85e3bd765995c79d0e6b8bb7c6da17ed0fc05bfbdf"
 argv=[sys.executable,"-B",str(S/"scripts/qualify_durable_audit_record_io_boundaries.py"),"--manifest",str(manifest),"--record-manifest",str(record),"--output",str(Q/"controls")]
 (Q/"intent.json").write_text(json.dumps(dict(argv=argv,timeout_seconds=120),sort_keys=True,indent=2)+"\n")
 with(Q/"stdout").open("xb")as out,(Q/"stderr").open("xb")as err:
  child=subprocess.run(argv,cwd=S,env=dict(os.environ,LC_ALL="C",LANG="C"),stdout=out,stderr=err,timeout=120)
 assert child.returncode==0,("actual native boundary controls failed",child.returncode)
 outcome=json.loads((Q/"controls/report.json").read_bytes());assert outcome["state"]=="PASS"and outcome["source_unchanged"]is True
 after=pins();(Q/"source-after.json").write_text(json.dumps(after,sort_keys=True,indent=2)+"\n");assert before==after
 report.update(state="PASS",actual_controls=outcome["controls"],control_seconds=outcome["elapsed_seconds"],source_unchanged=True)
except BaseException as error:
 report.update(state="FAIL",error=type(error).__name__+": "+str(error));(Q/"exception.txt").write_text(traceback.format_exc());print(traceback.format_exc(),flush=True)
 if(Q/"stderr").exists():print((Q/"stderr").read_text(errors="replace"),flush=True)
finally:
 report["elapsed_seconds"]=time.monotonic()-start
 for name in("stdout","stderr"):
  if(Q/name).exists():report[name]=dict(bytes=(Q/name).stat().st_size,sha256=SHA((Q/name).read_bytes()))
 (Q/"terminal.json").write_text(json.dumps(report,sort_keys=True,indent=2)+"\n");print(json.dumps(report,sort_keys=True),flush=True)
raise SystemExit(0 if report["state"]=="PASS"else 1)
