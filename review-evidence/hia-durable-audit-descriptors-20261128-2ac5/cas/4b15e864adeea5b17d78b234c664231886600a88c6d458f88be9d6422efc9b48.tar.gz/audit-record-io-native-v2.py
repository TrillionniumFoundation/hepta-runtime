from pathlib import Path
import subprocess,sys,os,json,hashlib,time,traceback,tomllib,tarfile
B=Path("/home/qian-qi/hia-runtime-durable-requests-20261128-2ac5");S=B/"source";Q=B/"qualification/audit-record-io-native-v2";Q.mkdir(parents=True,exist_ok=False)
HEPTA=Path("/home/qian-qi/hia-runtime-filebytes-20261128-2ac5/pinned-hepta-d3e2")
TEMPLATE=Path("/home/qian-qi/hia-runtime-filebytes-20261128-2ac5/config-nativejobs-linux-reference-build-v2/project")
BOOTSTRAP=Path("/home/qian-qi/hia-runtime-filebytes-20261128-2ac5/local-read-component-build-v1/build/bootstrap")
SHA=lambda raw:hashlib.sha256(raw).hexdigest()
os.umask(0o022)
env=dict(os.environ,LC_ALL="C",LANG="C",CARGO_BUILD_JOBS="2",CARGO_TARGET_DIR=str(B/"target"))
for k in list(env):
 if k.startswith(("CARGO_PROFILE_","HIA_"))or k in("RUSTC_WRAPPER","RUSTC_WORKSPACE_WRAPPER","RUSTFLAGS"):env.pop(k)
def run(argv,label,timeout=300):
 t=time.monotonic();argv=list(map(str,argv));r=dict(argv=argv,timeout_seconds=timeout,state="RUNNING")
 (Q/(label+".intent.json")).write_text(json.dumps(r,sort_keys=True,indent=2)+"\n")
 with(Q/(label+".stdout")).open("xb")as out,(Q/(label+".stderr")).open("xb")as err:p=subprocess.run(argv,cwd=S,env=env,stdout=out,stderr=err,timeout=timeout)
 r.update(exit_code=p.returncode,elapsed_seconds=time.monotonic()-t,state="PASS"if p.returncode==0 else"FAIL")
 for k in("stdout","stderr"):r[k]=dict(bytes=(Q/(label+"."+k)).stat().st_size,sha256=SHA((Q/(label+"."+k)).read_bytes()))
 (Q/(label+".terminal.json")).write_text(json.dumps(r,sort_keys=True,indent=2)+"\n");print(json.dumps(r),flush=True)
 if p.returncode:print((Q/(label+".stderr")).read_text(errors="replace"),flush=True);raise RuntimeError(label+" failed")
names=["scripts/author_durable_common.py","scripts/author_durable_audit_record_io.py","scripts/durable_audit_record_io_source.py.txt","native/durable_audit_record_io.hepta","native/durable_audit_record_io_composition.json","native/durable_audit_record.hepta","native/durable_audit_record_composition.json","native/request_storage_json.hepta","scripts/hia_native_build.py","scripts/hia_native_loader.py","scripts/prepare_durable_audit_record_io_reference.py","scripts/qualify_durable_audit_record_io.py","src/mcp/runtime/request_audit.rs"]
def sources():return{n:dict(bytes=len(raw),sha256=SHA(raw))for n in names for raw in[(S/n).read_bytes()]}
before=sources();(Q/"source-before.json").write_text(json.dumps(before,sort_keys=True,indent=2)+"\n")
start=time.monotonic();report=dict(state="RUNNING",started_ns=time.time_ns());(Q/"terminal.json").write_text(json.dumps(report)+"\n")
try:
 original_proof=json.loads((B/"reference/audit_record_io/source-relation.json").read_bytes())
 assert original_proof["original_sha256"]==SHA((S/"src/mcp/runtime/request_audit.rs").read_bytes())
 assert original_proof["oracle_sha256"]==SHA((B/"reference/audit_record_io/oracle.rs").read_bytes())
 (Q/"retained-exact-original-source-relation.json").write_text(json.dumps(original_proof,sort_keys=True,indent=2)+"\n")
 assert json.loads((B/"qualification/audit-record-io-native-v1/exact-original-prepare.terminal.json").read_bytes())["state"]=="PASS"
 rustbin=Path.home()/".rustup/toolchains/1.95.0-x86_64-unknown-linux-gnu/bin"
 cargo=rustbin/"cargo";rustc=rustbin/"rustc"
 if not cargo.is_file()or not rustc.is_file():raise ValueError("fixed Rust1.95.0 unavailable")
 env["PATH"]=str(rustbin)+os.pathsep+env.get("PATH","");env["RUSTC"]=str(rustc)
 run([rustc,"--version","--verbose"],"rust-version",30)
 if b"commit-hash: 59807616e1fa2540724bfbac14d7976d7e4a3860" not in (Q/"rust-version.stdout").read_bytes():raise ValueError("Rust compiler exact commit differs")
 lock=(B/"reference/Cargo.lock").read_bytes()
 if lock!=(TEMPLATE/"Cargo.lock").read_bytes():raise ValueError("reference lock changed")
 run([cargo,"metadata","--manifest-path",B/"reference/Cargo.toml","--locked","--offline","--format-version","1"],"cargo-metadata",180)
 meta=json.loads((Q/"cargo-metadata.stdout").read_bytes());locked={(r["name"],r["version"]):r for r in tomllib.loads(lock.decode())["package"]if"checksum"in r}
 packages=[p for p in meta["packages"]if p["source"]is not None];observed=[]
 if len(packages)!=len(locked):raise ValueError("dependency count changed")
 for p in packages:
  key=(p["name"],p["version"]);r=locked[key];src=Path(p["manifest_path"]).parent
  archive=src.parents[2]/"cache"/src.parent.name/(src.name+".crate")
  raw=archive.read_bytes()
  if SHA(raw)!=r["checksum"]:raise ValueError("registry archive mismatch "+src.name)
  count=0
  with tarfile.open(archive,"r:gz") as tf:
   for m in tf:
    if m.isfile():
     name=Path(m.name).relative_to(src.name)
     old=tf.extractfile(m).read()
     if (src/name).read_bytes()!=old:raise ValueError("registry member mismatch "+str(name))
     count+=1
  observed.append(dict(name=p["name"],version=p["version"],source=p["source"],checksum=SHA(raw),members=count))
 (Q/"actual-locked-registry.json").write_text(json.dumps(observed,sort_keys=True,indent=2)+"\n")

 build=B/"build";captured={}
 for name in("bootstrap.json","B1.image.bin","B2.image.bin","B3.image.bin"):
  raw=(build/"bootstrap"/name).read_bytes();assert(BOOTSTRAP/name).read_bytes()==raw
  captured[name]=dict(bytes=len(raw),sha256=SHA(raw))
 assert captured["B3.image.bin"]["sha256"]=="bfd603dd2b40974d2083b567b4295fb3975938da8435dd636514fc197c485de0"
 (Q/"borrowed-compiler.json").write_text(json.dumps(captured,sort_keys=True,indent=2)+"\n")
 sys.path.insert(0,str(S/"scripts"))
 from hia_native_build import NativeBuild
 maker=NativeBuild(HEPTA,build);manifest=maker.compile("durable-audit-record-io-v2",S/"native/durable_audit_record_io.hepta",standalone=None)
 record_manifest=build/"modules/durable-audit-record/manifest.json"
 assert SHA(record_manifest.read_bytes())=="74157806c4151c906499d2dd9be51d537f85d00795dd2490f36c32ba9c0375b6"
 run([cargo,"build","--manifest-path",B/"reference/Cargo.toml","--release","--locked","--offline","--jobs","2","--bin","hia-durable-audit-record-io-original"],"original-rust-build",300)
 original=B/"target/release/hia-durable-audit-record-io-original"
 run([sys.executable,"-B",S/"scripts/qualify_durable_audit_record_io.py","--manifest",manifest,"--record-manifest",record_manifest,"--original",original,"--output",Q/"comparison"],"actual-original-filesystem-comparison",120)
 compared=json.loads((Q/"comparison/report.json").read_bytes());assert compared["state"]=="PASS"and compared["source_unchanged"]is True
 assert(B/"reference/Cargo.lock").read_bytes()==lock
 after=sources();(Q/"source-after.json").write_text(json.dumps(after,sort_keys=True,indent=2)+"\n");assert before==after
 report.update(state="PASS",actual_original_filesystem_cases=compared["cases"],source_unchanged=True,manifest_sha256=SHA(manifest.read_bytes()),original_sha256=SHA(original.read_bytes()),elapsed_seconds=time.monotonic()-start)
except BaseException as error:
 report.update(state="FAIL",error=type(error).__name__+": "+str(error),elapsed_seconds=time.monotonic()-start)
 (Q/"exception.txt").write_text(traceback.format_exc());print(traceback.format_exc(),flush=True)
finally:
 (Q/"terminal.json").write_text(json.dumps(report,sort_keys=True,indent=2)+"\n");print(json.dumps(report,sort_keys=True),flush=True)
raise SystemExit(0 if report["state"]=="PASS"else 1)
