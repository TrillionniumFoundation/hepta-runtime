from pathlib import Path
import os,sys,stat,hashlib,json,tarfile,io,time
B=Path("/home/qian-qi/hia-runtime-durable-requests-20261128-2ac5")
Q=B/"qualification/descriptor-checkpoint-v1";Q.mkdir(parents=True,exist_ok=False)
SHA=lambda raw:hashlib.sha256(raw).hexdigest()
def identity(path):
 s=path.lstat();return[s.st_dev,s.st_ino,s.st_mode,s.st_nlink,s.st_uid,s.st_gid,s.st_size,s.st_mtime_ns,s.st_ctime_ns]
required=["qualification/audit-record-io-native-v2","qualification/audit-record-io-boundaries-v1","qualification/audit-root-native-v1","qualification/audit-hot-native-v1","reference/audit_record_io","reference/audit_root","reference/audit_hot","reference/Cargo.toml","reference/Cargo.lock","build/modules/durable-audit-record-io-v2","build/modules/durable-audit-root-v1","build/modules/durable-audit-hot-v1","build/modules/durable-audit-record","target/release/hia-durable-audit-record-io-original","target/release/hia-durable-audit-root-original","target/release/hia-durable-audit-hot-original"]
for p in required:assert(B/p).exists(),p
for p in required[:4]:
 r=json.loads((B/p/"terminal.json").read_bytes());assert r["state"]=="PASS",p
optional=["qualification/audit-record-io-native-v1","build/modules/durable-audit-record-io-v1"]
roots=required+[p for p in optional if(B/p).exists()]
names=["scripts/author_durable_common.py","scripts/author_durable_audit_record_io.py","scripts/durable_audit_record_io_source.py.txt","native/durable_audit_record_io.hepta","native/durable_audit_record_io_composition.json","native/durable_audit_record.hepta","native/durable_audit_record_composition.json","native/request_storage_json.hepta","scripts/hia_native_build.py","scripts/hia_native_loader.py","scripts/prepare_durable_audit_record_io_reference.py","scripts/qualify_durable_audit_record_io.py","src/mcp/runtime/request_audit.rs","scripts/author_durable_audit_root.py","scripts/durable_audit_root_source.py.txt","native/durable_audit_root.hepta","native/durable_audit_root_composition.json","scripts/prepare_durable_audit_root_reference.py","scripts/qualify_durable_audit_root.py","scripts/author_durable_audit_hot.py","scripts/durable_audit_hot_source.py.txt","native/durable_audit_hot.hepta","native/durable_audit_hot_composition.json","scripts/prepare_durable_audit_hot_reference.py","scripts/qualify_durable_audit_hot.py","scripts/qualify_durable_audit_record_io_boundaries.py"]
roots.extend("source/"+n for n in names)
roots.extend(p.relative_to(B).as_posix()for p in B.iterdir()if p.is_file()and (p.name.startswith(("audit-record-io","audit-root","audit-hot","transport-audit-record-io","transport-audit-root","transport-audit-hot"))))
paths=set();pruned=[];special={}
def walk(root):
 if root.is_symlink()or root.is_file():paths.add(root);return
 def error(e):raise e
 for directory,dirs,files in os.walk(root,followlinks=False,onerror=error):
  here=Path(directory)
  for n in list(dirs):
   p=here/n
   if p.is_symlink():paths.add(p);dirs.remove(n);continue
   if n in("original","native")and "comparison"in p.parts:
    snapshot=here/(n+"-after.json")
    assert snapshot.is_file(),p
    value=json.loads(snapshot.read_bytes());assert type(value)is dict
    # Every regular payload and symlink is retained in the immutable, complete
    # post-operation snapshot. Expanded test objects remain untouched in place.
    for entry in value.values():
     mode=entry["mode"]
     if stat.S_ISREG(mode):assert "raw_hex"in entry
     if stat.S_ISLNK(mode):assert "target_hex"in entry
    pruned.append(dict(path=p.relative_to(B).as_posix(),complete_snapshot=snapshot.relative_to(B).as_posix(),snapshot_sha256=SHA(snapshot.read_bytes()),entries=len(value),expanded_retained=True))
    dirs.remove(n)
  for n in files:paths.add(here/n)
for name in roots:walk(B/name)
members={};start=time.monotonic()
with tarfile.open(Q/"all-recorded-originals.tar.gz","w:gz",compresslevel=1)as tf:
 for p in sorted(paths):
  name=p.relative_to(B).as_posix();initial=identity(p);s=p.lstat()
  if stat.S_ISREG(s.st_mode):
   raw=p.read_bytes();assert identity(p)==initial
   record=dict(kind="regular",bytes=len(raw),sha256=SHA(raw),mode=stat.S_IMODE(s.st_mode),identity=initial)
   info=tarfile.TarInfo(name);info.size=len(raw);info.mode=record["mode"];tf.addfile(info,io.BytesIO(raw))
  elif stat.S_ISLNK(s.st_mode):
   target=os.fsencode(os.readlink(p));assert identity(p)==initial
   record=dict(kind="symlink",target_hex=target.hex(),mode=stat.S_IMODE(s.st_mode),identity=initial)
  elif stat.S_ISFIFO(s.st_mode):
   record=dict(kind="fifo",mode=stat.S_IMODE(s.st_mode),identity=initial)
  else:raise ValueError("unexpected recorded object "+name)
  members[name]=record
 manifest=dict(schema="hepta.runtime.audit-descriptor-originals.v1",members=members,expanded_fixture_snapshots=pruned,required_roots=required,optional_present=[p for p in optional if(B/p).exists()],source_paths=names,failed_attempts_retained=True)
 encoded=json.dumps(manifest,sort_keys=True,indent=2).encode()+b"\n"
 info=tarfile.TarInfo("complete-manifest.json");info.size=len(encoded);info.mode=0o644;tf.addfile(info,io.BytesIO(encoded))
(Q/"complete-manifest.json").write_bytes(encoded)
raw=(Q/"all-recorded-originals.tar.gz").read_bytes();seen=set()
with tarfile.open(fileobj=io.BytesIO(raw),mode="r:gz")as tf:
 for m in tf:
  assert m.isfile()and m.name not in seen;seen.add(m.name);data=tf.extractfile(m).read()
  if m.name=="complete-manifest.json":assert data==encoded
  else:
   r=members[m.name];assert r["kind"]=="regular"and r["bytes"]==len(data)and r["sha256"]==SHA(data)and r["mode"]==m.mode
 assert seen=={n for n,r in members.items()if r["kind"]=="regular"}|{"complete-manifest.json"}
for name,r in members.items():
 p=B/name;assert identity(p)==r["identity"],name
 if r["kind"]=="regular":assert SHA(p.read_bytes())==r["sha256"]
 if r["kind"]=="symlink":assert os.fsencode(os.readlink(p)).hex()==r["target_hex"]
report=dict(state="PASS",recorded_members=len(members),regular_members=len(seen)-1,recorded_bytes=sum(r.get("bytes",0)for r in members.values()),expanded_snapshots=len(pruned),archive_bytes=len(raw),archive_sha256=SHA(raw),manifest_sha256=SHA(encoded),initial_terminal_identical=True,all_member_readback=True,elapsed_seconds=time.monotonic()-start)
(Q/"terminal.json").write_text(json.dumps(report,sort_keys=True,indent=2)+"\n")
print(json.dumps(report,sort_keys=True))
