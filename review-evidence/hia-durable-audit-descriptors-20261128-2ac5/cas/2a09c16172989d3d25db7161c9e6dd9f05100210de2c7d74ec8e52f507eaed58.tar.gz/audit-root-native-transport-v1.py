from pathlib import Path
import subprocess, sys, os, json, hashlib, time, tarfile, io, shlex, ast
B=Path("/Users/qianqi/work/hia-runtime-durable-requests-20261128-2ac5")
S=B/"source";Q=B/"qualification/audit-root-native-transport-v1";Q.mkdir(parents=True,exist_ok=False)
os.umask(0o022)
names=["scripts/author_durable_common.py","scripts/author_durable_audit_record_io.py","scripts/durable_audit_record_io_source.py.txt","native/durable_audit_record_io.hepta","native/durable_audit_record_io_composition.json","native/durable_audit_record.hepta","native/durable_audit_record_composition.json","native/request_storage_json.hepta","scripts/hia_native_build.py","scripts/hia_native_loader.py","scripts/prepare_durable_audit_record_io_reference.py","scripts/qualify_durable_audit_record_io.py","src/mcp/runtime/request_audit.rs","scripts/author_durable_audit_root.py","scripts/durable_audit_root_source.py.txt","native/durable_audit_root.hepta","native/durable_audit_root_composition.json","scripts/prepare_durable_audit_root_reference.py","scripts/qualify_durable_audit_root.py"]
sha=lambda raw:hashlib.sha256(raw).hexdigest()
captured={}
for name in names:
 p=S/name;raw=p.read_bytes()
 if name.endswith(".py"):ast.parse(raw)
 if name.startswith("src/"):
  original=subprocess.check_output(["/usr/bin/git","show","3161db718a193b69631fea3e68655f82d02aa334:"+name],cwd=S)
  if raw!=original:raise ValueError("original Git source differs "+name)
 captured["source/"+name]=raw
captured["audit-root-native-v1.py"]=(B/"audit-root-native-v1.py").read_bytes();ast.parse(captured["audit-root-native-v1.py"])
with tarfile.open(Q/"inputs.tar.gz","w:gz")as tf:
 for name,raw in captured.items():
  info=tarfile.TarInfo(name);info.size=len(raw);info.mode=0o644;tf.addfile(info,io.BytesIO(raw))
manifest={k:{"bytes":len(v),"sha256":sha(v)}for k,v in captured.items()}
(Q/"inputs.json").write_text(json.dumps(manifest,sort_keys=True,indent=2)+"\n")
archive=(Q/"inputs.tar.gz").read_bytes()
remote='''from pathlib import Path
import sys,os,hashlib,tarfile,io,json
B=Path("/home/qian-qi/hia-runtime-durable-requests-20261128-2ac5")
os.umask(0o022)
raw=sys.stdin.buffer.read()
assert hashlib.sha256(raw).hexdigest()==EXPECTED
assert B.is_dir() and (B/"qualification/audit-record-native-v1/terminal.json").is_file()
assert json.loads((B/"qualification/audit-record-native-v1/terminal.json").read_bytes())["state"]=="PASS"
(B/"transport-audit-root-inputs-v1.tar.gz").write_bytes(raw)
with tarfile.open(fileobj=io.BytesIO(raw),mode="r:gz")as tf:
 for m in tf:
  p=Path(m.name)
  assert m.isfile()and not p.is_absolute()and ".." not in p.parts
  target=B/p;target.parent.mkdir(parents=True,exist_ok=True)
  value=tf.extractfile(m).read()
  if target.exists():
   prior=target.read_bytes()
   assert prior==value,("owned source differs",m.name)
  else:
   with target.open("xb")as stream:stream.write(value)
   target.chmod(m.mode)
(B/"transport-audit-root-inputs-v1.json").write_text(MANIFEST)
os.execv(sys.executable,[sys.executable,"-I","-B",str(B/"audit-root-native-v1.py")])
'''.replace("EXPECTED",repr(sha(archive))).replace("MANIFEST",repr(json.dumps(manifest,sort_keys=True,indent=2)+"\n"))
cmd=["/usr/bin/ssh","-oBatchMode=yes","-oConnectTimeout=15","desktop","python3 -I -B -c "+shlex.quote(remote)]
(Q/"intent.json").write_text(json.dumps(dict(argv=cmd,input_bytes=len(archive),input_sha256=sha(archive)),sort_keys=True,indent=2)+"\n")
t=time.monotonic()
with (Q/"inputs.tar.gz").open("rb")as inp,(Q/"stdout").open("xb")as out,(Q/"stderr").open("xb")as err:
 child=subprocess.Popen(cmd,stdin=inp,stdout=out,stderr=err)
 (Q/"started.json").write_text(json.dumps(dict(pid=child.pid,started_ns=time.time_ns()))+"\n")
 code=child.wait()
result=dict(exit_code=code,elapsed_seconds=time.monotonic()-t)
(Q/"terminal.json").write_text(json.dumps(result,sort_keys=True,indent=2)+"\n")
print(json.dumps(result),flush=True)
print((Q/"stdout").read_text(),flush=True);print((Q/"stderr").read_text(),flush=True)
sys.exit(code)
