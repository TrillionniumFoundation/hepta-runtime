from pathlib import Path
import subprocess,hashlib,json,tarfile,io,stat,os,time
B=Path("/Users/qianqi/work/hia-runtime-durable-requests-20261128-2ac5");S=B/"source";Q=B/"qualification/descriptor-checkpoint-v1";E=S/"review-evidence/hia-durable-audit-descriptors-20261128-2ac5"
SHA=lambda raw:hashlib.sha256(raw).hexdigest()
def git(*args):return subprocess.check_output(["/usr/bin/git",*args],cwd=S,text=True).strip()
assert git("rev-parse","HEAD")=="f423b94ed9a6fadb03408e3c91d12b6b8c43cfe3"
assert git("diff","--name-only")==""and git("diff","--cached","--name-only")==""
report=json.loads((Q/"terminal.json").read_bytes());assert report["state"]=="PASS"and report["mac_readback"]is True and report["initial_terminal_identical"]is True
raw=(Q/"all-recorded-originals.tar.gz").read_bytes();assert len(raw)==4745519 and SHA(raw)=="4b15e864adeea5b17d78b234c664231886600a88c6d458f88be9d6422efc9b48"
manifest=json.loads((Q/"complete-manifest.json").read_bytes())
source_paths=["scripts/author_durable_audit_record_io.py","scripts/durable_audit_record_io_source.py.txt","native/durable_audit_record_io.hepta","native/durable_audit_record_io_composition.json","scripts/prepare_durable_audit_record_io_reference.py","scripts/qualify_durable_audit_record_io.py","scripts/author_durable_audit_root.py","scripts/durable_audit_root_source.py.txt","native/durable_audit_root.hepta","native/durable_audit_root_composition.json","scripts/prepare_durable_audit_root_reference.py","scripts/qualify_durable_audit_root.py","scripts/author_durable_audit_hot.py","scripts/durable_audit_hot_source.py.txt","native/durable_audit_hot.hepta","native/durable_audit_hot_composition.json","scripts/prepare_durable_audit_hot_reference.py","scripts/qualify_durable_audit_hot.py","scripts/qualify_durable_audit_record_io_boundaries.py","native/durable_audit_record_io_abi.md","native/durable_audit_root_abi.md","native/durable_audit_hot_abi.md"]
assert len(source_paths)==22 and len(set(source_paths))==22
for name in source_paths:
 p=S/name;assert p.is_file()
 if not name.endswith("_abi.md"):
  row=manifest["members"]["source/"+name];value=p.read_bytes();assert len(value)==row["bytes"]and SHA(value)==row["sha256"],name
for name in source_paths:(S/name).chmod(0o644)
E.mkdir(parents=True,exist_ok=False);(E/"cas").mkdir()
(E/"cas"/(SHA(raw)+".tar.gz")).write_bytes(raw)
(E/"complete-desktop-manifest.json").write_bytes((Q/"complete-manifest.json").read_bytes())
(E/"desktop-mac-readback.json").write_bytes((Q/"terminal.json").read_bytes())
selected=set()
prefixes=("audit-record-io","audit-root","audit-hot")
for directory in (B/"qualification").iterdir():
 if directory.is_dir()and directory.name.startswith(prefixes):
  for p in directory.rglob("*"):
   if p.is_file()and "__pycache__"not in p.parts:selected.add(p)
for p in B.iterdir():
 if p.is_file()and p.name.startswith(prefixes+("descriptor-checkpoint",))and p.suffix==".py":selected.add(p)
def identity(p):
 t=p.lstat();return[t.st_dev,t.st_ino,t.st_mode,t.st_nlink,t.st_uid,t.st_gid,t.st_size,t.st_mtime_ns,t.st_ctime_ns]
members={};values={}
for p in sorted(selected):
 assert stat.S_ISREG(p.lstat().st_mode)
 before=identity(p);data=p.read_bytes();assert identity(p)==before
 name=p.relative_to(B).as_posix();members[name]=dict(bytes=len(data),sha256=SHA(data),mode=stat.S_IMODE(p.stat().st_mode),identity=before);values[name]=data
local_manifest=json.dumps(dict(schema="hepta.runtime.audit-descriptor-mac-originals.v1",members=members),sort_keys=True,indent=2).encode()+b"\n"
mem=io.BytesIO()
with tarfile.open(fileobj=mem,mode="w:gz",compresslevel=1)as tf:
 for name,data in values.items():
  t=tarfile.TarInfo(name);t.mode=members[name]["mode"];t.size=len(data);tf.addfile(t,io.BytesIO(data))
 t=tarfile.TarInfo("complete-manifest.json");t.mode=0o644;t.size=len(local_manifest);tf.addfile(t,io.BytesIO(local_manifest))
local_raw=mem.getvalue()
with tarfile.open(fileobj=io.BytesIO(local_raw),mode="r:gz")as tf:
 seen=set()
 for m in tf:
  assert m.isfile()and m.name not in seen;seen.add(m.name);data=tf.extractfile(m).read()
  if m.name=="complete-manifest.json":assert data==local_manifest
  else:
   r=members[m.name];assert len(data)==r["bytes"]and SHA(data)==r["sha256"]and m.mode==r["mode"]
 assert seen==set(members)|{"complete-manifest.json"}
for name,r in members.items():assert identity(B/name)==r["identity"]and SHA((B/name).read_bytes())==r["sha256"]
(E/"cas"/(SHA(local_raw)+".tar.gz")).write_bytes(local_raw)
(E/"complete-mac-manifest.json").write_bytes(local_manifest)
qualification=dict(schema="hepta.runtime.audit-descriptor-qualification.v1",base=git("rev-parse","HEAD"),original_graph="abc9ecb95ee9538518ec3f36c47b881974107021",
 components={"record_io":{"original_actual_filesystem_cases":63,"additional_boundary_controls":30,"passed":True},"root":{"original_actual_filesystem_cases":92,"passed":True},"hot":{"original_actual_filesystem_cases":40,"passed":True,"comparison_elapsed_seconds":49.213560862932354,"comparison_timeout_seconds":120}},
 total_control_cases=225,original_actual_filesystem_cases=195,
 source={name:{"bytes":len((S/name).read_bytes()),"sha256":SHA((S/name).read_bytes())}for name in source_paths},
 desktop=report,mac={"members":len(members),"archive_bytes":len(local_raw),"archive_sha256":SHA(local_raw),"full_member_readback":True,"initial_terminal_identical":True},
 explicit_fault_injection_is_not_kernel_outcome=True,public_routing_qualified=False,archive_index_lifecycle_qualified=False,native_descriptor_engine_qualified=False,
 exact_native_compiler={"hepta":"d3e2c90173cf733e42b299d0c4274df4b593a12f","B3":"bfd603dd2b40974d2083b567b4295fb3975938da8435dd636514fc197c485de0"},
 retained_failures=["Record I/O first actual compiler refusal, unchanged old source captured; split state phases without increasing compiler or input limits","Hot author first unsupported unary Not, exact source and traceback retained; authored equivalent explicit boolean comparison"])
(E/"qualification.json").write_text(json.dumps(qualification,sort_keys=True,indent=2)+"\n")
(E/"README.md").write_text("""# Native audit directory and hot Record qualification

Three actual HIA actors now cover fixed-original Record I/O and staging cleanup,
configured root/hot directory admission, and complete hot collection. The suite
contains 195 original-versus-native real filesystem cases (63 + 92 + 40) and
30 additional actual HIA boundaries. All outcomes and full post-operation
directory snapshots are compared. Explicit error injection is labeled and is
not represented as a kernel-generated error.

Hot collection retains complete member capture before all staging cleanup,
then all Record reads, original 512/544 limits, full u128/ID ordering, and a
fresh scan description. Root admission retains original ancestor search,
current-euid/mode checks and read-only absence semantics. No unsafe directory
is repaired into acceptance, no refusal becomes absence, and close/UNKNOWN
outcomes are not replayed.

The complete recorded originals archive binds 1,649 original files, including
all raw streams, case descriptions, complete byte-bearing filesystem snapshots,
actual native images, executed fixed Rust oracle ELFs, source composition,
locked dependency receipts, and failed attempts. The 390 expanded fixture
trees are represented by their complete immutable snapshots, including raw
regular-file bytes and symlink targets; their live expanded copies remain
untouched on Desktop. Initial and terminal identities of every archived file
are checked, and Mac independently reads every archive member and mode.

The separate Mac archive preserves all matching author/transport attempts and
drivers, including original failures. qualification.json binds source and
both archives. The earlier f423 Record/Page/FIFO qualification remains its
own ancestor and is not replaced.

These are private actors. Python brokers provide qualification-only actual
system-call effects. The final native descriptor engine, global-context
integration, public ten-handler routing, v12 archive/redb index, cancellation
and restart remain separate open work. No component result claims those gates.
""")
for p in E.rglob("*"):
 if p.is_file():p.chmod(0o644)
staged=source_paths+[p.relative_to(S).as_posix()for p in E.rglob("*")if p.is_file()]
subprocess.run(["/usr/bin/git","add","--sparse","--",*staged],cwd=S,check=True)
assert sorted(git("diff","--cached","--name-only").splitlines())==sorted(staged)
subprocess.run(["/usr/bin/git","diff","--cached","--check"],cwd=S,check=True)
message=B/"descriptor-checkpoint-commit-message.txt"
message.write_text("Add native audit directory and hot Record owners\n\nPreserve original directory/Record policies and qualify 195 real filesystem\ncomparisons plus 30 native boundaries. Keep complete failed attempts and\nbyte-bearing filesystem snapshots. Public durable routing remains open.\n")
start=time.monotonic()
p=subprocess.run(["/usr/bin/git","commit","--file",str(message)],cwd=S,capture_output=True,text=True)
(B/"qualification/descriptor-checkpoint-commit.stdout").write_text(p.stdout);(B/"qualification/descriptor-checkpoint-commit.stderr").write_text(p.stderr)
assert p.returncode==0,(p.stdout,p.stderr)
assert git("diff","--name-only")==""and git("diff","--cached","--name-only")==""
result=dict(head=git("rev-parse","HEAD"),tree=git("rev-parse","HEAD^{tree}"),parent=git("rev-parse","HEAD^"),source_paths=source_paths,paths=len(staged),elapsed_seconds=time.monotonic()-start,local_only=True,mac_archive_sha256=SHA(local_raw),mac_archive_bytes=len(local_raw))
(B/"qualification/descriptor-checkpoint-commit.json").write_text(json.dumps(result,sort_keys=True,indent=2)+"\n")
print(json.dumps(result,sort_keys=True))
