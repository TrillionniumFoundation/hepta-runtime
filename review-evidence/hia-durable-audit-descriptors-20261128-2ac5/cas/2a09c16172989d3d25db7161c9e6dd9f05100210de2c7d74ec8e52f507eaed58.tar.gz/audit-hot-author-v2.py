from pathlib import Path
import subprocess,json,hashlib,time,os
B=Path("/Users/qianqi/work/hia-runtime-durable-requests-20261128-2ac5");S=B/"source";Q=B/"qualification/audit-hot-author-v2";Q.mkdir(exist_ok=False)
argv=["/opt/homebrew/bin/python3.14","-B",str(S/"scripts/author_durable_audit_hot.py"),"--runtime",str(S),"--hepta","/Users/qianqi/work/hia-ndu-current-native-20261128-2ac5/source"]
before={n:hashlib.sha256((S/n).read_bytes()).hexdigest()for n in("scripts/author_durable_common.py","scripts/author_durable_audit_hot.py","scripts/durable_audit_hot_source.py.txt","native/durable_audit_record_io.hepta")}
(Q/"intent.json").write_text(json.dumps(dict(argv=argv,source_before=before),sort_keys=True,indent=2)+"\n")
t=time.monotonic()
with(Q/"stdout").open("xb")as out,(Q/"stderr").open("xb")as err:p=subprocess.run(argv,cwd=S,stdout=out,stderr=err)
after={n:hashlib.sha256((S/n).read_bytes()).hexdigest()for n in before}
r=dict(exit_code=p.returncode,elapsed_seconds=time.monotonic()-t,source_unchanged=before==after)
if p.returncode==0:
 r["composition"]=json.loads((S/"native/durable_audit_hot_composition.json").read_bytes())
assert before==after
(Q/"terminal.json").write_text(json.dumps(r,sort_keys=True,indent=2)+"\n")
print(json.dumps(r));print((Q/"stderr").read_text());raise SystemExit(p.returncode)
