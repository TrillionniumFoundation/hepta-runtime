from pathlib import Path
import subprocess,os,json,hashlib,tarfile,time,shlex
B=Path("/Users/qianqi/work/hia-runtime-durable-requests-20261128-2ac5")
Q=B/"qualification/descriptor-checkpoint-v1";Q.mkdir(parents=True,exist_ok=False)
SHA=lambda raw:hashlib.sha256(raw).hexdigest()
remote=(B/"descriptor-checkpoint-remote-v1.py").read_text()
argv=["/usr/bin/ssh","-oBatchMode=yes","-oConnectTimeout=15","desktop","python3 -I -B -c "+shlex.quote(remote)]
(Q/"intent.json").write_text(json.dumps(dict(argv=argv),sort_keys=True,indent=2)+"\n")
start=time.monotonic()
with(Q/"desktop.stdout").open("xb")as out,(Q/"desktop.stderr").open("xb")as err:
 p=subprocess.Popen(argv,stdout=out,stderr=err);(Q/"started.json").write_text(json.dumps(dict(pid=p.pid,started_ns=time.time_ns()))+"\n");code=p.wait()
assert code==0,(code,(Q/"desktop.stderr").read_text())
report=json.loads((Q/"desktop.stdout").read_bytes());assert report["state"]=="PASS"
code_string="import sys;from pathlib import Path;sys.stdout.buffer.write(Path('/home/qian-qi/hia-runtime-durable-requests-20261128-2ac5/qualification/descriptor-checkpoint-v1/all-recorded-originals.tar.gz').read_bytes())"
argv=["/usr/bin/ssh","-oBatchMode=yes","-oConnectTimeout=15","desktop","python3 -I -B -c "+shlex.quote(code_string)]
with(Q/"all-recorded-originals.tar.gz").open("xb")as out,(Q/"transfer.stderr").open("xb")as err:p=subprocess.run(argv,stdout=out,stderr=err)
assert p.returncode==0
raw=(Q/"all-recorded-originals.tar.gz").read_bytes();assert len(raw)==report["archive_bytes"]and SHA(raw)==report["archive_sha256"]
with tarfile.open(Q/"all-recorded-originals.tar.gz","r:gz")as tf:
 manifest_raw=tf.extractfile("complete-manifest.json").read();manifest=json.loads(manifest_raw);assert SHA(manifest_raw)==report["manifest_sha256"];seen=set()
 for m in tf:
  assert m.isfile()and m.name not in seen and not Path(m.name).is_absolute()and ".."not in Path(m.name).parts
  seen.add(m.name);data=tf.extractfile(m).read()
  if m.name=="complete-manifest.json":assert data==manifest_raw
  else:
   r=manifest["members"][m.name];assert r["kind"]=="regular"and len(data)==r["bytes"]and SHA(data)==r["sha256"]and m.mode==r["mode"]
 assert seen=={n for n,r in manifest["members"].items()if r["kind"]=="regular"}|{"complete-manifest.json"}
(Q/"complete-manifest.json").write_bytes(manifest_raw)
for name in manifest["source_paths"]:
 r=manifest["members"]["source/"+name];v=(B/"source"/name).read_bytes()
 assert len(v)==r["bytes"]and SHA(v)==r["sha256"],name
report.update(mac_readback=True,source_matches_actual_mac=True,mac_elapsed_seconds=time.monotonic()-start)
(Q/"terminal.json").write_text(json.dumps(report,sort_keys=True,indent=2)+"\n")
print(json.dumps(report,sort_keys=True))
