from pathlib import Path
import subprocess, os, json, hashlib, time, sys
B=Path("/Users/qianqi/work/hia-runtime-durable-requests-20261128-2ac5")
S=B/"source"; Q=B/"qualification/audit-fifo-author-v3"; Q.mkdir(parents=True,exist_ok=False)
H=Path("/Users/qianqi/work/hia-ndu-current-native-20261128-2ac5/source")
os.umask(0o022)
argv=["/opt/homebrew/bin/python3.14","-B",str(S/"scripts/author_durable_audit_fifo.py"),"--runtime",str(S),"--hepta",str(H)]
inputs=[S/"scripts/author_durable_common.py",S/"scripts/author_durable_audit_fifo.py",S/"scripts/durable_audit_fifo_source.py.txt",S/"native/request_storage_json.hepta",S/"src/mcp/runtime/request_audit.rs"]
pin=lambda p:dict(bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
before={str(p):pin(p) for p in inputs}
(Q/"intent.json").write_text(json.dumps(dict(argv=argv,cwd=str(S),source_before=before),sort_keys=True,indent=2)+"\n")
t=time.monotonic()
with (Q/"stdout").open("xb") as out,(Q/"stderr").open("xb") as err:
 p=subprocess.run(argv,cwd=S,stdout=out,stderr=err,timeout=120)
after={str(p):pin(p) for p in inputs}
r=dict(exit_code=p.returncode,elapsed_seconds=time.monotonic()-t,source_unchanged=before==after)
(Q/"terminal.json").write_text(json.dumps(r,sort_keys=True,indent=2)+"\n")
print(json.dumps(r),flush=True)
print((Q/"stdout").read_text(),flush=True)
print((Q/"stderr").read_text(),flush=True)
sys.exit(p.returncode)
