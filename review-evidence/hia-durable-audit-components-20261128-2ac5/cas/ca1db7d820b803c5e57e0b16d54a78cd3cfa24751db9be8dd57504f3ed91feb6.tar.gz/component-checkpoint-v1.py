from pathlib import Path
import subprocess,hashlib,json,tarfile,io,shlex,time,sys
B=Path("/Users/qianqi/work/hia-runtime-durable-requests-20261128-2ac5");Q=B/"qualification/component-checkpoint-v1";Q.mkdir(parents=True,exist_ok=False)
code=(B/"component-checkpoint-remote-v1.py").read_text()
argv=["/usr/bin/ssh","-oBatchMode=yes","-oConnectTimeout=15","desktop","python3 -I -B -c "+shlex.quote(code)]
(Q/"intent.json").write_text(json.dumps(dict(argv=argv),sort_keys=True,indent=2)+"\n");start=time.monotonic()
with (Q/"all-originals.tar.gz").open("xb")as out,(Q/"stderr").open("xb")as err:
 p=subprocess.Popen(argv,stdout=out,stderr=err);(Q/"started.json").write_text(json.dumps(dict(pid=p.pid,started_ns=time.time_ns()))+"\n");code=p.wait()
if code:print((Q/"stderr").read_text());raise SystemExit(code)
report=json.loads((Q/"stderr").read_text().strip());raw=(Q/"all-originals.tar.gz").read_bytes()
assert report["state"]=="PASS"and len(raw)==report["archive_bytes"]and hashlib.sha256(raw).hexdigest()==report["archive_sha256"]
with tarfile.open(fileobj=io.BytesIO(raw),mode="r:gz")as tf:
 manifest=tf.extractfile("complete-manifest.json").read();assert hashlib.sha256(manifest).hexdigest()==report["manifest_sha256"]
 entries=json.loads(manifest)["members"];seen=set()
 for m in tf:
  if m.name=="complete-manifest.json":continue
  assert m.isfile()and m.name in entries and m.name not in seen;seen.add(m.name);value=tf.extractfile(m).read();row=entries[m.name]
  assert len(value)==row["bytes"]and hashlib.sha256(value).hexdigest()==row["sha256"]and m.mode==row["mode"]
 assert seen==set(entries)
(Q/"complete-manifest.json").write_bytes(manifest)
report.update(mac_readback=True,elapsed_seconds=time.monotonic()-start,exit_code=code)
(Q/"terminal.json").write_text(json.dumps(report,sort_keys=True,indent=2)+"\n");print(json.dumps(report,sort_keys=True))
