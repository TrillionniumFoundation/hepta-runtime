from pathlib import Path
import json,re,subprocess
S=Path("/Users/qianqi/work/hia-runtime-durable-requests-20261128-2ac5/source")
names=subprocess.run(["/usr/bin/git","ls-files","--","native","scripts"],cwd=S,capture_output=True,check=True).stdout.decode().splitlines()
print(json.dumps({"native_candidates":[n for n in names if n.startswith("native/")and n.endswith((".hepta",".md",".py"))and re.search("audit|history|archive|request|operation|metadata|retention|index",n)],
"authors":[n for n in names if n.startswith("scripts/")and re.search("author|gateway|generate|public.*build|mcp.*build|common",n)]}),flush=True)
