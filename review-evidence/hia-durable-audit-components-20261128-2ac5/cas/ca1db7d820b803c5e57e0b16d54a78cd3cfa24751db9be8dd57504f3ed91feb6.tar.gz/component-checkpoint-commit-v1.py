from pathlib import Path
import subprocess,hashlib,json,tarfile,io,stat,os,time
B=Path("/Users/qianqi/work/hia-runtime-durable-requests-20261128-2ac5");S=B/"source";Q=B/"qualification/component-checkpoint-v1";E=S/"review-evidence/hia-durable-audit-components-20261128-2ac5"
SHA=lambda x:hashlib.sha256(x).hexdigest()
def git(*args):return subprocess.check_output(["/usr/bin/git",*args],cwd=S,text=True).strip()
assert git("rev-parse","HEAD")=="3161db718a193b69631fea3e68655f82d02aa334"
assert git("diff","--name-only")==""
report=json.loads((Q/"terminal.json").read_text());assert report["state"]=="PASS"and report["mac_readback"]is True and report["initial_terminal_identical"]is True
raw=(Q/"all-originals.tar.gz").read_bytes();assert len(raw)==4689440 and SHA(raw)=="66b8fcc6dde13a45a40c6fc34212ce7e009545509160ab200a97c9f4ec7f11fd"
manifest=json.loads((Q/"complete-manifest.json").read_text())
source_paths=sorted({line for line in git("ls-files","--others","--exclude-standard").splitlines()if line.startswith(("native/durable_audit_","scripts/author_durable_","scripts/durable_audit_","scripts/prepare_durable_audit_","scripts/qualify_durable_audit_"))})
assert len(source_paths)==20,(len(source_paths),source_paths)
for name in source_paths:
 r=manifest["members"]["source/"+name];value=(S/name).read_bytes()
 assert SHA(value)==r["sha256"]and len(value)==r["bytes"],name
DOCS=json.loads("{\"native/durable_audit_record_abi.md\":\"# Durable audit Record, private ABI 1\\n\\nThis component owns the complete original `request_audit::Record` JSON type and the\\nadditional filename/identity checks of `read_record`. It does not authorize an\\nowner, open files, select an archive, or implement a public Runtime handler.\\n\\nAll integers are unsigned little-endian. The six-argument flat HIA ABI uses an\\nimmutable input, output, and private workspace. The return is the output length,\\n`0xffffffff` for a malformed private frame, or `0xfffffffe` for insufficient\\ncapacity. A private-frame failure produces no output.\\n\\nInput starts with `HRAJQ001`: operation at 8, JSON byte length at 16, filename\\nlength at 24, then filename and JSON. Operation 1 is the exact typed Record\\ndomain; operation 2 additionally requires a 69-byte lowercase hexadecimal ID\\nplus `.json` filename, matching request ID/owner/tool identity. Both operations retain the original\\n2,048-byte JSON bound. The filename is checked before the JSON.\\n\\nOutput starts with `HRAJR001`. Error results are 32 bytes: diagnostic at 8\\n(1 JSON type, 2 identity, 3 size, 4 filename), remaining words zero.\\nA successful result contains a 128-byte header followed by decoded UTF-8 request\\nID, owner, and tool name. Header words: diagnostic 0; state at 16\\n(0 unknown, 1 completed, 2 failed); accepted timestamp low/high words at 24/32;\\nelapsed-present and elapsed milliseconds at 40/48; total length at 56; three\\noffset/length pairs at 64/72, 80/88, 96/104; reserved zero at 112/120.\\n\\nThe JSON owner retains the original six-field map and sequence forms, optional\\nelapsed field, externally tagged unit-state form, decoded-key duplicate and\\nunknown-field rejection, full Unicode decoding, and unsigned 128-bit timestamp\\nrange. Its qualification compares complete output bytes to independently\\ncompiled original Rust/Serde sources; it does not replace the public storage\\nand source-custody gates.\\n\",\"native/durable_audit_page_abi.md\":\"# Durable audit page selection, private ABI 1\\n\\nThis component owns the original history sort/cursor/filter selection and\\narchive-page JSON rendering. It receives already captured rows; the caller must\\nprovide the real owner capability, guarded archive/index snapshot, current\\nactive state, and monotonic query deadline. This module alone supplies no\\nfilesystem, archive integrity, clock, or public owner authority.\\n\\nInput is `HRAQP001`, 192-byte header followed by 256-byte rows. Header words:\\noperation at 8 (1 history, 2 archive); row count 16; limit 24 (1..32);\\ncursor-present 32; archive total 40; now/deadline 48/56. Bytes 64..127 are the\\n64 lowercase hexadecimal owner; 128..191 are a matching-format cursor or zeros.\\nHistory requires total/now/deadline zero and at most 512 rows. Archive requires\\nat most limit+1 rows, all owned, already strictly ordered, total >= row count,\\nand an absent cursor (the indexed range has already applied it).\\n\\nEach row contains request ID at 0..63, owner at 64..127, tool bytes in a zero\\npadded 64-byte area at 128, tool length at 192, state at 200, full timestamp\\nlow/high at 208/216, elapsed-present/value at 224/232, actual-active boolean\\nat 240, and a zero reserved word at 248. Rows have distinct IDs.\\n\\nHistory filters by owner, sorts by the full unsigned 128-bit timestamp and ID,\\nchecks the owner-local cursor, and emits the original page and active-state\\nprojection. Archive renders the already guarded ordered range with original\\nnext-cursor and total semantics. It does not substitute a full directory scan\\nfor the original indexed archive query.\\n\\nOutput `HRAQR001` has a 32-byte header: diagnostic at 8, JSON length at 16,\\ntotal length at 24, followed by exact original compact JSON.\\nDiagnostics are 0 success, 1 parameters, 2 cursor, 3 selected timestamp cannot\\nbe represented by the original JSON number domain, 4 deadline, 5 wire bound.\\nPrivate malformed input returns `0xffffffff`; short output/workspace returns\\n`0xfffffffe`. Complete original Rust JSON bytes are compared in qualification.\\n\",\"native/durable_audit_fifo_abi.md\":\"# Durable audit FIFO owner, private ABI 1\\n\\nThis HIA component owns the original writer/reader admission queue, ticket\\nallocation, reservations, poisoning, deadlines, and release transitions.\\nThe installed broker must serialize calls with the same actual audit queue\\nmutex, supply its actual monotonic clock and lock outcomes, and retain the\\nactual inner/file I/O guard until the corresponding transition. Private frames\\nare not public MCP parameters. The Rust fixture in scripts is qualification\\nonly: it provides real Mutex/Condvar/Instant and maps native decisions, without\\na replacement Rust admission policy.\\n\\nThe 64-byte input is `HRAFL001`, followed by operation, monotonic now,\\ndeadline-present, deadline, ticket, outcome flags, zero reserved word.\\nFlags are bit 0 queue poisoned, bit 1 inner mutex poisoned, bit 2 actual\\ntry-lock WouldBlock, bit 3 current thread panicking.\\n\\nOperations:\\n\\n| Op | Meaning |\\n| --- | --- |\\n| 0 | Initialize a zero workspace |\\n| 1 | Enqueue a writer; optional deadline |\\n| 2 | Enqueue a reader; deadline required |\\n| 3 | Poll this exact FIFO ticket |\\n| 4 | Check time after reservation; request writer inner-lock attempt |\\n| 5 | Report actual writer inner-lock attempt |\\n| 6 | Drop writer, after the actual inner guard has dropped |\\n| 7 | Finish reader while holding the final queue snapshot lock |\\n| 8 | Drop reader; panic poisons the store |\\n| 9 | Cancel a waiter after an actual poisoned Condvar wait |\\n| 10 | Deadline preflight before acquiring queue mutex |\\n\\nOutput is 64 bytes, `HRAFO001`, status, ticket, required workspace, notify,\\nthen three zero words. Status: 0 finished, 1 queued, 2 reserved, 3 held,\\n4 deadline, 5 unavailable, 7 grow workspace, 8 perform actual inner try-lock.\\nMalformed input/state returns `0xffffffff` with no mutation; short output\\nreturns `0xfffffffe`.\\n\\nWorkspace is `HRQST001`, next ticket, writer-active, writer ticket,\\nreader count, reader-poisoned, live entry count, then 72 zero bytes.\\nEach 64-byte entry is ticket, access (1 writer / 2 reader), phase\\n(1 waiting / 2 reserved / 3 held / 4 writer-inner-pending), deadline-present,\\ndeadline, and three zero words. Every call validates the full state, ticket\\nordering/uniqueness, reservations, and reader/writer exclusion.\\n\\nThere is no application queue cap. Grow is a read-only result, consumes no\\nticket, and permits the broker to grow its owned workspace before submitting\\nthe same admission. Ticket overflow refuses. A deadline does not autonomously\\nrelease a held reservation or a running blocking operation. Writer failure\\nretains the reservation until actual inner guard drop plus operation 6; a\\nreader requires finish/drop. Finished reads are not retroactively poisoned.\\n\\nQualification preserves all nine complete original multithreaded method\\nbodies and their budgets, including 32 parallel readers and queued writers.\\nTwenty-six additional actual HIA controls exercise malformed states, forged\\ntickets, release replay, expiration, exact grow, and capacity boundaries.\\n\"}")
for name,text in DOCS.items():
 p=S/name;assert not p.exists();p.write_text(text)
source_paths+=sorted(DOCS)
E.mkdir(parents=True,exist_ok=False);(E/"cas").mkdir()
(E/"cas"/(SHA(raw)+".tar.gz")).write_bytes(raw)
(E/"complete-desktop-manifest.json").write_bytes((Q/"complete-manifest.json").read_bytes())
(E/"desktop-mac-readback.json").write_bytes((Q/"terminal.json").read_bytes())
local_paths=set()
for p in (B/"qualification").rglob("*"):
 if p.is_file()and not p.is_relative_to(Q)and "__pycache__"not in p.parts:local_paths.add(p)
for p in B.iterdir():
 if p.is_file()and p.suffix in(".py",".json"):local_paths.add(p)
def ident(p):
 s=p.lstat();return[s.st_dev,s.st_ino,s.st_mode,s.st_nlink,s.st_uid,s.st_gid,s.st_size,s.st_mtime_ns,s.st_ctime_ns]
local_entries={};values={}
for p in sorted(local_paths):
 assert stat.S_ISREG(p.lstat().st_mode)
 name=p.relative_to(B).as_posix();before=ident(p);value=p.read_bytes();assert ident(p)==before
 local_entries[name]=dict(bytes=len(value),sha256=SHA(value),mode=stat.S_IMODE(p.stat().st_mode),identity=before);values[name]=value
local_manifest=json.dumps(dict(schema="hepta.runtime.durable-audit-mac-originals.v1",members=local_entries),sort_keys=True,indent=2).encode()+b"\n"
mem=io.BytesIO()
with tarfile.open(fileobj=mem,mode="w:gz")as tf:
 for name,value in values.items():
  ti=tarfile.TarInfo(name);ti.size=len(value);ti.mode=local_entries[name]["mode"];tf.addfile(ti,io.BytesIO(value))
 ti=tarfile.TarInfo("complete-manifest.json");ti.size=len(local_manifest);ti.mode=0o644;tf.addfile(ti,io.BytesIO(local_manifest))
local_raw=mem.getvalue()
with tarfile.open(fileobj=io.BytesIO(local_raw),mode="r:gz")as tf:
 seen=set()
 for m in tf:
  assert m.isfile()and m.name not in seen;seen.add(m.name);value=tf.extractfile(m).read()
  if m.name=="complete-manifest.json":assert value==local_manifest
  else:assert SHA(value)==local_entries[m.name]["sha256"]and len(value)==local_entries[m.name]["bytes"]
 assert seen==set(local_entries)|{"complete-manifest.json"}
for name,row in local_entries.items():assert ident(B/name)==row["identity"]and SHA((B/name).read_bytes())==row["sha256"]
(E/"cas"/(SHA(local_raw)+".tar.gz")).write_bytes(local_raw)
(E/"complete-mac-manifest.json").write_bytes(local_manifest)
qualification=dict(schema="hepta.runtime.durable-audit-components-qualification.v1",base=git("rev-parse","HEAD"),original_graph="abc9ecb95ee9538518ec3f36c47b881974107021",components={
 "record":dict(original_full_byte_comparisons=6708,negative_capacity_controls=12,actual_native_calls=6720,passed=True),
 "page":dict(original_full_byte_comparisons=1832,negative_capacity_controls=26,actual_native_calls=1858,passed=True),
 "fifo":dict(original_complete_multithreaded_methods=9,original_rust_passed=9,native_original_methods_passed=9,additional_actual_controls=26,passed=True)},
 native_compiler=dict(hepta="d3e2c90173cf733e42b299d0c4274df4b593a12f",B3_image_sha256="bfd603dd2b40974d2083b567b4295fb3975938da8435dd636514fc197c485de0"),
 public_handler_routing_qualified=False,filesystem_archive_lifecycle_qualified=False,
 desktop=report,mac=dict(members=len(local_entries),bytes=sum(v["bytes"]for v in local_entries.values()),archive_bytes=len(local_raw),archive_sha256=SHA(local_raw),complete_member_readback=True,initial_terminal_identical=True),
 source={name:dict(bytes=len((S/name).read_bytes()),sha256=SHA((S/name).read_bytes()))for name in source_paths},
 retained_failures=["FIFO author v1 unsupported DSL move_range","FIFO author v2 fill count semantics corrected before native execution","FIFO native v1 Rust-only fixture LowerHex compilation failure","FIFO native v2 unique build-directory precondition failure"])
(E/"qualification.json").write_text(json.dumps(qualification,sort_keys=True,indent=2)+"\n")
(E/"README.md").write_text("""# Native durable audit component qualification

This commit adds three independent HIA owners for the exact original audit
Record type, page selection/rendering, and FIFO admission transitions. It does
not claim the ten public durable-request/operation interfaces are routed, nor
that archive storage, filesystem I/O, restart, or cancellation is qualified.

The original Rust graph is preserved as a separate oracle. Record: 6,708
complete-byte comparisons plus 12 controls. Page: 1,832 complete-byte
comparisons plus 26 controls. FIFO: all nine original complete multithreaded
methods passed on the original Rust and on actual HIA decisions, with original
timeouts and assertions unchanged, plus 26 additional actual HIA boundaries.

qualification.json identifies the exact native compiler, each source, and both
complete content archives. complete-desktop-manifest.json binds 293 original
files including all corpora, native images, executed Rust test ELFs, outputs,
build/registry validation, and failures. The desktop archive was independently
read on Mac with every member hash and mode checked. The separate Mac archive
retains complete author/transport attempts and drivers, including failed
attempts. No failed attempt was replaced with a later result.

The FIFO Rust broker is qualification-only mechanical scheduling around the
actual HIA state machine. Its real clock, Mutex/Condvar and inner guards are
not a replacement production policy. Production integration must provide the
same private capabilities and preserve the original operation lifetime.
""")
for name in source_paths:(S/name).chmod(0o644)
for p in E.rglob("*"):
 if p.is_file():p.chmod(0o644)
staged=source_paths+[p.relative_to(S).as_posix()for p in E.rglob("*")if p.is_file()]
subprocess.run(["/usr/bin/git","add","--sparse","--",*staged],cwd=S,check=True)
assert sorted(git("diff","--cached","--name-only").splitlines())==sorted(staged)
subprocess.run(["/usr/bin/git","diff","--cached","--check"],cwd=S,check=True)
msg=B/"component-checkpoint-commit-message.txt";msg.write_text("Add native durable audit Record, page and FIFO owners\n\nPreserve the complete original Rust oracle and all failed attempts. Qualify\nwhole-byte record/page results and all nine original multithreaded FIFO\nmethods plus native refusal controls. Public storage/routing remains open.\n")
start=time.monotonic();p=subprocess.run(["/usr/bin/git","commit","--file",str(msg)],cwd=S,capture_output=True,text=True)
(B/"qualification/component-checkpoint-git-commit.stdout").write_text(p.stdout);(B/"qualification/component-checkpoint-git-commit.stderr").write_text(p.stderr)
assert p.returncode==0,(p.stdout,p.stderr)
assert git("diff","--name-only")==""and git("diff","--cached","--name-only")==""
result=dict(head=git("rev-parse","HEAD"),tree=git("rev-parse","HEAD^{tree}"),parent=git("rev-parse","HEAD^"),source_paths=source_paths,paths=len(staged),elapsed_seconds=time.monotonic()-start,local_only=True,qualification=qualification)
(B/"qualification/component-checkpoint-commit.json").write_text(json.dumps(result,sort_keys=True,indent=2)+"\n")
print(json.dumps({k:v for k,v in result.items()if k!="qualification"},sort_keys=True))
