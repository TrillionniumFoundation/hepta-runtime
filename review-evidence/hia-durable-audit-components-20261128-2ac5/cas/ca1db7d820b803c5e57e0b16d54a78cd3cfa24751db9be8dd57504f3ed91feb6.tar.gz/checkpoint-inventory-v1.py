from pathlib import Path
import subprocess,json,hashlib,os
B=Path("/Users/qianqi/work/hia-runtime-durable-requests-20261128-2ac5");S=B/"source";Q=B/"qualification/component-checkpoint-v1"
def git(*args):return subprocess.check_output(["/usr/bin/git",*args],cwd=S,text=True)
r=json.loads((Q/"terminal.json").read_text());m=json.loads((Q/"complete-manifest.json").read_text())
print(json.dumps({"head":git("rev-parse","HEAD").strip(),"branch":git("branch","--show-current").strip(),"status":git("status","--short","--untracked-files=all"),"archive":r,"executed_binaries":[[p,v["bytes"],v["sha256"]]for p,v in m["members"].items()if p.startswith("target/")],"ssh_pid_live":subprocess.run(["/bin/ps","-p","25960","-o","pid=,ppid=,comm="],capture_output=True,text=True).stdout},sort_keys=True))
