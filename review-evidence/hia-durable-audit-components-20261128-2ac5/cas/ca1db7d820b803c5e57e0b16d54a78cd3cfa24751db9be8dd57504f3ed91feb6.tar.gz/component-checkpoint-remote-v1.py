from pathlib import Path
import hashlib,json,os,stat,tarfile,io,re,time
B=Path("/home/qian-qi/hia-runtime-durable-requests-20261128-2ac5");Q=B/"component-checkpoint-v1";Q.mkdir(exist_ok=False)
SHA=lambda raw:hashlib.sha256(raw).hexdigest()
def ident(p):
 s=p.lstat();return[s.st_dev,s.st_ino,s.st_mode,s.st_nlink,s.st_uid,s.st_gid,s.st_size,s.st_mtime_ns,s.st_ctime_ns]
paths=set()
for folder in ("source","reference","build/modules","build/bootstrap","qualification"):
 for p in (B/folder).rglob("*"):
  if p.is_file()and"__pycache__"not in p.parts and not p.name.endswith(".pyc"):paths.add(p)
for p in B.iterdir():
 if p.is_file()and(p.suffix in(".py",".json")or p.name.endswith(".tar.gz")or p.name=="original-failed-fifo-fixture-v1.rs.txt"):paths.add(p)
for name in ("hia-durable-audit-record-original","hia-durable-audit-page-original"):paths.add(B/"target/release"/name)
for folder in ("audit-fifo-native-v1","audit-fifo-native-v3"):
 for p in (B/"qualification"/folder).glob("*methods.stderr"):
  for name in re.findall(r"Running [^\n]*\(([^()]+hia_durable_audit_fifo_[^() ]+)\)",p.read_text()):
   binary=Path(name)
   if not binary.is_absolute():binary=B/"reference"/binary
   if not binary.is_file():raise ValueError("executed original/native test binary unavailable")
   paths.add(binary.resolve())
for p in paths:
 if not p.is_relative_to(B)or not stat.S_ISREG(p.lstat().st_mode):raise ValueError("unexpected archive member")
records={};originals={}
for p in sorted(paths):
 name=p.relative_to(B).as_posix();before=ident(p);raw=p.read_bytes()
 if ident(p)!=before:raise ValueError("changed during capture "+name)
 records[name]=dict(bytes=len(raw),sha256=SHA(raw),mode=stat.S_IMODE(p.stat().st_mode),identity=before);originals[name]=raw
manifest=json.dumps({"schema":"hepta.runtime.durable-audit-component-originals.v1","members":records},sort_keys=True,indent=2).encode()+b"\n"
archive=Q/"all-originals.tar.gz"
with tarfile.open(archive,"w:gz")as tf:
 for name,raw in originals.items():
  info=tarfile.TarInfo(name);info.size=len(raw);info.mode=records[name]["mode"];tf.addfile(info,io.BytesIO(raw))
 info=tarfile.TarInfo("complete-manifest.json");info.size=len(manifest);info.mode=0o644;tf.addfile(info,io.BytesIO(manifest))
for name,row in records.items():
 p=B/name
 if ident(p)!=row["identity"]or SHA(p.read_bytes())!=row["sha256"]:raise ValueError("terminal source/evidence changed "+name)
raw=archive.read_bytes()
with tarfile.open(fileobj=io.BytesIO(raw),mode="r:gz")as tf:
 got={m.name:tf.extractfile(m).read()for m in tf if m.isfile()}
if set(got)!=(set(records)|{"complete-manifest.json"}):raise ValueError("archive exact set differs")
for name,row in records.items():
 if len(got[name])!=row["bytes"]or SHA(got[name])!=row["sha256"]:raise ValueError("archive member differs")
report=dict(state="PASS",members=len(records),source_bytes=sum(v["bytes"]for v in records.values()),archive_bytes=len(raw),archive_sha256=SHA(raw),manifest_sha256=SHA(manifest),initial_terminal_identical=True)
(Q/"receipt.json").write_text(json.dumps(report,sort_keys=True,indent=2)+"\n")
import sys
print(json.dumps(report,sort_keys=True),file=sys.stderr,flush=True)
sys.stdout.buffer.write(raw);sys.stdout.buffer.flush()
