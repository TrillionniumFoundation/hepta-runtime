from pathlib import Path
import subprocess,hashlib,json,time,shlex,sys
B=Path("/Users/qianqi/work/hia-runtime-durable-requests-20261128-2ac5");Q=B/"qualification/audit-fifo-boundaries-v1";Q.mkdir(parents=True,exist_ok=False)
source=(B/"source/scripts/qualify_durable_audit_fifo_boundaries.py").read_bytes()
remote=r'''from pathlib import Path
import sys,hashlib,subprocess,time,json
B=Path("/home/qian-qi/hia-runtime-durable-requests-20261128-2ac5");Q=B/"qualification/audit-fifo-boundaries-v1";Q.mkdir(parents=True,exist_ok=False)
raw=sys.stdin.buffer.read();assert hashlib.sha256(raw).hexdigest()==EXPECTED
p=B/"source/scripts/qualify_durable_audit_fifo_boundaries.py"
with p.open("xb")as stream:stream.write(raw)
argv=[sys.executable,"-I","-B",str(p),"--manifest",str(B/"build/modules/durable-audit-fifo-v3/manifest.json"),"--output",str(Q/"controls")]
t=time.monotonic()
with (Q/"stdout").open("xb")as out,(Q/"stderr").open("xb")as err:r=subprocess.run(argv,stdout=out,stderr=err,timeout=60)
report=dict(argv=argv,exit_code=r.returncode,elapsed_seconds=time.monotonic()-t)
(Q/"terminal.json").write_text(json.dumps(report,sort_keys=True,indent=2)+"\n")
print(json.dumps(report));print((Q/"stdout").read_text());print((Q/"stderr").read_text());sys.exit(r.returncode)
'''.replace("EXPECTED",repr(hashlib.sha256(source).hexdigest()))
argv=["/usr/bin/ssh","-oBatchMode=yes","-oConnectTimeout=15","desktop","python3 -I -B -c "+shlex.quote(remote)]
(Q/"intent.json").write_text(json.dumps(dict(argv=argv,source_sha256=hashlib.sha256(source).hexdigest()),sort_keys=True,indent=2)+"\n")
t=time.monotonic()
with (Q/"stdout").open("xb")as out,(Q/"stderr").open("xb")as err:r=subprocess.run(argv,input=source,stdout=out,stderr=err)
report=dict(exit_code=r.returncode,elapsed_seconds=time.monotonic()-t)
(Q/"terminal.json").write_text(json.dumps(report)+"\n");print(json.dumps(report));print((Q/"stdout").read_text());print((Q/"stderr").read_text());sys.exit(r.returncode)
