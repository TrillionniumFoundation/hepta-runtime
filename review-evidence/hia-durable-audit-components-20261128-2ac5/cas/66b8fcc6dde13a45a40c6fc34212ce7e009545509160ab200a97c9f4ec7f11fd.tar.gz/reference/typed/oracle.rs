// Original type bodies and default functions are copied byte-for-byte.
// Copyright 2026 Muvon Un Limited; Copyright 2026 TrillionniumFoundation
// SPDX-License-Identifier: Apache-2.0
use serde::{Deserialize, Serialize};
use std::io::{self, BufRead};


pub mod mcp {

pub mod weight_config { use serde::{Deserialize,Serialize};

#[derive(Clone, Debug, Deserialize, Serialize, PartialEq, Eq)]
#[serde(deny_unknown_fields)]
pub struct WeightWorkerProfile {
	pub host: String,
	pub python_executable: String,
	pub worker_path: String,
	pub worker_sha256: String,
	/// Whole package identity in addition to the mandatory entry-point identity.
	#[serde(default)]
	pub worker_package_sha256: Option<String>,
	/// Explicit installation on the worker host; never infer the controller path.
	/// Omission preserves the historical profile serialization and Python client.
	#[serde(default, skip_serializing_if = "Option::is_none")]
	pub native_client: Option<WeightNativeClientProfile>,
	pub session_root: String,
	pub input_roots: Vec<String>,
	pub allowed_providers: Vec<String>,
	#[serde(default = "default_memory")]
	pub max_memory_bytes: u64,
	#[serde(default = "default_threads")]
	pub max_cpu_threads: u8,
	#[serde(default = "default_lifetime")]
	pub max_lifetime_seconds: u64,
	#[serde(default = "default_request")]
	pub max_request_ms: u64,
	/// Legacy identity field retained for existing profile digests; no concurrency cap is applied.
	#[serde(default = "default_sessions")]
	pub max_active_sessions: usize,
	#[serde(default = "default_calls")]
	pub max_requests_per_session: usize,
}

#[derive(Clone, Debug, Deserialize, Serialize, PartialEq, Eq)]
#[serde(deny_unknown_fields)]
pub struct WeightNativeClientProfile {
	pub executable: String,
	pub sha256: String,
}

fn default_memory() -> u64 {
	4 * 1024 * 1024 * 1024
}

fn default_threads() -> u8 {
	2
}

fn default_lifetime() -> u64 {
	1800
}

fn default_request() -> u64 {
	120_000
}

fn default_sessions() -> usize {
	1
}

fn default_calls() -> usize {
	128
}

}

pub mod rea_provider { use serde::{Deserialize,Serialize}; use std::collections::BTreeMap;

#[derive(Clone, Copy, Debug, Deserialize, Serialize, PartialEq, Eq, schemars::JsonSchema)]
#[serde(rename_all = "snake_case")]
pub enum StaticProvider {
	GnuReadelf,
	GnuObjdump,
	Jadx,
	Ghidra,
}

#[derive(
	Clone, Copy, Debug, Deserialize, Serialize, PartialEq, Eq, PartialOrd, Ord, schemars::JsonSchema,
)]
#[serde(rename_all = "snake_case")]
pub enum StaticOperation {
	Headers,
	Sections,
	Symbols,
	Notes,
	Relocations,
	Classes,
	Sources,
	Inventory,
	Functions,
	Function,
	Decompile,
	Xrefs,
}

#[derive(Clone, Debug, Deserialize, Serialize, PartialEq, Eq)]
#[serde(deny_unknown_fields)]
pub struct JavaEngineProfile {
	pub java_home: String,
	pub jar_path: String,
	pub jar_sha256: String,
	pub engine_version: String,
	/// Distribution provenance, independently verified when the admin installs it.
	pub release_archive_sha256: String,
	/// Exact relative JRE files and their pins; system shared libraries remain outside this set.
	pub runtime_files: BTreeMap<String, String>,
}

#[derive(Clone, Debug, Deserialize, Serialize, PartialEq, Eq)]
#[serde(deny_unknown_fields)]
pub struct ReaStaticProfile {
	pub host: String,
	pub runtime_executable: String,
	pub runtime_sha256: String,
	pub provider: StaticProvider,
	pub backend_executable: String,
	pub backend_sha256: String,
	/// Exact first line of the admitted backend's `--version` output under LC_ALL=C.
	pub backend_version: String,
	pub working_directory: String,
	pub input_roots: Vec<String>,
	pub allowed_operations: Vec<StaticOperation>,
	#[serde(default = "default_artifact_bytes")]
	pub max_artifact_bytes: u64,
	#[serde(default = "default_output_bytes")]
	pub max_output_bytes: usize,
	#[serde(default = "default_timeout")]
	pub timeout_seconds: u64,
	#[serde(default = "default_memory")]
	pub memory_max_bytes: u64,
	#[serde(default, skip_serializing_if = "Option::is_none")]
	pub java_engine: Option<JavaEngineProfile>,
	#[serde(default, skip_serializing_if = "Option::is_none")]
	pub ghidra_engine: Option<GhidraEngineProfile>,
}

#[derive(Clone, Debug, Deserialize, Serialize, PartialEq, Eq)]
#[serde(deny_unknown_fields)]
pub struct GhidraEngineProfile {
	/// Absent and revision 2 retain Ghidra 12.2; revisions 3 and 4 select fixed 12.1.4.
	#[serde(default, skip_serializing_if = "Option::is_none")]
	pub bridge_revision: Option<u32>,
	pub java_home: String,
	pub installation_root: String,
	pub manifest_path: String,
	pub manifest_sha256: String,
	pub engine_version: String,
	pub release_archive_sha256: String,
	pub runtime_files: BTreeMap<String, String>,
}

fn default_artifact_bytes() -> u64 {
	64 * 1024 * 1024
}

fn default_output_bytes() -> usize {
	32 * 1024
}

fn default_timeout() -> u64 {
	30
}

fn default_memory() -> u64 {
	512 * 1024 * 1024
}

}

pub mod hia_provider { use serde::{Deserialize,Serialize};

#[derive(Clone, Debug, Deserialize, Serialize, PartialEq, Eq)]
#[serde(deny_unknown_fields)]
pub struct HiaWorkerProfile {
	pub host: String,
	pub python_executable: String,
	/// Trusted installed Hepta source root. No caller-controlled PYTHONPATH is accepted.
	pub working_directory: String,
	/// Private store shared by this configured operator authority across sessions.
	pub state_root: String,
	#[serde(default)]
	pub artifact_roots: Vec<String>,
	/// Exact sorted source inventory returned by the installed worker's manifest command.
	pub worker_sha256: String,
	pub backend_sha256: String,
	pub catalog_sha256: String,
	/// Optional administrator-selected manifest for pinned native helper images.
	/// Omitted legacy fields must not change durable profile/request identities.
	#[serde(default, skip_serializing_if = "Option::is_none")]
	pub native_helpers_manifest: Option<String>,
	#[serde(default, skip_serializing_if = "Option::is_none")]
	pub native_helpers_sha256: Option<String>,
	#[serde(default = "default_timeout")]
	pub timeout_seconds: u64,
	#[serde(default = "default_memory")]
	pub memory_max_bytes: u64,
}

fn default_timeout() -> u64 {
	120
}

fn default_memory() -> u64 {
	1024 * 1024 * 1024
}

}

}

use std::collections::BTreeMap; use std::path::PathBuf;

#[derive(Debug, Clone, Copy, Default, Deserialize, Serialize, PartialEq, Eq)]
#[serde(rename_all = "snake_case")]
pub enum Platform {
	#[default]
	Linux,
	Macos,
}

#[derive(Debug, Clone, Copy, Default, Deserialize, Serialize, PartialEq, Eq)]
#[serde(rename_all = "snake_case")]
pub enum ExecutionMode {
	#[default]
	Isolated,
	/// Full authority of the configured SSH login, including its existing sudo rights.
	Operator,
}

#[derive(Debug, Clone, Deserialize, Serialize)]
pub struct PrivilegedAction {
	pub executable: String,
	#[serde(default)]
	pub fixed_args: Vec<String>,
	#[serde(default)]
	pub allow_extra_args: bool,
	/// One full-match regex per accepted extra argument. Empty means none.
	#[serde(default)]
	pub extra_arg_patterns: Vec<String>,
	#[serde(default = "default_action_timeout")]
	pub timeout_seconds: u64,
}

#[derive(Debug, Clone, Deserialize, Serialize)]
pub struct HostConfig {
	/// Optional administrator-pinned CRIU executable. Disabled when absent.
	#[serde(default)]
	pub checkpoint_binary: Option<String>,
	/// Exact SHA256 for the configured CRIU artifact, never supplied by tool callers.
	#[serde(default)]
	pub checkpoint_binary_sha256: Option<String>,
	#[serde(default)]
	pub execution_mode: ExecutionMode,
	/// OpenSSH config alias or user@host target. Never supplied by a tool call.
	pub ssh_target: String,
	#[serde(default)]
	pub platform: Platform,
	/// Absolute per-host directory holding durable job state and logs.
	pub remote_state_dir: String,
	#[serde(default)]
	pub allow_execute: bool,
	#[serde(default)]
	pub allow_pty: bool,
	#[serde(default)]
	pub allow_write: bool,
	/// Allow AF_INET/AF_INET6 from durable jobs. Default false creates a fail-closed
	/// private network namespace restricted to AF_UNIX.
	#[serde(default)]
	pub allow_job_network: bool,
	/// Allow a detached supervisor when user-systemd cannot create the unit.
	/// Keep false on production Linux hosts; macOS requires true in v0.1.
	#[serde(default)]
	pub allow_detached_fallback: bool,
	/// Optional absolute cwd allowlist. Empty means any cwd reachable by the SSH identity.
	#[serde(default)]
	pub allowed_cwd_prefixes: Vec<String>,
	/// Absolute remote read roots for inherited SFTP tools. Empty denies reads.
	#[serde(default)]
	pub allowed_read_path_prefixes: Vec<String>,
	/// Absolute remote write roots. Empty denies writes even when allow_write is true.
	#[serde(default)]
	pub allowed_write_path_prefixes: Vec<String>,
	#[serde(default)]
	pub protected_path_prefixes: Vec<String>,
	#[serde(default)]
	pub protected_argument_substrings: Vec<String>,
	#[serde(default)]
	pub denied_executables: Vec<String>,
	#[serde(default)]
	pub allowed_dangerous_executables: Vec<String>,
	#[serde(default)]
	pub privileged_actions: BTreeMap<String, PrivilegedAction>,
}

#[derive(Debug, Clone, Deserialize, Serialize)]
pub struct RuntimeConfig {
	#[serde(default = "default_state_dir")]
	pub state_dir: PathBuf,
	/// Absolute roots exposed through the inherited Octofs local file tools.
	/// Empty denies local file access while runtime mode is enabled.
	#[serde(default)]
	pub controller_workspace_roots: Vec<PathBuf>,
	#[serde(default)]
	pub hosts: BTreeMap<String, HostConfig>,
	/// Named administrator-owned model workers; absent disables all weight tools.
	#[serde(default, skip_serializing_if = "BTreeMap::is_empty")]
	pub weight_workers: BTreeMap<String, crate::mcp::weight_config::WeightWorkerProfile>,
	/// Fixed read-only static analyzers, pinned by executable, version and SHA-256.
	#[serde(default, skip_serializing_if = "BTreeMap::is_empty")]
	pub rea_static_profiles: BTreeMap<String, crate::mcp::rea_provider::ReaStaticProfile>,
	/// Pinned HIA installation and private operator artifact namespace; absent disables HIA.
	#[serde(default, skip_serializing_if = "Option::is_none")]
	pub hia_worker: Option<crate::mcp::hia_provider::HiaWorkerProfile>,
}

fn default_action_timeout() -> u64 {
	30
}

fn default_state_dir() -> PathBuf {
	if let Some(path) = std::env::var_os("HEPTA_RUNTIME_STATE_DIR") {
		return PathBuf::from(path);
	}
	if let Some(path) = std::env::var_os("XDG_STATE_HOME") {
		return PathBuf::from(path).join("hepta-runtime");
	}
	std::env::var_os("HOME")
		.map(PathBuf::from)
		.unwrap_or_else(std::env::temp_dir)
		.join(".local/state/hepta-runtime")
}


fn hex(bytes:&[u8])->String { bytes.iter().map(|b|format!("{b:02x}")).collect() }
fn unhex(s:&str)->Vec<u8> { (0..s.len()).step_by(2).map(|i|u8::from_str_radix(&s[i..i+2],16).unwrap()).collect() }
fn typed<T:serde::de::DeserializeOwned+Serialize>(raw:&[u8])->String {
    match serde_json::from_slice::<T>(raw) {
        Err(e)=>format!("ffffffff:{}",hex(e.to_string().as_bytes())),
        Ok(value)=>match serde_json::to_vec(&value) {
            Ok(out)=>format!("{:08x}:{}",out.len(),hex(&out)),
            Err(e)=>format!("fffffffd:{}",hex(e.to_string().as_bytes()))
        }
    }
}
fn main() {
    use std::os::unix::ffi::OsStringExt;
    for line in io::stdin().lock().lines() {
        let wire=unhex(&line.unwrap());
        let word=|at:usize|u64::from_le_bytes(wire[at..at+8].try_into().unwrap());
        let kind=word(16); let defaults=word(24) as usize; let size=word(32) as usize;
        assert_eq!(&wire[..8],b"HRCFGJ01"); assert_eq!(word(8),1);
        assert_eq!(wire.len(),40+defaults+size);
        std::env::set_var("HEPTA_RUNTIME_STATE_DIR", std::ffi::OsString::from_vec(wire[40..40+defaults].to_vec()));
        let raw=&wire[40+defaults..];
        let result=match kind {


            100=>typed::<RuntimeConfig>(raw),

            101=>typed::<HostConfig>(raw),

            102=>typed::<PrivilegedAction>(raw),

            103=>typed::<mcp::weight_config::WeightWorkerProfile>(raw),

            104=>typed::<mcp::weight_config::WeightNativeClientProfile>(raw),

            105=>typed::<mcp::rea_provider::ReaStaticProfile>(raw),

            106=>typed::<mcp::rea_provider::JavaEngineProfile>(raw),

            107=>typed::<mcp::rea_provider::GhidraEngineProfile>(raw),

            108=>typed::<mcp::hia_provider::HiaWorkerProfile>(raw),

            10=>typed::<Platform>(raw),

            11=>typed::<ExecutionMode>(raw),

            12=>typed::<mcp::rea_provider::StaticProvider>(raw),

            13=>typed::<mcp::rea_provider::StaticOperation>(raw),

            1=>typed::<String>(raw),

            2=>typed::<bool>(raw),

            3=>typed::<u64>(raw),

            4=>typed::<u8>(raw),

            5=>typed::<u32>(raw),

            6=>typed::<PathBuf>(raw),

            _=>panic!("unknown fixture schema")
        };
        println!("{result}");
    }
}
