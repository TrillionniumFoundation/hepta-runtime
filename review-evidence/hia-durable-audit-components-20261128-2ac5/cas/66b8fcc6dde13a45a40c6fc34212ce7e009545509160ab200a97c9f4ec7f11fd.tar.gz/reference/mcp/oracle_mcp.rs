// Copyright 2026 Muvon Un Limited
// Copyright 2026 TrillionniumFoundation
// SPDX-License-Identifier: Apache-2.0
// Test-only assembly of the unchanged original config/summary functions with
// the actual locked SDK Parameters extractor, ToolRouter and stdio transport.
pub mod mcp;
pub mod utils;
use std::{path::PathBuf,sync::Arc};
use rmcp::{RoleServer,ServiceExt,handler::server::{ServerHandler,wrapper::Parameters,
    tool::{ToolCallContext,ToolRoute,ToolRouter}},model::{CallToolRequestParams,
    CallToolResponse,ServerCapabilities,ServerInfo,Tool},service::RequestContext};

#[derive(Clone)]
struct Reference;

fn host_list(Parameters(_):Parameters<mcp::runtime::inspect::HostListParams>)->Result<String,String>{
    mcp::runtime::inspect::host_list().map_err(|e|e.to_string())
}
fn effective_config(Parameters(p):Parameters<mcp::runtime::effective_config::EffectiveConfigParams>)->Result<String,String>{
    mcp::runtime::effective_config::effective_config(p).map_err(|e|e.to_string())
}

fn execution_shadow_admit(Parameters(p):Parameters<mcp::runtime::execution::ShadowExecutionIntentParams>)->Result<String,String>{
    mcp::runtime::execution::admit_shadow_intent(p).map_err(|e|e.to_string())
}

impl ServerHandler for Reference {
    fn get_info(&self)->ServerInfo {
        let mut info = ServerInfo::default();
        info.capabilities = ServerCapabilities::builder().enable_tools().build();
        info
    }
    async fn call_tool(&self,request:CallToolRequestParams,context:RequestContext<RoleServer>)->Result<CallToolResponse,rmcp::ErrorData>{
        let router=ToolRouter::new()
            .with_route(ToolRoute::new(Tool::new("execution_shadow_admit","Execution Shadow Admission",Arc::new(Default::default())),execution_shadow_admit))
            .with_route(ToolRoute::new(Tool::new("host_list","Host List",Arc::new(Default::default())),host_list))
            .with_route(ToolRoute::new(Tool::new("effective_config","Effective Config",Arc::new(Default::default())),effective_config));
        router.call(ToolCallContext::new(self,request,context)).await
    }
}

fn main(){
    let args:Vec<_>=std::env::args_os().collect();
    if args.len()==2 && args[1]=="--schema" {
        println!("{}",serde_json::to_string(&rmcp::schemars::schema_for!(mcp::runtime::execution::ShadowExecutionIntentParams)).unwrap());return;
    }
    assert_eq!(args.len(),3);assert_eq!(args[1],"--runtime-config");
    let installed=mcp::runtime::config::RuntimeConfig::load(&PathBuf::from(&args[2])).and_then(mcp::runtime::config::init_runtime);
    if let Err(error)=installed{eprintln!("{error}");std::process::exit(78);}
    tokio::runtime::Builder::new_current_thread().enable_all().build().unwrap().block_on(async {
        Reference.serve((tokio::io::stdin(),tokio::io::stdout())).await.unwrap().waiting().await.unwrap();
    });
}
