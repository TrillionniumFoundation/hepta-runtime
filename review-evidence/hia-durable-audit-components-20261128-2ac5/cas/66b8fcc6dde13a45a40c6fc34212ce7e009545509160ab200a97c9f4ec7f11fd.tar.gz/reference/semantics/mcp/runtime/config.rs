use serde::{Deserialize,Serialize};
use anyhow::{anyhow,bail,Context,Result};
use regex::Regex;
use std::path::{Path,Component};
use std::sync::OnceLock;
use std::io::{self,BufRead};
use crate::mcp;
use std::collections::BTreeMap; use std::path::PathBuf;

#[derive(Debug, Clone, Copy, Default, Deserialize, Serialize, PartialEq, Eq)]
#[serde(rename_all = "snake_case")]
pub enum Platform {
	#[default]
	Linux,
	Macos,
}

#[derive(Debug, Clone, Copy, Default, Deserialize, Serialize, PartialEq, Eq)]
#[serde(rename_all = "snake_case")]
pub enum ExecutionMode {
	#[default]
	Isolated,
	/// Full authority of the configured SSH login, including its existing sudo rights.
	Operator,
}

#[derive(Debug, Clone, Deserialize, Serialize)]
pub struct PrivilegedAction {
	pub executable: String,
	#[serde(default)]
	pub fixed_args: Vec<String>,
	#[serde(default)]
	pub allow_extra_args: bool,
	/// One full-match regex per accepted extra argument. Empty means none.
	#[serde(default)]
	pub extra_arg_patterns: Vec<String>,
	#[serde(default = "default_action_timeout")]
	pub timeout_seconds: u64,
}

#[derive(Debug, Clone, Deserialize, Serialize)]
pub struct HostConfig {
	/// Optional administrator-pinned CRIU executable. Disabled when absent.
	#[serde(default)]
	pub checkpoint_binary: Option<String>,
	/// Exact SHA256 for the configured CRIU artifact, never supplied by tool callers.
	#[serde(default)]
	pub checkpoint_binary_sha256: Option<String>,
	#[serde(default)]
	pub execution_mode: ExecutionMode,
	/// OpenSSH config alias or user@host target. Never supplied by a tool call.
	pub ssh_target: String,
	#[serde(default)]
	pub platform: Platform,
	/// Absolute per-host directory holding durable job state and logs.
	pub remote_state_dir: String,
	#[serde(default)]
	pub allow_execute: bool,
	#[serde(default)]
	pub allow_pty: bool,
	#[serde(default)]
	pub allow_write: bool,
	/// Allow AF_INET/AF_INET6 from durable jobs. Default false creates a fail-closed
	/// private network namespace restricted to AF_UNIX.
	#[serde(default)]
	pub allow_job_network: bool,
	/// Allow a detached supervisor when user-systemd cannot create the unit.
	/// Keep false on production Linux hosts; macOS requires true in v0.1.
	#[serde(default)]
	pub allow_detached_fallback: bool,
	/// Optional absolute cwd allowlist. Empty means any cwd reachable by the SSH identity.
	#[serde(default)]
	pub allowed_cwd_prefixes: Vec<String>,
	/// Absolute remote read roots for inherited SFTP tools. Empty denies reads.
	#[serde(default)]
	pub allowed_read_path_prefixes: Vec<String>,
	/// Absolute remote write roots. Empty denies writes even when allow_write is true.
	#[serde(default)]
	pub allowed_write_path_prefixes: Vec<String>,
	#[serde(default)]
	pub protected_path_prefixes: Vec<String>,
	#[serde(default)]
	pub protected_argument_substrings: Vec<String>,
	#[serde(default)]
	pub denied_executables: Vec<String>,
	#[serde(default)]
	pub allowed_dangerous_executables: Vec<String>,
	#[serde(default)]
	pub privileged_actions: BTreeMap<String, PrivilegedAction>,
}

#[derive(Debug, Clone, Deserialize, Serialize)]
pub struct RuntimeConfig {
	#[serde(default = "default_state_dir")]
	pub state_dir: PathBuf,
	/// Absolute roots exposed through the inherited Octofs local file tools.
	/// Empty denies local file access while runtime mode is enabled.
	#[serde(default)]
	pub controller_workspace_roots: Vec<PathBuf>,
	#[serde(default)]
	pub hosts: BTreeMap<String, HostConfig>,
	/// Named administrator-owned model workers; absent disables all weight tools.
	#[serde(default, skip_serializing_if = "BTreeMap::is_empty")]
	pub weight_workers: BTreeMap<String, crate::mcp::weight_config::WeightWorkerProfile>,
	/// Fixed read-only static analyzers, pinned by executable, version and SHA-256.
	#[serde(default, skip_serializing_if = "BTreeMap::is_empty")]
	pub rea_static_profiles: BTreeMap<String, crate::mcp::rea_provider::ReaStaticProfile>,
	/// Pinned HIA installation and private operator artifact namespace; absent disables HIA.
	#[serde(default, skip_serializing_if = "Option::is_none")]
	pub hia_worker: Option<crate::mcp::hia_provider::HiaWorkerProfile>,
}

fn default_action_timeout() -> u64 {
	30
}

fn default_state_dir() -> PathBuf {
	if let Some(path) = std::env::var_os("HEPTA_RUNTIME_STATE_DIR") {
		return PathBuf::from(path);
	}
	if let Some(path) = std::env::var_os("XDG_STATE_HOME") {
		return PathBuf::from(path).join("hepta-runtime");
	}
	std::env::var_os("HOME")
		.map(PathBuf::from)
		.unwrap_or_else(std::env::temp_dir)
		.join(".local/state/hepta-runtime")
}


struct InstalledRuntimeConfig {
	config: RuntimeConfig,
	#[cfg(any(target_os = "linux", test))]
	policy_digest: OnceLock<std::result::Result<[u8; 32], serde_json::Error>>,
}

impl InstalledRuntimeConfig {
	fn new(config: RuntimeConfig) -> Self {
		Self {
			config,
			#[cfg(any(target_os = "linux", test))]
			policy_digest: OnceLock::new(),
		}
	}

	#[cfg(any(target_os = "linux", test))]
	fn policy_digest(&self) -> Result<[u8; 32]> {
		self.policy_digest
			.get_or_init(|| {
				let bytes = serde_json::to_vec(&self.config)?;
				let mut digest = [0; 32];
				digest
					.copy_from_slice(ring::digest::digest(&ring::digest::SHA256, &bytes).as_ref());
				Ok(digest)
			})
			.as_ref()
			.copied()
			.map_err(|error| anyhow!("{error}"))
	}
}

impl RuntimeConfig {
	pub fn validate(&self) -> Result<()> {
		if !self.state_dir.is_absolute() {
			bail!("controller state directory must be absolute");
		}
		if self.hosts.is_empty() {
			bail!("runtime config must declare at least one host");
		}
		for root in &self.controller_workspace_roots {
			if !root.is_absolute() {
				bail!(
					"controller workspace root `{}` must be absolute",
					root.display()
				);
			}
		}
		for (name, host) in &self.hosts {
			match (&host.checkpoint_binary, &host.checkpoint_binary_sha256) {
				(None, None) => {}
				(Some(binary), Some(sha)) => {
					if host.execution_mode != ExecutionMode::Operator
						|| host.platform != Platform::Linux
						|| !host.allow_execute
					{
						bail!("checkpoint pin requires an executable Linux operator host `{name}`");
					}
					if !Path::new(binary).is_absolute()
						|| binary.contains(['\0', '\n', '\r'])
						|| Path::new(binary)
							.components()
							.any(|c| matches!(c, Component::ParentDir))
						|| sha.len() != 64 || !sha
						.bytes()
						.all(|b| b.is_ascii_digit() || (b'a'..=b'f').contains(&b))
					{
						bail!("invalid checkpoint executable or SHA256 on `{name}`");
					}
				}
				_ => bail!("checkpoint executable and SHA256 must be paired on `{name}`"),
			}
			if host.execution_mode == ExecutionMode::Operator {
				if !host.protected_path_prefixes.is_empty()
					|| !host.protected_argument_substrings.is_empty()
					|| !host.denied_executables.is_empty()
					|| !host.allowed_cwd_prefixes.is_empty()
					|| !host.allowed_dangerous_executables.is_empty()
				{
					bail!("operator host `{name}` cannot claim command/path sandboxing; use isolated mode or OS permissions");
				}
				if (host.allow_execute || host.allow_pty) && !host.allow_job_network {
					bail!("operator host `{name}` requires explicit allow_job_network=true");
				}
			}
			if !valid_name(name) {
				bail!("invalid host name `{name}`; use letters, digits, dot, underscore or dash");
			}
			if host.ssh_target.trim().is_empty()
				|| host.ssh_target.starts_with('-')
				|| host.ssh_target.contains(['\0', '\n', '\r'])
			{
				bail!("host `{name}` has an invalid ssh_target");
			}
			if host.allow_execute || host.allow_pty {
				let state = Path::new(&host.remote_state_dir);
				if !state.is_absolute() {
					bail!("host `{name}` remote_state_dir must be absolute");
				}
			}
			if host.platform == Platform::Macos && host.allow_execute {
				if !host.allow_detached_fallback {
					bail!("macOS host `{name}` requires allow_detached_fallback for durable jobs");
				}
				if !host.allow_job_network {
					bail!("macOS host `{name}` cannot enforce the Linux private-network sandbox; allow_job_network must be true");
				}
			}
			for prefix in host
				.allowed_cwd_prefixes
				.iter()
				.chain(host.allowed_read_path_prefixes.iter())
				.chain(host.allowed_write_path_prefixes.iter())
				.chain(host.protected_path_prefixes.iter())
			{
				if !Path::new(prefix).is_absolute() {
					bail!("host `{name}` path policy prefix `{prefix}` must be absolute");
				}
			}
			for (action_name, action) in &host.privileged_actions {
				if !valid_name(action_name) || !Path::new(&action.executable).is_absolute() {
					bail!("host `{name}` has invalid privileged action `{action_name}`");
				}
				if action.timeout_seconds == 0 || action.timeout_seconds > 300 {
					bail!("host `{name}` privileged action `{action_name}` timeout must be 1..300 seconds");
				}
				if action.allow_extra_args == action.extra_arg_patterns.is_empty() {
					bail!("host `{name}` privileged action `{action_name}` must pair allow_extra_args with explicit extra_arg_patterns");
				}
				if action.extra_arg_patterns.len() > 32 {
					bail!("host `{name}` privileged action `{action_name}` has too many argument patterns");
				}
				for pattern in &action.extra_arg_patterns {
					Regex::new(&format!(r"\A(?:{pattern})\z")).with_context(|| {
						format!("host `{name}` privileged action `{action_name}` has invalid argument regex")
					})?;
				}
			}
		}
		crate::mcp::weight_config::validate_profiles(self)?;
		crate::mcp::rea_provider::validate_profiles(self)?;
		crate::mcp::hia_provider::validate_profile(self)?;
		Ok(())
	}
	pub fn host(&self, name: &str) -> Result<&HostConfig> {
		self.hosts
			.get(name)
			.ok_or_else(|| anyhow!("unknown host `{name}`; call host_list for configured names"))
	}
}
pub fn valid_name(value: &str) -> bool {
	!value.is_empty()
		&& value.len() <= 128
		&& value
			.bytes()
			.all(|b| b.is_ascii_alphanumeric() || matches!(b, b'.' | b'_' | b'-' | b'@'))
}

fn hex(bytes:&[u8])->String { bytes.iter().map(|b|format!("{b:02x}")).collect() }
fn unhex(s:&str)->Vec<u8> { (0..s.len()).step_by(2).map(|i|u8::from_str_radix(&s[i..i+2],16).unwrap()).collect() }
pub fn run_probe(){
 use std::os::unix::ffi::OsStringExt;
 eprintln!("MCP_EMPTY_WIRE:{}",hex(&serde_json::to_vec(&rmcp::model::CallToolResult::success(vec![rmcp::model::ContentBlock::text(String::new())])).unwrap()));
 for line in io::stdin().lock().lines(){
  let wire=unhex(&line.unwrap());let word=|at:usize|u64::from_le_bytes(wire[at..at+8].try_into().unwrap());
  assert_eq!(&wire[..8],b"HRCFGJ01");let op=word(8);assert_eq!(word(16),100);
  let defaults=word(24) as usize;let size=word(32) as usize;assert_eq!(wire.len(),40+defaults+size);
  std::env::set_var("HEPTA_RUNTIME_STATE_DIR",std::ffi::OsString::from_vec(wire[40..40+defaults].to_vec()));
  let config:RuntimeConfig=match serde_json::from_slice(&wire[40+defaults..]){Ok(v)=>v,Err(e)=>{println!("ffffffff:{}",hex(e.to_string().as_bytes()));continue}};
  let result:Result<Vec<u8>>=match op {
   1=>config.validate().map(|_|Vec::new()),
   2=>mcp::runtime::inspect::probe(&config).map(String::into_bytes),
   3=>mcp::runtime::effective_config::probe(&config).map(String::into_bytes),
   4=>InstalledRuntimeConfig::new(config).policy_digest().map(|b|b.to_vec()),
   _=>panic!("unknown original operation")
  };
  match result {Ok(out)=>println!("00000000:{}",hex(&out)),Err(e)=>println!("00000001:{}",hex(e.to_string().as_bytes()))}
 }
}
