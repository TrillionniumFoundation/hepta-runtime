use anyhow::{anyhow,bail,Result};
use serde::{Deserialize,Serialize};
use serde_json::{json,Value};
use rmcp::schemars;
use std::{path::Path,time::{Instant,Duration},collections::HashSet,cell::RefCell,io::{Read,Write}};
const MAX_GLOBAL:usize=512;
const MAX_OWNER:usize=128;
const MAX_PAGE_BYTES:usize=64*1024;
#[derive(Clone, Copy, Deserialize, Serialize, PartialEq, Eq)]
#[serde(rename_all = "snake_case")]
enum DurableState {
	Unknown,
	Completed,
	Failed,
}

mod record_schema {
	use super::DurableState;
	use serde::{Deserialize, Serialize};

	// Serde derives its default Visitor diagnostic from the Rust identifier,
	// not serde(rename). Keep the original name for both string specializations.
	#[derive(Clone, Deserialize, Serialize, PartialEq, Eq)]
	#[serde(deny_unknown_fields)]
	pub(super) struct Record<S> {
		pub(super) request_id: S,
		pub(super) owner: S,
		pub(super) tool_name: S,
		pub(super) state: DurableState,
		pub(super) accepted_unix_ms: u128,
		pub(super) elapsed_ms: Option<u64>,
	}
}
// Owned publications, projections and legacy rows keep their original type.
// Complete original verification borrows only the three string fields from its
// current bounded input; both forms share this exact serde field contract.
type RecordFields<S> = record_schema::Record<S>;
type Record = record_schema::Record<String>;

#[derive(Debug, Clone, Deserialize, schemars::JsonSchema)]
#[serde(deny_unknown_fields)]
pub struct RequestHistoryParams {
	/// Last returned request id. Expired and other-owner cursors are refused.
	#[serde(default)]
	pub after_id: Option<String>,
	/// At most 32 metadata records; default 32. No parameters or output are returned.
	#[serde(default)]
	pub limit: Option<u16>,
}

fn valid_id(value: &str) -> bool {
	value.len() == 64
		&& value
			.bytes()
			.all(|byte| byte.is_ascii_digit() || (b'a'..=b'f').contains(&byte))
}
thread_local! {static ROWS:RefCell<Vec<Record>>=const{RefCell::new(Vec::new())};static ACTIVE:RefCell<HashSet<String>>=RefCell::new(HashSet::new());}
fn store_lock()->Result<()>{Ok(())}
fn open_store(_root:&Path)->Result<()>{Ok(())}
fn entries(_directory:&())->Result<Vec<Record>>{
 let mut result=ROWS.with(|r|r.borrow().clone());
	result.sort_by(|left, right| {
		(left.accepted_unix_ms, &left.request_id).cmp(&(right.accepted_unix_ms, &right.request_id))
	});
 Ok(result)
}
fn is_dispatch_active(id:&str)->Result<bool>{Ok(ACTIVE.with(|r|r.borrow().contains(id)))}
#[derive(Debug)]struct MetadataQueryDeadline;
impl std::fmt::Display for MetadataQueryDeadline {fn fmt(&self,f:&mut std::fmt::Formatter<'_>)->std::fmt::Result{write!(f,"archive metadata query total deadline exceeded")}}
impl std::error::Error for MetadataQueryDeadline{}
fn wire_size(value: &Value) -> Result<usize> {
	let text = serde_json::to_string(value)?;
	let result = rmcp::model::CallToolResult::success(vec![rmcp::model::ContentBlock::text(text)]);
	Ok(serde_json::to_vec(&result)?.len())
}
fn history_at(root: &Path, owner: &str, params: RequestHistoryParams) -> Result<String> {
	if !valid_id(owner) {
		bail!("request history unavailable to this session");
	}
	let limit = params.limit.unwrap_or(32) as usize;
	if !(1..=32).contains(&limit) || params.after_id.as_deref().is_some_and(|id| !valid_id(id)) {
		bail!("invalid request history page");
	}
	let _guard = store_lock()?;
	let directory = open_store(root)?;
	let retained = entries(&directory)?;
	let records: Vec<_> = retained
		.iter()
		.filter(|record| record.owner == owner)
		.collect();
	let start = match params.after_id {
		Some(id) => {
			records
				.iter()
				.position(|record| record.request_id == id)
				.ok_or_else(|| {
					anyhow!("request history cursor expired or unavailable to this session")
				})? + 1
		}
		None => 0,
	};
	let mut page = Vec::new();
	for record in records.iter().skip(start).take(limit) {
		let state =
			if record.state == DurableState::Unknown && is_dispatch_active(&record.request_id)? {
				"accepted"
			} else {
				match record.state {
					DurableState::Unknown => "unknown",
					DurableState::Completed => "completed",
					DurableState::Failed => "failed",
				}
			};
		page.push(json!({"request_id":record.request_id,"tool_name":record.tool_name,"state":state,"accepted_unix_ms":record.accepted_unix_ms,"elapsed_ms":record.elapsed_ms}));
	}
	let next = if start + page.len() < records.len() {
		page.last().map(|row| row["request_id"].clone())
	} else {
		None
	};
	let output = json!({"requests":page,"next_after_id":next,"retention":{"global":MAX_GLOBAL,"per_session":MAX_OWNER},
		"status_semantics":"native_request_dispatch_observation_not_side_effect_delivery_or_business_success",
		"session_scope":"native_mcp_session_only","cross_session_resume":false,"history_is_live":true,
		"automatic_operation_retry":false});
	if wire_size(&output)? > MAX_PAGE_BYTES {
		bail!("request history wire page limit exceeded");
	}
	Ok(serde_json::to_string(&output)?)
}
fn archive_page_output(
	mut records: Vec<Record>,
	total: u64,
	limit: usize,
	deadline: Instant,
) -> Result<String> {
	let more = records.len() > limit;
	records.truncate(limit);
	let mut page = Vec::new();
	for record in &records {
		if Instant::now() >= deadline {
			return Err(MetadataQueryDeadline.into());
		}
		let state = match record.state {
			DurableState::Unknown if is_dispatch_active(&record.request_id)? => "accepted",
			DurableState::Unknown => "unknown",
			DurableState::Completed => "completed",
			DurableState::Failed => "failed",
		};
		page.push(
			json!({"request_id":record.request_id,"tool_name":record.tool_name,
			"state":state,"accepted_unix_ms":record.accepted_unix_ms,"elapsed_ms":record.elapsed_ms}),
		);
	}
	let next = if more {
		page.last().map(|row| row["request_id"].clone())
	} else {
		None
	};
	let output = json!({"requests":page,"next_after_id":next,"total":total,
		"archive_retention":"no_automatic_metadata_eviction","history_is_live":true,
		"coverage":"metadata_retained_at_archive_introduction_and_subsequent_admitted_requests",
		"contains_parameters_or_output":false,"automatic_operation_retry":false});
	if wire_size(&output)? > MAX_PAGE_BYTES {
		bail!("request archive wire page limit exceeded");
	}
	let serialized = serde_json::to_string(&output)?;
	if Instant::now() >= deadline {
		return Err(MetadataQueryDeadline.into());
	}
	Ok(serialized)
}
fn word(raw:&[u8],at:usize)->u64{u64::from_le_bytes(raw[at..at+8].try_into().unwrap())}
fn string(raw:&[u8],at:usize,len:usize)->String{std::str::from_utf8(&raw[at..at+len]).unwrap().to_owned()}
fn response(diag:u64,value:&[u8])->Vec<u8>{
 let mut out=vec![0;32+value.len()];out[..8].copy_from_slice(b"HRAQR001");out[8..16].copy_from_slice(&diag.to_le_bytes());
 if diag==0 {out[16..24].copy_from_slice(&(value.len()as u64).to_le_bytes());let n=out.len()as u64;out[24..32].copy_from_slice(&n.to_le_bytes());out[32..].copy_from_slice(value)}
 out
}
fn run(frame:&[u8])->Vec<u8>{
 assert!(frame.len()>=192&&&frame[..8]==b"HRAQP001");
 let op=word(frame,8);let n=word(frame,16)as usize;let limit=word(frame,24);let after=word(frame,32);
 assert!(op==1||op==2);assert_eq!(frame.len(),192+256*n);
 let owner=string(frame,64,64);let cursor=if after==1{Some(string(frame,128,64))}else{None};
 let mut records=Vec::new();let mut active=HashSet::new();
 for i in 0..n {let at=192+i*256;let id=string(frame,at,64);
 if word(frame,at+240)==1{active.insert(id.clone());}
 records.push(Record{request_id:id,owner:string(frame,at+64,64),tool_name:string(frame,at+128,word(frame,at+192)as usize),state:match word(frame,at+200){0=>DurableState::Unknown,1=>DurableState::Completed,2=>DurableState::Failed,_=>panic!("private state")},accepted_unix_ms:word(frame,at+208)as u128|((word(frame,at+216)as u128)<<64),elapsed_ms:if word(frame,at+224)==1{Some(word(frame,at+232))}else{None}});
 }
 ROWS.with(|r|*r.borrow_mut()=records.clone());ACTIVE.with(|r|*r.borrow_mut()=active);
 let value=std::panic::catch_unwind(||{
  if op==1{history_at(Path::new("private-fixture-not-opened"),&owner,RequestHistoryParams{after_id:cursor,limit:Some(limit.try_into().unwrap())})}
  else{let deadline=if word(frame,48)>=word(frame,56){Instant::now()-Duration::from_nanos(1)}else{Instant::now()+Duration::from_secs(3)};archive_page_output(records,word(frame,40),limit as usize,deadline)}
 });
 match value{
  Ok(Ok(text))=>response(0,text.as_bytes()),
  Ok(Err(e))=>response(if e.is::<MetadataQueryDeadline>(){4}else if e.to_string()=="request history cursor expired or unavailable to this session"{2}else{1},&[]),
  Err(_)=>response(3,&[])
 }
}
fn main()->std::io::Result<()>{
 let mut input=std::io::stdin().lock();let mut output=std::io::stdout().lock();
 loop{let mut prefix=[0;4];match input.read_exact(&mut prefix){Ok(())=>{},Err(e)if e.kind()==std::io::ErrorKind::UnexpectedEof=>break,Err(e)=>return Err(e)}
 let n=u32::from_le_bytes(prefix)as usize;assert!(n<=192+512*256);let mut raw=vec![0;n];input.read_exact(&mut raw)?;let result=run(&raw);
 output.write_all(&(result.len()as u32).to_le_bytes())?;output.write_all(&result)?;}output.flush()
}
