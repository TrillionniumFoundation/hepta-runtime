use anyhow::Result;
use serde_json::{json,Value};
fn render_host_list(config: &super::config::RuntimeConfig) -> Result<String> {
	let hosts: Vec<Value> = config
		.hosts
		.iter()
		.map(|(name, host)| {
			json!({
				"name": name,
				"platform": host.platform,
				"execution_mode": host.execution_mode,
				"operator_tools": host.execution_mode == super::config::ExecutionMode::Operator,
				"allow_execute": host.allow_execute,
				"allow_pty": host.allow_pty,
				"allow_write": host.allow_write,
				"privileged_actions": host.privileged_actions.keys().collect::<Vec<_>>(),
			})
		})
		.collect();
	Ok(serde_json::to_string_pretty(&json!({"hosts": hosts}))?)
}
pub fn probe(config:&super::config::RuntimeConfig)->Result<String>{render_host_list(config)}
