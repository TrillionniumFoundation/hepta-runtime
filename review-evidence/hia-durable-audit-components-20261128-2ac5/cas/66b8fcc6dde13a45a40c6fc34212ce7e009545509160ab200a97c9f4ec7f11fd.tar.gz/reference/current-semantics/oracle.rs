pub mod mcp;
pub mod utils;
fn main(){mcp::runtime::config::run_probe()}
