use std::collections::VecDeque;
use std::sync::{Arc,Mutex};
use std::time::{Instant,Duration};
#[derive(Clone, Copy, PartialEq, Eq)]
enum AuditStoreAccess {
	Exclusive,
	#[cfg(unix)]
	Shared,
}

#[derive(Default)]
struct AuditStoreQueue {
	next_ticket: u64,
	active: bool,
	readers: usize,
	reader_poisoned: bool,
	waiting: VecDeque<(u64, AuditStoreAccess)>,
}

#[derive(Default)]
struct AuditStoreLock {
	inner: Mutex<()>,
	queue: Mutex<AuditStoreQueue>,
	changed: std::sync::Condvar,
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
enum StoreLockFailure {
	Deadline,
	Unavailable,
}

#[must_use = "the store guard must cover the protected operation"]
struct AuditStoreGuard<'a> {
	lock: &'a AuditStoreLock,
	inner: Option<std::sync::MutexGuard<'a, ()>>,
}

#[cfg(unix)]
#[must_use = "finish the read guard while the final snapshot state remains locked"]
struct AuditSharedGuard<'a> {
	lock: &'a AuditStoreLock,
	deadline: Instant,
	active: bool,
	// A panic must publish poison on the same thread that owns this operation.
	_not_send: std::marker::PhantomData<std::sync::MutexGuard<'a, ()>>,
}

impl AuditStoreLock {
	fn cancel(&self, queue: &mut AuditStoreQueue, ticket: u64) {
		queue.waiting.retain(|queued| queued.0 != ticket);
		self.changed.notify_all();
	}

	fn release(&self) {
		// Cleanup releases custody during unwinding without clearing poison.
		let mut queue = self.queue.lock().unwrap_or_else(|error| error.into_inner());
		queue.active = false;
		self.changed.notify_all();
	}

	fn acquire(
		&self,
		deadline: Option<Instant>,
	) -> std::result::Result<AuditStoreGuard<'_>, StoreLockFailure> {
		if deadline.is_some_and(|limit| Instant::now() >= limit) {
			return Err(StoreLockFailure::Deadline);
		}
		let mut queue = self
			.queue
			.lock()
			.map_err(|_| StoreLockFailure::Unavailable)?;
		if deadline.is_some_and(|limit| Instant::now() >= limit) {
			return Err(StoreLockFailure::Deadline);
		}
		if queue.reader_poisoned {
			return Err(StoreLockFailure::Unavailable);
		}
		let ticket = queue.next_ticket;
		queue.next_ticket = ticket.checked_add(1).ok_or(StoreLockFailure::Unavailable)?;
		queue
			.waiting
			.push_back((ticket, AuditStoreAccess::Exclusive));
		loop {
			if deadline.is_some_and(|limit| Instant::now() >= limit) {
				self.cancel(&mut queue, ticket);
				return Err(StoreLockFailure::Deadline);
			}
			if queue.reader_poisoned {
				self.cancel(&mut queue, ticket);
				return Err(StoreLockFailure::Unavailable);
			}
			if !queue.active
				&& queue.readers == 0
				&& queue.waiting.front() == Some(&(ticket, AuditStoreAccess::Exclusive))
			{
				queue.waiting.pop_front();
				queue.active = true;
				break;
			}
			let waited = match deadline {
				Some(limit) => self
					.changed
					.wait_timeout(queue, limit.saturating_duration_since(Instant::now()))
					.map(|(queue, _)| queue)
					.map_err(|error| error.into_inner().0),
				None => self.changed.wait(queue).map_err(|error| error.into_inner()),
			};
			queue = match waited {
				Ok(queue) => queue,
				Err(mut queue) => {
					self.cancel(&mut queue, ticket);
					return Err(StoreLockFailure::Unavailable);
				}
			};
		}
		drop(queue);
		let mut guard = AuditStoreGuard {
			lock: self,
			inner: None,
		};
		if deadline.is_some_and(|limit| Instant::now() >= limit) {
			return Err(StoreLockFailure::Deadline);
		}
		// The former owner drops inner before releasing its FIFO reservation.
		// No second, unbounded wait is introduced after admission.
		match self.inner.try_lock() {
			Ok(inner) => guard.inner = Some(inner),
			Err(std::sync::TryLockError::Poisoned(error)) => {
				drop(error.into_inner());
				return Err(StoreLockFailure::Unavailable);
			}
			Err(std::sync::TryLockError::WouldBlock) => {
				return Err(StoreLockFailure::Unavailable);
			}
		}
		if deadline.is_some_and(|limit| Instant::now() >= limit) {
			return Err(StoreLockFailure::Deadline);
		}
		Ok(guard)
	}

	#[cfg(unix)]
	fn acquire_shared(
		&self,
		deadline: Instant,
	) -> std::result::Result<AuditSharedGuard<'_>, StoreLockFailure> {
		if Instant::now() >= deadline {
			return Err(StoreLockFailure::Deadline);
		}
		let mut queue = self
			.queue
			.lock()
			.map_err(|_| StoreLockFailure::Unavailable)?;
		if Instant::now() >= deadline {
			return Err(StoreLockFailure::Deadline);
		}
		if queue.reader_poisoned || self.inner.is_poisoned() {
			return Err(StoreLockFailure::Unavailable);
		}
		let ticket = queue.next_ticket;
		queue.next_ticket = ticket.checked_add(1).ok_or(StoreLockFailure::Unavailable)?;
		queue.waiting.push_back((ticket, AuditStoreAccess::Shared));
		loop {
			if Instant::now() >= deadline {
				self.cancel(&mut queue, ticket);
				return Err(StoreLockFailure::Deadline);
			}
			if queue.reader_poisoned || self.inner.is_poisoned() {
				self.cancel(&mut queue, ticket);
				return Err(StoreLockFailure::Unavailable);
			}
			if !queue.active && queue.waiting.front() == Some(&(ticket, AuditStoreAccess::Shared)) {
				queue.waiting.pop_front();
				queue.readers += 1;
				// Let the next adjacent reader observe its own admission condition.
				self.changed.notify_all();
				break;
			}
			queue = match self
				.changed
				.wait_timeout(queue, deadline.saturating_duration_since(Instant::now()))
			{
				Ok((queue, _)) => queue,
				Err(error) => {
					let (mut queue, _) = error.into_inner();
					self.cancel(&mut queue, ticket);
					return Err(StoreLockFailure::Unavailable);
				}
			};
		}
		drop(queue);
		let guard = AuditSharedGuard {
			lock: self,
			deadline,
			active: true,
			_not_send: std::marker::PhantomData,
		};
		if Instant::now() >= deadline {
			return Err(StoreLockFailure::Deadline);
		}
		Ok(guard)
	}
}

#[cfg(unix)]
impl AuditSharedGuard<'_> {
	fn finish(mut self) -> std::result::Result<(), StoreLockFailure> {
		let mut queue = match self.lock.queue.lock() {
			Ok(queue) => queue,
			Err(error) => {
				drop(error.into_inner());
				return Err(StoreLockFailure::Unavailable);
			}
		};
		// This critical section is the success boundary. A peer that already
		// finished is not retroactively revoked by later poison publication.
		let mut result = if queue.reader_poisoned || self.lock.inner.is_poisoned() {
			Err(StoreLockFailure::Unavailable)
		} else if Instant::now() >= self.deadline {
			Err(StoreLockFailure::Deadline)
		} else {
			Ok(())
		};
		match queue.readers.checked_sub(1) {
			Some(readers) => queue.readers = readers,
			None => {
				queue.reader_poisoned = true;
				result = Err(StoreLockFailure::Unavailable);
			}
		}
		self.active = false;
		self.lock.changed.notify_all();
		result
	}
}

#[cfg(unix)]
impl Drop for AuditSharedGuard<'_> {
	fn drop(&mut self) {
		if !self.active {
			return;
		}
		let mut queue = self
			.lock
			.queue
			.lock()
			.unwrap_or_else(|error| error.into_inner());
		if std::thread::panicking() {
			queue.reader_poisoned = true;
		}
		match queue.readers.checked_sub(1) {
			Some(readers) => queue.readers = readers,
			None => queue.reader_poisoned = true,
		}
		self.active = false;
		self.lock.changed.notify_all();
	}
}

impl Drop for AuditStoreGuard<'_> {
	fn drop(&mut self) {
		// Keep standard mutex poison and release inner before the FIFO turn.
		drop(self.inner.take());
		self.lock.release();
	}
}

fn wait_for_shared_gate_queue(lock: &AuditStoreLock, expected: usize) {
	let until = Instant::now() + std::time::Duration::from_secs(5);
	loop {
		if lock.queue.lock().unwrap().waiting.len() == expected {
			return;
		}
		assert!(Instant::now() < until, "store gate waiter did not arrive");
		std::thread::yield_now();
	}
}

fn assert_shared_gate_idle(lock: &AuditStoreLock) {
	let queue = lock.queue.lock().unwrap_or_else(|error| error.into_inner());
	assert!(!queue.active);
	assert_eq!(queue.readers, 0);
	assert!(queue.waiting.is_empty());
}

#[test]
fn shared_gate_allows_two_readers_without_bypassing_a_queued_writer() {
	use std::sync::mpsc;
	use std::time::Duration;
	let lock = Arc::new(AuditStoreLock::default());
	let first = lock
		.acquire_shared(Instant::now() + Duration::from_secs(5))
		.unwrap();
	let second = lock
		.acquire_shared(Instant::now() + Duration::from_secs(5))
		.unwrap();
	assert_eq!(lock.queue.lock().unwrap().readers, 2);
	let (events_tx, events_rx) = mpsc::channel();
	let (release_tx, release_rx) = mpsc::channel();
	let writer_lock = lock.clone();
	let writer_events = events_tx.clone();
	let writer = std::thread::spawn(move || {
		let guard = writer_lock
			.acquire(Some(Instant::now() + Duration::from_secs(5)))
			.unwrap();
		writer_events.send("writer").unwrap();
		release_rx.recv_timeout(Duration::from_secs(5)).unwrap();
		drop(guard);
	});
	wait_for_shared_gate_queue(&lock, 1);
	let later_lock = lock.clone();
	let later = std::thread::spawn(move || {
		let guard = later_lock
			.acquire_shared(Instant::now() + Duration::from_secs(5))
			.unwrap();
		events_tx.send("reader").unwrap();
		guard.finish().unwrap();
	});
	wait_for_shared_gate_queue(&lock, 2);
	first.finish().unwrap();
	assert_eq!(lock.queue.lock().unwrap().readers, 1);
	assert!(matches!(
		events_rx.try_recv(),
		Err(mpsc::TryRecvError::Empty)
	));
	second.finish().unwrap();
	assert_eq!(
		events_rx.recv_timeout(Duration::from_secs(5)).unwrap(),
		"writer"
	);
	wait_for_shared_gate_queue(&lock, 1);
	assert!(matches!(
		events_rx.try_recv(),
		Err(mpsc::TryRecvError::Empty)
	));
	release_tx.send(()).unwrap();
	assert_eq!(
		events_rx.recv_timeout(Duration::from_secs(5)).unwrap(),
		"reader"
	);
	writer.join().unwrap();
	later.join().unwrap();
	assert_shared_gate_idle(&lock);
}

#[test]
fn shared_readers_have_no_count_cap_and_cancelled_waiters_preserve_fifo() {
	use std::sync::mpsc;
	use std::time::Duration;
	// Independent readers all own the same snapshot concurrently. A writer still
	// waits for every original reader to release that protected snapshot.
	let lock = Arc::new(AuditStoreLock::default());
	let mut readers = (0..32)
		.map(|_| {
			lock.acquire_shared(Instant::now() + Duration::from_secs(5))
				.unwrap()
		})
		.collect::<Vec<_>>();
	assert_eq!(lock.queue.lock().unwrap().readers, 32);
	assert!(lock.queue.lock().unwrap().waiting.is_empty());
	let other = lock.clone();
	let (tx, rx) = mpsc::channel();
	let writer = std::thread::spawn(move || {
		let guard = other
			.acquire(Some(Instant::now() + Duration::from_secs(5)))
			.unwrap();
		tx.send(()).unwrap();
		drop(guard);
	});
	wait_for_shared_gate_queue(&lock, 1);
	while readers.len() > 1 {
		readers.pop().unwrap().finish().unwrap();
	}
	assert_eq!(lock.queue.lock().unwrap().readers, 1);
	assert!(matches!(rx.try_recv(), Err(mpsc::TryRecvError::Empty)));
	readers.pop().unwrap().finish().unwrap();
	rx.recv_timeout(Duration::from_secs(5)).unwrap();
	writer.join().unwrap();
	assert_shared_gate_idle(&lock);
	for cancelled_position in [0, 1] {
		let lock = Arc::new(AuditStoreLock::default());
		let held = lock.acquire(None).unwrap();
		let (order_tx, order_rx) = mpsc::channel();
		let (cancel_tx, cancel_rx) = mpsc::channel();
		let mut threads = Vec::new();
		for position in 0..3 {
			let other = lock.clone();
			let order = order_tx.clone();
			let cancelled = cancel_tx.clone();
			threads.push(std::thread::spawn(move || {
				if position == cancelled_position {
					let result = other.acquire_shared(Instant::now() + Duration::from_secs(2));
					cancelled
						.send(matches!(result, Err(StoreLockFailure::Deadline)))
						.unwrap();
				} else {
					let guard = other
						.acquire(Some(Instant::now() + Duration::from_secs(5)))
						.unwrap();
					order.send(position).unwrap();
					drop(guard);
				}
			}));
			wait_for_shared_gate_queue(&lock, position + 1);
		}
		assert!(cancel_rx.recv_timeout(Duration::from_secs(5)).unwrap());
		wait_for_shared_gate_queue(&lock, 2);
		drop(held);
		let order = [
			order_rx.recv_timeout(Duration::from_secs(5)).unwrap(),
			order_rx.recv_timeout(Duration::from_secs(5)).unwrap(),
		];
		let expected: Vec<_> = (0..3)
			.filter(|position| *position != cancelled_position)
			.collect();
		assert_eq!(order.as_slice(), expected.as_slice());
		for thread in threads {
			thread.join().unwrap();
		}
		assert_shared_gate_idle(&lock);
	}
}

#[test]
fn expired_shared_owner_keeps_custody_until_finish_then_releases_writer() {
	use std::sync::mpsc;
	use std::time::Duration;
	let lock = Arc::new(AuditStoreLock::default());
	let limit = Instant::now() + Duration::from_secs(2);
	let held = lock.acquire_shared(limit).unwrap();
	let other = lock.clone();
	let (tx, rx) = mpsc::channel();
	let writer = std::thread::spawn(move || {
		let guard = other
			.acquire(Some(Instant::now() + Duration::from_secs(5)))
			.unwrap();
		tx.send(()).unwrap();
		drop(guard);
	});
	wait_for_shared_gate_queue(&lock, 1);
	while Instant::now() < limit {
		std::thread::sleep(Duration::from_millis(1));
	}
	assert_eq!(lock.queue.lock().unwrap().readers, 1);
	assert!(matches!(rx.try_recv(), Err(mpsc::TryRecvError::Empty)));
	assert_eq!(held.finish(), Err(StoreLockFailure::Deadline));
	rx.recv_timeout(Duration::from_secs(5)).unwrap();
	writer.join().unwrap();
	assert_shared_gate_idle(&lock);
}

#[test]
fn shared_panic_refuses_active_peers_without_revoking_finished_reads() {
	use std::time::Duration;
	let lock = Arc::new(AuditStoreLock::default());
	let completed = lock
		.acquire_shared(Instant::now() + Duration::from_secs(5))
		.unwrap()
		.finish();
	let peer = lock
		.acquire_shared(Instant::now() + Duration::from_secs(5))
		.unwrap();
	let other = lock.clone();
	let panicked = std::thread::spawn(move || {
		std::panic::catch_unwind(std::panic::AssertUnwindSafe(|| {
			let _guard = other
				.acquire_shared(Instant::now() + Duration::from_secs(5))
				.unwrap();
			panic!("shared owner fault injection");
		}))
		.is_err()
	})
	.join()
	.unwrap();
	assert!(panicked);
	assert_eq!(completed, Ok(()));
	assert_eq!(peer.finish(), Err(StoreLockFailure::Unavailable));
	assert!(matches!(
		lock.acquire_shared(Instant::now() + Duration::from_secs(5)),
		Err(StoreLockFailure::Unavailable)
	));
	assert!(matches!(
		lock.acquire(None),
		Err(StoreLockFailure::Unavailable)
	));
	assert!(lock.queue.lock().unwrap().reader_poisoned);
	assert_shared_gate_idle(&lock);
}

#[test]
fn shared_admission_and_finish_preserve_writer_and_queue_poison() {
	use std::time::Duration;
	for poison_queue in [false, true] {
		let lock = Arc::new(AuditStoreLock::default());
		let peer = lock
			.acquire_shared(Instant::now() + Duration::from_secs(5))
			.unwrap();
		let other = lock.clone();
		assert!(std::thread::spawn(move || {
			std::panic::catch_unwind(std::panic::AssertUnwindSafe(|| {
				if poison_queue {
					let _queue = other.queue.lock().unwrap();
					panic!("queue fault injection");
				} else {
					let _inner = other.inner.lock().unwrap();
					panic!("original writer mutex fault injection");
				}
			}))
			.is_err()
		})
		.join()
		.unwrap());
		assert_eq!(peer.finish(), Err(StoreLockFailure::Unavailable));
		assert!(matches!(
			lock.acquire_shared(Instant::now() + Duration::from_secs(5)),
			Err(StoreLockFailure::Unavailable)
		));
		assert!(matches!(
			lock.acquire(None),
			Err(StoreLockFailure::Unavailable)
		));
		assert_eq!(lock.queue.is_poisoned(), poison_queue);
		assert_eq!(lock.inner.is_poisoned(), !poison_queue);
		assert_shared_gate_idle(&lock);
	}
}

fn wait_for_audit_store_waiters(lock: &AuditStoreLock, expected: usize) {
	let deadline = Instant::now() + Duration::from_secs(5);
	loop {
		if lock.queue.lock().unwrap().waiting.len() == expected {
			return;
		}
		assert!(Instant::now() < deadline, "store waiter did not register");
		std::thread::sleep(Duration::from_millis(1));
	}
}

fn assert_audit_store_idle(lock: &AuditStoreLock) {
	let queue = lock.queue.lock().unwrap();
	assert!(!queue.active);
	assert_eq!(queue.readers, 0);
	assert!(queue.waiting.is_empty());
}

#[test]
fn audit_store_fifo_orders_writers_and_timed_queries_together() {
	let lock = Arc::new(AuditStoreLock::default());
	let held = lock.acquire(None).unwrap();
	let (send, receive) = std::sync::mpsc::channel();
	let mut workers = Vec::new();
	for (position, timed) in [false, true, false, true].into_iter().enumerate() {
		let worker_lock = lock.clone();
		let send = send.clone();
		workers.push(std::thread::spawn(move || {
			let deadline = timed.then(|| Instant::now() + Duration::from_secs(10));
			let _guard = worker_lock.acquire(deadline).unwrap();
			send.send(position).unwrap();
		}));
		// Observe registration, rather than assume a sleep established order.
		wait_for_audit_store_waiters(&lock, position + 1);
	}
	drop(held);
	let observed: Vec<_> = (0..4)
		.map(|_| receive.recv_timeout(Duration::from_secs(5)).unwrap())
		.collect();
	for worker in workers {
		worker.join().unwrap();
	}
	assert_eq!(observed, [0, 1, 2, 3]);
	assert_audit_store_idle(&lock);
}

#[test]
fn audit_store_expired_query_never_takes_an_available_turn() {
	let lock = AuditStoreLock::default();
	assert_eq!(
		lock.acquire(Some(Instant::now())).err(),
		Some(StoreLockFailure::Deadline)
	);
	assert_audit_store_idle(&lock);
	drop(lock.acquire(None).unwrap());
	assert_audit_store_idle(&lock);
}

#[test]
fn audit_store_timed_cancellation_removes_head_and_middle_waiters() {
	for preceding_writer in [false, true] {
		let lock = Arc::new(AuditStoreLock::default());
		let held = lock.acquire(None).unwrap();
		let (send, receive) = std::sync::mpsc::channel();
		let mut workers = Vec::new();
		if preceding_writer {
			let worker_lock = lock.clone();
			let send = send.clone();
			workers.push(std::thread::spawn(move || {
				let _guard = worker_lock.acquire(None).unwrap();
				send.send(0).unwrap();
			}));
			wait_for_audit_store_waiters(&lock, 1);
		}
		let (expired_send, expired_receive) = std::sync::mpsc::channel();
		let query_lock = lock.clone();
		let query = std::thread::spawn(move || {
			let result = query_lock
				.acquire(Some(Instant::now() + Duration::from_secs(2)))
				.err();
			expired_send.send(result).unwrap();
		});
		wait_for_audit_store_waiters(&lock, usize::from(preceding_writer) + 1);
		let worker_lock = lock.clone();
		workers.push(std::thread::spawn(move || {
			let _guard = worker_lock.acquire(None).unwrap();
			send.send(1).unwrap();
		}));
		wait_for_audit_store_waiters(&lock, usize::from(preceding_writer) + 2);
		assert_eq!(
			expired_receive
				.recv_timeout(Duration::from_secs(5))
				.unwrap(),
			Some(StoreLockFailure::Deadline)
		);
		query.join().unwrap();
		assert_eq!(
			lock.queue.lock().unwrap().waiting.len(),
			usize::from(preceding_writer) + 1
		);
		assert!(receive.try_recv().is_err());
		drop(held);
		let expected = if preceding_writer {
			vec![0, 1]
		} else {
			vec![1]
		};
		let observed: Vec<_> = (0..expected.len())
			.map(|_| receive.recv_timeout(Duration::from_secs(5)).unwrap())
			.collect();
		for worker in workers {
			worker.join().unwrap();
		}
		assert_eq!(observed, expected);
		assert_audit_store_idle(&lock);
		// An expired query has no background waiter that can later take a turn.
		drop(lock.acquire(None).unwrap());
		assert_audit_store_idle(&lock);
	}
}

#[test]
fn audit_store_owner_panic_preserves_poison_and_releases_all_waiters() {
	let lock = Arc::new(AuditStoreLock::default());
	let (held_send, held_receive) = std::sync::mpsc::channel();
	let (panic_send, panic_receive) = std::sync::mpsc::channel();
	let owner_lock = lock.clone();
	let owner = std::thread::spawn(move || {
		let _guard = owner_lock.acquire(None).unwrap();
		held_send.send(()).unwrap();
		panic_receive.recv_timeout(Duration::from_secs(5)).unwrap();
		panic!("intentional audit store owner panic");
	});
	held_receive.recv_timeout(Duration::from_secs(5)).unwrap();
	let mut waiters = Vec::new();
	for (position, timed) in [false, true].into_iter().enumerate() {
		let waiter_lock = lock.clone();
		waiters.push(std::thread::spawn(move || {
			let deadline = timed.then(|| Instant::now() + Duration::from_secs(10));
			waiter_lock.acquire(deadline).err()
		}));
		wait_for_audit_store_waiters(&lock, position + 1);
	}
	panic_send.send(()).unwrap();
	assert!(owner.join().is_err());
	for waiter in waiters {
		assert_eq!(waiter.join().unwrap(), Some(StoreLockFailure::Unavailable));
	}
	assert!(lock.inner.is_poisoned());
	assert_audit_store_idle(&lock);
	for deadline in [None, Some(Instant::now() + Duration::from_secs(5))] {
		assert_eq!(
			lock.acquire(deadline).err(),
			Some(StoreLockFailure::Unavailable)
		);
		assert_audit_store_idle(&lock);
	}
}
