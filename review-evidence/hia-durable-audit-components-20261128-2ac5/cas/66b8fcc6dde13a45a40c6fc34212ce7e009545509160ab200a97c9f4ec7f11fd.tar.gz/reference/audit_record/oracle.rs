use serde::{Deserialize, Serialize};
use anyhow::{bail, Result};
use std::io::{Read, Write};
#[derive(Clone, Copy, Deserialize, Serialize, PartialEq, Eq)]
#[serde(rename_all = "snake_case")]
enum DurableState {
	Unknown,
	Completed,
	Failed,
}

mod record_schema {
	use super::DurableState;
	use serde::{Deserialize, Serialize};

	// Serde derives its default Visitor diagnostic from the Rust identifier,
	// not serde(rename). Keep the original name for both string specializations.
	#[derive(Clone, Deserialize, Serialize, PartialEq, Eq)]
	#[serde(deny_unknown_fields)]
	pub(super) struct Record<S> {
		pub(super) request_id: S,
		pub(super) owner: S,
		pub(super) tool_name: S,
		pub(super) state: DurableState,
		pub(super) accepted_unix_ms: u128,
		pub(super) elapsed_ms: Option<u64>,
	}
}
// Owned publications, projections and legacy rows keep their original type.
// Complete original verification borrows only the three string fields from its
// current bounded input; both forms share this exact serde field contract.
type RecordFields<S> = record_schema::Record<S>;
type Record = record_schema::Record<String>;

fn valid_id(value: &str) -> bool {
	value.len() == 64
		&& value
			.bytes()
			.all(|byte| byte.is_ascii_digit() || (b'a'..=b'f').contains(&byte))
}
fn valid_tool(value: &str) -> bool {
	!value.is_empty()
		&& value.len() <= 64
		&& value
			.bytes()
			.all(|byte| byte.is_ascii_lowercase() || byte == b'_')
}
fn original_record(filename: &str, bytes: &[u8]) -> Result<Record> {
	let record: Record = serde_json::from_slice(&bytes)?;
	if !valid_id(&record.request_id)
		|| !valid_id(&record.owner)
		|| !valid_tool(&record.tool_name)
		|| filename != format!("{}.json", record.request_id)
	{
		bail!("request audit metadata identity refused");
	}
	Ok(record)
}
fn word(raw: &[u8], at: usize) -> u64 {u64::from_le_bytes(raw[at..at+8].try_into().unwrap())}
fn put(raw: &mut [u8], at: usize, value: u64) {raw[at..at+8].copy_from_slice(&value.to_le_bytes());}
fn diagnostic(value: u64) -> Vec<u8> {
 let mut out=vec![0;32];out[..8].copy_from_slice(b"HRAJR001");put(&mut out,8,value);out
}
fn run(frame: &[u8]) -> Vec<u8> {
 assert!(frame.len()>=32 && &frame[..8]==b"HRAJQ001");
 let op=word(frame,8);let size=word(frame,16) as usize;let fsize=word(frame,24) as usize;
 assert!(op==1 || op==2);assert_eq!(fsize,if op==1 {0} else {69});assert_eq!(frame.len(),32+fsize+size);
 let filename=if op==2 {
  let Ok(name)=std::str::from_utf8(&frame[32..32+fsize]) else {return diagnostic(4)};
  let Some(id)=name.strip_suffix(".json") else {return diagnostic(4)};
  if !valid_id(id) {return diagnostic(4)};name
 } else {""};
 if size>2048 {return diagnostic(3)}
 let json=&frame[32+fsize..];
 let parsed: Record=match serde_json::from_slice(json) {Ok(value)=>value,Err(_)=>return diagnostic(1)};
 if op==2 && original_record(filename,json).is_err(){return diagnostic(2)}
 let fields=[parsed.request_id.as_bytes(),parsed.owner.as_bytes(),parsed.tool_name.as_bytes()];
 let mut out=vec![0;128+fields.iter().map(|s|s.len()).sum::<usize>()];
 out[..8].copy_from_slice(b"HRAJR001");
 put(&mut out,16,match parsed.state {DurableState::Unknown=>0,DurableState::Completed=>1,DurableState::Failed=>2});
 put(&mut out,24,parsed.accepted_unix_ms as u64);put(&mut out,32,(parsed.accepted_unix_ms>>64)as u64);
 put(&mut out,40,if parsed.elapsed_ms.is_some(){1}else{0});put(&mut out,48,parsed.elapsed_ms.unwrap_or(0));
 let n=out.len();put(&mut out,56,n as u64);
 let mut at=128;
 for(i,field)in fields.iter().enumerate(){put(&mut out,64+i*16,at as u64);put(&mut out,72+i*16,field.len()as u64);out[at..at+field.len()].copy_from_slice(field);at+=field.len();}
 out
}
fn main() -> std::io::Result<()> {
 let mut input=std::io::stdin().lock();let mut output=std::io::stdout().lock();
 loop {let mut head=[0u8;4];match input.read_exact(&mut head){Ok(())=>{},Err(e)if e.kind()==std::io::ErrorKind::UnexpectedEof=>break,Err(e)=>return Err(e)}
 let size=u32::from_le_bytes(head) as usize;assert!(size<=1<<20);let mut raw=vec![0;size];input.read_exact(&mut raw)?;
 let response=run(&raw);output.write_all(&(response.len()as u32).to_le_bytes())?;output.write_all(&response)?;
 } output.flush()
}
