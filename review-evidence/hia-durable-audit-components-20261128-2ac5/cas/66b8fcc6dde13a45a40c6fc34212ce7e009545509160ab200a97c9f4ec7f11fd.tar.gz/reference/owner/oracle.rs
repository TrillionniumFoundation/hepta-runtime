// Copyright 2026 Muvon Un Limited
// Copyright 2026 TrillionniumFoundation
// SPDX-License-Identifier: Apache-2.0
// Test-only fixed framing. The original module and its public functions are unchanged.
pub mod mcp;
pub mod utils;
use std::io::{self,Read,Write};
use std::os::unix::ffi::OsStringExt;
use std::path::PathBuf;
fn word(b:&[u8],at:usize)->u64{u64::from_le_bytes(b[at..at+8].try_into().unwrap())}
fn load(path:PathBuf)->anyhow::Result<()> {let config=mcp::runtime::config::RuntimeConfig::load(&path)?;mcp::runtime::config::init_runtime(config)}
fn initialize(b:&[u8])->anyhow::Result<Vec<u8>> {
 assert!(b.len()>=64);assert_eq!(&b[..8],b"HRCFGC01");assert_eq!(word(b,56),0);let flags=word(b,8);assert!(flags<16);
 let pathn=word(b,16) as usize;let path=PathBuf::from(std::ffi::OsString::from_vec(b[64..64+pathn].to_vec()));let mut pos=64+pathn;
 for (i,name) in ["HEPTA_RUNTIME_STATE_DIR","XDG_STATE_HOME","HOME","TMPDIR"].iter().enumerate(){
  let n=word(b,24+i*8) as usize;if flags&(1<<i)!=0 {std::env::set_var(name,std::ffi::OsString::from_vec(b[pos..pos+n].to_vec()));} else {std::env::remove_var(name);}pos+=n;
 }
 assert_eq!(pos,b.len());load(path)?;Ok(Vec::new())
}
fn main(){
 let args:Vec<_>=std::env::args_os().collect();assert_eq!(args.len(),3);assert_eq!(args[1],"--runtime-config");
 if let Err(error)=load(PathBuf::from(&args[2])){eprintln!("{error}");std::process::exit(78);}
 let mut input=io::stdin().lock();let mut output=io::stdout().lock();
 loop {let mut size=[0;8];match input.read(&mut size[..1]){Ok(0)=>break,Ok(1)=>(),v=>panic!("{v:?}")};input.read_exact(&mut size[1..]).unwrap();let n=u64::from_le_bytes(size) as usize;let mut b=vec![0;n];input.read_exact(&mut b).unwrap();
  let result=if &b[..8]==b"HRCFGC01" {initialize(&b)} else {assert_eq!(&b[..8],b"HRCFGQ01");let op=word(&b,8);let n=word(&b,16) as usize;assert_eq!(b.len(),24+n);let key=std::str::from_utf8(&b[24..]).unwrap();mcp::runtime::query(op,key)};
  let(status,payload)=match result{Ok(v)=>(0,v),Err(e)=>(1,e.to_string().into_bytes())};let mut response=b"HRCFGM01".to_vec();for value in [status,0,payload.len() as u64]{response.extend_from_slice(&value.to_le_bytes())}response.extend(payload);
  output.write_all(&(response.len() as u64).to_le_bytes()).unwrap();output.write_all(&response).unwrap();output.flush().unwrap();
 }
}
