from pathlib import Path
import subprocess, sys, os, json, hashlib, shutil, time, traceback, tomllib, tarfile
B=Path("/home/qian-qi/hia-runtime-durable-requests-20261128-2ac5")
S=B/"source";Q=B/"qualification/audit-fifo-native-v3";Q.mkdir(parents=True,exist_ok=False)
HEPTA=Path("/home/qian-qi/hia-runtime-filebytes-20261128-2ac5/pinned-hepta-d3e2")
TEMPLATE=Path("/home/qian-qi/hia-runtime-filebytes-20261128-2ac5/config-nativejobs-linux-reference-build-v2/project")
BOOTSTRAP=Path("/home/qian-qi/hia-runtime-filebytes-20261128-2ac5/local-read-component-build-v1/build/bootstrap")
SHA=lambda raw:hashlib.sha256(raw).hexdigest()
os.umask(0o022)
env=dict(os.environ,LC_ALL="C",LANG="C",CARGO_BUILD_JOBS="2",CARGO_TARGET_DIR=str(B/"target"))
for k in list(env):
 if k.startswith(("CARGO_PROFILE_","HIA_")) or k in ("RUSTC_WRAPPER","RUSTC_WORKSPACE_WRAPPER","RUSTFLAGS"):env.pop(k)
def run(argv,label,timeout=300):
 t=time.monotonic();argv=list(map(str,argv));r={"argv":argv,"timeout_seconds":timeout,"state":"RUNNING"}
 (Q/(label+".intent.json")).write_text(json.dumps(r,sort_keys=True,indent=2)+"\n")
 with (Q/(label+".stdout")).open("xb") as out,(Q/(label+".stderr")).open("xb") as err:
  p=subprocess.run(argv,cwd=S,env=env,stdout=out,stderr=err,timeout=timeout)
 r.update(exit_code=p.returncode,elapsed_seconds=time.monotonic()-t,state="PASS"if p.returncode==0 else"FAIL")
 for k in ("stdout","stderr"):r[k]={"bytes":(Q/(label+"."+k)).stat().st_size,"sha256":SHA((Q/(label+"."+k)).read_bytes())}
 (Q/(label+".terminal.json")).write_text(json.dumps(r,sort_keys=True,indent=2)+"\n")
 print(json.dumps(r),flush=True)
 if p.returncode:print((Q/(label+".stderr")).read_text(errors="replace"),flush=True);raise RuntimeError(label+" failed")
 return p
names=("scripts/author_durable_common.py","scripts/author_durable_audit_fifo.py","scripts/durable_audit_fifo_source.py.txt","native/durable_audit_fifo.hepta","native/durable_audit_fifo_composition.json","native/request_storage_json.hepta","scripts/hia_native_build.py","scripts/hia_native_loader.py","scripts/prepare_durable_audit_fifo_reference.py","scripts/durable_audit_fifo_native_fixture.rs.txt","src/mcp/runtime/request_audit.rs","src/mcp/runtime/request_audit_tests.rs","src/mcp/runtime/request_archive_index_tests.rs")
def sources():return{n:{"bytes":len(raw),"sha256":SHA(raw)}for n in names for raw in[(S/n).read_bytes()]}
before=sources();(Q/"source-before.json").write_text(json.dumps(before,sort_keys=True,indent=2)+"\n")
start=time.monotonic();report={"state":"RUNNING","started_ns":time.time_ns()}
(Q/"terminal.json").write_text(json.dumps(report)+"\n")
try:
 actual=(B/"reference/audit_fifo/native.rs").read_bytes()
 adapter=(S/"scripts/durable_audit_fifo_native_fixture.rs.txt").read_bytes()
 if not actual.startswith(adapter) or SHA(adapter)!="ccf5cbf729d3d95c6641bcadedee1838389cdafc2e366d67bd9b34f10b866aab":raise ValueError("exact native fixture successor differs")
 prior=(B/"qualification/audit-fifo-native-v2/source-relation.json").read_bytes()
 (Q/"source-relation.json").write_bytes(prior)
 original= B/"qualification/audit-fifo-native-v1/original-nine-original-methods"
 old_terminal=json.loads(Path(str(original)+".terminal.json").read_bytes())
 if old_terminal["state"]!="PASS" or old_terminal["exit_code"]!=0:raise ValueError("original nine not passed")
 for stream in ("stdout","stderr"):
  raw=Path(str(original)+"."+stream).read_bytes()
  if SHA(raw)!=old_terminal[stream]["sha256"]:raise ValueError("original nine raw changed")
 (Q/"retained-original-nine-terminal.json").write_text(json.dumps(old_terminal,sort_keys=True,indent=2)+"\n")
 rustbin=Path.home()/".rustup/toolchains/1.95.0-x86_64-unknown-linux-gnu/bin"
 cargo=rustbin/"cargo";rustc=rustbin/"rustc"
 if not cargo.is_file()or not rustc.is_file():raise ValueError("fixed Rust1.95.0 unavailable")
 env["PATH"]=str(rustbin)+os.pathsep+env.get("PATH","");env["RUSTC"]=str(rustc)
 run([rustc,"--version","--verbose"],"rust-version",30)
 if b"commit-hash: 59807616e1fa2540724bfbac14d7976d7e4a3860" not in (Q/"rust-version.stdout").read_bytes():raise ValueError("Rust compiler exact commit differs")
 lock=(B/"reference/Cargo.lock").read_bytes()
 if lock!=(TEMPLATE/"Cargo.lock").read_bytes():raise ValueError("reference lock changed")
 run([cargo,"metadata","--manifest-path",B/"reference/Cargo.toml","--locked","--offline","--format-version","1"],"cargo-metadata",180)
 meta=json.loads((Q/"cargo-metadata.stdout").read_bytes());locked={(r["name"],r["version"]):r for r in tomllib.loads(lock.decode())["package"]if"checksum"in r}
 packages=[p for p in meta["packages"]if p["source"]is not None];observed=[]
 if len(packages)!=len(locked):raise ValueError("dependency count changed")
 for p in packages:
  key=(p["name"],p["version"]);r=locked[key];src=Path(p["manifest_path"]).parent
  archive=src.parents[2]/"cache"/src.parent.name/(src.name+".crate")
  raw=archive.read_bytes()
  if SHA(raw)!=r["checksum"]:raise ValueError("registry archive mismatch "+src.name)
  count=0
  with tarfile.open(archive,"r:gz") as tf:
   for m in tf:
    if m.isfile():
     name=Path(m.name).relative_to(src.name)
     old=tf.extractfile(m).read()
     if (src/name).read_bytes()!=old:raise ValueError("registry member mismatch "+str(name))
     count+=1
  observed.append(dict(name=p["name"],version=p["version"],source=p["source"],checksum=SHA(raw),members=count))
 (Q/"actual-locked-registry.json").write_text(json.dumps(observed,sort_keys=True,indent=2)+"\n")

 if (B/"reference/Cargo.lock").read_bytes()!=lock:raise ValueError("original Cargo lock mutated")
 build=B/"build"
 captured={}
 for name in ("bootstrap.json","B1.image.bin","B2.image.bin","B3.image.bin"):
  raw=(build/"bootstrap"/name).read_bytes()
  if (BOOTSTRAP/name).read_bytes()!=raw:raise ValueError("borrowed completed compiler changed")
  captured[name]={"bytes":len(raw),"sha256":SHA(raw)}
 if captured["B3.image.bin"]["sha256"]!="bfd603dd2b40974d2083b567b4295fb3975938da8435dd636514fc197c485de0":raise ValueError("compiler image differs")
 (Q/"borrowed-completed-compiler.json").write_text(json.dumps(captured,sort_keys=True,indent=2)+"\n")
 sys.path.insert(0,str(S/"scripts"))
 from hia_native_build import NativeBuild
 maker=NativeBuild(HEPTA,build)
 manifest=maker.compile("durable-audit-fifo-v3",S/"native/durable_audit_fifo.hepta",standalone=None)
 manifest_raw=manifest.read_bytes();data=json.loads(manifest_raw)
 image=manifest.parent/data["image"];image_raw=image.read_bytes()
 if SHA(image_raw)!=data["image_sha256"]:raise ValueError("actual FIFO image differs")
 env["HIA_FIFO_FIXTURE_IMAGE"]=str(image);env["HIA_FIFO_FIXTURE_IMAGE_SHA256"]=SHA(image_raw)
 for kind in ("native",):
  run([cargo,"test","--manifest-path",B/"reference/Cargo.toml","--release","--locked","--offline","--jobs","2","--test","hia-durable-audit-fifo-"+kind,"--","--test-threads=1","--nocapture"],kind+"-nine-original-methods",120)
  raw=(Q/(kind+"-nine-original-methods.stdout")).read_text()
  if "9 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out"not in raw:raise ValueError("complete nine original methods absent")
 if manifest.read_bytes()!=manifest_raw or image.read_bytes()!=image_raw:raise ValueError("actual native image or manifest changed")
 if (B/"reference/Cargo.lock").read_bytes()!=lock:raise ValueError("locked dependency graph changed")
 report.update(original_methods=9,native_original_methods=9,manifest_sha256=SHA(manifest_raw),image_sha256=SHA(image_raw))

 after=sources();(Q/"source-after.json").write_text(json.dumps(after,sort_keys=True,indent=2)+"\n")
 if before!=after:raise ValueError("physical source changed")
 report.update(source_unchanged=True,state="PASS",elapsed_seconds=time.monotonic()-start,manifest=str(manifest))
except BaseException as error:
 report.update(state="FAIL",elapsed_seconds=time.monotonic()-start,error=repr(error),traceback=traceback.format_exc())
finally:
 (Q/"terminal.json").write_text(json.dumps(report,sort_keys=True,indent=2)+"\n")
 print(json.dumps(report),flush=True)
sys.exit(0 if report["state"]=="PASS"else 1)
