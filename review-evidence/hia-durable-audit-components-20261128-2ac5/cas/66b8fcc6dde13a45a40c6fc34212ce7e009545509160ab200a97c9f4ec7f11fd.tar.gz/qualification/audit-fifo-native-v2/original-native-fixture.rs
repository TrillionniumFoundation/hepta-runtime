// Copyright 2026 Muvon Un Limited
// Copyright 2026 TrillionniumFoundation
// SPDX-License-Identifier: Apache-2.0
// QA-only mechanical synchronization for the actual native FIFO owner.
// Public/runtime policy remains in durable_audit_fifo.hepta.
use std::collections::VecDeque;
use std::sync::{Arc,Mutex,OnceLock};
use std::time::{Instant,Duration};
use std::io::Write;
use std::os::fd::{FromRawFd,AsRawFd};
use sha2::{Sha256,Digest};
type Entry=unsafe extern "C" fn(*const u8,u64,*mut u8,u64,*mut u8,u64)->u64;
struct Code{entry:Entry}
unsafe impl Send for Code{}
unsafe impl Sync for Code{}
impl Code{
 fn get()->&'static Self{
  static CODE:OnceLock<Code>=OnceLock::new();
  CODE.get_or_init(||{
   let path=std::env::var("HIA_FIFO_FIXTURE_IMAGE").expect("explicit private image");
   let expected=std::env::var("HIA_FIFO_FIXTURE_IMAGE_SHA256").expect("explicit complete image SHA");
   let bytes=std::fs::read(path).unwrap();
   assert_eq!(format!("{:x}",Sha256::digest(&bytes)),expected);
   let name=std::ffi::CString::new("audit-fifo-qualified").unwrap();
   let fd=unsafe{libc::memfd_create(name.as_ptr(),libc::MFD_CLOEXEC|libc::MFD_ALLOW_SEALING)};assert!(fd>=0);
   let mut file=unsafe{std::fs::File::from_raw_fd(fd)};file.write_all(&bytes).unwrap();
   let seals=libc::F_SEAL_WRITE|libc::F_SEAL_SHRINK|libc::F_SEAL_GROW|libc::F_SEAL_SEAL;
   assert_eq!(unsafe{libc::fcntl(file.as_raw_fd(),libc::F_ADD_SEALS,seals)},0);
   assert_eq!(unsafe{libc::fcntl(file.as_raw_fd(),libc::F_GET_SEALS)},seals);
   let address=unsafe{libc::mmap(std::ptr::null_mut(),bytes.len(),libc::PROT_READ|libc::PROT_EXEC,libc::MAP_PRIVATE,file.as_raw_fd(),0)};
   assert_ne!(address,libc::MAP_FAILED);
   Self{entry:unsafe{std::mem::transmute::<*mut libc::c_void,Entry>(address)}}
  })
 }
}
fn clock_origin()->Instant{static ORIGIN:OnceLock<Instant>=OnceLock::new();*ORIGIN.get_or_init(Instant::now)}
fn tick(value:Instant)->u64{u64::try_from(value.saturating_duration_since(clock_origin()).as_nanos()).unwrap()}
fn get(raw:&[u8],at:usize)->u64{u64::from_le_bytes(raw[at..at+8].try_into().unwrap())}
fn put(raw:&mut[u8],at:usize,value:u64){raw[at..at+8].copy_from_slice(&value.to_le_bytes())}
#[derive(Clone,Copy,PartialEq,Eq)]enum AuditStoreAccess{Exclusive,Shared}
#[derive(Clone,Copy,Debug,PartialEq,Eq)]enum StoreLockFailure{Deadline,Unavailable}
struct AuditStoreQueue{
 next_ticket:u64,active:bool,readers:usize,reader_poisoned:bool,
 waiting:VecDeque<(u64,AuditStoreAccess)>,state:Vec<u8>
}
impl Default for AuditStoreQueue{
 fn default()->Self{
  let _=clock_origin();let mut result=Self{next_ticket:0,active:false,readers:0,reader_poisoned:false,waiting:VecDeque::new(),state:vec![0;128]};
  assert_eq!(result.call_at(0,None,0,0,0)[1],0);result
 }
}
impl AuditStoreQueue{
 fn publish_observation(&mut self){
  self.next_ticket=get(&self.state,8);self.active=get(&self.state,16)==1;self.readers=get(&self.state,32)as usize;self.reader_poisoned=get(&self.state,40)==1;
  self.waiting.clear();
  for i in 0..get(&self.state,48)as usize{let at=128+i*64;if get(&self.state,at+16)==1{self.waiting.push_back((get(&self.state,at),if get(&self.state,at+8)==1{AuditStoreAccess::Exclusive}else{AuditStoreAccess::Shared}));}}
 }
 fn call_at(&mut self,op:u64,deadline:Option<Instant>,ticket:u64,flags:u64,now:u64)->[u64;8]{
  let mut input=[0u8;64];input[..8].copy_from_slice(b"HRAFL001");
  for(at,value)in[(8,op),(16,now),(24,u64::from(deadline.is_some())),(32,deadline.map(tick).unwrap_or(0)),(40,ticket),(48,flags)]{put(&mut input,at,value)}
  loop{
   let original=input;let state_before=self.state.clone();let mut output=[0xa5u8;96];let input_ptr=input.as_ptr();
   // The 16-byte output canaries are outside the exact declared 64-byte span.
   let code=unsafe{(Code::get().entry)(input_ptr,64,output.as_mut_ptr().add(16),64,self.state.as_mut_ptr(),self.state.len()as u64)};
   assert_eq!(input,original);assert_eq!(&output[..16],&[0xa5;16]);assert_eq!(&output[80..],&[0xa5;16]);
   assert_eq!(code,64,"native private FIFO protocol refusal");
   let reply=std::array::from_fn(|i|get(&output[16..80],i*8));
   assert_eq!(&output[16..24],b"HRAFO001");assert_eq!(&reply[5..],&[0,0,0]);
   if reply[1]==7{
    assert_eq!(self.state,state_before,"growth must not consume a ticket or change ownership");
    let required=usize::try_from(reply[3]).unwrap();assert!(required>self.state.len());
    let capacity=required.max(self.state.len().checked_mul(2).unwrap());self.state.resize(capacity,0);continue
   }
   self.publish_observation();return reply
  }
 }
 fn step(&mut self,op:u64,deadline:Option<Instant>,ticket:u64,flags:u64)->[u64;8]{self.call_at(op,deadline,ticket,flags,tick(Instant::now()))}
}
#[derive(Default)]struct AuditStoreLock{inner:Mutex<()>,queue:Mutex<AuditStoreQueue>,changed:std::sync::Condvar}
struct AuditStoreGuard<'a>{lock:&'a AuditStoreLock,inner:Option<std::sync::MutexGuard<'a,()>>,ticket:u64,deadline:Option<Instant>,active:bool}
struct AuditSharedGuard<'a>{lock:&'a AuditStoreLock,deadline:Instant,ticket:u64,active:bool,_not_send:std::marker::PhantomData<std::sync::MutexGuard<'a,()>>}
fn failure(code:u64)->StoreLockFailure{match code{4=>StoreLockFailure::Deadline,5=>StoreLockFailure::Unavailable,_=>panic!("unexpected native status {code}")}}
fn preflight(deadline:Option<Instant>)->Result<(),StoreLockFailure>{
 let mut state=AuditStoreQueue::default();let result=state.step(10,deadline,0,0);if result[1]==0{Ok(())}else{Err(failure(result[1]))}
}
impl AuditStoreLock{
 fn flags(&self)->u64{u64::from(self.inner.is_poisoned())*2}
 fn resume(&self,op:u64,deadline:Option<Instant>,ticket:u64,extra:u64)->[u64;8]{
  let (mut queue,poison)=match self.queue.lock(){Ok(q)=>(q,0),Err(e)=>(e.into_inner(),1)};
  let result=queue.step(op,deadline,ticket,self.flags()|poison|extra);
  if result[4]==1{self.changed.notify_all()}result
 }
 fn reserve(&self,deadline:Option<Instant>,access:u64)->Result<u64,StoreLockFailure>{
  preflight(deadline)?;
  let mut queue=self.queue.lock().map_err(|_|StoreLockFailure::Unavailable)?;
  let first=queue.step(access,deadline,0,self.flags());
  if first[1]!=1{return Err(failure(first[1]))}
  let ticket=first[2];
  loop{
   let result=queue.step(3,deadline,ticket,self.flags());
   if result[4]==1{self.changed.notify_all()}
   match result[1]{2=>return Ok(ticket),1=>{},code=>return Err(failure(code))}
   let waited=match deadline{
    Some(limit)=>self.changed.wait_timeout(queue,limit.saturating_duration_since(Instant::now())).map(|(queue,_)|queue).map_err(|e|e.into_inner().0),
    None=>self.changed.wait(queue).map_err(|e|e.into_inner())
   };
   queue=match waited{Ok(q)=>q,Err(mut q)=>{let result=q.step(9,deadline,ticket,self.flags()|1);assert_eq!(result[1],5);self.changed.notify_all();return Err(StoreLockFailure::Unavailable)}};
  }
 }
 fn acquire(&self,deadline:Option<Instant>)->Result<AuditStoreGuard<'_>,StoreLockFailure>{
  let ticket=self.reserve(deadline,1)?;
  let mut guard=AuditStoreGuard{lock:self,inner:None,ticket,deadline,active:true};
  let before=self.resume(4,deadline,ticket,0);
  if before[1]!=8{return Err(failure(before[1]))}
  let flags=match self.inner.try_lock(){Ok(inner)=>{guard.inner=Some(inner);0},Err(std::sync::TryLockError::Poisoned(e))=>{drop(e.into_inner());2},Err(std::sync::TryLockError::WouldBlock)=>4};
  let after=self.resume(5,deadline,ticket,flags);
  if after[1]!=3{return Err(failure(after[1]))}
  Ok(guard)
 }
 fn acquire_shared(&self,deadline:Instant)->Result<AuditSharedGuard<'_>,StoreLockFailure>{
  let ticket=self.reserve(Some(deadline),2)?;
  let guard=AuditSharedGuard{lock:self,deadline,ticket,active:true,_not_send:std::marker::PhantomData};
  let result=self.resume(4,Some(deadline),ticket,0);
  if result[1]!=3{return Err(failure(result[1]))}Ok(guard)
 }
}
impl Drop for AuditStoreGuard<'_>{
 fn drop(&mut self){if !self.active{return}drop(self.inner.take());let result=self.lock.resume(6,self.deadline,self.ticket,0);assert_eq!(result[1],0);self.active=false;}
}
impl AuditSharedGuard<'_>{
 fn finish(mut self)->Result<(),StoreLockFailure>{
  let result=self.lock.resume(7,Some(self.deadline),self.ticket,0);self.active=false;
  if result[1]==0{Ok(())}else{Err(failure(result[1]))}
 }
}
impl Drop for AuditSharedGuard<'_>{
 fn drop(&mut self){if !self.active{return}let result=self.lock.resume(8,Some(self.deadline),self.ticket,u64::from(std::thread::panicking())*8);assert_eq!(result[1],0);self.active=false;}
}

fn wait_for_shared_gate_queue(lock: &AuditStoreLock, expected: usize) {
	let until = Instant::now() + std::time::Duration::from_secs(5);
	loop {
		if lock.queue.lock().unwrap().waiting.len() == expected {
			return;
		}
		assert!(Instant::now() < until, "store gate waiter did not arrive");
		std::thread::yield_now();
	}
}

fn assert_shared_gate_idle(lock: &AuditStoreLock) {
	let queue = lock.queue.lock().unwrap_or_else(|error| error.into_inner());
	assert!(!queue.active);
	assert_eq!(queue.readers, 0);
	assert!(queue.waiting.is_empty());
}

#[test]
fn shared_gate_allows_two_readers_without_bypassing_a_queued_writer() {
	use std::sync::mpsc;
	use std::time::Duration;
	let lock = Arc::new(AuditStoreLock::default());
	let first = lock
		.acquire_shared(Instant::now() + Duration::from_secs(5))
		.unwrap();
	let second = lock
		.acquire_shared(Instant::now() + Duration::from_secs(5))
		.unwrap();
	assert_eq!(lock.queue.lock().unwrap().readers, 2);
	let (events_tx, events_rx) = mpsc::channel();
	let (release_tx, release_rx) = mpsc::channel();
	let writer_lock = lock.clone();
	let writer_events = events_tx.clone();
	let writer = std::thread::spawn(move || {
		let guard = writer_lock
			.acquire(Some(Instant::now() + Duration::from_secs(5)))
			.unwrap();
		writer_events.send("writer").unwrap();
		release_rx.recv_timeout(Duration::from_secs(5)).unwrap();
		drop(guard);
	});
	wait_for_shared_gate_queue(&lock, 1);
	let later_lock = lock.clone();
	let later = std::thread::spawn(move || {
		let guard = later_lock
			.acquire_shared(Instant::now() + Duration::from_secs(5))
			.unwrap();
		events_tx.send("reader").unwrap();
		guard.finish().unwrap();
	});
	wait_for_shared_gate_queue(&lock, 2);
	first.finish().unwrap();
	assert_eq!(lock.queue.lock().unwrap().readers, 1);
	assert!(matches!(
		events_rx.try_recv(),
		Err(mpsc::TryRecvError::Empty)
	));
	second.finish().unwrap();
	assert_eq!(
		events_rx.recv_timeout(Duration::from_secs(5)).unwrap(),
		"writer"
	);
	wait_for_shared_gate_queue(&lock, 1);
	assert!(matches!(
		events_rx.try_recv(),
		Err(mpsc::TryRecvError::Empty)
	));
	release_tx.send(()).unwrap();
	assert_eq!(
		events_rx.recv_timeout(Duration::from_secs(5)).unwrap(),
		"reader"
	);
	writer.join().unwrap();
	later.join().unwrap();
	assert_shared_gate_idle(&lock);
}

#[test]
fn shared_readers_have_no_count_cap_and_cancelled_waiters_preserve_fifo() {
	use std::sync::mpsc;
	use std::time::Duration;
	// Independent readers all own the same snapshot concurrently. A writer still
	// waits for every original reader to release that protected snapshot.
	let lock = Arc::new(AuditStoreLock::default());
	let mut readers = (0..32)
		.map(|_| {
			lock.acquire_shared(Instant::now() + Duration::from_secs(5))
				.unwrap()
		})
		.collect::<Vec<_>>();
	assert_eq!(lock.queue.lock().unwrap().readers, 32);
	assert!(lock.queue.lock().unwrap().waiting.is_empty());
	let other = lock.clone();
	let (tx, rx) = mpsc::channel();
	let writer = std::thread::spawn(move || {
		let guard = other
			.acquire(Some(Instant::now() + Duration::from_secs(5)))
			.unwrap();
		tx.send(()).unwrap();
		drop(guard);
	});
	wait_for_shared_gate_queue(&lock, 1);
	while readers.len() > 1 {
		readers.pop().unwrap().finish().unwrap();
	}
	assert_eq!(lock.queue.lock().unwrap().readers, 1);
	assert!(matches!(rx.try_recv(), Err(mpsc::TryRecvError::Empty)));
	readers.pop().unwrap().finish().unwrap();
	rx.recv_timeout(Duration::from_secs(5)).unwrap();
	writer.join().unwrap();
	assert_shared_gate_idle(&lock);
	for cancelled_position in [0, 1] {
		let lock = Arc::new(AuditStoreLock::default());
		let held = lock.acquire(None).unwrap();
		let (order_tx, order_rx) = mpsc::channel();
		let (cancel_tx, cancel_rx) = mpsc::channel();
		let mut threads = Vec::new();
		for position in 0..3 {
			let other = lock.clone();
			let order = order_tx.clone();
			let cancelled = cancel_tx.clone();
			threads.push(std::thread::spawn(move || {
				if position == cancelled_position {
					let result = other.acquire_shared(Instant::now() + Duration::from_secs(2));
					cancelled
						.send(matches!(result, Err(StoreLockFailure::Deadline)))
						.unwrap();
				} else {
					let guard = other
						.acquire(Some(Instant::now() + Duration::from_secs(5)))
						.unwrap();
					order.send(position).unwrap();
					drop(guard);
				}
			}));
			wait_for_shared_gate_queue(&lock, position + 1);
		}
		assert!(cancel_rx.recv_timeout(Duration::from_secs(5)).unwrap());
		wait_for_shared_gate_queue(&lock, 2);
		drop(held);
		let order = [
			order_rx.recv_timeout(Duration::from_secs(5)).unwrap(),
			order_rx.recv_timeout(Duration::from_secs(5)).unwrap(),
		];
		let expected: Vec<_> = (0..3)
			.filter(|position| *position != cancelled_position)
			.collect();
		assert_eq!(order.as_slice(), expected.as_slice());
		for thread in threads {
			thread.join().unwrap();
		}
		assert_shared_gate_idle(&lock);
	}
}

#[test]
fn expired_shared_owner_keeps_custody_until_finish_then_releases_writer() {
	use std::sync::mpsc;
	use std::time::Duration;
	let lock = Arc::new(AuditStoreLock::default());
	let limit = Instant::now() + Duration::from_secs(2);
	let held = lock.acquire_shared(limit).unwrap();
	let other = lock.clone();
	let (tx, rx) = mpsc::channel();
	let writer = std::thread::spawn(move || {
		let guard = other
			.acquire(Some(Instant::now() + Duration::from_secs(5)))
			.unwrap();
		tx.send(()).unwrap();
		drop(guard);
	});
	wait_for_shared_gate_queue(&lock, 1);
	while Instant::now() < limit {
		std::thread::sleep(Duration::from_millis(1));
	}
	assert_eq!(lock.queue.lock().unwrap().readers, 1);
	assert!(matches!(rx.try_recv(), Err(mpsc::TryRecvError::Empty)));
	assert_eq!(held.finish(), Err(StoreLockFailure::Deadline));
	rx.recv_timeout(Duration::from_secs(5)).unwrap();
	writer.join().unwrap();
	assert_shared_gate_idle(&lock);
}

#[test]
fn shared_panic_refuses_active_peers_without_revoking_finished_reads() {
	use std::time::Duration;
	let lock = Arc::new(AuditStoreLock::default());
	let completed = lock
		.acquire_shared(Instant::now() + Duration::from_secs(5))
		.unwrap()
		.finish();
	let peer = lock
		.acquire_shared(Instant::now() + Duration::from_secs(5))
		.unwrap();
	let other = lock.clone();
	let panicked = std::thread::spawn(move || {
		std::panic::catch_unwind(std::panic::AssertUnwindSafe(|| {
			let _guard = other
				.acquire_shared(Instant::now() + Duration::from_secs(5))
				.unwrap();
			panic!("shared owner fault injection");
		}))
		.is_err()
	})
	.join()
	.unwrap();
	assert!(panicked);
	assert_eq!(completed, Ok(()));
	assert_eq!(peer.finish(), Err(StoreLockFailure::Unavailable));
	assert!(matches!(
		lock.acquire_shared(Instant::now() + Duration::from_secs(5)),
		Err(StoreLockFailure::Unavailable)
	));
	assert!(matches!(
		lock.acquire(None),
		Err(StoreLockFailure::Unavailable)
	));
	assert!(lock.queue.lock().unwrap().reader_poisoned);
	assert_shared_gate_idle(&lock);
}

#[test]
fn shared_admission_and_finish_preserve_writer_and_queue_poison() {
	use std::time::Duration;
	for poison_queue in [false, true] {
		let lock = Arc::new(AuditStoreLock::default());
		let peer = lock
			.acquire_shared(Instant::now() + Duration::from_secs(5))
			.unwrap();
		let other = lock.clone();
		assert!(std::thread::spawn(move || {
			std::panic::catch_unwind(std::panic::AssertUnwindSafe(|| {
				if poison_queue {
					let _queue = other.queue.lock().unwrap();
					panic!("queue fault injection");
				} else {
					let _inner = other.inner.lock().unwrap();
					panic!("original writer mutex fault injection");
				}
			}))
			.is_err()
		})
		.join()
		.unwrap());
		assert_eq!(peer.finish(), Err(StoreLockFailure::Unavailable));
		assert!(matches!(
			lock.acquire_shared(Instant::now() + Duration::from_secs(5)),
			Err(StoreLockFailure::Unavailable)
		));
		assert!(matches!(
			lock.acquire(None),
			Err(StoreLockFailure::Unavailable)
		));
		assert_eq!(lock.queue.is_poisoned(), poison_queue);
		assert_eq!(lock.inner.is_poisoned(), !poison_queue);
		assert_shared_gate_idle(&lock);
	}
}

fn wait_for_audit_store_waiters(lock: &AuditStoreLock, expected: usize) {
	let deadline = Instant::now() + Duration::from_secs(5);
	loop {
		if lock.queue.lock().unwrap().waiting.len() == expected {
			return;
		}
		assert!(Instant::now() < deadline, "store waiter did not register");
		std::thread::sleep(Duration::from_millis(1));
	}
}

fn assert_audit_store_idle(lock: &AuditStoreLock) {
	let queue = lock.queue.lock().unwrap();
	assert!(!queue.active);
	assert_eq!(queue.readers, 0);
	assert!(queue.waiting.is_empty());
}

#[test]
fn audit_store_fifo_orders_writers_and_timed_queries_together() {
	let lock = Arc::new(AuditStoreLock::default());
	let held = lock.acquire(None).unwrap();
	let (send, receive) = std::sync::mpsc::channel();
	let mut workers = Vec::new();
	for (position, timed) in [false, true, false, true].into_iter().enumerate() {
		let worker_lock = lock.clone();
		let send = send.clone();
		workers.push(std::thread::spawn(move || {
			let deadline = timed.then(|| Instant::now() + Duration::from_secs(10));
			let _guard = worker_lock.acquire(deadline).unwrap();
			send.send(position).unwrap();
		}));
		// Observe registration, rather than assume a sleep established order.
		wait_for_audit_store_waiters(&lock, position + 1);
	}
	drop(held);
	let observed: Vec<_> = (0..4)
		.map(|_| receive.recv_timeout(Duration::from_secs(5)).unwrap())
		.collect();
	for worker in workers {
		worker.join().unwrap();
	}
	assert_eq!(observed, [0, 1, 2, 3]);
	assert_audit_store_idle(&lock);
}

#[test]
fn audit_store_expired_query_never_takes_an_available_turn() {
	let lock = AuditStoreLock::default();
	assert_eq!(
		lock.acquire(Some(Instant::now())).err(),
		Some(StoreLockFailure::Deadline)
	);
	assert_audit_store_idle(&lock);
	drop(lock.acquire(None).unwrap());
	assert_audit_store_idle(&lock);
}

#[test]
fn audit_store_timed_cancellation_removes_head_and_middle_waiters() {
	for preceding_writer in [false, true] {
		let lock = Arc::new(AuditStoreLock::default());
		let held = lock.acquire(None).unwrap();
		let (send, receive) = std::sync::mpsc::channel();
		let mut workers = Vec::new();
		if preceding_writer {
			let worker_lock = lock.clone();
			let send = send.clone();
			workers.push(std::thread::spawn(move || {
				let _guard = worker_lock.acquire(None).unwrap();
				send.send(0).unwrap();
			}));
			wait_for_audit_store_waiters(&lock, 1);
		}
		let (expired_send, expired_receive) = std::sync::mpsc::channel();
		let query_lock = lock.clone();
		let query = std::thread::spawn(move || {
			let result = query_lock
				.acquire(Some(Instant::now() + Duration::from_secs(2)))
				.err();
			expired_send.send(result).unwrap();
		});
		wait_for_audit_store_waiters(&lock, usize::from(preceding_writer) + 1);
		let worker_lock = lock.clone();
		workers.push(std::thread::spawn(move || {
			let _guard = worker_lock.acquire(None).unwrap();
			send.send(1).unwrap();
		}));
		wait_for_audit_store_waiters(&lock, usize::from(preceding_writer) + 2);
		assert_eq!(
			expired_receive
				.recv_timeout(Duration::from_secs(5))
				.unwrap(),
			Some(StoreLockFailure::Deadline)
		);
		query.join().unwrap();
		assert_eq!(
			lock.queue.lock().unwrap().waiting.len(),
			usize::from(preceding_writer) + 1
		);
		assert!(receive.try_recv().is_err());
		drop(held);
		let expected = if preceding_writer {
			vec![0, 1]
		} else {
			vec![1]
		};
		let observed: Vec<_> = (0..expected.len())
			.map(|_| receive.recv_timeout(Duration::from_secs(5)).unwrap())
			.collect();
		for worker in workers {
			worker.join().unwrap();
		}
		assert_eq!(observed, expected);
		assert_audit_store_idle(&lock);
		// An expired query has no background waiter that can later take a turn.
		drop(lock.acquire(None).unwrap());
		assert_audit_store_idle(&lock);
	}
}

#[test]
fn audit_store_owner_panic_preserves_poison_and_releases_all_waiters() {
	let lock = Arc::new(AuditStoreLock::default());
	let (held_send, held_receive) = std::sync::mpsc::channel();
	let (panic_send, panic_receive) = std::sync::mpsc::channel();
	let owner_lock = lock.clone();
	let owner = std::thread::spawn(move || {
		let _guard = owner_lock.acquire(None).unwrap();
		held_send.send(()).unwrap();
		panic_receive.recv_timeout(Duration::from_secs(5)).unwrap();
		panic!("intentional audit store owner panic");
	});
	held_receive.recv_timeout(Duration::from_secs(5)).unwrap();
	let mut waiters = Vec::new();
	for (position, timed) in [false, true].into_iter().enumerate() {
		let waiter_lock = lock.clone();
		waiters.push(std::thread::spawn(move || {
			let deadline = timed.then(|| Instant::now() + Duration::from_secs(10));
			waiter_lock.acquire(deadline).err()
		}));
		wait_for_audit_store_waiters(&lock, position + 1);
	}
	panic_send.send(()).unwrap();
	assert!(owner.join().is_err());
	for waiter in waiters {
		assert_eq!(waiter.join().unwrap(), Some(StoreLockFailure::Unavailable));
	}
	assert!(lock.inner.is_poisoned());
	assert_audit_store_idle(&lock);
	for deadline in [None, Some(Instant::now() + Duration::from_secs(5))] {
		assert_eq!(
			lock.acquire(deadline).err(),
			Some(StoreLockFailure::Unavailable)
		);
		assert_audit_store_idle(&lock);
	}
}
