from pathlib import Path
import os,stat,hashlib,tarfile,io,json,time,subprocess
B=Path("/Users/qianqi/work/hia-runtime-durable-requests-20261128-2ac5");S=B/"source";Q=B/"qualification/archive-records-checkpoint-v1";Q.mkdir(parents=True,exist_ok=False)
E=S/"review-evidence/hia-durable-archive-records-20261128-2ac5";E.mkdir(parents=True,exist_ok=False)
SHA=lambda v:hashlib.sha256(v).hexdigest()
names=["scripts/durable_audit_archive_records_source.py.txt","scripts/author_durable_audit_archive_records.py","native/durable_audit_archive_records.hepta","native/durable_audit_archive_records_composition.json","native/durable_audit_archive_records_abi.md","scripts/prepare_durable_audit_archive_records_reference.py","scripts/qualify_durable_audit_archive_records.py"]
def git(label,args):
 p=subprocess.run(["/usr/bin/git",*args],cwd=S,capture_output=True);(Q/(label+".stdout")).write_bytes(p.stdout);(Q/(label+".stderr")).write_bytes(p.stderr);assert p.returncode==0,(label,p.returncode,p.stderr.decode(errors="replace"));return p.stdout
head=git("head-before",["rev-parse","HEAD"]).decode().strip();assert head=="7815d85db3f3eda57a9dae84c1632170ccdfd3eb"
assert not git("staged-before",["diff","--cached","--name-only"]).strip()
for n in names:os.chmod(S/n,0o644)
sources={n:(S/n).read_bytes()for n in names};assert SHA(sources["native/durable_audit_archive_records.hepta"])=="729c1b695584bc88a36bbbde7cdb0c1069743c1b355e189e14e55b74da4b3ec0"
native=json.loads((B/"qualification/archive-records-native-artifacts-v1/files/qualification/terminal.json").read_bytes())
reference=json.loads((B/"qualification/archive-records-original-artifacts-v1/files/qualification/terminal.json").read_bytes())
assert native["state"]==reference["state"]=="PASS"and native["cases"]==3024 and native["controls"]==45 and reference["locked_registry_archives"]==360
roots=["archive-records-author-v1","archive-records-full-original-transport-v1","archive-records-original-artifacts-v1","archive-records-native-transport-v1","archive-records-native-artifacts-v1"]
selected=[(p,"qualification/"+n+"/"+p.relative_to(B/"qualification"/n).as_posix())for n in roots for p in(B/"qualification"/n).rglob("*")if p.is_file()]
selected += [(p,"drivers/"+p.name)for p in sorted(B.glob("archive-records*.py"))if p.name!="archive-records-checkpoint-v1.py"]
selected += [(S/n,"source/"+n)for n in names]
def raw(p):
 a=p.lstat();assert stat.S_ISREG(a.st_mode)and not p.is_symlink()
 with p.open("rb")as f:
  x=os.fstat(f.fileno());v=f.read();y=os.fstat(f.fileno())
 b=p.lstat();sig=lambda s:(s.st_dev,s.st_ino,s.st_mode,s.st_uid,s.st_gid,s.st_nlink,s.st_size,s.st_mtime_ns,s.st_ctime_ns)
 assert sig(a)==sig(x)==sig(y)==sig(b)
 return v,sig(a)
records={};objects={}
for p,n in selected:
 v,identity=raw(p);assert n not in records;sha=SHA(v)
 records[n]=dict(bytes=len(v),sha256=sha,mode=stat.S_IMODE(identity[2]),physical=list(identity));objects.setdefault(sha,v)
for p,n in selected:
 v,identity=raw(p);assert SHA(v)==records[n]["sha256"]and list(identity)==records[n]["physical"]
manifest=dict(schema="hepta.runtime.durable-archive-records-originals.v1",parent=head,initial_terminal_same=True,files=records,object_count=len(objects),logical_bytes=sum(r["bytes"]for r in records.values()))
manifest_raw=json.dumps(manifest,sort_keys=True,indent=2).encode()+b"\n"
archive=E/"complete-originals.tar.gz"
with tarfile.open(archive,"w:gz",compresslevel=1)as tf:
 for sha,v in sorted(objects.items()):
  t=tarfile.TarInfo("objects/"+sha);t.size=len(v);t.mode=0o444;tf.addfile(t,io.BytesIO(v))
 t=tarfile.TarInfo("manifest.json");t.size=len(manifest_raw);t.mode=0o444;tf.addfile(t,io.BytesIO(manifest_raw))
with tarfile.open(archive,"r:gz")as tf:
 members=tf.getmembers();assert{m.name for m in members}=={"manifest.json"}|{"objects/"+sha for sha in objects}
 assert tf.extractfile("manifest.json").read()==manifest_raw
 for sha,v in objects.items():assert tf.extractfile("objects/"+sha).read()==v
for n,v in sources.items():assert(S/n).read_bytes()==v
report=dict(schema="hepta.runtime.durable-archive-records-qualification.v1",scope="complete original ArchiveAnchor/ShardAnchor/InitIntent typed JSON boundary; filesystem/v12 topology/redb/public ten handlers remain separate",
 parent=head,original_commit="abc9ecb95ee9538518ec3f36c47b881974107021",original_full_graph_provenance=reference,native=native,
 source={n:dict(bytes=len(v),sha256=SHA(v))for n,v in sources.items()},
 capture=dict(file_count=len(records),unique_objects=len(objects),logical_bytes=manifest["logical_bytes"],archive_bytes=archive.stat().st_size,archive_sha256=SHA(archive.read_bytes()),manifest_sha256=SHA(manifest_raw),all_members_readback=True),
 filesystem_archive_qualified=False,public_durable_handlers_qualified=False)
(E/"qualification.json").write_text(json.dumps(report,sort_keys=True,indent=2)+"\n")
(E/"README.md").write_text("""# Original audit archive record types

The new HIA owner parses the original raw JSON bytes for ArchiveAnchor, ShardAnchor, and InitIntent. The original derives run in the complete fixed abc9ecb95ee9538518ec3f36c47b881974107021 Rust dependency graph, with unchanged Cargo lock, default features, and release profile. The ancestor 7815 checkpoint retains the complete graph provenance; this checkpoint rechecks all 360 original crate archives and all 309 registry packages used by this specific original build.

The actual gate compared 3,024 raw inputs byte for byte and ran 45 additional frame, capacity, and output-boundary controls. All passed. The original full build took 168.340821 seconds; the native module compile took 2.320117 seconds and the comparison took 2.820541 seconds. Complete inputs, stdout/stderr, original executable, compiled HIA artifacts, physical source snapshots, and transport readbacks are retained in the archive.

The typed owner preserves raw file limits of 2,048 and 65,536 bytes and the original Option/sequence behavior. It intentionally applies no 256-shard policy to the Vec type: that belongs to the separate v12 filesystem and topology admission. Unknown fields, duplicates, malformed input, integer overflow, and capacity failures retain their declared rejection domains.

This checkpoint does not qualify retained filesystem anchors, archive initialization/recovery, the redb index, or the ten public Durable Requests handlers. Those remain ongoing work. The native owner and its compiler source are HIA; the Rust executable is an independent fixed oracle, and Python scripts are qualification/authoring tools.

complete-originals.tar.gz is content-addressed. Its manifest.json maps every logical original path to exact bytes, SHA-256, mode, and captured physical identity; the archive contains every referenced complete object. Every member was reread and compared before this commit.
""")
targets=names+[p.relative_to(S).as_posix()for p in E.iterdir()if p.is_file()]
git("add",["add","-f","--",*targets]);actual=git("staged-after",["diff","--cached","--name-only"]).decode().splitlines();assert set(actual)==set(targets),(actual,targets)
git("diff-check",["diff","--cached","--check"])
message=Q/"commit-message.txt";message.write_text("Add native audit archive record types with exact full-graph qualification\n\nPreserve the original raw serde boundary for all three audit archive metadata types. Retain 3,024 complete comparisons, 45 ABI controls, and the full original source/build/native evidence. Filesystem admission and public handler integration remain separate ongoing work.\n")
git("commit",["commit","-F",str(message)])
new=git("head-after",["rev-parse","HEAD"]).decode().strip();tree=git("tree-after",["rev-parse","HEAD^{tree}"]).decode().strip();parent=git("parent-after",["rev-parse","HEAD^"]).decode().strip();assert parent==head
terminal=dict(state="PASS",head=new,tree=tree,parent=parent,paths=actual,capture=report["capture"],source_unchanged=all((S/n).read_bytes()==v for n,v in sources.items()))
(Q/"terminal.json").write_text(json.dumps(terminal,sort_keys=True,indent=2)+"\n");print(json.dumps(terminal,sort_keys=True),flush=True)
