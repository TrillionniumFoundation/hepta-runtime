# REA 6.8.0: source-only cross-tool fixture recovery

This recovered set preserves the actual Java Ghidra script, C GDB target source, Node Chrome/CDP test, HTML/XML fixtures, reference protocol manifests and small tool/version/validation records from ChatGPT Library. It deliberately excludes APK binaries, compiled executable, logs, and the very large oracle JSON responses; original ZIP identities and hashes remain in SOURCE_MANIFEST.json.

To verify: sha256sum the tar.gz against Git sidecar, extract to a new empty directory, then check each path and SHA-256 against SOURCE_MANIFEST.json. Regenerating the full P0-P5 REA program behavior requires a compatible REA 6.8.0 runtime and external Ghidra/Chrome/GDB/Android tools, not bundled here. This is not a claim of passing parity or production eligibility.
