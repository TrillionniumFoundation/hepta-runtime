// Only a Ghidra reference probe. No Rust Adapter or REA tool parity.
import ghidra.app.script.GhidraScript;
import java.nio.file.Files;
import java.nio.file.Path;
public class ReaCIInspect extends GhidraScript {
    @Override
    public void run() throws Exception {
        if (currentProgram == null) {
            throw new IllegalStateException("No analyzed program");
        }
        int functions = currentProgram.getFunctionManager().getFunctionCount();
        String format = currentProgram.getExecutableFormat();
        if (functions < 1 || format == null || !format.contains("ELF")) {
            throw new IllegalStateException("Missing real ELF analysis facts");
        }
        Path output = Path.of(getScriptArgs()[0]);
        String observation =
            "provider=Ghidra_12.2_build\n" +
            "format=" + format + "\n" +
            "functions=" + functions + "\n" +
            "name=" + currentProgram.getName() + "\n";
        Files.writeString(output, observation);
        println("REA_P3_GHIDRA_REFERENCE_COMPLETED " + functions);
    }
}
