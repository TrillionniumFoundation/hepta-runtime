#include <stdio.h>
__attribute__((noinline)) int inspect_target(int value) {
    volatile int doubled = value * 2;
    return doubled;
}
int main(void) {
    int result = inspect_target(21);
    printf("REA_GDB_RESULT=%d\n", result);
    return result == 42 ? 0 : 1;
}
