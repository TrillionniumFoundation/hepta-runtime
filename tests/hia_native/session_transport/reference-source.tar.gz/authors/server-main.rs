// Copyright 2026 Muvon Un Limited
// Copyright 2026 TrillionniumFoundation
// SPDX-License-Identifier: Apache-2.0
//! Qualification-only public SDK codec. Original dependency bytes are unchanged.
use rmcp::model::*;
use serde::Serialize;
use serde_json::{json, Value};
use std::io::{self, BufRead, Write};

const TARGET_CAP: usize = 8 * 1024 * 1024;

fn invalid(message: &str) -> Value {
	json!({"status":"INVALID_FIXTURE","error":message})
}

fn target_error(error: serde_json::Error, input_bytes: usize) -> Value {
	json!({"status":"ERROR","error":error.to_string(),"line":error.line(),
        "column":error.column(),"input_bytes":input_bytes})
}

fn payload(q: &Value, raw_key: &str, hex_key: &str) -> Result<Vec<u8>, Value> {
	match (q.get(raw_key), q.get(hex_key)) {
		(Some(Value::String(text)), None) => {
			if text.len() > TARGET_CAP {
				return Err(invalid("target input exceeds 8388608 bytes"));
			}
			Ok(text.as_bytes().to_vec())
		}
		(None, Some(Value::String(text))) => {
			if text.len() > TARGET_CAP * 2 || text.len() % 2 != 0 {
				return Err(invalid("invalid target hex length"));
			}
			let digit = |b: u8| -> Option<u8> {
				match b {
					b'0'..=b'9' => Some(b - b'0'),
					b'a'..=b'f' => Some(b - b'a' + 10),
					b'A'..=b'F' => Some(b - b'A' + 10),
					_ => None,
				}
			};
			let mut bytes = Vec::with_capacity(text.len() / 2);
			for pair in text.as_bytes().chunks_exact(2) {
				let high = digit(pair[0]).ok_or_else(|| invalid("invalid target hex digit"))?;
				let low = digit(pair[1]).ok_or_else(|| invalid("invalid target hex digit"))?;
				bytes.push(high * 16 + low);
			}
			Ok(bytes)
		}
		_ => Err(invalid("exactly one raw string or hex string is required")),
	}
}

fn serialize<T: Serialize>(value: &T, variant: &str, input_bytes: usize) -> Value {
	// These are separate actual public calls. Do not derive one from the other.
	let wire = match serde_json::to_string(value) {
		Ok(wire) => wire,
		Err(error) => {
			return json!({"status":"SERIALIZE_ERROR","operation":"to_string",
            "error":error.to_string(),"variant":variant,"input_bytes":input_bytes})
		}
	};
	let tree = match serde_json::to_value(value) {
		Ok(tree) => tree,
		Err(error) => {
			return json!({"status":"SERIALIZE_ERROR","operation":"to_value",
            "error":error.to_string(),"variant":variant,"input_bytes":input_bytes})
		}
	};
	json!({"status":"OK","variant":variant,"wire":wire,"value":tree,"input_bytes":input_bytes})
}

macro_rules! names {
    ($function:ident, $union:ident, $($variant:ident),+ $(,)?) => {
        fn $function(value: &$union) -> &'static str {
            match value {
                $($union::$variant(_) => stringify!($variant),)+
                _ => panic!("pinned SDK union gained an unlisted variant"),
            }
        }
    };
}
names!(
	server_request_name,
	ServerRequest,
	PingRequest,
	CreateMessageRequest,
	ListRootsRequest,
	ElicitRequest,
	CustomRequest
);
names!(
	server_notification_name,
	ServerNotification,
	CancelledNotification,
	ProgressNotification,
	LoggingMessageNotification,
	ResourceUpdatedNotification,
	ResourceListChangedNotification,
	ToolListChangedNotification,
	PromptListChangedNotification,
	SubscriptionsAcknowledgedNotification,
	TaskStatusNotification,
	CustomNotification
);
names!(
	server_result_name,
	ServerResult,
	DiscoverResult,
	InitializeResult,
	CompleteResult,
	GetPromptResult,
	ListPromptsResult,
	ListResourcesResult,
	ListResourceTemplatesResult,
	ReadResourceResult,
	SubscriptionsListenResult,
	ListToolsResult,
	ElicitResult,
	CreateTaskResult,
	GetTaskResult,
	CallToolResult,
	InputRequiredResult,
	TaskAckResult,
	EmptyResult,
	CustomResult
);
names!(
	client_request_name,
	ClientRequest,
	PingRequest,
	InitializeRequest,
	DiscoverRequest,
	CompleteRequest,
	SetLevelRequest,
	GetPromptRequest,
	ListPromptsRequest,
	ListResourcesRequest,
	ListResourceTemplatesRequest,
	ReadResourceRequest,
	SubscriptionsListenRequest,
	SubscribeRequest,
	UnsubscribeRequest,
	CallToolRequest,
	ListToolsRequest,
	GetTaskRequest,
	UpdateTaskRequest,
	CancelTaskRequest,
	CustomRequest
);
names!(
	client_notification_name,
	ClientNotification,
	CancelledNotification,
	ProgressNotification,
	InitializedNotification,
	RootsListChangedNotification,
	CustomNotification
);
names!(
	client_result_name,
	ClientResult,
	CreateMessageResult,
	ListRootsResult,
	ElicitResult,
	EmptyResult,
	CustomResult
);

macro_rules! selected {
    ($function:ident, $union:ident, $($variant:ident),+ $(,)?) => {
        fn $function(q: &Value, raw: &[u8]) -> Result<$union, Value> {
            match q.get("variant").and_then(Value::as_str) {
                $(Some(stringify!($variant)) =>
                    serde_json::from_slice::<$variant>(raw)
                        .map($union::$variant)
                        .map_err(|error| target_error(error, raw.len())),)+
                _ => Err(invalid("unknown or missing selected variant")),
            }
        }
    };
}
selected!(
	select_server_request,
	ServerRequest,
	PingRequest,
	CreateMessageRequest,
	ListRootsRequest,
	ElicitRequest,
	CustomRequest
);
selected!(
	select_server_notification,
	ServerNotification,
	CancelledNotification,
	ProgressNotification,
	LoggingMessageNotification,
	ResourceUpdatedNotification,
	ResourceListChangedNotification,
	ToolListChangedNotification,
	PromptListChangedNotification,
	SubscriptionsAcknowledgedNotification,
	TaskStatusNotification,
	CustomNotification
);
selected!(
	select_server_result,
	ServerResult,
	DiscoverResult,
	InitializeResult,
	CompleteResult,
	GetPromptResult,
	ListPromptsResult,
	ListResourcesResult,
	ListResourceTemplatesResult,
	ReadResourceResult,
	SubscriptionsListenResult,
	ListToolsResult,
	ElicitResult,
	CreateTaskResult,
	GetTaskResult,
	CallToolResult,
	InputRequiredResult,
	TaskAckResult,
	EmptyResult,
	CustomResult
);

fn server_message_name(message: &ServerJsonRpcMessage) -> (&'static str, &'static str) {
	match message {
		JsonRpcMessage::Request(value) => ("Request", server_request_name(&value.request)),
		JsonRpcMessage::Response(value) => ("Response", server_result_name(&value.result)),
		JsonRpcMessage::Notification(value) => (
			"Notification",
			server_notification_name(&value.notification),
		),
		JsonRpcMessage::Error(_) => ("Error", "ErrorData"),
	}
}

fn client_message_name(message: &ClientJsonRpcMessage) -> (&'static str, &'static str) {
	match message {
		JsonRpcMessage::Request(value) => ("Request", client_request_name(&value.request)),
		JsonRpcMessage::Response(value) => ("Response", client_result_name(&value.result)),
		JsonRpcMessage::Notification(value) => (
			"Notification",
			client_notification_name(&value.notification),
		),
		JsonRpcMessage::Error(_) => ("Error", "ErrorData"),
	}
}

fn server_message_reply(message: &ServerJsonRpcMessage, input_bytes: usize) -> Value {
	let (kind, variant) = server_message_name(message);
	let mut reply = serialize(message, variant, input_bytes);
	reply["kind"] = json!(kind);
	reply
}

fn client_message_reply(message: &ClientJsonRpcMessage, input_bytes: usize) -> Value {
	let (kind, variant) = client_message_name(message);
	let mut reply = serialize(message, variant, input_bytes);
	reply["kind"] = json!(kind);
	reply
}

fn legacy(q: &Value) -> Result<bool, Value> {
	match q.get("legacy") {
		None => Ok(false),
		Some(Value::Bool(value)) => Ok(*value),
		_ => Err(invalid("legacy must be a Boolean when present")),
	}
}

fn required_id(q: &Value) -> Result<RequestId, Value> {
	let raw = payload(q, "id_raw", "id_hex")?;
	serde_json::from_slice::<RequestId>(&raw).map_err(|error| {
		let mut result = target_error(error, raw.len());
		result["target"] = json!("id");
		result
	})
}

fn optional_id(q: &Value) -> Result<Option<RequestId>, Value> {
	if q.get("id_raw").is_none() && q.get("id_hex").is_none() {
		return Ok(None);
	}
	let raw = payload(q, "id_raw", "id_hex")?;
	serde_json::from_slice::<Option<RequestId>>(&raw).map_err(|error| {
		let mut result = target_error(error, raw.len());
		result["target"] = json!("id");
		result
	})
}

fn encode_message(q: &Value, raw: &[u8]) -> Result<ServerJsonRpcMessage, Value> {
	match q.get("kind").and_then(Value::as_str) {
		Some("Request") => {
			let request = select_server_request(q, raw)?;
			let id = required_id(q)?;
			Ok(ServerJsonRpcMessage::request(request, id))
		}
		Some("Response") => {
			let mut result = select_server_result(q, raw)?;
			if legacy(q)? {
				result.strip_result_type_for_legacy_peer();
			}
			let id = required_id(q)?;
			Ok(ServerJsonRpcMessage::response(result, id))
		}
		Some("Notification") => {
			let notification = select_server_notification(q, raw)?;
			Ok(ServerJsonRpcMessage::notification(notification))
		}
		Some("Error") => {
			let error = serde_json::from_slice::<ErrorData>(raw)
				.map_err(|error| target_error(error, raw.len()))?;
			let id = optional_id(q)?;
			Ok(ServerJsonRpcMessage::error(error, id))
		}
		_ => Err(invalid("unknown or missing selected message kind")),
	}
}

macro_rules! normalize {
	($raw:ident, $type:ty, $name:ident) => {
		match serde_json::from_slice::<$type>(&$raw) {
			Ok(value) => serialize(&value, $name(&value), $raw.len()),
			Err(error) => target_error(error, $raw.len()),
		}
	};
}

fn execute(q: &Value) -> Value {
	let raw = match payload(q, "raw", "hex") {
		Ok(raw) => raw,
		Err(error) => return error,
	};
	match q.get("op").and_then(Value::as_str) {
		Some("server_message_normalize") => {
			match serde_json::from_slice::<ServerJsonRpcMessage>(&raw) {
				Ok(value) => server_message_reply(&value, raw.len()),
				Err(error) => target_error(error, raw.len()),
			}
		}
		Some("client_message_normalize") => {
			match serde_json::from_slice::<ClientJsonRpcMessage>(&raw) {
				Ok(value) => client_message_reply(&value, raw.len()),
				Err(error) => target_error(error, raw.len()),
			}
		}
		Some("server_request_normalize") => normalize!(raw, ServerRequest, server_request_name),
		Some("server_notification_normalize") => {
			normalize!(raw, ServerNotification, server_notification_name)
		}
		Some("server_result_normalize") => {
			let legacy = match legacy(q) {
				Ok(value) => value,
				Err(error) => return error,
			};
			match serde_json::from_slice::<ServerResult>(&raw) {
				Ok(mut value) => {
					if legacy {
						value.strip_result_type_for_legacy_peer();
					}
					serialize(&value, server_result_name(&value), raw.len())
				}
				Err(error) => target_error(error, raw.len()),
			}
		}
		Some("client_result_normalize") => normalize!(raw, ClientResult, client_result_name),
		Some("server_request_encode") => match select_server_request(q, &raw) {
			Ok(value) => serialize(&value, server_request_name(&value), raw.len()),
			Err(error) => error,
		},
		Some("server_notification_encode") => match select_server_notification(q, &raw) {
			Ok(value) => serialize(&value, server_notification_name(&value), raw.len()),
			Err(error) => error,
		},
		Some("server_result_encode") => {
			let legacy = match legacy(q) {
				Ok(value) => value,
				Err(error) => return error,
			};
			match select_server_result(q, &raw) {
				Ok(mut value) => {
					if legacy {
						value.strip_result_type_for_legacy_peer();
					}
					serialize(&value, server_result_name(&value), raw.len())
				}
				Err(error) => error,
			}
		}
		Some("server_message_encode") => match encode_message(q, &raw) {
			Ok(value) => server_message_reply(&value, raw.len()),
			Err(error) => error,
		},
		_ => invalid("unknown or missing codec operation"),
	}
}

fn main() {
	assert_eq!(
		std::env::args().len(),
		1,
		"this observer uses only JSONL on stdin"
	);
	let stdin = io::stdin();
	let mut stdout = io::BufWriter::new(io::stdout().lock());
	for line in stdin.lock().split(b'\n') {
		let bytes = line.expect("read actual observer input");
		if bytes.is_empty() {
			continue;
		}
		let answer = match serde_json::from_slice::<Value>(&bytes) {
			Ok(Value::Object(fields)) => execute(&Value::Object(fields)),
			Ok(_) => invalid("fixture envelope must be an object"),
			Err(error) => json!({"status":"INVALID_FIXTURE","error":error.to_string()}),
		};
		serde_json::to_writer(&mut stdout, &answer).expect("write actual typed result");
		stdout.write_all(b"\n").expect("write result delimiter");
		stdout.flush().expect("flush actual result");
	}
}
