// Qualification-only append after every original local.rs byte.
// The public LocalSessionHandle::initialize implementation is unchanged.
pub mod qualification_handle_initialize {
	use super::{LocalSessionHandle, SessionError, SessionEvent};
	use crate::model::{ClientJsonRpcMessage, ServerJsonRpcMessage};
	use serde::Deserialize;
	use serde_json::{json, Value};
	use std::{
		future::{poll_fn, Future},
		io::Write,
		mem::ManuallyDrop,
		pin::Pin,
		sync::{Arc, Mutex},
		task::{Context, Poll, RawWaker, RawWakerVTable, Waker},
	};
	use tokio::sync::mpsc;

	type Reply = Result<ServerJsonRpcMessage, SessionError>;

	#[derive(Clone, Deserialize)]
	#[serde(deny_unknown_fields)]
	struct Case {
		name: String,
		client_json: String,
		server_json: String,
		scenario: String,
		channel_capacity: usize,
	}

	struct State {
		case: String,
		phase: &'static str,
		step: String,
		sequence: u64,
		rows: Vec<Value>,
		trace: Vec<Value>,
		callback_cursor: usize,
		poll_calls: u64,
		outer_polls: u64,
		base_creates: [u64; 2],
		clones: [u64; 2],
		drops: [u64; 2],
		wakes: [u64; 2],
		by_ref: [u64; 2],
	}
	#[derive(Clone)]
	struct Log(Arc<Mutex<State>>);
	impl Log {
		fn new(name: &str) -> Self {
			Self(Arc::new(Mutex::new(State {
				case: name.to_owned(),
				phase: "setup",
				step: "setup".into(),
				sequence: 0,
				rows: Vec::new(),
				trace: Vec::new(),
				callback_cursor: 0,
				poll_calls: 0,
				outer_polls: 0,
				base_creates: [0; 2],
				clones: [0; 2],
				drops: [0; 2],
				wakes: [0; 2],
				by_ref: [0; 2],
			})))
		}
		fn emit(&self, event: &str, details: Value) {
			let mut s = self.0.lock().unwrap();
			let row = json!({
				"seq": s.sequence, "event": event, "phase": s.phase,
				"step": s.step, "thread": format!("{:?}", std::thread::current().id()),
				"details": details
			});
			s.sequence += 1;
			// Each observed edge is flushed before continuing the actual operation.
			let mut out = std::io::stdout().lock();
			serde_json::to_writer(
				&mut out,
				&json!({
					"event": "trace", "case": s.case, "record": row
				}),
			)
			.unwrap();
			out.write_all(b"\n").unwrap();
			out.flush().unwrap();
			s.trace.push(row);
		}
		fn begin(&self, step: &str) {
			{
				let mut s = self.0.lock().unwrap();
				s.phase = "operation";
				s.step = step.into();
			}
			self.emit("operation_begin", Value::Null);
		}
		fn row(&self, result: Value) {
			self.emit("operation_end", result.clone());
			let mut s = self.0.lock().unwrap();
			let events: Vec<Value> = s.trace[s.callback_cursor..]
				.iter()
				.filter(|r| r["event"] == "waker" && r["phase"] != "base_cleanup")
				.map(|r| json!({"kind": r["details"]["kind"], "waker": r["details"]["waker"]}))
				.collect();
			let step = s.step.clone();
			s.rows
				.push(json!({"step": step, "result": result, "events": events}));
			s.callback_cursor = s.trace.len();
		}
		fn callback(&self, index: usize, kind: &str, address: usize) {
			{
				let mut s = self.0.lock().unwrap();
				match kind {
					"clone" => s.clones[index] += 1,
					"drop" => s.drops[index] += 1,
					"wake" => s.wakes[index] += 1,
					"wake_by_ref" => s.by_ref[index] += 1,
					_ => unreachable!(),
				};
			}
			self.emit(
				"waker",
				json!({"kind": kind, "waker": index, "raw_address": address}),
			);
		}
		fn base(&self, index: usize, forward: &Waker) -> Waker {
			self.0.lock().unwrap().base_creates[index] += 1;
			let token = Arc::new(ObservedWaker {
				log: self.clone(),
				index,
				forward: forward.clone(),
			});
			let raw = Arc::into_raw(token);
			self.emit(
				"base_create",
				json!({"waker": index, "raw_address": raw as usize}),
			);
			unsafe { Waker::from_raw(RawWaker::new(raw.cast(), &VTABLE)) }
		}
	}

	struct ObservedWaker {
		log: Log,
		index: usize,
		forward: Waker,
	}
	unsafe fn clone_waker(pointer: *const ()) -> RawWaker {
		let token = ManuallyDrop::new(unsafe { Arc::<ObservedWaker>::from_raw(pointer.cast()) });
		token.log.callback(token.index, "clone", pointer as usize);
		let cloned = Arc::clone(&token);
		RawWaker::new(Arc::into_raw(cloned).cast(), &VTABLE)
	}
	unsafe fn wake_waker(pointer: *const ()) {
		let token = unsafe { Arc::<ObservedWaker>::from_raw(pointer.cast()) };
		token.log.callback(token.index, "wake", pointer as usize);
		token.forward.wake_by_ref();
		drop(token);
	}
	unsafe fn wake_ref(pointer: *const ()) {
		let token = ManuallyDrop::new(unsafe { Arc::<ObservedWaker>::from_raw(pointer.cast()) });
		token
			.log
			.callback(token.index, "wake_by_ref", pointer as usize);
		token.forward.wake_by_ref();
	}
	unsafe fn drop_waker(pointer: *const ()) {
		let token = unsafe { Arc::<ObservedWaker>::from_raw(pointer.cast()) };
		token.log.callback(token.index, "drop", pointer as usize);
		drop(token);
	}
	static VTABLE: RawWakerVTable =
		RawWakerVTable::new(clone_waker, wake_waker, wake_ref, drop_waker);

	struct Observe<F> {
		inner: F,
		log: Log,
	}
	impl<F: Future> Future for Observe<F> {
		type Output = F::Output;
		fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
			// The field remains pinned for the lifetime of this wrapper.
			let this = unsafe { self.get_unchecked_mut() };
			this.log.0.lock().unwrap().outer_polls += 1;
			this.log.emit("outer_poll_begin", Value::Null);
			let result = unsafe { Pin::new_unchecked(&mut this.inner) }.poll(cx);
			this.log
				.emit("outer_poll_end", json!({"ready": result.is_ready()}));
			result
		}
	}
	async fn actual_poll<F: Future + ?Sized>(
		mut future: Pin<&mut F>,
		waker: &Waker,
		log: &Log,
		name: &str,
	) -> Poll<F::Output> {
		poll_fn(|cx| {
			// This is one actual channel poll inside a genuine spawned Tokio task.
			// The observer's stable RawWaker forwards wakeups to this task.
			log.0.lock().unwrap().poll_calls += 1;
			log.emit(
				"channel_poll_begin",
				json!({"operation": name, "real_context_present": true,
                "observer_is_context": waker.will_wake(cx.waker())}),
			);
			let result = future.as_mut().poll(&mut Context::from_waker(waker));
			log.emit(
				"channel_poll_end",
				json!({"operation": name, "ready": result.is_ready()}),
			);
			Poll::Ready(result)
		})
		.await
	}
	async fn receive_event(
		receiver: &mut mpsc::Receiver<SessionEvent>,
		waker: &Waker,
		log: &Log,
	) -> SessionEvent {
		let mut future = Box::pin(receiver.recv());
		let event = match actual_poll(future.as_mut(), waker, log, "mpsc_recv").await {
			Poll::Ready(Some(event)) => event,
			Poll::Ready(None) => panic!("actual event channel closed"),
			Poll::Pending => panic!("actual queued event unexpectedly pending"),
		};
		drop(future);
		event
	}

	async fn execute(case: Case, log: Log) {
		let (w0, w1) =
			poll_fn(|cx| Poll::Ready((log.base(0, cx.waker()), log.base(1, cx.waker())))).await;
		let (event_tx, mut event_rx) = mpsc::channel::<SessionEvent>(case.channel_capacity);
		let handle = LocalSessionHandle {
			id: "initialize-qualification".into(),
			event_tx,
		};
		log.begin("construct_client");
		let client: ClientJsonRpcMessage = serde_json::from_str(&case.client_json).unwrap();
		log.row(json!({"wire": serde_json::to_string(&client).unwrap()}));
		log.begin("create_future");
		let mut future = Some(Box::pin(handle.initialize(client)));
		log.row(Value::Null);
		if case.scenario == "pending_send_resume_ok_take" {
			log.begin("fill_queue");
			let mut fill = Box::pin(handle.event_tx.send(SessionEvent::Close));
			match actual_poll(fill.as_mut(), &w1, &log, "mpsc_send").await {
				Poll::Ready(Ok(())) => (),
				Poll::Ready(Err(_)) => panic!("open event queue refused filler"),
				Poll::Pending => panic!("empty event queue filler pending"),
			};
			drop(fill);
			log.row(Value::Null);
		}
		log.begin("poll_initial");
		match actual_poll(future.as_mut().unwrap().as_mut(), &w0, &log, "initialize").await {
			Poll::Pending => log.row(json!("pending")),
			Poll::Ready(_) => panic!("initialize unexpectedly ready before reply"),
		}
		if case.scenario == "pending_send_resume_ok_take" {
			log.begin("drain_filler");
			let event = receive_event(&mut event_rx, &w1, &log).await;
			assert!(matches!(event, SessionEvent::Close));
			drop(event);
			log.row(Value::Null);
			log.begin("poll_after_capacity");
			match actual_poll(future.as_mut().unwrap().as_mut(), &w0, &log, "initialize").await {
				Poll::Pending => log.row(json!("pending")),
				Poll::Ready(_) => panic!("initialize ready before responder reply"),
			}
		}
		log.begin("take_initialize_event");
		let event = receive_event(&mut event_rx, &w1, &log).await;
		let (request, responder) = match event {
			SessionEvent::InitializeRequest { request, responder } => (request, responder),
			other => panic!("unexpected actual event: {other:?}"),
		};
		log.row(json!({"wire": serde_json::to_string(&request).unwrap()}));
		log.begin("drop_client_message");
		drop(request);
		log.row(Value::Null);
		log.begin("construct_reply");
		let message: ServerJsonRpcMessage = serde_json::from_str(&case.server_json).unwrap();
		let reply: Reply = Ok(message);
		log.row(json!({"wire": serde_json::to_string(reply.as_ref().unwrap()).unwrap()}));
		if case.scenario == "cancel_before_reply" {
			log.begin("drop_future");
			drop(future.take().unwrap());
			log.row(json!({"when": "before_reply"}));
			log.begin("send_reply");
			let rejected = match responder.send(reply) {
				Err(value) => value,
				Ok(()) => panic!("dropped initialize receiver accepted reply"),
			};
			log.row(json!("closed"));
			log.begin("drop_rejected_reply");
			drop(rejected);
			log.row(Value::Null);
		} else {
			log.begin("send_reply");
			match responder.send(reply) {
				Ok(()) => (),
				Err(_) => panic!("live initialize receiver refused reply"),
			};
			log.row(json!("sent"));
			if case.scenario == "cancel_buffered_reply" {
				log.begin("drop_future");
				drop(future.take().unwrap());
				log.row(json!({"when": "buffered_reply"}));
			} else {
				log.begin("poll_reply");
				let returned =
					match actual_poll(future.as_mut().unwrap().as_mut(), &w0, &log, "initialize")
						.await
					{
						Poll::Ready(value @ Ok(_)) => value,
						Poll::Ready(Err(error)) => panic!("unexpected initialize error: {error}"),
						Poll::Pending => panic!("reply buffered but initialize pending"),
					};
				log.row(json!({"status": "ok",
                    "wire": serde_json::to_string(returned.as_ref().unwrap()).unwrap()}));
				log.begin("drop_future");
				drop(future.take().unwrap());
				log.row(json!({"when": "ready"}));
				if case.scenario == "reply_ok_drop" {
					log.begin("drop_reply_result");
					drop(returned);
					log.row(Value::Null);
				} else {
					assert!(["reply_ok_take", "pending_send_resume_ok_take"]
						.contains(&case.scenario.as_str()));
					log.begin("take_reply_result");
					let message = returned.unwrap();
					log.row(json!({"wire": serde_json::to_string(&message).unwrap()}));
					log.begin("drop_server_message");
					drop(message);
					log.row(Value::Null);
				}
			}
		}
		// The future's immutable handle borrow ends before the real channel handles.
		drop(future);
		log.begin("channel_cleanup");
		drop(handle);
		drop(event_rx);
		log.row(Value::Null);
		{
			let mut s = log.0.lock().unwrap();
			s.phase = "base_cleanup";
			s.step = "base_waker_drop".into();
		}
		log.emit("base_cleanup_begin", Value::Null);
		drop(w0);
		drop(w1);
		log.emit("base_cleanup_end", Value::Null);
	}

	pub fn run(input: &Value) -> Value {
		let case: Case = serde_json::from_value(input.clone()).expect("typed fixture input");
		assert!(!case.name.is_empty() && case.name.len() <= 256);
		assert!(case.client_json.len() <= 8 * 1024 * 1024);
		assert!(case.server_json.len() <= 8 * 1024 * 1024);
		assert!([
			"reply_ok_take",
			"reply_ok_drop",
			"cancel_before_reply",
			"cancel_buffered_reply",
			"pending_send_resume_ok_take"
		]
		.contains(&case.scenario.as_str()));
		assert_eq!(case.channel_capacity, 1);
		let log = Log::new(&case.name);
		let task_log = log.clone();
		let rt = tokio::runtime::Builder::new_current_thread()
			.enable_all()
			.build()
			.unwrap();
		rt.block_on(async move {
			tokio::spawn(Observe {
				inner: execute(case, task_log.clone()),
				log: task_log,
			})
			.await
			.unwrap();
		});
		drop(rt);
		let s = log.0.lock().unwrap();
		assert_eq!(s.outer_polls, 1);
		for i in 0..2 {
			assert_eq!(s.base_creates[i], 1);
			assert_eq!(s.base_creates[i] + s.clones[i], s.drops[i] + s.wakes[i]);
		}
		json!({
			"status": "PASS_FINITE_ACTUAL_HANDLE_INITIALIZE",
			"canonical": {"name": s.case, "rows": s.rows},
			"trace": s.trace, "actual_channel_polls": s.poll_calls,
			"actual_outer_task_polls": s.outer_polls, "base_creates": s.base_creates,
			"clones": s.clones, "drops_including_base": s.drops,
			"consuming_wakes": s.wakes, "wake_by_ref": s.by_ref,
			"real_runtime": "current_thread", "real_spawned_task": true,
			"actual_public_initialize": true, "actual_session_event_channel": true,
			"actual_typed_destructor_callbacks_observed": false,
			"whole_worker_qualified": false, "production_activated": false
		})
	}
}
