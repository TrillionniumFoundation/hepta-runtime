// Qualification-only append after every original local.rs byte.
// LocalSessionWorkerError, SessionEvent, SessionError and Tokio are unchanged.
pub mod qualification_local_worker_error {
	use super::{
		EventId, EventIdParseError, LocalSessionWorkerError, SessionError, SessionEvent,
		StreamableHttpMessageReceiver,
	};
	use crate::model::{ClientJsonRpcMessage, ServerJsonRpcMessage};
	use serde::Deserialize;
	use serde_json::{json, Value};
	use std::{
		future::{poll_fn, Future},
		io::Write,
		mem::ManuallyDrop,
		pin::Pin,
		sync::{Arc, Mutex},
		task::{Context, Poll, RawWaker, RawWakerVTable, Waker},
		time::Duration,
	};
	use tokio::sync::oneshot;
	type Reply = Result<(), LocalSessionWorkerError>;
	#[derive(Clone, Deserialize)]
	#[serde(deny_unknown_fields)]
	struct Case {
		name: String,
		label: String,
		variant: u64,
		seconds: u64,
		nanos: u32,
		route: String,
		child: Value,
	}

	struct State {
		case: String,
		phase: &'static str,
		step: String,
		sequence: u64,
		rows: Vec<Value>,
		trace: Vec<Value>,
		callback_cursor: usize,
		poll_calls: u64,
		outer_polls: u64,
		base_creates: [u64; 2],
		clones: [u64; 2],
		drops: [u64; 2],
		wakes: [u64; 2],
		by_ref: [u64; 2],
	}
	#[derive(Clone)]
	struct Log(Arc<Mutex<State>>);
	impl Log {
		fn new(name: &str) -> Self {
			Self(Arc::new(Mutex::new(State {
				case: name.to_owned(),
				phase: "setup",
				step: "setup".into(),
				sequence: 0,
				rows: Vec::new(),
				trace: Vec::new(),
				callback_cursor: 0,
				poll_calls: 0,
				outer_polls: 0,
				base_creates: [0; 2],
				clones: [0; 2],
				drops: [0; 2],
				wakes: [0; 2],
				by_ref: [0; 2],
			})))
		}
		fn emit(&self, event: &str, details: Value) {
			let mut s = self.0.lock().unwrap();
			let row = json!({
				"seq": s.sequence, "event": event, "phase": s.phase,
				"step": s.step, "thread": format!("{:?}", std::thread::current().id()),
				"details": details
			});
			s.sequence += 1;
			// Each observed edge is flushed before continuing the actual operation.
			let mut out = std::io::stdout().lock();
			serde_json::to_writer(
				&mut out,
				&json!({
					"event": "trace", "case": s.case, "record": row
				}),
			)
			.unwrap();
			out.write_all(b"\n").unwrap();
			out.flush().unwrap();
			s.trace.push(row);
		}
		fn begin(&self, step: &str) {
			{
				let mut s = self.0.lock().unwrap();
				s.phase = "operation";
				s.step = step.into();
			}
			self.emit("operation_begin", Value::Null);
		}
		fn row(&self, result: Value) {
			self.emit("operation_end", result.clone());
			let mut s = self.0.lock().unwrap();
			let events: Vec<Value> = s.trace[s.callback_cursor..]
				.iter()
				.filter(|r| r["event"] == "waker" && r["phase"] != "base_cleanup")
				.map(|r| json!({"kind": r["details"]["kind"], "waker": r["details"]["waker"]}))
				.collect();
			let step = s.step.clone();
			s.rows
				.push(json!({"step": step, "result": result, "events": events}));
			s.callback_cursor = s.trace.len();
		}
		fn callback(&self, index: usize, kind: &str, address: usize) {
			{
				let mut s = self.0.lock().unwrap();
				match kind {
					"clone" => s.clones[index] += 1,
					"drop" => s.drops[index] += 1,
					"wake" => s.wakes[index] += 1,
					"wake_by_ref" => s.by_ref[index] += 1,
					_ => unreachable!(),
				};
			}
			self.emit(
				"waker",
				json!({"kind": kind, "waker": index, "raw_address": address}),
			);
		}
		fn base(&self, index: usize, forward: &Waker) -> Waker {
			self.0.lock().unwrap().base_creates[index] += 1;
			let token = Arc::new(ObservedWaker {
				log: self.clone(),
				index,
				forward: forward.clone(),
			});
			let raw = Arc::into_raw(token);
			self.emit(
				"base_create",
				json!({"waker": index, "raw_address": raw as usize}),
			);
			unsafe { Waker::from_raw(RawWaker::new(raw.cast(), &VTABLE)) }
		}
	}

	struct ObservedWaker {
		log: Log,
		index: usize,
		forward: Waker,
	}
	unsafe fn clone_waker(pointer: *const ()) -> RawWaker {
		let token = ManuallyDrop::new(unsafe { Arc::<ObservedWaker>::from_raw(pointer.cast()) });
		token.log.callback(token.index, "clone", pointer as usize);
		let cloned = Arc::clone(&token);
		RawWaker::new(Arc::into_raw(cloned).cast(), &VTABLE)
	}
	unsafe fn wake_waker(pointer: *const ()) {
		let token = unsafe { Arc::<ObservedWaker>::from_raw(pointer.cast()) };
		token.log.callback(token.index, "wake", pointer as usize);
		token.forward.wake_by_ref();
		drop(token);
	}
	unsafe fn wake_ref(pointer: *const ()) {
		let token = ManuallyDrop::new(unsafe { Arc::<ObservedWaker>::from_raw(pointer.cast()) });
		token
			.log
			.callback(token.index, "wake_by_ref", pointer as usize);
		token.forward.wake_by_ref();
	}
	unsafe fn drop_waker(pointer: *const ()) {
		let token = unsafe { Arc::<ObservedWaker>::from_raw(pointer.cast()) };
		token.log.callback(token.index, "drop", pointer as usize);
		drop(token);
	}
	static VTABLE: RawWakerVTable =
		RawWakerVTable::new(clone_waker, wake_waker, wake_ref, drop_waker);

	struct Observe<F> {
		inner: F,
		log: Log,
	}
	impl<F: Future> Future for Observe<F> {
		type Output = F::Output;
		fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
			// The field remains pinned for the lifetime of this wrapper.
			let this = unsafe { self.get_unchecked_mut() };
			this.log.0.lock().unwrap().outer_polls += 1;
			this.log.emit("outer_poll_begin", Value::Null);
			let result = unsafe { Pin::new_unchecked(&mut this.inner) }.poll(cx);
			this.log
				.emit("outer_poll_end", json!({"ready": result.is_ready()}));
			result
		}
	}
	async fn actual_poll<F: Future + ?Sized>(
		mut future: Pin<&mut F>,
		waker: &Waker,
		log: &Log,
		name: &str,
	) -> Poll<F::Output> {
		poll_fn(|cx| {
			// This is one actual channel poll inside a genuine spawned Tokio task.
			// The observer's stable RawWaker forwards wakeups to this task.
			log.0.lock().unwrap().poll_calls += 1;
			log.emit(
				"channel_poll_begin",
				json!({"operation": name, "real_context_present": true,
                "observer_is_context": waker.will_wake(cx.waker())}),
			);
			let result = future.as_mut().poll(&mut Context::from_waker(waker));
			log.emit(
				"channel_poll_end",
				json!({"operation": name, "ready": result.is_ready()}),
			);
			Poll::Ready(result)
		})
		.await
	}
	enum EventReceiver {
		Unit(oneshot::Receiver<Result<(), SessionError>>),
		Stream(oneshot::Receiver<Result<StreamableHttpMessageReceiver, SessionError>>),
		Message(oneshot::Receiver<Result<ServerJsonRpcMessage, SessionError>>),
	}
	enum Child {
		None,
		Event(SessionEvent),
		Error(SessionError),
	}
	fn maybe_u64(value: &Value) -> Option<u64> {
		if value.is_null() {
			None
		} else {
			Some(value.as_u64().expect("u64"))
		}
	}
	fn duration(value: &Value) -> Option<Duration> {
		if value.is_null() {
			None
		} else {
			let seconds = value["seconds"].as_u64().expect("seconds");
			let nanos = value["nanos"].as_u64().expect("nanos");
			assert!(nanos < 1_000_000_000);
			Some(Duration::new(seconds, nanos as u32))
		}
	}
	fn child_error(value: &Value) -> SessionError {
		assert_eq!(value["op"], "session_error");
		match value["variant"].as_u64().expect("SessionError variant") {
			1 => SessionError::DuplicatedRequestId(value["id"].as_u64().expect("id")),
			2 => SessionError::ChannelClosed(maybe_u64(&value["id"])),
			3 => {
				assert_eq!(value["event_error"].as_u64(), Some(1));
				assert_eq!(value["parse_kind"].as_u64(), Some(2));
				let parse = "not-a-number".parse::<usize>().unwrap_err();
				assert_eq!(*parse.kind(), std::num::IntErrorKind::InvalidDigit);
				SessionError::EventIdParseError(EventIdParseError::InvalidIndex(parse))
			}
			4 => SessionError::SessionServiceTerminated,
			5 => SessionError::InvalidEventId,
			6 => {
				assert_eq!(value["io_form"], "kind");
				assert_eq!(value["io_kind"], "PermissionDenied");
				SessionError::Io(std::io::Error::from(std::io::ErrorKind::PermissionDenied))
			}
			_ => panic!("outside frozen SessionError child corpus"),
		}
	}
	fn event_view(event: &SessionEvent) -> Value {
		let (tag, http_id, index, retry, wire, responder_present) = match event {
			SessionEvent::ClientMessage {
				message,
				http_request_id,
			} => (
				1,
				*http_request_id,
				0,
				None,
				Some(serde_json::to_string(message).unwrap()),
				false,
			),
			SessionEvent::EstablishRequestWiseChannel { .. } => (2, None, 0, None, None, true),
			SessionEvent::CloseRequestWiseChannel { id, .. } => (3, Some(*id), 0, None, None, true),
			SessionEvent::Resume { last_event_id, .. } => (
				4,
				last_event_id.http_request_id,
				last_event_id.index,
				None,
				None,
				true,
			),
			SessionEvent::InitializeRequest { request, .. } => (
				5,
				None,
				0,
				None,
				Some(serde_json::to_string(request).unwrap()),
				true,
			),
			SessionEvent::Close => (6, None, 0, None, None, false),
			SessionEvent::CloseSseStream {
				http_request_id,
				retry_interval,
				..
			} => (7, *http_request_id, 0, *retry_interval, None, true),
			SessionEvent::EstablishCommonChannel { .. } => (8, None, 0, None, None, true),
		};
		json!({"type":"session_event","tag":tag,"http_request_id":http_id,
            "index":index,"retry":retry.map(|x|json!({"seconds":x.as_secs(),"nanos":x.subsec_nanos()})),
            "wire":wire,"responder_present":responder_present})
	}
	fn child_view(child: &Child) -> Value {
		match child {
			Child::None => Value::Null,
			Child::Event(event) => event_view(event),
			Child::Error(error) => json!({"type":"session_error","display":error.to_string()}),
		}
	}
	fn make_child(case: &Case) -> (Child, Option<EventReceiver>) {
		if case.child.is_null() {
			return (Child::None, None);
		}
		let value = &case.child;
		if value["kind"] == "session_error" {
			return (Child::Error(child_error(&value["value"])), None);
		}
		assert_eq!(value["kind"], "session_event");
		let tag = value["tag"].as_u64().expect("tag");
		let id = maybe_u64(&value["http_request_id"]);
		let index = usize::try_from(value["index"].as_u64().expect("index")).unwrap();
		let retry = duration(&value["retry"]);
		let message = || -> ClientJsonRpcMessage {
			serde_json::from_str(value["message_json"].as_str().expect("actual Client raw"))
				.unwrap()
		};
		let (event, receiver) = match tag {
			1 => (
				SessionEvent::ClientMessage {
					message: message(),
					http_request_id: id,
				},
				None,
			),
			2 => {
				let (responder, receiver) = oneshot::channel();
				(
					SessionEvent::EstablishRequestWiseChannel { responder },
					Some(EventReceiver::Stream(receiver)),
				)
			}
			3 => {
				let (responder, receiver) = oneshot::channel();
				(
					SessionEvent::CloseRequestWiseChannel {
						id: id.expect("id"),
						responder,
					},
					Some(EventReceiver::Unit(receiver)),
				)
			}
			4 => {
				let (responder, receiver) = oneshot::channel();
				(
					SessionEvent::Resume {
						last_event_id: EventId {
							http_request_id: id,
							index,
						},
						responder,
					},
					Some(EventReceiver::Stream(receiver)),
				)
			}
			5 => {
				let (responder, receiver) = oneshot::channel();
				(
					SessionEvent::InitializeRequest {
						request: message(),
						responder,
					},
					Some(EventReceiver::Message(receiver)),
				)
			}
			6 => (SessionEvent::Close, None),
			7 => {
				let (responder, receiver) = oneshot::channel();
				(
					SessionEvent::CloseSseStream {
						http_request_id: id,
						retry_interval: retry,
						responder,
					},
					Some(EventReceiver::Unit(receiver)),
				)
			}
			8 => {
				let (responder, receiver) = oneshot::channel();
				(
					SessionEvent::EstablishCommonChannel { responder },
					Some(EventReceiver::Stream(receiver)),
				)
			}
			_ => panic!("outside frozen SessionEvent corpus"),
		};
		(Child::Event(event), receiver)
	}
	fn make_error(case: &Case, child: Child) -> LocalSessionWorkerError {
		match (case.variant, child) {
			(1, Child::None) => LocalSessionWorkerError::TransportTerminated,
			(2, Child::Event(event)) => LocalSessionWorkerError::UnexpectedEvent(event),
			(3, Child::Error(error)) => LocalSessionWorkerError::FailToSendInitializeRequest(error),
			(4, Child::Error(error)) => LocalSessionWorkerError::FailToHandleMessage(error),
			(5, Child::None) => {
				LocalSessionWorkerError::InitTimeout(Duration::new(case.seconds, case.nanos))
			}
			(6, Child::None) => LocalSessionWorkerError::TransportClosed,
			_ => panic!("variant and actual child mismatch"),
		}
	}
	fn error_view(error: &LocalSessionWorkerError) -> Value {
		let (variant, seconds, nanos, child) = match error {
			LocalSessionWorkerError::TransportTerminated => (1, 0, 0, Value::Null),
			LocalSessionWorkerError::UnexpectedEvent(event) => (2, 0, 0, event_view(event)),
			LocalSessionWorkerError::FailToSendInitializeRequest(error) => (
				3,
				0,
				0,
				json!({"type":"session_error","display":error.to_string()}),
			),
			LocalSessionWorkerError::FailToHandleMessage(error) => (
				4,
				0,
				0,
				json!({"type":"session_error","display":error.to_string()}),
			),
			LocalSessionWorkerError::InitTimeout(duration) => {
				(5, duration.as_secs(), duration.subsec_nanos(), Value::Null)
			}
			LocalSessionWorkerError::TransportClosed => (6, 0, 0, Value::Null),
			LocalSessionWorkerError::TokioJoinError(_) => panic!("JoinError outside corpus"),
		};
		json!({"variant":variant,"seconds":seconds,"nanos":nanos,"child":child})
	}
	async fn event_poll(receiver: &mut EventReceiver, waker: &Waker, log: &Log) -> &'static str {
		macro_rules! once {
			($rx:expr) => {
				match actual_poll(Pin::new($rx), waker, log, "event_oneshot_rx").await {
					Poll::Pending => "pending",
					Poll::Ready(Err(_)) => "closed",
					Poll::Ready(Ok(_)) => panic!("Event responder unexpectedly sent a value"),
				}
			};
		}
		match receiver {
			EventReceiver::Unit(rx) => once!(rx),
			EventReceiver::Stream(rx) => once!(rx),
			EventReceiver::Message(rx) => once!(rx),
		}
	}
	async fn execute(case: Case, log: Log) {
		let (w0, w1) =
			poll_fn(|cx| Poll::Ready((log.base(0, cx.waker()), log.base(1, cx.waker())))).await;
		log.begin("construct_child");
		let (child, mut event_receiver) = make_child(&case);
		log.row(child_view(&child));
		if let Some(rx) = event_receiver.as_mut() {
			log.begin("poll_event_reply_before");
			let state = event_poll(rx, &w1, &log).await;
			assert_eq!(state, "pending");
			log.row(json!(state));
		}
		log.begin("construct_error");
		let error = make_error(&case, child);
		log.row(error_view(&error));
		if case.route == "direct_drop" {
			log.begin("drop_error");
			drop(error);
			log.row(Value::Null);
		} else {
			let (sender, receiver) = oneshot::channel::<Reply>();
			let mut receiver = Some(receiver);
			log.begin("poll_result_before");
			match actual_poll(
				Pin::new(receiver.as_mut().unwrap()),
				&w0,
				&log,
				"result_oneshot_rx",
			)
			.await
			{
				Poll::Pending => log.row(json!("pending")),
				Poll::Ready(_) => panic!("fresh WorkerResult receiver ready"),
			}
			if case.route == "closed_send" {
				log.begin("drop_result_rx_before");
				drop(receiver.take().unwrap());
				log.row(Value::Null);
			}
			log.begin("construct_result");
			let result: Reply = Err(error);
			log.row(json!({"status":"error"}));
			log.begin("send_result");
			let rejected = match sender.send(result) {
				Ok(()) => {
					log.row(json!("sent"));
					None
				}
				Err(value) => {
					log.row(json!("closed"));
					Some(value)
				}
			};
			if let Some(value) = rejected {
				assert_eq!(case.route, "closed_send");
				log.begin("drop_rejected_result");
				drop(value);
				log.row(Value::Null);
			} else if case.route == "buffered_cancel" {
				log.begin("drop_buffered_result_rx");
				drop(receiver.take().unwrap());
				log.row(Value::Null);
			} else {
				assert!(["reply_drop", "reply_take"].contains(&case.route.as_str()));
				log.begin("poll_result_after");
				let result = match actual_poll(
					Pin::new(receiver.as_mut().unwrap()),
					&w0,
					&log,
					"result_oneshot_rx",
				)
				.await
				{
					Poll::Ready(Ok(value @ Err(_))) => value,
					Poll::Ready(Ok(Ok(()))) => panic!("actual WorkerResult unexpectedly Ok"),
					Poll::Ready(Err(_)) => {
						panic!("actual WorkerResult sender closed without value")
					}
					Poll::Pending => panic!("buffered actual WorkerResult pending"),
				};
				log.row(json!({"status":"error","error":error_view(result.as_ref().unwrap_err())}));
				if case.route == "reply_take" {
					log.begin("take_result");
					let error = result.unwrap_err();
					log.row(json!({"error":error_view(&error)}));
					log.begin("drop_error");
					drop(error);
					log.row(Value::Null);
				} else {
					log.begin("drop_result");
					drop(result);
					log.row(Value::Null);
				}
				log.begin("drop_result_rx_after");
				drop(receiver.take().unwrap());
				log.row(Value::Null);
			}
			assert!(receiver.is_none());
		}
		if let Some(mut receiver) = event_receiver.take() {
			log.begin("poll_event_reply_after");
			let state = event_poll(&mut receiver, &w1, &log).await;
			assert_eq!(state, "closed");
			log.row(json!(state));
			log.begin("drop_event_reply_after");
			drop(receiver);
			log.row(Value::Null);
		}
		{
			let mut s = log.0.lock().unwrap();
			s.phase = "base_cleanup";
			s.step = "base_waker_drop".into();
		}
		log.emit("base_cleanup_begin", Value::Null);
		drop(w0);
		drop(w1);
		log.emit("base_cleanup_end", Value::Null);
	}
	pub fn run(input: &Value) -> Value {
		let case: Case = serde_json::from_value(input.clone()).expect("typed fixture input");
		assert!(!case.name.is_empty() && case.name.len() <= 256 && !case.label.is_empty());
		assert!(case.nanos < 1_000_000_000 && (1..=6).contains(&case.variant));
		assert!([
			"direct_drop",
			"reply_drop",
			"reply_take",
			"closed_send",
			"buffered_cancel"
		]
		.contains(&case.route.as_str()));
		let log = Log::new(&case.name);
		let task_log = log.clone();
		let rt = tokio::runtime::Builder::new_current_thread()
			.enable_all()
			.build()
			.unwrap();
		rt.block_on(async move {
			tokio::spawn(Observe {
				inner: execute(case, task_log.clone()),
				log: task_log,
			})
			.await
			.unwrap();
		});
		drop(rt);
		let s = log.0.lock().unwrap();
		assert_eq!(s.outer_polls, 1);
		for i in 0..2 {
			assert_eq!(s.base_creates[i], 1);
			assert_eq!(s.base_creates[i] + s.clones[i], s.drops[i] + s.wakes[i]);
		}
		json!({"status":"PASS_FINITE_ACTUAL_LOCAL_WORKER_ERROR",
            "canonical":{"name":s.case,"rows":s.rows},"trace":s.trace,
            "actual_channel_polls":s.poll_calls,"actual_outer_task_polls":s.outer_polls,
            "base_creates":s.base_creates,"clones":s.clones,"drops_including_base":s.drops,
            "consuming_wakes":s.wakes,"wake_by_ref":s.by_ref,
            "real_runtime":"current_thread","real_spawned_task":true,
            "actual_typed_destructor_callbacks_observed":false,
            "local_worker_error_formatting_qualified":false,"join_error_qualified":false,
            "whole_worker_qualified":false,"production_activated":false})
	}
}
