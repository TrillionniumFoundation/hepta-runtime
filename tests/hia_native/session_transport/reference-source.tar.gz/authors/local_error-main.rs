// Copyright 2026 Muvon Un Limited
// Copyright 2026 TrillionniumFoundation
// SPDX-License-Identifier: Apache-2.0
// Qualification driver only; the actual WorkerResult Err and ownership operations run in the real rmcp module.
use std::io::{self, BufRead, Write};
fn main() {
	let stdin = io::stdin();
	for line in stdin.lock().lines() {
		let line = line.expect("input line");
		if line.is_empty() {
			continue;
		}
		let input: serde_json::Value = serde_json::from_str(&line).expect("fixture JSON");
		let output = rmcp::transport::streamable_http_server::session::local::qualification_local_worker_error::run(&input);
		let mut stdout = io::stdout().lock();
		serde_json::to_writer(
			&mut stdout,
			&serde_json::json!({
				"event": "result", "case": input["name"], "value": output
			}),
		)
		.unwrap();
		stdout.write_all(b"\n").unwrap();
		stdout.flush().unwrap();
	}
}
