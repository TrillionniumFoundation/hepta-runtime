// Qualification-only observer appended after all original worker.rs bytes.
// Original Worker/WorkerSendRequest/WorkerTransport implementations are unchanged.
pub mod qualification_worker_owners {
	use super::{Worker, WorkerSendRequest};
	use crate::model::ServerJsonRpcMessage;
	use crate::transport::streamable_http_server::session::local::{
		LocalSessionWorker, LocalSessionWorkerError,
	};
	use serde::Deserialize;
	use serde_json::{json, Value};
	use std::{
		future::{poll_fn, Future},
		io::Write,
		mem::ManuallyDrop,
		pin::Pin,
		sync::{Arc, Mutex},
		task::{Context, Poll, RawWaker, RawWakerVTable, Waker},
	};
	use tokio::sync::{mpsc, oneshot};

	type Request = WorkerSendRequest<LocalSessionWorker>;
	type Reply = Result<(), LocalSessionWorkerError>;

	#[derive(Clone, Deserialize)]
	#[serde(deny_unknown_fields)]
	struct Case {
		name: String,
		message_json: String,
		control_generation: u64,
		route: String,
		finish: String,
		receiver: String,
		poll_receiver: bool,
		poll_queue: bool,
		result_finish: String,
		channel_capacity: usize,
	}

	struct State {
		case: String,
		phase: &'static str,
		step: String,
		sequence: u64,
		rows: Vec<Value>,
		trace: Vec<Value>,
		callback_cursor: usize,
		poll_calls: u64,
		outer_polls: u64,
		base_creates: [u64; 2],
		clones: [u64; 2],
		drops: [u64; 2],
		wakes: [u64; 2],
		by_ref: [u64; 2],
	}
	#[derive(Clone)]
	struct Log(Arc<Mutex<State>>);
	impl Log {
		fn new(name: &str) -> Self {
			Self(Arc::new(Mutex::new(State {
				case: name.to_owned(),
				phase: "setup",
				step: "setup".into(),
				sequence: 0,
				rows: Vec::new(),
				trace: Vec::new(),
				callback_cursor: 0,
				poll_calls: 0,
				outer_polls: 0,
				base_creates: [0; 2],
				clones: [0; 2],
				drops: [0; 2],
				wakes: [0; 2],
				by_ref: [0; 2],
			})))
		}
		fn emit(&self, event: &str, details: Value) {
			let mut s = self.0.lock().unwrap();
			let row = json!({
				"seq": s.sequence, "event": event, "phase": s.phase,
				"step": s.step, "thread": format!("{:?}", std::thread::current().id()),
				"details": details
			});
			s.sequence += 1;
			// Each observed edge is flushed before continuing the actual operation.
			let mut out = std::io::stdout().lock();
			serde_json::to_writer(
				&mut out,
				&json!({
					"event": "trace", "case": s.case, "record": row
				}),
			)
			.unwrap();
			out.write_all(b"\n").unwrap();
			out.flush().unwrap();
			s.trace.push(row);
		}
		fn begin(&self, step: &str) {
			{
				let mut s = self.0.lock().unwrap();
				s.phase = "operation";
				s.step = step.into();
			}
			self.emit("operation_begin", Value::Null);
		}
		fn row(&self, result: Value) {
			self.emit("operation_end", result.clone());
			let mut s = self.0.lock().unwrap();
			let events: Vec<Value> = s.trace[s.callback_cursor..]
				.iter()
				.filter(|r| r["event"] == "waker" && r["phase"] != "base_cleanup")
				.map(|r| json!({"kind": r["details"]["kind"], "waker": r["details"]["waker"]}))
				.collect();
			let step = s.step.clone();
			s.rows
				.push(json!({"step": step, "result": result, "events": events}));
			s.callback_cursor = s.trace.len();
		}
		fn callback(&self, index: usize, kind: &str, address: usize) {
			{
				let mut s = self.0.lock().unwrap();
				match kind {
					"clone" => s.clones[index] += 1,
					"drop" => s.drops[index] += 1,
					"wake" => s.wakes[index] += 1,
					"wake_by_ref" => s.by_ref[index] += 1,
					_ => unreachable!(),
				};
			}
			self.emit(
				"waker",
				json!({"kind": kind, "waker": index, "raw_address": address}),
			);
		}
		fn base(&self, index: usize, forward: &Waker) -> Waker {
			self.0.lock().unwrap().base_creates[index] += 1;
			let token = Arc::new(ObservedWaker {
				log: self.clone(),
				index,
				forward: forward.clone(),
			});
			let raw = Arc::into_raw(token);
			self.emit(
				"base_create",
				json!({"waker": index, "raw_address": raw as usize}),
			);
			unsafe { Waker::from_raw(RawWaker::new(raw.cast(), &VTABLE)) }
		}
	}

	struct ObservedWaker {
		log: Log,
		index: usize,
		forward: Waker,
	}
	unsafe fn clone_waker(pointer: *const ()) -> RawWaker {
		let token = ManuallyDrop::new(unsafe { Arc::<ObservedWaker>::from_raw(pointer.cast()) });
		token.log.callback(token.index, "clone", pointer as usize);
		let cloned = Arc::clone(&token);
		RawWaker::new(Arc::into_raw(cloned).cast(), &VTABLE)
	}
	unsafe fn wake_waker(pointer: *const ()) {
		let token = unsafe { Arc::<ObservedWaker>::from_raw(pointer.cast()) };
		token.log.callback(token.index, "wake", pointer as usize);
		token.forward.wake_by_ref();
		drop(token);
	}
	unsafe fn wake_ref(pointer: *const ()) {
		let token = ManuallyDrop::new(unsafe { Arc::<ObservedWaker>::from_raw(pointer.cast()) });
		token
			.log
			.callback(token.index, "wake_by_ref", pointer as usize);
		token.forward.wake_by_ref();
	}
	unsafe fn drop_waker(pointer: *const ()) {
		let token = unsafe { Arc::<ObservedWaker>::from_raw(pointer.cast()) };
		token.log.callback(token.index, "drop", pointer as usize);
		drop(token);
	}
	static VTABLE: RawWakerVTable =
		RawWakerVTable::new(clone_waker, wake_waker, wake_ref, drop_waker);

	struct Observe<F> {
		inner: F,
		log: Log,
	}
	impl<F: Future> Future for Observe<F> {
		type Output = F::Output;
		fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
			// The field remains pinned for the lifetime of this wrapper.
			let this = unsafe { self.get_unchecked_mut() };
			this.log.0.lock().unwrap().outer_polls += 1;
			this.log.emit("outer_poll_begin", Value::Null);
			let result = unsafe { Pin::new_unchecked(&mut this.inner) }.poll(cx);
			this.log
				.emit("outer_poll_end", json!({"ready": result.is_ready()}));
			result
		}
	}
	async fn actual_poll<F: Future + ?Sized>(
		mut future: Pin<&mut F>,
		waker: &Waker,
		log: &Log,
		name: &str,
	) -> Poll<F::Output> {
		poll_fn(|cx| {
			// This is one actual channel poll inside a genuine spawned Tokio task.
			// The observer's stable RawWaker forwards wakeups to this task.
			log.0.lock().unwrap().poll_calls += 1;
			log.emit(
				"channel_poll_begin",
				json!({"operation": name, "real_context_present": true,
                "observer_is_context": waker.will_wake(cx.waker())}),
			);
			let result = future.as_mut().poll(&mut Context::from_waker(waker));
			log.emit(
				"channel_poll_end",
				json!({"operation": name, "ready": result.is_ready()}),
			);
			Poll::Ready(result)
		})
		.await
	}
	fn fields(request: &Request) -> Value {
		json!({
			"control_generation": request.control_generation(),
			"cancellation_none": request.cancellation_token().is_none(),
			"wire": serde_json::to_string(&request.message).unwrap()
		})
	}

	async fn execute(case: Case, log: Log) {
		let (w0, w1) =
			poll_fn(|cx| Poll::Ready((log.base(0, cx.waker()), log.base(1, cx.waker())))).await;
		assert!(!<LocalSessionWorker as Worker>::supports_request_cancellation());
		log.begin("construct");
		let message: ServerJsonRpcMessage = serde_json::from_str(&case.message_json).unwrap();
		let (responder, receiver) = oneshot::channel::<Reply>();
		let mut reply_rx = Some(receiver);
		let mut request = Some(Request {
			message,
			responder,
			cancellation: None,
			control_generation: case.control_generation,
		});
		log.row(fields(request.as_ref().unwrap()));
		if case.receiver == "closed" {
			log.begin("reply_drop_before");
			drop(reply_rx.take().unwrap());
			log.row(Value::Null);
		} else if case.poll_receiver {
			log.begin("reply_poll_before");
			match actual_poll(
				Pin::new(reply_rx.as_mut().unwrap()),
				&w0,
				&log,
				"oneshot_rx",
			)
			.await
			{
				Poll::Pending => log.row(json!("pending")),
				Poll::Ready(value) => panic!("pre-send receiver unexpectedly ready: {value:?}"),
			}
		}
		let mut queue_tx = None;
		let mut queue_rx = None;
		if case.route != "direct" {
			let (tx, mut rx) = mpsc::channel::<Request>(case.channel_capacity);
			if case.route == "mpsc_closed" {
				log.begin("queue_close_before");
				drop(rx);
				log.row(Value::Null);
				log.begin("send_queue");
				let mut send = Box::pin(tx.send(request.take().unwrap()));
				let returned = match actual_poll(send.as_mut(), &w1, &log, "mpsc_send").await {
					Poll::Ready(Err(error)) => error.0,
					Poll::Ready(Ok(())) => panic!("closed queue accepted request"),
					Poll::Pending => panic!("closed queue send pending"),
				};
				drop(send);
				request = Some(returned);
				log.row(json!("closed"));
			} else if case.route == "mpsc" {
				let mut recv = Box::pin(rx.recv());
				if case.poll_queue {
					log.begin("queue_poll_before");
					match actual_poll(recv.as_mut(), &w1, &log, "mpsc_recv").await {
						Poll::Pending => log.row(json!("pending")),
						Poll::Ready(_) => panic!("empty queue receiver unexpectedly ready"),
					}
				}
				log.begin("send_queue");
				let mut send = Box::pin(tx.send(request.take().unwrap()));
				match actual_poll(send.as_mut(), &w1, &log, "mpsc_send").await {
					Poll::Ready(Ok(())) => (),
					Poll::Ready(Err(_)) => panic!("open queue refused request"),
					Poll::Pending => panic!("non-full queue send pending"),
				};
				drop(send);
				log.row(json!("sent"));
				log.begin("take_queue");
				request = match actual_poll(recv.as_mut(), &w1, &log, "mpsc_recv").await {
					Poll::Ready(Some(value)) => Some(value),
					Poll::Ready(None) => panic!("open queued receiver closed"),
					Poll::Pending => panic!("queued receiver pending"),
				};
				drop(recv);
				log.row(json!("request"));
				queue_rx = Some(rx);
			} else {
				assert_eq!(case.route, "mpsc_drain");
				log.begin("send_queue");
				let mut send = Box::pin(tx.send(request.take().unwrap()));
				match actual_poll(send.as_mut(), &w1, &log, "mpsc_send").await {
					Poll::Ready(Ok(())) => (),
					Poll::Ready(Err(_)) => panic!("open queue refused request"),
					Poll::Pending => panic!("non-full queue send pending"),
				};
				drop(send);
				log.row(json!("sent"));
				log.begin("drop_queue_rx");
				drop(rx);
				log.row(Value::Null);
			}
			queue_tx = Some(tx);
		}
		if let Some(value) = request.take() {
			if case.finish == "drop" {
				log.begin("drop_request");
				drop(value);
				log.row(Value::Null);
			} else {
				assert_eq!(case.finish, "take_ok");
				log.begin("take_request");
				let before = fields(&value);
				let WorkerSendRequest {
					message,
					responder,
					cancellation,
					control_generation,
				} = value;
				assert!(cancellation.is_none());
				let after = json!({"control_generation": control_generation,
                    "cancellation_none": cancellation.is_none(),
                    "wire": serde_json::to_string(&message).unwrap()});
				assert_eq!(before, after);
				log.row(after);
				drop(cancellation);
				log.begin("drop_message");
				drop(message);
				log.row(Value::Null);
				log.begin("send_reply");
				let sent = match responder.send(Ok(())) {
					Ok(()) => "sent",
					Err(value) => {
						drop(value);
						"closed"
					}
				};
				log.row(json!(sent));
			}
		}
		if let Some(mut rx) = reply_rx.take() {
			log.begin("reply_poll_after");
			let value = match actual_poll(Pin::new(&mut rx), &w0, &log, "oneshot_rx").await {
				Poll::Ready(Ok(value)) => {
					log.row(json!("ok"));
					Some(value)
				}
				Poll::Ready(Err(_)) => {
					log.row(json!("closed"));
					None
				}
				Poll::Pending => panic!("settled responder still pending"),
			};
			if let Some(value) = value {
				if case.result_finish == "take" {
					log.begin("take_reply_value");
					match value {
						Ok(()) => (),
						Err(error) => panic!("unexpected error: {error}"),
					}
				} else {
					assert_eq!(case.result_finish, "drop");
					log.begin("drop_reply_value");
					drop(value);
				}
				log.row(Value::Null);
			}
			log.begin("reply_drop_after");
			drop(rx);
			log.row(Value::Null);
		}
		if let Some(tx) = queue_tx {
			log.begin("queue_cleanup");
			drop(tx);
			drop(queue_rx.take());
			log.row(Value::Null);
		}
		{
			let mut s = log.0.lock().unwrap();
			s.phase = "base_cleanup";
			s.step = "base_waker_drop".into();
		}
		log.emit("base_cleanup_begin", Value::Null);
		drop(w0);
		drop(w1);
		log.emit("base_cleanup_end", Value::Null);
	}

	pub fn run(input: &Value) -> Value {
		let case: Case = serde_json::from_value(input.clone()).expect("typed fixture input");
		assert!(!case.name.is_empty() && case.name.len() <= 256);
		assert!(case.message_json.len() <= 8 * 1024 * 1024);
		assert!(["direct", "mpsc", "mpsc_closed", "mpsc_drain"].contains(&case.route.as_str()));
		assert!(["drop", "take_ok"].contains(&case.finish.as_str()));
		assert!(["open", "closed"].contains(&case.receiver.as_str()));
		assert!(["take", "drop"].contains(&case.result_finish.as_str()));
		assert!((1..=16).contains(&case.channel_capacity));
		assert!(!case.poll_queue || case.route == "mpsc");
		assert!(!case.poll_receiver || case.receiver == "open");
		let log = Log::new(&case.name);
		let task_log = log.clone();
		let rt = tokio::runtime::Builder::new_current_thread()
			.enable_all()
			.build()
			.unwrap();
		rt.block_on(async move {
			tokio::spawn(Observe {
				inner: execute(case, task_log.clone()),
				log: task_log,
			})
			.await
			.unwrap();
		});
		drop(rt);
		let s = log.0.lock().unwrap();
		assert_eq!(s.outer_polls, 1);
		for i in 0..2 {
			assert_eq!(s.base_creates[i], 1);
			assert_eq!(s.base_creates[i] + s.clones[i], s.drops[i] + s.wakes[i]);
		}
		json!({
			"status": "PASS_FINITE_ACTUAL_WORKER_OWNERS",
			"canonical": {"name": s.case, "rows": s.rows},
			"trace": s.trace, "actual_channel_polls": s.poll_calls,
			"actual_outer_task_polls": s.outer_polls, "base_creates": s.base_creates,
			"clones": s.clones, "drops_including_base": s.drops,
			"consuming_wakes": s.wakes, "wake_by_ref": s.by_ref,
			"real_runtime": "current_thread", "real_spawned_task": true,
			"actual_local_worker_supports_cancellation": false,
			"registration_some_qualified": false, "complete_worker_qualified": false
		})
	}
}
