// Copyright 2026 Muvon Un Limited
// Copyright 2026 TrillionniumFoundation
// SPDX-License-Identifier: Apache-2.0
//! Framed qualification transport for the exact original private HTTP helper.
use std::io::{self, Read, Write};

#[tokio::main(flavor = "current_thread")]
async fn main() -> Result<(), Box<dyn std::error::Error>> {
	let mut input = io::stdin().lock();
	let mut output = io::stdout().lock();
	loop {
		let mut size = [0u8; 8];
		let first = input.read(&mut size[..1])?;
		if first == 0 {
			break;
		}
		input.read_exact(&mut size[1..])?;
		let count = usize::try_from(u64::from_le_bytes(size))?;
		if count > 8 * 1024 * 1024 {
			return Err("qualification frame exceeds 8 MiB".into());
		}
		let mut frame = vec![0; count];
		input.read_exact(&mut frame)?;
		let (code, response) =
			rmcp::transport::streamable_http_server::tower::hia_http_ingress_original_v1(&frame)
				.await;
		output.write_all(&u64::from(code).to_le_bytes())?;
		output.write_all(&(response.len() as u64).to_le_bytes())?;
		output.write_all(&response)?;
		output.flush()?;
	}
	Ok(())
}
