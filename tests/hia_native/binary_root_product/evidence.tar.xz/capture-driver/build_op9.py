from pathlib import Path
import json,shutil,sys,time
sys.dont_write_bytecode=True
work=Path(__file__).resolve().parent
source=work/'op9-candidate'
retained=work/'public124-retained/capture/default-build'
hepta=work/'retained-compiler/compiler-source'
sys.path.insert(0,str(source/'scripts'))
from public_nine_build import build_runtime_mcp,source_check
model=json.loads((retained/'build/public-task-batch-extract/manifest.json').read_bytes())
oldroot=Path(model['build_root'])
reuse={r['name']:str(retained/'build'/Path(r['manifest']).relative_to(oldroot)) for r in model['members'] if r['name']!='owner'}
output=work/'op9-build-public'
assert not output.exists()
shutil.copytree(retained/'build/bootstrap',output/'bootstrap')
started=time.monotonic()
manifest=build_runtime_mcp(hepta,output,name='binary-root-product',source_root=source,manifests=reuse,
 bellman_port_build=retained/'port/build-v3',bellman_port_package=source/'runtime_support/bellman_port',bellman_worker_build=retained/'worker')
print(json.dumps({'stage':'public','manifest':str(manifest),'elapsed_seconds':time.monotonic()-started}),flush=True)
public=json.loads(manifest.read_bytes())
reuse={r['name']:r['manifest'] for r in public['members']}
fixtureout=work/'op9-build-fixture'
assert not fixtureout.exists()
shutil.copytree(retained/'build/bootstrap',fixtureout/'bootstrap')
manifest=build_runtime_mcp(hepta,fixtureout,name='binary-root-fixture',source_root=source,manifests=reuse,private_fixture=True,
 bellman_port_build=retained/'port/build-v3',bellman_port_package=source/'runtime_support/bellman_port',bellman_worker_build=retained/'worker')
print(json.dumps({'stage':'fixture','manifest':str(manifest),'elapsed_seconds':time.monotonic()-started}),flush=True)
