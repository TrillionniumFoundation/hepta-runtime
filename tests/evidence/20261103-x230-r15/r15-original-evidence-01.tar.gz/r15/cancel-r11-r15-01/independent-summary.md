# Native cancellation-load responsiveness

finite native MCP wrong-host rejection workload; not successful remote cancellation throughput. Two runs per arm/case; no statistical-significance claim.

| Workers | Receipt bytes | host_list p50 ms A → B | host_list p95 ms A → B | p95 change | CPU ms / mixed RPC A → B | VmHWM KiB median A → B |
|---:|---:|---:|---:|---:|---:|---:|
| 1 | 1024 | 13.967 → 13.225 | 18.173 → 19.496 | +7.28% | 1.782 → 1.829 | 14070.0 → 13964.0 |
| 1 | 4194272 | 196.256 → 13.487 | 213.215 → 17.314 | -91.88% | 23.356 → 25.972 | 22044.0 → 29280.0 |
| 2 | 1024 | 15.991 → 15.926 | 18.758 → 17.065 | -9.03% | 1.852 → 1.921 | 15374.0 → 14980.0 |
| 2 | 4194272 | 106.604 → 14.158 | 123.100 → 21.798 | -82.29% | 25.023 → 26.736 | 34248.0 → 30712.0 |

Validated 3456 measured and 288 warmup replies across 16 controller generations.

Limitations:

- two independent controller runs per arm/case.
- no statistical significance claim.
- host_list includes ordinary audit and result-retention costs.
- warm receipt cache after two mixed waves.
- whole-child VmHWM includes startup/warmup and is not incremental request memory.
- clock endpoints were not retained; recorded timing deltas cannot be independently re-created.
- all negative directional results retained.
