# Native cancellation-load responsiveness

finite native MCP wrong-host rejection workload; not successful remote cancellation throughput. Two runs per arm/case; no statistical-significance claim.

| Workers | Receipt bytes | host_list p50 ms A → B | host_list p95 ms A → B | p95 change | CPU ms / mixed RPC A → B | VmHWM KiB median A → B |
|---:|---:|---:|---:|---:|---:|---:|
| 1 | 1024 | 13.047 → 14.160 | 17.883 → 18.420 | +3.00% | 1.782 → 1.898 | 14438.0 → 13690.0 |
| 1 | 4194272 | 13.139 → 13.610 | 20.350 → 27.644 | +35.84% | 25.880 → 25.394 | 106338.0 → 29070.0 |
| 2 | 1024 | 15.617 → 15.740 | 20.406 → 17.132 | -16.05% | 1.875 → 1.852 | 15450.0 → 15014.0 |
| 2 | 4194272 | 13.723 → 14.050 | 17.382 → 21.246 | +22.23% | 25.856 → 26.528 | 102650.0 → 30720.0 |

Validated 3456 measured and 288 warmup replies across 16 controller generations.

Limitations:

- two independent controller runs per arm/case.
- no statistical significance claim.
- host_list includes ordinary audit and result-retention costs.
- warm receipt cache after two mixed waves.
- whole-child VmHWM includes startup/warmup and is not incremental request memory.
- clock endpoints were not retained; recorded timing deltas cannot be independently re-created.
- all negative directional results retained.
