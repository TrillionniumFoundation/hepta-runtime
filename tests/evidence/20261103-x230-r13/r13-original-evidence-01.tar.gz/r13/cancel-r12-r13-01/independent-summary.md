# Native cancellation-load responsiveness

finite native MCP wrong-host rejection workload; not successful remote cancellation throughput. Two runs per arm/case; no statistical-significance claim.

| Workers | Receipt bytes | host_list p50 ms A → B | host_list p95 ms A → B | p95 change | CPU ms / mixed RPC A → B | VmHWM KiB median A → B |
|---:|---:|---:|---:|---:|---:|---:|
| 1 | 1024 | 14.242 → 13.738 | 18.297 → 19.036 | +4.04% | 1.736 → 1.759 | 14388.0 → 14340.0 |
| 1 | 4194272 | 28.636 → 29.171 | 39.919 → 43.858 | +9.87% | 37.431 → 36.181 | 132020.0 → 120062.0 |
| 2 | 1024 | 16.674 → 16.868 | 21.628 → 21.970 | +1.58% | 1.898 → 1.944 | 15510.0 → 15552.0 |
| 2 | 4194272 | 33.825 → 31.912 | 51.747 → 55.291 | +6.85% | 37.731 → 35.972 | 136948.0 → 128842.0 |

Validated 3456 measured and 288 warmup replies across 16 controller generations.

Limitations:

- two independent controller runs per arm/case.
- no statistical significance claim.
- host_list includes ordinary audit and result-retention costs.
- warm receipt cache after two mixed waves.
- whole-child VmHWM includes startup/warmup and is not incremental request memory.
- clock endpoints were not retained; recorded timing deltas cannot be independently re-created.
- all negative directional results retained.
