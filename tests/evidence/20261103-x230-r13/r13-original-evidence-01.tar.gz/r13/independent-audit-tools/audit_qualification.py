#!/usr/bin/env python3
# Copyright 2026 TrillionniumFoundation
# SPDX-License-Identifier: Apache-2.0
"""Independently verify frozen R13 qualification evidence without running tests."""
import collections, datetime, hashlib, json, os
from pathlib import Path
ROOT=Path("/home/qian/hepta-runtime-optimization-20261103-r13")
QUAL=ROOT/"qualification-03"
SOURCE=ROOT/"source"
def need(value, message):
    if not value: raise RuntimeError(message)
def sha(path):
    with Path(path).open("rb") as stream:
        before=os.fstat(stream.fileno())
        digest=hashlib.file_digest(stream,"sha256").hexdigest()
        after=os.fstat(stream.fileno())
    current=Path(path).stat()
    identity=lambda s:(s.st_dev,s.st_ino,s.st_size,s.st_mtime_ns,s.st_ctime_ns)
    need(identity(before)==identity(after)==identity(current),"file changed while hashing: "+str(path))
    return digest
def source_map():
    files=[SOURCE/name for name in ("Cargo.toml","Cargo.lock","rustfmt.toml")]
    for name in ("src","examples"): files.extend(p for p in (SOURCE/name).rglob("*") if p.is_file())
    return {str(p.relative_to(SOURCE)):sha(p) for p in sorted(files)}
q=json.loads((QUAL/"report.json").read_text())
s=json.loads((QUAL/"isolated-tests/summary.json").read_text())
need(q.get("qualified") is True and q.get("finished_utc") and not q.get("error"),"qualification not successful")
need(all(stage.get("returncode")==0 for stage in q["stages"]),"failed qualification stage")
current=source_map()
need(len(current)==219 and current==q["source_tested"]==q["source_after"],"qualified source maps differ")
need(current["src/mcp/runtime/jobs.rs"]=="ac36fbd969b526a6385652d0f6779fc67ed1250ac889ff5a3a48a2451cd948d9","corrected source differs")
expected={"passed":1636,"failed":0,"ignored":33,"selected":1669,"retries":0}
need({key:s.get(key) for key in expected}==expected,"test counts/retries differ")
need(s.get("success") is True and s.get("enumeration_errors")==[],"test enumeration or success differs")
need(set(q["binaries"])=={"hepta-runtime","hepta-runtime-jobctl","native_process_driver"},"release binary set differs")
binaries={}
for name,binding in q["binaries"].items():
    actual=sha(binding["path"])
    need(actual==binding["sha256"],"release binary differs: "+name)
    binaries[name]={"path":binding["path"],"sha256":actual,"size":Path(binding["path"]).stat().st_size}
libs=[v for v in s["binaries"] if v["target"]["name"]=="hepta_runtime" and v["target"]["kind"]==["lib"]]
need(len(libs)==1,"retained libtest not unique")
lib=libs[0]
lib_sha=sha(lib["path"])
need(lib_sha==lib["sha256"]=="9751bb413ec9ed05566fb4dc5d724c93794edb2bfe2a04f2ece02ca04c5d9909","retained libtest differs")
print(json.dumps({"priority_identity_verified":True,"runtime_sha256":binaries["hepta-runtime"]["sha256"],"tests":expected,"source_inputs":219,"libtest_sha256":lib_sha}),flush=True)
rows=[json.loads(line) for line in (QUAL/"isolated-tests/tests.jsonl").read_text().splitlines() if line]
counts=dict(collections.Counter(v.get("status") for v in rows))
need(len(rows)==1669 and counts=={"passed":1636,"ignored":33},"raw test outcome counts differ")
need(len({(v["binary"],v["name"]) for v in rows})==1669,"duplicate raw test identities")
inventory={v["path"]:v for v in s["binaries"]}
for row in rows:
    need(row["binary"] in inventory,"unknown raw test binary")
    if row["status"]=="passed":
        need(row.get("binary_sha256")==inventory[row["binary"]]["sha256"],"test binary SHA binding differs")
        need(row.get("attempt")==1 and row.get("executed") is True and row.get("exit_code")==0 and not row.get("timed_out"),"test attempt/outcome differs")
        need(row.get("stdout_proof",{}).get("passed") is True,"single-test success proof missing")
    else:
        need(row.get("executed") is not True,"ignored case executed")
need(source_map()==current,"source changed during audit")
result={"schema":"hepta-x230-r13-independent-qualification-audit/v1","audited_utc":datetime.datetime.now(datetime.timezone.utc).isoformat(),"success":True,
 "auditor_sha256":sha(__file__),"qualification_report_sha256":sha(QUAL/"report.json"),"isolated_summary_sha256":sha(QUAL/"isolated-tests/summary.json"),"raw_tests_jsonl_sha256":sha(QUAL/"isolated-tests/tests.jsonl"),"source_map_sha256":sha(QUAL/"source-map.json"),
 "source_input_count":219,"source_tested_after_current_equal":True,"jobs_rs_sha256":current["src/mcp/runtime/jobs.rs"],
 "tests":dict(expected,raw_status_counts=counts,unique_test_identities=1669,executed_binary_bindings_matched=True),
 "release_binaries":binaries,"retained_libtest":{"path":lib["path"],"sha256":lib_sha,"size":Path(lib["path"]).stat().st_size},
 "qualification_stages":[{"name":v["name"],"returncode":v["returncode"],"seconds":v["seconds"]} for v in q["stages"]],
 "scope":"Current artifacts hashed; raw test counts and execution/binary bindings independently checked. No tests, benchmarks or source changes."}
output=ROOT/"qualification-audit-summary.json"
with output.open("x") as stream: json.dump(result,stream,indent=2); stream.write("\n")
print(json.dumps({"success":True,"path":str(output),"sha256":sha(output),"result":result}),flush=True)
