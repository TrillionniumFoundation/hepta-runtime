#!/usr/bin/env python3
# Copyright 2026 TrillionniumFoundation
# SPDX-License-Identifier: Apache-2.0
"""Independent recomputation of frozen R13 performance evidence; never runs benchmarks."""
import collections, datetime, hashlib, json, math, re, statistics
from pathlib import Path
ROOT=Path("/home/qian/hepta-runtime-optimization-20261103-r13")
OLD=Path("/home/qian/hepta-runtime-optimization-20261103-r12")
R11="660d64674fe3422006c0c2a82bc31f3f36edf19baf6613df7cdce51e8f3f8e4c"
R12="e7f1f8275c6735a6823f35b6367baf9fc9f943ea7e62a1114fe1187e82cd1c1f"
R13="91baf096139002075ead3c2b9043ffe12269c155650c41bd4258efd3ac5ef364"
LIB="9751bb413ec9ed05566fb4dc5d724c93794edb2bfe2a04f2ece02ca04c5d9909"
INPUTS={}
def need(value,message):
    if not value: raise RuntimeError(message)
def digest(data): return hashlib.sha256(data).hexdigest()
def sha(path):
    with Path(path).open("rb") as stream: return hashlib.file_digest(stream,"sha256").hexdigest()
def finite(value,path="root"):
    if isinstance(value,float): need(math.isfinite(value),"nonfinite value: "+path)
    elif isinstance(value,dict):
        for key,child in value.items(): finite(child,path+"."+key)
    elif isinstance(value,list):
        for i,child in enumerate(value): finite(child,path+"["+str(i)+"]")
def load(path):
    path=Path(path)
    raw=path.read_bytes()
    INPUTS[str(path)]=digest(raw)
    value=json.loads(raw)
    finite(value,str(path))
    return value
def equal_number(a,b):
    return isinstance(a,(int,float)) and not isinstance(a,bool) and math.isfinite(a) and math.isclose(a,b,rel_tol=1e-9,abs_tol=1e-10)
def positive(value,message): need(isinstance(value,(int,float)) and not isinstance(value,bool) and math.isfinite(value) and value>0,message)
def percentile(values,p):
    need(bool(values),"empty percentile")
    return sorted(values)[max(0,math.ceil(len(values)*p)-1)]
def percent(before,after):
    positive(before,"zero percent denominator")
    return (after/before-1)*100
def canonical(value):
    return (json.dumps(value,sort_keys=True,separators=(",",":"))+"\n").encode()
def within(base,name):
    path=Path(name)
    if not path.is_absolute(): path=base/path
    need(path.resolve().is_relative_to(base.resolve()),"artifact outside campaign directory")
    return path
def file_bound(base,name,expected):
    path=within(base,name)
    actual=sha(path)
    need(actual==expected,"artifact SHA differs: "+str(path))
    return path
def comparison(a,b,keys):
    return {key:{"baseline":a[key],"candidate":b[key],"change_percent":percent(a[key],b[key])} for key in keys}

qualification=load(ROOT/"qualification-audit-summary.json")
need(qualification["success"] and qualification["source_input_count"]==219,"independent qualification not clean")
need(qualification["release_binaries"]["hepta-runtime"]["sha256"]==R13 and qualification["retained_libtest"]["sha256"]==LIB,"qualification binary binding differs")
local=load(ROOT/"local-campaigns-02/report.json")
remote=load(ROOT/"remote-campaigns-02/report.json")
need(local.get("success") is True and local.get("finished_utc") and local["automatic_retries"]==0,"local campaign incomplete")
need(remote.get("success") is True and remote.get("finished_utc") and remote["automatic_retries"]==0,"remote campaign incomplete")
need(remote["local_gate_sha256"]==sha(ROOT/"local-campaigns-02/report.json"),"remote/local gate hash mismatch")
need(remote["qualification_report_sha256"]==qualification["qualification_report_sha256"],"remote qualification hash mismatch")
need(remote["candidate_sha256"]==local["gate"]["release_binaries"]["hepta-runtime"]["sha256"]==R13,"pipeline runtime mismatch")
need(local["gate"]["libtest"]["sha256"]==LIB and local["gate"]["source_files"]==219,"local libtest/source binding mismatch")
need(len(local["stages"])==6 and len(remote["stages"])==4,"pipeline stage matrix differs")
for stage in local["stages"]:
    need(stage["returncode"]==0 and stage["automatic_retries"]==0,"local stage failed/retried")
    for stream in ("stdout","stderr"):
        item=stage[stream]
        path=file_bound(ROOT,item["path"],item["sha256"])
        need(path.stat().st_size==item["bytes"],"local stage log length differs")
for item in local["retained_result_files"]:
    path=file_bound(ROOT,item["path"],item["sha256"])
    need(path.stat().st_size==item["bytes"],"retained report length differs")
for stage in remote["stages"]:
    need(stage["returncode"]==0,"remote stage failed")
    for stream in ("stdout","stderr"):
        file_bound(ROOT/"remote-campaigns-02",stage["name"]+"."+stream,stage[stream+"_sha256"])
for name,expected in remote["harness_before"].items():
    need(sha(OLD/"source/tools/x230/20261103/r12"/name)==expected,"original harness changed")
need(remote["baseline_sha256"]==R11,"remote baseline differs")
for path,expected in [
    (Path("/home/qian/hepta-runtime-optimization-20261103-r11/qualification-01/hepta-runtime"),R11),
    (OLD/"qualification-02/hepta-runtime",R12),
    (ROOT/"qualification-03/hepta-runtime",R13)]:
    need(sha(path)==expected,"runtime artifact changed")

def projection():
    base=ROOT/"operation-projection-abba-01"
    r=load(base/"report.json")
    need(r["passed"] and r["automatic_retries"]==0 and r["binary_sha256"]==LIB,"projection provenance differs")
    need(r["order"]==["owned","projected","projected","owned"] and r["pins"]==[8,32] and r["rounds"]==2,"projection plan differs")
    need(len(r["samples"])==16 and r["remote_effects"]==0,"projection count/effect differs")
    manifest=Path(r["fixture_manifest"])
    need(sha(manifest)==r["fixture_manifest_sha256"],"fixture manifest changed")
    fixture_details={}
    for fixture in r["fixtures"]:
        path=within(manifest.parent,fixture["relative_path"])
        need(path.stat().st_size==fixture["bytes"]==4194272 and sha(path)==fixture["sha256"],"projection fixture changed")
        value=json.loads(path.read_text())
        decoded=sum(len(arg.encode()) for arg in value["args"])
        need(decoded==fixture["decoded_argument_bytes"],"decoded fixture length differs")
        fixture_details[fixture["payload"]]={"encoded_bytes":fixture["bytes"],"decoded_argument_bytes":decoded,"sha256":fixture["sha256"]}
    need(set(fixture_details)=={"plain","escaped"},"fixture payload matrix differs")
    groups=collections.defaultdict(list)
    matrix=set()
    for sample in r["samples"]:
        key=(sample["payload"],sample["pins"],sample["position"])
        need(key not in matrix and sample["mode"]==r["order"][sample["position"]],"duplicate or wrong projection arm")
        matrix.add(key)
        need(sample["returncode"]==0,"projection child failed")
        text=file_bound(base,sample["stdout"],sample["stdout_sha256"]).read_text()
        file_bound(base,sample["stderr"],sample["stderr_sha256"])
        usage=file_bound(base,sample["native_usage"],sample["native_usage_sha256"]).read_text()
        results=[json.loads(line.split("OPERATION_PROJECTION_BENCH ",1)[1]) for line in text.splitlines() if "OPERATION_PROJECTION_BENCH " in line]
        need(len(results)==1 and results[0]==sample["result"],"projection stdout/result mismatch")
        need(re.search(r"test result: ok\. 1 passed; 0 failed; 0 ignored;",text) is not None,"projection test not successful")
        lines=[line for line in usage.splitlines() if line.startswith("HEPTA_TIME\t")]
        need(len(lines)==1,"missing GNU time row")
        fields=lines[0].split("\t")
        need(len(fields)==6,"invalid GNU time row")
        native={"wall_seconds":float(fields[1]),"user_seconds":float(fields[2]),"system_seconds":float(fields[3]),"max_rss_kib":int(fields[4]),"exit_code":int(fields[5])}
        need(native==sample["native"] and native["exit_code"]==0 and 0<native["max_rss_kib"]<300*1024,"GNU time result differs")
        result=sample["result"]
        need(result["mode"]==sample["mode"] and result["pins"]==sample["pins"] and result["rounds"]==2,"projection result parameters differ")
        need(result["successes"]==sample["pins"]*2 and result["failures"]==0 and result["remote_effects"]==0,"projection result counts differ")
        need(result["fixture_sha256"]==sample["fixture_sha256"]==fixture_details[sample["payload"]]["sha256"],"sample fixture hash differs")
        positive(result["cpu_seconds"],"invalid projection CPU")
        positive(result["wall_seconds"],"invalid projection wall")
        need(equal_number(result["calls_per_second"],result["successes"]/result["wall_seconds"]),"projection rate differs")
        need(equal_number(result["cpu_seconds_per_call"],result["cpu_seconds"]/result["successes"]),"projection CPU rate differs")
        groups[(sample["payload"],sample["pins"],sample["mode"])].append(sample)
    need(matrix=={(payload,pins,position) for payload in ("plain","escaped") for pins in (8,32) for position in range(4)},"projection matrix incomplete")
    cells=[]
    total=0
    for payload in ("plain","escaped"):
        for pins in (8,32):
            arms={}
            for arm in ("owned","projected"):
                samples=groups[(payload,pins,arm)]
                need(len(samples)==2,"projection arm sample count differs")
                calls=sum(s["result"]["successes"] for s in samples)
                cpu=sum(s["result"]["cpu_seconds"] for s in samples)
                wall=sum(s["result"]["wall_seconds"] for s in samples)
                total+=calls
                held=[s["result"]["resident_pinned_max_kib"] for s in samples]
                peak=[s["native"]["max_rss_kib"] for s in samples]
                arms[arm]={"calls":calls,"cpu_seconds":cpu,"wall_seconds":wall,"cpu_ms_per_guarded_read":cpu*1000/calls,"guarded_reads_per_second":calls/wall,"held_vmrss_kib_samples":held,"held_vmrss_kib_median":statistics.median(held),"child_peak_rss_kib_samples":peak,"child_peak_rss_kib_median":statistics.median(peak)}
            cells.append({"payload":payload,"pins":pins,"arms":arms,"comparison":comparison(arms["owned"],arms["projected"],["cpu_ms_per_guarded_read","guarded_reads_per_second","held_vmrss_kib_median","child_peak_rss_kib_median"])})
    need(total==640,"projection total differs")
    return {"report_sha256":INPUTS[str(base/"report.json")],"child_processes":16,"measured_guarded_reads":640,"owned_warmup_reads_excluded":16,"raw_stdout_and_time_rows_verified":16,"fixture_details":fixture_details,"cells":cells,"scope":"Same qualified opt-1 libtest, owned versus projected decoder; not R12/R13 release throughput. Owned warmup affects child peak; held VmRSS and GNU time lifetime peak are distinct."}

def cancellation(directory,baseline):
    base=ROOT/directory
    r=load(base/"report.json")
    need(r["okay"] and r["automatic_retries"]==0 and r["binaries_unchanged"],"cancel campaign failed/retried")
    need(r["binary_sha256"]=={"A":baseline,"B":R13},"cancel binary binding differs")
    need(r["order"]=="ABBA" and r["concurrency"]==8 and r["waves"]==24 and r["payload"]=="escaped","cancel plan differs")
    need(len(r["rounds"])==16,"cancel round count differs")
    groups=collections.defaultdict(list)
    matrix=set()
    identities=set()
    reply_count=0
    for sample in r["rounds"]:
        key=(sample["workers"],sample["receipt_bytes"],sample["position"])
        need(key not in matrix and sample["arm"]=="ABBA"[sample["position"]],"cancel ABBA matrix differs")
        matrix.add(key)
        identity=(sample["startup"]["pid"],sample["startup"]["birth_ticks"])
        need(identity not in identities,"controller generation reused")
        identities.add(identity)
        need(all(sample[k] is True for k in ("okay","no_cancel_intent","no_ssh_dispatch","receipt_unchanged")),"cancel guard assertion failed")
        need(sample["shutdown"]["exit_code"]==0 and sample["shutdown"]["reader_error"] is None and sample["shutdown"]["unmatched"]==0,"cancel shutdown mismatch")
        positive(sample["wall_seconds"],"invalid cancel wall")
        positive(sample["controller_cpu_seconds"],"invalid cancel CPU")
        for label,count in (("measured",216),("warmup",18)):
            rows=sample[label]
            need(len(rows)==count,"cancel measured/warmup count differs")
            need(len({v["rpc_id"] for v in rows})==count,"duplicate cancel RPC id")
            expected_counts={"process_cancel":192,"host_list":24} if label=="measured" else {"process_cancel":16,"host_list":2}
            need(dict(collections.Counter(v["params"]["name"] for v in rows))==expected_counts,"cancel method mix differs")
            for row in rows:
                positive(row["elapsed_ms"],"invalid cancel latency")
                need(row["method"]=="tools/call" and row["expected_result"] is True,"cancel row not accepted")
                response=row["response"]
                need(response.get("jsonrpc")=="2.0" and response.get("id")==row["rpc_id"] and "error" not in response,"cancel JSON-RPC reply differs")
                need(digest(canonical(response))==row["response_sha256"],"cancel raw reply hash differs")
                result=response["result"]
                text=[part["text"] for part in result.get("content",[]) if part.get("type")=="text"]
                need(bool(text),"cancel reply missing text")
                if row["params"]["name"]=="process_cancel":
                    need(row["params"]["arguments"]=={"grace_seconds":0,"host":"other","job_id":"cancel-responsiveness"},"cancel arguments differ")
                    need(result.get("isError") is True and text==["job `cancel-responsiveness` belongs to host `owner`, not `other`"],"wrong-host refusal differs")
                else:
                    need(row["params"]["arguments"]=={} and result.get("isError") is False,"host_list refused")
                    dto=json.loads(text[0])
                    need({v["name"] for v in dto["hosts"]}=={"owner","other"} and len(dto["hosts"])==2,"host_list result differs")
                reply_count+=1
        need(len({v["rpc_id"] for v in sample["measured"]+sample["warmup"]})==234,"warmup and measurement ids overlap")
        for wave in range(24):
            rows=[v for v in sample["measured"] if v["wave"]==wave]
            need(len(rows)==9 and collections.Counter(v["params"]["name"] for v in rows)=={"process_cancel":8,"host_list":1},"wave mix differs")
        for tool in ("process_cancel","host_list"):
            values=[v["elapsed_ms"] for v in sample["measured"] if v["params"]["name"]==tool]
            need(sample[tool]["count"]==len(values) and equal_number(sample[tool]["p95_ms"],percentile(values,.95)),"recorded cancel percentile differs")
        groups[(sample["workers"],sample["receipt_bytes"],sample["arm"])].append(sample)
    need(matrix=={(workers,size,p) for workers in (1,2) for size in (1024,4194272) for p in range(4)},"cancel matrix incomplete")
    need(reply_count==3744,"cancel RPC total differs")
    cells=[]
    for workers in (1,2):
        for size in (1024,4194272):
            arms={}
            hashes=set()
            for arm in "AB":
                samples=groups[(workers,size,arm)]
                need(len(samples)==2,"cancel arm count differs")
                rows=[v for s in samples for v in s["measured"]]
                calls=len(rows)
                cpu=sum(s["controller_cpu_seconds"] for s in samples)
                wall=sum(s["wall_seconds"] for s in samples)
                lat={name:[v["elapsed_ms"] for v in rows if v["params"]["name"]==name] for name in ("process_cancel","host_list")}
                hwm=[s["memory_after"]["kib"]["VmHWM"] for s in samples]
                rss=[s["memory_after"]["kib"]["VmRSS"] for s in samples]
                need(calls==432 and len(lat["process_cancel"])==384 and len(lat["host_list"])==48,"cancel denominator differs")
                for v in hwm+rss: positive(v,"invalid cancel memory")
                hashes.update(s["receipt_sha256"] for s in samples)
                arms[arm]={"mixed_calls":calls,"cancel_calls":384,"host_list_calls":48,"cpu_seconds":cpu,"wall_seconds":wall,"cpu_ms_per_mixed_rpc":cpu*1000/calls,"mixed_rpc_per_second":calls/wall,"host_list_p95_ms":percentile(lat["host_list"],.95),"cancel_p95_ms":percentile(lat["process_cancel"],.95),"vmhwm_kib_samples":hwm,"vmhwm_kib_median":statistics.median(hwm),"vmrss_after_kib_samples":rss,"vmrss_after_kib_median":statistics.median(rss)}
            need(len(hashes)==1,"A/B receipt bytes differ")
            cells.append({"workers":workers,"receipt_bytes":size,"receipt_sha256":next(iter(hashes)),"arms":arms,"comparison":comparison(arms["A"],arms["B"],["cpu_ms_per_mixed_rpc","mixed_rpc_per_second","host_list_p95_ms","cancel_p95_ms","vmhwm_kib_median","vmrss_after_kib_median"])})
    return {"report_sha256":INPUTS[str(base/"report.json")],"baseline_sha256":baseline,"candidate_sha256":R13,"child_processes":16,"measured_calls":3456,"warmup_calls_excluded":288,"all_reply_hashes_and_semantics_verified":reply_count,"automatic_retries":0,"cells":cells,"scope":"Expected wrong-host refusals plus host_list; CPU denominator is mixed RPCs. VmHWM is sampled after measurement, since exec, including warmup; not per-request allocation."}

def native():
    base=ROOT/"native-r11-r13-01"
    r=load(base/"report.json")
    need(r["passed"] and r["automatic_rpc_retries"]==0 and r["binary_hashes_unchanged"],"native campaign failed/retried")
    need(r["binary_sha256"]=={"A":R11,"B":R13},"native binary binding differs")
    need(remote["native_report_sha256"]==INPUTS[str(base/"report.json")],"remote native report binding differs")
    need(r["order"]=="ABBA" and r["concurrency"]==[1,4,8] and r["calls_per_cell"]==96 and r["tokio_workers"]==2,"native plan differs")
    need(r["remote_mutation_tool_calls"]==0 and r["effect_starts"]==0 and r["source_originals_unchanged"],"native read-only invariants differ")
    originals={v["host"]:v for v in r["six_originals"]}
    need(set(originals)=={"ai395","mac","main","pocket4","rog","x230"},"native six-host set differs")
    groups=collections.defaultdict(list)
    resources={"A":[],"B":[]}
    all_rows=[]
    measured=warmup=checks=0
    measured_mix=warmup_mix=None
    metric_errors=[]
    def row_check(row):
        need(row.get("okay") is True and row.get("isError") is False and row.get("automatic_retry") is False,"native row unsuccessful or retried")
        need(row["host"] in originals and row["job_id"]==originals[row["host"]]["job_id"],"native original identity differs")
        need(row["tool"] in ("process_status","process_read","process_wait"),"unexpected native tool")
        positive(row["elapsed_ms"],"invalid native latency")
        for key in ("dto_sha256","response_sha256"): need(re.fullmatch("[0-9a-f]{64}",row[key]) is not None,"invalid native digest")
        if "stdout_bytes" in row:
            original=originals[row["host"]]
            need(row["stdout_bytes"]==original["stdout_bytes"] and row["stdout_sha256"]==original["stdout_sha256"],"complete original output binding differs")
            need(row["stderr_bytes"]==0 and row["stderr_sha256"]==digest(b""),"original stderr differs")
    need(len(r["rounds"])==4,"native round count differs")
    for index,round_ in enumerate(r["rounds"]):
        need(round_["index"]==index and round_["version"]=="ABBA"[index] and round_["passed"],"native ABBA order differs")
        need([cell["concurrency"] for cell in round_["cells"]]==[1,4,8],"native concurrency matrix differs")
        initial=round_["initial_complete_outputs"]
        restart=round_["restart_checks"]
        need(len(initial)==6 and len(restart)==12,"native verification call count differs")
        for row in initial+restart: row_check(row)
        checks+=len(initial)+len(restart)
        all_rows.extend(initial+restart)
        for cell in round_["cells"]:
            for label,batch,expected in (("measured",cell,96),("warmup",cell["warmup"],24)):
                rows=batch["rows"]
                need(batch["calls"]==batch["successes"]==len(rows)==expected and batch["no_success_filtering"] is True,"native call count differs")
                need(batch["concurrency"]==cell["concurrency"],"native warmup C differs")
                positive(batch["seconds"],"invalid native duration")
                positive(batch["controller_cpu_seconds"],"invalid native CPU")
                need(batch["sampled_tree_cpu_seconds_delta_is_performance_numerator"] is False,"wrong native CPU numerator")
                need("same-PID/start-ticks" in batch["controller_cpu_source"],"native CPU identity scope differs")
                need(equal_number(batch["completion_rps"],expected/batch["seconds"]) and equal_number(batch["successful_rps"],expected/batch["seconds"]),"native cell rate differs")
                need(equal_number(batch["controller_cpu_ms_per_call"],batch["controller_cpu_seconds"]*1000/expected),"native cell CPU rate differs")
                need(equal_number(batch["p95_ms"],percentile([v["elapsed_ms"] for v in rows],.95)),"native cell p95 differs")
                for row in rows: row_check(row)
                mix=collections.Counter((v["host"],v["tool"]) for v in rows)
                if label=="measured":
                    measured+=len(rows)
                    if measured_mix is None: measured_mix=mix
                    need(mix==measured_mix,"native measured host/tool mix differs")
                else:
                    warmup+=len(rows)
                    if warmup_mix is None: warmup_mix=mix
                    need(mix==warmup_mix,"native warmup host/tool mix differs")
                all_rows.extend(rows)
            groups[(round_["version"],cell["concurrency"])].append(cell)
        for name in ("shutdown","restart_shutdown"):
            shutdown=round_[name]
            need(shutdown["exit_code"]==0 and shutdown["reader_error"] is None and shutdown["unmatched_responses"]==0 and shutdown["observed_descendant_survivors"]==[],"native shutdown not clean")
            usage=shutdown["resources"]
            if usage["error_counts"]: metric_errors.append({"round":index,"phase":name,"error_counts":usage["error_counts"]})
        usage=round_["shutdown"]["resources"]
        hwm=usage["peaks"].get("controller_hwm_kib") if usage["metric_samples"].get("controller_hwm_kib",0)>0 else None
        rss=usage["peaks"].get("controller_rss_kib") if usage["metric_samples"].get("controller_rss_kib",0)>0 else None
        resources[round_["version"]].append({"round":index,"controller_vmhwm_kib":hwm,"sampled_controller_rss_peak_kib":rss,"metric_samples":usage["metric_samples"],"errors":usage["error_counts"]})
    need((measured,warmup,checks)==(1152,288,72) and len(all_rows)==1512,"native total call counts differ")
    cells=[]
    for concurrency in (1,4,8):
        arms={}
        for arm in "AB":
            samples=groups[(arm,concurrency)]
            need(len(samples)==2,"native arm sample count differs")
            rows=[v for s in samples for v in s["rows"]]
            calls=len(rows)
            cpu=sum(s["controller_cpu_seconds"] for s in samples)
            wall=sum(s["seconds"] for s in samples)
            need(calls==192,"native pooled denominator differs")
            arms[arm]={"calls":calls,"cpu_seconds":cpu,"wall_seconds":wall,"cpu_ms_per_call":cpu*1000/calls,"calls_per_second":calls/wall,"p95_ms":percentile([v["elapsed_ms"] for v in rows],.95),"p99_ms":percentile([v["elapsed_ms"] for v in rows],.99),"per_process_wall_seconds":[s["seconds"] for s in samples],"per_process_cpu_seconds":[s["controller_cpu_seconds"] for s in samples]}
        cells.append({"concurrency":concurrency,"arms":arms,"comparison":comparison(arms["A"],arms["B"],["cpu_ms_per_call","calls_per_second","p95_ms","p99_ms"])})
    for arm,samples in resources.items():
        for s in samples: positive(s["controller_vmhwm_kib"],"unavailable native HWM")
    memory={arm:{"samples":samples,"controller_vmhwm_kib_median":statistics.median(s["controller_vmhwm_kib"] for s in samples),"sampled_rss_peak_kib_median":statistics.median(s["sampled_controller_rss_peak_kib"] for s in samples)} for arm,samples in resources.items()}
    return {"report_sha256":INPUTS[str(base/"report.json")],"baseline_sha256":R11,"candidate_sha256":R13,"measured_calls":1152,"warmup_calls_excluded":288,"verification_calls_excluded":72,"total_native_calls":1512,"automatic_retries":0,"cells":cells,"whole_controller_memory":memory,"resource_metric_errors_preserved":metric_errors,
    "native_response_proof_scope":"Rows carry reply/DTO hashes and successful validation flags, not JSON-RPC bodies. This audit validates their format, identity/matrix, complete-output bindings, and recomputes metrics; it does not claim independently recomputed native transport-envelope hashes.",
    "memory_scope":"Main controller across initial checks, all C levels and warmup; sampled kernel VmHWM and sampled VmRSS peaks are not per-C or per-call allocations. FD permission errors remain visible and do not invalidate separately available CPU/RSS."}

result={"schema":"hepta-x230-r13-independent-performance-audit/v1","audited_utc":datetime.datetime.now(datetime.timezone.utc).isoformat(),"success":True,"auditor_sha256":sha(__file__),"qualification_audit_sha256":sha(ROOT/"qualification-audit-summary.json"),"candidate_sha256":R13,"libtest_sha256":LIB,
 "method":{"cpu_and_rate":"sum of measured numerators divided by sum of measured call counts or wall durations; no median-rate substitution","p95":"nearest-rank ceil(0.95*N) of pooled raw per-call latencies","rss":"two fresh process samples per arm/case, both samples retained, arithmetic median","all_raw_floats_finite":True,"existing_analysis_summaries_used_for_metrics":False},
 "projection":projection(),"cancel_r12_r13":cancellation("cancel-r12-r13-01",R12),"cancel_r11_r13":cancellation("cancel-r11-r13-01",R11),"native_r11_r13":native()}
for path,expected in INPUTS.items(): need(sha(path)==expected,"input changed during audit")
result["input_sha256"]=INPUTS
output=ROOT/"independent-performance-audit.json"
with output.open("x") as stream: json.dump(result,stream,indent=2,allow_nan=False); stream.write("\n")
compact={"success":True,"path":str(output),"sha256":sha(output)}
for key in ("projection","cancel_r12_r13","cancel_r11_r13","native_r11_r13"):
    compact[key]=[{k:v for k,v in cell.items() if k!="arms"} for cell in result[key]["cells"]]
print(json.dumps(compact,allow_nan=False),flush=True)
