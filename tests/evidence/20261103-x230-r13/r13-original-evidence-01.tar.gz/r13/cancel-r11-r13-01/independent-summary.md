# Native cancellation-load responsiveness

finite native MCP wrong-host rejection workload; not successful remote cancellation throughput. Two runs per arm/case; no statistical-significance claim.

| Workers | Receipt bytes | host_list p50 ms A → B | host_list p95 ms A → B | p95 change | CPU ms / mixed RPC A → B | VmHWM KiB median A → B |
|---:|---:|---:|---:|---:|---:|---:|
| 1 | 1024 | 14.217 → 14.041 | 17.666 → 18.753 | +6.15% | 1.736 → 1.759 | 13806.0 → 14484.0 |
| 1 | 4194272 | 196.589 → 27.785 | 214.904 → 47.106 | -78.08% | 23.241 → 36.319 | 22268.0 → 115612.0 |
| 2 | 1024 | 16.556 → 16.082 | 21.174 → 17.664 | -16.58% | 1.829 → 1.806 | 15340.0 → 15648.0 |
| 2 | 4194272 | 105.306 → 33.742 | 120.514 → 49.543 | -58.89% | 24.838 → 36.065 | 34514.0 → 134954.0 |

Validated 3456 measured and 288 warmup replies across 16 controller generations.

Limitations:

- two independent controller runs per arm/case.
- no statistical significance claim.
- host_list includes ordinary audit and result-retention costs.
- warm receipt cache after two mixed waves.
- whole-child VmHWM includes startup/warmup and is not incremental request memory.
- clock endpoints were not retained; recorded timing deltas cannot be independently re-created.
- all negative directional results retained.
