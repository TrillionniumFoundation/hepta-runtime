#!/usr/bin/env python3
# Copyright 2026 TrillionniumFoundation
# SPDX-License-Identifier: Apache-2.0
"""Archive frozen R13 evidence with exact selection, credential scan and verification."""
import argparse, datetime, gzip, hashlib, io, json, os, re, stat, tarfile
from pathlib import Path, PurePosixPath
ROOT=Path("/home/qian/hepta-runtime-optimization-20261103-r13")
FINAL=ROOT/"publication-r13-final"
RECOVERY=Path("/home/qian/hepta-runtime-optimization-20261103-r12/r13-candidate-cancel-recovery-01")
AUDITS=("qualification-audit-summary.json","independent-performance-audit.json","independent-recovery-audit.json")
DIRS=("qualification-01","qualification-02","qualification-03","failure-fix-03","failure-fix-04",
      "local-campaigns-01","local-campaigns-02","remote-campaigns-01","remote-campaigns-02",
      "operation-projection-abba-01","cancel-r12-r13-01","cancel-r11-r13-01","native-r11-r13-01",
      "measurement-tools","independent-audit-tools")
FILES=("build-preflight-01.json","build-preflight-02.json","build-preflight-03.json",
       "qualification-launch-03.py","run-state-03.json","publication-progress-01.json",
       "preliminary-performance-summary.json","github-compiler-tree-verification-01.json",*AUDITS)
STAGED=("compiler-inputs.json","publication-source-manifest.json","publication-tools-manifest.json",
        "uploaded-blobs-23.json",*[f"blob-receipts/upload-batch-0{i}.json" for i in range(1,5)])
RAW_FIXTURES={f"r13/measurement-tools/fixtures/{kind}/operation-projection.json" for kind in ("plain","escaped")}
PATTERNS=[
 ("private_key",rb"-----BEGIN (?:[A-Z0-9]+ )*PRIVATE KEY-----|openssh-key-v1\x00"),
 ("github_token",rb"\b(?:gh[pousr]_[A-Za-z0-9]{20,}|github_pat_[A-Za-z0-9_]{20,})\b"),
 ("aws_key",rb"\b(?:AKIA|ASIA)[A-Z0-9]{16}\b"),
 ("slack_token",rb"\bxox[baprs]-[A-Za-z0-9-]{20,}\b"),
 ("openai_key",rb"\bsk-(?:proj-|svcacct-)?[A-Za-z0-9_-]{32,}\b"),
 ("jwt",rb"\beyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}\b"),
 ("bearer",rb"(?i)authorization[\"'\s:=]+bearer\s+[A-Za-z0-9._~+/-]{24,}"),
]
MAGICS=(b"\x7fELF",b"MZ",b"\xfe\xed\xfa\xce",b"\xfe\xed\xfa\xcf",b"\xce\xfa\xed\xfe",
        b"\xcf\xfa\xed\xfe",b"\xca\xfe\xba\xbe",b"\xbe\xba\xfe\xca",b"\xca\xfe\xba\xbf",
        b"\xbf\xba\xfe\xca",b"\x00asm")
def need(ok,why):
    if not ok: raise RuntimeError(why)
def sha(data): return hashlib.sha256(data).hexdigest()
def encoded(value): return (json.dumps(value,indent=2,sort_keys=True)+"\n").encode()
def version(s): return [s.st_dev,s.st_ino,s.st_size,s.st_mtime_ns,s.st_ctime_ns,s.st_mode,s.st_uid,s.st_nlink]
def safe(name): return bool(name) and not PurePosixPath(name).is_absolute() and ".." not in PurePosixPath(name).parts and "\\" not in name and "\x00" not in name
def write(path,data):
    with Path(path).open("xb") as f: f.write(data); f.flush(); os.fsync(f.fileno())
def read(path,expected=None):
    before=path.lstat()
    need(stat.S_ISREG(before.st_mode),"source is not regular: "+str(path))
    if expected is not None: need(version(before)==expected,"source identity changed: "+str(path))
    fd=os.open(path,os.O_RDONLY|os.O_NOFOLLOW|os.O_CLOEXEC)
    try:
        need(version(os.fstat(fd))==version(before),"opened source differs")
        with os.fdopen(fd,"rb",closefd=False) as f: data=f.read()
        need(version(os.fstat(fd))==version(before)==version(path.lstat()),"source changed during read")
        return data,before
    finally: os.close(fd)
def meta(path):
    data=path.read_bytes()
    return {"path":str(path),"bytes":len(data),"sha256":sha(data),
            "git_blob_sha1":hashlib.sha1(b"blob "+str(len(data)).encode()+b"\0"+data).hexdigest()}

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("--bindings",required=True)
    p.add_argument("--id",default="01")
    args=p.parse_args()
    need(re.fullmatch(r"[0-9]{2}",args.id),"invalid package id")
    bindings=json.loads(Path(args.bindings).read_bytes())
    need(set(AUDITS).issubset(bindings),"missing independent audit bindings")
    for name,digest in bindings.items():
        need(safe(name) and re.fullmatch(r"[0-9a-f]{64}",digest),"invalid audit binding")
        need(sha((ROOT/name).read_bytes())==digest,"audit binding mismatch: "+name)
    for name in AUDITS: json.loads((ROOT/name).read_bytes())
    need(json.loads((ROOT/"qualification-03/report.json").read_bytes()).get("qualified") is True,"qualification not complete")
    for name in ("local-campaigns-02","remote-campaigns-02"):
        need(json.loads((ROOT/name/"report.json").read_bytes()).get("success") is True,"campaign not complete")
    for name in ("local-campaigns-01","remote-campaigns-01"):
        result=json.loads((ROOT/name/"report.json").read_bytes())
        need(result.get("success") is False and result.get("stages")==[],"old failed gate differs")
    out=ROOT/("evidence-package-"+args.id)
    out.mkdir(mode=0o700,exist_ok=False)
    sources,excluded={},[]
    def add(path,name):
        need(safe(name) and name not in sources,"unsafe/duplicate archive path")
        st=path.lstat();reason=None
        if not stat.S_ISREG(st.st_mode): reason="nonregular object; no link or device archived"
        elif name in RAW_FIXTURES: reason="projection payload omitted; verified generator/manifest retained"
        elif "/test-binaries/" in name: reason="compiled test binary omitted"
        elif name.startswith("r13/qualification-") and path.name in {"hepta-runtime","hepta-runtime-jobctl","native_process_driver","hepta-effect-ownerctl"}: reason="compiled release binary omitted"
        if reason: excluded.append({"path":name,"bytes":st.st_size,"reason":reason})
        else: sources[name]=path
    def tree(path,prefix):
        need(path.is_dir(),"missing evidence directory: "+str(path))
        for directory,dirs,files in os.walk(path,followlinks=False):
            for name in list(dirs):
                child=Path(directory)/name
                if child.is_symlink() or name=="__pycache__":
                    excluded.append({"path":prefix+"/"+child.relative_to(path).as_posix(),"reason":"symlink directory/cache omitted"})
                    dirs.remove(name)
            dirs.sort()
            for name in sorted(files):
                child=Path(directory)/name;add(child,prefix+"/"+child.relative_to(path).as_posix())
    for name in DIRS: tree(ROOT/name,"r13/"+name)
    for name in FILES: add(ROOT/name,"r13/"+name)
    for name in bindings:
        if "r13/"+name not in sources: add(ROOT/name,"r13/"+name)
    for name in STAGED: add(FINAL/name,"publication-snapshot/"+name)
    tree(RECOVERY,"r12/r13-candidate-cancel-recovery-01")
    add(Path(__file__).resolve(),"r13/evidence-tools/build_r13_archive.py")
    add(Path(args.bindings).resolve(),"r13/evidence-tools/audit-bindings.json")
    selected,versions,findings=[],{},[]
    patterns=[(kind,re.compile(pattern)) for kind,pattern in PATTERNS]
    for name,path in sorted(sources.items()):
        with path.open("rb") as f: magic=f.read(8)
        if any(magic.startswith(prefix) for prefix in MAGICS):
            excluded.append({"path":name,"bytes":path.stat().st_size,"reason":"compiled binary magic omitted"});continue
        data,st=read(path)
        for kind,pattern in patterns:
            if pattern.search(data): findings.append({"path":name,"kind":kind})
        selected.append({"path":name,"bytes":len(data),"sha256":sha(data),"mode":format(stat.S_IMODE(st.st_mode)&0o777,"04o"),"mtime_ns":st.st_mtime_ns})
        versions[name]=version(st)
    scan={"patterns":[name for name,_ in PATTERNS],"matches":findings,"selected_files_scanned":len(selected),"scope":"known credential patterns; matching values never printed"}
    write(out/"secret-scan.json",encoded(scan))
    need(not findings,"secret pattern match; inspect metadata-only secret-scan.json")
    groups={}
    for row in selected:
        key="/".join(PurePosixPath(row["path"]).parts[:2]);g=groups.setdefault(key,{"files":0,"bytes":0});g["files"]+=1;g["bytes"]+=row["bytes"]
    index={"schema":"hepta-r13-evidence-selection/v1","created_utc":datetime.datetime.now(datetime.timezone.utc).isoformat(),
           "source_roots":{"r13":str(ROOT),"r12/r13-candidate-cancel-recovery-01":str(RECOVERY),"publication-snapshot":str(FINAL)},
           "audit_bindings":bindings,"files":selected,"excluded":sorted(excluded,key=lambda x:x["path"]),
           "groups":groups,"selected_count":len(selected),"selected_bytes":sum(x["bytes"] for x in selected),
           "secret_scan":scan,"regular_archive_entries_only":True,"manifest_excludes_itself":True,
           "compiled_binaries_included":False,"raw_projection_fixture_bytes_included":0,"source_data_modified":False}
    index_bytes=encoded(index);index_path=out/"archive-selection.json";write(index_path,index_bytes)
    index_gz=out/("archive-selection-"+args.id+".json.gz");write(index_gz,gzip.compress(index_bytes,compresslevel=6,mtime=0))
    archive_path=out/("r13-original-evidence-"+args.id+".tar.gz")
    with archive_path.open("xb") as raw:
        with gzip.GzipFile(fileobj=raw,filename="",mode="wb",compresslevel=6,mtime=0) as gz:
            with tarfile.open(fileobj=gz,mode="w|",format=tarfile.PAX_FORMAT) as tar:
                for row in selected:
                    data,_=read(sources[row["path"]],versions[row["path"]]);need(sha(data)==row["sha256"],"source bytes changed")
                    info=tarfile.TarInfo(row["path"]);info.size=len(data);info.mode=int(row["mode"],8);info.mtime=0
                    tar.addfile(info,io.BytesIO(data))
                info=tarfile.TarInfo("archive-selection.json");info.size=len(index_bytes);info.mode=0o644;info.mtime=0
                tar.addfile(info,io.BytesIO(index_bytes))
        raw.flush();os.fsync(raw.fileno())
    expected={x["path"]:(x["bytes"],x["sha256"]) for x in selected}
    expected["archive-selection.json"]=(len(index_bytes),sha(index_bytes));seen=set()
    with tarfile.open(archive_path,"r:gz") as tar:
        for item in tar:
            need(item.isfile() and safe(item.name) and item.name in expected and item.name not in seen,"unsafe/unexpected/duplicate archive entry")
            data=tar.extractfile(item).read();need((len(data),sha(data))==expected[item.name],"archive member hash mismatch");seen.add(item.name)
    need(seen==set(expected),"archive member set differs")
    for name,digest in bindings.items(): need(sha((ROOT/name).read_bytes())==digest,"audit changed during archive")
    result={"schema":"hepta-r13-evidence-archive/v1","created_utc":index["created_utc"],"finished_utc":datetime.datetime.now(datetime.timezone.utc).isoformat(),
            "archive":meta(archive_path),"selection_index":meta(index_gz),"uncompressed_selection":meta(index_path),
            "selected_files":len(selected),"selected_bytes":index["selected_bytes"],"groups":groups,
            "archive_members_verified":len(seen),"excluded_entries":len(excluded),"audit_bindings":bindings,
            "secret_pattern_matches":0,"archive_member_hashes_verified":True,"source_data_modified":False,
            "compiled_binaries_included":False,"raw_projection_fixture_bytes_included":0}
    summary=out/("archive-summary-"+args.id+".json");write(summary,encoded(result))
    print(json.dumps({"package":str(out),"summary_path":str(summary),"summary":result}),flush=True)
if __name__=="__main__": main()
