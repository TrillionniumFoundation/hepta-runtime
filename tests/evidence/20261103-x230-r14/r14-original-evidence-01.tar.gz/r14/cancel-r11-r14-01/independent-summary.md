# Native cancellation-load responsiveness

finite native MCP wrong-host rejection workload; not successful remote cancellation throughput. Two runs per arm/case; no statistical-significance claim.

| Workers | Receipt bytes | host_list p50 ms A → B | host_list p95 ms A → B | p95 change | CPU ms / mixed RPC A → B | VmHWM KiB median A → B |
|---:|---:|---:|---:|---:|---:|---:|
| 1 | 1024 | 14.620 → 13.422 | 18.782 → 20.981 | +11.71% | 1.713 → 1.782 | 13836.0 → 14242.0 |
| 1 | 4194272 | 200.396 → 13.246 | 211.735 → 16.469 | -92.22% | 23.449 → 25.093 | 22026.0 → 94424.0 |
| 2 | 1024 | 16.226 → 16.079 | 17.510 → 17.738 | +1.30% | 1.806 → 1.852 | 15362.0 → 15460.0 |
| 2 | 4194272 | 105.231 → 14.446 | 134.941 → 26.892 | -80.07% | 24.977 → 25.926 | 33926.0 → 96786.0 |

Validated 3456 measured and 288 warmup replies across 16 controller generations.

Limitations:

- two independent controller runs per arm/case.
- no statistical significance claim.
- host_list includes ordinary audit and result-retention costs.
- warm receipt cache after two mixed waves.
- whole-child VmHWM includes startup/warmup and is not incremental request memory.
- clock endpoints were not retained; recorded timing deltas cannot be independently re-created.
- all negative directional results retained.
