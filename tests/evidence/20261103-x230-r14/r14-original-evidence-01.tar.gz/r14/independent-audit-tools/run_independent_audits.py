#!/usr/bin/env python3
# Copyright 2026 TrillionniumFoundation
# SPDX-License-Identifier: Apache-2.0
"""Wait for existing R14 evidence, then run independent read-only audits exactly once."""
import datetime,hashlib,json,os,subprocess,sys,time
from pathlib import Path
ROOT=Path("/home/qian/hepta-runtime-optimization-20261103-r14")
HERE=ROOT/"independent-audit-tools"
ATTEMPT=HERE/"attempt-01"
GATES=[("qualification",ROOT/"qualification-01/report.json","qualified"),
       ("local",ROOT/"local-campaigns-01/report.json","success"),
       ("remote",ROOT/"remote-campaigns-01/report.json","success")]
def need(value,message):
    if not value: raise RuntimeError(message)
def now(): return datetime.datetime.now(datetime.timezone.utc).isoformat()
def sha(path):
    with Path(path).open("rb") as stream: return hashlib.file_digest(stream,"sha256").hexdigest()
def save():
    next_path=ATTEMPT/"execution.next"
    next_path.write_text(json.dumps(report,indent=2)+"\n")
    os.replace(next_path,ATTEMPT/"execution.json")
def event(**fields): print(json.dumps(dict(utc=now(),**fields)),flush=True)
ATTEMPT.mkdir(mode=0o700,exist_ok=False)
manifest=json.loads((HERE/"auditor-manifest.json").read_text())
report={"schema":"hepta-x230-r14-independent-audit-execution/v1","success":False,"started_utc":now(),"state":"waiting","automatic_retries":0,"tests_or_benchmarks_started":0,"gate_wait_limit_seconds":7200,"stages":[],"manifest_sha256":sha(HERE/"auditor-manifest.json")}
save()
try:
    for name,expected in manifest["auditor_sha256"].items():
        need(sha(HERE/name)==expected,"auditor source differs before wait: "+name)
    expected_outputs=["qualification-audit-summary.json","independent-performance-audit.json","independent-recovery-audit.json"]
    need(not any((ROOT/name).exists() for name in expected_outputs),"audit output already exists; no automatic rerun")
    deadline=time.monotonic()+7200
    previous=None
    while True:
        all_done=True
        state={}
        raw_gates={}
        for label,path,flag in GATES:
            if not path.exists():
                all_done=False;state[label]={"exists":False};continue
            raw=path.read_bytes()
            value=json.loads(raw)
            need(not value.get("error"),label+" gate failed")
            need(not any(v.get("returncode") not in (None,0) for v in value.get("stages",[])),label+" stage failed")
            finished=bool(value.get("finished_utc"))
            need(not finished or value.get(flag) is True,label+" gate finished unsuccessfully")
            done=finished and value.get(flag) is True
            all_done=all_done and done
            state[label]={"done":done,"stage":value.get("current_stage",value.get("state")),"finished_utc":value.get("finished_utc")}
            raw_gates[label]=raw
        report["gate_state"]=state
        report["last_observed_utc"]=now()
        save()
        if state!=previous: event(state="waiting_for_completed_evidence",gates=state);previous=state
        if all_done:
            report["gate_sha256"]={}
            for label,path,flag in GATES:
                raw=raw_gates[label]
                with (ATTEMPT/(label+"-completed-gate.json")).open("xb") as stream: stream.write(raw)
                report["gate_sha256"][str(path)]=hashlib.sha256(raw).hexdigest()
            break
        need(time.monotonic()<deadline,"bounded evidence wait expired")
        time.sleep(20)
    report["state"]="auditing"
    save()
    event(state="all_measurements_completed_audit_started",gate_sha256=report["gate_sha256"])
    plans=[
      ("qualification","audit_qualification.py",[],expected_outputs[0]),
      ("performance","audit_performance.py",[],expected_outputs[1]),
      ("recovery","audit_recovery.py",["--root",str(ROOT),"--recovery","/home/qian/hepta-runtime-optimization-20261103-r12/r14-candidate-cancel-recovery-01","--remote-gate","remote-campaigns-01/report.json"],expected_outputs[2])]
    for label,script,arguments,output in plans:
        need(sha(HERE/script)==manifest["auditor_sha256"][script],"auditor source changed")
        row={"name":label,"script":str(HERE/script),"script_sha256":manifest["auditor_sha256"][script],"started_utc":now(),"returncode":None,"automatic_retries":0}
        report["stages"].append(row)
        save()
        stdout=ATTEMPT/(label+".stdout")
        stderr=ATTEMPT/(label+".stderr")
        with stdout.open("xb") as a,stderr.open("xb") as b:
            child=subprocess.run(["/usr/bin/python3","-B",str(HERE/script),*arguments],stdout=a,stderr=b,timeout=900)
        row["returncode"]=child.returncode
        row["finished_utc"]=now()
        row["stdout"]={"path":str(stdout),"sha256":sha(stdout),"bytes":stdout.stat().st_size}
        row["stderr"]={"path":str(stderr),"sha256":sha(stderr),"bytes":stderr.stat().st_size}
        save()
        need(child.returncode==0,label+" independent audit failed; preserved stdout/stderr")
        value=json.loads((ROOT/output).read_text())
        need(value.get("success") is True,label+" audit did not return success:true")
        row["result"]={"path":str(ROOT/output),"sha256":sha(ROOT/output)}
        save()
        event(state="independent_audit_completed",stage=label,result=row["result"])
    for path,expected in report["gate_sha256"].items(): need(sha(path)==expected,"completed evidence gate changed during audit")
    for name,expected in manifest["auditor_sha256"].items(): need(sha(HERE/name)==expected,"auditor source changed during audit")
    report["success"]=True
    report["state"]="completed"
except BaseException as error:
    report["state"]="failed"
    report["error"]={"type":type(error).__name__,"reason":str(error)[:2000]}
finally:
    report["finished_utc"]=now()
    save()
    event(state="independent_audit_terminal",success=report["success"],report=str(ATTEMPT/"execution.json"),sha256=sha(ATTEMPT/"execution.json"),error=report.get("error"))
raise SystemExit(0 if report["success"] else 1)
