# Native cancellation-load responsiveness

finite native MCP wrong-host rejection workload; not successful remote cancellation throughput. Two runs per arm/case; no statistical-significance claim.

| Workers | Receipt bytes | host_list p50 ms A → B | host_list p95 ms A → B | p95 change | CPU ms / mixed RPC A → B | VmHWM KiB median A → B |
|---:|---:|---:|---:|---:|---:|---:|
| 1 | 1024 | 13.449 → 13.394 | 18.712 → 18.682 | -0.16% | 1.759 → 1.759 | 14314.0 → 14250.0 |
| 1 | 4194272 | 29.483 → 13.918 | 42.202 → 17.723 | -58.00% | 36.343 → 25.139 | 125306.0 → 104736.0 |
| 2 | 1024 | 16.277 → 15.924 | 18.706 → 19.312 | +3.24% | 1.875 → 1.898 | 15600.0 → 15490.0 |
| 2 | 4194272 | 34.345 → 14.569 | 46.257 → 19.799 | -57.20% | 36.111 → 25.949 | 137380.0 → 101152.0 |

Validated 3456 measured and 288 warmup replies across 16 controller generations.

Limitations:

- two independent controller runs per arm/case.
- no statistical significance claim.
- host_list includes ordinary audit and result-retention costs.
- warm receipt cache after two mixed waves.
- whole-child VmHWM includes startup/warmup and is not incremental request memory.
- clock endpoints were not retained; recorded timing deltas cannot be independently re-created.
- all negative directional results retained.
