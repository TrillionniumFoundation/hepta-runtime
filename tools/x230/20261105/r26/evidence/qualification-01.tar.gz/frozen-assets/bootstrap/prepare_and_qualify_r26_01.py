#!/usr/bin/env python3
# Copyright 2026 TrillionniumFoundation
# SPDX-License-Identifier: Apache-2.0
"""Qualify a new R26 snapshot; retain the rejected R25 source and measurements."""
import argparse
import datetime
import hashlib
import json
import os
from pathlib import Path
import shutil
import stat
import subprocess
import time
import traceback

ROOT = Path('/home/qian/hepta-runtime-optimization-20261105-r26')
PARENT = Path('/home/qian/hepta-runtime-optimization-20261105-r25')
ACCEPTED = Path('/home/qian/hepta-runtime-optimization-20261105-r24')
OLD_SOURCE = PARENT / 'source-02'
SOURCE = ROOT / 'source'
TARGET = ROOT / 'target-build'
OUTPUT = ROOT / 'qualification-01'
INPUT = PARENT / 'tools/r26-qualification-01-input.json'
JOB_PATH = 'src/mcp/runtime/jobs.rs'
BASE_REPORT_SHA = '72a4001ed303d565f5c3300ea8786acf1c4e9d7991e0a1f0486fabc140900e3c'
BASE_MAP_SHA = '3933df57e42f8341ef7c7dd3faba6776ce2b34245e3d765ce8da0814207e3ee0'
REJECTION_SHA = '1e06d6bbf06e391505ef8937e304190a4a333f03903c12a9a833ea5133610603'
REJECTION_SUMMARY_SHA = '68fd9d1cc05d2c0eab670ccd6d3d99ec4922a3eb369b02cb3b3d16e70bc9737c'
PUBLICATION_SHA = '38866c01fac54133c8a88e25bee90ea4a551e7273614f493bf44522a8273d3ca'
TRANSFORM_SHA = '49ed522430eed5275a7cdc4b6001cbbdc1330119bc06f45924509e379e16acf8'
STAGES = ['format', 'fmt-check', 'harness-tests', 'clippy', 'test-build',
          'isolated-tests', 'audit-isolated-tests', 'release']


def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def encoded(value):
    return (json.dumps(value, sort_keys=True, indent=2, allow_nan=False) + '\n').encode()


def stamp(value):
    return tuple(getattr(value, key) for key in ('st_dev', 'st_ino', 'st_mode',
                 'st_uid', 'st_nlink', 'st_size', 'st_mtime_ns', 'st_ctime_ns'))


def read(path, expected=None, retain=False):
    path = Path(path)
    assert path.is_absolute() and path.resolve(strict=True) == path, str(path)
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_CLOEXEC | os.O_NONBLOCK)
    try:
        before = os.fstat(fd)
        assert stat.S_ISREG(before.st_mode) and before.st_uid == os.geteuid()
        assert before.st_nlink == 1 and not before.st_mode & (stat.S_ISUID | stat.S_ISGID)
        assert 0 <= before.st_size <= 1024**3
        digest, size, blocks = hashlib.sha256(), 0, []
        while block := os.read(fd, 1024 * 1024):
            size += len(block)
            assert size <= before.st_size
            digest.update(block)
            if retain:
                blocks.append(block)
        assert size == before.st_size and stamp(before) == stamp(os.fstat(fd)) == stamp(path.lstat())
        assert expected is None or digest.hexdigest() == expected, str(path)
        return {'path': str(path), 'bytes': size, 'sha256': digest.hexdigest()}, b''.join(blocks)
    finally:
        os.close(fd)


def source_map(root):
    paths = [root / name for name in ('Cargo.toml', 'Cargo.lock', 'rustfmt.toml')]
    for name in ('src', 'examples'):
        paths.extend(path for path in (root / name).rglob('*') if path.is_file())
    return {path.relative_to(root).as_posix(): read(path)[0]['sha256'] for path in sorted(paths)}


def harness_map(root):
    return {path.name: read(path)[0]['sha256']
            for path in sorted((root / 'tools/x230/20261028').glob('*.py'))}


def check_terminal(raw, job_id):
    value = json.loads(raw)
    assert value['job_id'] == job_id and value['state'] == 'succeeded' and value['exit_code'] == 0
    assert all(value[k] is True for k in ('output_complete', 'output_durable', 'terminal_publication_confirmed'))
    assert all(value[k] is False for k in ('automatic_retry', 'cancelled', 'timed_out'))
    assert value['terminal_publication_protocol'] == 1
    for name in ('stdout', 'stderr'):
        assert value['log_synced'][name] is True and value['log_truncated'][name] is False
        assert value['log_errors'][name] is None
        assert value['log_bytes'][name]['seen'] == value['log_bytes'][name]['stored']


def quiescence():
    deadline, samples = time.monotonic() + 300, []
    while True:
        active = []
        for path in Path('/proc').glob('[0-9]*/comm'):
            try:
                name = path.read_text().strip()
                if name in ('cargo', 'rustc', 'rust-lld', 'ld.lld'):
                    active.append({'pid': int(path.parent.name), 'name': name})
            except (FileNotFoundError, ProcessLookupError, PermissionError):
                pass
        samples.append({'utc': utc(), 'compiler_processes': active})
        if not active:
            return samples
        assert time.monotonic() < deadline, 'compiler quiescence unavailable; no cache copy or qualification started'
        if len(samples) == 1:
            print(json.dumps({'waiting_for_compiler_quiescence': active}), flush=True)
        time.sleep(2)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--input-sha256', required=True)
    parser.add_argument('--launcher-sha256', required=True)
    args = parser.parse_args()
    launcher_identity, _ = read(Path(__file__).resolve(), args.launcher_sha256)
    input_identity, input_raw = read(INPUT, args.input_sha256, retain=True)
    payload = json.loads(input_raw)
    assert payload['schema'] == 'hepta-r26-selected-b-qualification-input/v1'
    assert payload['production_selection'] == 'B-only: defer unused Python read JSON'
    assert not os.path.lexists(ROOT), str(ROOT)
    ROOT.mkdir(mode=0o700)
    receipt = {'schema': 'hepta-r26-qualified-parent-preparation/v1', 'started_utc': utc(),
               'passed': False, 'candidate_qualified': False, 'candidate_adopted': False,
               'parent_source_qualified': False, 'parent_candidate_adopted': False,
               'parent_observation_rejection_preserved': False, 'automatic_test_retries': 0,
               'production_services_modified': False, 'shared_hardlinks_created': False,
               'input': input_identity, 'launcher': launcher_identity, 'selected_proposal': 'B only'}
    with (ROOT / 'qualification-input-01.json').open('xb') as stream:
        stream.write(input_raw)
    saved_inputs = {}

    def bind(path, digest):
        identity, raw = read(path, digest, retain=True)
        saved_inputs[str(path)] = identity
        return json.loads(raw)

    result_code = 1
    try:
        parent = bind(PARENT / 'qualification-02/report.json', BASE_REPORT_SHA)
        parent_map = bind(PARENT / 'qualification-02/source-map.json', BASE_MAP_SHA)
        assert parent['qualified'] is True and parent['finished_utc']
        assert parent['source_tested'] == parent['source_after'] == parent_map == source_map(OLD_SOURCE)
        assert len(parent_map) == 221 and [s['name'] for s in parent['stages']] == STAGES
        assert all(s['returncode'] == 0 for s in parent['stages']) and parent['automatic_test_retries'] == 0
        native_identity, native_raw = read(PARENT / 'qualification-terminal-status-02.json',
            '87db6a4da3004f8fe62c94825136a253c6a63b461f0c22cb493462c1f0c48e85', retain=True)
        check_terminal(native_raw, '1a1aaa6552d-fc05-459f')
        saved_inputs[native_identity['path']] = native_identity
        rejection = bind(PARENT / 'campaign-02/report.json', REJECTION_SHA)
        summary = bind(PARENT / 'campaign-02/summary.json', REJECTION_SUMMARY_SHA)
        assert rejection['passed'] is True and rejection['observation_gate_passed'] is False
        assert rejection['inputs_unchanged'] is True and rejection['source_inputs_unchanged'] is True
        assert summary['evidence_verified'] is True and summary['correctness_verified'] is True
        assert summary['observation_gate_passed'] is False
        assert summary['rejection_reasons'] == rejection['rejection_reasons'] == [
            'C1 regression gate', 'C1 controller CPU regression gate']
        receipt.update(parent_source_qualified=True, parent_observation_rejection_preserved=True)
        publication = bind(ACCEPTED / 'final-publication-readback.json', PUBLICATION_SHA)
        assert publication['commit'] == 'baab4def80be7af015b2e7a594cb302f66c4130e'
        assert publication['verified'] is True and publication['candidate_adopted'] is True
        for binary in parent['binaries'].values():
            identity, _ = read(binary['path'], binary['sha256'])
            saved_inputs[identity['path']] = identity
        transform_raw = payload['transform_text'].encode()
        assert hashlib.sha256(transform_raw).hexdigest() == TRANSFORM_SHA
        transform = json.loads(transform_raw)
        assert transform['relative_path'] == JOB_PATH and len(transform['operations']) == 2
        assert transform['before']['sha256'] == parent_map[JOB_PATH]
        identity, original = read(OLD_SOURCE / JOB_PATH, transform['before']['sha256'], retain=True)
        assert identity['bytes'] == transform['before']['bytes']
        candidate = original.decode('utf-8')
        for operation in transform['operations']:
            assert operation['required_matches'] == candidate.count(operation['old']) == 1
            candidate = candidate.replace(operation['old'], operation['new'], 1)
        candidate_raw = candidate.encode('utf-8')
        assert len(candidate_raw) == transform['after']['bytes']
        assert hashlib.sha256(candidate_raw).hexdigest() == transform['after']['sha256']
        expected = dict(parent_map)
        expected[JOB_PATH] = transform['after']['sha256']
        assert payload['candidate_source_map'] == expected
        assert [p for p in expected if expected[p] != parent_map[p]] == [JOB_PATH]
        harness = parent['harness_after']
        assert len(harness) == 19 and parent['harness_before'] == harness_map(OLD_SOURCE) == harness
        receipt['compiler_quiescence'] = quiescence()
        cache = PARENT / 'target-build-02'
        cache_files = [path for path in cache.rglob('*') if path.is_file()]
        cache_bytes = sum(path.stat().st_size for path in cache_files)
        disk = os.statvfs(ROOT)
        available = disk.f_bavail * disk.f_frsize
        assert cache_files and available >= cache_bytes + 3 * 1024**3, (available, cache_bytes)
        preparation_started = time.monotonic()
        shutil.copytree(OLD_SOURCE, SOURCE)
        (SOURCE / JOB_PATH).write_bytes(candidate_raw)
        assert source_map(SOURCE) == expected and source_map(OLD_SOURCE) == parent_map
        assert harness_map(SOURCE) == harness_map(OLD_SOURCE) == harness
        copy_started = time.monotonic()
        shutil.copytree(cache, TARGET)
        receipt.update(source=str(SOURCE), target=str(TARGET), qualification_output=str(OUTPUT),
            source_before=parent_map, candidate_compilation_inputs=expected, harness_before=harness,
            cache_source=str(cache), cache_file_count=len(cache_files), cache_bytes=cache_bytes,
            cache_reused=True, cache_source_source_qualified=True, private_cache_copy_seconds=time.monotonic()-copy_started,
            disk_available_before_bytes=available, preparation_seconds=time.monotonic()-preparation_started,
            source_changes=[{'path': JOB_PATH, 'before': transform['before'], 'after': transform['after']}])
        (ROOT / 'preparation-01.json').write_bytes(encoded(receipt))
        print(json.dumps({'phase': 'prepared', 'source_changes': [JOB_PATH], 'automatic_test_retries': 0}), flush=True)
        argv = ['/usr/bin/python3', '-B', str(SOURCE / 'tools/x230/20261028/qualify.py'),
            '--source', str(SOURCE), '--output', str(OUTPUT), '--target', str(TARGET),
            '--cargo-home', '/home/qian/hepta-runtime-optimization-20261023/cargo-home-a32-a33-r02',
            '--jobs', '2', '--stage-timeout', '3600']
        receipt['qualification_argv'] = argv
        result = subprocess.run(argv, cwd=SOURCE, timeout=10800)
        receipt['qualification_returncode'] = result.returncode
        for path, identity in saved_inputs.items():
            assert read(path)[0] == identity, 'bound parent evidence changed: ' + path
        assert source_map(OLD_SOURCE) == parent_map and harness_map(OLD_SOURCE) == harness_map(SOURCE) == harness
        read(INPUT, args.input_sha256)
        read(Path(__file__).resolve(), args.launcher_sha256)
        receipt['parent_inputs_unchanged'] = True
        qualified_identity, qualified_raw = read(OUTPUT / 'report.json', retain=True)
        qualified = json.loads(qualified_raw)
        receipt['qualification_report'] = qualified_identity
        receipt['candidate_qualified'] = qualified['qualified'] is True
        if result.returncode != 0:
            assert qualified['qualified'] is False
            result_code = result.returncode
        else:
            assert qualified['qualified'] is True and qualified['finished_utc']
            assert qualified['source_tested'] == qualified['source_after'] == source_map(SOURCE)
            assert all(s['returncode'] == 0 for s in qualified['stages'])
            assert [s['name'] for s in qualified['stages']] == STAGES
            assert qualified['automatic_test_retries'] == 0
            assert all(qualified['source_after'][p] == expected[p] for p in expected if p != JOB_PATH)
            test_summary = json.loads(read(OUTPUT / 'isolated-tests/summary.json', retain=True)[1])
            assert [test_summary[k] for k in ('passed','failed','ignored','selected','retries')] == [1653,0,34,1687,0]
            receipt.update(passed=True, tests=test_summary, source_tested=qualified['source_after'],
                           formatter_changed_paths=[p for p in expected if qualified['source_after'][p] != expected[p]])
            result_code = 0
    except Exception as error:
        receipt['error'] = f'{type(error).__name__}: {error}'
        receipt['error_trace'] = traceback.format_exc()
    finally:
        receipt['finished_utc'] = utc()
        receipt['bound_parent_inputs'] = saved_inputs
        (ROOT / 'preparation-01.json').write_bytes(encoded(receipt))
        print(json.dumps({'preparation_and_qualification_passed': receipt['passed'],
                          'candidate_qualified': receipt['candidate_qualified'], 'error': receipt.get('error')}), flush=True)
    return result_code


if __name__ == '__main__':
    raise SystemExit(main())
