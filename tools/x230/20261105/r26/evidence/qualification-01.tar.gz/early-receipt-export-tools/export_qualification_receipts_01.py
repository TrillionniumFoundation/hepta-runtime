#!/usr/bin/env python3
"""Export six actual completed R26 qualification receipts; never run a workload."""
import argparse
import base64
import datetime
import gzip
import hashlib
import io
import json
import os
from pathlib import Path
import re
import stat
import tarfile

ROOT = Path('/home/qian/hepta-runtime-optimization-20261105-r26')
SELF = ROOT / 'evidence-receipts-tools-01/export_qualification_receipts_01.py'
OUT = ROOT / 'evidence-receipts-01'
JOB = '1a1ab4cb0fc-fc05-4c3c'
ARCHIVE = 'qualification-receipts-01.tar.gz'
FILES = {
    'preparation-01.json': ROOT / 'preparation-01.json',
    'qualification-native-terminal-01.json': ROOT / 'qualification-terminal-status-01.json',
    'qualification-report-01.json': ROOT / 'qualification-01/report.json',
    'qualified-source-map-01.json': ROOT / 'qualification-01/source-map.json',
    'isolated-tests-summary-01.json': ROOT / 'qualification-01/isolated-tests/summary.json',
    'isolated-tests-audit-01.json': ROOT / 'qualification-01/isolated-tests.audit.json',
}
STAGES = ['format', 'fmt-check', 'harness-tests', 'clippy', 'test-build',
          'isolated-tests', 'audit-isolated-tests', 'release']
COUNTS = {'passed': 1653, 'failed': 0, 'ignored': 34, 'selected': 1687, 'retries': 0}
HEX = re.compile(r'[0-9a-f]{64}\Z')
MAX_FILE = 16 * 1024 * 1024
MAX_TOTAL = 32 * 1024 * 1024


def need(value, reason):
    if not value:
        raise ValueError(reason)


def encoded(value):
    return (json.dumps(value, sort_keys=True, indent=2, allow_nan=False) + '\n').encode()


def identity(path, raw):
    return {'path': str(path), 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


def stamp(value):
    return {key: getattr(value, key) for key in ('st_dev', 'st_ino', 'st_mode', 'st_uid',
            'st_nlink', 'st_size', 'st_mtime_ns', 'st_ctime_ns')}


def read(path, maximum=MAX_FILE):
    need(path.is_absolute() and path.resolve(strict=True) == path, 'indirect input path')
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK | os.O_CLOEXEC)
    with os.fdopen(fd, 'rb') as stream:
        before = os.fstat(stream.fileno())
        need(stat.S_ISREG(before.st_mode) and before.st_nlink == 1 and before.st_uid == os.geteuid()
             and 0 < before.st_size <= maximum, 'input is not a bounded owned regular file')
        raw = stream.read(maximum + 1)
        after = os.fstat(stream.fileno())
    need(len(raw) == before.st_size and len(raw) <= maximum
         and stamp(before) == stamp(after) == stamp(path.lstat())
         and path.resolve(strict=True) == path, 'input changed during descriptor read')
    return raw, identity(path, raw), stamp(before)


def create(path, raw):
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW | os.O_CLOEXEC, 0o600)
    with os.fdopen(fd, 'wb') as stream:
        stream.write(raw)
        stream.flush()
        os.fsync(stream.fileno())


def verify(raw, terminal_sha):
    p, t, q, source, summary, audit = (json.loads(raw[name]) for name in FILES)
    need(hashlib.sha256(raw['qualification-native-terminal-01.json']).hexdigest() == terminal_sha,
         'original terminal bytes differ from root-supplied receipt SHA')
    need(t['job_id'] == JOB and t['state'] == 'succeeded'
         and type(t['exit_code']) is int and t['exit_code'] == 0, 'original qualification job did not succeed')
    need(all(t[key] is True for key in ('output_complete', 'output_durable', 'terminal_publication_confirmed'))
         and all(t[key] is False for key in ('automatic_retry', 'cancelled', 'timed_out'))
         and type(t['terminal_publication_protocol']) is int and t['terminal_publication_protocol'] == 1,
         'original complete durable terminal is required')
    for channel in ('stdout', 'stderr'):
        need(t['log_synced'][channel] is True and t['log_truncated'][channel] is False
             and t['log_errors'][channel] is None
             and type(t['log_bytes'][channel]['seen']) is int and t['log_bytes'][channel]['seen'] >= 0
             and type(t['log_bytes'][channel]['stored']) is int
             and t['log_bytes'][channel]['seen'] == t['log_bytes'][channel]['stored'],
             'original native log seal is incomplete')
    need(q['schema'] == 'hepta-x230-composed-qualification/v1' and q['qualified'] is True
         and q['finished_utc'] and q['source'] == str(ROOT / 'source')
         and [row['name'] for row in q['stages']] == STAGES
         and all(type(row['returncode']) is int and row['returncode'] == 0 for row in q['stages'])
         and type(q['automatic_test_retries']) is int and q['automatic_test_retries'] == 0,
         'all eight original qualification stages must pass')
    need(q['source_tested'] == q['source_after'] == source and len(source) == 221
         and q['harness_before'] == q['harness_after'] and len(q['harness_after']) == 19,
         'qualified source or harness inventory differs')
    report_identity = identity(FILES['qualification-report-01.json'], raw['qualification-report-01.json'])
    need(p['schema'] == 'hepta-r26-qualified-parent-preparation/v1'
         and type(p.get('finished_utc')) is str and bool(p['finished_utc'])
         and type(p.get('qualification_returncode')) is int and p['qualification_returncode'] == 0
         and type(p.get('automatic_test_retries')) is int and p['automatic_test_retries'] == 0
         and p.get('production_services_modified') is False and p.get('shared_hardlinks_created') is False
         and all(p[key] is True for key in ('passed', 'candidate_qualified', 'parent_source_qualified',
             'parent_observation_rejection_preserved', 'parent_inputs_unchanged'))
         and p['candidate_adopted'] is False and p['parent_candidate_adopted'] is False
         and p['selected_proposal'] == 'B only' and p['qualification_report'] == report_identity
         and p.get('launcher') == {
             'path': '/home/qian/hepta-runtime-optimization-20261105-r25/tools/prepare_and_qualify_r26_01.py',
             'bytes': 14305, 'sha256': '5306935cc2771a1138dc0a641ee4b9d359e00fd152d4be746a630db0b9bb72f7'}
         and p.get('input') == {
             'path': '/home/qian/hepta-runtime-optimization-20261105-r25/tools/r26-qualification-01-input.json',
             'bytes': 27079, 'sha256': '3b6e6a119f09c649c11d4170e59c6d63831d824a2280b435a2ea57defd949111'}
         and p.get('tests') == summary and p['source_tested'] == source,
         'actual original R26 preparation did not pass')
    need(summary['schema'] == 'hepta-isolated-libtest/v1' and summary['success'] is True
         and summary['filter'] == '' and summary['enumeration_errors'] == []
         and all(type(summary[key]) is int and summary[key] == value for key, value in COUNTS.items())
         and summary['source_manifest_sha256'] == hashlib.sha256(raw['qualified-source-map-01.json']).hexdigest(),
         'full original isolated test summary differs')
    need(audit['schema'] == 'hepta-isolated-libtest-audit/v1' and audit['success'] is True
         and audit['errors'] == [] and 'fatal_error' not in audit and audit['expected_filter'] == ''
         and audit['input_sha256']['summary.json'] == hashlib.sha256(raw['isolated-tests-summary-01.json']).hexdigest()
         and all(type(audit[key]) is int and audit[key] == value for key, value in COUNTS.items() if key != 'retries')
         and type(audit['executed']) is int and audit['executed'] == 1653,
         'independent original isolated test audit differs')
    return {'passed': True, 'original_qualification_job_id': JOB, 'stage_names': STAGES,
            'source_files': 221, 'harness_files': 19, 'isolated_test_counts': COUNTS,
            'strong_original_terminal_sha256': terminal_sha,
            'scope': 'six actual original receipt bodies; no runtime source or ELF bodies read or exported'}


def archive_bytes(raw, manifest_raw):
    output = io.BytesIO()
    with gzip.GzipFile(fileobj=output, filename='', mode='wb', compresslevel=9, mtime=0) as gz:
        with tarfile.open(fileobj=gz, mode='w|', format=tarfile.USTAR_FORMAT) as archive:
            for name, body in [('_export-manifest.json', manifest_raw)] + [(name, raw[name]) for name in sorted(raw)]:
                member = tarfile.TarInfo(name)
                member.size, member.mode, member.mtime = len(body), 0o600, 0
                member.uid = member.gid = 0
                member.uname = member.gname = ''
                archive.addfile(member, io.BytesIO(body))
    return output.getvalue()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--exporter-sha256', required=True)
    parser.add_argument('--terminal-sha256', required=True)
    args = parser.parse_args()
    need(os.geteuid() != 0 and Path(__file__).resolve() == SELF, 'fixed native operator exporter path required')
    need(HEX.fullmatch(args.exporter_sha256) and HEX.fullmatch(args.terminal_sha256),
         'actual exporter and original terminal SHA256 required; unresolved draft is not executable')
    _, exporter, _ = read(SELF, 65536)
    need(exporter['sha256'] == args.exporter_sha256, 'exporter source SHA differs')
    root_info = ROOT.lstat()
    need(ROOT.resolve(strict=True) == ROOT and stat.S_ISDIR(root_info.st_mode)
         and root_info.st_uid == os.geteuid(), 'original R26 root is not an owned direct directory')
    need(not os.path.lexists(OUT), 'fresh receipt export directory required; original attempt is not overwritten')
    OUT.mkdir(mode=0o700)
    report = {'schema': 'hepta-r26-qualification-receipts-export/v1', 'passed': False,
              'started_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
              'original_qualification_job_id': JOB, 'exporter': exporter,
              'expected_original_terminal_sha256': args.terminal_sha256,
              'archive': None, 'chunks_manifest': None, 'files': {},
              'benchmarks_executed': False, 'qualification_replayed': False,
              'source_or_binary_modified': False, 'runtime_source_or_elf_bodies_read': False,
              'archive_extracted_or_code_executed': False, 'candidate_adoption_assessed': False}
    try:
        raw, identities, stamps = {}, {}, {}
        for name, path in FILES.items():
            raw[name], identities[name], stamps[name] = read(path)
            need(sum(len(body) for body in raw.values()) <= MAX_TOTAL, 'total receipt bytes exceed fixed bound')
        report['files'] = identities
        proof = verify(raw, args.terminal_sha256)
        manifest = {'schema': 'hepta-r26-qualification-receipts-manifest/v1', 'files': {
            name: {'source_path': str(FILES[name]), 'bytes': identities[name]['bytes'],
                   'sha256': identities[name]['sha256'], 'stable_stat': stamps[name],
                   'ci_freezer_local_name': name} for name in sorted(FILES)},
            'original_qualification_job_id': JOB, 'qualification_proof': proof,
            'original_bytes_preserved': True, 'omitted_bodies': [], 'source_or_elf_bodies_included': False,
            'snapshot_scope': 'six independent descriptor reads with final byte/hash/stat revalidation'}
        manifest_raw = encoded(manifest)
        packed = archive_bytes(raw, manifest_raw)
        create(OUT / 'manifest.json', manifest_raw)
        create(OUT / ARCHIVE, packed)
        packed_again, packed_identity, _ = read(OUT / ARCHIVE, MAX_TOTAL)
        need(packed_again == packed, 'written archive bytes differ')
        chunk_root = OUT / 'chunks'
        chunk_root.mkdir(mode=0o700)
        chunks = []
        for offset in range(0, len(packed), 48000):
            body = packed[offset:offset + 48000]
            text = base64.b64encode(body)
            path = chunk_root / ('chunk-' + f'{len(chunks):05d}' + '.b64')
            create(path, text)
            chunks.append({'path': str(path), 'offset': offset, 'bytes': len(body),
                           'sha256': hashlib.sha256(body).hexdigest(), 'base64_bytes': len(text),
                           'base64_sha256': hashlib.sha256(text).hexdigest()})
        chunk_manifest = {'schema': 'hepta-r26-qualification-receipt-chunks/v1', 'encoding': 'base64',
                          'maximum_decoded_chunk_bytes': 48000, 'maximum_text_file_bytes': 64000,
                          'archive': packed_identity, 'chunks': chunks}
        chunk_raw = encoded(chunk_manifest)
        create(OUT / 'chunks-manifest.json', chunk_raw)
        # Re-read all original descriptors after the archive and transfer chunks exist.
        for name, path in FILES.items():
            after_raw, after_identity, after_stamp = read(path)
            need(after_raw == raw[name] and after_identity == identities[name] and after_stamp == stamps[name],
                 'original receipt changed while creating export: ' + name)
        _, exporter_after, _ = read(SELF, 65536)
        need(exporter_after == exporter, 'exporter source changed')
        report.update(passed=True, qualification_proof=proof, original_files_unchanged=True,
                      archive=packed_identity, manifest=identity(OUT / 'manifest.json', manifest_raw),
                      chunks_manifest=identity(OUT / 'chunks-manifest.json', chunk_raw),
                      original_file_count=6, archive_member_count=7, chunk_count=len(chunks))
    except BaseException as error:
        report['error'] = {'type': type(error).__name__, 'reason': str(error)[:3000]}
    report['finished_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    final = encoded(report)
    create(OUT / 'report.json', final)
    directory_fd = os.open(OUT, os.O_RDONLY | os.O_DIRECTORY)
    try:
        os.fsync(directory_fd)
    finally:
        os.close(directory_fd)
    print(json.dumps({'passed': report['passed'], 'report': identity(OUT / 'report.json', final),
                      'archive': report['archive'], 'error': report.get('error')}, sort_keys=True), flush=True)
    return 0 if report['passed'] else 1


if __name__ == '__main__':
    os.umask(0o077)
    raise SystemExit(main())
