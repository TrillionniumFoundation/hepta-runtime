#!/usr/bin/env python3
"""Create only the reviewed R26 tools after original qualification; run no tools."""
import argparse
import datetime
import hashlib
import io
import json
import os
from pathlib import Path, PurePosixPath
import re
import stat
import sys
import tarfile

sys.dont_write_bytecode = True
STAGE_ROOT = Path('/home/qian/hepta-runtime-optimization-20261105-r25')
ROOT = Path('/home/qian/hepta-runtime-optimization-20261105-r26')
SOURCE = ROOT / 'source'
CANDIDATE_DIR = ROOT / 'qualification-01'
SCRIPT = STAGE_ROOT / 'tools/install_r26_lifecycle_attempt02_tools_04.py'
QUALIFICATION_INPUT = STAGE_ROOT / 'tools/r26-installation-qualification-03.json'
RECEIPT = 'lifecycle-tools-install-04-receipt.json'
NEW_DIRECTORIES = ('tools-04', 'lifecycle-tools-04', 'lifecycle-original01-failure-evidence-04', 'lifecycle-attempt02-protocol-04')
ROOT_FILES = {'lifecycle-inputs-02.example.json'}
MANIFEST_MEMBER = 'lifecycle-attempt02-protocol-04/package-manifest-04.json'
HEX = re.compile(r'[0-9a-f]{64}\Z')
ARCHIVES = {'lifecycle02': {'path': '/home/qian/hepta-runtime-optimization-20261105-r25/staged-r26-lifecycle-attempt02-tools-04.tar.gz', 'bytes': 118902, 'sha256': 'a3c40c20120cdaed2a9150fb3b8c01da938adf0efe5921721d775d0f0c793819', 'member_count': 49, 'expanded_bytes': 533950, 'members': {'tools-04/prepare_lifecycle_inputs.py': {'bytes': 12238, 'sha256': '379ae03a13aedeb16b99bc74234ec42fd72f41c262f6d9a0170ecdefaaddf4b4'}, 'tools-04/r26_lifecycle_campaign.py': {'bytes': 37172, 'sha256': '73435f80156d6b20b0ca8ffadbc7ae583182f3ae78b00949f77a16101522a182'}, 'lifecycle-tools-04/README.md': {'bytes': 9053, 'sha256': '02d016a50e76d58031b07b881bc82440ea49e667e79e21164ca11919a9583eec'}, 'lifecycle-tools-04/allocator_environment.py': {'bytes': 5879, 'sha256': 'f5c8e879c540b3f7cb1b7d3a7a0f5002c2f40c1a87963174b0b00470fa3a4525'}, 'lifecycle-tools-04/allocator_environment_audit.py': {'bytes': 6709, 'sha256': '4b082ce343ae3943e3098baa58af2f5def7198881b9c087d63d88360e9763727'}, 'lifecycle-tools-04/analyze_lifecycle_gates.py': {'bytes': 7581, 'sha256': 'c7a861a94a89dd81debb5c055773918d89a1c9c29b699e2e5a0341e51be69553'}, 'lifecycle-tools-04/analyze_native_observation.py': {'bytes': 8708, 'sha256': 'cc7f6884d581cd1ced430437350e808de51931c50d12441797205501b20cae66'}, 'lifecycle-tools-04/audit_native_evidence.py': {'bytes': 17065, 'sha256': 'b69f6902d2de81eab41b21506f024c002d2f8264d60e86df6b1086623a77fd28'}, 'lifecycle-tools-04/cancel_saturation_gate.py': {'bytes': 15789, 'sha256': '536ebdc5f2b090a8c007f189a895ed2e19d7b8b7e41530ccba94dd826742ef7f'}, 'lifecycle-tools-04/lifecycle-gate-policy.json': {'bytes': 1575, 'sha256': '36658346c4e265bf551a1ae1a4c6210bec8e4729f7961302a203008741cd381e'}, 'lifecycle-tools-04/lifecycle-tools-manifest-01.json': {'bytes': 4066, 'sha256': '4b87b1b7e0430f7419051c0a2716904dbea2baaecf49efc9077eccb1e64d272b'}, 'lifecycle-tools-04/observation_resources.py': {'bytes': 12382, 'sha256': 'f3402d51cb37b2fe20f4351b3a81ec5990a9fdaff93a846d21c07ccd557cb894'}, 'lifecycle-tools-04/owned_ssh_interruption.py': {'bytes': 7892, 'sha256': '1989c57f0b944afae1ed759d6529b8f1cc26197e269e2c34c4fd49e43a32aa7b'}, 'lifecycle-tools-04/run_lifecycle_abba_01.py': {'bytes': 14787, 'sha256': 'f24c358effd4de71e6a68b971fcab3b9fda6db000b79888c48ad364147c1768d'}, 'lifecycle-tools-04/run_lifecycle_tool_tests.py': {'bytes': 2224, 'sha256': 'e3c1e8163249dba14672a3a82b43a2d7b8b4c0802b94b8511bf3db668f865a2d'}, 'lifecycle-tools-04/run_native_observation.py': {'bytes': 3279, 'sha256': '7606648c99b2ff2bbf0bba58384e8cab609ac3899f838c0b80ba54d6288d20bb'}, 'lifecycle-tools-04/run_six_host_cancel_recovery.py': {'bytes': 27847, 'sha256': '698eb7801cde3f2bd5ff202412c0833fc218fd7e912c3c949d2b37fde7a56a12'}, 'lifecycle-tools-04/run_six_host_cancel_recovery_timed.py': {'bytes': 30163, 'sha256': '898bbbc5a30f5dba0f67992e299a5d904b71a1f4a97129c646ef6076a7fc2372'}, 'lifecycle-tools-04/run_six_host_cancel_saturation.py': {'bytes': 31325, 'sha256': 'ec0c84295477619568fb38867d1c3e3101e42746950f4d0cd104b4c0daf006ff'}, 'lifecycle-tools-04/source-provenance.json': {'bytes': 2510, 'sha256': '58d276c8df05dcd95a0a25e6264c3de1b248e8bb821651fb1b52859dd707dbbe'}, 'lifecycle-tools-04/status-predicate.json': {'bytes': 875, 'sha256': '5828c7ba2990f38531cce7e1a42b44315ee42278ccaee361ace8d9472a96da34'}, 'lifecycle-tools-04/summarize_lifecycle_abba_01.py': {'bytes': 16065, 'sha256': '9e050343bb32e7f57148f633ff94bbcfb3a7452b2872ae68404ca642e937af89'}, 'lifecycle-tools-04/test_native_harness.py': {'bytes': 13286, 'sha256': '2b450175b9e6122248ac1bcb51860aa8a6d3eff55f6ac8c877c0a905e3dd7d00'}, 'lifecycle-tools-04/test_r25_lifecycle_tools.py': {'bytes': 10026, 'sha256': '1845cdb48440a03146e337af7baf916bb9cdb76fb46ea0699f79144cf7197566'}, 'lifecycle-tools-04/test_verify_saturation_extension.py': {'bytes': 8187, 'sha256': '10f2dcbfa9e2b5c625f22c3edc32c9f8a969509345b20d9b135cebc2235c16fb'}, 'lifecycle-tools-04/verify_cancel_recovery.py': {'bytes': 16634, 'sha256': '0116652a0b489dc462f005e01d7c943feda9ba784563d7317c92bb5beb9a701c'}, 'lifecycle-tools-04/verify_cancel_saturation.py': {'bytes': 17123, 'sha256': 'd3b6772ddffc711a23aa4aa9566f903c149535a3d3c4cc3466ee73690cbc1e75'}, 'lifecycle-tools-04/verify_saturation_extension.py': {'bytes': 9418, 'sha256': '23dfd25517b517067a4fbb3f4a3227f12bafff46b828eb05f7bf322596124e6a'}, 'lifecycle-tools-04/x230_observation_benchmark.py': {'bytes': 37006, 'sha256': '4d96f0bf2da2562e788f48be7c37589ab3a513be5f9d8b2d741afe5c08ea9eed'}, 'lifecycle-tools-04/x230_six_running_recovery_canary.py': {'bytes': 47298, 'sha256': '6219bc556b0ac6d142bd4c731466b959e8a410f0b4b55f3d8b303f8fdbfbaaf4'}, 'lifecycle-original01-failure-evidence-04/compiler-monitor.audit.json': {'bytes': 1325, 'sha256': '52ed7b65204004a81a80603278a5264bd4d42e6e89ed0232a9e5528a1be962a2'}, 'lifecycle-original01-failure-evidence-04/compiler-monitor.json': {'bytes': 7342, 'sha256': '279709edf6508b3573d6948fb1edbf2dbb00eb315aae010066aadf8c7b1bd674'}, 'lifecycle-original01-failure-evidence-04/mac-forwarded.stderr': {'bytes': 0, 'sha256': 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855'}, 'lifecycle-original01-failure-evidence-04/mac-forwarded.stdout': {'bytes': 261, 'sha256': '24b543d0849eb16d41fef7aa2c804faba99da8630a25f42fd566778a810ea1e2'}, 'lifecycle-original01-failure-evidence-04/mac-remote-script.py': {'bytes': 26760, 'sha256': '2970725473f7dab854a9d13326aa0ca792b9442615d325ebb0e767065bd08f37'}, 'lifecycle-original01-failure-evidence-04/mac-report.json': {'bytes': 9213, 'sha256': 'c5569b1fbeb40acd5f8c10ff33f6bd7afc58c9862ef949309d6c88387bf1bd69'}, 'lifecycle-original01-failure-evidence-04/native-terminal.json': {'bytes': 726, 'sha256': '87f52ad158e945f95976b31d85b720938374bf52ec010acee045e4a819c65aea'}, 'lifecycle-original01-failure-evidence-04/native.stderr': {'bytes': 0, 'sha256': 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855'}, 'lifecycle-original01-failure-evidence-04/native.stdout': {'bytes': 298, 'sha256': 'aaa28ad2cd7a3de525f3427d150b65f59f20b76ef45bfdace7de266c5cc02ff7'}, 'lifecycle-original01-failure-evidence-04/report.json': {'bytes': 7004, 'sha256': '95fe29cf6c69fc98f65d3c12e7c819d9c5a6817c587aad7b7dea7a34093d6270'}, 'lifecycle-original01-failure-evidence-04/root-failure-receipt-01.json': {'bytes': 2324, 'sha256': 'd137a981f1463ee6dc6f9135f89d488db8fc3b68a8f2990ab5f5320dccceeec2'}, 'lifecycle-attempt02-protocol-04/README.md': {'bytes': 2269, 'sha256': '4f8fe1ca57de54f7907911e68f05a0fac30cb89b93d43634881360abba2f6065'}, 'lifecycle-attempt02-protocol-04/admission-checks-01.stderr': {'bytes': 1022, 'sha256': '54024f19f4a555eb752f69dd9b77ea6fbff484d41f2686fbbd5347c47ead51c2'}, 'lifecycle-attempt02-protocol-04/admission-checks-01.stdout': {'bytes': 0, 'sha256': 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855'}, 'lifecycle-attempt02-protocol-04/derivation-proof-04.json': {'bytes': 5718, 'sha256': '83ca66c49e6704c117fab0ba2cf9c65862255f039fda42bc58cf0ab497ba4098'}, 'lifecycle-attempt02-protocol-04/source-delta-04.diff': {'bytes': 18209, 'sha256': '509d1d5cba3d2e8fc45e6d970ccec717261275e57301bc003a5fe7d2f9bd6ba7'}, 'lifecycle-attempt02-protocol-04/test_original01_admission.py': {'bytes': 3224, 'sha256': '8536913788aa84a13b4c1bd32eb4af81f73cd85675e0392d83706846d96c0b96'}, 'lifecycle-inputs-02.example.json': {'bytes': 4406, 'sha256': 'e73f1bc295d29094a6f9fa7cf6142cb6e036693ef6819c15d89aa3794a328851'}, 'lifecycle-attempt02-protocol-04/package-manifest-04.json': {'bytes': 9687, 'sha256': '72ac824593af5d530935d1f005dbab0f382ab2a1cc794257b19e75b95f797811'}}}}
QUALIFICATION_INPUT_PIN = {'path': '/home/qian/hepta-runtime-optimization-20261105-r25/tools/r26-installation-qualification-03.json', 'bytes': 1512, 'sha256': 'a7fff2eebd922c170d68304dc56f3b5213efdcaa50e8a7459b7eb8551d73528d'}
ACTUAL_PREREQUISITES = {'observation': {'path': '/home/qian/hepta-runtime-optimization-20261105-r26/campaign-01/report.json', 'bytes': 106430, 'sha256': 'd9ae83138d356e1e5b6b03176040955b8e231c8c69c051a224cd7468fabc6d7f'}, 'summary': {'path': '/home/qian/hepta-runtime-optimization-20261105-r26/campaign-01/summary.json', 'bytes': 13508, 'sha256': 'bda9fc9d6eefc49c011c2293fef0e706bd59ae00afcef56111e40b362cfbb60f'}, 'monitor_ledger': {'path': '/home/qian/hepta-runtime-optimization-20261105-r26/campaign-01/compiler-monitor.json', 'bytes': 196225, 'sha256': 'd218ae7cd39d1eb275ff75ad0a23d6eaf0e95786ea8d3f7927335fdc7e00d9e4'}, 'monitor_audit': {'path': '/home/qian/hepta-runtime-optimization-20261105-r26/campaign-01/compiler-monitor.audit.json', 'bytes': 841, 'sha256': 'cec3f1d1ff9d648c895f23210c1e89eede5f84ff5bb2cccdfeda5938012c3183'}, 'original01_report': {'path': '/home/qian/hepta-runtime-optimization-20261105-r26/lifecycle-campaign-01/report.json', 'bytes': 7004, 'sha256': '95fe29cf6c69fc98f65d3c12e7c819d9c5a6817c587aad7b7dea7a34093d6270'}, 'original01_ledger': {'path': '/home/qian/hepta-runtime-optimization-20261105-r26/lifecycle-campaign-01/compiler-monitor.json', 'bytes': 7342, 'sha256': '279709edf6508b3573d6948fb1edbf2dbb00eb315aae010066aadf8c7b1bd674'}, 'original01_audit': {'path': '/home/qian/hepta-runtime-optimization-20261105-r26/lifecycle-campaign-01/compiler-monitor.audit.json', 'bytes': 1325, 'sha256': '52ed7b65204004a81a80603278a5264bd4d42e6e89ed0232a9e5528a1be962a2'}}
SHARED_TOOLS = {'helper': {'bytes': 55076, 'path': '/home/qian/hepta-runtime-optimization-20261105-r26/tools-03/r26_campaign.py', 'sha256': '34883c3b7bcae75e81604e7a3fb2845540eef979328010f4f597fdd218f79add'}, 'module': {'bytes': 12510, 'path': '/home/qian/hepta-runtime-optimization-20261105-r26/tools-03/compiler_monitor.py', 'sha256': 'afb514362a9d8dd573b806f0dc87df16bd3a906e4574d10d91bf483b2e76cdcf'}, 'policy': {'bytes': 1001, 'path': '/home/qian/hepta-runtime-optimization-20261105-r26/tools-03/compiler-monitor-policy-01.json', 'sha256': 'ddb2e03d4a1a1610466a5dc2d1a544f554ad12fc31412483101b48a235402368'}, 'reader': {'bytes': 6243, 'path': '/home/qian/hepta-runtime-optimization-20261105-r26/tools-03/compiler_state.py', 'sha256': '9da718654db04a646e081d2d719a2d6d4655ffe337bc0e3f906e736e4d77a251'}, 'validator': {'bytes': 7055, 'path': '/home/qian/hepta-runtime-optimization-20261105-r26/tools-03/validate_compiler_monitor.py', 'sha256': 'd2cd009adf1f35a394ffddcc8f8646cc0c1b856b78181ca321ea68f6468218b2'}}

def need(value, message):
    if not value:
        raise RuntimeError(message)

def encoded(value):
    return (json.dumps(value, sort_keys=True, indent=2, allow_nan=False) + '\n').encode()

def identity(raw):
    return {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}

def stamp(value):
    return tuple(getattr(value, name) for name in
                 ('st_dev', 'st_ino', 'st_uid', 'st_mode', 'st_nlink', 'st_size', 'st_mtime_ns', 'st_ctime_ns'))

def read_path(path, expected=None, maximum=128 * 1024 * 1024, retain=True):
    path = Path(path)
    need(path.is_absolute() and path.resolve(strict=True) == path, 'indirect or missing input path')
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_CLOEXEC | os.O_NONBLOCK)
    try:
        before = os.fstat(fd)
        need(stat.S_ISREG(before.st_mode) and before.st_nlink == 1 and before.st_uid == os.geteuid()
             and 0 <= before.st_size <= maximum, 'unsafe or oversized owned input')
        digest, size, chunks = hashlib.sha256(), 0, []
        while block := os.read(fd, 1024 * 1024):
            size += len(block)
            need(size <= before.st_size, 'input grew while reading')
            digest.update(block)
            if retain:
                chunks.append(block)
        need(size == before.st_size and stamp(before) == stamp(os.fstat(fd)) == stamp(path.lstat()),
             'input identity changed while reading')
    finally:
        os.close(fd)
    result = {'path': str(path), 'bytes': size, 'sha256': digest.hexdigest()}
    if expected is not None:
        need(type(expected.get('bytes')) is int and HEX.fullmatch(expected.get('sha256', ''))
             and result == {key: expected[key] for key in result}, 'actual input identity differs')
    return result, b''.join(chunks)

def read_at(directory, name, expected):
    need(Path(name).name == name, 'only direct file names are permitted')
    fd = os.open(name, os.O_RDONLY | os.O_NOFOLLOW | os.O_CLOEXEC | os.O_NONBLOCK, dir_fd=directory)
    try:
        before = os.fstat(fd)
        need(stat.S_ISREG(before.st_mode) and before.st_nlink == 1 and before.st_uid == os.geteuid()
             and 0 <= before.st_size == expected['bytes'] <= 1048576, 'unsafe installed file')
        with os.fdopen(os.dup(fd), 'rb') as stream:
            raw = stream.read(expected['bytes'] + 1)
        need(stamp(before) == stamp(os.fstat(fd)) == stamp(os.stat(name, dir_fd=directory, follow_symlinks=False))
             and identity(raw) == expected, 'installed file identity differs')
        return {'device': before.st_dev, 'inode': before.st_ino, 'uid': before.st_uid,
                'mode': stat.S_IMODE(before.st_mode), 'links': before.st_nlink, **identity(raw)}
    finally:
        os.close(fd)

def members_from_archive(raw, spec):
    need(identity(raw) == {key: spec[key] for key in ('bytes', 'sha256')}, 'archive identity differs')
    result = {}
    with tarfile.open(fileobj=io.BytesIO(raw), mode='r:gz') as archive:
        entries = archive.getmembers()
        need(len(entries) == spec['member_count'] and sum(entry.size for entry in entries) == spec['expanded_bytes']
             and spec['expanded_bytes'] <= 1048576, 'archive member count or expansion differs')
        for entry in entries:
            path = PurePosixPath(entry.name)
            need(entry.type in (tarfile.REGTYPE, tarfile.AREGTYPE) and not entry.issparse()
                 and not entry.linkname and path.parts and not path.is_absolute()
                 and all(part not in ('.', '..') for part in path.parts)
                 and path.as_posix() == entry.name and entry.name in spec['members']
                 and entry.name not in result, 'unexpected, linked, duplicate or unsafe archive member')
            expected = spec['members'][entry.name]
            need(entry.size == expected['bytes'], 'archive member size differs')
            stream = archive.extractfile(entry)
            need(stream is not None, 'regular member unreadable')
            body = stream.read(expected['bytes'] + 1)
            need(identity(body) == expected, 'archive member SHA differs')
            result[entry.name] = body
        need(set(result) == set(spec['members']), 'archive member set differs')
    return result

def verify_r26_candidate_preparation(preparation, terminal, job_id, qualified, tests):
    """Pure check of actual R26 qualification; no future identity is inferred."""
    need(isinstance(job_id, str) and re.fullmatch(r"[0-9a-f]{11,16}-[0-9a-f]{4}-[0-9a-f]{4}", job_id)
         and job_id not in {"1a1aa7fa690-fc05-43af", "1a1aaa6552d-fc05-459f"},
         "the actual new R26 qualification job is required")
    need(terminal.get("job_id") == job_id and terminal.get("state") == "succeeded"
         and type(terminal.get("exit_code")) is int and terminal["exit_code"] == 0
         and all(terminal.get(key) is False for key in ("automatic_retry", "timed_out", "cancelled"))
         and all(terminal.get(key) is True for key in ("output_complete", "output_durable", "terminal_publication_confirmed"))
         and type(terminal.get("terminal_publication_protocol")) is int and terminal["terminal_publication_protocol"] == 1
         and terminal.get("log_synced") == {"stdout": True, "stderr": True}
         and terminal.get("log_errors") == {"stdout": None, "stderr": None}
         and terminal.get("log_truncated") == {"stdout": False, "stderr": False},
         "original R26 qualification has no complete successful native terminal proof")
    for stream in ("stdout", "stderr"):
        counts = terminal["log_bytes"][stream]
        need(set(counts) == {"seen", "stored"} and all(type(value) is int and value >= 0 for value in counts.values())
             and counts["seen"] == counts["stored"], "qualification native log byte custody differs")
    need(preparation["schema"] == "hepta-r26-qualified-parent-preparation/v1"
         and preparation["selected_proposal"] == "B only" and preparation.get("finished_utc")
         and all(preparation.get(key) is True for key in ("passed", "candidate_qualified", "parent_source_qualified",
             "parent_observation_rejection_preserved", "parent_inputs_unchanged"))
         and all(preparation.get(key) is False for key in ("candidate_adopted", "parent_candidate_adopted",
             "production_services_modified", "shared_hardlinks_created")), "actual R26 preparation is incomplete")
    need(preparation["source"] == str(SOURCE) and preparation["target"] == str(ROOT / "target-build")
         and preparation["qualification_output"] == str(CANDIDATE_DIR)
         and preparation["launcher"]["bytes"] == 14305
         and preparation["launcher"]["sha256"] == "5306935cc2771a1138dc0a641ee4b9d359e00fd152d4be746a630db0b9bb72f7"
         and preparation["input"]["bytes"] == 27079
         and preparation["input"]["sha256"] == "3b6e6a119f09c649c11d4170e59c6d63831d824a2280b435a2ea57defd949111",
         "R26 qualification launcher, input or private paths differ")
    need(type(preparation["qualification_returncode"]) is int and preparation["qualification_returncode"] == 0
         and type(preparation["automatic_test_retries"]) is int and preparation["automatic_test_retries"] == 0,
         "R26 qualification did not finish once with exit zero")
    expected_change = {"path": "src/mcp/runtime/jobs.rs",
        "before": {"bytes": 186495, "sha256": "783f162ffd9be6165da63cd40e4ce28844496c53c8c651926fc359c93904e952"},
        "after": {"bytes": 186504, "sha256": "8a80623ccf9131e520ed5f25647200bd2086e4718b892eed90c1530a5ccb9283"}}
    need(preparation["source_changes"] == [expected_change], "qualified selection is not the exact B-only change")
    before = preparation["source_before"]
    expected = dict(before)
    expected[expected_change["path"]] = expected_change["after"]["sha256"]
    need(len(before) == len(expected) == 221 and before[expected_change["path"]] == expected_change["before"]["sha256"]
         and preparation["candidate_compilation_inputs"] == expected, "R26 pre-format source map differs")
    stages = ["format", "fmt-check", "harness-tests", "clippy", "test-build", "isolated-tests", "audit-isolated-tests", "release"]
    need(qualified["schema"] == "hepta-x230-composed-qualification/v1" and qualified["qualified"] is True
         and qualified.get("finished_utc") and qualified["source"] == str(SOURCE)
         and qualified["jobs"] == 2 and qualified["service_changes"] is False
         and type(qualified["automatic_test_retries"]) is int and qualified["automatic_test_retries"] == 0
         and [row["name"] for row in qualified["stages"]] == stages
         and all(type(row["returncode"]) is int and row["returncode"] == 0 for row in qualified["stages"]),
         "all eight original R26 qualification stages must pass")
    need(qualified["source_input"] == expected and qualified["source_tested"] == qualified["source_after"] == preparation["source_tested"]
         and set(qualified["source_after"]) == set(expected)
         and all(qualified["source_after"][name] == value for name, value in expected.items() if name != expected_change["path"]),
         "actual formatted R26 source differs from its qualified preparation")
    need(preparation["formatter_changed_paths"] == [name for name in expected if qualified["source_after"][name] != expected[name]]
         and qualified["harness_before"] == qualified["harness_after"] == preparation["harness_before"]
         and len(qualified["harness_after"]) == 19, "qualification formatter or original harness binding differs")
    counts = ("passed", "failed", "ignored", "selected", "retries")
    need(all(type(tests[key]) is int for key in counts)
         and [tests[key] for key in counts] == [1653, 0, 34, 1687, 0]
         and preparation["tests"] == tests, "original full R26 isolated test result is incomplete")
    return {"passed": True, "original_job_id": job_id, "selected_proposal": "B only",
            "qualified_source_files": 221, "harness_files": 19, "stages": stages,
            "tests": {key: tests[key] for key in counts}, "candidate_adopted": False,
            "qualified_parent_R25_observation_rejection_preserved": True}

def verify_qualification_documents(value, preparation, terminal, qualified, summary, audit, source_map):
    need(value['schema'] == 'hepta-r26-installation-qualification/v1'
         and value['executed'] is False, 'actual qualification input schema differs')
    proof = verify_r26_candidate_preparation(preparation, terminal, value['original_qualification_job_id'], qualified, summary)
    need(value['original_qualification_job_id'] == '1a1ab4cb0fc-fc05-4c3c',
         'installation requires the observed original R26 qualification job')
    need(type(preparation.get('finished_utc')) is str and bool(preparation['finished_utc'])
         and preparation['qualification_report'] == value['qualification_report']
         and source_map == qualified['source_after'], 'completed preparation/source-map binding differs')
    need(summary['schema'] == 'hepta-isolated-libtest/v1' and summary['success'] is True
         and summary['filter'] == '' and summary['enumeration_errors'] == []
         and summary['source_manifest_path'] == str(CANDIDATE_DIR / 'source-map.json')
         and summary['source_manifest_sha256'] == value['source_map']['sha256'], 'full actual isolated summary differs')
    need(audit['schema'] == 'hepta-isolated-libtest-audit/v1' and audit['success'] is True
         and audit['errors'] == [] and 'fatal_error' not in audit and audit['expected_filter'] == ''
         and audit['input_sha256']['summary.json'] == value['isolated_summary']['sha256']
         and all(audit[key] == summary[key] for key in ('passed', 'failed', 'ignored', 'selected'))
         and audit['executed'] == 1653, 'original independent isolated audit differs')
    return proof

def qualification_prerequisites(value, bind):
    paths = {
        'preparation': ROOT / 'preparation-01.json',
        'native_terminal': ROOT / 'qualification-terminal-status-01.json',
        'qualification_report': CANDIDATE_DIR / 'report.json',
        'source_map': CANDIDATE_DIR / 'source-map.json',
        'isolated_summary': CANDIDATE_DIR / 'isolated-tests/summary.json',
        'isolated_audit': CANDIDATE_DIR / 'isolated-tests.audit.json',
    }
    documents = {}
    for name, path in paths.items():
        need(value[name]['path'] == str(path), 'actual qualification receipt path differs')
        _, raw = bind(path, value[name])
        documents[name] = json.loads(raw)
    proof = verify_qualification_documents(value, documents['preparation'], documents['native_terminal'],
        documents['qualification_report'], documents['isolated_summary'], documents['isolated_audit'], documents['source_map'])
    qualified = documents['qualification_report']
    paths = [SOURCE / name for name in ('Cargo.toml', 'Cargo.lock', 'rustfmt.toml')]
    for name in ('src', 'examples'):
        paths.extend(path for path in (SOURCE / name).rglob('*') if path.is_file())
    actual = {path.relative_to(SOURCE).as_posix(): bind(path, retain=False)[0]['sha256'] for path in sorted(paths)}
    need(actual == qualified['source_after'], 'actual qualified source changed before tool installation')
    harness = {path.name: bind(path, retain=False)[0]['sha256']
               for path in sorted((SOURCE / 'tools/x230/20261028').glob('*.py'))}
    need(harness == qualified['harness_after'], 'actual qualification harness changed')
    binaries = {}
    need(set(qualified['binaries']) == {'hepta-runtime', 'hepta-runtime-jobctl', 'native_process_driver'},
         'qualified executable set differs')
    for name, item in qualified['binaries'].items():
        path = CANDIDATE_DIR / name
        need(item['path'] == str(path) and os.access(path, os.X_OK), 'qualified artifact path differs')
        row, _ = bind(path, retain=False)
        need(row['sha256'] == item['sha256'], 'actual qualified executable changed')
        binaries[name] = row
    for label in ('launcher', 'input'):
        item = documents['preparation'][label]
        need(Path(item['path']).parent == STAGE_ROOT / 'tools', 'qualification bootstrap input path differs')
        bind(item['path'], item, retain=False)
    proof.update(actual_binaries=binaries, source_files=len(actual), harness_files=len(harness))
    return proof

def absent(directory, name):
    try:
        os.stat(name, dir_fd=directory, follow_symlinks=False)
    except FileNotFoundError:
        return
    raise RuntimeError('existing destination must not be replaced: ' + name)

def create_file(directory, name, raw):
    need(Path(name).name == name, 'direct destination required')
    fd = os.open(name, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW | os.O_CLOEXEC, 0o600, dir_fd=directory)
    with os.fdopen(fd, 'wb') as stream:
        stream.write(raw)
        stream.flush()
        os.fsync(stream.fileno())
    result = read_at(directory, name, identity(raw))
    need(result['mode'] == 0o600, 'created file is not private')
    return result

def build_installation(bundles):
    payload = bundles['lifecycle02']
    manifest = json.loads(payload[MANIFEST_MEMBER])
    need(manifest['schema'] == 'hepta-r26-lifecycle-attempt02-tools/v1'
         and manifest['attempt'] == '02' and manifest['tool_revision'] == '04'
         and manifest['destination_root'] == str(ROOT)
         and manifest['create_only'] is True and manifest['prepared_only'] is True
         and set(manifest['files']) == set(payload) - {MANIFEST_MEMBER}, 'attempt02 payload manifest differs')
    for name, pin in manifest['files'].items():
        need(identity(payload[name]) == pin, 'attempt02 payload identity differs')
    example = json.loads(payload['lifecycle-inputs-02.example.json'])
    need(example['attempt'] == '02' and example['candidate_release'] == 'R26'
         and example['launcher_sha256'] == identity(payload['tools-04/r26_lifecycle_campaign.py'])['sha256']
         and example['tools_manifest'] == {'path': str(ROOT / 'lifecycle-tools-04/lifecycle-tools-manifest-01.json'),
              **identity(payload['lifecycle-tools-04/lifecycle-tools-manifest-01.json'])}
         and example['campaign_helpers'] == SHARED_TOOLS['helper']
         and example['compiler_monitor'] == {key: value for key, value in SHARED_TOOLS.items() if key != 'helper'},
         'actual parent/native/shared source binding differs')
    need(example['source_inputs_sha256'] is None and example['qualification_terminal_status']['job_id'] is None
         and all(row == {'bytes': None, 'sha256': None} for row in example['candidate_binaries'].values()),
         'candidate input must be materialized from actual receipts, not a manufactured future result')
    native = json.loads(payload['lifecycle-tools-04/lifecycle-tools-manifest-01.json'])
    need(native['schema'] == 'hepta-r25-lifecycle-tools/v1' and len(native['files']) == 27,
         'original 27 native tool set differs')
    for name, pin in native['files'].items():
        need(Path(name).name == name and identity(payload['lifecycle-tools-04/' + name]) == pin,
             'native tool identity differs')
    plan = []
    for relative, raw in sorted(payload.items()):
        path = PurePosixPath(relative)
        need(path.as_posix() == relative and not path.is_absolute() and '..' not in path.parts
             and ((path.parent.as_posix() == '.' and relative in ROOT_FILES)
                  or path.parent.as_posix() in NEW_DIRECTORIES), 'destination outside named fresh scope')
        plan.append((relative, raw, 'lifecycle02', relative))
    need(len(plan) == ARCHIVES['lifecycle02']['member_count'], 'installation file count differs')
    return plan


def actual_lifecycle_prerequisites(bundles, bind):
    documents, proofs = {}, {}
    for label, pin in ACTUAL_PREREQUISITES.items():
        row, raw = bind(pin['path'], pin)
        proofs[label] = row
        documents[label] = json.loads(raw)
    for pin in SHARED_TOOLS.values():
        bind(pin['path'], pin, retain=False)
    observed, failed = documents['observation'], documents['original01_report']
    need(observed['schema'] == 'hepta-r25-observation-campaign-control/v1' and observed.get('finished_utc')
         and all(observed.get(key) is True for key in ('passed', 'observation_gate_passed', 'measurement_attribution_valid'))
         and observed['automatic_retries'] == 0
         and all(row.get('passed') is True and row.get('waited_and_reaped') is True
                 and row.get('owned_process_absent') is True and row.get('owned_process_group_absent') is True
                 for row in observed['stages']), 'original completed observation did not pass or close')
    need(documents['summary']['observation_gate_passed'] is True and documents['summary']['rejection_reasons'] == []
         and documents['monitor_audit']['validation']['passed'] is True,
         'actual completed observation summary/monitor audit differs')
    need(failed.get('finished_utc') and failed.get('stages') == [] and 'stage_plan' not in failed
         and failed.get('passed') is False and failed.get('adoption_passed') is False
         and failed.get('error') == {'type': 'RuntimeError',
             'reason': 'initial compiler monitor sample failed; no lifecycle fixture submitted'},
         'original lifecycle01 is not the specific closed pre-fixture failure')
    payload = bundles['lifecycle02']
    for label, filename in (('original01_report', 'report.json'), ('original01_ledger', 'compiler-monitor.json'),
                            ('original01_audit', 'compiler-monitor.audit.json')):
        need(identity(payload['lifecycle-original01-failure-evidence-04/' + filename])
             == {key: proofs[label][key] for key in ('bytes', 'sha256')}, 'actual original01 differs from retained copy')
    for attempt in ('01', '02'):
        for name in ('lifecycle-abba-', 'cancel-saturation-', 'lifecycle-tool-tests-'):
            need(not os.path.lexists(ROOT / (name + attempt)), 'existing lifecycle fixture outputs require reconciliation')
    for name in ('lifecycle-inputs-02.json', 'lifecycle-campaign-02'):
        need(not os.path.lexists(ROOT / name), 'new lifecycle attempt output must be absent')
    for number in ('1', '2'):
        for name in ('r26lc' + number, 'r26sat' + number):
            need(not os.path.lexists(Path('/home/qian') / name), 'lifecycle socket path is not fresh')
        for index, arm in enumerate('ABBA'):
            need(not os.path.lexists(Path('/home/qian') / ('r26lc' + number + '-' + str(index) + '-' + arm)),
                 'derived lifecycle socket path is not fresh')
    return {'original01_failed_before_fixtures': True, 'original01_job_id': '1a1ababc175-fc05-4f94',
            'observation01_passed': True, 'actual_prerequisites': proofs,
            'shared_tools03_preserved': SHARED_TOOLS, 'fresh_attempt': '02'}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--installer-sha256', required=True)
    args = parser.parse_args()
    need(sys.platform == 'linux' and os.geteuid() != 0 and HEX.fullmatch(args.installer_sha256),
         'native Linux operator and reviewed source SHA required')
    need(Path(__file__).resolve() == SCRIPT and ROOT.resolve(strict=True) == ROOT,
         'fixed installer and existing qualifier-created R26 root required')
    os.umask(0o077)
    bindings, directories, created, created_dirs = [], {}, [], []
    root_fd = os.open(ROOT, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW | os.O_CLOEXEC)

    def bind(path, expected=None, retain=True):
        row, raw = read_path(path, expected, retain=retain)
        bindings.append(row)
        return row, raw

    try:
        before = os.fstat(root_fd)
        need(before.st_uid == os.geteuid() and stat.S_IMODE(before.st_mode) == 0o700,
             'qualifier-created root is not owned private0700')
        own, _ = bind(SCRIPT)
        need(own['sha256'] == args.installer_sha256, 'reviewed installer source changed')
        input_identity, raw = bind(QUALIFICATION_INPUT, QUALIFICATION_INPUT_PIN)
        qualification = qualification_prerequisites(json.loads(raw), bind)
        bundles, archive_rows = {}, {}
        for label, spec in ARCHIVES.items():
            need(Path(spec['path']).parent == STAGE_ROOT, 'staged archive is outside existing R25 root')
            row, raw = bind(spec['path'], spec)
            bundles[label] = members_from_archive(raw, spec)
            archive_rows[label] = dict(row, member_count=len(bundles[label]))
        plan = build_installation(bundles)
        lifecycle_admission = actual_lifecycle_prerequisites(bundles, bind)
        # Only the named destinations are checked. Existing unrelated parent
        # entries, including binary_write's persistent locks, are not enumerated.
        for name in (*[d for d in NEW_DIRECTORIES if '/' not in d], *sorted(ROOT_FILES), RECEIPT):
            absent(root_fd, name)
        for row in bindings:
            need(read_path(row['path'], row, retain=False)[0] == row, 'prerequisite changed before installation')
        # No mutation occurs before all actual qualification and archive gates.
        for relative in NEW_DIRECTORIES:
            path = PurePosixPath(relative)
            owner_fd = root_fd if path.parent.as_posix() == '.' else directories[path.parent.as_posix()]
            os.mkdir(path.name, mode=0o700, dir_fd=owner_fd)
            fd = os.open(path.name, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW | os.O_CLOEXEC, dir_fd=owner_fd)
            current = os.fstat(fd)
            need(current.st_uid == os.geteuid() and stat.S_IMODE(current.st_mode) == 0o700, 'created directory ownership differs')
            directories[relative] = fd
            created_dirs.append(relative)
        installed = []
        for relative, raw, label, member in plan:
            path = PurePosixPath(relative)
            owner_fd = root_fd if path.parent.as_posix() == '.' else directories[path.parent.as_posix()]
            row = create_file(owner_fd, path.name, raw)
            created.append(relative)
            installed.append(dict(row, path=str(ROOT / relative), archive=label, member=member))
        for relative, fd in directories.items():
            os.fsync(fd)
            path = PurePosixPath(relative)
            owner_fd = root_fd if path.parent.as_posix() == '.' else directories[path.parent.as_posix()]
            need(stamp(os.fstat(fd)) == stamp(os.stat(path.name, dir_fd=owner_fd, follow_symlinks=False)),
                 'installed directory identity changed')
        for relative, raw, _, _ in plan:
            path = PurePosixPath(relative)
            read_at(root_fd if path.parent.as_posix() == '.' else directories[path.parent.as_posix()], path.name, identity(raw))
        for row in bindings:
            need(read_path(row['path'], row, retain=False)[0] == row, 'original prerequisite changed during installation')
        need(os.fstat(root_fd).st_ino == ROOT.lstat().st_ino and os.fstat(root_fd).st_dev == ROOT.lstat().st_dev,
             'original root directory was replaced')
        report = {'schema': 'hepta-r26-reviewed-tools-install/v2', 'installed': True,
                  'finished_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
                  'installer': own, 'actual_qualification_input': input_identity, 'qualification': qualification,
                  'tool_revision': '04', 'fresh_lifecycle_attempt': '02', 'lifecycle_admission': lifecycle_admission,
                  'archives': archive_rows, 'created_directories': created_dirs, 'installed_file_count': len(installed),
                  'files': installed, 'input_bindings': bindings, 'all_destinations_initially_absent': True,
                  'manual_regular_member_extraction': True, 'all_files_and_archives_rehashed': True,
                  'source_or_cache_modified': False, 'production_services_modified': False,
                  'packaged_code_executed': False, 'tests_run': 0, 'campaigns_started': 0, 'automatic_retries': 0}
        receipt = create_file(root_fd, RECEIPT, encoded(report))
        os.fsync(root_fd)
        print(json.dumps({'installed': True, 'installed_file_count': len(installed),
                          'receipt': dict(receipt, path=str(ROOT / RECEIPT)), 'tests_run': 0,
                          'campaigns_started': 0, 'source_or_cache_modified': False}), flush=True)
    except BaseException as error:
        print(json.dumps({'installed': False, 'created_files': created, 'created_directories': created_dirs,
                          'error': {'type': type(error).__name__, 'reason': str(error)},
                          'automatic_retries': 0, 'tests_run': 0, 'campaigns_started': 0}), flush=True)
        raise
    finally:
        for fd in reversed(list(directories.values())):
            os.close(fd)
        os.close(root_fd)

if __name__ == '__main__':
    main()
