#!/usr/bin/env python3
"""Synthetic prerequisite composition checks; never run a native job or workload."""
import copy
import importlib.util
import json
from pathlib import Path
import unittest

HERE = Path(__file__).resolve().parent


def module(name, filename):
    spec = importlib.util.spec_from_file_location(name, HERE / "tools-03" / filename)
    value = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(value)
    return value


parent = module("r26_test_parent", "r26_campaign.py")
observation = module("r26_test_observation_materializer", "prepare_campaign_inputs.py")
lifecycle = module("r26_test_lifecycle_materializer", "prepare_lifecycle_inputs.py")
life_parent = module("r26_test_lifecycle_parent", "r26_lifecycle_campaign.py")


def synthetic_success():
    """Protocol-shaped values only; this ID and these maps are never real evidence."""
    job = "deadbeef0001-0000-0000"
    source = {f"src/synthetic_{number:03d}.rs": "1" * 64 for number in range(220)}
    source["src/mcp/runtime/jobs.rs"] = "783f162ffd9be6165da63cd40e4ce28844496c53c8c651926fc359c93904e952"
    after = dict(source)
    after["src/mcp/runtime/jobs.rs"] = "8a80623ccf9131e520ed5f25647200bd2086e4718b892eed90c1530a5ccb9283"
    harness = {f"synthetic_{number}.py": "2" * 64 for number in range(19)}
    tests = dict(passed=1653, failed=0, ignored=34, selected=1687, retries=0, synthetic_only=True)
    stages = ["format", "fmt-check", "harness-tests", "clippy", "test-build", "isolated-tests", "audit-isolated-tests", "release"]
    qualified = {"schema": "hepta-x230-composed-qualification/v1", "qualified": True,
        "finished_utc": "synthetic-finished", "source": str(parent.SOURCE), "jobs": 2,
        "service_changes": False, "automatic_test_retries": 0,
        "stages": [{"name": name, "returncode": 0} for name in stages],
        "source_input": after, "source_tested": after, "source_after": after,
        "harness_before": harness, "harness_after": harness}
    preparation = {"schema": "hepta-r26-qualified-parent-preparation/v1", "selected_proposal": "B only",
        "finished_utc": "synthetic-finished", "passed": True, "candidate_qualified": True,
        "parent_source_qualified": True, "parent_observation_rejection_preserved": True,
        "parent_inputs_unchanged": True, "candidate_adopted": False, "parent_candidate_adopted": False,
        "production_services_modified": False, "shared_hardlinks_created": False,
        "source": str(parent.SOURCE), "target": str(parent.ROOT / "target-build"),
        "qualification_output": str(parent.CANDIDATE_DIR),
        "launcher": {"bytes": 14305, "sha256": "5306935cc2771a1138dc0a641ee4b9d359e00fd152d4be746a630db0b9bb72f7"},
        "input": {"bytes": 27079, "sha256": "3b6e6a119f09c649c11d4170e59c6d63831d824a2280b435a2ea57defd949111"},
        "qualification_returncode": 0, "automatic_test_retries": 0,
        "source_changes": [{"path": "src/mcp/runtime/jobs.rs",
            "before": {"bytes": 186495, "sha256": source["src/mcp/runtime/jobs.rs"]},
            "after": {"bytes": 186504, "sha256": after["src/mcp/runtime/jobs.rs"]}}],
        "source_before": source, "candidate_compilation_inputs": after,
        "source_tested": after, "formatter_changed_paths": [], "harness_before": harness, "tests": tests}
    terminal = {"job_id": job, "state": "succeeded", "exit_code": 0, "automatic_retry": False,
        "timed_out": False, "cancelled": False, "output_complete": True, "output_durable": True,
        "terminal_publication_confirmed": True, "terminal_publication_protocol": 1,
        "log_synced": {"stdout": True, "stderr": True}, "log_errors": {"stdout": None, "stderr": None},
        "log_truncated": {"stdout": False, "stderr": False},
        "log_bytes": {"stdout": {"seen": 10, "stored": 10}, "stderr": {"seen": 0, "stored": 0}}}
    return preparation, terminal, job, qualified, tests


class Prerequisites(unittest.TestCase):
    def verify(self, values):
        return parent.verify_r26_candidate_preparation(*values)

    def test_complete_synthetic_chain(self):
        proof = self.verify(synthetic_success())
        self.assertTrue(proof["passed"])
        self.assertFalse(proof["candidate_adopted"])

    def test_unfinished_or_failed_preparation_never_closes(self):
        for field in ("passed", "candidate_qualified", "parent_inputs_unchanged", "parent_observation_rejection_preserved"):
            with self.subTest(field=field):
                values = synthetic_success()
                values[0][field] = False
                with self.assertRaises(RuntimeError):
                    self.verify(values)

    def test_missing_or_old_native_job_and_incomplete_streams_reject(self):
        for job in (None, "1a1aa7fa690-fc05-43af", "1a1aaa6552d-fc05-459f"):
            values = list(synthetic_success())
            values[2] = job
            values[1]["job_id"] = job
            with self.subTest(job=job), self.assertRaises(RuntimeError):
                self.verify(values)
        for field in ("output_complete", "output_durable", "terminal_publication_confirmed"):
            values = synthetic_success()
            values[1][field] = False
            with self.subTest(field=field), self.assertRaises(RuntimeError):
                self.verify(values)
        values = synthetic_success()
        values[1]["log_bytes"]["stdout"]["stored"] = 9
        with self.assertRaises(RuntimeError):
            self.verify(values)

    def test_cross_record_source_or_selected_patch_mismatch_rejects(self):
        values = synthetic_success()
        values[0]["source_changes"][0]["after"]["sha256"] = "f" * 64
        with self.assertRaises(RuntimeError):
            self.verify(values)
        values = copy.deepcopy(synthetic_success())
        values[3]["source_after"] = dict(values[3]["source_after"], extra="f" * 64)
        values[3]["source_tested"] = values[3]["source_after"]
        values[0]["source_tested"] = values[3]["source_after"]
        with self.assertRaises(RuntimeError):
            self.verify(values)

    def test_missing_stage_failed_test_retry_or_harness_change_rejects(self):
        changes = (lambda v: v[3]["stages"].pop(),
                   lambda v: v[3]["stages"][4].update(returncode=1),
                   lambda v: v[4].update(failed=1, passed=1652),
                   lambda v: v[4].update(retries=1),
                   lambda v: v[3].update(harness_after={}))
        for change in changes:
            values = copy.deepcopy(synthetic_success())
            change(values)
            with self.subTest(change=change), self.assertRaises(RuntimeError):
                self.verify(values)

    def test_unknown_future_inputs_are_explicit_nulls(self):
        cases = ((observation, "campaign-inputs-01.example.json"),
                 (lifecycle, "lifecycle-inputs-01.example.json"))
        for implementation, name in cases:
            value = json.loads((HERE / name).read_bytes())
            implementation.validate_template(value)
            with self.subTest(template=name):
                mutated = copy.deepcopy(value)
                mutated["qualification_terminal_status"]["job_id"] = "deadbeef0001-0000-0000"
                with self.assertRaises(RuntimeError):
                    implementation.validate_template(mutated)
                mutated = copy.deepcopy(value)
                mutated["candidate_binaries"]["hepta-runtime"] = {"bytes": 1, "sha256": "f" * 64}
                with self.assertRaises(RuntimeError):
                    implementation.validate_template(mutated)

    def test_rejected_observation_cannot_authorize_lifecycle(self):
        value = {"schema": "hepta-r25-observation-campaign-control/v1", "passed": True,
                 "observation_gate_passed": False}
        with self.assertRaises(RuntimeError):
            life_parent.completed_observation(value)


if __name__ == "__main__":
    unittest.main(verbosity=2)
