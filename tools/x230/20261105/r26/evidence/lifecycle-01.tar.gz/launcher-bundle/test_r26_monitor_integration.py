#!/usr/bin/env python3
"""Synthetic R26 composition tests; no /proc sampling, job, SSH or benchmark."""
import ast
import contextlib
import copy
import hashlib
import importlib.util
import json
from pathlib import Path
import shutil
import sys
import tempfile
import unittest
from unittest import mock

HERE = Path(__file__).resolve().parent
OLD = HERE.with_name("r26-tools-01")
spec = importlib.util.spec_from_file_location("r26_monitor_integration_test_parent", HERE / "tools-03/r26_campaign.py")
parent = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = parent
spec.loader.exec_module(parent)


def identity(path):
    raw = path.read_bytes()
    return {"path": str(path), "bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest()}


def synthetic_ledger():
    start, body_start, body_end, finish = 1_000_000_000, 1_050_000_000, 3_350_000_000, 3_401_000_000
    rows = []
    for kind, slot, stamp in (("periodic", 0, 1_001_000_000), ("periodic", 1, 2_001_000_000),
                               ("periodic", 2, 3_001_000_000), ("final", None, 3_400_000_000)):
        rows.append({"kind": kind, "slot": slot,
            "scheduled_monotonic_ns": None if slot is None else start + slot * 1_000_000_000,
            "started_monotonic_ns": stamp, "finished_monotonic_ns": stamp + 100_000,
            "thread_cpu_ns": 10_000, "error": None,
            "snapshot": {"schema": "hepta-compiler-state-sample/v1",
                "started_monotonic_ns": stamp + 1, "finished_monotonic_ns": stamp + 99_999,
                "records": [], "blocking_records": [], "quiescent": True,
                "cmdline_or_environment_read": False, "signals_sent": 0, "enumerated_process_directories": 3}})
    return {"schema": "hepta-bounded-compiler-monitor/v1", "synthetic_test_only": True,
        "passed": True, "limits": parent.COMPILER_MONITOR_LIMITS,
        "parent_started_monotonic_ns": body_start, "parent_finished_monotonic_ns": body_end,
        "monitor_started_monotonic_ns": start, "monitor_finished_monotonic_ns": finish,
        "native_thread_id": 12345, "thread_joined": True, "thread_cpu_ns": 100_000,
        "wall_ns": finish-start, "thread_cpu_seconds_per_wall_second": 100_000/(finish-start),
        "covers_parent_lifecycle": True, "sample_count": len(rows),
        "serialized_sample_bytes": sum(len(json.dumps(row, separators=(",", ":")).encode()) for row in rows),
        "compiler_records": 0, "missed_scheduled_slots": 0, "required_slots_through_parent_end": 3,
        "observed_required_slots": [0, 1, 2], "errors": [], "errors_dropped": 0, "samples": rows,
        "hot_loop_file_writes": 0, "signals_sent": 0, "argv_or_environment_read": False,
        "statement_scope": "Synthetic local test fixture only"}


class FakeMonitor:
    def __init__(self, ledger=None, error=None):
        self.ledger, self.error, self.calls = ledger, error, 0

    def stop(self, start, end):
        self.calls += 1
        if self.error:
            raise self.error
        assert (start, end) == (self.ledger["parent_started_monotonic_ns"], self.ledger["parent_finished_monotonic_ns"])
        return copy.deepcopy(self.ledger)


@contextlib.contextmanager
def fixture():
    with tempfile.TemporaryDirectory() as temporary:
        root = Path(temporary)
        tools = root / "tools-03"
        tools.mkdir()
        paths = {}
        for key, old_path in parent.COMPILER_MONITOR_PATHS.items():
            destination = tools / old_path.name
            shutil.copyfile(HERE / "tools-03" / old_path.name, destination)
            paths[key] = destination
        inputs = {"compiler_monitor": {key: identity(path) for key, path in paths.items()}}
        def bind(path, expected=None, retain=False, maximum=128 * 1024 * 1024):
            return parent.checked(path, expected, maximum, retain)
        with mock.patch.object(parent, "ROOT", root), mock.patch.object(parent, "COMPILER_MONITOR_PATHS", paths):
            raw, proof = parent.bind_compiler_monitor_inputs(inputs, bind)
            validator = parent.monitor_module("r26_synthetic_monitor_validator", raw["validator"], paths["validator"])
            out = root / "campaign-01"
            out.mkdir()
            yield root, paths, inputs, bind, proof, validator, out


class IntegrationTests(unittest.TestCase):
    def test_original_ownership_and_workload_ast_unchanged(self):
        def functions(path):
            return {node.name: ast.dump(node, include_attributes=False) for node in ast.walk(ast.parse(path.read_text()))
                    if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef))}
        for name in ("r26_campaign.py", "r26_lifecycle_campaign.py"):
            before, after = functions(OLD / "tools-01" / name), functions(HERE / "tools-03" / name)
            self.assertEqual(before["run_stage"], after["run_stage"])
        before, after = functions(OLD / "tools-01/r26_campaign.py"), functions(HERE / "tools-03/r26_campaign.py")
        for name in ("commands", "process_identity", "group_present", "verify_r26_candidate_preparation"):
            self.assertEqual(before[name], after[name])
        old_files = {path.relative_to(OLD / "lifecycle-tools-01"): path.read_bytes()
                     for path in (OLD / "lifecycle-tools-01").rglob("*") if path.is_file()}
        new_files = {path.relative_to(HERE / "lifecycle-tools-03"): path.read_bytes()
                     for path in (HERE / "lifecycle-tools-03").rglob("*") if path.is_file()}
        self.assertEqual(old_files, new_files)

    def test_missing_monitor_inputs_reject_before_any_bind(self):
        binder = mock.Mock(side_effect=AssertionError("unexpected file read"))
        with self.assertRaisesRegex(RuntimeError, "four frozen"):
            parent.bind_compiler_monitor_inputs({}, binder)
        binder.assert_not_called()

    def test_complete_synthetic_ledger_roundtrip_and_independent_consumer(self):
        with fixture() as (_, _, inputs, bind, proof, validator, out):
            ledger = synthetic_ledger()
            monitor = FakeMonitor(ledger)
            report = {"synthetic_test_only": True, "passed": True, "observation_gate_passed": True,
                      "inputs_unchanged": True, "rejection_reasons": []}
            parent.finish_compiler_monitor(monitor, validator, proof, ledger["parent_started_monotonic_ns"],
                ledger["parent_finished_monotonic_ns"], out, report, "observation_gate_passed")
            self.assertEqual(monitor.calls, 1)
            self.assertTrue(report["measurement_attribution_valid"])
            self.assertTrue(report["passed"])
            self.assertTrue(parent.verify_completed_compiler_monitor(report, inputs, bind, out)["passed"])

    def test_missing_slot_with_true_flag_retains_raw_but_cannot_authorize(self):
        with fixture() as (_, _, inputs, bind, proof, validator, out):
            ledger = synthetic_ledger()
            ledger["samples"].pop(1)
            ledger["sample_count"] = len(ledger["samples"])
            ledger["serialized_sample_bytes"] = sum(len(json.dumps(row, separators=(",", ":")).encode()) for row in ledger["samples"])
            ledger["observed_required_slots"] = [0, 2]
            report = {"passed": True, "observation_gate_passed": True, "inputs_unchanged": True}
            monitor = FakeMonitor(ledger)
            parent.finish_compiler_monitor(monitor, validator, proof, ledger["parent_started_monotonic_ns"],
                ledger["parent_finished_monotonic_ns"], out, report, "observation_gate_passed")
            self.assertEqual(monitor.calls, 1)
            self.assertFalse(report["measurement_attribution_valid"])
            self.assertFalse(report["observation_gate_passed"])
            self.assertTrue(report["result_before_compiler_monitor"]["observation_gate_passed"])
            self.assertEqual(json.loads((out / "compiler-monitor.json").read_bytes())["samples"], ledger["samples"])
            with self.assertRaises(RuntimeError):
                parent.verify_completed_compiler_monitor(report, inputs, bind, out)

    def test_source_change_preserves_samples_and_invalidates_inputs(self):
        with fixture() as (_, paths, _, _, proof, validator, out):
            ledger = synthetic_ledger()
            paths["reader"].write_bytes(paths["reader"].read_bytes() + b"\n# synthetic mutation after binding\n")
            report = {"passed": True, "observation_gate_passed": True, "inputs_unchanged": True}
            parent.finish_compiler_monitor(FakeMonitor(ledger), validator, proof, ledger["parent_started_monotonic_ns"],
                ledger["parent_finished_monotonic_ns"], out, report, "observation_gate_passed")
            self.assertFalse(report["measurement_attribution_valid"])
            self.assertFalse(report["inputs_unchanged"])
            self.assertEqual(json.loads((out / "compiler-monitor.json").read_bytes())["samples"], ledger["samples"])
            self.assertTrue(json.loads((out / "compiler-monitor.audit.json").read_bytes())["source_recheck_errors"])

    def test_stop_failure_never_retries_or_overwrites_original_decision(self):
        with fixture() as (_, _, _, _, proof, validator, out):
            monitor = FakeMonitor(error=RuntimeError("synthetic stop failure"))
            report = {"passed": True, "adoption_passed": True}
            parent.finish_compiler_monitor(monitor, validator, proof, 1, 2, out, report, "adoption_passed")
            self.assertEqual(monitor.calls, 1)
            self.assertFalse(report["adoption_passed"])
            self.assertTrue(report["result_before_compiler_monitor"]["adoption_passed"])
            self.assertIn("synthetic stop failure", report["compiler_monitor_finalization_error"]["reason"])


if __name__ == "__main__":
    unittest.main(verbosity=2)
