# Revision03 status

This fresh preparation preserves all actually staged revision02 objects. The original shared sampler02 failed its real 2% CPU cost gate; the reviewed faster sampler03 must still pass a real native cost/coverage gate before these R26 campaigns may start. No measurement, threshold, baseline, runtime source or socket-creation behavior is changed.

# R26 monitored observation and lifecycle tools, revision 02

These are prepared tools for the original R26 attempt01. They are not a qualification result or a measured optimization. The actual qualification job reported and independently checked by the root agent is `1a1ab4cb0fc-fc05-4c3c`; its final report, native terminal, source map and retained binary identities must still be read from that original operation before the materializers can run.

The formal A arm remains accepted R24 at source commit `baab4def80be7af015b2e7a594cb302f66c4130e`. Qualified but rejected R25 is not the formal performance baseline. R26 contains only the selected B change that defers unused Python request construction; these control tools do not change runtime source.

## Preserve the actual staged revision01

Root reconciled six already staged originals: the three revision01 archives, the revision01 installer under ROOT25/tools, and the two Mac campaign-01.py files. The exact original local receipt is recorded in `runtime-path-rebinding-02.json`; no old staged file is replaced or executed by this package.

Revision02 uses fresh installation paths:

| Item | New path |
|---|---|
| Parent and monitor tools | `/home/qian/hepta-runtime-optimization-20261105-r26/tools-03` |
| Original native lifecycle tools | `/home/qian/hepta-runtime-optimization-20261105-r26/lifecycle-tools-03` |
| Preserved outer bundle | `/home/qian/hepta-runtime-optimization-20261105-r26/lifecycle-launcher-bundle-02` |
| Mac observation script | `/Users/qianqi/work/hepta-runtime-r26-observation-campaign-03.py` |
| Mac lifecycle script | `/Users/qianqi/work/hepta-runtime-r26-lifecycle-campaign-03.py` |

Actual effect outputs remain the original attempt01 paths: `campaign-01`, `lifecycle-campaign-01`, `lifecycle-abba-01`, `cancel-saturation-01`, and `lifecycle-tool-tests-01`. The Mac evidence directories retain the planned observation/lifecycle evidence-01 names. Every output must be absent before its original operation starts. Existing paths never authorize overwrite or reuse.

The complete pre-rebinding revision02 source is preserved locally in `r26-tools-03-before-runtime-rebinding`. Its independent review remains attached to its exact old bytes. The new runtime path substitution is explicit and does not change a workload argument, output attempt, threshold, runtime input, source qualification or ownership function.

## Real source identity from the Mac holder

The unchanged holder is `held_agent_campaign_02.py`, SHA256 `715e996217c7d33a7483354f16f2d39c9a033f51f3a20a52484495a00262dd65`. It hashes and transmits the actual new parent script, and supplies that script's real SHA as `--launcher-sha256`.

The monitor runs inside each modified parent's own `main`/`finally` flow. There is no outer wrapper claiming the previous parent hash. The observation example binds the new observation SHA. The lifecycle example binds its own new SHA and the exact newly installed observation helper SHA. Both examples also bind four explicit files: monitor component, metadata reader, independent ledger validator and immutable policy.

Every source file is checked before use and after the guarded body. The new monitor/validator code executes from the already verified memory bytes rather than reopening a path after hashing. The metadata reader repeats its own bounded descriptor read before executing the checked bytes. New controls are outside the qualified runtime source and private compiler cache.

## The compiler monitoring validity gate

The observer is one controlled daemon thread; it starts no additional process. The first completed metadata scan must acknowledge readiness before the parent enters prerequisite checks, quiescence or any fixture submission. The final scan begins only after original child cleanup and final source checks have returned. Complete join is mandatory for successful evidence.

| Bound | Frozen value |
|---|---:|
| Sampling period | 1 second |
| Maximum scheduled lateness | 0.75 seconds |
| Maximum consecutive start gap | 2 seconds |
| Maximum scan wall duration | 0.5 seconds |
| Maximum monitored interval | 3600 seconds |
| Maximum retained samples | 3603 |
| Maximum compact serialized samples | 8 MiB |
| Maximum compiler records | 8192 |
| Maximum numeric process directories per scan | 16384 |
| Maximum observer CPU per wall second | 0.02 CPU seconds |
| Initial readiness wait / final join wait | 5 / 10 seconds |

The duration/sample bounds explicitly cover R26's existing 3300-second parent budget and 3600-second holder envelope. The reused component's diagnostic default is 2400 seconds/2403 samples; R26 explicitly constructs the longer frozen limits. The 8 MiB bound describes compact serialized samples, not total Python resident memory.

The sampler reads process names and, for compiler names, PID, birth ticks, UID, state, parent PID and process group. It does not read argv, environments or credentials. A live compiler, matched compiler disappearance, unreadable or unstable metadata, missing slot, clock error, late or slow scan, overflow, lost thread, incomplete join, or excessive/unavailable observer CPU prohibits attribution. Z/X/x records remain visible. Ordinary process exits before their name can be observed remain a limitation of sampled metadata.

The monitor never writes hot-loop logs. After original cleanup, its complete retained ledger is written create-only, reread against the SHA of the exact written bytes, and validated independently. The validator recomputes every scheduled slot through parent end, endpoint ordering, sample clocks and gaps, ledger counts, raw thread CPU ratio and all metadata rejection conditions. It cannot accept a hand-edited `passed=true` with a missing sample.

Passing establishes only that the bounded 1 Hz observations did not detect disqualifying activity. It cannot prove the absence of activity between observations. Root scheduling also stops owned compiler work and archive I/O before any measurement.

## Preserve the original result when monitoring fails

Each actual parent directory gains `compiler-monitor.json` and `compiler-monitor.audit.json`. The parent report records their exact SHA/size, the four source identities, policy, guarded start/end times and the independent decision.

The pre-monitor stage outcome is retained as `result_before_compiler_monitor`. A monitor failure makes `measurement_attribution_valid=false`, `passed=false`, and the corresponding observation/adoption gate false; it does not rewrite raw workload reports or their performance statistics. A late monitor source change preserves the raw samples and marks `inputs_unchanged=false`. No failure starts a replacement measurement.

The lifecycle materializer and the actual lifecycle parent each reopen the prior observation ledger and audit, bind its source/policy set to their own reviewed inputs, and independently revalidate it. An observation with false, missing or inconsistent monitor evidence cannot authorize lifecycle fixtures even if its raw performance summary passed.

## Original workload and ownership invariants

The two `run_stage` functions are unchanged by AST. The observation command generator, process identity/group custody functions, source checks and R26 qualification validator remain unchanged. All 27 native lifecycle payload files and their manifest are byte-identical to reviewed revision01; only their enclosing installation directory changes.

Observation uses ABBA, C1/C8/C16, 192 measured and 24 warmup calls per cell, two Tokio workers and arena_max=1. Every concurrency retains throughput B/A >=0.95, p95 B/A <=1.10, controller CPU per call B/A <=1.10, and RSS B <=min(A+512 KiB, A*1.05). Original boundary and cancellation-recovery auditors remain unchanged.

Lifecycle retains the original finite ABBA, six fresh jobs per round and the existing CPU clock-tick resolution allowance. Aggregate, launch and live-cancel throughput/p95 gates remain unchanged, as do the RSS gate, the six-host cancellation saturation proof, exact status-only blocking predicate, release/drain/retirement ordering, same-key recovery and cancellation after terminal state. All 14 actual native helper tests must pass with zero skips before fixtures start.

The monitor does not change launch/cancel dispatch, replay uncertain effects, alter runtime capacity, send process signals, or replace original child ownership and cleanup. The additional gate only determines whether the retained result is admissible for performance attribution.

## Materialization and execution order

1. Let the original R26 qualifier finish. Reconcile its same native job and retain the strong terminal DTO, preparation, full qualification report, 221-source map, 19-file harness proof, exact eight stages, and actual 1653 passed / 34 ignored / zero failed / zero retry result.
2. Root performs the separately bound external Rust CI gate. R26 Python CI is explicitly unplanned; R25's Python result remains historical evidence.
3. Install only reviewed revision02 files create-only into the new directories after actual qualification binding. Staged archives and installer remain under fresh ROOT25 revision02 names; the qualifier owns creating ROOT26.
4. Materialize observation inputs using actual original job and receipt SHA arguments. Future candidate binary and report fields in the reviewed example remain null until this read-only materialization.
5. Root alone starts the new Mac observation parent once. Preserve the original holder, native streams, terminal DTO, monitor ledger and all workload output whether successful or rejected.
6. Only a complete, successful, independently validated observation and monitor gate can materialize lifecycle inputs. Root then starts the new Mac lifecycle parent once and retains all original output.

Installation, materialization, monitoring, qualification, workload gates, evidence export and production adoption remain separate results. This package claims no completed R26 measurement or adoption.

## Local verification

The prerequisite suite checks future-pin refusal, original job/source/harness/qualification binding and rejection propagation. The six new composition tests use explicitly synthetic ledgers and temporary local files: they verify lossless retained-ledger consumption, missing-slot rejection despite a true flag, source-change failure with raw preservation, one-shot stop failure, missing-input refusal, and unchanged original workload/ownership ASTs and native bytes.

These local tests perform no native job, SSH, process sampling or benchmark. Their complete final stdout/stderr and exact source hashes are included in the local validation receipt. Actual monitor timing, native cost and all performance results remain mandatory runtime evidence.
