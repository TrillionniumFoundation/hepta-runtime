# R26 original lifecycle attempt02, tool revision04

This is a fresh experiment after actual original01 failed before any fixture.
It preserves original job 1a1ababc175-fc05-4f94, all eleven actual failure files,
its unchanged source, and its original attempt01 input and output directories.
The materializer and actual parent require that precise strong failed1 receipt,
zero submitted stages, the exact initial-monitor error, completed owned-holder
cleanup, and absent original fixture/socket paths. This is not an effect retry.

The accepted R24 A arm and actually qualified R26 B arm, ABBA order, six-host
topology, workloads, quantitative gates, 14 native helper tests, cancellation
pressure/8-second ACK gate, independent auditors and owned cleanup are unchanged.
Only three native fixed output path guards change to attempt02. Other24 native
payload bytes, including their historical README/provenance, are preserved.

Runtime helper, compiler reader/module/validator/policy remain installed tools03
with actual observation01's identical source pins. Both original input materializer
and parent revalidate the successful actual observation01 and qualification01.
The parent source transmitted by the original Mac holder is the new tools04 byte
identity. Nothing substitutes a wrapper hash for those actual stdin bytes.

Fresh destinations: tools-04, lifecycle-tools-04, lifecycle-inputs-02.json,
lifecycle-campaign-02, lifecycle-abba-02, cancel-saturation-02,
lifecycle-tool-tests-02, short socket names r26lc2/r26sat2. Each fixture receives
the existing protocol's fresh random nonce and fresh exclusive remote directory.

The separate bounded natural quiet wait is read-only admission preparation.
Root must obtain its actual terminal and report before launching the holder.
It never overrides this parent's initial/continuous monitor or 90-second quiet
period. No successful wait or future workload result is fabricated in this package.

Installation creates only named fresh files; unrelated parent lock files are
not rejected or removed. It does not execute packaged tools, tests or workloads.
Materialization remains a separate actual invocation. The original holder remains
unchanged; root uniquely starts a fresh attempt02 after reviewing actual inputs.
