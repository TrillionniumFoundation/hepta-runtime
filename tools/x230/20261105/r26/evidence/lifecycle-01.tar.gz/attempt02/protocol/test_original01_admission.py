#!/usr/bin/env python3
"""Pure checks over actual retained original01 evidence; no native/remote calls."""
import copy
import importlib.util
import json
from pathlib import Path
import unittest

HERE = Path(__file__).resolve().parent
SOURCE = HERE / 'tools-04/r26_lifecycle_campaign.py'
spec = importlib.util.spec_from_file_location('r26_life04_admission_review', SOURCE)
parent = importlib.util.module_from_spec(spec)
spec.loader.exec_module(parent)
RAW = {p.name: p.read_bytes() for p in (HERE / 'lifecycle-original01-failure-evidence-04').iterdir()}
DOCUMENTS = {name: json.loads(raw) for name, raw in RAW.items() if name.endswith('.json')}
INPUTS = json.loads((HERE / 'lifecycle-inputs-02.example.json').read_bytes())


class OriginalEvidence(unittest.TestCase):
    def test_actual_original_is_the_pre_fixture_failed_attempt(self):
        result = parent.validate_original01_early_failure(DOCUMENTS, RAW, INPUTS)
        self.assertTrue(result['verified'])
        self.assertTrue(result['no_fixture_stages_submitted'])
        self.assertEqual(result['original_job_id'], '1a1ababc175-fc05-4f94')

    def test_refuses_any_submitted_stage(self):
        changed = copy.deepcopy(DOCUMENTS)
        changed['report.json']['stages'] = [{'name': 'lifecycle-tool-tests'}]
        with self.assertRaises(RuntimeError):
            parent.validate_original01_early_failure(changed, RAW, INPUTS)

    def test_refuses_unfinished_original(self):
        changed = copy.deepcopy(DOCUMENTS)
        changed['report.json'].pop('finished_utc')
        with self.assertRaises(RuntimeError):
            parent.validate_original01_early_failure(changed, RAW, INPUTS)

    def test_refuses_different_native_job_or_incomplete_log(self):
        for field, value in [('job_id', 'different-original'), ('output_complete', False)]:
            changed = copy.deepcopy(DOCUMENTS)
            changed['native-terminal.json'][field] = value
            with self.subTest(field=field), self.assertRaises(RuntimeError):
                parent.validate_original01_early_failure(changed, RAW, INPUTS)

    def test_refuses_unreaped_holder(self):
        changed = copy.deepcopy(DOCUMENTS)
        changed['mac-report.json']['owned_agent_reaped'] = False
        with self.assertRaises(RuntimeError):
            parent.validate_original01_early_failure(changed, RAW, INPUTS)

    def test_refuses_unjoined_monitor(self):
        changed = copy.deepcopy(DOCUMENTS)
        changed['compiler-monitor.json']['thread_joined'] = False
        with self.assertRaises(RuntimeError):
            parent.validate_original01_early_failure(changed, RAW, INPUTS)

    def test_refuses_nonmatching_prior_monitor_source(self):
        changed = copy.deepcopy(INPUTS)
        changed['compiler_monitor']['reader']['sha256'] = '0' * 64
        with self.assertRaises(RuntimeError):
            parent.validate_original01_early_failure(DOCUMENTS, RAW, changed)

    def test_refuses_changed_native_original_stream(self):
        changed = dict(RAW, **{'native.stdout': b''})
        with self.assertRaises(RuntimeError):
            parent.validate_original01_early_failure(DOCUMENTS, changed, INPUTS)


if __name__ == '__main__':
    unittest.main(verbosity=2)
