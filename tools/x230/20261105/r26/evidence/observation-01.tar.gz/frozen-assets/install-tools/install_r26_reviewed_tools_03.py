#!/usr/bin/env python3
"""Create only the reviewed R26 tools after original qualification; run no tools."""
import argparse
import datetime
import hashlib
import io
import json
import os
from pathlib import Path, PurePosixPath
import re
import stat
import sys
import tarfile

sys.dont_write_bytecode = True
STAGE_ROOT = Path('/home/qian/hepta-runtime-optimization-20261105-r25')
ROOT = Path('/home/qian/hepta-runtime-optimization-20261105-r26')
SOURCE = ROOT / 'source'
CANDIDATE_DIR = ROOT / 'qualification-01'
SCRIPT = STAGE_ROOT / 'tools/install_r26_reviewed_tools_03.py'
QUALIFICATION_INPUT = STAGE_ROOT / 'tools/r26-installation-qualification-03.json'
RECEIPT = 'tools-install-03-receipt.json'
NEW_DIRECTORIES = ('tools-03', 'lifecycle-tools-03', 'lifecycle-launcher-bundle-03',
                   'lifecycle-launcher-bundle-03/tools-03')
PARENT_INSTALL = {
    'tools-03/r26_lifecycle_campaign.py': str(ROOT / 'tools-03/r26_lifecycle_campaign.py'),
    'tools-03/prepare_lifecycle_inputs.py': str(ROOT / 'tools-03/prepare_lifecycle_inputs.py'),
    'lifecycle-inputs-01.example.json': str(ROOT / 'lifecycle-inputs-01.example.json'),
}
ROOT_FILES = {'campaign-inputs-01.example.json', 'observation-plan-01.json',
              'observation-tools-manifest-03.json', 'lifecycle-inputs-01.example.json'}
ARCHIVES = {'lifecycle': {'bytes': 83481,
               'expanded_bytes': 384752,
               'member_count': 28,
               'members': {'README.md': {'bytes': 9053,
                                         'sha256': '02d016a50e76d58031b07b881bc82440ea49e667e79e21164ca11919a9583eec'},
                           'allocator_environment.py': {'bytes': 5879,
                                                        'sha256': 'f5c8e879c540b3f7cb1b7d3a7a0f5002c2f40c1a87963174b0b00470fa3a4525'},
                           'allocator_environment_audit.py': {'bytes': 6709,
                                                              'sha256': '4b082ce343ae3943e3098baa58af2f5def7198881b9c087d63d88360e9763727'},
                           'analyze_lifecycle_gates.py': {'bytes': 7581,
                                                          'sha256': 'c7a861a94a89dd81debb5c055773918d89a1c9c29b699e2e5a0341e51be69553'},
                           'analyze_native_observation.py': {'bytes': 8708,
                                                             'sha256': 'cc7f6884d581cd1ced430437350e808de51931c50d12441797205501b20cae66'},
                           'audit_native_evidence.py': {'bytes': 17065,
                                                        'sha256': 'b69f6902d2de81eab41b21506f024c002d2f8264d60e86df6b1086623a77fd28'},
                           'cancel_saturation_gate.py': {'bytes': 15789,
                                                         'sha256': '536ebdc5f2b090a8c007f189a895ed2e19d7b8b7e41530ccba94dd826742ef7f'},
                           'lifecycle-gate-policy.json': {'bytes': 1575,
                                                          'sha256': '36658346c4e265bf551a1ae1a4c6210bec8e4729f7961302a203008741cd381e'},
                           'lifecycle-tools-manifest-01.json': {'bytes': 4066,
                                                                'sha256': '3de28dd79333cb52ad426ff8e60b74f23d3c4a297a6c9691e18431a0fbff7e94'},
                           'observation_resources.py': {'bytes': 12382,
                                                        'sha256': 'f3402d51cb37b2fe20f4351b3a81ec5990a9fdaff93a846d21c07ccd557cb894'},
                           'owned_ssh_interruption.py': {'bytes': 7892,
                                                         'sha256': '1989c57f0b944afae1ed759d6529b8f1cc26197e269e2c34c4fd49e43a32aa7b'},
                           'run_lifecycle_abba_01.py': {'bytes': 14787,
                                                        'sha256': '2097a2f89eb01f4eb1d8a965f85bcde82d9b5bf8e6baef38fc03d35f6ec60654'},
                           'run_lifecycle_tool_tests.py': {'bytes': 2224,
                                                           'sha256': 'e3c1e8163249dba14672a3a82b43a2d7b8b4c0802b94b8511bf3db668f865a2d'},
                           'run_native_observation.py': {'bytes': 3279,
                                                         'sha256': '7606648c99b2ff2bbf0bba58384e8cab609ac3899f838c0b80ba54d6288d20bb'},
                           'run_six_host_cancel_recovery.py': {'bytes': 27847,
                                                               'sha256': '698eb7801cde3f2bd5ff202412c0833fc218fd7e912c3c949d2b37fde7a56a12'},
                           'run_six_host_cancel_recovery_timed.py': {'bytes': 30163,
                                                                     'sha256': 'b20e1fe84790a069aac3e408452e63567aff73e066fdb7abfa96658556770ac4'},
                           'run_six_host_cancel_saturation.py': {'bytes': 31325,
                                                                 'sha256': 'd33c51cd0b6b43dda06efcabc3000355512de2725591c5863cf0864cde06ae99'},
                           'source-provenance.json': {'bytes': 2510,
                                                      'sha256': '58d276c8df05dcd95a0a25e6264c3de1b248e8bb821651fb1b52859dd707dbbe'},
                           'status-predicate.json': {'bytes': 875,
                                                     'sha256': '5828c7ba2990f38531cce7e1a42b44315ee42278ccaee361ace8d9472a96da34'},
                           'summarize_lifecycle_abba_01.py': {'bytes': 16065,
                                                              'sha256': '9e050343bb32e7f57148f633ff94bbcfb3a7452b2872ae68404ca642e937af89'},
                           'test_native_harness.py': {'bytes': 13286,
                                                      'sha256': '2b450175b9e6122248ac1bcb51860aa8a6d3eff55f6ac8c877c0a905e3dd7d00'},
                           'test_r25_lifecycle_tools.py': {'bytes': 10026,
                                                           'sha256': '1845cdb48440a03146e337af7baf916bb9cdb76fb46ea0699f79144cf7197566'},
                           'test_verify_saturation_extension.py': {'bytes': 8187,
                                                                   'sha256': '10f2dcbfa9e2b5c625f22c3edc32c9f8a969509345b20d9b135cebc2235c16fb'},
                           'verify_cancel_recovery.py': {'bytes': 16634,
                                                         'sha256': '0116652a0b489dc462f005e01d7c943feda9ba784563d7317c92bb5beb9a701c'},
                           'verify_cancel_saturation.py': {'bytes': 17123,
                                                           'sha256': 'd3b6772ddffc711a23aa4aa9566f903c149535a3d3c4cc3466ee73690cbc1e75'},
                           'verify_saturation_extension.py': {'bytes': 9418,
                                                              'sha256': '23dfd25517b517067a4fbb3f4a3227f12bafff46b828eb05f7bf322596124e6a'},
                           'x230_observation_benchmark.py': {'bytes': 37006,
                                                             'sha256': '4d96f0bf2da2562e788f48be7c37589ab3a513be5f9d8b2d741afe5c08ea9eed'},
                           'x230_six_running_recovery_canary.py': {'bytes': 47298,
                                                                   'sha256': '6219bc556b0ac6d142bd4c731466b959e8a410f0b4b55f3d8b303f8fdbfbaaf4'}},
               'path': '/home/qian/hepta-runtime-optimization-20261105-r25/staged-r26-lifecycle-tools-03.tar.gz',
               'sha256': '77e808515f424ec204ec7f3df69a94b0f370e674a5d37a6a43c272cde743f21b'},
 'observation': {'bytes': 33764,
                 'expanded_bytes': 123735,
                 'member_count': 10,
                 'members': {'campaign-inputs-01.example.json': {'bytes': 3818,
                                                                 'sha256': '516b3a4a4699482928a5dc0dab409e0c59a9653d78cb8eeb1b77a8b567e9677a'},
                             'observation-plan-01.json': {'bytes': 11669,
                                                          'sha256': '01f375b70ce82aeb6007d0d2cf17dfeaaa8cab82089b98e39b614e37067e472f'},
                             'observation-tools-manifest-03.json': {'bytes': 1943,
                                                                    'sha256': 'e4afdd219a63b208d9dea3b6b2716f7ba28cc74c05f159f15ff2838bcbed068d'},
                             'tools-03/compiler-monitor-policy-01.json': {'bytes': 1001,
                                                                          'sha256': 'ddb2e03d4a1a1610466a5dc2d1a544f554ad12fc31412483101b48a235402368'},
                             'tools-03/compiler_monitor.py': {'bytes': 12510,
                                                              'sha256': 'afb514362a9d8dd573b806f0dc87df16bd3a906e4574d10d91bf483b2e76cdcf'},
                             'tools-03/compiler_state.py': {'bytes': 6243,
                                                            'sha256': '9da718654db04a646e081d2d719a2d6d4655ffe337bc0e3f906e736e4d77a251'},
                             'tools-03/prepare_campaign_inputs.py': {'bytes': 9964,
                                                                     'sha256': '096f5968d145a4f2ba4b677582f167bd2f68f39694af4d036eccf4b217534914'},
                             'tools-03/r26_campaign.py': {'bytes': 55076,
                                                          'sha256': '34883c3b7bcae75e81604e7a3fb2845540eef979328010f4f597fdd218f79add'},
                             'tools-03/summarize_r25_campaign.py': {'bytes': 14456,
                                                                    'sha256': '2418bad36fe4aef75d52c5a00c898ff93fef9bb4b6efb10028105143106a1864'},
                             'tools-03/validate_compiler_monitor.py': {'bytes': 7055,
                                                                       'sha256': 'd2cd009adf1f35a394ffddcc8f8646cc0c1b856b78181ca321ea68f6468218b2'}},
                 'path': '/home/qian/hepta-runtime-optimization-20261105-r25/staged-r26-observation-tools-03.tar.gz',
                 'sha256': 'a64271f70afd0ea559ad832b6b084becda8d3245a9b00db95b724d0a1b6fd912'},
 'parent': {'bytes': 32507,
            'expanded_bytes': 128368,
            'member_count': 18,
            'members': {'derivation-inputs-03.json': {'bytes': 16758,
                                                      'sha256': 'daf6a6d4c5f2e66adb529c1be841de2a33cc141b2308a64dc374a6d6722cddd0'},
                        'lifecycle-inputs-01.example.json': {'bytes': 2585,
                                                             'sha256': '5cbfeac896bcbb2f883408cd7f013cec6f23bf370098c7b1c8df13c06f0ee591'},
                        'lifecycle-launcher-manifest-03.json': {'bytes': 3724,
                                                                'sha256': '862053c9cf16eb187179c49a7ff6e6fb60966064aa005b6628930e792de7be3f'},
                        'lifecycle-plan-01.json': {'bytes': 8134,
                                                   'sha256': '750cc72456d498440fc2661abe6248c4c44590de2d98dbdb3237de4eb833db11'},
                        'local-validation-03.json': {'bytes': 2277,
                                                     'sha256': '74cf2bae6863c241991aa1d94504ef8c09e840bfb4c6cf8708cc38e65d8a5870'},
                        'monitor-authority-proof-03.json': {'bytes': 5344,
                                                            'sha256': '5f46ad393afb016a96affcd6de2fcb0493bd9388a2cf74f185bf3f9f28f42635'},
                        'monitor-integration-checks-01.stderr': {'bytes': 1024,
                                                                 'sha256': '7232ee64b81c6e4ca3024e69040e60090f5a40805da45d17443a913cd93d89ec'},
                        'monitor-integration-checks-01.stdout': {'bytes': 0,
                                                                 'sha256': 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855'},
                        'monitor-protocol-delta-03.diff': {'bytes': 15129,
                                                           'sha256': 'c9789bbd79254bf956c7464cfe95b2d88b2eab57921bcaffda50e77a9596f621'},
                        'monitor-source-derivation-03.json': {'bytes': 2053,
                                                              'sha256': '8410f3ae78f5977760ff956b7dcf0c03fa5e81e6ea5ef8af2cae788158bd62b2'},
                        'prerequisite-checks-01.stderr': {'bytes': 1050,
                                                          'sha256': '63d0216559d95c1b048819df221c027e685ad32e4367a7e63d4a69c94591992c'},
                        'prerequisite-checks-01.stdout': {'bytes': 0,
                                                          'sha256': 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855'},
                        'r26-tools-03.README.md': {'bytes': 11167,
                                                   'sha256': 'fafeb54936c36ee5576091adc0e37c6d9fd0df652cecbe9bde3f858074c8ece5'},
                        'runtime-path-rebinding-03.json': {'bytes': 2538,
                                                           'sha256': '11e5929429c1c99d847d6566947fd9b6c3b44f0801d5ab61f1209227f8005638'},
                        'test_r26_monitor_integration.py': {'bytes': 9801,
                                                            'sha256': 'df8148a40643c15834e91302fab17823d141acb35956d6786bf90306dfdf7c53'},
                        'test_r26_prerequisites.py': {'bytes': 7958,
                                                      'sha256': '42e5ab8d568aecb87942f8dfb45fbacdeb888189e5fefb33b310d56385040bb5'},
                        'tools-03/prepare_lifecycle_inputs.py': {'bytes': 12066,
                                                                 'sha256': 'b1f2d581b9db84ef9633680116a1ab67b0c41e02f7f5977d128e14515a4f2619'},
                        'tools-03/r26_lifecycle_campaign.py': {'bytes': 26760,
                                                               'sha256': '2970725473f7dab854a9d13326aa0ca792b9442615d325ebb0e767065bd08f37'}},
            'path': '/home/qian/hepta-runtime-optimization-20261105-r25/staged-r26-lifecycle-launcher-bundle-03.tar.gz',
            'sha256': '0130cfd36ff92632e84086d284276b8a766e9d485d94bff861de256b1ab7cc80'}}
HEX = re.compile(r'[0-9a-f]{64}\Z')


def need(value, message):
    if not value:
        raise RuntimeError(message)


def encoded(value):
    return (json.dumps(value, sort_keys=True, indent=2, allow_nan=False) + '\n').encode()


def identity(raw):
    return {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


def stamp(value):
    return tuple(getattr(value, name) for name in
                 ('st_dev', 'st_ino', 'st_uid', 'st_mode', 'st_nlink', 'st_size', 'st_mtime_ns', 'st_ctime_ns'))


def read_path(path, expected=None, maximum=128 * 1024 * 1024, retain=True):
    path = Path(path)
    need(path.is_absolute() and path.resolve(strict=True) == path, 'indirect or missing input path')
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_CLOEXEC | os.O_NONBLOCK)
    try:
        before = os.fstat(fd)
        need(stat.S_ISREG(before.st_mode) and before.st_nlink == 1 and before.st_uid == os.geteuid()
             and 0 <= before.st_size <= maximum, 'unsafe or oversized owned input')
        digest, size, chunks = hashlib.sha256(), 0, []
        while block := os.read(fd, 1024 * 1024):
            size += len(block)
            need(size <= before.st_size, 'input grew while reading')
            digest.update(block)
            if retain:
                chunks.append(block)
        need(size == before.st_size and stamp(before) == stamp(os.fstat(fd)) == stamp(path.lstat()),
             'input identity changed while reading')
    finally:
        os.close(fd)
    result = {'path': str(path), 'bytes': size, 'sha256': digest.hexdigest()}
    if expected is not None:
        need(type(expected.get('bytes')) is int and HEX.fullmatch(expected.get('sha256', ''))
             and result == {key: expected[key] for key in result}, 'actual input identity differs')
    return result, b''.join(chunks)


def read_at(directory, name, expected):
    need(Path(name).name == name, 'only direct file names are permitted')
    fd = os.open(name, os.O_RDONLY | os.O_NOFOLLOW | os.O_CLOEXEC | os.O_NONBLOCK, dir_fd=directory)
    try:
        before = os.fstat(fd)
        need(stat.S_ISREG(before.st_mode) and before.st_nlink == 1 and before.st_uid == os.geteuid()
             and 0 <= before.st_size == expected['bytes'] <= 1048576, 'unsafe installed file')
        with os.fdopen(os.dup(fd), 'rb') as stream:
            raw = stream.read(expected['bytes'] + 1)
        need(stamp(before) == stamp(os.fstat(fd)) == stamp(os.stat(name, dir_fd=directory, follow_symlinks=False))
             and identity(raw) == expected, 'installed file identity differs')
        return {'device': before.st_dev, 'inode': before.st_ino, 'uid': before.st_uid,
                'mode': stat.S_IMODE(before.st_mode), 'links': before.st_nlink, **identity(raw)}
    finally:
        os.close(fd)


def members_from_archive(raw, spec):
    need(identity(raw) == {key: spec[key] for key in ('bytes', 'sha256')}, 'archive identity differs')
    result = {}
    with tarfile.open(fileobj=io.BytesIO(raw), mode='r:gz') as archive:
        entries = archive.getmembers()
        need(len(entries) == spec['member_count'] and sum(entry.size for entry in entries) == spec['expanded_bytes']
             and spec['expanded_bytes'] <= 1048576, 'archive member count or expansion differs')
        for entry in entries:
            path = PurePosixPath(entry.name)
            need(entry.type in (tarfile.REGTYPE, tarfile.AREGTYPE) and not entry.issparse()
                 and not entry.linkname and path.parts and not path.is_absolute()
                 and all(part not in ('.', '..') for part in path.parts)
                 and path.as_posix() == entry.name and entry.name in spec['members']
                 and entry.name not in result, 'unexpected, linked, duplicate or unsafe archive member')
            expected = spec['members'][entry.name]
            need(entry.size == expected['bytes'], 'archive member size differs')
            stream = archive.extractfile(entry)
            need(stream is not None, 'regular member unreadable')
            body = stream.read(expected['bytes'] + 1)
            need(identity(body) == expected, 'archive member SHA differs')
            result[entry.name] = body
        need(set(result) == set(spec['members']), 'archive member set differs')
    return result


def verify_r26_candidate_preparation(preparation, terminal, job_id, qualified, tests):
    """Pure check of actual R26 qualification; no future identity is inferred."""
    need(isinstance(job_id, str) and re.fullmatch(r"[0-9a-f]{11,16}-[0-9a-f]{4}-[0-9a-f]{4}", job_id)
         and job_id not in {"1a1aa7fa690-fc05-43af", "1a1aaa6552d-fc05-459f"},
         "the actual new R26 qualification job is required")
    need(terminal.get("job_id") == job_id and terminal.get("state") == "succeeded"
         and type(terminal.get("exit_code")) is int and terminal["exit_code"] == 0
         and all(terminal.get(key) is False for key in ("automatic_retry", "timed_out", "cancelled"))
         and all(terminal.get(key) is True for key in ("output_complete", "output_durable", "terminal_publication_confirmed"))
         and type(terminal.get("terminal_publication_protocol")) is int and terminal["terminal_publication_protocol"] == 1
         and terminal.get("log_synced") == {"stdout": True, "stderr": True}
         and terminal.get("log_errors") == {"stdout": None, "stderr": None}
         and terminal.get("log_truncated") == {"stdout": False, "stderr": False},
         "original R26 qualification has no complete successful native terminal proof")
    for stream in ("stdout", "stderr"):
        counts = terminal["log_bytes"][stream]
        need(set(counts) == {"seen", "stored"} and all(type(value) is int and value >= 0 for value in counts.values())
             and counts["seen"] == counts["stored"], "qualification native log byte custody differs")
    need(preparation["schema"] == "hepta-r26-qualified-parent-preparation/v1"
         and preparation["selected_proposal"] == "B only" and preparation.get("finished_utc")
         and all(preparation.get(key) is True for key in ("passed", "candidate_qualified", "parent_source_qualified",
             "parent_observation_rejection_preserved", "parent_inputs_unchanged"))
         and all(preparation.get(key) is False for key in ("candidate_adopted", "parent_candidate_adopted",
             "production_services_modified", "shared_hardlinks_created")), "actual R26 preparation is incomplete")
    need(preparation["source"] == str(SOURCE) and preparation["target"] == str(ROOT / "target-build")
         and preparation["qualification_output"] == str(CANDIDATE_DIR)
         and preparation["launcher"]["bytes"] == 14305
         and preparation["launcher"]["sha256"] == "5306935cc2771a1138dc0a641ee4b9d359e00fd152d4be746a630db0b9bb72f7"
         and preparation["input"]["bytes"] == 27079
         and preparation["input"]["sha256"] == "3b6e6a119f09c649c11d4170e59c6d63831d824a2280b435a2ea57defd949111",
         "R26 qualification launcher, input or private paths differ")
    need(type(preparation["qualification_returncode"]) is int and preparation["qualification_returncode"] == 0
         and type(preparation["automatic_test_retries"]) is int and preparation["automatic_test_retries"] == 0,
         "R26 qualification did not finish once with exit zero")
    expected_change = {"path": "src/mcp/runtime/jobs.rs",
        "before": {"bytes": 186495, "sha256": "783f162ffd9be6165da63cd40e4ce28844496c53c8c651926fc359c93904e952"},
        "after": {"bytes": 186504, "sha256": "8a80623ccf9131e520ed5f25647200bd2086e4718b892eed90c1530a5ccb9283"}}
    need(preparation["source_changes"] == [expected_change], "qualified selection is not the exact B-only change")
    before = preparation["source_before"]
    expected = dict(before)
    expected[expected_change["path"]] = expected_change["after"]["sha256"]
    need(len(before) == len(expected) == 221 and before[expected_change["path"]] == expected_change["before"]["sha256"]
         and preparation["candidate_compilation_inputs"] == expected, "R26 pre-format source map differs")
    stages = ["format", "fmt-check", "harness-tests", "clippy", "test-build", "isolated-tests", "audit-isolated-tests", "release"]
    need(qualified["schema"] == "hepta-x230-composed-qualification/v1" and qualified["qualified"] is True
         and qualified.get("finished_utc") and qualified["source"] == str(SOURCE)
         and qualified["jobs"] == 2 and qualified["service_changes"] is False
         and type(qualified["automatic_test_retries"]) is int and qualified["automatic_test_retries"] == 0
         and [row["name"] for row in qualified["stages"]] == stages
         and all(type(row["returncode"]) is int and row["returncode"] == 0 for row in qualified["stages"]),
         "all eight original R26 qualification stages must pass")
    need(qualified["source_input"] == expected and qualified["source_tested"] == qualified["source_after"] == preparation["source_tested"]
         and set(qualified["source_after"]) == set(expected)
         and all(qualified["source_after"][name] == value for name, value in expected.items() if name != expected_change["path"]),
         "actual formatted R26 source differs from its qualified preparation")
    need(preparation["formatter_changed_paths"] == [name for name in expected if qualified["source_after"][name] != expected[name]]
         and qualified["harness_before"] == qualified["harness_after"] == preparation["harness_before"]
         and len(qualified["harness_after"]) == 19, "qualification formatter or original harness binding differs")
    counts = ("passed", "failed", "ignored", "selected", "retries")
    need(all(type(tests[key]) is int for key in counts)
         and [tests[key] for key in counts] == [1653, 0, 34, 1687, 0]
         and preparation["tests"] == tests, "original full R26 isolated test result is incomplete")
    return {"passed": True, "original_job_id": job_id, "selected_proposal": "B only",
            "qualified_source_files": 221, "harness_files": 19, "stages": stages,
            "tests": {key: tests[key] for key in counts}, "candidate_adopted": False,
            "qualified_parent_R25_observation_rejection_preserved": True}


def verify_qualification_documents(value, preparation, terminal, qualified, summary, audit, source_map):
    need(value['schema'] == 'hepta-r26-installation-qualification/v1'
         and value['executed'] is False, 'actual qualification input schema differs')
    proof = verify_r26_candidate_preparation(preparation, terminal, value['original_qualification_job_id'], qualified, summary)
    need(value['original_qualification_job_id'] == '1a1ab4cb0fc-fc05-4c3c',
         'installation requires the observed original R26 qualification job')
    need(type(preparation.get('finished_utc')) is str and bool(preparation['finished_utc'])
         and preparation['qualification_report'] == value['qualification_report']
         and source_map == qualified['source_after'], 'completed preparation/source-map binding differs')
    need(summary['schema'] == 'hepta-isolated-libtest/v1' and summary['success'] is True
         and summary['filter'] == '' and summary['enumeration_errors'] == []
         and summary['source_manifest_path'] == str(CANDIDATE_DIR / 'source-map.json')
         and summary['source_manifest_sha256'] == value['source_map']['sha256'], 'full actual isolated summary differs')
    need(audit['schema'] == 'hepta-isolated-libtest-audit/v1' and audit['success'] is True
         and audit['errors'] == [] and 'fatal_error' not in audit and audit['expected_filter'] == ''
         and audit['input_sha256']['summary.json'] == value['isolated_summary']['sha256']
         and all(audit[key] == summary[key] for key in ('passed', 'failed', 'ignored', 'selected'))
         and audit['executed'] == 1653, 'original independent isolated audit differs')
    return proof


def qualification_prerequisites(value, bind):
    paths = {
        'preparation': ROOT / 'preparation-01.json',
        'native_terminal': ROOT / 'qualification-terminal-status-01.json',
        'qualification_report': CANDIDATE_DIR / 'report.json',
        'source_map': CANDIDATE_DIR / 'source-map.json',
        'isolated_summary': CANDIDATE_DIR / 'isolated-tests/summary.json',
        'isolated_audit': CANDIDATE_DIR / 'isolated-tests.audit.json',
    }
    documents = {}
    for name, path in paths.items():
        need(value[name]['path'] == str(path), 'actual qualification receipt path differs')
        _, raw = bind(path, value[name])
        documents[name] = json.loads(raw)
    proof = verify_qualification_documents(value, documents['preparation'], documents['native_terminal'],
        documents['qualification_report'], documents['isolated_summary'], documents['isolated_audit'], documents['source_map'])
    qualified = documents['qualification_report']
    paths = [SOURCE / name for name in ('Cargo.toml', 'Cargo.lock', 'rustfmt.toml')]
    for name in ('src', 'examples'):
        paths.extend(path for path in (SOURCE / name).rglob('*') if path.is_file())
    actual = {path.relative_to(SOURCE).as_posix(): bind(path, retain=False)[0]['sha256'] for path in sorted(paths)}
    need(actual == qualified['source_after'], 'actual qualified source changed before tool installation')
    harness = {path.name: bind(path, retain=False)[0]['sha256']
               for path in sorted((SOURCE / 'tools/x230/20261028').glob('*.py'))}
    need(harness == qualified['harness_after'], 'actual qualification harness changed')
    binaries = {}
    need(set(qualified['binaries']) == {'hepta-runtime', 'hepta-runtime-jobctl', 'native_process_driver'},
         'qualified executable set differs')
    for name, item in qualified['binaries'].items():
        path = CANDIDATE_DIR / name
        need(item['path'] == str(path) and os.access(path, os.X_OK), 'qualified artifact path differs')
        row, _ = bind(path, retain=False)
        need(row['sha256'] == item['sha256'], 'actual qualified executable changed')
        binaries[name] = row
    for label in ('launcher', 'input'):
        item = documents['preparation'][label]
        need(Path(item['path']).parent == STAGE_ROOT / 'tools', 'qualification bootstrap input path differs')
        bind(item['path'], item, retain=False)
    proof.update(actual_binaries=binaries, source_files=len(actual), harness_files=len(harness))
    return proof


def build_installation(bundles):
    observation = json.loads(bundles['observation']['observation-tools-manifest-03.json'])
    lifecycle = json.loads(bundles['lifecycle']['lifecycle-tools-manifest-01.json'])
    parent = json.loads(bundles['parent']['lifecycle-launcher-manifest-03.json'])
    need(observation['schema'] == 'hepta-r26-observation-tools-install/v2'
         and observation['prepared_only'] is True and observation['create_only'] is True
         and observation['destination_root'] == str(ROOT) and len(observation['files']) == 9
         and set(observation['files']) == set(bundles['observation']) - {'observation-tools-manifest-03.json'},
         'observation payload manifest differs')
    need(lifecycle['schema'] == 'hepta-r25-lifecycle-tools/v1' and len(lifecycle['files']) == 27
         and set(lifecycle['files']) == set(bundles['lifecycle']) - {'lifecycle-tools-manifest-01.json'},
         'native lifecycle payload manifest differs')
    need(parent['schema'] == 'hepta-r26-lifecycle-launcher-bundle/v2'
         and parent['prepared_only'] is True and parent['create_only'] is True
         and parent['preserve_bundle_at'] == str(ROOT / 'lifecycle-launcher-bundle-03')
         and parent['installations'] == PARENT_INSTALL and len(parent['files']) == 17
         and set(parent['files']) == set(bundles['parent']) - {'lifecycle-launcher-manifest-03.json'},
         'outer lifecycle payload manifest differs')
    for label, manifest in (('observation', observation), ('lifecycle', lifecycle), ('parent', parent)):
        for name, pin in manifest['files'].items():
            need(identity(bundles[label][name]) == pin, 'payload manifest identity differs')
    need(parent['requires_observation_tools_manifest'] == identity(bundles['observation']['observation-tools-manifest-03.json'])
         and parent['requires_native_tools_manifest'] == identity(bundles['lifecycle']['lifecycle-tools-manifest-01.json']),
         'reviewed bundle dependencies disagree')
    obs_example = json.loads(bundles['observation']['campaign-inputs-01.example.json'])
    life_example = json.loads(bundles['parent']['lifecycle-inputs-01.example.json'])
    need(obs_example['launcher_sha256'] == life_example['campaign_helpers']['sha256']
         == identity(bundles['observation']['tools-03/r26_campaign.py'])['sha256']
         and life_example['launcher_sha256'] == identity(bundles['parent']['tools-03/r26_lifecycle_campaign.py'])['sha256']
         and life_example['tools_manifest']['sha256'] == identity(bundles['lifecycle']['lifecycle-tools-manifest-01.json'])['sha256'],
         'example helper identity differs')
    monitor = {}
    for label, name in {'module': 'compiler_monitor.py', 'validator': 'validate_compiler_monitor.py',
                        'reader': 'compiler_state.py', 'policy': 'compiler-monitor-policy-01.json'}.items():
        member = 'tools-03/' + name
        monitor[label] = {'path': str(ROOT / member), **identity(bundles['observation'][member])}
    need(obs_example['compiler_monitor'] == life_example['compiler_monitor'] == monitor,
         'actual four monitor paths or source identities differ between payload and templates')
    for example in (obs_example, life_example):
        need(example['attempt'] == '01' and example['candidate_release'] == 'R26'
             and example['qualification_terminal_status']['job_id'] is None
             and example['source_inputs_sha256'] is None
             and all(row == {'bytes': None, 'sha256': None} for row in example['candidate_binaries'].values()),
             'reviewed example was replaced by premature future evidence')
    plan = []
    for label, prefix in (('observation', ''), ('lifecycle', 'lifecycle-tools-03/'),
                           ('parent', 'lifecycle-launcher-bundle-03/')):
        for name, raw in sorted(bundles[label].items()):
            plan.append((prefix + name, raw, label, name))
    for name, path in sorted(PARENT_INSTALL.items()):
        plan.append((Path(path).relative_to(ROOT).as_posix(), bundles['parent'][name], 'parent', name))
    need(len(plan) == len({row[0] for row in plan}) == 59, 'installation collision or file count differs')
    for relative, _, _, _ in plan:
        path = PurePosixPath(relative)
        need(path.as_posix() == relative and not path.is_absolute() and '..' not in path.parts
             and ((path.parent.as_posix() == '.' and relative in ROOT_FILES)
                  or path.parent.as_posix() in NEW_DIRECTORIES), 'destination is outside fixed new scope')
    return plan


def absent(directory, name):
    try:
        os.stat(name, dir_fd=directory, follow_symlinks=False)
    except FileNotFoundError:
        return
    raise RuntimeError('existing destination must not be replaced: ' + name)


def create_file(directory, name, raw):
    need(Path(name).name == name, 'direct destination required')
    fd = os.open(name, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW | os.O_CLOEXEC, 0o600, dir_fd=directory)
    with os.fdopen(fd, 'wb') as stream:
        stream.write(raw)
        stream.flush()
        os.fsync(stream.fileno())
    result = read_at(directory, name, identity(raw))
    need(result['mode'] == 0o600, 'created file is not private')
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--installer-sha256', required=True)
    args = parser.parse_args()
    need(sys.platform == 'linux' and os.geteuid() != 0 and HEX.fullmatch(args.installer_sha256),
         'native Linux operator and reviewed source SHA required')
    need(Path(__file__).resolve() == SCRIPT and ROOT.resolve(strict=True) == ROOT,
         'fixed installer and existing qualifier-created R26 root required')
    os.umask(0o077)
    bindings, directories, created, created_dirs = [], {}, [], []
    root_fd = os.open(ROOT, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW | os.O_CLOEXEC)

    def bind(path, expected=None, retain=True):
        row, raw = read_path(path, expected, retain=retain)
        bindings.append(row)
        return row, raw

    try:
        before = os.fstat(root_fd)
        need(before.st_uid == os.geteuid() and stat.S_IMODE(before.st_mode) == 0o700,
             'qualifier-created root is not owned private0700')
        own, _ = bind(SCRIPT)
        need(own['sha256'] == args.installer_sha256, 'reviewed installer source changed')
        input_identity, raw = bind(QUALIFICATION_INPUT)
        qualification = qualification_prerequisites(json.loads(raw), bind)
        bundles, archive_rows = {}, {}
        for label, spec in ARCHIVES.items():
            need(Path(spec['path']).parent == STAGE_ROOT, 'staged archive is outside existing R25 root')
            row, raw = bind(spec['path'], spec)
            bundles[label] = members_from_archive(raw, spec)
            archive_rows[label] = dict(row, member_count=len(bundles[label]))
        plan = build_installation(bundles)
        # Only the named destinations are checked. Existing unrelated parent
        # entries, including binary_write's persistent locks, are not enumerated.
        for name in (*[d for d in NEW_DIRECTORIES if '/' not in d], *sorted(ROOT_FILES), RECEIPT):
            absent(root_fd, name)
        for row in bindings:
            need(read_path(row['path'], row, retain=False)[0] == row, 'prerequisite changed before installation')
        # No mutation occurs before all actual qualification and archive gates.
        for relative in NEW_DIRECTORIES:
            path = PurePosixPath(relative)
            owner_fd = root_fd if path.parent.as_posix() == '.' else directories[path.parent.as_posix()]
            os.mkdir(path.name, mode=0o700, dir_fd=owner_fd)
            fd = os.open(path.name, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW | os.O_CLOEXEC, dir_fd=owner_fd)
            current = os.fstat(fd)
            need(current.st_uid == os.geteuid() and stat.S_IMODE(current.st_mode) == 0o700, 'created directory ownership differs')
            directories[relative] = fd
            created_dirs.append(relative)
        installed = []
        for relative, raw, label, member in plan:
            path = PurePosixPath(relative)
            owner_fd = root_fd if path.parent.as_posix() == '.' else directories[path.parent.as_posix()]
            row = create_file(owner_fd, path.name, raw)
            created.append(relative)
            installed.append(dict(row, path=str(ROOT / relative), archive=label, member=member))
        for relative, fd in directories.items():
            os.fsync(fd)
            path = PurePosixPath(relative)
            owner_fd = root_fd if path.parent.as_posix() == '.' else directories[path.parent.as_posix()]
            need(stamp(os.fstat(fd)) == stamp(os.stat(path.name, dir_fd=owner_fd, follow_symlinks=False)),
                 'installed directory identity changed')
        for relative, raw, _, _ in plan:
            path = PurePosixPath(relative)
            read_at(root_fd if path.parent.as_posix() == '.' else directories[path.parent.as_posix()], path.name, identity(raw))
        for row in bindings:
            need(read_path(row['path'], row, retain=False)[0] == row, 'original prerequisite changed during installation')
        need(os.fstat(root_fd).st_ino == ROOT.lstat().st_ino and os.fstat(root_fd).st_dev == ROOT.lstat().st_dev,
             'original root directory was replaced')
        report = {'schema': 'hepta-r26-reviewed-tools-install/v2', 'installed': True,
                  'finished_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
                  'installer': own, 'actual_qualification_input': input_identity, 'qualification': qualification,
                  'archives': archive_rows, 'created_directories': created_dirs, 'installed_file_count': len(installed),
                  'files': installed, 'input_bindings': bindings, 'all_destinations_initially_absent': True,
                  'manual_regular_member_extraction': True, 'all_files_and_archives_rehashed': True,
                  'source_or_cache_modified': False, 'production_services_modified': False,
                  'packaged_code_executed': False, 'tests_run': 0, 'campaigns_started': 0, 'automatic_retries': 0}
        receipt = create_file(root_fd, RECEIPT, encoded(report))
        os.fsync(root_fd)
        print(json.dumps({'installed': True, 'installed_file_count': len(installed),
                          'receipt': dict(receipt, path=str(ROOT / RECEIPT)), 'tests_run': 0,
                          'campaigns_started': 0, 'source_or_cache_modified': False}), flush=True)
    except BaseException as error:
        print(json.dumps({'installed': False, 'created_files': created, 'created_directories': created_dirs,
                          'error': {'type': type(error).__name__, 'reason': str(error)},
                          'automatic_retries': 0, 'tests_run': 0, 'campaigns_started': 0}), flush=True)
        raise
    finally:
        for fd in reversed(list(directories.values())):
            os.close(fd)
        os.close(root_fd)


if __name__ == '__main__':
    main()
