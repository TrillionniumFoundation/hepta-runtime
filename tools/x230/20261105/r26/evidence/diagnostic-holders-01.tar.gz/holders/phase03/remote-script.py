#!/usr/bin/env python3
"""Bind the actual Mac-holder stdin buffer to one installed diagnostic wrapper."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import stat
import sys
import traceback

sys.dont_write_bytecode = True
ROOT = Path('/home/qian/hepta-runtime-optimization-20261105-r25')
BOOTSTRAP = ROOT / 'mechanism-monitor-bootstrap-03.py'
TOOLS = ROOT / 'mechanism-monitor-tools-03'
WRAPPER = TOOLS / 'run_monitored_phase_03.py'
ENTRY = ROOT / 'mechanism-monitor-bootstrap-entry-03.json'
REPORT = ROOT / 'mechanism-monitor-bootstrap-report-03.json'
WRAPPER_SHA = '293dde7bf6608b34eb1741aac44ba373b3362edc5bcc1f96e31ac663d9332103'
MANIFEST_SHA = '5a0efdf879e9eb9889caea2176db220e8b0f33806fc1835d2257549309678016'
BUILD_REPORT_SHA = '6364c71ca6567b40fbfe8c211f0479f7a89e1c4dab568e1e7756be36e528f705'
HOLDER_SHA = '715e996217c7d33a7483354f16f2d39c9a033f51f3a20a52484495a00262dd65'
FIELDS = ('st_dev', 'st_ino', 'st_uid', 'st_mode', 'st_nlink', 'st_size', 'st_mtime_ns', 'st_ctime_ns')


def checked_source(path):
    if path.resolve(strict=True) != path:
        raise ValueError('source path is indirect')
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
    with os.fdopen(fd, 'rb') as stream:
        before = os.fstat(stream.fileno())
        if (not stat.S_ISREG(before.st_mode) or before.st_uid != os.geteuid()
                or before.st_nlink != 1 or not 0 <= before.st_size <= 65536):
            raise ValueError('source descriptor type, owner, link count or byte bound differs')
        raw = stream.read(65537)
        after = os.fstat(stream.fileno())
    current = path.lstat()
    if (len(raw) != after.st_size or path.resolve(strict=True) != path
            or any(getattr(before, key) != getattr(after, key) or getattr(after, key) != getattr(current, key) for key in FIELDS)):
        raise ValueError('source changed during stable descriptor read')
    return {'path': str(path), 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest(),
            'descriptor_identity': {key: getattr(after, key) for key in FIELDS}}, raw


def save_new(path, value):
    raw = (json.dumps(value, sort_keys=True, indent=2, allow_nan=False) + '\n').encode()
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600)
    with os.fdopen(fd, 'wb') as stream:
        stream.write(raw); stream.flush(); os.fsync(stream.fileno())
    return {'path': str(path), 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


def execute_checked_wrapper(raw, path, argv):
    old_argv = list(sys.argv)
    try:
        sys.argv = list(argv)
        namespace = {'__file__': str(path), '__name__': '__main__', '__package__': None}
        try:
            exec(compile(raw, str(path), 'exec'), namespace)
        except SystemExit as stopped:
            if type(stopped.code) is not int:
                raise ValueError('wrapper returned a noninteger SystemExit code')
            return stopped.code
        raise ValueError('reviewed wrapper did not produce its required SystemExit result')
    finally:
        sys.argv = old_argv


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--launcher-sha256', required=True)
    args = parser.parse_args()
    if not re.fullmatch('[0-9a-f]{64}', args.launcher_sha256):
        raise ValueError('holder stdin SHA is not a canonical SHA256')
    if sys.platform != 'linux' or os.geteuid() == 0 or ROOT.resolve(strict=True) != ROOT:
        raise ValueError('direct non-root Linux task root required')
    if os.path.lexists(ENTRY) or os.path.lexists(REPORT):
        raise ValueError('bootstrap already entered; no reuse or automatic retry')
    own, _ = checked_source(BOOTSTRAP)
    wrapper, wrapper_bytes = checked_source(WRAPPER)
    manifest, _ = checked_source(TOOLS / 'package-manifest.json')
    if own['sha256'] != args.launcher_sha256:
        raise ValueError('installed bootstrap differs from actual holder stdin SHA')
    if wrapper['sha256'] != WRAPPER_SHA or manifest['sha256'] != MANIFEST_SHA:
        raise ValueError('installed wrapper or monitor package manifest differs from frozen entry')
    argv = [str(WRAPPER), '--build-report-sha256', BUILD_REPORT_SHA,
            '--monitor-package-manifest-sha256', MANIFEST_SHA,
            '--transmitted-bootstrap-sha256', args.launcher_sha256]
    report = {'schema': 'hepta-r25-phase-stdin-bootstrap/v2', 'passed': False,
              'diagnostic_only': True, 'production_candidate': False,
              'holder_supplied_stdin_sha256': args.launcher_sha256,
              'expected_unchanged_holder_sha256': HOLDER_SHA,
              'installed_bootstrap_source': own, 'installed_wrapper_source': wrapper,
              'monitor_package_manifest': manifest, 'wrapper_argv': argv,
              'wrapper_invocations': 0, 'wrapper_returncode': None, 'automatic_retries': 0,
              'new_processes_spawned': 0, 'source_binding_scope':
              'The unchanged Mac holder hashes, retains and transmits the same source byte buffer. '
              'Final admission additionally requires its original source/report/foreground argv and '
              'retained remote-script.py to bind this exact bootstrap SHA. This process compares the '
              'supplied stdin SHA with the installed source; it does not reread consumed Python stdin.'}
    report['entry_receipt'] = save_new(ENTRY, report)
    print(json.dumps({'phase': 'source_bound_bootstrap_entered', 'entry': report['entry_receipt'],
                      'holder_supplied_stdin_sha256': args.launcher_sha256, 'wrapper_sha256': WRAPPER_SHA}), flush=True)
    try:
        report['wrapper_invocations'] = 1
        report['wrapper_returncode'] = execute_checked_wrapper(wrapper_bytes, WRAPPER, argv)
    except BaseException as error:
        report['error'] = type(error).__name__ + ': ' + str(error)
        traceback.print_exc()
    finally:
        try:
            for label, expected in [('installed_bootstrap_source', own), ('installed_wrapper_source', wrapper),
                                    ('monitor_package_manifest', manifest)]:
                actual, _ = checked_source(Path(expected['path']))
                if actual != expected:
                    raise ValueError('source changed during original wrapper: ' + label)
            report['source_descriptors_stable'] = True
        except BaseException as error:
            report['source_descriptors_stable'] = False
            report['postcheck_error'] = type(error).__name__ + ': ' + str(error)
        report['passed'] = bool(report['wrapper_returncode'] == 0 and report['wrapper_invocations'] == 1
                                and report['source_descriptors_stable'] and 'error' not in report)
        final = save_new(REPORT, report)
    print(json.dumps({'phase': 'source_bound_bootstrap_finished', 'passed': report['passed'],
                      'wrapper_returncode': report['wrapper_returncode'], 'report': final}), flush=True)
    return 0 if report['passed'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
