// Copyright 2026 Muvon Un Limited
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// File System MCP provider - modular structure

pub mod background;
pub mod core;
pub mod delta;
pub mod directory;
pub mod file_ops;
pub mod parity_ops;
pub mod remote;
pub mod search;
pub mod shell;
pub mod text_editing;
pub mod text_file_write;
pub mod workdir;

#[cfg(test)]
mod fs_tests;

// Re-export main functionality
pub use core::{execute_batch_edit, execute_extract_lines, execute_text_editor, execute_view};

pub use remote::{parse_path_source, PathSource};
pub use shell::execute_shell_command;
pub use workdir::{execute_workdir_command, WorkdirResult};
