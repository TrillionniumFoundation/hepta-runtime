// Copyright 2026 Muvon Un Limited
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// Directory operations module — file listing and content search using ignore + pure-Rust matching.

use super::super::McpToolCall;
use super::remote::{
	io_list_dir, io_read, io_read_to_string, resolve_path_source, IoMetadata, PathSource,
};
use super::search::{self, Matcher};
use crate::utils::line_hash::line_id_at;
use anyhow::{bail, Result};
use ignore::{overrides::Override, overrides::OverrideBuilder, WalkBuilder};
use rayon::prelude::*;
use std::collections::HashMap;
use std::path::{Path, PathBuf};
use std::sync::{Arc, Mutex, OnceLock};
use std::time::SystemTime;

// Listing annotations are a pure function of file content; keying on (mtime, len)
// makes a repeat listing of an unchanged tree stat-only instead of re-reading every
// file. Same fingerprint editors use for external-change detection.
type AnnotationCache = HashMap<PathBuf, (SystemTime, u64, String)>;
static ANNOTATIONS: OnceLock<Mutex<AnnotationCache>> = OnceLock::new();
const ANNOTATION_CACHE_MAX: usize = 100_000;

fn annotation_cache() -> &'static Mutex<AnnotationCache> {
	ANNOTATIONS.get_or_init(|| Mutex::new(HashMap::new()))
}

// Annotation suffix for a listed file: "NL\t~Nt" or "(binary)". None = unreadable.
// Newline count over raw bytes — the listing annotation needs only the count,
// not decoded text.
fn bytecount_newlines(bytes: &[u8]) -> usize {
	bytes.iter().filter(|&&b| b == b'\n').count()
}
fn annotation_suffix(full_path: &Path, mtime: Option<SystemTime>, len: u64) -> Option<String> {
	if let Some(mt) = mtime {
		if let Some((c_mt, c_len, suffix)) = annotation_cache()
			.lock()
			.expect("annotation cache poisoned")
			.get(full_path)
		{
			if *c_mt == mt && *c_len == len {
				return Some(suffix.clone());
			}
		}
	}

	let bytes = std::fs::read(full_path).ok()?;
	// Skip likely binary files: NUL-density check on a leading sample.
	let sample_size = bytes.len().min(512);
	let null_count = bytes[..sample_size].iter().filter(|&&b| b == 0).count();
	let suffix = if null_count > sample_size / 10 {
		"(binary)".to_string()
	} else {
		// Count newlines on the raw bytes: identical to `lines().count()` for both
		// LF and CRLF, without the lossy UTF-8 copy of the whole file.
		let newlines = bytecount_newlines(&bytes);
		let line_count = if bytes.is_empty() {
			0
		} else if bytes[bytes.len() - 1] == b'\n' {
			newlines
		} else {
			newlines + 1
		};
		format!(
			"{}L\t~{}t",
			line_count,
			crate::utils::truncation::estimate_tokens(bytes.len())
		)
	};

	if let Some(mt) = mtime {
		let mut cache = annotation_cache()
			.lock()
			.expect("annotation cache poisoned");
		// ponytail: crude bound — clear and rebuild lazily instead of tracking LRU.
		if cache.len() >= ANNOTATION_CACHE_MAX {
			cache.clear();
		}
		cache.insert(full_path.to_path_buf(), (mt, len, suffix.clone()));
	}
	Some(suffix)
}
// `|` predates the rg-compatible matcher and remains a convenient way to pass
// several ordered -g-style globs through one MCP string. Do not split escaped
// pipes or pipes inside character classes, where `|` names a literal character.
const MAX_PATTERN_BYTES: usize = 4096;
const MAX_PATTERN_ALTERNATIVES: usize = 64;
const MAX_BRACE_NESTING: usize = 16;

fn split_pattern_alternatives(pattern: &str) -> Result<Vec<&str>, String> {
	if pattern.len() > MAX_PATTERN_BYTES {
		return Err(format!(
			"Invalid `pattern`: {} bytes exceeds the {MAX_PATTERN_BYTES}-byte limit. Narrow the glob or split the search into separate `view` calls.",
			pattern.len()
		));
	}
	if pattern.chars().any(char::is_control) {
		return Err(
			"Invalid `pattern`: control characters are not allowed. Pass one single-line glob string."
				.to_string(),
		);
	}

	let mut alternatives = Vec::new();
	let mut start = 0;
	let mut escaped = false;
	let mut in_class = false;

	for (index, ch) in pattern.char_indices() {
		if escaped {
			escaped = false;
			continue;
		}
		match ch {
			'\\' => escaped = true,
			'[' if !in_class => in_class = true,
			']' if in_class => in_class = false,
			'|' if !in_class => {
				let alternative = pattern[start..index].trim();
				if alternative.is_empty() {
					return Err(format!(
						"Invalid `pattern` glob {pattern:?}: every `|`-separated glob must be non-empty"
					));
				}
				if alternatives.len() >= MAX_PATTERN_ALTERNATIVES {
					return Err(format!(
						"Invalid `pattern`: more than {MAX_PATTERN_ALTERNATIVES} `|`-separated globs. Split the search into separate `view` calls."
					));
				}
				alternatives.push(alternative);
				start = index + ch.len_utf8();
			}
			_ => {}
		}
	}

	let alternative = pattern[start..].trim();
	if alternative.is_empty() {
		return Err(format!(
			"Invalid `pattern` glob {pattern:?}: every `|`-separated glob must be non-empty"
		));
	}
	if alternatives.len() >= MAX_PATTERN_ALTERNATIVES {
		return Err(format!(
			"Invalid `pattern`: more than {MAX_PATTERN_ALTERNATIVES} `|`-separated globs. Split the search into separate `view` calls."
		));
	}
	alternatives.push(alternative);

	for glob in &alternatives {
		if glob.starts_with('#') {
			return Err(format!(
				"Invalid `pattern` glob {glob:?}: a leading `#` is parsed as a comment. Use `\\#` to match a literal leading `#`."
			));
		}
		if *glob == "!" {
			return Err(
				"Invalid `pattern` glob \"!\": an exclusion must include a glob after `!`."
					.to_string(),
			);
		}
	}
	Ok(alternatives)
}

fn validate_glob_structure(glob: &str) -> Result<(), String> {
	let mut branches_have_content: Vec<bool> = Vec::new();
	let mut escaped = false;
	let mut in_class = false;

	for ch in glob.chars() {
		if escaped {
			if let Some(has_content) = branches_have_content.last_mut() {
				*has_content = true;
			}
			escaped = false;
			continue;
		}
		if in_class {
			if ch == ']' {
				in_class = false;
			}
			continue;
		}

		match ch {
			'\\' => escaped = true,
			'[' => {
				in_class = true;
				if let Some(has_content) = branches_have_content.last_mut() {
					*has_content = true;
				}
			}
			'{' => {
				if branches_have_content.len() >= MAX_BRACE_NESTING {
					return Err(format!(
						"Invalid `pattern` glob {glob:?}: brace nesting exceeds the {MAX_BRACE_NESTING}-level limit"
					));
				}
				branches_have_content.push(false);
			}
			',' if !branches_have_content.is_empty() => {
				if let Some(has_content) = branches_have_content.last_mut() {
					if !*has_content {
						return Err(format!(
							"Invalid `pattern` glob {glob:?}: empty brace alternatives are not supported"
						));
					}
					*has_content = false;
				}
			}
			'}' if !branches_have_content.is_empty() => {
				if let Some(has_content) = branches_have_content.pop() {
					if !has_content {
						return Err(format!(
							"Invalid `pattern` glob {glob:?}: empty brace alternatives are not supported"
						));
					}
					if let Some(parent_has_content) = branches_have_content.last_mut() {
						*parent_has_content = true;
					}
				}
			}
			_ => {
				if let Some(has_content) = branches_have_content.last_mut() {
					*has_content = true;
				}
			}
		}
	}

	Ok(())
}

// Compile before traversal so malformed or adversarial patterns fail without walking a tree.
// Positive globs include, leading-! globs exclude, and later alternatives take precedence.
fn build_pattern_matcher(pattern: &str) -> Result<Override, String> {
	let alternatives = split_pattern_alternatives(pattern)?;
	let mut builder = OverrideBuilder::new("");
	for glob in alternatives {
		validate_glob_structure(glob)?;
		builder
			.add(glob)
			.map_err(|e| format!("Invalid `pattern` glob {glob:?}: {e}"))?;
	}
	builder
		.build()
		.map_err(|e| format!("Invalid `pattern` glob {pattern:?}: {e}"))
}

fn apply_pattern(files: &mut Vec<String>, matcher: &Override) {
	files.retain(|file| !matcher.matched(file, false).is_ignore());
}

// Build an ignore::WalkBuilder with the given options
fn build_walker(directory: &str, max_depth: Option<usize>, include_hidden: bool) -> WalkBuilder {
	let mut builder = WalkBuilder::new(directory);
	builder
		.git_ignore(true)
		.git_global(true)
		.git_exclude(true)
		.require_git(false)
		.follow_links(false)
		.hidden(!include_hidden);
	if let Some(depth) = max_depth {
		builder.max_depth(Some(depth));
	}
	builder
}

// Collect file paths from walker, relative to working_dir
fn collect_file_paths(builder: &mut WalkBuilder, working_dir: &Path) -> Vec<String> {
	let walker = builder.build();
	let mut files: Vec<String> = Vec::new();
	for entry in walker.flatten() {
		let path = entry.path();
		// The walker already knows the entry type — `path.is_file()` would stat again.
		if !entry.file_type().is_some_and(|ft| ft.is_file()) {
			continue;
		}
		let mut rel = path
			.strip_prefix(working_dir)
			.unwrap_or(path)
			.to_string_lossy()
			.to_string();
		// Normalize Windows separators so listings and `/`-containing glob patterns
		// behave identically on all platforms ('\' is a legal filename char on Unix,
		// so only rewrite it where it is a separator).
		if cfg!(windows) {
			rel = rel.replace('\\', "/");
		}
		files.push(rel);
	}
	files.sort();
	files
}

// --- Remote directory listing (SFTP) ---

// Construct a child PathSource for a remote directory entry.
fn remote_child(source: &PathSource, name: &str) -> PathSource {
	match source {
		PathSource::Remote {
			host,
			port,
			user,
			path,
			user_explicit,
			port_explicit,
		} => {
			let new_path = if path.ends_with('/') {
				format!("{path}{name}")
			} else {
				format!("{path}/{name}")
			};
			PathSource::Remote {
				host: host.clone(),
				port: *port,
				user: user.clone(),
				path: new_path,
				user_explicit: *user_explicit,
				port_explicit: *port_explicit,
			}
		}
		_ => unreachable!("remote_child called on non-remote source"),
	}
}

// Remote listings without an explicit max_depth stop at the root entries: a
// full walk of e.g. a home directory (target/, node_modules/ under every
// checkout) is the wrong default for `ls`-style use.
const REMOTE_DEFAULT_MAX_DEPTH: usize = 1;

// In-flight SFTP requests per walk level / content search. One channel
// multiplexes them by request id and OpenSSH's sftp-server handles this many
// outstanding without stalling; each read_dir is 3+ round trips, so serial
// walks of a thousand directories took minutes.
const REMOTE_CONCURRENCY: usize = 32;

// Drive futures with at most REMOTE_CONCURRENCY in flight. Results come back
// in completion order; callers sort.
async fn join_bounded<F, T>(futures: Vec<F>) -> Result<Vec<T>>
where
	F: std::future::Future<Output = T> + Send + 'static,
	T: Send + 'static,
{
	let mut set = tokio::task::JoinSet::new();
	let mut pending = futures.into_iter();
	for f in pending.by_ref().take(REMOTE_CONCURRENCY) {
		set.spawn(f);
	}
	let mut out = Vec::new();
	while let Some(joined) = set.join_next().await {
		out.push(joined.map_err(|e| anyhow::anyhow!("remote task failed: {e}"))?);
		if let Some(f) = pending.next() {
			set.spawn(f);
		}
	}
	Ok(out)
}

fn parse_gitignore(root: &str, text: &str) -> Option<ignore::gitignore::Gitignore> {
	let mut builder = ignore::gitignore::GitignoreBuilder::new(root);
	for line in text.lines() {
		let _ = builder.add_line(None, line);
	}
	builder.build().ok()
}

// A directory queued for listing during a remote walk.
struct RemoteDir {
	source: PathSource,
	rel: String,
	depth: usize,
	// .gitignore of this directory and its ancestors, each rooted at its own
	// directory so `matched` sees paths relative to it.
	ignores: Vec<Arc<ignore::gitignore::Gitignore>>,
}

// Walk a remote tree breadth-first: every directory of a level is listed
// concurrently, then the .gitignore files that level revealed are fetched
// concurrently, so wall time scales with depth rather than directory count.
// Only the metadata read_dir already returns is used — nothing per file.
// Each directory's .gitignore prunes its subtree before it is descended, so
// target/ and node_modules/ under nested checkouts are skipped like rg does.
async fn collect_remote_files(
	root: &PathSource,
	max_depth: Option<usize>,
	include_hidden: bool,
) -> Result<Vec<(String, IoMetadata)>> {
	let mut files = Vec::new();
	let mut level = vec![RemoteDir {
		source: root.clone(),
		rel: String::new(),
		depth: 0,
		ignores: Vec::new(),
	}];

	while !level.is_empty() {
		let listings: Vec<_> = level
			.drain(..)
			.map(|dir| async move {
				let entries = io_list_dir(&dir.source).await;
				(dir, entries)
			})
			.collect();
		let mut listed: Vec<(RemoteDir, Vec<(String, IoMetadata)>)> = join_bounded(listings)
			.await?
			.into_iter()
			.map(|(dir, entries)| entries.map(|e| (dir, e)))
			.collect::<Result<_>>()?;

		let ignore_reads: Vec<_> = listed
			.iter()
			.enumerate()
			.filter(|(_, (_, entries))| {
				entries
					.iter()
					.any(|(name, meta)| name == ".gitignore" && meta.is_file)
			})
			.map(|(i, (dir, _))| {
				let gitignore = remote_child(&dir.source, ".gitignore");
				let rel = dir.rel.clone();
				async move { (i, rel, io_read_to_string(&gitignore).await) }
			})
			.collect();
		for (i, rel, text) in join_bounded(ignore_reads).await? {
			if let Some(gi) = text.ok().and_then(|t| parse_gitignore(&rel, &t)) {
				listed[i].0.ignores.push(Arc::new(gi));
			}
		}

		for (dir, entries) in listed {
			for (name, meta) in entries {
				if !include_hidden && name.starts_with('.') {
					continue;
				}
				let rel_path = if dir.rel.is_empty() {
					name.clone()
				} else {
					format!("{}/{name}", dir.rel)
				};
				if dir
					.ignores
					.iter()
					.any(|gi| gi.matched(&rel_path, meta.is_dir).is_ignore())
				{
					continue;
				}
				if meta.is_dir {
					if max_depth.is_some_and(|d| dir.depth >= d) {
						continue;
					}
					level.push(RemoteDir {
						source: remote_child(&dir.source, &name),
						rel: rel_path,
						depth: dir.depth + 1,
						ignores: dir.ignores.clone(),
					});
				} else {
					files.push((rel_path, meta));
				}
			}
		}
	}

	files.sort_by(|a, b| a.0.cmp(&b.0));
	Ok(files)
}

// Render content-search hits for one remote file, or None when it is binary,
// unreadable or has no match.
fn render_content_matches(
	rel_path: &str,
	bytes: &[u8],
	matcher: &Matcher,
	context_lines: usize,
) -> Option<String> {
	let sample_size = bytes.len().min(512);
	let null_count = bytes[..sample_size].iter().filter(|&&b| b == 0).count();
	if null_count > sample_size / 10 {
		return None;
	}

	let file_content = String::from_utf8_lossy(bytes);
	let blocks = search::search_lines(&file_content, matcher, context_lines);
	if blocks.is_empty() {
		return None;
	}

	let file_lines: Vec<&str> = file_content.lines().collect();
	let mut rendered_blocks: Vec<String> = Vec::new();
	for block in &blocks {
		let mut rendered = Vec::new();
		for &n in &block.line_numbers {
			if n <= file_lines.len() {
				rendered.push(format!(
					"{}|{}",
					line_id_at(&file_lines, n),
					file_lines[n - 1]
				));
			}
		}
		rendered_blocks.push(rendered.join("\n"));
	}
	Some(format!("{}:\n{}", rel_path, rendered_blocks.join("\n")))
}

// Annotation suffix for a remote file, from metadata ONLY — downloading each
// file for line/token counts made listing a large tree take minutes.
fn annotation_suffix_remote(meta: &IoMetadata) -> String {
	if meta.size > super::file_ops::MAX_VIEW_FILE_BYTES {
		format!("(large: {}MB)", meta.size / (1024 * 1024))
	} else if meta.size >= 1024 {
		format!("{}KB", meta.size / 1024)
	} else {
		format!("{}B", meta.size)
	}
}

// List a remote directory — file listing or content search via SFTP.
// Honors .gitignore at every level of the walk; hidden files are controlled
// by `include_hidden` like the local path.
async fn list_directory_remote(
	source: &PathSource,
	pattern: Option<String>,
	content: Option<String>,
	max_depth: Option<usize>,
	include_hidden: bool,
	context_lines: usize,
	regex_flag: bool,
) -> Result<String> {
	let has_content = content.as_ref().is_some_and(|c| !c.trim().is_empty());
	let pattern_matcher = pattern
		.as_deref()
		.map(build_pattern_matcher)
		.transpose()
		.map_err(|e| anyhow::anyhow!(e))?;

	let mut files = collect_remote_files(source, max_depth, include_hidden).await?;

	if let Some(ref matcher) = pattern_matcher {
		let mut names: Vec<String> = files.iter().map(|(name, _)| name.clone()).collect();
		apply_pattern(&mut names, matcher);
		if names.is_empty() {
			let name_pattern = pattern.as_deref().unwrap_or_default();
			return Ok(format!("No files matched pattern \"{name_pattern}\"."));
		}
		let keep: std::collections::HashSet<String> = names.into_iter().collect();
		files.retain(|(n, _)| keep.contains(n));
	}

	if has_content {
		let content_pattern = content.unwrap();
		let matcher = Arc::new(Matcher::new(&content_pattern, regex_flag)?);

		// Read and match concurrently; each task returns only its rendered
		// hits, so memory is bounded by matches, not tree size. Index keeps
		// the sorted file order in the output.
		let reads: Vec<_> = files
			.iter()
			.enumerate()
			.filter(|(_, (_, meta))| meta.size <= super::file_ops::MAX_VIEW_FILE_BYTES)
			.map(|(i, (rel_path, _))| {
				let file_source = remote_child(source, rel_path);
				let rel_path = rel_path.clone();
				let matcher = matcher.clone();
				async move {
					let hit = match io_read(&file_source).await {
						Ok(bytes) => {
							render_content_matches(&rel_path, &bytes, &matcher, context_lines)
						}
						Err(_) => None,
					};
					(i, hit)
				}
			})
			.collect();
		let mut hits: Vec<(usize, String)> = join_bounded(reads)
			.await?
			.into_iter()
			.filter_map(|(i, hit)| hit.map(|h| (i, h)))
			.collect();
		hits.sort_by_key(|(i, _)| *i);

		Ok(hits
			.into_iter()
			.map(|(_, h)| h)
			.collect::<Vec<_>>()
			.join("\n\n"))
	} else {
		let mut lines: Vec<String> = Vec::new();
		for (rel_path, meta) in &files {
			lines.push(format!("{}\t{}", rel_path, annotation_suffix_remote(meta)));
		}
		Ok(lines.join("\n"))
	}
}

// Execute list_directory — file listing or content search
pub async fn list_directory(call: &McpToolCall, directory: &str) -> Result<String> {
	let pattern = call
		.parameters
		.get("pattern")
		.and_then(|v| v.as_str())
		.map(|s| s.to_string());
	let content = call
		.parameters
		.get("content")
		.and_then(|v| v.as_str())
		.map(|s| s.to_string());
	let max_depth = call
		.parameters
		.get("max_depth")
		.and_then(|v| v.as_u64())
		.map(|n| n as usize);
	let include_hidden = call
		.parameters
		.get("include_hidden")
		.and_then(|v| v.as_bool())
		.unwrap_or(false);
	let context_lines = call
		.parameters
		.get("context")
		.and_then(|v| v.as_i64())
		.unwrap_or(0) as usize;

	let working_dir = call.workdir.clone();

	// Remote paths (ssh://, sftp://) dispatch to the SFTP listing path.
	let source = resolve_path_source(directory, &working_dir);
	if source.is_remote() {
		let regex_flag = call
			.parameters
			.get("regex")
			.and_then(|v| v.as_bool())
			.unwrap_or(false);
		// A bare listing stops at the root; pattern/content searches walk the
		// whole tree like rg, since a depth cap would silently drop matches.
		let is_search = pattern.is_some() || content.as_ref().is_some_and(|c| !c.trim().is_empty());
		let max_depth = if is_search {
			max_depth
		} else {
			max_depth.or(Some(REMOTE_DEFAULT_MAX_DEPTH))
		};
		return list_directory_remote(
			&source,
			pattern,
			content,
			max_depth,
			include_hidden,
			context_lines,
			regex_flag,
		)
		.await;
	}

	let abs_dir = if Path::new(directory).is_absolute() {
		std::path::PathBuf::from(directory)
	} else {
		working_dir.join(directory)
	};
	let abs_dir_str = abs_dir.to_string_lossy().to_string();

	let has_content = content.as_ref().is_some_and(|c| !c.trim().is_empty());

	if has_content {
		// Content search mode
		let content_pattern = content.unwrap();
		let regex_flag = call
			.parameters
			.get("regex")
			.and_then(|v| v.as_bool())
			.unwrap_or(false);

		// Compile matcher up front so invalid regex fails fast with a clear error.
		let matcher = Matcher::new(&content_pattern, regex_flag)?;

		let output = tokio::task::spawn_blocking(move || -> Result<String, String> {
			let pattern_matcher = pattern.as_deref().map(build_pattern_matcher).transpose()?;
			let mut builder = build_walker(&abs_dir_str, max_depth, include_hidden);
			let mut files = collect_file_paths(&mut builder, &working_dir);

			// The `pattern` glob narrows content search the same way it narrows listing —
			// silently ignoring it here would search files the caller explicitly excluded.
			if let Some(ref matcher) = pattern_matcher {
				apply_pattern(&mut files, matcher);
				if files.is_empty() {
					let name_pattern = pattern.as_deref().unwrap_or_default();
					return Ok(format!("No files matched pattern \"{name_pattern}\"."));
				}
			}

			// Parallel per-file scan. Each thread reads + searches independently;
			// results carry the original index so the final output preserves
			// the deterministic alphabetic order of `files`.
			let mut indexed: Vec<(usize, String)> = files
				.par_iter()
				.enumerate()
				.filter_map(|(i, rel_path)| {
					let full_path = working_dir.join(rel_path);

					// ponytail: files over the view cap are skipped like binaries — loading
					// a multi-GB artifact into memory (twice, with the lossy copy) is an OOM
					// hazard, and no real source file is that large.
					let meta = std::fs::metadata(&full_path).ok()?;
					if meta.len() > super::file_ops::MAX_VIEW_FILE_BYTES {
						return None;
					}

					let bytes = std::fs::read(&full_path).ok()?;

					// Skip likely binary files: NUL-density check on a leading sample.
					let sample_size = bytes.len().min(512);
					let null_count = bytes[..sample_size].iter().filter(|&&b| b == 0).count();
					if null_count > sample_size / 10 {
						return None;
					}

					// Lossy UTF-8 conversion lets us search Latin-1, mixed encodings,
					// and BOM-prefixed UTF-8 files without panicking. Invalid byte
					// sequences become U+FFFD; line structure is preserved.
					let file_content = String::from_utf8_lossy(&bytes);

					let blocks = search::search_lines(&file_content, &matcher, context_lines);
					if blocks.is_empty() {
						return None;
					}

					let file_lines: Vec<&str> = file_content.lines().collect();

					let mut rendered_blocks: Vec<String> = Vec::new();
					for block in &blocks {
						let mut rendered = Vec::new();
						for &n in &block.line_numbers {
							if n <= file_lines.len() {
								rendered.push(format!(
									"{}|{}",
									line_id_at(&file_lines, n),
									file_lines[n - 1]
								));
							}
						}
						rendered_blocks.push(rendered.join("\n"));
					}

					Some((i, format!("{}:\n{}", rel_path, rendered_blocks.join("\n"))))
				})
				.collect();

			indexed.sort_by_key(|(i, _)| *i);
			let file_results: Vec<String> = indexed.into_iter().map(|(_, s)| s).collect();
			Ok(file_results.join("\n\n"))
		})
		.await;

		match output {
			Ok(Ok(s)) => Ok(s),
			Ok(Err(e)) => bail!("{}", e),
			Err(join_err) => bail!("Failed to execute content search: {}", join_err),
		}
	} else {
		// File listing mode — annotate each file with line count + estimated tokens.
		let output = tokio::task::spawn_blocking(move || -> Result<String, String> {
			let pattern_matcher = pattern.as_deref().map(build_pattern_matcher).transpose()?;
			let mut builder = build_walker(&abs_dir_str, max_depth, include_hidden);
			let mut files = collect_file_paths(&mut builder, &working_dir);

			// Apply glob pattern filter if provided — an unparseable pattern is a caller
			// error, not a reason to silently return the unfiltered listing.
			if let Some(ref matcher) = pattern_matcher {
				apply_pattern(&mut files, matcher);
				if files.is_empty() {
					let name_pattern = pattern.as_deref().unwrap_or_default();
					return Ok(format!("No files matched pattern \"{name_pattern}\"."));
				}
			}

			// Parallel annotation (cached by mtime+len — see annotation_suffix).
			// Order is preserved via the carried index so output stays alphabetic.
			let mut indexed: Vec<(usize, String)> = files
				.par_iter()
				.enumerate()
				.map(|(i, rel_path)| {
					let full_path = working_dir.join(rel_path);
					let line = match std::fs::metadata(&full_path) {
						// Annotate oversized files from metadata alone — reading a huge
						// artifact just to count its lines wastes I/O and memory.
						Ok(meta) if meta.len() > super::file_ops::MAX_VIEW_FILE_BYTES => {
							format!("{}\t(large: {}MB)", rel_path, meta.len() / (1024 * 1024))
						}
						Ok(meta) => {
							match annotation_suffix(&full_path, meta.modified().ok(), meta.len()) {
								Some(suffix) => format!("{}\t{}", rel_path, suffix),
								None => rel_path.clone(),
							}
						}
						Err(_) => rel_path.clone(),
					};
					(i, line)
				})
				.collect();

			indexed.sort_by_key(|(i, _)| *i);
			let lines: Vec<String> = indexed.into_iter().map(|(_, s)| s).collect();
			Ok(lines.join("\n"))
		})
		.await;

		match output {
			Ok(Ok(s)) => Ok(s),
			Ok(Err(e)) => bail!("{}", e),
			Err(join_err) => bail!("Failed to execute directory listing: {}", join_err),
		}
	}
}

#[cfg(test)]
#[path = "directory_tests.rs"]
mod directory_tests;
