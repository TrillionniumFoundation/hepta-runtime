// Copyright 2026 Muvon Un Limited
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//! Runtime startup, private-store preparation, transports and graceful shutdown.

use anyhow::Result;
use clap::Parser;
use tracing::Level;

mod cli;
use hepta_runtime::mcp;

use cli::{Cli, Commands};

#[tokio::main]
async fn main() -> Result<()> {
	let cli = Cli::parse();

	match cli.command {
		Commands::Mcp {
			path,
			bind,
			ssh_key,
			ssh_timeout,
			runtime_config,
			auth_token_file,
			runtime_prewarm,
			runtime_audit_group_commit,
			runtime_observation_pool_profile,
			runtime_file_observation_pool,
		} => {
			let runtime_enabled = runtime_config.is_some();
			if let Some(config_path) = runtime_config.as_ref() {
				let config = mcp::runtime::RuntimeConfig::load(config_path)?;
				mcp::runtime::search_jobs::init_search_interpreters(&config)?;
				mcp::runtime::init_runtime(config)?;
				if runtime_prewarm || runtime_audit_group_commit {
					mcp::runtime::prepare_durable_stores().await?;
				}
				if runtime_audit_group_commit {
					mcp::runtime::request_audit::enable_group_commit()?;
				}
			}

			// Resolve working directory
			let working_directory = if let Some(p) = path {
				p.canonicalize().unwrap_or(p)
			} else {
				std::env::current_dir()?
			};

			// Stderr-only logging — no stdout (would corrupt stdio MCP protocol)
			init_mcp_logging();

			// Initialize SFTP pool for remote filesystem support.
			let config = mcp::fs::remote::SshConfig {
				key_path: ssh_key,
				timeout: std::time::Duration::from_secs(ssh_timeout.unwrap_or(30)),
			};
			mcp::fs::remote::init_sftp_pool(config);

			// Set the session root directory for all tool calls
			mcp::set_session_root_directory(working_directory.clone());

			let direct_transport = if runtime_enabled {
				Some(mcp::runtime::ssh::start_direct_transport()?)
			} else {
				None
			};
			let observation_pool = match mcp::runtime::ssh::start_observation_pool(
				runtime_observation_pool_profile.as_deref(),
				runtime_file_observation_pool,
			)
			.await
			{
				Ok(pool) => pool,
				Err(error) => {
					if let Some(owner) = direct_transport {
						owner.shutdown().await?;
					}
					return Err(error);
				}
			};
			let transport = match bind {
				Some(addr) => {
					// HTTP mode with Streamable HTTP transport.
					run_http_server(&addr, auth_token_file.as_deref(), runtime_enabled).await
				}
				None => {
					// STDIO mode (default)
					run_stdio_server(mcp::server::OctofsServer::new()).await
				}
			};
			// Join both original transport owners before propagating either error.
			let direct_cleanup = async {
				if let Some(owner) = direct_transport {
					owner.shutdown().await
				} else {
					Ok(())
				}
			};
			let observation_cleanup = async {
				if let Some(pool) = observation_pool {
					pool.shutdown().await
				} else {
					Ok(())
				}
			};
			let (direct_cleanup, observation_cleanup) =
				tokio::join!(direct_cleanup, observation_cleanup);
			direct_cleanup?;
			observation_cleanup?;
			transport?;
		}
	}

	Ok(())
}

/// Run the MCP server over STDIO (default mode).
///
/// Exits cleanly on: EOF on stdin (parent closed pipe), or SIGTERM
/// (parent requests graceful shutdown). Both paths call kill_all_shell_children()
/// to ensure no orphan processes survive after we exit.
async fn run_stdio_server(server: mcp::server::OctofsServer) -> Result<()> {
	use rmcp::{transport::stdio, ServiceExt};

	tracing::info!("Starting MCP server (STDIO mode)");

	let service = server.serve(stdio()).await.inspect_err(|e| {
		tracing::error!("serving error: {:?}", e);
	})?;

	// `waiting()` blocks until the transport closes naturally (EOF on stdin).
	// For SIGTERM we cancel via the service's cancellation token so the task
	// exits cleanly without dropping the handle mid-flight.
	#[cfg(unix)]
	{
		use tokio::signal::unix::{signal, SignalKind};
		let ct = service.cancellation_token();
		let mut sigterm =
			signal(SignalKind::terminate()).expect("failed to register SIGTERM handler");
		tokio::select! {
			_ = service.waiting() => {
				// EOF on stdin — clean shutdown
			}
			_ = sigterm.recv() => {
				tracing::debug!("SIGTERM received, shutting down gracefully");
				ct.cancel();
			}
		}
	}
	#[cfg(not(unix))]
	{
		service.waiting().await.ok();
	}

	// Kill request-scoped shell trees and interactive SSH PTYs. Durable runtime jobs
	// are deliberately independent and remain queryable after this process restarts.
	mcp::runtime::shutdown_request_scoped().await;

	Ok(())
}

#[derive(Clone)]
struct HttpAuth {
	token_hash: [u8; 32],
	scope: mcp::runtime::caller_scope::AuthenticatedOperatorScope,
}

fn load_http_auth(path: Option<&std::path::Path>, required: bool) -> Result<Option<HttpAuth>> {
	use sha2::{Digest, Sha256};
	let Some(path) = path else {
		if required {
			anyhow::bail!("runtime HTTP mode requires --auth-token-file");
		}
		return Ok(None);
	};
	let token = mcp::runtime::caller_scope::read_private_token(path)?;
	Ok(Some(HttpAuth {
		token_hash: Sha256::digest(&token).into(),
		scope: mcp::runtime::caller_scope::AuthenticatedOperatorScope::from_verified_token(&token),
	}))
}

async fn require_http_auth(
	axum::extract::State(auth): axum::extract::State<HttpAuth>,
	mut request: axum::extract::Request,
	next: axum::middleware::Next,
) -> axum::response::Response {
	use axum::response::IntoResponse;
	use sha2::{Digest, Sha256};
	use subtle::ConstantTimeEq;
	if request.headers().contains_key("origin") {
		return axum::http::StatusCode::FORBIDDEN.into_response();
	}
	let valid = request
		.headers()
		.get("x-hepta-runtime-token")
		.is_some_and(|value| {
			let candidate: [u8; 32] = Sha256::digest(value.as_bytes()).into();
			bool::from(candidate.ct_eq(&auth.token_hash))
		});
	if !valid {
		return axum::http::StatusCode::UNAUTHORIZED.into_response();
	}
	request.extensions_mut().insert(auth.scope.clone());
	next.run(request).await
}

/// Run the MCP server over HTTP with Streamable HTTP transport.
async fn run_http_server(
	bind_addr: &str,
	auth_token_file: Option<&std::path::Path>,
	auth_required: bool,
) -> Result<()> {
	use rmcp::transport::streamable_http_server::{
		session::local::LocalSessionManager, StreamableHttpServerConfig, StreamableHttpService,
	};

	let ct = tokio_util::sync::CancellationToken::new();

	// Each HTTP session gets a fresh server instance with isolated workdir state.
	// The factory closure creates a new OctofsServer for each session.
	let service = StreamableHttpService::new(
		|| Ok(mcp::server::OctofsServer::new()),
		LocalSessionManager::default().into(),
		StreamableHttpServerConfig::default().with_cancellation_token(ct.child_token()),
	);

	let auth = load_http_auth(auth_token_file, auth_required)?;
	let mut protected = axum::Router::new().nest_service("/mcp", service);
	if let Some(auth) = auth {
		protected = protected.layer(axum::middleware::from_fn_with_state(
			auth,
			require_http_auth,
		));
	}
	let router = axum::Router::new()
		.route("/healthz", axum::routing::get(|| async { "ok\n" }))
		.route(
			"/readyz",
			axum::routing::get(|| async {
				if mcp::runtime::request_audit::group_commit_ready() {
					(axum::http::StatusCode::OK, "ready\n")
				} else {
					(axum::http::StatusCode::SERVICE_UNAVAILABLE, "not ready\n")
				}
			}),
		)
		.merge(protected);
	let addr = bind_addr
		.parse::<std::net::SocketAddr>()
		.map_err(|e| anyhow::anyhow!("Invalid bind address '{}': {}", bind_addr, e))?;

	if auth_required && !addr.ip().is_loopback() {
		anyhow::bail!("runtime HTTP must bind a loopback address");
	}
	let tcp_listener = tokio::net::TcpListener::bind(&addr)
		.await
		.map_err(|e| anyhow::anyhow!("Failed to bind to {}: {}", addr, e))?;

	tracing::info!("MCP HTTP server listening on {}", addr);

	let _ = axum::serve(tcp_listener, router)
		.with_graceful_shutdown(async move {
			#[cfg(unix)]
			{
				use tokio::signal::unix::{signal, SignalKind};
				let mut sigterm =
					signal(SignalKind::terminate()).expect("failed to register SIGTERM handler");
				tokio::select! {
					_ = tokio::signal::ctrl_c() => {},
					_ = sigterm.recv() => {},
				}
			}
			#[cfg(not(unix))]
			tokio::signal::ctrl_c().await.unwrap();
			ct.cancel();
		})
		.await;

	// Same orphan cleanup as STDIO shutdown. Durable runtime jobs are unaffected.
	mcp::runtime::shutdown_request_scoped().await;

	Ok(())
}

fn init_mcp_logging() {
	// Parse RUST_LOG for a level override; default to WARN so debug! is a no-op.
	let level = std::env::var("RUST_LOG")
		.ok()
		.and_then(|v| v.parse::<Level>().ok())
		.unwrap_or(Level::WARN);

	tracing::subscriber::set_global_default(StderrSubscriber { level })
		.expect("failed to set tracing subscriber");
}

/// Minimal tracing subscriber — writes level + message to stderr.
/// Avoids the heavy tracing-subscriber crate (regex-automata, sharded-slab, etc.).
struct StderrSubscriber {
	level: Level,
}

impl tracing::Subscriber for StderrSubscriber {
	fn enabled(&self, metadata: &tracing::Metadata<'_>) -> bool {
		metadata.level() <= &self.level
	}

	fn new_span(&self, _span: &tracing::span::Attributes<'_>) -> tracing::span::Id {
		tracing::span::Id::from_u64(1)
	}

	fn record(&self, _span: &tracing::span::Id, _values: &tracing::span::Record<'_>) {}

	fn record_follows_from(&self, _span: &tracing::span::Id, _follows: &tracing::span::Id) {}

	fn event(&self, event: &tracing::Event<'_>) {
		use std::fmt::Write;
		let mut msg = String::new();
		let _ = write!(msg, "[{}] ", event.metadata().level());
		event.record(&mut MessageVisitor(&mut msg));
		eprintln!("{}", msg);
	}

	fn enter(&self, _span: &tracing::span::Id) {}
	fn exit(&self, _span: &tracing::span::Id) {}
}

struct MessageVisitor<'a>(&'a mut String);

impl tracing::field::Visit for MessageVisitor<'_> {
	fn record_debug(&mut self, field: &tracing::field::Field, value: &dyn std::fmt::Debug) {
		if field.name() == "message" {
			let _ = std::fmt::write(self.0, format_args!("{:?}", value));
		}
	}

	fn record_str(&mut self, field: &tracing::field::Field, value: &str) {
		if field.name() == "message" {
			self.0.push_str(value);
		}
	}
}
