#!/usr/bin/env python3
"""Local as-of inventory only; incomplete native jobs stay incomplete."""
import datetime
import hashlib
import json
from pathlib import Path
import runpy

WORK = Path('/workspace/scratch/806ba5f52f94')
HERE = WORK / 'r25-integration-audit/r29-native-custody-current-02'
BENCHMARK = WORK / 'benchmark-r29'
PRIOR = WORK / 'r25-integration-audit/r28-native-custody-preparation-01'
EXTRA_FILES = (
    BENCHMARK / 'holder-receipt-materialization-failure-01.json',
    BENCHMARK / 'holder-receipt-materialization-02.json',
    BENCHMARK / 'materialize_holder_receipts_02.py',
    BENCHMARK / 'receive_original_archive_01.py',
    BENCHMARK / 'receive_original_archive_02.py',
)
KNOWN_LOCAL_FAILURES = {
    BENCHMARK / 'holder-receipt-materialization-failure-01.json',
    BENCHMARK / 'observation-operations-01/local-verification-failure-01.json',
    BENCHMARK / 'lifecycle-operations-01/monitor-materialization-failure-01.json',
}
SOURCES = {
    'snapshot_inputs_01.py': 'c6838d6263b3efea517035aeefb8f9b3636a5fbd321f111e5a227152e8185d39',
    'check_native_custody_01.py': 'ec0cb9f40a935523f035b66e74417aee51fe4e34ddffdb91bafe9a4109ad733a',
}


def need(value, message):
    if not value:
        raise ValueError(message)


def encode(value):
    return (json.dumps(value, sort_keys=True, indent=2) + '\n').encode()


def main():
    output = HERE / 'input-snapshot-current-02.json'
    error_output = HERE / 'original-error-ledger-current-02.json'
    source_output = HERE / 'qualified-source-local-map-02.json'
    need(not any(path.exists() for path in (output, error_output, source_output)), 'fresh current snapshot required')
    definitions = {}
    for filename, expected in SOURCES.items():
        raw = (PRIOR / filename).read_bytes()
        need(hashlib.sha256(raw).hexdigest() == expected, 'reviewed prior source changed')
        definitions[filename] = runpy.run_path(str(PRIOR / filename), run_name='r29_current_local_definitions')
    frozen = definitions['snapshot_inputs_01.py']['frozen']
    walk = definitions['check_native_custody_01.py']['walk']
    strong = definitions['check_native_custody_01.py']['strong']
    roots = sorted(path for path in BENCHMARK.iterdir() if path.is_dir() and 'operations' in path.name)
    names = {str(root): sorted(str(path) for path in root.rglob('*') if path.is_file()) for root in roots}
    files, starts, statuses, errors = [], {}, {}, []
    for path in sorted({Path(name) for listing in names.values() for name in listing} | set(EXTRA_FILES)):
        raw, identity = frozen(path)
        files.append(identity)
        if path.suffix != '.json':
            continue
        try:
            value = json.loads(raw)
        except (ValueError, UnicodeError):
            continue
        if path in KNOWN_LOCAL_FAILURES:
            errors.append({'kind': 'original_local_checker_failure',
                           'source': {'source_path': str(path), 'sha256': identity['sha256'], 'json_pointer': '$'},
                           'original_failure': value})
        for pointer, dto in walk(value):
            evidence = {'source_path': str(path), 'sha256': identity['sha256'], 'json_pointer': pointer}
            job = dto.get('job')
            if isinstance(job, dict) and all(k in job for k in ('id', 'host', 'args', 'idempotency_key', 'request_digest')):
                if 'r29' in job['idempotency_key']:
                    starts.setdefault(job['id'], []).append((evidence, job))
            if isinstance(dto.get('job_id'), str) and 'log_bytes' in dto and 'terminal_publication_confirmed' in dto:
                statuses.setdefault(dto['job_id'], []).append((evidence, dto))
            if dto.get('isError') is True:
                errors.append({'kind': 'original_RPC_isError_true', 'source': evidence,
                               'original_texts': [row['text'] for row in dto.get('content', [])
                                                  if isinstance(row, dict) and row.get('type') == 'text']})
            if dto.get('error') is not None:
                errors.append({'kind': 'original_nonnull_error_field', 'source': evidence, 'original_error': dto['error']})
            if 'exception' in dto and dto['exception'] is not None:
                errors.append({'kind': 'original_exception_field', 'source': evidence, 'original_exception': dto['exception']})
    operations = {}
    for job_id, rows in sorted(starts.items()):
        job = rows[0][1]
        need(all(all(row[key] == job[key] for key in ('host', 'idempotency_key', 'request_digest'))
                 for _, row in rows), 'conflicting original start identities')
        observed = statuses.get(job_id, [])
        latest = max(observed, key=lambda item: item[1].get('at_unix_ms', 0)) if observed else None
        terminals = [item for item in observed if strong(item[1])]
        terminal = max(terminals, key=lambda item: item[1].get('at_unix_ms', 0)) if terminals else None
        operations[job_id] = {
            'job_id': job_id, 'host': job['host'], 'idempotency_key': job['idempotency_key'],
            'expected_state': terminal[1]['state'] if terminal else None,
            'expected_exit_code': terminal[1]['exit_code'] if terminal else None,
            'expected_values_are_observed_original_terminal_only': True,
            'latest_observed_state': latest[1]['state'] if latest else None,
            'latest_observed_at_unix_ms': latest[1].get('at_unix_ms') if latest else None,
            'original_launch_state': job.get('launch_state'),
            'request_digest': job['request_digest'],
            'request_digest_not_recomputed': True,
            'original_start_paths': sorted({item['source_path'] for item, _ in rows}),
        }
    need(operations, 'no actual original starts found')
    for root, original in names.items():
        need(sorted(str(path) for path in Path(root).rglob('*') if path.is_file()) == original,
             'current operation directory changed during snapshot; preserve this failure and take a new snapshot')
    for record in files:
        _, again = frozen(Path(record['source_path']))
        need(again == record, 'original operation changed during snapshot')
    timestamp = datetime.datetime.now(datetime.timezone.utc).isoformat()
    result = {
        'schema': 'hepta-r29-native-custody-input-snapshot/v1', 'as_of_utc': timestamp,
        'files': files, 'directory_scope': names, 'operation_jobs': operations,
        'explicit_extra_files': [str(path) for path in EXTRA_FILES],
        'excluded_job': None, 'all_three_companions_verified': False,
        'current_snapshot_only': True, 'complete_final_scope_frozen': False,
        'future_OBS_terminal_lifecycle_QC_export_not_invented': True,
        'actual_failed_operations_remain_failed': True, 'host_calls': 0,
    }
    map_path = BENCHMARK / 'actual-qualification-receipts-01/qualified-source-map-01.json'
    map_raw, map_identity = frozen(map_path)
    source_map = json.loads(map_raw)
    need(len(source_map) == 221, 'actual qualified source map differs')
    candidate = WORK / 'r25-capacity-audit/r29-router-cache-candidate-01/candidate'
    actual_formatted = BENCHMARK / 'qualified-source-recovery-01/server_tests.rs'
    recovered = []
    for relative, expected_sha in sorted(source_map.items()):
        p = Path(relative)
        need(not p.is_absolute() and '..' not in p.parts, 'unsafe actual compiler input')
        local = actual_formatted if relative == 'src/mcp/server_tests.rs' else candidate / relative
        _, identity = frozen(local)
        need(identity['sha256'] == expected_sha, 'local body does not equal actual qualified source: ' + relative)
        recovered.append({'repository_path': relative, 'actual_qualified_sha256': expected_sha,
                          'body_source': identity, 'formatted_body_used': relative == 'src/mcp/server_tests.rs'})
    source_result = {'schema': 'hepta-r29-actual-qualified-local-source-body-map/v1',
                     'source_map_original': map_identity, 'compiler_inputs': 221,
                     'all_actual_qualified_bodies_present': True, 'files': recovered,
                     'formatted_server_tests_preimage_not_selected': True,
                     'Git_entries_created': False, 'candidate_adopted': False,
                     'future_QC_archive_must_include_same_221_bodies': True}
    error_result = {'schema': 'hepta-r29-original-operation-error-ledger/v1',
                    'as_of_utc': timestamp, 'entries': errors,
                    'all_original_API_envelopes_retained_in_snapshot': True,
                    'scope_is_current_benchmark_r29_operation_directories': True,
                    'absence_of_logged_timeout_is_not_proof_no_transport_timeout_occurred': True,
                    'failure_metadata_does_not_replace_the_original_job_outcome': True}
    for path, value in ((output, result), (error_output, error_result), (source_output, source_result)):
        with path.open('xb') as stream:
            stream.write(encode(value))
    print(json.dumps({'jobs': len(operations), 'operation_files': len(files),
                      'original_errors': len(errors), 'qualified_body_count': len(recovered),
                      'as_of_utc': timestamp, 'host_calls': 0}), flush=True)


if __name__ == '__main__':
    main()
