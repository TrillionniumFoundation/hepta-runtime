#!/usr/bin/env python3
"""Export only six actual R29 qualification JSON bodies; no qualification or CI execution."""
import argparse
import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import stat
import types

ROOT = Path('/home/qian/hepta-runtime-optimization-20261105-r29')
SOURCE = ROOT / 'source'
CANDIDATE_DIR = ROOT / 'qualification-01'
STAGE = Path('/home/qian/hepta-runtime-optimization-20261105-r25/tools')
SELF = STAGE / 'r29_export_qualification_receipts_01.py'
INPUT = STAGE / 'r29_qualification_receipts_input_01.json'
HELPER = STAGE / 'r26_export_stable_archive_03.py'
HELPER_SHA = '34ce88cc28da10e1167dabaf6e3480aa42f5e6e76a29472d93959334aa9ec2ed'
OUT = ROOT / 'qualification-receipts-export-01'
ARCHIVE = 'qualification-receipts-01.tar.gz'
FILES = {
    'preparation-01.json': ROOT / 'preparation-01.json',
    'qualification-native-terminal-01.json': ROOT / 'qualification-terminal-status-01.json',
    'qualification-report-01.json': ROOT / 'qualification-01/report.json',
    'qualified-source-map-01.json': ROOT / 'qualification-01/source-map.json',
    'isolated-tests-summary-01.json': ROOT / 'qualification-01/isolated-tests/summary.json',
    'isolated-tests-audit-01.json': ROOT / 'qualification-01/isolated-tests.audit.json',
}
STAGES = ['format', 'fmt-check', 'harness-tests', 'clippy', 'test-build',
          'isolated-tests', 'audit-isolated-tests', 'release']
COUNTS = {'passed': 1655, 'failed': 0, 'ignored': 34, 'selected': 1689, 'retries': 0}
HEX = re.compile(r'[0-9a-f]{64}\Z')
JOB = re.compile(r'[0-9a-f]+-[0-9a-f]+-[0-9a-f]+\Z')
MAX_FILE = 16 * 1024**2
MAX_TOTAL = 32 * 1024**2


def need(value, reason):
    if not value:
        raise RuntimeError(reason)


def load_helper():
    need(HELPER.resolve(strict=True) == HELPER, 'indirect reviewed archive helper')
    fd = os.open(HELPER, os.O_RDONLY | os.O_NOFOLLOW | os.O_CLOEXEC | os.O_NONBLOCK)
    try:
        before = os.fstat(fd)
        need(stat.S_ISREG(before.st_mode) and before.st_uid == os.geteuid()
             and before.st_nlink == 1 and before.st_size == 12842, 'reviewed helper descriptor differs')
        with os.fdopen(os.dup(fd), 'rb') as stream:
            raw = stream.read(131073)
        fields = ('st_dev', 'st_ino', 'st_uid', 'st_mode', 'st_nlink', 'st_size', 'st_mtime_ns', 'st_ctime_ns')
        need(len(raw) == before.st_size and hashlib.sha256(raw).hexdigest() == HELPER_SHA
             and all(getattr(before, key) == getattr(os.fstat(fd), key) == getattr(HELPER.lstat(), key)
                     for key in fields), 'reviewed helper bytes or identity changed')
    finally:
        os.close(fd)
    module = types.ModuleType('_hepta_r29_bound_receipt_archive')
    module.__file__ = str(HELPER)
    exec(compile(raw, str(HELPER), 'exec'), module.__dict__)
    return module


def bind_input(value):
    need(type(value) is dict and set(value) == {'schema', 'original_qualification_job_id', 'files'}
         and value['schema'] == 'hepta-r29-fixed-qualification-receipts-input/v1', 'fixed input schema differs')
    job_id = value['original_qualification_job_id']
    need(type(job_id) is str and JOB.fullmatch(job_id), 'actual original qualification job is unbound')
    need(type(value['files']) is dict and set(value['files']) == set(FILES), 'exact six original inputs required')
    total = 0
    for name, path in FILES.items():
        pin = value['files'][name]
        need(type(pin) is dict and set(pin) == {'source_path', 'bytes', 'sha256'}
             and pin['source_path'] == str(path)
             and type(pin['bytes']) is int and 0 < pin['bytes'] <= MAX_FILE
             and type(pin['sha256']) is str and HEX.fullmatch(pin['sha256']),
             'actual original file bytes/SHA is unbound or outside fixed scope: ' + name)
        total += pin['bytes']
    need(total <= MAX_TOTAL, 'six original JSON bodies exceed fixed bound')
    return job_id


def verify_r29_candidate_preparation(preparation, terminal, job_id, qualified, tests):
    """Verify actual R29 source/qualification/cache custody; never infer future passes."""
    import hashlib
    import json
    # Filled only from the reviewed final entry and its actual cache/QC/window
    # input. An unbound template cannot qualify any existing or future version.
    expected_launcher = {'path': '/home/qian/hepta-runtime-optimization-20261105-r25/tools/prepare_and_qualify_r29_01.py', 'bytes': 67635, 'sha256': '7ce339aa261fdf6acbc8e0ca8cf67f5c5d3a7b56fcc34d51ed4ee56ea4fe389a'}
    expected_input = {'path': '/home/qian/hepta-runtime-optimization-20261105-r25/tools/r29-qualification-01-input.json', 'bytes': 311502, 'sha256': '60bfe1ef593ad58d528f6e508d3f6e0a1e4f76183f1293b40f36b7ee6bb3f8a8'}
    need(isinstance(expected_launcher, dict) and isinstance(expected_input, dict),
         "R29 actual qualification entry/input identities remain unbound")
    need(isinstance(job_id, str) and re.fullmatch(r"[0-9a-f]{11,16}-[0-9a-f]{4}-[0-9a-f]{4}", job_id)
         and job_id not in {"1a1aa7fa690-fc05-43af", "1a1aaa6552d-fc05-459f", "1a1ab4cb0fc-fc05-4c3c",
                            "1a1ac274e49-fc05-5286", "1a1ac456b07-fc05-532a", "1a1ac5d5a29-fc05-53d9",
                            "1a1acfe317a-fc05-57ee"},
         "the actual new R29 qualification job is required")
    need(terminal.get("job_id") == job_id and terminal.get("state") == "succeeded"
         and type(terminal.get("exit_code")) is int and terminal["exit_code"] == 0
         and all(terminal.get(key) is False for key in ("automatic_retry", "timed_out", "cancelled"))
         and all(terminal.get(key) is True for key in ("output_complete", "output_durable", "terminal_publication_confirmed"))
         and type(terminal.get("terminal_publication_protocol")) is int and terminal["terminal_publication_protocol"] == 1
         and terminal.get("log_synced") == {"stdout": True, "stderr": True}
         and terminal.get("log_errors") == {"stdout": None, "stderr": None}
         and terminal.get("log_truncated") == {"stdout": False, "stderr": False},
         "original R29 qualification has no complete successful native terminal proof")
    for stream in ("stdout", "stderr"):
        counts = terminal["log_bytes"][stream]
        need(set(counts) == {"seen", "stored"} and all(type(value) is int and value >= 0 for value in counts.values())
             and counts["seen"] == counts["stored"], "qualification native log byte custody differs")
    need(preparation["schema"] == "hepta-r29-qualified-parent-preparation/v1"
         and preparation["selected_proposal"] == "shared unfiltered ToolRouter"
         and preparation.get("optional_pidfd_selected") is False and preparation.get("finished_utc")
         and all(preparation.get(key) is True for key in ("passed", "candidate_qualified", "parent_source_qualified",
             "parent_observation_rejection_preserved", "parent_inputs_unchanged", "cache_reused",
             "cache_source_source_qualified", "cache_moved_by_single_no_replace_rename"))
         and all(preparation.get(key) is False for key in ("candidate_adopted", "parent_candidate_adopted",
             "production_services_modified", "shared_hardlinks_created", "cache_copy_executed", "cache_cleanup_executed")),
         "actual R29 preparation is incomplete or changed the private cache scope")
    need(preparation["source"] == str(SOURCE) and preparation["target"] == str(ROOT / "target-build")
         and preparation["qualification_output"] == str(CANDIDATE_DIR)
         and preparation["launcher"] == expected_launcher and preparation["input"] == expected_input,
         "R29 qualification launcher, actual input or private paths differ")
    need(expected_launcher["path"] == "/home/qian/hepta-runtime-optimization-20261105-r25/tools/prepare_and_qualify_r29_01.py"
         and expected_input["path"] == "/home/qian/hepta-runtime-optimization-20261105-r25/tools/r29-qualification-01-input.json",
         "R29 entry belongs to another runtime attempt")
    source_cache = "/home/qian/hepta-runtime-optimization-20261105-r28/target-build"
    need(preparation["cache_source"] == source_cache and preparation["unchanged_disk_reserve_bytes"] == 3221225472
         and preparation["new_full_cache_copy_bytes"] == 0, "R29 cache reuse weakened allocation or reserve policy")
    admission = preparation["admission"]
    need(admission["original_failed_probe01_preserved_as_failed"] is True
         and admission["original_failed_probe01_error"] == {"type": "RuntimeError", "message": "directory outside exact task parent"}
         and admission["original_failed_probe01"]["job_id"] == "1a1acfe317a-fc05-57ee"
         and admission["original_failed_probe01"]["stdout_identity"] == {
             "bytes": 21898, "sha256": "7d96f345114fcad140b40f69804df679f68b8e67d57a1c46941d809cedb3c58f"}
         and admission["readonly_probe_does_not_authorize_transfer"] is True
         and admission["all_user_process_channels_readable_claimed"] is False,
         "original failed readonly probe or reference limits were promoted")
    need(admission["downloaded_QC_full_verification"] == {
        "bytes": 9585, "sha256": "7342eed4ed17389eb57f5f40111438c5c4e339591ebb77c450a4fb1fe3ae2614"}
         and admission["downloaded_QC_archive"] == {
        "bytes": 1915620, "sha256": "442586ded13a4cfde54531e6f05ddddcf26c2f53d40d15b04c5993ece5f04186"},
         "R28 full downloaded QC archive was not independently verified")
    writer = admission["root_writer_admission"]
    need(writer["schema"] == "hepta-r29-owned-cache-writer-admission/v1"
         and writer["source_cache"] == source_cache and writer["destination_cache"] == str(ROOT / "target-build")
         and writer["exclusive_compilation_window_held"] is True
         and writer["no_later_R28_cache_use_scheduled"] is True
         and writer["original_native_raw_custody_retained"] is True
         and writer["same_owner_unknowns_reviewed_without_claiming_all_channels_readable"] is True
         and writer["fd_and_mmap_reference_channels_not_covered"] is True
         and writer["root_reviewed_readonly_probe_stdout"] == admission["original_probe_stdout"]
         and writer["root_reviewed_downloaded_QC_verification"] == admission["downloaded_QC_full_verification"],
         "the actual root execution window is not bound to the preserved original evidence")
    transfer = preparation["cache_transfer"]
    need(transfer["schema"] == "hepta-r29-owned-cache-transfer/v1"
         and transfer["source_cache"] == source_cache and transfer["destination_cache"] == str(ROOT / "target-build")
         and transfer["root_writer_admission"] == writer and transfer["original_cache_probe"] == admission["original_probe_stdout"]
         and all(transfer.get(key) is True for key in ("passed", "rename_attempted", "rename_returned_success",
             "old_path_absent", "destination_is_original_inode", "descendants_metadata_unchanged"))
         and all(transfer.get(key) is False for key in ("copy_executed", "cleanup_executed", "automatic_retry", "automatic_rollback"))
         and transfer.get("finished_utc") and "error" not in transfer and "rename_errno" not in transfer,
         "the one original no-replace cache transfer did not close")
    before, immediate, after = (transfer[key] for key in ("metadata_before", "immediate_metadata_before", "metadata_after"))
    for row in (before, immediate, after):
        need(row["all_entries_traversed"] is True and row["all_regular_links_accounted_within_target"] is True
             and row["external_or_unaccounted_hardlink_inodes"] == 0 and row["retained_qualification_elf_aliases"] == []
             and row["anomaly_examples_maximum_32"] == []
             and all(row["counts"][key] == 0 for key in ("symlinks", "other_nonregular", "other_device_entries", "other_owner_entries")),
             "cache metadata escaped the original owned regular/directory scope")
    need(before["path"] == immediate["path"] == source_cache and after["path"] == str(ROOT / "target-build")
         and before["counts"] == immediate["counts"] == after["counts"]
         and before["root_identity"] == immediate["root_identity"]
         and before["metadata_sha256"] == immediate["metadata_sha256"]
         and before["descendants_metadata_sha256"] == immediate["descendants_metadata_sha256"] == after["descendants_metadata_sha256"],
         "cache descendants or pre-transfer identity changed")
    root_fields = ("st_dev", "st_ino", "st_uid", "st_gid", "st_mode", "st_nlink", "st_size", "st_mtime_ns")
    need(all(immediate["root_identity"][key] == after["root_identity"][key] for key in root_fields)
         and after["root_identity"]["st_ctime_ns"] >= immediate["root_identity"]["st_ctime_ns"]
         and transfer["root_ctime_before"] == immediate["root_identity"]["st_ctime_ns"]
         and transfer["root_ctime_after"] == after["root_identity"]["st_ctime_ns"],
         "cache root identity changed beyond rename ctime")
    need(preparation["cache_bytes"] == before["counts"]["regular_logical_bytes"]
         and preparation["cache_file_count"] == before["counts"]["regular_files"], "cache size accounting differs")
    for scan in (preparation["cache_reference_scan_before_source"], transfer["immediate_reference_scan"]):
        need(scan["matched_live_processes"] == [] and scan["raw_argv_or_environment_or_unrelated_cwd_emitted"] is False,
             "an observed cache reference was ignored")
    for samples in (preparation["compiler_quiescence"], preparation["compiler_quiescence_immediately_before_move"]):
        need(isinstance(samples, list) and samples and samples[-1]["compiler_processes"] == [],
             "compiler quiet admission did not finish")
    for disk in (preparation["disk_after_fresh_source_before_move"], transfer["disk_before_move"],
                 preparation["disk_immediately_before_compiler"]):
        need(disk["unchanged_required_headroom_bytes"] == 3221225472
             and type(disk["available_bytes"]) is int and disk["available_bytes"] >= 3221225472
             and disk["new_full_cache_copy_bytes"] == 0 and disk["move_frees_bytes"] is False
             and disk["future_build_growth_guaranteed_to_fit"] is False,
             "the unchanged 3 GiB reserve was not checked at the actual admission boundaries")
    retained = preparation["retained_parent_ELFs_before"]
    need(len(retained) == 8 and len({row["path"] for row in retained}) == 8
         and retained == preparation["retained_parent_ELFs_after_qualification"]
         == transfer["retained_parent_ELFs_before"] == transfer["retained_parent_ELFs_after"],
         "the eight retained R28 ELF copies were not preserved")
    for row in retained:
        d = row["current_identity"]
        need(row["path"].startswith("/home/qian/hepta-runtime-optimization-20261105-r28/qualification-01/")
             and d["st_uid"] == 1000 and d["st_nlink"] == 1 and d["st_mode"] & 0o170000 == 0o100000
             and d["st_size"] == row["bytes"] and row["full_export_identity_unchanged"] is True
             and row["sha256_recomputed_by_this_metadata_probe"] is False and row["payload_read_bytes"] == 0,
             "an original retained ELF descriptor was substituted or reclassified")
    transfer_raw = (json.dumps(transfer, sort_keys=True, indent=2, allow_nan=False) + "\n").encode()
    need(preparation["cache_transfer_receipt"] == {"path": str(ROOT / "target-transfer-01.json"),
         "bytes": len(transfer_raw), "sha256": hashlib.sha256(transfer_raw).hexdigest()},
         "embedded transfer proof differs from the original closed receipt")
    expected_changes = [
        {"path": "src/mcp/server.rs", "before": {"bytes": 118630, "sha256": "875785604d51feba6b02fdf1a6699b8d361d065a44cc4ef7bee6f931521e7e71"},
         "after": {"bytes": 118947, "sha256": "e6f34ef9ace819f72ceafaeee40a957210362f87cc4317d6ebfe4b76ba2fa4d4"}},
        {"path": "src/mcp/server_tests.rs", "before": {"bytes": 38983, "sha256": "003fa3365b3af0302c4a8e19f9230cea35f3366878898c1cf0920b2b6d47cddb"},
         "after": {"bytes": 49832, "sha256": "f4dfdc9c26ef3fdbba4dd2b5d0cfe3f239230a43cb78162bbba21a1c0499cc7f"}}]
    need(preparation["source_changes"] == expected_changes, "R29 is not the exact selected two-file router change")
    before_map = preparation["source_before"]
    expected = dict(before_map)
    changed_paths = {change["path"] for change in expected_changes}
    need(len(before_map) == 221 and len(changed_paths) == 2, "R29 source/change inventory differs")
    for change in expected_changes:
        need(before_map[change["path"]] == change["before"]["sha256"], "R29 qualified parent preimage differs")
        expected[change["path"]] = change["after"]["sha256"]
    need(hashlib.sha256((json.dumps(before_map, sort_keys=True, indent=2) + "\n").encode()).hexdigest()
         == "da8cbdfef75c1c9fc5861e4fe0bd96aeb98f635e95fc122610021cd725db1d28",
         "the R29 parent is not the actual complete qualified R28 map")
    need(preparation["candidate_compilation_inputs"] == expected
         and hashlib.sha256((json.dumps(expected, sort_keys=True, indent=2) + "\n").encode()).hexdigest()
         == "ce3e814a7bfeb7f0d168782dc325e643550cc0c768b606d90c4d45693fbe4853",
         "R29 pre-format compilation input differs")
    stages = ["format", "fmt-check", "harness-tests", "clippy", "test-build", "isolated-tests", "audit-isolated-tests", "release"]
    need(qualified["schema"] == "hepta-x230-composed-qualification/v1" and qualified["qualified"] is True
         and qualified.get("finished_utc") and qualified["source"] == str(SOURCE)
         and qualified["jobs"] == 2 and qualified["service_changes"] is False
         and type(qualified["automatic_test_retries"]) is int and qualified["automatic_test_retries"] == 0
         and [row["name"] for row in qualified["stages"]] == stages
         and all(type(row["returncode"]) is int and row["returncode"] == 0 for row in qualified["stages"]),
         "all eight original R29 qualification stages must pass")
    need(qualified["source_input"] == expected and qualified["source_tested"] == qualified["source_after"] == preparation["source_tested"]
         and set(qualified["source_after"]) == set(expected)
         and all(qualified["source_after"][name] == value for name, value in expected.items() if name not in changed_paths),
         "actual formatted R29 source differs from its qualification")
    need(preparation["formatter_changed_paths"] == [name for name in expected if qualified["source_after"][name] != expected[name]]
         and qualified["harness_before"] == qualified["harness_after"] == preparation["harness_before"]
         and len(qualified["harness_after"]) == 19, "qualification formatter or original harness binding differs")
    counts = ("passed", "failed", "ignored", "selected", "retries")
    need(all(type(tests[key]) is int for key in counts) and [tests[key] for key in counts] == [1655, 0, 34, 1689, 0]
         and tests["success"] is True and tests["filter"] == "" and not tests["enumeration_errors"]
         and preparation["tests"] == tests and preparation["qualification_returncode"] == 0
         and preparation["automatic_test_retries"] == 0, "original full R29 isolated result is incomplete")
    new_names = ["mcp::server::server_tests::cached_router_keeps_mcp_sessions_and_teardown_independent",
                 "mcp::server::server_tests::cached_router_rechecks_runtime_mode_and_native_session_owner"]
    need([row["name"] for row in preparation["new_exact_tests"]] == new_names
         and all(row["status"] == "passed" and row["executed"] is True and row["attempt"] == 1
                 and row["exit_code"] == 0 and row["timed_out"] is False for row in preparation["new_exact_tests"]),
         "the two new original exact cases were not executed once successfully")
    need(preparation["qualification_argv"] == ["/usr/bin/python3", "-B", str(SOURCE / "tools/x230/20261028/qualify.py"),
         "--source", str(SOURCE), "--output", str(CANDIDATE_DIR), "--target", str(ROOT / "target-build"),
         "--cargo-home", "/home/qian/hepta-runtime-optimization-20261023/cargo-home-a32-a33-r02",
         "--jobs", "2", "--stage-timeout", "3600"], "the original qualification argv was weakened")
    return {"passed": True, "original_job_id": job_id, "selected_proposal": "shared unfiltered ToolRouter",
            "optional_pidfd_selected": False, "qualified_source_files": 221, "harness_files": 19, "stages": stages,
            "tests": {key: tests[key] for key in counts}, "candidate_adopted": False,
            "qualified_parent_R28_observation_rejection_preserved": True,
            "original_failed_readonly_probe01_preserved": True, "single_no_replace_cache_move_verified": True,
            "cache_copy_executed": False, "cache_cleanup_executed": False, "unchanged_disk_reserve_bytes": 3221225472}


def verify_receipts(raw, identities, job_id):
    p, terminal, q, source, summary, audit = (json.loads(raw[name]) for name in FILES)
    need(all(type(value) is dict for value in (p, terminal, q, source, summary, audit)),
         'six original JSON objects required')
    need(terminal['job_id'] == job_id and terminal['state'] == 'succeeded'
         and type(terminal['exit_code']) is int and terminal['exit_code'] == 0
         and terminal['audit_recorded'] is True, 'original qualification strong success required')
    need(all(terminal[key] is True for key in ('output_complete', 'output_durable', 'terminal_publication_confirmed'))
         and all(terminal[key] is False for key in ('automatic_retry', 'cancelled', 'timed_out'))
         and type(terminal['terminal_publication_protocol']) is int and terminal['terminal_publication_protocol'] == 1,
         'original complete durable terminal required')
    for channel in ('stdout', 'stderr'):
        need(terminal['log_synced'][channel] is True and terminal['log_truncated'][channel] is False
             and terminal['log_errors'][channel] is None
             and type(terminal['log_bytes'][channel]['seen']) is int
             and terminal['log_bytes'][channel]['seen'] >= 0
             and type(terminal['log_bytes'][channel]['stored']) is int
             and terminal['log_bytes'][channel]['seen'] == terminal['log_bytes'][channel]['stored'],
             'original native log seal incomplete')
    need(q['schema'] == 'hepta-x230-composed-qualification/v1' and q['qualified'] is True
         and q['finished_utc'] and q['source'] == str(ROOT / 'source')
         and [row['name'] for row in q['stages']] == STAGES
         and all(type(row['returncode']) is int and row['returncode'] == 0 for row in q['stages'])
         and type(q['automatic_test_retries']) is int and q['automatic_test_retries'] == 0,
         'all eight original qualification stages must pass')
    need(q['source_tested'] == q['source_after'] == source and len(source) == 221
         and q['harness_before'] == q['harness_after'] and len(q['harness_after']) == 19,
         'qualified source or harness inventory differs')
    q_identity = identities['qualification-report-01.json']
    verify_r29_candidate_preparation(p, terminal, job_id, q, summary)
    need(p['qualification_report'] == {'path': q_identity['source_path'],
             'bytes': q_identity['bytes'], 'sha256': q_identity['sha256']},
         'actual original R29 preparation/report bytes differ')
    need(summary['schema'] == 'hepta-isolated-libtest/v1' and summary['success'] is True
         and summary['filter'] == '' and summary['enumeration_errors'] == []
         and all(type(summary[key]) is int and summary[key] == value for key, value in COUNTS.items())
         and summary['source_manifest_sha256'] == identities['qualified-source-map-01.json']['sha256'],
         'full original isolated test summary differs')
    need(audit['schema'] == 'hepta-isolated-libtest-audit/v1' and audit['success'] is True
         and audit['errors'] == [] and 'fatal_error' not in audit and audit['expected_filter'] == ''
         and audit['input_sha256']['summary.json'] == identities['isolated-tests-summary-01.json']['sha256']
         and all(type(audit[key]) is int and audit[key] == value for key, value in COUNTS.items() if key != 'retries')
         and type(audit['executed']) is int and audit['executed'] == 1655,
         'complete original isolated test audit differs')
    return {'original_qualification_job_id': job_id, 'strong_terminal_succeeded': True,
            'stage_names': STAGES, 'source_files': 221, 'harness_files': 19,
            'isolated_test_counts': COUNTS, 'audit_body_sampled': False,
            'original_R29_preparation_and_parent_rejection_history_preserved': True,
            'scope': 'six original raw receipt bodies and their cross-links; no test or audit replay',
            'downstream_exact_CI_freezer_still_required': True}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--exporter-sha256', required=True)
    parser.add_argument('--input-sha256', required=True)
    args = parser.parse_args()
    need(os.geteuid() == 1000 and Path(__file__).resolve() == SELF, 'fixed native exporter path/owner required')
    need(HEX.fullmatch(args.exporter_sha256) and HEX.fullmatch(args.input_sha256),
         'actual bound exporter/input SHA required; an unbound template cannot run')
    helper = load_helper()
    exporter, _ = helper.read(SELF)
    helper_identity, _ = helper.read(HELPER)
    input_identity, input_raw = helper.read(INPUT, retain=True)
    need(exporter['sha256'] == args.exporter_sha256 and helper_identity['sha256'] == HELPER_SHA
         and input_identity['sha256'] == args.input_sha256 and input_identity['bytes'] <= 65536,
         'exporter/helper/late-bound input identities differ')
    payload = json.loads(input_raw)
    job_id = bind_input(payload)
    need(ROOT.resolve(strict=True) == ROOT and not os.path.lexists(OUT), 'fresh direct fixed export root required')
    root_before = ROOT.lstat()
    need(stat.S_ISDIR(root_before.st_mode) and root_before.st_uid == os.geteuid()
         and stat.S_IMODE(root_before.st_mode) == 0o700, 'original R29 root ownership differs')
    OUT.mkdir(mode=0o700)
    out_before = OUT.lstat()
    report = {'schema': 'hepta-r29-fixed-six-qualification-receipts-export/v1', 'passed': False,
              'started_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
              'original_qualification_job_id': job_id, 'exporter': exporter,
              'archive_helper': helper_identity, 'input': input_identity,
              'files': {}, 'archive': None, 'transfer': None,
              'expected_original_file_count': 6, 'expected_archive_member_count': 7,
              'only_six_original_JSON_bodies_in_payload': True,
              'qualification_or_CI_or_audit_replayed': False, 'source_or_binary_modified': False,
              'runtime_source_or_elf_bodies_read': False, 'original_json_bodies_reencoded': False,
              'archive_code_executed': False, 'candidate_adoption_assessed': False,
              'automatic_retries': 0, 'partial_failed_output_preserved': True}
    try:
        raw, files = {}, {}
        report['files'] = files
        for name, path in FILES.items():
            actual, body = helper.read(path, retain=True)
            expected = payload['files'][name]
            need(all(actual[key] == expected[key] for key in ('source_path', 'bytes', 'sha256'))
                 and actual['is_elf'] is False, 'original fixed JSON identity differs: ' + name)
            files[name], raw[name] = actual, body
        proof = verify_receipts(raw, files, job_id)
        manifest = {'schema': 'hepta-r29-fixed-six-qualification-receipts-manifest/v1',
                    'files': files, 'original_qualification_job_id': job_id,
                    'qualification_receipt_cross_links': proof,
                    'original_json_bytes_preserved': True, 'omitted_bodies': [],
                    'snapshot_scope': 'six independent original descriptors with whole-byte revalidation',
                    'member_names_match_actual_CI02_receipt_layout': True,
                    'archive_code_executed': False, 'runtime_source_or_elf_bodies_included': False}
        manifest_raw, archive_proof = helper.write_archive(OUT / ARCHIVE, manifest, files)
        helper.create(OUT / 'manifest.json', manifest_raw)
        report['manifest'] = helper.read(OUT / 'manifest.json')[0]
        need(report['manifest']['bytes'] == len(manifest_raw)
             and report['manifest']['sha256'] == hashlib.sha256(manifest_raw).hexdigest(),
             'written original manifest bytes differ')
        report['archive'] = archive_proof['identity']
        report['archive_validation'] = archive_proof
        report['transfer'] = helper.transfer_chunks(OUT / ARCHIVE, OUT)
        for name, path in FILES.items():
            helper.read(path, expected=files[name])
        helper.read(SELF, expected=exporter)
        helper.read(HELPER, expected=helper_identity)
        helper.read(INPUT, expected=input_identity)
        for path, original in ((ROOT, root_before), (OUT, out_before)):
            need(path.resolve(strict=True) == path and all(getattr(path.lstat(), key) == getattr(original, key)
                 for key in ('st_dev', 'st_ino', 'st_uid', 'st_mode')), 'owned directory changed')
        report.update(passed=True, qualification_receipt_cross_links=proof,
                      original_file_count=6, archive_member_count=7,
                      original_six_files_unchanged=True, tool_and_input_identities_unchanged=True,
                      single_gzip_crc_eof_and_all_seven_members_verified=True,
                      maximum_transfer_decoded_chunk_bytes=48000)
    except BaseException as error:
        report['error'] = {'type': type(error).__name__, 'reason': str(error)[:2000]}
    report['finished_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    report_raw = helper.encode(report)
    helper.create(OUT / 'report.json', report_raw)
    final, _ = helper.read(OUT / 'report.json')
    need(final['bytes'] == len(report_raw) and final['sha256'] == hashlib.sha256(report_raw).hexdigest(),
         'written final report bytes differ')
    fd = os.open(OUT, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW | os.O_CLOEXEC)
    try:
        os.fsync(fd)
    finally:
        os.close(fd)
    print(json.dumps({'passed': report['passed'], 'report': final,
                      'archive': report['archive'], 'transfer': report['transfer'],
                      'error': report.get('error')}, sort_keys=True), flush=True)
    return 0 if report['passed'] else 1


if __name__ == '__main__':
    os.umask(0o077)
    raise SystemExit(main())
