"""Construct fixed local R29 CI drafts from reviewed originals; never run CI."""
import ast
import hashlib
import json
from pathlib import Path
import pprint

WORK = Path('/workspace/scratch/806ba5f52f94')
HERE = Path(__file__).parent
OLD_RUST = WORK / 'r25-lifecycle-audit/r28-rust-ci-02'
OLD_PY = WORK / 'r25-lifecycle-audit/r28-python-ci-02'
SUCCESS_PY = WORK / 'r25-lifecycle-audit/r28-python-ci-recovery-02/delivery-02/tools/launch_python_ci_02.py'
CANONICAL = WORK / 'r25-integration-audit/r29-qualification-final-01/canonical-preparation-validator.py'

def sha(body):
    return hashlib.sha256(body).hexdigest()

def identity(path):
    body = path.read_bytes()
    return {'path': str(path), 'bytes': len(body), 'sha256': sha(body)}

def write(path, body):
    path.parent.mkdir(parents=True, exist_ok=True)
    if isinstance(body, str):
        body = body.encode()
    if path.suffix == '.py':
        ast.parse(body)
    path.write_bytes(body)

def source_node(source, kind, name):
    for node in ast.parse(source).body:
        if kind == 'function' and isinstance(node, ast.FunctionDef) and node.name == name:
            return node
        if kind == 'assignment' and isinstance(node, ast.Assign) and any(isinstance(t, ast.Name) and t.id == name for t in node.targets):
            return node
    raise AssertionError((kind, name))

def replace_node(source, kind, name, replacement):
    old = ast.get_source_segment(source, source_node(source, kind, name))
    assert source.count(old) == 1
    return source.replace(old, replacement, 1)

def rename_runtime(source):
    source = source.replace('r28', 'r29').replace('R28', 'R29')
    source = source.replace('qualification-native-terminal-02.json', 'qualification-native-terminal-01.json')
    source = source.replace('qualification-terminal-status-02.json', 'qualification-terminal-status-01.json')
    source = source.replace('preparation-02.json', 'preparation-01.json')
    source = source.replace('terminal path must be attempt02', 'terminal path must be attempt01')
    return source

canonical = CANONICAL.read_text().rstrip()
origins = {'canonical': identity(CANONICAL), 'rust': {}, 'python': {}}
rust = HERE / 'rust'
draft = rust / 'rust-ci-draft-01'
entry = rust / 'entry-01'
for name in ('audit_nextest_0137.py', 'run_rust_ci_01.py', 'materialize_rust_ci_plan_01.py'):
    source_path = OLD_RUST / 'rust-ci-draft-01' / name
    origins['rust'][name] = identity(source_path)
    raw = source_path.read_bytes()
    if name != 'audit_nextest_0137.py':
        text = rename_runtime(raw.decode())
        if name == 'materialize_rust_ci_plan_01.py':
            text = replace_node(text, 'function', 'verify_r29_candidate_preparation', canonical)
            text = replace_node(text, 'function', 'verify_preparation', '''def verify_preparation(value, qualified, qualification_identity, terminal):
    """Reuse the one canonical R29 gate plus the exact original report binding."""
    verify_r29_candidate_preparation(value, terminal, JOB_ID, qualified, value["tests"])
    need(type(value.get("finished_utc")) is str and bool(value["finished_utc"])
         and value["qualification_report"] == qualification_identity,
         "actual R29 preparation report identity differs")''')
        # Only exact test totals change; no command, filter, timeout or child
        # custody behavior changes. Preserve the canonical function verbatim.
        marker = '__FIXED_CANONICAL_FUNCTION__'
        if canonical in text:
            text = text.replace(canonical, marker)
        text = text.replace('1653', '1655').replace('1687', '1689')
        text = text.replace(marker, canonical)
        raw = text.encode()
    write(draft / name, raw)
draft_pins = {p.name: sha(p.read_bytes()) for p in sorted(draft.iterdir())}

freezer = rename_runtime((OLD_RUST / 'freeze_rust_ci_01.py').read_text())
freezer = replace_node(freezer, 'function', 'verify_r29_candidate_preparation', canonical)
fn = ast.get_source_segment(freezer, source_node(freezer, 'function', 'verify_six_receipts'))
begin = fn.index("    need(type(p.get('finished_utc'))")
end = fn.index('    expected_counts =', begin)
fn = fn[:begin] + '''    need(type(p.get('finished_utc')) is str and bool(p['finished_utc'])
         and p['qualification_report'] == report_identity,
         'actual R29 preparation report identity differs')
''' + fn[end:]
fn = fn.replace('1653', '1655').replace('1687', '1689')
freezer = replace_node(freezer, 'function', 'verify_six_receipts', fn)
freezer = replace_node(freezer, 'assignment', 'DRAFT_PINS', 'DRAFT_PINS = ' + repr(draft_pins))
write(rust / 'freeze_rust_ci_01.py', freezer)
origins['rust']['freeze_rust_ci_01.py'] = identity(OLD_RUST / 'freeze_rust_ci_01.py')
for name in ('install_rust_ci_tools_01.template.py', 'launch_exact_rust_ci_01.template.py'):
    origins['rust'][name] = identity(OLD_RUST / 'entry-01' / name)
    write(entry / name, rename_runtime((OLD_RUST / 'entry-01' / name).read_text()))
generator = rename_runtime((OLD_RUST / 'entry-01/generate_ci_entry_01.py').read_text())
generator = replace_node(generator, 'assignment', 'HERE', 'HERE = WORK / ' + repr(str(entry.relative_to(WORK))))
generator = replace_node(generator, 'assignment', 'DRAFT', 'DRAFT = WORK / ' + repr(str(draft.relative_to(WORK))))
generator = replace_node(generator, 'assignment', 'DRAFT_PINS', 'DRAFT_PINS = ' + repr(draft_pins))
generator = replace_node(generator, 'assignment', 'VERIFY_SOURCE', 'VERIFY_SOURCE = WORK / ' + repr(str((rust / 'freeze_rust_ci_01.py').relative_to(WORK))))
generator = replace_node(generator, 'assignment', 'VERIFY_SHA', 'VERIFY_SHA = ' + repr(sha(freezer.encode())))
template_pins = {name: sha((entry / name).read_bytes()) for name in ('install_rust_ci_tools_01.template.py','launch_exact_rust_ci_01.template.py')}
generator = replace_node(generator, 'assignment', 'TEMPLATE_PINS', 'TEMPLATE_PINS = ' + repr(template_pins))
write(entry / 'generate_ci_entry_01.py', generator)
origins['rust']['generate_ci_entry_01.py'] = identity(OLD_RUST / 'entry-01/generate_ci_entry_01.py')

py = HERE / 'python'
actual = SUCCESS_PY.read_text()
assert sha(actual.encode()) == '7c61fbcb65d71a6c0d9694a837a29c42ac1fc8cb18b46eda53cf4733ed611494'
start, end = actual.index('RECOVERY_INPUT ='), actual.index('def main():')
text = actual[:start] + actual[end:]
for block in (
    '    parser.add_argument("--recovery-input-sha256", required=True)\n',
    '        receipt["original_preflight_failure"] = verify_original_preflight_failure(args.recovery_input_sha256)\n',
    '        need(verify_original_preflight_failure(args.recovery_input_sha256) == receipt["original_preflight_failure"],\n             "original preflight evidence or private source ancestry changed during Python CI")\n',
):
    assert text.count(block) == 1
    text = text.replace(block, '')
text = rename_runtime(text)
for old, new in (('python-ci-tools-02','python-ci-tools-01'),('python-ci-launch-02','python-ci-launch-01'),
                 ('python-ci-02','python-ci-01'),('launch_python_ci_02.py','launch_python_ci_01.py')):
    text = text.replace(old,new)
text = text.replace('selected Rust cache changes affect Python inputs', 'selected Rust router changes affect Python inputs')
text = text.replace('selected_cache_changes_outside_python_inputs', 'selected_router_changes_outside_python_inputs')
text = text.replace(
    '18 published workflow commands with 85 dependency inputs, bound to the fixed R29 candidate Git parent and actual qualified R29 source',
    '18 published workflow commands with 85 dependency inputs, bound to the immutable dependency reference 06530d71 and actual qualified R29 source')
text = text.replace(
    '# Exact inherited source identities confirmed by the original read-only metadata\n# job 1a1aca4ad22-fc05-561a. No JSON, tool or unlisted source is eligible.',
    '# Parent R28 source identities were confirmed by metadata job 1a1aca4ad22-fc05-561a.\n# Every R29 read still checks its actual descriptor and bytes. No JSON, tool or\n# unlisted source is eligible for this exact mode exception.')
text = replace_node(text, 'assignment', 'QUALIFICATION_VERIFIER_SHA256', 'QUALIFICATION_VERIFIER_SHA256 = ' + repr(sha(freezer.encode())))
parent = json.loads((OLD_PY / 'candidate-parent-proof-01.json').read_bytes())
assert parent['schema'] == 'hepta-r28-published-python-parent-proof/v1'
parent['schema'] = 'hepta-r29-published-python-parent-proof/v1'
parent['scope_note'] = 'Immutable published input reference 06530d71, an ancestor of the actually published 1c23ba9a; not a claim about a future R29 publication parent or current branch HEAD.'
parent['known_later_publication_continuity'] = {
    'commit': '1c23ba9ad4e7c9436eb76d1508f6f0bd8ee7ce64',
    'tree': '91ef72ae803bede6a2b2d8e8eb8f25da95ad170b',
    'proof': identity(WORK / 'r26-publication-root-operations-01/python-input-continuity-01.json'),
    'same_seven_original_dependency_subtrees': True,
    'current_HEAD_or_hosted_CI_claimed': False}
parent_raw = (json.dumps(parent,sort_keys=True,indent=2)+'\n').encode()
write(py / 'candidate-parent-proof-01.json', parent_raw)
text = replace_node(text, 'assignment', 'PARENT_PROOF_SHA256', 'PARENT_PROOF_SHA256 = ' + repr(sha(parent_raw)))
write(py / 'launch_python_ci_01.template.py', text)
origins['python']['launch_python_ci_01.template.py'] = identity(SUCCESS_PY)
installer = rename_runtime((OLD_PY / 'install_python_ci_tools_01.template.py').read_text())
write(py / 'install_python_ci_tools_01.template.py', installer)
origins['python']['install_python_ci_tools_01.template.py'] = identity(OLD_PY / 'install_python_ci_tools_01.template.py')
pygen = rename_runtime((OLD_PY / 'generate_python_ci_entry_01.py').read_text())
pygen = replace_node(pygen, 'assignment', 'HERE', 'HERE = WORK / ' + repr(str(py.relative_to(WORK))))
pygen = replace_node(pygen, 'assignment', 'VERIFIER', 'VERIFIER = WORK / ' + repr(str((rust / 'freeze_rust_ci_01.py').relative_to(WORK))))
pygen = replace_node(pygen, 'assignment', 'VERIFIER_SHA', 'VERIFIER_SHA = ' + repr(sha(freezer.encode())))
pygen = replace_node(pygen, 'assignment', 'TEMPLATE_PINS', 'TEMPLATE_PINS = ' + repr({name:sha((py/name).read_bytes()) for name in ('launch_python_ci_01.template.py','install_python_ci_tools_01.template.py')}))
pygen = replace_node(pygen, 'assignment', 'PARENT_PROOF_SHA', 'PARENT_PROOF_SHA = ' + repr(sha(parent_raw)))
pygen = pygen.replace('selected cache-only changes affect Python dependency inputs','selected router changes affect Python dependency inputs')
pygen = pygen.replace('selected_cache_changes_outside_python_inputs','selected_router_changes_outside_python_inputs')
write(py / 'generate_python_ci_entry_01.py', pygen)
origins['python']['generate_python_ci_entry_01.py'] = identity(OLD_PY / 'generate_python_ci_entry_01.py')
write(HERE / 'derivation-origins-01.json', json.dumps(origins,sort_keys=True,indent=2)+'\n')
print(json.dumps({'drafts_written':True,'canonical_source_input_bound':True,'actual_qualification_results_bound':False,'candidate_or_CI_main_executed':False,
                  'rust_freezer':identity(rust/'freeze_rust_ci_01.py'),
                  'python_launcher':identity(py/'launch_python_ci_01.template.py')}))
