"""Read only ten fixed archive/manifest/chunk groups; never remove or create files."""
import argparse
import base64
import hashlib
import json
import os
from pathlib import Path
import re
import stat
import sys
import time

SPECS = [{'archive': {'bytes': 3339674,
              'path': '/home/qian/hepta-runtime-optimization-20261105-r26/evidence-export-02/qualification-01.tar.gz',
              'sha256': '00f0e20189a54e52f21b54f14057f7974789575fd9d9ef19c555925b32a89136'},
  'chunk_count': 70,
  'chunk_logical_bytes': 4452900,
  'chunks_directory': '/home/qian/hepta-runtime-optimization-20261105-r26/evidence-export-02/qualification-01.tar.gz.chunks',
  'id': 'r26-qualification',
  'manifest': {'bytes': 28450,
               'path': '/home/qian/hepta-runtime-optimization-20261105-r26/evidence-export-02/qualification-01.tar.gz.chunks/manifest.json',
               'sha256': 'fbe6155a292305d49842987fe6241e42b5580284902ebc939d12d4fde3933b89'}},
 {'archive': {'bytes': 307232,
              'path': '/home/qian/hepta-runtime-optimization-20261105-r26/evidence-export-02/ci-01.tar.gz',
              'sha256': '3daf244b382819902a99cc7a8d92cecf2adc639d793a9f3c7d0eaf435333690b'},
  'chunk_count': 7,
  'chunk_logical_bytes': 409644,
  'chunks_directory': '/home/qian/hepta-runtime-optimization-20261105-r26/evidence-export-02/ci-01.tar.gz.chunks',
  'id': 'r26-ci',
  'manifest': {'bytes': 3363,
               'path': '/home/qian/hepta-runtime-optimization-20261105-r26/evidence-export-02/ci-01.tar.gz.chunks/manifest.json',
               'sha256': 'b16df8c0e30d283ca7cd19df92e8fa0d96b9527da14a13b4f5cedc9d44920ad9'}},
 {'archive': {'bytes': 3465581,
              'path': '/home/qian/hepta-runtime-optimization-20261105-r26/evidence-export-02/observation-01.tar.gz',
              'sha256': 'ba1831f0e2f3fc1428082509380f33f5a47058cb70c657ee135e66a064ea1ca8'},
  'chunk_count': 73,
  'chunk_logical_bytes': 4620776,
  'chunks_directory': '/home/qian/hepta-runtime-optimization-20261105-r26/evidence-export-02/observation-01.tar.gz.chunks',
  'id': 'r26-observation',
  'manifest': {'bytes': 29492,
               'path': '/home/qian/hepta-runtime-optimization-20261105-r26/evidence-export-02/observation-01.tar.gz.chunks/manifest.json',
               'sha256': 'b088a277b66fde18eec8f3ccf45c327355a799e7c6aaa4aea76fd21d3853cab1'}},
 {'archive': {'bytes': 2002792,
              'path': '/home/qian/hepta-runtime-optimization-20261105-r26/evidence-export-02/lifecycle-01.tar.gz',
              'sha256': '92d990467a03552aeb61d3940903b9ccc78bed3521ab1fe96310001b430381f9'},
  'chunk_count': 42,
  'chunk_logical_bytes': 2670392,
  'chunks_directory': '/home/qian/hepta-runtime-optimization-20261105-r26/evidence-export-02/lifecycle-01.tar.gz.chunks',
  'id': 'r26-lifecycle',
  'manifest': {'bytes': 17162,
               'path': '/home/qian/hepta-runtime-optimization-20261105-r26/evidence-export-02/lifecycle-01.tar.gz.chunks/manifest.json',
               'sha256': '5db2528985112c2cea5cc5f930ea47d9bfeeddb1f0f51a406f722f5d8489dc11'}},
 {'archive': {'bytes': 7150445,
              'path': '/home/qian/hepta-runtime-optimization-20261105-r25/mechanism-evidence-export-07/private-diagnostic-full-07.tar.gz',
              'sha256': '4292ad42e87728630f4a6d9a42a34a8447836f20b07ce095415f91c0f897d1bd'},
  'chunk_count': 149,
  'chunk_logical_bytes': 9533928,
  'chunks_directory': '/home/qian/hepta-runtime-optimization-20261105-r25/mechanism-evidence-export-07/private-diagnostic-full-07.tar.gz.chunks',
  'id': 'r25-private07',
  'manifest': {'bytes': 62815,
               'path': '/home/qian/hepta-runtime-optimization-20261105-r25/mechanism-evidence-export-07/private-diagnostic-full-07.tar.gz.chunks/manifest.json',
               'sha256': '66a10a77cc10c118521e74dc358c842aa7429661e71fa85f3aa5604e8f3cef5b'}},
 {'archive': {'bytes': 2450580,
              'path': '/home/qian/hepta-runtime-optimization-20261105-r25/evidence-export-rejection-02/qualification-02.tar.gz',
              'sha256': '82164857d78b965910fb5e1f8ae4d3d9769718d7fcafdd32bf2653eb1f1bd893'},
  'chunk_count': 52,
  'chunk_logical_bytes': 3267440,
  'chunks_directory': '/home/qian/hepta-runtime-optimization-20261105-r25/evidence-export-rejection-02/qualification-02.tar.gz.chunks',
  'id': 'r25-qualification',
  'manifest': {'bytes': 21834,
               'path': '/home/qian/hepta-runtime-optimization-20261105-r25/evidence-export-rejection-02/qualification-02.tar.gz.chunks/manifest.json',
               'sha256': '1f911d01ffe5ce8b6807b5a511b6b9c9726f4284c0af67a4ad80bf833da655a1'}},
 {'archive': {'bytes': 838300,
              'path': '/home/qian/hepta-runtime-optimization-20261105-r25/evidence-export-rejection-02/ci-02.tar.gz',
              'sha256': '1faf3d0faa8bc2b76e91aa88fdfa6ae5211f47f5eb630fd4bf6a71dc7b0a0d43'},
  'chunk_count': 18,
  'chunk_logical_bytes': 1117736,
  'chunks_directory': '/home/qian/hepta-runtime-optimization-20261105-r25/evidence-export-rejection-02/ci-02.tar.gz.chunks',
  'id': 'r25-ci',
  'manifest': {'bytes': 7790,
               'path': '/home/qian/hepta-runtime-optimization-20261105-r25/evidence-export-rejection-02/ci-02.tar.gz.chunks/manifest.json',
               'sha256': 'd71aeae1b9c7dfcb07075e00343937f5e10ad887c9c38abb1fc51e2e071d683c'}},
 {'archive': {'bytes': 3229182,
              'path': '/home/qian/hepta-runtime-optimization-20261105-r25/evidence-export-rejection-02/observation-02.tar.gz',
              'sha256': 'b463c80bb3897b4a96ce60d6cb7452ee23b521c50fe9c22048ea23169d180c7c'},
  'chunk_count': 68,
  'chunk_logical_bytes': 4305576,
  'chunks_directory': '/home/qian/hepta-runtime-optimization-20261105-r25/evidence-export-rejection-02/observation-02.tar.gz.chunks',
  'id': 'r25-observation',
  'manifest': {'bytes': 28210,
               'path': '/home/qian/hepta-runtime-optimization-20261105-r25/evidence-export-rejection-02/observation-02.tar.gz.chunks/manifest.json',
               'sha256': '0f0f0572cd09a2c3b104b3a59fccbcd1263ac4e616ee034c274dd33035ffca89'}},
 {'archive': {'bytes': 1915620,
              'path': '/home/qian/hepta-runtime-optimization-20261105-r28/qualification-ci-evidence-01/qualification-ci-01.tar.xz',
              'sha256': '442586ded13a4cfde54531e6f05ddddcf26c2f53d40d15b04c5993ece5f04186'},
  'chunk_count': 40,
  'chunk_logical_bytes': 2554160,
  'chunks_directory': '/home/qian/hepta-runtime-optimization-20261105-r28/qualification-ci-evidence-01/qualification-ci-01.tar.xz.chunks',
  'id': 'r28-qc',
  'manifest': {'bytes': 17075,
               'path': '/home/qian/hepta-runtime-optimization-20261105-r28/qualification-ci-evidence-01/qualification-ci-01.tar.xz.chunks/manifest.json',
               'sha256': '15555b8c06b4d9bb1aaca1f1f8f398785e669e18f1b4c52a943f8667abae8f6f'}},
 {'archive': {'bytes': 1704632,
              'path': '/home/qian/hepta-runtime-optimization-20261105-r28/performance-evidence-01/performance-01.tar.xz',
              'sha256': 'ba420b2e0a34a23b9d0330b3c5f38e743b08110d02db9c7dd599b25943070613'},
  'chunk_count': 36,
  'chunk_logical_bytes': 2272844,
  'chunks_directory': '/home/qian/hepta-runtime-optimization-20261105-r28/performance-evidence-01/performance-01.tar.xz.chunks',
  'id': 'r28-performance',
  'manifest': {'bytes': 15065,
               'path': '/home/qian/hepta-runtime-optimization-20261105-r28/performance-evidence-01/performance-01.tar.xz.chunks/manifest.json',
               'sha256': 'cd2cda53143d871079850c94d4ce041aeb23c42bcf5a6fecac964f73ccca6742'}}]  # FIXED_TEN_GROUPS
SCOPE_SHA256 = "c2c4e4aff98f6a7971c372c308f6cc61f29701de7525f2059b3f6e9f54c4ed5c"
OWNER = 1000
FIELDS = ("st_dev", "st_ino", "st_mode", "st_uid", "st_gid", "st_nlink",
          "st_size", "st_mtime_ns", "st_ctime_ns", "st_blocks")
DIRECTORY_IDENTITY = ("st_dev", "st_ino", "st_mode", "st_uid", "st_gid")
HEX = re.compile(r"[0-9a-f]{64}\Z")


def need(value, message):
    if not value:
        raise RuntimeError(message)


def encode(value):
    return (json.dumps(value, sort_keys=True, indent=2, allow_nan=False) + "\n").encode()


def identity(body):
    return {"bytes": len(body), "sha256": hashlib.sha256(body).hexdigest()}


def stamp(value):
    return {key: getattr(value, key) for key in FIELDS}


def directory_identity(value):
    return {key: getattr(value, key) for key in DIRECTORY_IDENTITY}


def disk():
    value = os.statvfs("/home/qian")
    return {"available_bytes": value.f_bavail * value.f_frsize,
            "fragment_bytes": value.f_frsize, "unchanged_required_reserve_bytes": 3221225472}


def open_directory(path, state):
    path = Path(path)
    need(path.is_absolute() and path.as_posix().startswith("/home/qian/")
         and path.resolve(strict=True) == path, "indirect or out-of-scope directory")
    fd = os.open("/", os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW | os.O_CLOEXEC)
    current = Path("/")
    state["directories"].append((current, fd, directory_identity(os.fstat(fd))))
    for component in path.parts[1:]:
        fd = os.open(component, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW | os.O_CLOEXEC,
                     dir_fd=fd)
        current = current / component
        value = os.fstat(fd)
        state["directories"].append((current, fd, directory_identity(value)))
        need(stat.S_ISDIR(value.st_mode) and value.st_uid in (0, OWNER)
             and value.st_mode & 0o022 == 0, "unsafe fixed directory ownership or mode")
        need(directory_identity(value) == directory_identity(os.stat(current, follow_symlinks=False)),
             "directory descriptor no longer names its original path")
    need(os.fstat(fd).st_uid == OWNER, "task directory is not owned by the fixed native operator")
    return fd


def verify_directories(state):
    for path, fd, before in state["directories"]:
        need(directory_identity(os.fstat(fd)) == before
             == directory_identity(os.stat(path, follow_symlinks=False)),
             "held directory path identity changed: " + str(path))


def read_regular(directory, name, expected, state, keep=False, maximum=16 * 1024 * 1024):
    need(Path(name).name == name and name not in (".", "..")
         and type(expected["bytes"]) is int and 0 <= expected["bytes"] <= maximum
         and HEX.fullmatch(expected["sha256"]), "invalid fixed regular-file declaration")
    fd = os.open(name, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK | os.O_CLOEXEC, dir_fd=directory)
    retained = False
    try:
        before = os.fstat(fd)
        need(stat.S_ISREG(before.st_mode) and before.st_uid == OWNER and before.st_nlink == 1
             and before.st_mode & 0o022 == 0 and before.st_size == expected["bytes"],
             "unsafe, linked, changed or oversized original file: " + name)
        blocks = []
        size = 0
        while block := os.read(fd, min(1024 * 1024, expected["bytes"] - size + 1)):
            size += len(block)
            need(size <= expected["bytes"], "original file grew while reading")
            blocks.append(block)
        body = b"".join(blocks)
        need(identity(body) == {key: expected[key] for key in ("bytes", "sha256")}
             and stamp(before) == stamp(os.fstat(fd))
             == stamp(os.stat(name, dir_fd=directory, follow_symlinks=False)),
             "original file body or linked descriptor identity differs: " + name)
        result = {**identity(body), "identity": stamp(before)}
        if keep:
            state["originals"].append((directory, name, fd, result))
            retained = True
        return body, result, fd if keep else None
    finally:
        if not retained:
            os.close(fd)


def verify_originals(state):
    verify_directories(state)
    for directory, name, fd, before in state["originals"]:
        need(stamp(os.fstat(fd)) == before["identity"]
             == stamp(os.stat(name, dir_fd=directory, follow_symlinks=False)),
             "retained compressed archive or manifest changed: " + name)


def close_state(state):
    for _, _, fd, _ in reversed(state["originals"]):
        os.close(fd)
    for _, fd, _ in reversed(state["directories"]):
        os.close(fd)


def inspect_group(spec, state):
    archive_path = Path(spec["archive"]["path"])
    chunk_path = Path(spec["chunks_directory"])
    need(str(chunk_path) == str(archive_path) + ".chunks"
         and spec["manifest"]["path"] == str(chunk_path / "manifest.json"),
         "fixed archive/chunk/manifest relationship differs")
    parent = open_directory(archive_path.parent, state)
    directory = open_directory(chunk_path, state)
    directory_before = stamp(os.fstat(directory))
    need(os.fstat(parent).st_dev == os.fstat(directory).st_dev, "chunk directory changed filesystem")
    archive, archive_id, _ = read_regular(parent, archive_path.name, spec["archive"], state, keep=True)
    manifest_raw, manifest_id, _ = read_regular(directory, "manifest.json", spec["manifest"], state,
                                               keep=True, maximum=128 * 1024)
    manifest = json.loads(manifest_raw)
    need(manifest["encoding"] == "base64" and manifest["maximum_decoded_chunk_bytes"] == 48000
         and manifest["maximum_text_file_bytes"] == 64000 and len(manifest["chunks"]) == spec["chunk_count"]
         and {key: manifest["archive"][key] for key in ("bytes", "sha256")}
         == {key: spec["archive"][key] for key in ("bytes", "sha256")}
         and manifest["archive"]["source_path"] == str(archive_path), "original transfer manifest differs")
    names = []
    offset = 0
    records = []
    for index, item in enumerate(manifest["chunks"]):
        name = "chunk-%05d.b64" % index
        need(item["path"] == str(chunk_path / name) and item["offset"] == offset
             and type(item["bytes"]) is int and 0 < item["bytes"] <= 48000,
             "chunk path, ordering or offset differs")
        decoded = archive[offset:offset + item["bytes"]]
        generated = base64.b64encode(decoded)
        need(identity(decoded) == {key: item[key] for key in ("bytes", "sha256")}
             and identity(generated) == {"bytes": item["base64_bytes"], "sha256": item["base64_sha256"]},
             "chunk cannot be regenerated exactly from the retained archive")
        actual, file_id, _ = read_regular(directory, name, identity(generated), state, maximum=64000)
        need(actual == generated and file_id["identity"]["st_dev"] == os.fstat(directory).st_dev,
             "actual chunk is not the exact generated same-device regular file")
        inode = (file_id["identity"]["st_dev"], file_id["identity"]["st_ino"])
        need(inode not in state["chunk_inodes"], "two chunk paths alias the same inode")
        state["chunk_inodes"].add(inode)
        records.append({"path": item["path"], "name": name, **file_id})
        names.append(name)
        offset += len(decoded)
    entries = []
    with os.scandir(directory) as iterator:
        for entry in iterator:
            entries.append(entry.name)
            need(len(entries) <= 256, "fixed chunk directory entry limit exceeded")
    need(set(entries) == set(names) | {"manifest.json"},
         "unknown or missing entries in a fixed chunk directory; nothing may be removed")
    need(offset == len(archive) and sum(item["bytes"] for item in records) == spec["chunk_logical_bytes"]
         and directory_before == stamp(os.fstat(directory))
         == stamp(os.stat(chunk_path, follow_symlinks=False)), "chunk set or directory changed during inventory")
    for item in records:
        need(item["identity"] == stamp(os.stat(item["name"], dir_fd=directory, follow_symlinks=False)),
             "verified chunk identity changed before the complete set closed")
    verify_originals(state)
    proof = {"id": spec["id"], "archive": {"path": str(archive_path), **archive_id},
             "manifest": {"path": str(chunk_path / "manifest.json"), **manifest_id},
             "directory": str(chunk_path), "directory_identity": directory_before,
             "verified_chunk_count": len(records), "logical_bytes": sum(row["bytes"] for row in records),
             "allocated_bytes_from_st_blocks": sum(row["identity"]["st_blocks"] * 512 for row in records),
             "metadata_sha256": hashlib.sha256(encode(records)).hexdigest(),
             "all_chunks_reconstructed_and_byte_equal": True,
             "all_regular_owned_nlink1_same_device": True, "unknown_directory_entries": [],
             "archive_and_manifest_unchanged": True}
    state["groups"].append({"spec": spec, "directory_fd": directory, "records": records, "proof": proof})
    return proof


def inspect_all(state):
    need(sys.platform == "linux" and os.geteuid() == OWNER and len(SPECS) == 10
         and hashlib.sha256(encode(SPECS)).hexdigest() == SCOPE_SHA256,
         "fixed native operator and unchanged exact scope required")
    groups, errors = [], []
    for spec in SPECS:
        try:
            groups.append(inspect_group(spec, state))
        except Exception as error:
            errors.append({"id": spec["id"], "type": type(error).__name__, "reason": str(error)[:2000]})
    verify_originals(state)
    originals = {(row[3]["identity"]["st_dev"], row[3]["identity"]["st_ino"]) for row in state["originals"]}
    need(not originals.intersection(state["chunk_inodes"]), "a chunk aliases a protected original")
    return {"passed": not errors and len(groups) == 10, "groups": groups, "errors": errors,
            "verified_chunk_count": sum(row["verified_chunk_count"] for row in groups),
            "logical_bytes": sum(row["logical_bytes"] for row in groups),
            "allocated_bytes_from_st_blocks": sum(row["allocated_bytes_from_st_blocks"] for row in groups),
            "st_blocks_is_not_a_guarantee_of_new_available_space": True}


def source_copy_metadata(state):
    """Metadata only for the one exact source that the qualifier will copy."""
    path = Path("/home/qian/hepta-runtime-optimization-20261105-r28/source")
    root = open_directory(path, state)
    root_before = stamp(os.fstat(root))
    counts = {"directories": 0, "regular_files": 0, "logical_bytes": 0,
              "allocated_bytes_from_st_blocks": 0, "linked_regular_files": 0,
              "symlinks": 0, "other_entries": 0, "other_owner": 0, "other_device": 0}
    anomalies, rows = [], []

    def walk(directory, relative, depth):
        need(depth <= 32, "fixed source depth exceeds bounded metadata scope")
        before = stamp(os.fstat(directory))
        counts["directories"] += 1
        entries = []
        with os.scandir(directory) as iterator:
            for entry in iterator:
                entries.append(entry.name)
                need(len(entries) <= 10000, "source directory exceeds bounded metadata scope")
        entries.sort()
        for name in entries:
            need(len(rows) < 100000, "source entry count exceeds bounded metadata scope")
            value = os.stat(name, dir_fd=directory, follow_symlinks=False)
            rel = (relative + "/" if relative else "") + name
            row = {"path": rel, "identity": stamp(value)}
            rows.append(row)
            if value.st_uid != OWNER:
                counts["other_owner"] += 1
            if value.st_dev != root_before["st_dev"]:
                counts["other_device"] += 1
                if len(anomalies) < 32:
                    anomalies.append({"path": rel, "reason": "other device; not traversed"})
                continue
            if stat.S_ISDIR(value.st_mode):
                child = os.open(name, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW | os.O_CLOEXEC,
                                dir_fd=directory)
                try:
                    need(stamp(os.fstat(child)) == row["identity"], "source child directory replaced")
                    walk(child, rel, depth + 1)
                    need(stamp(os.fstat(child)) == row["identity"]
                         == stamp(os.stat(name, dir_fd=directory, follow_symlinks=False)),
                         "source child directory changed during metadata scan")
                finally:
                    os.close(child)
            elif stat.S_ISREG(value.st_mode):
                counts["regular_files"] += 1
                counts["logical_bytes"] += value.st_size
                counts["allocated_bytes_from_st_blocks"] += value.st_blocks * 512
                counts["linked_regular_files"] += int(value.st_nlink != 1)
            else:
                counts["symlinks" if stat.S_ISLNK(value.st_mode) else "other_entries"] += 1
                if len(anomalies) < 32:
                    anomalies.append({"path": rel, "reason": "nonregular; not followed"})
            need(stamp(value) == stamp(os.stat(name, dir_fd=directory, follow_symlinks=False)),
                 "source entry changed during metadata scan")
        need(before == stamp(os.fstat(directory)), "source directory changed during metadata scan")

    walk(root, "", 0)
    need(root_before == stamp(os.fstat(root)) == stamp(os.stat(path, follow_symlinks=False)),
         "original source root changed during metadata inventory")
    return {"path": str(path), "root_identity": root_before, "counts": counts,
            "metadata_sha256": hashlib.sha256(encode(rows)).hexdigest(), "anomaly_examples": anomalies,
            "complete_metadata_traversal": counts["other_device"] == 0,
            "source_payload_bytes_read": 0, "symlinks_followed": False,
            "copy_allocation_or_future_free_space_guaranteed": False}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source-sha256", required=True)
    args = parser.parse_args()
    need(HEX.fullmatch(args.source_sha256), "original request source SHA required")
    state = {"directories": [], "originals": [], "groups": [], "chunk_inodes": set()}
    report = {"schema": "hepta-r29-fixed-chunk-inventory/v1", "operation": "read_only_inventory",
              "entry_source_sha256_from_original_request": args.source_sha256,
              "source_self_readback_claimed": False, "scope_sha256": SCOPE_SHA256,
              "passed": False, "started_monotonic_ns": time.monotonic_ns(),
              "files_created": 0, "files_removed": 0, "archive_or_manifest_modified": False,
              "proc_argv_or_environment_read": False, "automatic_retries": 0}
    try:
        report["disk_before"] = disk()
        report.update(inspect_all(state))
        report["fixed_source_copy_metadata"] = source_copy_metadata(state)
        report["disk_after"] = disk()
    except Exception as error:
        report.update(passed=False, fatal_error={"type": type(error).__name__, "reason": str(error)[:2000]})
    finally:
        close_state(state)
        report["finished_monotonic_ns"] = time.monotonic_ns()
        print(json.dumps(report, sort_keys=True, separators=(",", ":"), allow_nan=False), flush=True)
    return 0 if report["passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
