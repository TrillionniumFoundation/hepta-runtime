"""Data-only fresh installation of the R29 Python launcher and four binding files."""
import base64
import gzip
import hashlib
import io
import json
import os
from pathlib import Path
import stat
import sys
import tarfile

SPEC = {'actual_pins': {'AUDIT_SHA256': 'cee3be54342f396bd7438bf1f604ca2fa6658e35e8489c9b7d4189544326f8e4',
                 'JOB_ID': '1a1ad4261c8-fc05-593b',
                 'MAP_SHA256': '58ca6700a4378d14912358f9bb787d395ef5f86f17d7bf373af2525ee55ae88b',
                 'PREPARATION_SHA256': 'fcc7bd5ee050a60b38c047ea9b06ac0bae1d7ebf927b67af60b620af18012782',
                 'REPORT_SHA256': '942a570097ab3c751e9969f3d13924dec474888e85e0ce176ee7943547d12b62',
                 'SUMMARY_SHA256': '517a269344974176d7f713589915190068f72b5d40d0d91deaaad610aa5765da',
                 'TERMINAL_SHA256': '582adb11fde3f248411fa5daf25a235cc352bfae28fa3605f2898779b8b48462'},
 'archive': {'bytes': 21783,
             'sha256': '0a3be5eca468b3fee96bcd6aae8a63b392db5bb42870983da74cc2f2b1db60e4'},
 'base64_bytes': 29044,
 'files': {'actual-python-input-01.json': {'bytes': 2883,
                                           'sha256': '8cc3d0a7eb1535a11fc6c40934e5b704b7e0b555513904733345a177da810401'},
           'candidate-parent-proof-01.json': {'bytes': 31722,
                                              'sha256': 'b55a6a6210f3336a163ea6b4a4563b39be46c59e0a9e4c51c49d8008a07c7226'},
           'launch_python_ci_01.py': {'bytes': 26702,
                                      'sha256': '53ea93a10c2b0420f5f7872491bcacf85f95145360589a61885e341cbbde4629'},
           'package-manifest-01.json': {'bytes': 1005,
                                        'sha256': 'b73d74bd77b4327c2808d9e379ff237a8c48135e5c8efbff4cd3bf43a7d38dd5'},
           'qualification_binding_01.py': {'bytes': 25830,
                                           'sha256': 'b57b1f39182f393a834162f0fb685f967b110e66e9c92cca886f1ad21855707a'}}}
ROOT = Path('/home/qian/hepta-runtime-optimization-20261105-r29')
DEST = ROOT / 'python-ci-tools-01'
RECEIPT = ROOT / 'python-ci-tools-install-01.json'
NAMES = {'launch_python_ci_01.py', 'qualification_binding_01.py', 'candidate-parent-proof-01.json',
         'actual-python-input-01.json', 'package-manifest-01.json'}


def need(value, reason):
    if not value:
        raise ValueError(reason)


def identity(body):
    return {'bytes': len(body), 'sha256': hashlib.sha256(body).hexdigest()}


need(type(SPEC) is dict, 'actual reviewed installation package is not bound')
need(sys.platform == 'linux' and os.geteuid() != 0, 'native Linux operator required')
encoded = sys.stdin.buffer.read(SPEC['base64_bytes'] + 1)
need(len(encoded) == SPEC['base64_bytes'], 'fixed archive stdin length differs')
packed = base64.b64decode(encoded, validate=True)
need(identity(packed) == SPEC['archive'], 'fixed archive bytes/hash differ')
expanded = gzip.decompress(packed)
need(len(expanded) <= 512 * 1024, 'fixed tool archive exceeds expanded bound')
files = {}
with tarfile.open(fileobj=io.BytesIO(expanded), mode='r:') as archive:
    members = archive.getmembers()
    need(len(members) == 5 and {m.name for m in members} == NAMES, 'exact five-file archive required')
    for member in members:
        need(member.type == tarfile.REGTYPE and not member.linkname and not member.pax_headers
             and not member.issparse() and member.mode == 0o600 and member.name not in files
             and Path(member.name).name == member.name and 0 < member.size <= 65536,
             'unsafe, repeated or unexpected archive member')
        body = archive.extractfile(member).read()
        need(len(body) == member.size and identity(body) == SPEC['files'][member.name],
             'fixed member identity differs: ' + member.name)
        files[member.name] = body
    tail = expanded[archive.offset:]
    need(len(tail) >= 1024 and not any(tail), 'tar ending differs')
manifest = json.loads(files['package-manifest-01.json'])
need(set(SPEC['files']) == NAMES and manifest['schema'] == 'hepta-r29-exact-python-ci-tools/v1'
     and manifest['files'] == {name: SPEC['files'][name] for name in NAMES if name not in {
         'package-manifest-01.json'}}
     and manifest['actual_qualification_job_id'] == SPEC['actual_pins']['JOB_ID']
     and manifest['executed'] is False and manifest['hosted_actions_passed'] is False,
     'frozen package manifest composition differs')
need(ROOT.resolve(strict=True) == ROOT, 'R29 root path is indirect')
root_info = ROOT.lstat()
need(stat.S_ISDIR(root_info.st_mode) and root_info.st_uid == os.geteuid(), 'R29 root is not an owned directory')
need(not os.path.lexists(DEST) and not os.path.lexists(RECEIPT), 'fresh tool directory and receipt required')
os.umask(0o077)
root_fd = os.open(ROOT, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW | os.O_CLOEXEC)
try:
    need((os.fstat(root_fd).st_dev, os.fstat(root_fd).st_ino) == (root_info.st_dev, root_info.st_ino),
         'root directory changed before install')
    os.mkdir(DEST.name, mode=0o700, dir_fd=root_fd)
    dest_fd = os.open(DEST.name, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW | os.O_CLOEXEC, dir_fd=root_fd)
    try:
        directory = os.fstat(dest_fd)
        for name, body in sorted(files.items()):
            fd = os.open(name, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW | os.O_CLOEXEC, 0o600, dir_fd=dest_fd)
            with os.fdopen(fd, 'wb') as stream:
                stream.write(body)
                stream.flush()
                os.fsync(stream.fileno())
            fd = os.open(name, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK | os.O_CLOEXEC, dir_fd=dest_fd)
            with os.fdopen(fd, 'rb') as stream:
                before = os.fstat(stream.fileno())
                actual = stream.read(65537)
                after = os.fstat(stream.fileno())
            fields = ('st_dev', 'st_ino', 'st_mode', 'st_uid', 'st_nlink', 'st_size', 'st_mtime_ns', 'st_ctime_ns')
            current = os.stat(name, dir_fd=dest_fd, follow_symlinks=False)
            need(stat.S_ISREG(before.st_mode) and before.st_uid == os.geteuid() and before.st_nlink == 1
                 and stat.S_IMODE(before.st_mode) == 0o600 and actual == body
                 and all(getattr(before, k) == getattr(after, k) == getattr(current, k) for k in fields),
                 'installed file readback/identity differs: ' + name)
        os.fsync(dest_fd)
        need(DEST.resolve(strict=True) == DEST and (DEST.lstat().st_dev, DEST.lstat().st_ino)
             == (directory.st_dev, directory.st_ino) and {p.name for p in DEST.iterdir()} == NAMES,
             'installed directory identity or inventory differs')
    finally:
        os.close(dest_fd)
    receipt = {'schema': 'hepta-r29-exact-python-ci-tools-install/v1', 'passed': True,
               'destination': str(DEST), 'archive': SPEC['archive'], 'files': SPEC['files'],
               'actual_qualification_pins': SPEC['actual_pins'], 'original_file_count': 5,
               'packaged_tools_executed': False, 'cargo_executed': False,
               'source_or_compiler_cache_modified': False}
    receipt_raw = (json.dumps(receipt, sort_keys=True, indent=2) + '\n').encode()
    fd = os.open(RECEIPT.name, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW | os.O_CLOEXEC,
                 0o600, dir_fd=root_fd)
    with os.fdopen(fd, 'wb') as stream:
        stream.write(receipt_raw)
        stream.flush()
        os.fsync(stream.fileno())
    os.fsync(root_fd)
finally:
    os.close(root_fd)
print(json.dumps({'passed': True, 'receipt': {'path': str(RECEIPT), **identity(receipt_raw)},
                  'installed_regular_files': 5, 'packaged_tools_executed': False}, sort_keys=True), flush=True)
