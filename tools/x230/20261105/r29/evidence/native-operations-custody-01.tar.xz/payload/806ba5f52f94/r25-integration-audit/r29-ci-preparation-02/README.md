# R29 CI preparation revision02: final source binding, results unbound

These files prepare the two original Rust workflow commands and all 18 original
Python workflow commands for a future, fully qualified R29 source. No CI tool,
freezer, materializer, installer, or launcher main has been run. The local
`prepare_interfaces_01.py` only constructs the source files in this directory.

The runtime candidate is the frozen two-file shared unfiltered ToolRouter change
over the actual qualified R28 source. Accepted production remains R24. The R28
observation rejection is retained by the shared preparation validator and is not
converted into a R29 result.

## Final source binding and unresolved results

Revision02 copies the reviewed final canonical preparation function byte for byte
into both the Rust materializer and the six-receipt freezer. Python uses that
exact freezer as its qualification verifier. Only the canonical function's two
source identities have changed from the preserved revision01 snapshot:

| Identity | Bytes | SHA-256 |
| --- | ---: | --- |
| Final qualification entry | 67,635 | `7ce339aa261fdf6acbc8e0ca8cf67f5c5d3a7b56fcc34d51ed4ee56ea4fe389a` |
| Actual cache-admission input | 311,502 | `60bfe1ef593ad58d528f6e508d3f6e0a1e4f76183f1293b40f36b7ee6bb3f8a8` |

The final canonical source is 16,992 bytes with SHA-256
`2892bd35bb5f1b5a90919e74453a18d5ae6ad738d08fcc780f3c0ac01c67c923`.
The entry and input remote names remain respectively
`ROOT25/tools/prepare_and_qualify_r29_01.py` and
`ROOT25/tools/r29-qualification-01-input.json`. All dependent source hashes and
local generator paths were updated to this fresh revision02 directory. The old
revision01 source set and its independent review remain unchanged.

The actual admission input preserves the original failed probe01, the earlier
probe02 and chunk-inventory space shortages, the separately completed retirement
of one exact retained cache duplicate, the successful fresh probe03, and the
original root writer window. Probe03 observed 3,493,085,184 available bytes;
the unchanged qualification entry must still satisfy each of its three actual
3 GiB reserve checks. None of those snapshots is a qualification result.

All seven actual qualification fields in the Rust materializer remain
`UNBOUND_ACTUAL_*`. These templates do not embed any successful R29 job,
formatted source map, test result, release binary or native terminal. The native
qualification may be running separately under root's original request; only
its actual complete six original receipts may later fill these fields. No
freezer or CI package generator has been run with future or synthetic results.

## Original qualification and CI contracts

The qualification still requires all eight original stages, all 221 compiler
inputs, all 19 qualification harness files, an empty test filter, and zero
retries. Two new Linux tests change the expected full inventory to **1,689
selected, 34 ignored, 1,655 passed, zero failed**. These are required future
counts, not a report of execution. The independent audit must agree.

Rust retains these exact workflow commands:

```text
cargo check --locked --all-targets --all-features
cargo nextest run --locked --all-targets --all-features --test-threads 1 --retries 0 --no-fail-fast
```

The separate read-only inventory remains
`cargo nextest list --locked --all-targets --all-features --message-format json`.
Its complete case set is compared with actual qualification and nextest output.
The original nextest 0.9.137 auditor is byte-identical. The original environment,
1800-second check, 3600-second nextest, owned process-group cleanup, full logs,
and source/binary checks before and after are retained. The original native
request remains 7200 seconds, nice 5, CPU 200%, memory 5 GiB.

Python retains the exact frozen 85 dependency inputs, all 18 workflow argv, the
original discovery sets, and the original runner `de69c48b…`. It runs against the
already installed R25 CI input package, and independently binds that package to
the immutable published dependency reference `06530d71…` and the actual new R29
source. The known published descendant `1c23ba9a…` has the same seven dependency
subtrees. The historical fields named `candidate_git_parent` continue to identify
that immutable input reference; they do not assert the current branch HEAD or a
future R29 commit parent. No hosted CI result is inferred from this proof.

Python derives from the **actual successful R28 recovery launcher** `7c61fbcb…`.
Its generic input guards remain strict. Only these two qualified-source paths
may have exact mode `0100660`, and only with UID/GID 1000, one link, the exact
length below, the corresponding actual qualified-map hash, and matching bytes:

| Relative source path | Bytes | SHA-256 |
| --- | ---: | --- |
| `src/mcp/runtime/jobs_cancel_io_tests.rs` | 17,145 | `b9553137fe32d873536252c4371bcb57dfceb4e8fac988937b7c552a871f889a` |
| `src/mcp/runtime/jobs_cancel_read_tests.rs` | 14,542 | `ff92e72b71a8afc23edda7e686c66f87c13ac76dfa3b5c8a8b8e124383b3bf87` |

The qualified-source reader checks current R29 descriptors and bytes before and
after the original Python run. JSON, tools, other source files and arbitrary
group-writable files receive no exception. No chmod is performed. The preflight
recovery proof that belonged specifically to R28 failed attempt01 is removed;
R29 uses a fresh attempt01. The old R28 failure and its successful recovery remain
unchanged in their original evidence directories.

## Fixed remote paths and actual local receipts

All new remote products are under
`/home/qian/hepta-runtime-optimization-20261105-r29`:

| Purpose | Relative path |
| --- | --- |
| Qualified source and private target | `source`, `target-build` |
| Preparation and qualification | `preparation-01.json`, `qualification-01/` |
| Exact original native terminal text | `qualification-terminal-status-01.json` |
| Rust installed tools, plan, output | `rust-ci-tools-01/`, `rust-ci-plan-01.json`, `rust-ci-01/` |
| Rust data-only installation receipt | `rust-ci-tools-install-01.json` |
| Python installed tools, outer logs, output | `python-ci-tools-01/`, `python-ci-launch-01/`, `python-ci-01/` |
| Python data-only installation receipt | `python-ci-tools-install-01.json` |

The six local receipt names are `preparation-01.json`,
`qualification-native-terminal-01.json`, `qualification-report-01.json`,
`qualified-source-map-01.json`, `isolated-tests-summary-01.json`, and
`isolated-tests-audit-01.json`. The preparation includes the original target
transfer receipt binding, so no seventh qualification receipt is invented.

After those six actual original receipts have passed, the existing CLIs remain:

```text
python3 -I -B <final>/rust/freeze_rust_ci_01.py --receipts <absolute-actual-receipts> --original-job-id <actual-R29-job> --out <fresh-frozen-package>
python3 -I -B <final>/rust/entry-01/generate_ci_entry_01.py --frozen-package <absolute-frozen-package> --out <fresh-rust-delivery>
python3 -I -B <final>/python/generate_python_ci_entry_01.py --receipts <absolute-actual-receipts> --original-job-id <actual-R29-job> --out <fresh-python-delivery>
```

Each generator creates a fixed five-file data-only installation package and one
original CI request. Root reviews the actual package, installs once, verifies
the original installation terminal/receipt, and executes only outside measurement
windows. An uncertain dispatch is reconciled with the exact original request
and key; a new key must not replay the workload. This preparation itself has no
remote request that is safe to dispatch.

## Review evidence

`derivation-origins-01.json` pins every original source and the final canonical
function. `static-rebinding-02.json` records byte-identical copies, all seven
unbound result fields, command equality, dependent hash closure, and exact
reverse substitutions that reconstruct revision01 source bytes.
`revision-01-to-02.diff` contains the complete source delta. The original
revision01 `static-reuse-01.json` and Python composition review remain the base
proof for unchanged command, environment, reader, and child-custody behavior.

`operations-01/` contains the exact local source-construction argv, output and
exit result. That operation only generated source files; it did not run a copied
CI, freezer, materializer, installer, launcher, test or qualification function.
`review-ready-02.json` pins the complete source set. Full actual qualification
and subsequent original CI execution remain separate requirements.
