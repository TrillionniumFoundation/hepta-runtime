import json, pathlib, hashlib, runpy
P=pathlib.Path('/workspace/scratch/806ba5f52f94/benchmark-r29/observation-operations-01')
T=pathlib.Path('/workspace/scratch/806ba5f52f94/r25-capacity-audit/r29-acceptance-delivery-01/tools-01')
def need(v,m):
    if not v: raise ValueError(m)
def dto(n):
    d=json.loads((P/n).read_text())['result'];need(not d.get('isError'),n);return d['content'][0]['text']
def load(n): return json.loads((P/n).read_bytes())
def identity(b): return {'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def put(n,b):
    if (P/n).exists():
        need((P/n).read_bytes()==b,'previous saved original differs: '+n)
    else:
        with (P/n).open('xb') as f:f.write(b)
s=json.loads(dto('status-03.json'))
need(s['job_id']=='1a1ad77dfe5-fc05-59f9' and s['state']=='succeeded' and s['exit_code']==0 and s['terminal_publication_protocol']==1,'native terminal')
need(all(s[k] is True for k in ('output_complete','output_durable','terminal_publication_confirmed')),'native completion')
need(all(s[k] is False for k in ('automatic_retry','timed_out','cancelled')),'native retry/cancel')
pages=[json.loads(dto(n)) for n in ('read-progress-00-01.json','read-progress-01-01.json')]
for c,n in (('stdout',299),('stderr',0)):
    b=b''
    for d in pages:
        v=d[c];need(v['offset']==len(b),'native cursor');x=bytes.fromhex(v['bytes_hex']);need(x==v['text'].encode(),'native text');b+=x;need(v['next_offset']==len(b),'native next')
    need(v['eof'] is True and v['size']==len(b)==n,'native complete stream')
    need(s['log_bytes'][c]=={'seen':n,'stored':n} and s['log_synced'][c] is True and s['log_errors'][c] is None and s['log_truncated'][c] is False,'native custody')
    put('complete-'+c+'-01.log',b)
put('actual-native-terminal-01.json',dto('status-03.json').encode())
macfiles=json.loads(dto('mac-receipts-read-01.json'))['files']
aliases=('actual-mac-report-01.json','actual-forwarded-stdout-01.log','actual-forwarded-stderr-01.log','actual-owned-agent-stderr-01.log')
for f,name in zip(macfiles,aliases,strict=True):
    b=f['text'].encode();need(identity(b)=={'bytes':f['size'],'sha256':f['sha256']},'Mac original identity');put(name,b)
mac=load(aliases[0])
need(mac['passed'] is True and mac['remote_returncode']==0 and mac['automatic_ssh_retries']==0 and mac['finished_utc'],'Mac completion')
need(all(mac[k] is True for k in ('owned_agent_reaped','owned_agent_directory_absent_after_context','owned_agent_socket_absent_after_context')),'Mac cleanup')
need(mac['remote_script_sha256']=='0eaf6dd96e6a69eba4ef382360febefd58e1f0370baf7cd79bb817ac2ce266ec','Mac source')
for f in macfiles[1:]:
    row=next(x for x in mac['log_files'] if x['file']==pathlib.Path(f['path']).name)
    need((row['bytes'],row['sha256'])==(f['size'],f['sha256']),'Mac stream pin')
p=load('actual-parent-01.json');summary=load('actual-summary-01.json')
required=('passed','observation_gate_passed','inputs_unchanged','source_inputs_unchanged','baseline_source_inputs_unchanged','correctness_stages_completed','baseline_enablement_verified','measurement_attribution_valid')
need(all(p[k] is True for k in required) and p['automatic_retries']==0 and p['finished_utc'] and not p.get('error') and not p.get('cleanup_errors') and p['rejection_reasons']==[],'observation parent gates')
names=['native-observation','native-audit','native-boundary','boundary-audit','cancel-recovery','recovery-audit','observation-summary']
need([x['name'] for x in p['stages']]==names,'original seven stages')
for stage in p['stages']:
    need(stage['returncode']==0 and all(stage[k] is True for k in ('passed','waited_and_reaped','owned_process_absent','owned_process_group_absent')),'original stage completion')
need(all(summary[k] is True for k in ('evidence_verified','correctness_verified','performance_gates_passed','observation_gate_passed')) and summary['rejection_reasons']==[],'summary gates')
need(p['thresholds']==summary['thresholds'],'original thresholds')
need(identity((P/'actual-summary-01.json').read_bytes())=={k:p['summary'][k] for k in ('bytes','sha256')},'parent summary pin')
inputs=json.loads((P.parent/'observation-inputs-operations-01/actual-campaign-inputs-01.json').read_bytes())
need(p['source_inputs_sha256']==inputs['source_inputs_sha256'],'actual source binding')
monitor=load('actual-monitor-01.json');audit=load('actual-monitor-audit-01.json');m=p['compiler_monitor']
for field,name in (('ledger','actual-monitor-01.json'),('independent_audit','actual-monitor-audit-01.json')):
    need(identity((P/name).read_bytes())=={k:m[field][k] for k in ('bytes','sha256')},'monitor original pin')
for row in m['sources'].values():
    b=(T/pathlib.Path(row['path']).name).read_bytes()
    need(identity(b)=={k:row[k] for k in ('bytes','sha256')},'monitor frozen source')
policy=json.loads((T/'compiler-monitor-policy-01.json').read_bytes())
need(m['limits']==policy['limits'],'monitor policy')
need(monitor['source_bindings']=={'schema':'hepta-r26-compiler-monitor-input-binding/v1','limits':policy['limits'],'sources':m['sources']},'monitor source bindings')
validator=T/'validate_compiler_monitor.py'
need(identity(validator.read_bytes())=={'bytes':7055,'sha256':'d2cd009adf1f35a394ffddcc8f8646cc0c1b856b78181ca321ea68f6468218b2'},'validator identity')
validation=runpy.run_path(str(validator),run_name='r29_monitor_review_only')['validate'](monitor,policy['limits'],m['guarded_body_start_monotonic_ns'],m['guarded_body_end_monotonic_ns'])
need(audit=={'schema':'hepta-r26-compiler-monitor-audit/v1','ledger':m['ledger'],'validator':m['sources']['validator'],'validation':validation,'monitor_sources_unchanged':True,'source_recheck_errors':[]} and validation['passed'] is True and m['passed'] is True and m['monitor_sources_unchanged'] is True,'full monitor recomputation')
result={'schema':'hepta-r29-original-observation-eligibility-review/v1','passed':True,'holder_job_id':s['job_id'],'native_streams':{'stdout':299,'stderr':0},'source_inputs_sha256':p['source_inputs_sha256'],'parent':identity((P/'actual-parent-01.json').read_bytes()),'summary':identity((P/'actual-summary-01.json').read_bytes()),'monitor':identity((P/'actual-monitor-01.json').read_bytes()),'monitor_recomputation':validation,'monitor_samples':monitor['sample_count'],'monitor_slots':monitor['required_slots_through_parent_end'],'monitor_missed':monitor['missed_scheduled_slots'],'monitor_cpu_seconds_per_wall_second':monitor['thread_cpu_seconds_per_wall_second'],'owned_parent_groups_and_Mac_agent_closed':True,'lifecycle_eligible':True,'lifecycle_or_saturation_pass_inferred':False,'full_inner_raw_reports_downloaded_and_reaudited_here':False}
put('observation-eligibility-review-02.json',(json.dumps(result,sort_keys=True,indent=2)+'\n').encode())
print(json.dumps(result,sort_keys=True))
