# R29 QC 实际输入与单文件接收

## 已完成的本地物化

`materialize_actual_qc_input_01.py` 对固定原件首跑退出 0，stdout 282 字节、stderr 0；原 argv 和双流在 `operations-01/`。它没有主机调用。冻结 QC exporter/helper 的定义仅用于纯输入和终态检查，未调用 exporter main。

实际输入为 `actual-01/actual-input-01.json`，2,484 字节，SHA256 `09be52af5ac89ec134c60e391cd91f0aa4a95912c1acb47aac412b6f6f6f0038`。资格 job `1a1ad4261c8-fc05-593b`、Rust job `1a1ad69c247-fc05-59c8`、Python job `1a1ad72111c-fc05-59eb` 均取原终态/原报告。Python 外层报告逐字绑定其内层 16,692 字节报告；18 个 id/argv/workflow_step 与原清单逐项一致。原单次完整 read 8077/0 与保存双流、原终态计数逐字相符。

Python 完整 CI gate 日志正文尚未在这里重新检查；固定 QC capture 和 full consumer 将读取并核验原 36 份 gate 日志的 bytes/SHA。这份本地物化收据没有宣称完整归档已经交付。

## 根的下一步

1. 对账并 create-only 写 `actual-01/python-terminal-write.request.json`，独立执行其 file-info 请求。它包含原 native DTO 的 731 字节，不是重编码 JSON。资格和 Rust 原终态已经由根写入；不重复写。
2. create-only 写 `actual-01/input-write.request.json` 并独立 file-info。
3. 在 OBS/lifecycle/saturation 测量全部结束或尚未开始的归档窗口，根才执行 `actual-01/native-export.request.json`；原 key、nice19、1800 秒和两冻结源码 SHA 保持原样。当前没有提交这个原任务。

## 完整接收策略

`single-file-receive-strategy-01.json` 固定接收原 report、transfer manifest 与一个 chunk 一个原请求。每个 chunk 最多 48,000 decoded 字节 / 64,000 base64 字节；`max_file_bytes=65536`、`max_response_bytes=131072`，只保留一个在途 RPC。chunk 数量和归档实际身份尚未发生，继续为空。

原 report/transfer manifest 若超过 65,536 字节，先保留实际 file_info 后使用已有 bounded binary-read 原页；不截断，也不合成 native DTO。完整组 manifest 已嵌在归档 `_export-manifest.json`，可省去重复的大 JSON 读取。

接收器必须依次验证原请求封套、EOF/version、encoded SHA、canonical base64、decoded SHA、offset 和完整 compressed SHA。然后按文件中的绝对路径 CLI 调用现成 full consumer；`--out` 是新 receipt 文件。该 consumer 与原 XZ helper 检查完整 XZ checksum/EOF、所有 regular tar members、源码和原日志绑定，不执行归档代码。原 capture request/start/status/read 和全部失败/只读重试仍要独立保管。

这套文件只记录已发生的资格与外部 CI。性能、生命周期、饱和、hosted Actions、版本采用均没有从它推定。早先 `r29-ci-readback-01` 的 pending snapshot 保持原样；本目录实际输入继承原件而不改写那个历史快照。
