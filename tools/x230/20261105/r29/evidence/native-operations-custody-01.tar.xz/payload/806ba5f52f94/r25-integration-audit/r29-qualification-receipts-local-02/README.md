# R29 fixed-six local receiver revision02

Only the local receive protocol changes from the frozen revision01 consumer.
Each original read_multiple_files request contains exactly one consecutive
manifest chunk, max_file_bytes=65536 and max_response_bytes=131072. Preserve the
original request/result envelope as read-batch-NNN.json. Do not synthesize a
multi-file response from separate replies; save errors as separate originals.

The producer 114a6bee remains unchanged and already staged. The original
manifest, encoded/decoded chunk SHA, contiguous offsets, whole archive size/SHA,
complete gzip CRC/EOF, seven-member archive verification, original file aliases,
source/helper identities, strong terminals, and downstream CI freezer requirement
are unchanged. Reversing the three declared strings reconstructs the complete
revision01 consumer byte for byte. All earlier files remain intact.

All actual binding values and future results remain unresolved. This directory
has not executed a consumer, test, host RPC or workload. Root reviews this narrow
revision before using actual single-file read pages. usage-02.json provides the
fixed CLI and unchanged original binding template.
