"""Retire exactly one verified R28 cache ELF duplicate; preserve the qualification original."""
import argparse
import base64
import datetime
import hashlib
import json
import os
from pathlib import Path
import stat
import sys
import time

ROOT = "/home/qian/hepta-runtime-optimization-20261105-r28"
NAME = "hepta_runtime-1b8b761b89392e3b"
FILES = (("cache", ROOT + "/target-build/debug/deps/" + NAME),
         ("retained", ROOT + "/qualification-01/test-binaries/" + NAME))
EXPECTED_BYTES = 542867656
EXPECTED_SHA256 = "6bdc7febf11b0f41d64ae2c36f78f690309e0345729b147a73b1b2662fe15360"
FIELDS = ("st_dev", "st_ino", "st_mode", "st_uid", "st_gid", "st_nlink",
          "st_size", "st_mtime_ns", "st_ctime_ns", "st_blocks")
DIR_FIELDS = ("st_dev", "st_ino", "st_mode", "st_uid", "st_gid")
OWNER = 1000
CACHE = ROOT + "/target-build"
CACHES = (("owned_r28_target", CACHE, False),)
DEAD = {"Z", "X", "x"}
MAX_PROCESSES = 16384
MAX_PROC_BYTES = 1048576
MAX_DURATION_NS = 120 * 10**9
START = 0
PAIR_JOB_ID = "1a1ad271c8e-fc05-58bb"
SOURCE = "/home/qian/hepta-runtime-optimization-20261105-r25/tools/retire_r28_duplicate_cache_elf_01.py"
INPUT = "/home/qian/hepta-runtime-optimization-20261105-r25/tools/r29-cache-duplicate-retirement-input-01.json"
OUT = "/home/qian/hepta-runtime-optimization-20261105-r25/cache-duplicate-retirement-01"
INPUT_IDENTITY = {'bytes': 40958, 'sha256': 'e9a9d4bbcad23eb5fdb908493a084d5e102b8a6b230982ab1f121dadba42a0e1'}

def need(value, message):
    if not value:
        raise RuntimeError(message)

def stamp(value, fields=FIELDS):
    return {key: getattr(value, key) for key in fields}

def disk():
    value = os.statvfs("/home/qian")
    return {"available_bytes": value.f_bavail * value.f_frsize,
            "unchanged_required_reserve_bytes": 3221225472}

def parent_fd(path, directories):
    current = Path("/")
    fd = os.open("/", os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW | os.O_CLOEXEC)
    directories.append((str(current), fd, stamp(os.fstat(fd), DIR_FIELDS)))
    for component in Path(path).parent.parts[1:]:
        fd = os.open(component, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW | os.O_CLOEXEC, dir_fd=fd)
        current = current / component
        value = os.fstat(fd)
        original = stamp(value, DIR_FIELDS)
        directories.append((str(current), fd, original))
        need(stat.S_ISDIR(value.st_mode) and value.st_uid in (0, 1000)
             and value.st_mode & 0o022 == 0
             and original == stamp(os.stat(current, follow_symlinks=False), DIR_FIELDS),
             "fixed directory ownership, mode or linked descriptor differs")
    need(os.fstat(fd).st_uid == 1000, "fixed task directory must be owned by UID 1000")
    return fd

def inspect(role, path, directories, retained):
    row = {"role": role, "path": path, "exists": False, "full_sha256_recomputed": False}
    try:
        directory = parent_fd(path, directories)
        before_path = os.stat(NAME, dir_fd=directory, follow_symlinks=False)
        row.update(exists=True, path_identity_before=stamp(before_path),
                   regular=stat.S_ISREG(before_path.st_mode),
                   allocated_bytes_from_st_blocks=before_path.st_blocks * 512)
        need(stat.S_ISREG(before_path.st_mode) and before_path.st_uid == 1000,
             "fixed ELF is not a regular file owned by UID 1000")
        need(before_path.st_size == EXPECTED_BYTES, "fixed ELF length differs; do not perform an unbounded read")
        fd = os.open(NAME, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK | os.O_CLOEXEC, dir_fd=directory)
        retained.append((role, path, directory, fd, row))
        before = stamp(os.fstat(fd))
        need(before == row["path_identity_before"], "fixed ELF changed while opening its descriptor")
        hasher, size, prefix = hashlib.sha256(), 0, b""
        while block := os.read(fd, min(1024 * 1024, EXPECTED_BYTES - size + 1)):
            if not prefix:
                prefix = block[:4]
            size += len(block)
            need(size <= EXPECTED_BYTES, "fixed ELF grew during full hash")
            hasher.update(block)
        row.update(bytes=size, sha256=hasher.hexdigest(), full_sha256_recomputed=True,
                   elf_magic=prefix == b"\x7fELF", descriptor_identity_before=before,
                   descriptor_identity_after=stamp(os.fstat(fd)),
                   path_identity_after=stamp(os.stat(NAME, dir_fd=directory, follow_symlinks=False)))
        row["descriptor_and_path_stable"] = before == row["descriptor_identity_after"] == row["path_identity_after"]
        row["matches_original_retained_sha_and_bytes"] = size == EXPECTED_BYTES and hasher.hexdigest() == EXPECTED_SHA256
        row["single_link"] = before["st_nlink"] == 1
        need(row["descriptor_and_path_stable"] and row["elf_magic"], "fixed ELF identity or magic differs")
    except FileNotFoundError as error:
        row["error"] = {"type": type(error).__name__, "reason": str(error)}
    except Exception as error:
        row["error"] = {"type": type(error).__name__, "reason": str(error)[:2000]}
    return row

def budget():
    need(time.monotonic_ns() - START <= MAX_DURATION_NS, 'bounded inventory duration exceeded')

def proc_bytes(fd, name, maximum):
    child = os.open(name, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK | os.O_CLOEXEC, dir_fd=fd)
    try:
        with os.fdopen(os.dup(child), 'rb') as stream:
            raw = stream.read(maximum + 1)
        need(len(raw) <= maximum, 'bounded process metadata exceeded')
        return raw
    finally:
        os.close(child)

def proc_stat(raw, expected_pid):
    closing = raw.rfind(b')')
    need(closing > 0, 'malformed bounded process stat')
    pid = int(raw[:raw.find(b'(')].strip())
    fields = raw[closing + 1:].split()
    need(pid == expected_pid and len(fields) >= 20, 'process stat identity differs')
    state = fields[0].decode('ascii')
    birth = int(fields[19])
    need(len(state) == 1 and birth > 0, 'invalid process state or birth')
    return pid, birth, state

def matches_cache(value, cache, cwd=None):
    # Values remain private to this predicate and are never emitted or hashed.
    value = value.removesuffix(' (deleted)')
    start = 0
    while True:
        pos = value.find(cache, start)
        if pos < 0:
            break
        end = pos + len(cache)
        before_ok = pos == 0 or value[pos - 1] in '=,: \t'
        after_ok = end == len(value) or value[end] == '/'
        if before_ok and after_ok:
            return True
        start = pos + 1
    if cwd and value and not value.startswith('-') and not os.path.isabs(value):
        candidate = os.path.normpath(os.path.join(cwd.removesuffix(' (deleted)'), value))
        return candidate == cache or candidate.startswith(cache + '/')
    return False

def scan_references():
    started = time.monotonic_ns()
    summary = {'scope': ['cwd', 'argv', 'CARGO_TARGET_DIR'], 'started_monotonic_ns': started,
               'processes_enumerated': 0, 'live_processes_examined': 0, 'dead_processes_skipped': 0,
               'vanished_before_live_observation': 0, 'processes_indeterminate': 0,
               'same_owner_processes_indeterminate': 0, 'foreign_owner_processes_indeterminate': 0,
               'unknown_owner_processes_indeterminate': 0,
               'channel_error_counts': {}, 'matched_live_processes': [],
               'unknown_process_examples_maximum_16': [],
               'same_owner_unknown_processes_maximum_32': [], 'complete': False,
               'raw_argv_or_environment_or_unrelated_cwd_emitted': False}
    proc_fd = os.open('/proc', os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW | os.O_CLOEXEC)
    try:
        pids = []
        with os.scandir(proc_fd) as scan:
            for entry in scan:
                if entry.name.isascii() and entry.name.isdecimal():
                    need(len(pids) < MAX_PROCESSES, 'bounded process inventory exceeded')
                    pids.append(int(entry.name))
        summary['processes_enumerated'] = len(pids)
        for pid in sorted(pids):
            budget()
            fd = None
            uid = None
            first = None
            comm = None
            errors = []
            matches = {name: [] for name, _, _ in CACHES}
            try:
                fd = os.open(str(pid), os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW | os.O_CLOEXEC,
                             dir_fd=proc_fd)
                proc_identity = os.fstat(fd)
                uid = proc_identity.st_uid
                first_raw = proc_bytes(fd, 'stat', 16384)
                first = proc_stat(first_raw, pid)
                if uid == OWNER:
                    comm_raw = first_raw[first_raw.find(b'(') + 1:first_raw.rfind(b')')]
                    need(0 < len(comm_raw) <= 256, 'bounded same-owner process comm exceeded')
                    comm = comm_raw.decode('utf-8', errors='backslashreplace')
                del first_raw
                if first[2] in DEAD:
                    summary['dead_processes_skipped'] += 1
                    continue
                summary['live_processes_examined'] += 1
                cwd = None
                try:
                    cwd = os.readlink('cwd', dir_fd=fd)
                    for name, cache, _ in CACHES:
                        if matches_cache(cwd, cache):
                            matches[name].append('cwd')
                except OSError as error:
                    errors.append(('cwd', error.errno))
                try:
                    argv = proc_bytes(fd, 'cmdline', MAX_PROC_BYTES).split(b'\0')
                    for value in argv:
                        token = os.fsdecode(value)
                        for name, cache, _ in CACHES:
                            if matches_cache(token, cache, cwd) and 'argv' not in matches[name]:
                                matches[name].append('argv')
                    del argv
                except OSError as error:
                    errors.append(('argv', error.errno))
                try:
                    environment = proc_bytes(fd, 'environ', MAX_PROC_BYTES)
                    for value in environment.split(b'\0'):
                        if value.startswith(b'CARGO_TARGET_DIR='):
                            target = os.fsdecode(value[len(b'CARGO_TARGET_DIR='):])
                            for name, cache, _ in CACHES:
                                if matches_cache(target, cache, cwd):
                                    matches[name].append('CARGO_TARGET_DIR')
                    del environment
                except OSError as error:
                    errors.append(('CARGO_TARGET_DIR', error.errno))
                second = proc_stat(proc_bytes(fd, 'stat', 16384), pid)
                after = os.fstat(fd)
                linked = os.stat(str(pid), dir_fd=proc_fd, follow_symlinks=False)
                need(first[:2] == second[:2]
                     and (proc_identity.st_dev, proc_identity.st_ino, uid)
                     == (after.st_dev, after.st_ino, after.st_uid)
                     == (linked.st_dev, linked.st_ino, linked.st_uid), 'process identity changed during inspection')
                states = [first[2], second[2]]
            except FileNotFoundError:
                if first is None:
                    summary['vanished_before_live_observation'] += 1
                    continue
                errors.append(('identity_after_live_observation', 2))
                states = [first[2]]
            except OSError as error:
                errors.append(('process_metadata', error.errno))
                states = [first[2]] if first else []
            except (RuntimeError, ValueError, UnicodeError):
                errors.append(('process_identity_or_bounds', None))
                states = [first[2]] if first else []
            finally:
                if fd is not None:
                    os.close(fd)
            selected = {name: channels for name, channels in matches.items() if channels}
            if selected:
                summary['matched_live_processes'].append({'pid': pid, 'uid': uid,
                    'birth_ticks': first[1] if first else None, 'observed_states': states,
                    'cache_reference_channels': selected, 'inspection_complete': not errors})
            if errors:
                summary['processes_indeterminate'] += 1
                category = ('unknown_owner_processes_indeterminate' if uid is None else
                            'same_owner_processes_indeterminate' if uid == OWNER else
                            'foreign_owner_processes_indeterminate')
                summary[category] += 1
                if uid == OWNER and len(summary['same_owner_unknown_processes_maximum_32']) < 32:
                    summary['same_owner_unknown_processes_maximum_32'].append({
                        'pid': pid, 'uid': uid, 'birth_ticks': first[1] if first else None,
                        'comm': comm, 'comm_source': 'first_pid_birth_bound_stat' if comm is not None else None,
                        'observed_states': states, 'inspection_complete': False,
                        'unreadable_or_raced_channels': [
                            {'channel': channel, 'errno': code,
                             'classification': ('permission_denied' if code in (1, 13)
                                                else 'vanished_or_missing' if code == 2
                                                else 'identity_or_bounds' if code is None else 'os_error')}
                            for channel, code in errors]})
                for channel, code in errors:
                    key = channel + ':' + str(code)
                    summary['channel_error_counts'][key] = summary['channel_error_counts'].get(key, 0) + 1
                if len(summary['unknown_process_examples_maximum_16']) < 16:
                    summary['unknown_process_examples_maximum_16'].append({'pid': pid, 'uid': uid,
                        'birth_ticks': first[1] if first else None, 'observed_states': states,
                        'unreadable_or_raced_channels': [channel for channel, _ in errors]})
        summary['same_owner_unknown_examples_truncated'] = (
            summary['same_owner_processes_indeterminate']
            > len(summary['same_owner_unknown_processes_maximum_32']))
        summary['complete'] = summary['processes_indeterminate'] == 0
        summary['all_same_owner_live_process_channels_inspected'] = (
            summary['same_owner_processes_indeterminate'] == 0
            and summary['unknown_owner_processes_indeterminate'] == 0)
        summary['finished_monotonic_ns'] = time.monotonic_ns()
        summary['single_scan_only_no_continuous_liveness_claim'] = True
        return summary
    finally:
        os.close(proc_fd)

def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()

def quiescence():
    deadline, samples = time.monotonic() + 300, []
    while True:
        active = []
        for path in Path('/proc').glob('[0-9]*/comm'):
            try:
                name = path.read_text().strip()
                if name in ('cargo', 'rustc', 'rust-lld', 'ld.lld'):
                    active.append({'pid': int(path.parent.name), 'name': name})
            except (FileNotFoundError, ProcessLookupError, PermissionError):
                pass
        samples.append({'utc': utc(), 'compiler_processes': active})
        if not active:
            return samples
        assert time.monotonic() < deadline, 'compiler quiescence unavailable; no cache copy or qualification started'
        if len(samples) == 1:
            print(json.dumps({'waiting_for_compiler_quiescence': active}), flush=True)
        time.sleep(2)

def encoded(value):
    return (json.dumps(value, sort_keys=True, indent=2, allow_nan=False) + "\n").encode()


def byte_identity(body):
    return {"bytes": len(body), "sha256": hashlib.sha256(body).hexdigest()}


def read_evidence(path, expected, directories):
    parent = parent_fd(path, directories)
    name = Path(path).name
    fd = os.open(name, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK | os.O_CLOEXEC, dir_fd=parent)
    try:
        before = stamp(os.fstat(fd))
        need(stat.S_ISREG(before["st_mode"]) and before["st_uid"] == OWNER
             and before["st_gid"] == OWNER and before["st_nlink"] == 1
             and before["st_mode"] & 0o022 == 0
             and before["st_size"] == expected["bytes"] <= 131072,
             "fixed source/input metadata differs")
        blocks, size = [], 0
        while block := os.read(fd, min(1048576, expected["bytes"] - size + 1)):
            size += len(block)
            need(size <= expected["bytes"], "fixed source/input grew")
            blocks.append(block)
        raw = b"".join(blocks)
        need(byte_identity(raw) == expected and before == stamp(os.fstat(fd))
             == stamp(os.stat(name, dir_fd=parent, follow_symlinks=False)),
             "fixed source/input body or descriptor differs")
        return raw, {"path": path, **expected, "identity": before}
    finally:
        os.close(fd)


def validate_originals(payload):
    need(payload["schema"] == "hepta-r29-fixed-cache-duplicate-retirement-input/v1",
         "fixed retirement input schema differs")
    bodies = {}
    for name, item in payload["originals"].items():
        body = base64.b64decode(item["base64"], validate=True)
        need(base64.b64encode(body).decode() == item["base64"]
             and byte_identity(body) == {key: item[key] for key in ("bytes", "sha256")},
             "original input bytes differ: " + name)
        bodies[name] = body
    terminal = json.loads(bodies["pair_terminal"])
    need(terminal["job_id"] == PAIR_JOB_ID and terminal["state"] == "succeeded"
         and terminal["exit_code"] == 0 and terminal["terminal_publication_protocol"] == 1
         and all(terminal[key] is True for key in
                 ("audit_recorded", "output_complete", "output_durable", "terminal_publication_confirmed"))
         and all(terminal[key] is False for key in ("automatic_retry", "timed_out", "cancelled")),
         "original pair terminal is not the fixed strong success")
    original = json.loads(bodies["pair_report"])
    readback = json.loads(bodies["pair_read"])
    need(readback["job_id"] == PAIR_JOB_ID and readback["audit_recorded"] is True,
         "original pair read belongs to another operation")
    for stream, raw in (("stdout", bodies["pair_report"]), ("stderr", b"")):
        row = readback[stream]
        need(bytes.fromhex(row["bytes_hex"]) == raw and row["text"] == raw.decode("utf-8")
             and row["offset"] == 0 and row["next_offset"] == row["size"] == len(raw)
             and row["eof"] is True
             and terminal["log_bytes"][stream] == {"seen": len(raw), "stored": len(raw)}
             and terminal["log_synced"][stream] is True
             and terminal["log_truncated"][stream] is False and terminal["log_errors"][stream] is None,
             "original pair stream is incomplete or differs from the actual report")
    need(original["schema"] == "hepta-r29-fixed-elf-pair-readonly/v1" and original["passed"] is True
         and original["exact_duplicate_with_two_single_link_inodes_observed"] is True
         and original["files_created_or_deleted"] == 0 and original["expected_bytes"] == EXPECTED_BYTES
         and original["expected_sha256"] == EXPECTED_SHA256
         and [(row["role"], row["path"]) for row in original["files"]] == list(FILES),
         "original exact pair is not a verified independent duplicate")
    window = json.loads(bodies["root_window"])
    need(window["schema"] == "hepta-r29-fixed-cache-elf-retirement-root-window/v1"
         and window["root_sole_native_executor"] is True and window["exclusive_root_window_held"] is True
         and window["other_agent_native_slots_granted"] is False
         and window["no_later_R28_cache_use_scheduled"] is True
         and window["known_original_qualification_and_Rust_CI_writers_strongly_terminal"] is True
         and window["cache_path"] == FILES[0][1] and window["protected_retained_copy"] == FILES[1][1]
         and window["original_pair_job_id"] == PAIR_JOB_ID
         and window["original_pair_stdout"] == byte_identity(bodies["pair_report"])
         and window["transport_chunks_retirement_selected"] is False
         and window["automatic_retries_or_cleanup_of_other_paths_authorized"] is False
         and window["all_machine_process_channels_readable_or_all_future_writers_absent_claimed"] is False
         and window["unchanged_qualification_reserve_bytes"] == 3221225472,
         "specific root coordination window differs")
    need(payload["coordination_reference"] == "R27-B96-CURRENT-NATIVE-RESERVATION-29.txt"
         and bodies["coordination_note"] and payload["pair_source_sha256"]
         == "92320639b9cd6d21e5bc6eb7012ead2397080e46bbfcbd33aea4163e7e540fad",
         "original entry or root reservation binding differs")
    return original


def verify_directories(directories):
    for path, fd, before in directories:
        need(before == stamp(os.fstat(fd), DIR_FIELDS)
             == stamp(os.stat(path, follow_symlinks=False), DIR_FIELDS), "held fixed parent identity changed")


def verify_pair_identities(held, prior, directories):
    verify_directories(directories)
    for role, path, parent, fd, row in held:
        expected = next(item for item in prior["files"] if item["role"] == role)["final_descriptor_identity"]
        need(stamp(os.fstat(fd)) == expected
             == stamp(os.stat(NAME, dir_fd=parent, follow_symlinks=False)),
             "fixed pair no longer names its original single-link descriptor: " + role)


def save_new(parent, name, value):
    need(name in ("intent.json", "result.json"), "only fixed new operation receipt names allowed")
    raw = encoded(value)
    need(len(raw) <= 131072, "bounded operation receipt exceeded")
    fd = os.open(name, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW | os.O_CLOEXEC,
                 0o600, dir_fd=parent)
    try:
        before = stamp(os.fstat(fd))
        need(before["st_uid"] == before["st_gid"] == OWNER and before["st_nlink"] == 1
             and before["st_mode"] == (stat.S_IFREG | 0o600) and before["st_size"] == 0,
             "fresh receipt has unsafe metadata")
        position = 0
        while position < len(raw):
            size = os.write(fd, raw[position:])
            need(size > 0, "zero write to operation receipt")
            position += size
        os.fsync(fd)
        after = stamp(os.fstat(fd))
        need(all(before[k] == after[k] for k in DIR_FIELDS + ("st_nlink",))
             and after["st_size"] == len(raw)
             and after == stamp(os.stat(name, dir_fd=parent, follow_symlinks=False)),
             "written receipt lost its original descriptor")
    finally:
        os.close(fd)
    os.fsync(parent)
    fd = os.open(name, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK | os.O_CLOEXEC, dir_fd=parent)
    try:
        need(stamp(os.fstat(fd)) == after, "fresh receipt readback names a different inode")
        blocks, size = [], 0
        while block := os.read(fd, len(raw) - size + 1):
            size += len(block)
            need(size <= len(raw), "receipt grew during readback")
            blocks.append(block)
        need(b"".join(blocks) == raw and after == stamp(os.fstat(fd))
             == stamp(os.stat(name, dir_fd=parent, follow_symlinks=False)),
             "receipt readback bytes or descriptor differs")
    finally:
        os.close(fd)
    return {"path": OUT + "/" + name, **byte_identity(raw), "identity": after}


def hash_retained_again(held, prior, directories):
    role, path, parent, fd, row = next(item for item in held if item[0] == "retained")
    expected = next(item for item in prior["files"] if item["role"] == role)["final_descriptor_identity"]
    os.lseek(fd, 0, os.SEEK_SET)
    hasher, size = hashlib.sha256(), 0
    while block := os.read(fd, min(1048576, EXPECTED_BYTES - size + 1)):
        size += len(block)
        need(size <= EXPECTED_BYTES, "retained original grew after retirement")
        hasher.update(block)
    need(size == EXPECTED_BYTES and hasher.hexdigest() == EXPECTED_SHA256
         and expected == stamp(os.fstat(fd)) == stamp(os.stat(NAME, dir_fd=parent, follow_symlinks=False)),
         "retained qualification original changed")
    verify_directories(directories)
    return {"path": path, "bytes": size, "sha256": hasher.hexdigest(), "identity": expected,
            "full_hash_recomputed_after_unlink": True}


def main():
    global START
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source-sha256", required=True)
    args = parser.parse_args()
    directories, held = [], []
    out_fd, result_pin = None, None
    report = {"schema": "hepta-r29-fixed-cache-duplicate-retirement/v1", "passed": False,
              "cache_path": FILES[0][1], "protected_retained_copy": FILES[1][1],
              "original_pair_job_id": PAIR_JOB_ID, "automatic_retries": 0,
              "started_monotonic_ns": time.monotonic_ns(), "unlink_calls_completed": 0,
              "recursive_removal": False, "existing_files_replaced_or_chmodded": False,
              "transport_chunks_removed": False, "R24_R26_caches_touched": False,
              "source_logs_reports_archives_or_other_ELFs_removed": False,
              "full_machine_reference_absence_claimed": False,
              "qualification_reserve_bytes_unchanged": 3221225472,
              "qualification_or_measurement_success_claimed": False,
              "partial_failure_evidence_preserved": True}
    try:
        need(sys.platform == "linux" and os.geteuid() == OWNER, "fixed Linux operator required")
        need(len(args.source_sha256) == 64 and all(c in "0123456789abcdef" for c in args.source_sha256),
             "frozen source hash is required")
        source_expected = {"bytes": os.stat(SOURCE, follow_symlinks=False).st_size,
                           "sha256": args.source_sha256}
        _, source_id = read_evidence(SOURCE, source_expected, directories)
        raw_input, input_id = read_evidence(INPUT, INPUT_IDENTITY, directories)
        payload = json.loads(raw_input)
        prior = validate_originals(payload)
        report.update(source=source_id, input=input_id,
                      root_window={k: payload["originals"]["root_window"][k] for k in ("bytes", "sha256")},
                      coordination_reference=payload["coordination_reference"],
                      original_inputs={key: {k: item[k] for k in ("bytes", "sha256")}
                                       for key, item in payload["originals"].items()})
        parent = parent_fd(OUT, directories)
        try:
            os.stat(Path(OUT).name, dir_fd=parent, follow_symlinks=False)
        except FileNotFoundError:
            pass
        else:
            raise RuntimeError("fresh retirement output already exists; automatic retry forbidden")
        os.umask(0o077)
        os.mkdir(Path(OUT).name, 0o700, dir_fd=parent)
        os.fsync(parent)
        out_fd = os.open(Path(OUT).name, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW | os.O_CLOEXEC,
                         dir_fd=parent)
        out_identity = stamp(os.fstat(out_fd), DIR_FIELDS)
        directories.append((OUT, out_fd, out_identity))
        need(out_identity["st_uid"] == out_identity["st_gid"] == OWNER
             and out_identity["st_mode"] == (stat.S_IFDIR | 0o700), "fresh receipt directory differs")
        report["disk_before"] = disk()
        report["initial_compiler_quiescence"] = quiescence()
        rows = [inspect(role, path, directories, held) for role, path in FILES]
        report["immediate_pair_reads"] = rows
        need(len(held) == 2 and all(row.get("full_sha256_recomputed") is True
             and row.get("matches_original_retained_sha_and_bytes") is True
             and row.get("descriptor_and_path_stable") is True and row.get("single_link") is True
             and row.get("elf_magic") is True and "error" not in row for row in rows),
             "both complete stable expected ELF bodies are required")
        verify_pair_identities(held, prior, directories)
        report["immediate_compiler_quiescence"] = quiescence()
        START = time.monotonic_ns()
        reference_scan = scan_references()
        report["immediate_cache_reference_scan"] = reference_scan
        need(reference_scan["matched_live_processes"] == [], "observed live reference to this task cache")
        # Unknown channels are retained. This does not assert global readability or FD/mmap absence.
        _, current_input = read_evidence(INPUT, INPUT_IDENTITY, directories)
        _, current_source = read_evidence(SOURCE, source_expected, directories)
        need(current_input == input_id and current_source == source_id, "entry inputs changed before intent")
        verify_pair_identities(held, prior, directories)
        report["intent"] = save_new(out_fd, "intent.json", {
            "schema": "hepta-r29-fixed-cache-duplicate-retirement-intent/v1", "operation": "unlink_one_exact_cache_copy",
            "cache_path": FILES[0][1], "protected_retained_copy": FILES[1][1], "source": source_id,
            "input": input_id, "original_pair_job_id": PAIR_JOB_ID,
            "cache_identity": rows[0]["descriptor_identity_before"],
            "retained_identity": rows[1]["descriptor_identity_before"],
            "bytes": EXPECTED_BYTES, "sha256": EXPECTED_SHA256,
            "root_window": report["root_window"], "coordination_reference": payload["coordination_reference"],
            "immediate_compiler_quiescence": report["immediate_compiler_quiescence"],
            "immediate_cache_reference_scan": reference_scan,
            "monotonic_ns": time.monotonic_ns(), "disk": disk(), "automatic_retries": 0})
        verify_pair_identities(held, prior, directories)
        cache = next(item for item in held if item[0] == "cache")
        os.unlink(NAME, dir_fd=cache[2])
        report["unlink_calls_completed"] = 1
        os.fsync(cache[2])
        unlinked = stamp(os.fstat(cache[3]))
        expected = prior["files"][0]["final_descriptor_identity"]
        need(unlinked["st_nlink"] == 0
             and all(unlinked[k] == expected[k] for k in DIR_FIELDS + ("st_size", "st_mtime_ns")),
             "unlink did not detach the held original cache inode")
        try:
            os.stat(NAME, dir_fd=cache[2], follow_symlinks=False)
        except FileNotFoundError:
            pass
        else:
            raise RuntimeError("cache path reappeared; preserve new path and stop")
        report["unlinked_cache_descriptor"] = unlinked
        os.close(cache[3])
        held.remove(cache)
        report["owned_cache_descriptor_closed"] = True
        report["retained_original_after"] = hash_retained_again(held, prior, directories)
        _, after_input = read_evidence(INPUT, INPUT_IDENTITY, directories)
        _, after_source = read_evidence(SOURCE, source_expected, directories)
        need(after_input == input_id and after_source == source_id, "original source/input changed after unlink")
        report["disk_after"] = disk()
        report["actual_available_bytes_delta_before_final_receipt"] = (
            report["disk_after"]["available_bytes"] - report["disk_before"]["available_bytes"])
        report["passed"] = True
    except Exception as error:
        report["passed"] = False
        report["error"] = {"type": type(error).__name__, "reason": str(error)[:4000]}
    finally:
        report["finished_monotonic_ns"] = time.monotonic_ns()
        if out_fd is not None:
            try:
                verify_directories(directories)
                report["disk_at_result_write"] = disk()
                result_pin = save_new(out_fd, "result.json", report)
            except Exception as error:
                report["passed"] = False
                report["result_receipt_error"] = repr(error)[:2000]
        for _, _, _, fd, _ in reversed(held):
            os.close(fd)
        for _, fd, _ in reversed(directories):
            os.close(fd)
        print(json.dumps({"passed": report["passed"], "unlink_calls_completed": report["unlink_calls_completed"],
                          "report": result_pin, "failure": report.get("error")}, sort_keys=True), flush=True)
    return 0 if report["passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
