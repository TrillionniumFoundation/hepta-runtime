def original_paged_operation(original, state='succeeded', exit_code=0):
    terminal_raw = original['native_terminal_text'].encode('utf-8')
    assert byte_identity(terminal_raw) == original['native_terminal_identity']
    check_terminal(terminal_raw, original['job_id'], state, exit_code)
    terminal = json.loads(terminal_raw)
    streams = {'stdout': bytearray(), 'stderr': bytearray()}
    pages = original['native_read_pages']
    assert isinstance(pages, list) and 1 <= len(pages) <= 16
    assert [page['identity'] for page in pages] == original['native_read_page_identities']
    for page in pages:
        raw = page['text'].encode('utf-8')
        assert byte_identity(raw) == page['identity']
        dto = json.loads(raw)
        assert dto['job_id'] == original['job_id'] and dto['audit_recorded'] is True
        for name in ('stdout', 'stderr'):
            row, prior = dto[name], streams[name]
            body = bytes.fromhex(row['bytes_hex'])
            assert row['offset'] == len(prior) and row['next_offset'] == len(prior) + len(body)
            assert row['size'] == terminal['log_bytes'][name]['stored']
            assert row['eof'] is (row['next_offset'] == row['size'])
            assert row['text'].encode('utf-8') == body
            prior.extend(body)
    for name in ('stdout', 'stderr'):
        assert len(streams[name]) == terminal['log_bytes'][name]['seen'] == terminal['log_bytes'][name]['stored']
    assert streams['stderr'] == b'' and byte_identity(streams['stdout']) == original['stdout_identity']
    return json.loads(streams['stdout'])


def actual_admission(payload):
    """Bind actual evidence; a readonly snapshot never supplies a writer lease."""
    supplied = payload['cache_admission']
    assert set(supplied) == {'original_failed_probe01', 'read_only_probe', 'local_QC_full_archive_verification',
                             'root_exclusive_writer_admission'}
    assert all(isinstance(value, dict) for value in supplied.values()), 'actual cache/QC/writer admission remains unbound'
    original = supplied['read_only_probe']
    assert isinstance(PROBE_SOURCE_SHA, str) and original['source_sha256'] == PROBE_SOURCE_SHA
    assert re.fullmatch(r'[0-9a-f]+-[0-9a-f]+-[0-9a-f]+', original['job_id'])
    observed = original_paged_operation(original)
    failed_original = supplied['original_failed_probe01']
    assert {k: failed_original[k] for k in FAILED_PROBE_SPEC} == FAILED_PROBE_SPEC
    failed_report = original_paged_operation(failed_original, 'failed', 1)
    assert failed_report['schema'] == 'hepta-r28-owned-target-readonly-review/v1'
    assert failed_report['passed'] is False and failed_report['read_only'] is True
    assert failed_report['error'] == {'type': 'RuntimeError', 'message': 'directory outside exact task parent'}
    assert failed_report['files_created_or_deleted'] == 0 and failed_report['rename_executed'] is False
    assert failed_report['cleanup_executed'] is False and failed_report['transfer_authorized_by_this_report'] is False
    assert 'space' not in failed_report
    assert observed['schema'] == 'hepta-r28-owned-target-readonly-review/v1' and observed['passed'] is True
    assert observed['read_only'] is True and observed['files_created_or_deleted'] == 0
    assert observed['rename_executed'] is False and observed['cleanup_executed'] is False
    assert observed['transfer_authorized_by_this_report'] is False
    assert observed['transfer_eligibility_established'] is False
    assert observed['cache_metadata_stable_across_two_passes'] is True
    assert observed['original_evidence_files_unchanged'] is True
    assert observed['protected_elf_original_export_metadata_unchanged'] is True
    assert observed['retained_elf_copies_before'] == observed['retained_elf_copies_after']
    assert len(observed['retained_elf_copies_before']) == 8
    assert observed['future_root']['exists'] is False and observed['future_target_metadata']['exists'] is False
    assert observed['future_root']['path'] == str(ROOT) and observed['future_target_metadata']['path'] == str(TARGET)
    assert observed['current_reference_observed'] is False
    assert len(observed['cache_passes']) == 2 and len(observed['process_reference_scans']) == 2
    for row in observed['cache_passes']:
        check_cache_inventory(row, CACHE)
    for row in observed['process_reference_scans']:
        assert row['matched_live_processes'] == []
    assert observed['cache_passes'][0]['metadata_sha256'] == observed['cache_passes'][1]['metadata_sha256']
    assert set(observed['bound_inputs']) == set(BOUND)
    for name, (path, size, sha) in BOUND.items():
        assert {k: observed['bound_inputs'][name][k] for k in ('path', 'bytes', 'sha256')} == {
            'path': path, 'bytes': size, 'sha256': sha}

    local = supplied['local_QC_full_archive_verification']
    raw = local['original_verification_text'].encode('utf-8')
    assert byte_identity(raw) == local['original_verification_identity']
    assert local['consumer_sha256'] == QC_CONSUMER_SHA
    qa = json.loads(raw)
    assert qa['schema'] == 'hepta-r28-qualification-ci-independent-verification/v1'
    assert qa['passed'] is True and qa['candidate_adopted'] is False
    assert qa['archive'] == QC_ARCHIVE
    assert qa['manifest'] == {'bytes': BOUND['qc_manifest'][1], 'sha256': BOUND['qc_manifest'][2]}
    assert qa['archive_validation']['verified'] is True and qa['archive_validation']['regular_members'] == 3830
    assert qa['original_capture']['job_id'] == QC_EXPORT_JOB
    assert qa['original_capture']['native_outcome']['state'] == 'succeeded'
    assert qa['original_capture']['native_outcome']['exit_code'] == 0
    assert qa['original_capture']['native_outcome']['native_logs_lossless_complete'] is True
    assert qa['original_export_report'] == {'bytes': BOUND['qc_export'][1], 'sha256': BOUND['qc_export'][2]}
    assert qa['original_negative_outcomes_preserved'] is True
    assert qa['archive_code_executed'] is False and qa['remote_operations'] == 0
    for name, original_operation in KNOWN_OPERATIONS.items():
        outcome = qa['original_outcomes'][name]
        assert outcome['native_outcome']['state'] == original_operation['state']
        assert outcome['native_outcome']['exit_code'] == original_operation['exit_code']
    writer = supplied['root_exclusive_writer_admission']
    assert writer['schema'] == 'hepta-r29-owned-cache-writer-admission/v1'
    assert writer['source_cache'] == CACHE and writer['destination_cache'] == str(TARGET)
    assert writer['selected_candidate_source_map_sha256'] == CANDIDATE_MAP_SHA
    assert writer['root_reviewed_readonly_probe_stdout'] == original['stdout_identity']
    assert writer['root_reviewed_downloaded_QC_verification'] == local['original_verification_identity']
    assert writer['exclusive_compilation_window_held'] is True
    assert writer['no_later_R28_cache_use_scheduled'] is True
    assert writer['original_native_raw_custody_retained'] is True
    assert writer['same_owner_unknowns_reviewed_without_claiming_all_channels_readable'] is True
    assert isinstance(writer['window_reference'], str) and 0 < len(writer['window_reference']) <= 256
    assert writer['fd_and_mmap_reference_channels_not_covered'] is True
    # This is the already-authorized root execution window, not proof about all
    # machine users. Concrete observed references and known unclosed writers
    # still block below. All original unknown/error categories remain recorded.
    return observed, qa, {'original_probe_job_id': original['job_id'],
        'original_probe_terminal': original['native_terminal_identity'],
        'original_probe_read_pages': [p['identity'] for p in original['native_read_pages']],
        'original_probe_stdout': original['stdout_identity'],
        'original_probe_reference_scans': observed['process_reference_scans'],
        'original_probe_reference_scan_limits': observed['reference_scan_limits'],
        'downloaded_QC_full_verification': local['original_verification_identity'],
        'downloaded_QC_archive': QC_ARCHIVE, 'root_writer_admission': writer,
        'original_failed_probe01': FAILED_PROBE_SPEC, 'original_failed_probe01_error': failed_report['error'],
        'original_failed_probe01_preserved_as_failed': True,
        'readonly_probe_does_not_authorize_transfer': True,
        'all_user_process_channels_readable_claimed': False}


def check_cache_inventory(row, path):
    assert row['path'] == path and row['realpath_matches_literal'] is True
    assert row['all_entries_traversed'] is True and row['all_regular_links_accounted_within_target'] is True
    assert row['external_or_unaccounted_hardlink_inodes'] == 0
    assert row['retained_qualification_elf_aliases'] == []
    counts = row['counts']
    assert counts['regular_files'] > 0
    assert all(counts[key] == 0 for key in ('symlinks', 'other_nonregular', 'other_device_entries', 'other_owner_entries'))
    assert row['anomaly_examples_maximum_32'] == []


def same_inventory(first, second, moved=False):
    keys = ('counts', 'all_entries_traversed', 'all_regular_links_accounted_within_target',
            'external_or_unaccounted_hardlink_inodes', 'retained_qualification_elf_aliases')
    assert all(first[key] == second[key] for key in keys), 'cache inventory changed'
    if not moved:
        assert first['path'] == second['path'] and first['root_identity'] == second['root_identity']
        assert first['metadata_sha256'] == second['metadata_sha256']
    else:
        assert first['path'] == CACHE and second['path'] == str(TARGET)
        assert first['descendants_metadata_sha256'] == second['descendants_metadata_sha256']
        # The directory inode itself acquires a new ctime on rename; every
        # descendant and every other root metadata field remains exact.
        fields = tuple(key for key in FIELDS if key != 'st_ctime_ns')
        assert all(first['root_identity'][key] == second['root_identity'][key] for key in fields)
        assert second['root_identity']['st_ctime_ns'] >= first['root_identity']['st_ctime_ns']


def owned_receipt(parent_fd, name):
    fd = os.open(name, os.O_RDWR | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW | os.O_CLOEXEC, 0o600, dir_fd=parent_fd)
    os.fsync(parent_fd)
    return fd, (os.fstat(fd).st_dev, os.fstat(fd).st_ino)


def update_receipt(parent_fd, name, opened, value):
    fd, identity = opened
    current, linked = os.fstat(fd), os.stat(name, dir_fd=parent_fd, follow_symlinks=False)
    assert stat.S_ISREG(current.st_mode) and current.st_uid == OWNER and current.st_nlink == 1
    assert (current.st_dev, current.st_ino) == identity == (linked.st_dev, linked.st_ino)
    raw, position = encoded(value), 0
    while position < len(raw):
        size = os.pwrite(fd, raw[position:], position)
        assert size > 0
        position += size
    os.ftruncate(fd, len(raw))
    os.fsync(fd)
    assert os.pread(fd, len(raw) + 1, 0) == raw
    assert stamp(os.fstat(fd)) == stamp(os.stat(name, dir_fd=parent_fd, follow_symlinks=False))


def absent(parent_fd, name):
    try:
        os.stat(name, dir_fd=parent_fd, follow_symlinks=False)
    except FileNotFoundError:
        return True
    return False


def reserve(parent_fd):
    disk = os.fstatvfs(parent_fd)
    available = disk.f_bavail * disk.f_frsize
    assert available >= RESERVE_BYTES, (available, RESERVE_BYTES)
    return {'available_bytes': available, 'available_blocks': disk.f_bavail,
            'filesystem_fragment_size': disk.f_frsize, 'available_inodes': disk.f_favail,
            'unchanged_required_headroom_bytes': RESERVE_BYTES, 'new_full_cache_copy_bytes': 0,
            'move_frees_bytes': False, 'future_build_growth_guaranteed_to_fit': False}


def verify_selected_source(payload, parent_map):
    raw = payload['transform_text'].encode('utf-8')
    assert hashlib.sha256(raw).hexdigest() == TRANSFORM_SHA
    transform = json.loads(raw)
    assert transform['schema'] == 'hepta-r29-shared-router-fixed-source-transform/v1'
    assert transform['production_selection'] == 'shared unfiltered ToolRouter'
    assert transform['optional_pidfd_selected'] is False
    assert [change['relative_path'] for change in transform['files']] == list(CHANGED_PATHS)
    expected, candidates = dict(parent_map), {}
    for change in transform['files']:
        relative = change['relative_path']
        assert change['before']['sha256'] == parent_map[relative]
        identity, original = read(OLD_SOURCE / relative, change['before']['sha256'], retain=True)
        assert identity['bytes'] == change['before']['bytes']
        candidate = original.decode('utf-8')
        for operation in change['operations']:
            assert operation['required_matches'] == candidate.count(operation['old']) == 1
            candidate = candidate.replace(operation['old'], operation['new'], 1)
        candidate_raw = candidate.encode('utf-8')
        assert byte_identity(candidate_raw) == change['after']
        candidates[relative] = candidate_raw
        expected[relative] = change['after']['sha256']
    assert payload['candidate_source_map'] == expected
    assert hashlib.sha256(encoded(expected)).hexdigest() == CANDIDATE_MAP_SHA
    assert payload['candidate_manifest'] == CANDIDATE_MANIFEST
    assert sorted(p for p in expected if expected[p] != parent_map[p]) == sorted(CHANGED_PATHS)
    assert payload['test_expectation'] == {'selected': 1689, 'passed': 1655, 'failed': 0, 'ignored': 34,
        'retries': 0, 'new_exact_tests': list(NEW_EXACT_TESTS)}
    return transform, expected, candidates


def main():
    global START
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--input-sha256', required=True)
    parser.add_argument('--launcher-sha256', required=True)
    args = parser.parse_args()
    assert sys.platform == 'linux' and os.geteuid() == OWNER
    launcher_identity, _ = read(Path(__file__).resolve(), args.launcher_sha256)
    input_identity, input_raw = read(INPUT, args.input_sha256, retain=True)
    payload = json.loads(input_raw)
    assert payload['schema'] == 'hepta-r29-shared-router-qualification-input/v1'
    assert payload['production_selection'] == 'shared unfiltered ToolRouter'
    assert payload['optional_pidfd_selected'] is False and payload['parent_candidate_adopted'] is False
    assert payload['accepted_production_source_remains_R24'] is True
    assert payload['unchanged_disk_reserve_bytes'] == RESERVE_BYTES
    assert payload['cache_strategy'] == 'one same-filesystem renameat2(RENAME_NOREPLACE); no cache copy or cleanup'
    observed, qa, admission = actual_admission(payload)
    # Resolve the required no-replace primitive before creating any fresh path.
    libc = ctypes.CDLL(None, use_errno=True)
    renameat2 = libc.renameat2
    renameat2.argtypes = (ctypes.c_int, ctypes.c_char_p, ctypes.c_int, ctypes.c_char_p, ctypes.c_uint)
    renameat2.restype = ctypes.c_int
    saved_inputs, documents = {}, {}
    for name, spec in BOUND.items():
        identity, value = read_bound(spec)
        assert identity == observed['bound_inputs'][name], 'original probe evidence identity changed: ' + name
        saved_inputs[identity['path']] = {k: identity[k] for k in ('path', 'bytes', 'sha256')}
        documents[name] = value

    def bind(path, digest):
        identity, raw = read(path, digest, retain=True)
        saved_inputs[str(path)] = identity
        return json.loads(raw)

    parent = documents['qualification']
    parent_map = documents['qualified_source_map']
    assert parent['qualified'] is True and parent['finished_utc']
    assert parent['source_tested'] == parent['source_after'] == parent_map == source_map(OLD_SOURCE)
    assert len(parent_map) == 221 and [s['name'] for s in parent['stages']] == STAGES
    assert all(s['returncode'] == 0 for s in parent['stages']) and parent['automatic_test_retries'] == 0
    prep, summary, ci, exported, manifest = (documents[name] for name in
        ('preparation', 'isolated_summary', 'rust_ci', 'qc_export', 'qc_manifest'))
    assert prep['passed'] is True and prep['candidate_qualified'] is True and prep['candidate_adopted'] is False
    assert prep['target'] == CACHE and prep['source'] == str(OLD_SOURCE)
    assert prep['cache_source'] == ROOT26 + '/target-build' and prep['shared_hardlinks_created'] is False
    assert [summary[k] for k in ('passed','failed','ignored','selected','retries')] == [1653,0,34,1687,0]
    assert summary['success'] is True and summary['filter'] == '' and not summary['enumeration_errors']
    assert ci['passed'] is True and ci['owned_children_closed'] is True and ci['source_inputs_unchanged'] is True
    assert ci['explicit_environment']['CARGO_TARGET_DIR'] == CACHE and len(ci['stages']) == 6
    assert all(s['returncode'] == 0 and s['waited_and_reaped'] is True and s['owned_process_absent'] is True
               and s['owned_process_group_absent'] is True for s in ci['stages'])
    for name, declared in KNOWN_OPERATIONS.items():
        pin = declared['terminal']
        identity, raw = read(pin['path'], pin['sha256'], retain=True)
        assert {k: identity[k] for k in ('path', 'bytes', 'sha256')} == pin
        check_terminal(raw, declared['job_id'], declared['state'], declared['exit_code'])
        saved_inputs[identity['path']] = identity
        report_pin = declared['report']
        value = bind(report_pin['path'], report_pin['sha256'])
        assert saved_inputs[report_pin['path']]['bytes'] == report_pin['bytes']
        if name == 'python_ci02':
            assert value['passed'] is True and value['finished_unix']
    assert exported['passed'] is True and exported['original_inputs_unchanged'] is True
    assert exported['archive']['verified'] is True and exported['omission_count'] == 8
    assert manifest['compiler_cache_body_outside_scope'] == CACHE
    assert exported['manifest']['sha256'] == BOUND['qc_manifest'][2]
    archive_pin = exported['archive']['identity']
    archive_identity, _ = read(archive_pin['source_path'], QC_ARCHIVE['sha256'])
    assert {k: archive_identity[k] for k in ('bytes', 'sha256')} == QC_ARCHIVE
    saved_inputs[archive_identity['path']] = archive_identity
    rejection = bind(PARENT / 'campaign-01/report.json', REJECTION_REPORT_SHA)
    rejection_summary = bind(PARENT / 'campaign-01/summary.json', REJECTION_SUMMARY_SHA)
    assert rejection['finished_utc'] and rejection['passed'] is True and rejection['observation_gate_passed'] is False
    assert rejection['measurement_attribution_valid'] is True and rejection['compiler_monitor']['passed'] is True
    assert rejection['inputs_unchanged'] is True and rejection['source_inputs_unchanged'] is True
    assert rejection['rejection_reasons'] == rejection_summary['rejection_reasons'] == ['C1 regression gate']
    assert rejection_summary['observation_gate_passed'] is False and rejection_summary['performance_gates_passed'] is False
    assert {name: {k: v[k] for k in ('path', 'sha256')} for name, v in rejection['binaries']['B'].items()} == parent['binaries']
    native_identity, native_raw = read(PARENT / 'observation-native-terminal-01.json', REJECTION_NATIVE_SHA, retain=True)
    check_terminal(native_raw, '1a1acbbcbec-fc05-56a0')
    saved_inputs[native_identity['path']] = native_identity
    publication = bind(ACCEPTED / 'final-publication-readback.json', PUBLICATION_SHA)
    assert publication['commit'] == 'baab4def80be7af015b2e7a594cb302f66c4130e'
    assert publication['verified'] is True and publication['candidate_adopted'] is True
    transform, expected, candidates = verify_selected_source(payload, parent_map)
    harness = parent['harness_after']
    assert len(harness) == 19 and parent['harness_before'] == harness_map(OLD_SOURCE) == harness
    initial_quiet = quiescence()
    START = time.monotonic_ns()
    retained = preserved_elf_metadata(manifest, parent, ci, summary)
    assert retained == observed['retained_elf_copies_after']
    before = inventory_tree(CACHE)
    check_cache_inventory(before, CACHE)
    same_inventory(observed['cache_passes'][-1], before)
    current_references = scan_references()
    assert not current_references['matched_live_processes'], 'observed live R28 cache reference'
    # Unknown channels are kept with their exact categories. They are not a
    # claim of readable fd/mmap or machine-wide liveness, nor an auto-cleanup.
    home = open_directory('/home/qian', fixed_space_parent=True)
    parent_chain = open_directory(str(PARENT))
    root_chain = None
    root_fd = cache_fd = None
    prep_opened = transfer_opened = None
    receipt = {'schema': 'hepta-r29-qualified-parent-preparation/v1', 'started_utc': utc(),
        'passed': False, 'candidate_qualified': False, 'candidate_adopted': False,
        'parent_source_qualified': True, 'parent_candidate_adopted': False,
        'parent_observation_rejection_preserved': True, 'automatic_test_retries': 0,
        'production_services_modified': False, 'shared_hardlinks_created': False,
        'input': input_identity, 'launcher': launcher_identity,
        'selected_proposal': 'shared unfiltered ToolRouter', 'optional_pidfd_selected': False,
        'cache_source': CACHE, 'cache_source_source_qualified': True, 'cache_reused': False,
        'cache_copy_executed': False, 'cache_cleanup_executed': False,
        'unchanged_disk_reserve_bytes': RESERVE_BYTES, 'new_full_cache_copy_bytes': 0,
        'admission': admission, 'compiler_quiescence': initial_quiet,
        'cache_reference_scan_before_source': current_references,
        'retained_parent_ELFs_before': retained}
    transfer = {'schema': 'hepta-r29-owned-cache-transfer/v1', 'passed': False,
        'source_cache': CACHE, 'destination_cache': str(TARGET), 'copy_executed': False,
        'cleanup_executed': False, 'rename_attempted': False, 'rename_returned_success': False,
        'automatic_retry': False, 'automatic_rollback': False,
        'original_cache_probe': admission['original_probe_stdout'], 'metadata_before': before,
        'root_writer_admission': admission['root_writer_admission'],
        'retained_parent_ELFs_before': retained, 'started_utc': utc()}
    result_code = 1
    try:
        assert absent(home[-1]['fd'], ROOT.name), 'fresh R29 root already exists; reconcile original operation'
        assert before['root_identity']['st_dev'] == os.fstat(home[-1]['fd']).st_dev
        os.mkdir(ROOT.name, 0o700, dir_fd=home[-1]['fd'])
        os.fsync(home[-1]['fd'])
        root_chain = open_directory(str(ROOT))
        root_fd = root_chain[-1]['fd']
        assert stat.S_IMODE(os.fstat(root_fd).st_mode) == 0o700
        prep_opened = owned_receipt(root_fd, 'preparation-01.json')
        transfer_opened = owned_receipt(root_fd, 'target-transfer-01.json')
        update_receipt(root_fd, 'preparation-01.json', prep_opened, receipt)
        update_receipt(root_fd, 'target-transfer-01.json', transfer_opened, transfer)
        input_opened = owned_receipt(root_fd, 'qualification-input-01.json')
        try:
            update_receipt(root_fd, 'qualification-input-01.json', input_opened, payload)
            assert read(ROOT / 'qualification-input-01.json')[0]['sha256'] == args.input_sha256
        finally:
            os.close(input_opened[0])
        preparation_started = time.monotonic()
        shutil.copytree(OLD_SOURCE, SOURCE)
        for relative, candidate_raw in candidates.items():
            (SOURCE / relative).write_bytes(candidate_raw)
        assert source_map(SOURCE) == expected and source_map(OLD_SOURCE) == parent_map
        assert harness_map(SOURCE) == harness_map(OLD_SOURCE) == harness
        check_chain(home)
        check_chain(parent_chain)
        check_chain(root_chain)
        receipt['disk_after_fresh_source_before_move'] = reserve(root_fd)
        receipt['compiler_quiescence_immediately_before_move'] = quiescence()
        START = time.monotonic_ns()
        immediate = inventory_tree(CACHE)
        same_inventory(before, immediate)
        immediate_references = scan_references()
        transfer['immediate_reference_scan'] = immediate_references
        assert not immediate_references['matched_live_processes'], 'live cache reference appeared before move'
        assert preserved_elf_metadata(manifest, parent, ci, summary) == retained
        transfer['immediate_metadata_before'] = immediate
        transfer['disk_before_move'] = reserve(root_fd)
        cache_fd = os.open('target-build', os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW | os.O_CLOEXEC,
                           dir_fd=parent_chain[-1]['fd'])
        assert metadata_stamp(os.fstat(cache_fd)) == immediate['root_identity']
        assert metadata_stamp(os.stat('target-build', dir_fd=parent_chain[-1]['fd'], follow_symlinks=False)) == immediate['root_identity']
        assert absent(root_fd, 'target-build') and absent(root_fd, 'qualification-01')
        check_chain(parent_chain)
        check_chain(root_chain)
        transfer['rename_attempted'] = True
        transfer['rename_started_utc'] = utc()
        update_receipt(root_fd, 'target-transfer-01.json', transfer_opened, transfer)
        move_started = time.monotonic()
        # Exactly one syscall. EEXIST/EXDEV/unsupported errors fail with no
        # fallback to replace/copy. Never retry or reverse an unknown outcome.
        rc = renameat2(parent_chain[-1]['fd'], b'target-build', root_fd, b'target-build', 1)
        if rc != 0:
            error_number = ctypes.get_errno()
            transfer['rename_errno'] = error_number
            raise OSError(error_number, os.strerror(error_number))
        transfer['rename_returned_success'] = True
        transfer['rename_seconds'] = time.monotonic() - move_started
        os.fsync(parent_chain[-1]['fd'])
        os.fsync(root_fd)
        check_chain(home)
        check_chain(parent_chain)
        check_chain(root_chain)
        assert absent(parent_chain[-1]['fd'], 'target-build')
        linked = os.stat('target-build', dir_fd=root_fd, follow_symlinks=False)
        assert metadata_stamp(linked) == metadata_stamp(os.fstat(cache_fd))
        assert (linked.st_dev, linked.st_ino) == (immediate['root_identity']['st_dev'], immediate['root_identity']['st_ino'])
        START = time.monotonic_ns()
        after = inventory_tree(str(TARGET))
        check_cache_inventory(after, str(TARGET))
        same_inventory(immediate, after, moved=True)
        assert preserved_elf_metadata(manifest, parent, ci, summary) == retained
        check_chain(home)
        check_chain(parent_chain)
        check_chain(root_chain)
        transfer.update(passed=True, metadata_after=after,
            old_path_absent=True, destination_is_original_inode=True,
            descendants_metadata_unchanged=True, retained_parent_ELFs_after=retained,
            root_ctime_before=immediate['root_identity']['st_ctime_ns'], root_ctime_after=after['root_identity']['st_ctime_ns'])
        transfer['finished_utc'] = utc()
        update_receipt(root_fd, 'target-transfer-01.json', transfer_opened, transfer)
        receipt.update(source=str(SOURCE), target=str(TARGET), qualification_output=str(OUTPUT),
            source_before=parent_map, candidate_compilation_inputs=expected, harness_before=harness,
            cache_reused=True, cache_file_count=before['counts']['regular_files'],
            cache_bytes=before['counts']['regular_logical_bytes'], cache_moved_by_single_no_replace_rename=True,
            cache_transfer_receipt=read(ROOT / 'target-transfer-01.json')[0],
            cache_transfer=transfer,
            preparation_seconds=time.monotonic()-preparation_started,
            source_changes=[{'path': change['relative_path'], 'before': change['before'], 'after': change['after']}
                            for change in transform['files']])
        # Do not borrow space from the preserved R24/R26/R28 evidence. A move
        # avoids a second full cache allocation, but does not create free space.
        receipt['disk_immediately_before_compiler'] = reserve(root_fd)
        update_receipt(root_fd, 'preparation-01.json', prep_opened, receipt)
        print(json.dumps({'phase': 'prepared', 'source_changes': list(CHANGED_PATHS), 'automatic_test_retries': 0}), flush=True)
        argv = ['/usr/bin/python3', '-B', str(SOURCE / 'tools/x230/20261028/qualify.py'),
            '--source', str(SOURCE), '--output', str(OUTPUT), '--target', str(TARGET),
            '--cargo-home', '/home/qian/hepta-runtime-optimization-20261023/cargo-home-a32-a33-r02',
            '--jobs', '2', '--stage-timeout', '3600']
        receipt['qualification_argv'] = argv
        result = subprocess.run(argv, cwd=SOURCE, timeout=10800)
        receipt['qualification_returncode'] = result.returncode
        for path, identity in saved_inputs.items():
            assert read(path)[0] == identity, 'bound parent evidence changed: ' + path
        assert source_map(OLD_SOURCE) == parent_map and harness_map(OLD_SOURCE) == harness_map(SOURCE) == harness
        read(INPUT, args.input_sha256)
        read(Path(__file__).resolve(), args.launcher_sha256)
        START = time.monotonic_ns()
        assert preserved_elf_metadata(manifest, parent, ci, summary) == retained
        receipt['retained_parent_ELFs_after_qualification'] = retained
        receipt['parent_inputs_unchanged'] = True
        qualified_identity, qualified_raw = read(OUTPUT / 'report.json', retain=True)
        qualified = json.loads(qualified_raw)
        receipt['qualification_report'] = qualified_identity
        receipt['candidate_qualified'] = qualified['qualified'] is True
        if result.returncode != 0:
            assert qualified['qualified'] is False
            result_code = result.returncode
        else:
            assert qualified['qualified'] is True and qualified['finished_utc']
            assert qualified['source_tested'] == qualified['source_after'] == source_map(SOURCE)
            assert all(s['returncode'] == 0 for s in qualified['stages'])
            assert [s['name'] for s in qualified['stages']] == STAGES
            assert qualified['automatic_test_retries'] == 0
            assert all(qualified['source_after'][p] == expected[p] for p in expected if p not in CHANGED_PATHS)
            test_summary = json.loads(read(OUTPUT / 'isolated-tests/summary.json', retain=True)[1])
            audit = json.loads(read(OUTPUT / 'isolated-tests.audit.json', retain=True)[1])
            assert [test_summary[k] for k in ('passed','failed','ignored','selected','retries')] == [1655,0,34,1689,0]
            assert test_summary['success'] is True and test_summary['filter'] == '' and not test_summary['enumeration_errors']
            assert audit['success'] is True and audit['errors'] == [] and audit['expected_filter'] == ''
            assert [audit[k] for k in ('passed','failed','ignored','selected','executed')] == [1655,0,34,1689,1655]
            ledger_identity, ledger_raw = read(OUTPUT / 'isolated-tests/tests.jsonl', audit['input_sha256']['tests.jsonl'], retain=True)
            rows = [json.loads(line) for line in ledger_raw.splitlines()]
            assert len(rows) == 1689
            new_cases = []
            for name in NEW_EXACT_TESTS:
                matched = [row for row in rows if row['name'] == name]
                assert len(matched) == 1
                row = matched[0]
                assert row['status'] == 'passed' and row['executed'] is True and row['attempt'] == 1
                assert row['exit_code'] == 0 and row['timed_out'] is False
                new_cases.append(row)
            receipt.update(passed=True, tests=test_summary, source_tested=qualified['source_after'],
                           new_exact_tests=new_cases, original_test_ledger=ledger_identity,
                           formatter_changed_paths=[p for p in expected if qualified['source_after'][p] != expected[p]])
            result_code = 0
    except Exception as error:
        receipt['error'] = f'{type(error).__name__}: {error}'
        receipt['error_trace'] = traceback.format_exc()
        if transfer['passed'] is not True:
            transfer.setdefault('error', receipt['error'])
            transfer.setdefault('finished_utc', utc())
    finally:
        receipt['finished_utc'] = utc()
        receipt['bound_parent_inputs'] = saved_inputs
        try:
            if transfer_opened is not None:
                update_receipt(root_fd, 'target-transfer-01.json', transfer_opened, transfer)
            if prep_opened is not None:
                update_receipt(root_fd, 'preparation-01.json', prep_opened, receipt)
            print(json.dumps({'preparation_and_qualification_passed': receipt['passed'],
                              'candidate_qualified': receipt['candidate_qualified'], 'error': receipt.get('error')}), flush=True)
        finally:
            for opened in (prep_opened, transfer_opened):
                if opened is not None:
                    os.close(opened[0])
            if cache_fd is not None:
                os.close(cache_fd)
            if root_chain is not None:
                close_chain(root_chain)
            close_chain(parent_chain)
            close_chain(home)
    return result_code


if __name__ == '__main__':
    raise SystemExit(main())
