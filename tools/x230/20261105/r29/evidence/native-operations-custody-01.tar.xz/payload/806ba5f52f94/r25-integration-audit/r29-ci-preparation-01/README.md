# R29 CI preparation: unbound local templates

These files prepare the two original Rust workflow commands and all 18 original
Python workflow commands for a future, fully qualified R29 source. No CI tool,
freezer, materializer, installer, or launcher main has been run. The local
`prepare_interfaces_01.py` only constructs the source files in this directory.

The runtime candidate is the frozen two-file shared unfiltered ToolRouter change
over the actual qualified R28 source. Accepted production remains R24. The R28
observation rejection is retained by the shared preparation validator and is not
converted into a R29 result.

## Exact prerequisites remain unresolved

The single canonical preparation function is copied byte for byte into the Rust
materializer and six-receipt freezer. Python uses that exact freezer as its
qualification verifier. The function's `expected_launcher` and `expected_input`
are both `None`; it rejects execution until a reviewed final R29 entry and its
actual cache-admission input have been bound. The seven actual qualification
fields in the Rust materializer are also unbound. The original R29 qualification
job, formatter output map, test result, release binaries, and native terminal do
not yet exist as successful inputs to these tools.

The actual cache probe02 had 3,196,145,664 bytes available, 25,079,808 bytes below
the unchanged 3 GiB reserve. Its successful read-only job does not authorize a
move or compiler. Root controls the original execution window and any separately
reviewed recovery of reproducible transfer duplicates. Three original reserve
checks remain in the qualification entry. No cache or source is changed here.

When the final preparation function is available, retain this unbound snapshot
and derive a fresh final source set from the same originals with that one exact
function. Recompute the materializer, freezer, generator and Python verifier pins
before producing an actual package. The future final package must be reviewed
against its six actual original receipt bodies.

## Original qualification and CI contracts

The qualification still requires all eight original stages, all 221 compiler
inputs, all 19 qualification harness files, an empty test filter, and zero
retries. Two new Linux tests change the expected full inventory to **1,689
selected, 34 ignored, 1,655 passed, zero failed**. These are required future
counts, not a report of execution. The independent audit must agree.

Rust retains these exact workflow commands:

```text
cargo check --locked --all-targets --all-features
cargo nextest run --locked --all-targets --all-features --test-threads 1 --retries 0 --no-fail-fast
```

The separate read-only inventory remains
`cargo nextest list --locked --all-targets --all-features --message-format json`.
Its complete case set is compared with actual qualification and nextest output.
The original nextest 0.9.137 auditor is byte-identical. The original environment,
1800-second check, 3600-second nextest, owned process-group cleanup, full logs,
and source/binary checks before and after are retained. The original native
request remains 7200 seconds, nice 5, CPU 200%, memory 5 GiB.

Python retains the exact frozen 85 dependency inputs, all 18 workflow argv, the
original discovery sets, and the original runner `de69c48b…`. It runs against the
already installed R25 CI input package, and independently binds that package to
the immutable published dependency reference `06530d71…` and the actual new R29
source. The known published descendant `1c23ba9a…` has the same seven dependency
subtrees. The historical fields named `candidate_git_parent` continue to identify
that immutable input reference; they do not assert the current branch HEAD or a
future R29 commit parent. No hosted CI result is inferred from this proof.

Python derives from the **actual successful R28 recovery launcher** `7c61fbcb…`.
Its generic input guards remain strict. Only these two qualified-source paths
may have exact mode `0100660`, and only with UID/GID 1000, one link, the exact
length below, the corresponding actual qualified-map hash, and matching bytes:

| Relative source path | Bytes | SHA-256 |
| --- | ---: | --- |
| `src/mcp/runtime/jobs_cancel_io_tests.rs` | 17,145 | `b9553137fe32d873536252c4371bcb57dfceb4e8fac988937b7c552a871f889a` |
| `src/mcp/runtime/jobs_cancel_read_tests.rs` | 14,542 | `ff92e72b71a8afc23edda7e686c66f87c13ac76dfa3b5c8a8b8e124383b3bf87` |

The qualified-source reader checks current R29 descriptors and bytes before and
after the original Python run. JSON, tools, other source files and arbitrary
group-writable files receive no exception. No chmod is performed. The preflight
recovery proof that belonged specifically to R28 failed attempt01 is removed;
R29 uses a fresh attempt01. The old R28 failure and its successful recovery remain
unchanged in their original evidence directories.

## Fixed remote paths and actual local receipts

All new remote products are under
`/home/qian/hepta-runtime-optimization-20261105-r29`:

| Purpose | Relative path |
| --- | --- |
| Qualified source and private target | `source`, `target-build` |
| Preparation and qualification | `preparation-01.json`, `qualification-01/` |
| Exact original native terminal text | `qualification-terminal-status-01.json` |
| Rust installed tools, plan, output | `rust-ci-tools-01/`, `rust-ci-plan-01.json`, `rust-ci-01/` |
| Rust data-only installation receipt | `rust-ci-tools-install-01.json` |
| Python installed tools, outer logs, output | `python-ci-tools-01/`, `python-ci-launch-01/`, `python-ci-01/` |
| Python data-only installation receipt | `python-ci-tools-install-01.json` |

The six local receipt names are `preparation-01.json`,
`qualification-native-terminal-01.json`, `qualification-report-01.json`,
`qualified-source-map-01.json`, `isolated-tests-summary-01.json`, and
`isolated-tests-audit-01.json`. The preparation includes the original target
transfer receipt binding, so no seventh qualification receipt is invented.

After the canonical function has been finalized and those six actual original
receipts have passed, the existing CLIs remain:

```text
python3 -I -B <final>/rust/freeze_rust_ci_01.py --receipts <absolute-actual-receipts> --original-job-id <actual-R29-job> --out <fresh-frozen-package>
python3 -I -B <final>/rust/entry-01/generate_ci_entry_01.py --frozen-package <absolute-frozen-package> --out <fresh-rust-delivery>
python3 -I -B <final>/python/generate_python_ci_entry_01.py --receipts <absolute-actual-receipts> --original-job-id <actual-R29-job> --out <fresh-python-delivery>
```

Each generator creates a fixed five-file data-only installation package and one
original CI request. Root reviews the actual package, installs once, verifies
the original installation terminal/receipt, and executes only outside measurement
windows. An uncertain dispatch is reconciled with the exact original request
and key; a new key must not replay the workload. This preparation itself has no
remote request that is safe to dispatch.

## Review evidence

`derivation-origins-01.json` pins every source origin.
`static-reuse-01.json` records byte/AST comparisons, exact command and reader
invariants, current unresolved fields, and syntax parsing. It does not execute
any copied function or use synthetic success receipts.
`r28-to-r29-source.diff` shows the narrow derivation, including the canonical
preparation change. `review-ready-01.json` pins the complete prepared source set.
