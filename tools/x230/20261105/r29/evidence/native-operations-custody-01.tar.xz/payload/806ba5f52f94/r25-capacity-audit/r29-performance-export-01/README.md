# R29 performance originals: fixed capture and independent consumer

This package derives from the actual, completely verified R28 performance exporter/consumer. It preserves the original stable XZ archive helper and the pure compiler-monitor validator byte for byte. It does not execute a benchmark, replay an auditor, modify the runtime or decide adoption.

The R29 original observation is native Mac-holder job `1a1ad77dfe5-fc05-59f9`. Its completed original report and summary passed. The original lifecycle holder `1a1ad8309eb-fc05-5a1b` has started; its outcome must come from that original job. The input example is deliberately **not dispatchable** until the original lifecycle has a terminal outcome and its actual report identity, or an explicit report-absence observation, has been supplied. No future lifecycle or saturation success is implied.

## Fixed scope

All paths below are under `/home/qian/hepta-runtime-optimization-20261105-r29`, except the explicitly named R16 recovery directory.

| Namespace | Complete original directory |
| --- | --- |
| observation | `campaign-01` |
| recovery | `/home/qian/hepta-runtime-optimization-20261104-r16/r29-cancel-recovery-01` |
| lifecycle | `lifecycle-campaign-01` |
| lifecycle-abba | `lifecycle-abba-01` |
| saturation | `cancel-saturation-01` |
| lifecycle-tool-tests | `lifecycle-tool-tests-01` |

Every existing regular file in those six directories is captured, including nested round reports, phase records, original controller stdout/stderr, raw resource samples, all stage logs, checkpoints, original errors, source/input snapshots, original summary/gates and both complete monitor ledgers/audits. A missing fixed directory is recorded as an actual absence and checked again after capture. A present partial directory is included in full. A declared unsubmitted lifecycle must have no lifecycle execution output or native terminal; an already materialized lifecycle input may still exist and is retained.

The original 50 installed acceptance assets are pinned to the actual installation receipt. The three complete installed tool directories, the actual boundary-tool directory when created, all root input/plan/manifest/install receipts, original R16 measurement/boundary tools, installer source and installation input are included. Four immutable qualification references bind the actual R29 preparation, source map, report and original native terminal. Full qualification/CI source and test logs belong to the separate QC package; this performance package does not claim to replace it.

The installed observation parent contains the exact final canonical preparation validator `2892bd35bb5f1b5a90919e74453a18d5ae6ad738d08fcc780f3c0ac01c67c923`. The whole parent and its installation are bound. The canonical function is not reexecuted by this performance capture; its actual qualification is independently bound by the four original identities and the required QC companion.

ELF bodies and the previously excluded private transport/configuration bodies are classified before text-marker scanning; complete observed identities and omission reasons remain in the manifest. No source, report, log, manifest, archive, binary, workload, socket or service is changed or removed. Only a fresh `ROOT29/performance-evidence-01` capture tree is written.

## Original outcomes and producer bindings

Each of `observation01` and `lifecycle01` retains its actual original native terminal and original parent-report bytes. Native `succeeded0` is insufficient to establish a performance pass. The independent consumer reconstructs the original projection and classification from the archived bytes and the reviewed local source, not by trusting the export summary.

The positive observation branch requires its exact seven stages, complete bound streams and output records, final source/input preservation, the qualified 221-file candidate map, original A/B binary identities, summary-to-evidence identities, unchanged frozen thresholds, correct summary/parent gate agreement and independently validated complete compiler-monitor evidence. Original observation gate false remains a rejection. Incomplete, malformed or negative original reports remain retained negative evidence and cannot acquire `finished` or positive fields through the exporter.

The lifecycle branch retains the original four-stage ordering: 14 native harness tests, normal lifecycle ABBA, cancellation saturation, independent saturation audit. Complete positive evidence additionally binds the original accepted observation, all A/B artifacts and source snapshots, the normal ABBA report/index/tool manifest, four original raw round reports and four independent audits, all eleven phase records per round, normal descriptive/gate receipts and the original saturation report/independent proof. It does not replay those tests or audit programs.

When normal lifecycle fails, the original entered-stage list and the actual complete directory inventories are retained. The constant planned list is never treated as execution evidence. No saturation success is inferred from an absent directory or a missing `saturation_analysis` field. Negative or inconsistent original producer bindings are recorded explicitly and suppress positive classification while the complete original bytes remain available.

Both monitors are validated separately with the unchanged source-bound pure validator and unchanged policy. A valid capture can preserve invalid measurement evidence. Monitor claims are limited to what the actual 1 Hz samples observed; no continuous compiler absence is asserted.

`candidate_adopted` remains false in the capture and QA output even if all original workload gates pass. The final classification may state that original observation, lifecycle and saturation passed, while explicitly requiring the complete QC, native-custody and Mac-holder companions before publication/adoption.

## Paths and one original capture

Stage the frozen exporter at:

`/home/qian/hepta-runtime-optimization-20261105-r25/tools/export_r29_performance_01.py`

It is larger than 65,536 bytes. The two prepared sequential `binary_upload` chunks use one upload ID, offsets 0 and 65,535, then a create-only commit with the whole size/SHA and a separate `file_info`. Do not replace this with an oversized single write. No upload has been performed by this package.

The existing shared archive helper must be the exact reviewed 14,081-byte source at:

`/home/qian/hepta-runtime-optimization-20261105-r25/tools/r29_qualification_ci_stable_xz_01.py`

The common helper is owned by the QC staging flow. Verify/reuse it; do not blindly create it a second time.

After both original holders have completed and their owned cleanup has been assessed, root late-binds `actual-export-input-01.example.json`. Replace the unresolved original lifecycle terminal/report pins with actual complete original-byte identities, preserve any actual negative fields, and set `actual_outcomes_supplied` true only then. The remote input path is:

`/home/qian/hepta-runtime-optimization-20261105-r25/tools/r29-performance-export-input-01.json`

An executed original with no report must use `report: null` plus the actual reason; the capture must independently observe that fixed report path absent. A partial report that does exist must have its actual identity, not be declared absent. An unexecuted declaration is valid only after an actual decision not to submit that holder, with all original job/result fields null and a reason; it is not a way to snapshot an active workload as unexecuted.

`entry-templates-01.json` contains the exact original exporter argv and resources. Its input SHA remains null until the actual input is frozen, so it is not an executable request. The stable capture key is `hepta-r29-performance-evidence-export-20261105-01`. Root owns the only actual dispatch. There is no automatic retry and no workload is dispatched by the exporter.

The capture writes the original `performance-01.tar.xz`, `manifest.json`, fresh bounded base64 transfer files and `report.json`. Its source/fd/path and every captured file/directory identity are checked again after the archive and transport are produced. Capture failure retains its own partial output and error report; it does not overwrite or retry the original capture.

## Full local verification

After the original capture strongly succeeds and the complete archive arrives, run the frozen local consumer once with absolute paths:

```text
/usr/bin/python3 -B /workspace/scratch/806ba5f52f94/r25-capacity-audit/r29-performance-export-01/verify_r29_performance_01.py
  --archive /ABSOLUTE/performance-01.tar.xz
  --export-report /ABSOLUTE/report.json
  --report-sha256 ACTUAL_ORIGINAL_REPORT_SHA256
  --capture-native-terminal /ABSOLUTE/actual-export-terminal.json
  --capture-native-read /ABSOLUTE/actual-complete-export-read.json
  --out /ABSOLUTE/fresh-performance-verification.json
```

The consumer requires the actual capture's strong terminal and its complete original full read, including exact stdout hex/text, footer and report identity. It verifies one complete XZ stream, checksum/EOF with no concatenation or trailing stream, the bounded canonical tar and zero tail, every regular member and omission, the embedded manifest, exact namespaces and full inventories/absence coverage. It independently repeats producer and monitor bindings. It neither extracts the archive nor executes archived code. Only reviewed local definitions and the pinned pure validator are loaded.

The unchanged 48,000-byte transport protocol verifies each encoded/decoded chunk and the whole archive. Reuse the actual transfer manifest and reviewed receiver, and bind the final complete archive SHA to the original capture report. Do not infer an archive's integrity merely from its summary or chunk count.

## Local preparation status

Only source derivation, AST/source equality checks, known-input hashing and request/document generation have occurred here. No exporter/consumer main, runtime fixture, audit replay, benchmark, host RPC or Git operation ran. `source-reuse-proof-01.json` records the unchanged helper functions, complete shared helper/monitor source identity and exact canonical inclusion. The first unexecuted draft is preserved under `before-final-self-review-01`; the subsequent narrow delta adds explicit normal ABBA A/B and tool-manifest cross-binding. Original R28 sources and all earlier failures remain unchanged.
