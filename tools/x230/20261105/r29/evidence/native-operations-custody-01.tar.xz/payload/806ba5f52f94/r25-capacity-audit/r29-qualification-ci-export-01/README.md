# R29 qualification and CI evidence template

This is a local preparation. No R29 qualification, CI, ELF, capture, or performance result is supplied or fabricated here. The frozen exporter and independent consumer reuse the R28 QC revision02 transport and archive verifier. No exporter, consumer, archive payload, test, or host command has been executed by this preparation.

## Fixed scope

The archive retains all original files beneath ROOT29/qualification-01, both first01 CI output trees and tools, the Python first01 outer launcher tree, the unchanged 85-input Python package, all 221 qualified compiler inputs and 19 qualification harness files. It also retains preparation-01.json, qualification-input-01.json, the actual target-transfer-01.json, applicable original CI installation/plan receipts, both original qualifier source/input files, and the unchanged dependency/package receipts. ROOT29 denotes /home/qian/hepta-runtime-optimization-20261105-r29.

The complete canonical validator 2892bd35 is embedded byte for byte. It binds the actual qualifier/input, complete qualified source map, the two new original tests, the unchanged eight stages and expected 1655 passed / 34 ignored / 1689 selected / zero retry contract. These are requirements for future actual evidence, not observed results. All recorded test gzip logs, eight qualification stage streams, retained ELF identities, successful Rust CI stage streams and nextest audit, and successful Python 18 exact command declarations plus all 36 stream bodies are matched to original producer hashes.

The fixed QC capture requires a complete successful original qualification; it cannot certify a running or failed qualification. Actual negative or unexecuted Rust/Python CI is retained without manufacturing its completed counts. Unexecuted CI requires absence of its exact native terminal and original output paths. Existing staged tool files may remain present. A negative/partial CI tree is still copied in full; positive producer validation is reported only after its original positive report and complete native terminal satisfy the original contract. Early qualification failures, if one occurs, require their own explicitly scoped preservation instead of being relabelled as this qualified capture.

No R28 own-failed qualification01 or Python recovery02 is asserted about R29. R28 history stays in its original preserved archives and the bound parent inputs. The moved R28 cache is not inspected or required to exist. No source, log, report, archive, cache, or executable is modified. ELF bodies are omitted after complete observed identity/SHA verification; text private-marker checks occur only after ELF classification. Future actual ELF pins come from the original qualified report/audit plus observed descriptors; none is prefilled.

## Late binding and execution order

actual-export-input-01.example.json deliberately has actual_outcomes_supplied=false, null executed/job/receipt identities, and no actual source-map hash. It is invalid execution input. Fill a new actual input only from the original qualification and CI terminal/report bytes, preserving negative/unexecuted states. Native terminal filenames in entry-templates-01.json are planned custody destinations, not a claim those files exist. The native request template also has a null input SHA and must not be dispatched unchanged.

After root supplies and verifies actual input, data-only staging can use the existing create-only file protocol for the fixed exporter/helper/input. The one native export produces a fresh qualification-ci-evidence-01 directory with single-stream .tar.xz, embedded _export-manifest.json, manifest.json, report.json, and 48,000-byte decoded base64 transport chunks. Retain the original native start/terminal/full read separately. The independent local consumer requires that original successful capture footer plus exact report, full archive SHA, XZ EOF/check/tar framing, every original member, original outcome recomputation and full producer bindings. It executes only the separately reviewed local definitions, never archived code; it performs no extraction, tests, or audit replay.

Performance, observation, lifecycle, saturation, Mac holder evidence and hosted CI remain outside this QC scope. Their existence and success must be bound only after their own original results. This package does not adopt R29.

## Local preparation history

The first local textual derivation failed before any exporter or consumer output: its marker STAGES = ( also matched QUALIFICATION_STAGES. The preserved second derivation narrows that exact marker to a line start, then completed once. Both original argv/stdout/stderr/exit records and the one-line source correction are retained. Only textual derivation, syntax parsing and source byte-equivalence checks ran; no synthetic workload or additional test suite ran.
