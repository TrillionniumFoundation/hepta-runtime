# R29 original qualification entry — local preparation

This directory prepares the single fresh R29 qualification of the frozen shared, unfiltered `ToolRouter` candidate. It does not run that candidate, move a cache, stage a host file, or change Git. R24 remains the accepted runtime. R28's completed qualification and CI are parent evidence; its original C1 observation rejection remains a rejection.

## Fixed source and qualification scope

The actual R28 qualified parent contains 221 compiler inputs and 19 original qualification helpers. Only `src/mcp/server.rs` and `src/mcp/server_tests.rs` change. `candidate-transform-01.json` contains exact before/after identities and unique literal replacements; local artifact construction reproduced both frozen postimages byte for byte. The other 219 compiler inputs remain unchanged.

The candidate adds exactly these two Linux tests:

- `mcp::server::server_tests::cached_router_keeps_mcp_sessions_and_teardown_independent`
- `mcp::server::server_tests::cached_router_rechecks_runtime_mode_and_native_session_owner`

The expected complete result is 1,689 selected, 34 ignored, 1,655 executed and passed, zero failures, and zero retries. These are required future counts, not observed results. The original full inventory, isolated case runner, independent audit, and all eight qualification stages still run. The preparer additionally checks that both added cases appear once in the original audited ledger, passed, with one attempt and no timeout.

The original qualification invocation remains `/usr/bin/python3 -B <fresh source>/tools/x230/20261028/qualify.py --source <fresh source> --output <qualification-01> --target <target-build> --cargo-home /home/qian/hepta-runtime-optimization-20261023/cargo-home-a32-a33-r02 --jobs 2 --stage-timeout 3600`. Its `subprocess.run` timeout is still 10,800 seconds. The native request template retains two CPU cores, nice 5, 5 GiB memory and 11,700 seconds.

## Paths and receipts

| Purpose | Fixed path under `/home/qian/hepta-runtime-optimization-20261105-r29` |
|---|---|
| Fresh source | `source` |
| Moved private target | `target-build` |
| Original eight-stage output | `qualification-01` |
| Original input copy | `qualification-input-01.json` |
| Preparation report | `preparation-01.json` |
| Single cache move receipt | `target-transfer-01.json` |
| Future authoritative terminal copy, written by root only after completion | `qualification-terminal-status-01.json` |

The small executable/input are staged separately under R25's existing `tools/` directory as `prepare_and_qualify_r29_01.py` and `r29-qualification-01-input.json`. The R29 root must still be absent at admission. An existing R29 root is an original-operation reconciliation case, not permission to overwrite or restart.

The six local downstream receipt aliases are `preparation-01.json`, `qualification-native-terminal-01.json`, `qualification-report-01.json`, `qualified-source-map-01.json`, `isolated-tests-summary-01.json`, and `isolated-tests-audit-01.json`. The completed preparation embeds the exact transfer receipt object and its byte identity, so downstream gates do not require a seventh file.

## One owned cache move

The only cache mutation is a single Linux `renameat2(RENAME_NOREPLACE)` from R28's own `target-build` to fresh R29 `target-build`, on the same filesystem. Both parent chains and the cache directory stay open with no-follow descriptors. Destination presence, unsupported no-replace rename, or any identity mismatch fails without copy, replacement, retry, rollback, or cleanup.

The original successful R28 qualification had independently copied this target from R26. R24 and R26 caches are outside the mutation scope. The R28 source, all original reports and logs, CI attempts, observation rejection, evidence archives, and all five retained test plus three retained release ELF files remain in place. The eight ELF checks use the original SHA-bound QC-export descriptors and require current exact metadata, regular owner-1000 files, one link, and no cache inode aliases. They do not claim fresh ELF body hashing.

Two unchanged complete metadata passes from the original read-only probe are bound. The entry repeats the inventory before preparing source and immediately before the move. It records both complete before/after hashes and separately compares a descendant-only hash. A rename may change the moved directory's own ctime; this is recorded explicitly. Every other root field and every descendant metadata record and count must remain exact.

The move allocates no second full-cache copy and frees no existing filesystem blocks. The original 3 GiB reserve is checked after fresh source preparation, immediately before the move, and immediately before Cargo. It is not a guarantee that later compilation growth fits. A reserve failure preserves partial fresh output and any already completed move; it does not delete evidence or authorize further changes.

## Actual bindings still required

`qualification-input-01.template.json` already contains the actual downloaded QC verification (9,585 bytes, SHA-256 `7342eed4ed17389eb57f5f40111438c5c4e339591ebb77c450a4fb1fe3ae2614`) and the original failed cache-probe01's authoritative terminal and two original read pages. The failed probe remains failed: it stopped at its own `/home/qian` path guard and did not mutate anything. Its missing space result is not fabricated.

Two fields remain null until actual original evidence exists:

1. `cache_admission.read_only_probe`: the reviewed corrected probe02's actual original job ID, terminal text, ordered original read-page texts and byte identities, and exact complete stdout identity. Every stream's original offsets, hex/text, final byte totals and EOF are checked. No synthetic aggregate native DTO is produced.
2. `cache_admission.root_exclusive_writer_admission`: root's actual controlled compilation window, selected source-map identity, original probe/QC identities, confirmation that original native raw custody is retained and that no later R28 cache use is scheduled. This is not a new user permission request.

The original bounded reference scope remains cwd, argv and `CARGO_TARGET_DIR`. Observed cache references, a live compiler or a known unclosed original writer block the move. Original unknown process channels, including concrete same-owner error categories, remain recorded for root's actual review; no all-user-readable gate or all-writers-absent claim is added. Open fd/mmap channels and future writers are not proven by this snapshot. The root window does not turn the readonly report into a lease or remove those limitations.

`canonical-preparation-validator.template.py` is the shared downstream function. Its two exact launcher/input identity literals remain `None` until the reviewed final entry and actual input are frozen. It fails closed in this state. The signature is `verify_r29_candidate_preparation(preparation, terminal, job_id, qualified, tests)`. External bindings remain `need`, `re`, `ROOT`, `SOURCE`, and `CANDIDATE_DIR`; `hashlib` and `json` are imported locally inside the function.

## Failure and acknowledgement handling

Reports are created exclusively in the fresh task root. Only their originally opened descriptors are updated. A failed preparation leaves its exact report and partial task-owned files. A completed cache-transfer receipt remains a completed transfer even if later qualification fails. The preparation then remains failed and the candidate is not adopted.

There is one rename syscall and one original qualifier invocation. Lost acknowledgement must be reconciled against the original operation and recorded inode: old path absent plus new path with the original device/inode can establish the move. Both present, both absent, changed identity, or subsequent compiler activity requires root to inspect original evidence. This entry never performs a second rename or rollback.

Local work so far is artifact construction, hash checks, exact postimage reconstruction and AST review. No entry function, candidate test, compiler, cache move, host RPC or Git operation has run here.
