# R29 Mac holder original-evidence companion

This is a local preparation of the previously verified R28 collector and independent consumer. No holder, collector, consumer, directory preparer, workload or native request has been executed by this preparation. R29 observation job `1a1ad77dfe5-fc05-59f9` is the known original; its terminal outcome and the lifecycle outcome remain unbound in this frozen preparation.

## Fixed scope and unchanged contract

The only holder kinds are `observation01` and `lifecycle01`, under `/Users/qianqi/work/hepta-runtime-r29-observation-evidence-01` and `/Users/qianqi/work/hepta-runtime-r29-lifecycle-evidence-01`. Each executed holder contributes the same exact 22 files: its report, retained transmitted parent source, forwarded stdout/stderr, owned-agent stderr, seven identity-discovery stderr files and ten identity-load stdout/stderr files. The original held-agent source is fixed at 11,374 bytes / `715e996217c7d33a7483354f16f2d39c9a033f51f3a20a52484495a00262dd65`.

The R29 observation parent is 66,141 bytes / `0eaf6dd96e6a69eba4ef382360febefd58e1f0370baf7cd79bb817ac2ce266ec`; the lifecycle parent is 26,760 bytes / `12b9ad142d95148e9d08a69d44be3e4e3d17a03877eadc956a020602aa22e846`. Both are the actual frozen acceptance-delivery sources. Capture verifies the staged source and the retained transmitted source independently. The already-used holder accepts these source bytes without a 65,536-byte source limit; the archive file-read limit remains the original 32 MiB.

Collector and consumer functions are identical to the successful R28 version after changing only their schema namespace. The constant changes are fresh R29 paths, the two actual parent identities, the known observation job ID and removal of obsolete R28 outcome pins. All new outcome pins remain mandatory in the eventual actual input, bound by its SHA on both entry commands. `derivation-proof-01.json` and `source-delta-01.patch` provide the exact comparison. The base full archive QA is `benchmark-r28/mac-companion-operations-01/assembled-01/verified-01/independent-verification-01.json` (6,519 bytes / `a1036182464f30a7afe8880ffe19077d45dddebd298948c9c52d4179b0e4972b`).

## Actual late binding, after the original workloads finish

`actual-input-01.example.json` deliberately fails the existing input guard: its global terminal-or-unexecuted flag is false, required result hashes are null, and lifecycle execution remains null. It must never be submitted as actual evidence.

For each executed holder, retain the original full native terminal and full zero-offset native read as `<kind>-terminal.json` and `<kind>-read.json`. Preserve their exact saved original bytes, including an original request/result or MCP envelope when supplied. Bind those file hashes, the actual job ID and the actual Mac holder report SHA in the corresponding input row. A completed failed native/holder is valid negative evidence; its original false flags, nonzero return code and forwarded footer remain negative. Native success does not imply that observation or adoption gates passed.

If lifecycle was not submitted, its row must explicitly set `executed: false`, all job/report/native pins to null and a truthful nonempty reason. The collector then requires actual absence of that fixed evidence directory and rechecks absence before and after archiving. This preparation neither asserts that absence nor manufactures a lifecycle result. A staged lifecycle parent may be archived as prepared source; that does not prove that it was transmitted or executed.

Only after every row is resolved can `all_originals_terminal_or_unexecuted` become true. Freeze the actual input SHA, substitute the sole null `--input-sha256` argument in `capture-request-01.template.json`, and stage the exact actual files. The original observation ID cannot be omitted or replaced by an unexecuted row.

The terminal wrapper SHA and the inner terminal DTO SHA are different identities when a wrapper exists. For X230 cross-package comparison, compare the exact UTF-8 bytes of the unique original `content.text` with `ROOT29/observation-native-terminal-01.json` or `ROOT29/lifecycle-native-terminal-01.json`, without JSON re-encoding or an added newline. Do not assert equality between the wrapper hash and the inner DTO hash.

## Create-only staging and one capture

`native-directory-create.request.json` creates only the two fresh tools/input directories at mode 0700. Its code is the successful R28 fixed-two-directory implementation with path/schema replacements; it does not run any payload. Preserve its original native result before proceeding. The two exact source-write requests require `expected_version: absent`; each source is below 65,536 bytes. Verify each source with its associated file-info request. Later actual input/native files are also create-only. Do not overwrite a prior directory, source or evidence output.

The final capture output is `/Users/qianqi/work/hepta-runtime-r29-mac-companion-evidence-01`. The capture key is `hepta-r29-mac-holder-evidence-export-20261105-01`, nice 19, timeout 300 seconds. Root is the sole native executor. Staging/capture must wait for the timed-measurement window to end. No holder, SSH session, service, benchmark or cleanup is launched by these tools.

## Archive and independent consumer

The original deterministic single-member gzip format remains: one `formal/formal-holders-01.tar.gz`, an exact manifest and 48,000-byte binary chunks encoded into at most 64,000 bytes of base64. Preserve full capture native start/status/read, the output receipt, four group metadata files and all original transfer request/result envelopes. Prefer one small file per remote read; do not fabricate aggregate envelopes. The consumer independently validates gzip CRC/trailer/exact end, every archive member, original source identities, native streams, holder cleanup and the original outcomes without executing archived code.

`consumer-arguments.template.json` leaves the actual capture job, receipt hash/version, input SHA and local root unbound until capture and complete download. Independent archive QA is still pending. No performance improvement, adoption, hosted CI, Git publication or global optimization limit is asserted by this preparation.
