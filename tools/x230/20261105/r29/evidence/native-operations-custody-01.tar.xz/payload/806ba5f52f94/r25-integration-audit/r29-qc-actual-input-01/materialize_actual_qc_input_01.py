#!/usr/bin/env python3
"""Bind the three completed original R29 jobs; write local requests only."""
import base64
import hashlib
import json
from pathlib import Path

BASE = Path('/workspace/scratch/806ba5f52f94')
HERE = Path(__file__).resolve().parent
OUT = HERE / 'actual-01'
ROOT = Path('/home/qian/hepta-runtime-optimization-20261105-r29')
STAGE = Path('/home/qian/hepta-runtime-optimization-20261105-r25')
EXPORT_DIR = BASE / 'r25-capacity-audit/r29-qualification-ci-export-01'
EXPORTER_SHA = 'f38980671314149b376eb84d25b30b3ebadd3ac702424c36a4fa2c1ae5dc45c0'
HELPER_SHA = '8b7aa7ef3b3772da13ea4f7009d8c478e0c92bc207d65db3f45c23453097d7a2'
QUAL = BASE / 'benchmark-r29/actual-qualification-receipts-01'
RUST = BASE / 'benchmark-r29/rust-ci-operations-01'
PYTHON = BASE / 'benchmark-r29/python-ci-operations-01'
JOBS = {'qualification01': '1a1ad4261c8-fc05-593b',
        'rust_ci01': '1a1ad69c247-fc05-59c8',
        'python_ci01': '1a1ad72111c-fc05-59eb'}
PINNED = {
    QUAL / 'preparation-01.json': (350182, 'fcc7bd5ee050a60b38c047ea9b06ac0bae1d7ebf927b67af60b620af18012782'),
    QUAL / 'qualified-source-map-01.json': (24278, '58ca6700a4378d14912358f9bb787d395ef5f86f17d7bf373af2525ee55ae88b'),
    QUAL / 'qualification-report-01.json': (83733, '942a570097ab3c751e9969f3d13924dec474888e85e0ce176ee7943547d12b62'),
    QUAL / 'qualification-native-terminal-01.json': (731, '582adb11fde3f248411fa5daf25a235cc352bfae28fa3605f2898779b8b48462'),
    RUST / 'actual-report-01.json': (14131, '911e8c44f1441c7ab0e017d9862e4e7f953a5ceb27c23a14868caccf2f4a702f'),
    RUST / 'actual-native-terminal-01.json': (731, '6b3bfd27ffe4e037715343d836947a1431eda7294446efc7b3684bd7324a0822'),
    PYTHON / 'actual-launch-receipt-01.json': (9579, '68195d90ad8b6a6f18f17c24075d9db9ca73a8dc70d99a3aa3a70ba6e12420fb'),
    PYTHON / 'actual-report-01.json': (16692, '64c89946e08ab74420efab2c0dc4a17b76b4e836d4e2f76d87c4ee212b1798fa'),
    PYTHON / 'actual-native-terminal-01.json': (731, 'f81b9cc08f4a81cb79f1320c9813c101d7987cbd70e2238a88b3c42121905718'),
}


def need(value, message):
    if not value:
        raise ValueError(message)


def identity(raw):
    return {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


def encode(value):
    return (json.dumps(value, sort_keys=True, indent=2) + '\n').encode()


def main():
    need(not OUT.exists(), 'fresh local output required; do not overwrite prior materialization')
    originals = {}

    def read(path):
        raw = path.read_bytes()
        if path in PINNED:
            need((len(raw), hashlib.sha256(raw).hexdigest()) == PINNED[path], 'actual original differs: ' + str(path))
        originals[str(path)] = identity(raw)
        return raw

    def original_text(path):
        wrapper = json.loads(read(path))
        result = wrapper.get('result', wrapper)
        need(result.get('isError') is False, 'original RPC failed: ' + str(path))
        blocks = result.get('content', [])
        need(len(blocks) == 1 and blocks[0].get('type') == 'text', 'one original text block required')
        return wrapper, blocks[0]['text'].encode('utf-8')

    exporter = EXPORT_DIR / 'export_r29_qualification_ci_01.py'
    raw = read(exporter)
    need(hashlib.sha256(raw).hexdigest() == EXPORTER_SHA, 'frozen exporter changed')
    need(hashlib.sha256(read(EXPORT_DIR / 'stable_xz_archive.py')).hexdigest() == HELPER_SHA, 'frozen helper changed')
    # Load exact reviewed definitions. Its __main__ branch is not executed.
    module = {'__name__': 'r29_local_original_qc_definitions', '__file__': str(exporter)}
    exec(compile(raw, str(exporter), 'exec'), module)
    value = json.loads(read(EXPORT_DIR / 'actual-export-input-01.example.json'))
    outcomes = {}
    for name, terminal_path, report_path in (
        ('qualification01', QUAL / 'qualification-native-terminal-01.json', QUAL / 'qualification-report-01.json'),
        ('rust_ci01', RUST / 'actual-native-terminal-01.json', RUST / 'actual-report-01.json'),
        ('python_ci01', PYTHON / 'actual-native-terminal-01.json', PYTHON / 'actual-launch-receipt-01.json'),
    ):
        terminal_raw, report_raw = read(terminal_path), read(report_path)
        terminal, report = json.loads(terminal_raw), json.loads(report_raw)
        outcomes[name] = module['validate_terminal'](terminal, JOBS[name])
        value['stages'][name] = {
            'executed': True, 'job_id': JOBS[name],
            'native_terminal': {'path': str(module['NATIVE_PATHS'][name]), **identity(terminal_raw)},
            'report': {'path': str(module['REPORT_PATHS'][name]), **identity(report_raw)}, 'reason': None}
        outcomes[name]['original_report_schema'] = report.get('schema')
        outcomes[name]['original_report_passed'] = report.get('passed')
        outcomes[name]['original_report_qualified'] = report.get('qualified')
    for key, local, remote in (
        ('preparation', QUAL / 'preparation-01.json', ROOT / 'preparation-01.json'),
        ('source_map', QUAL / 'qualified-source-map-01.json', ROOT / 'qualification-01/source-map.json'),
    ):
        value[key] = {'path': str(remote), **identity(read(local))}
    for folder, status_name in ((RUST, 'status-01.json'), (PYTHON, 'status-02.json')):
        _, text = original_text(folder / status_name)
        need(text == read(folder / 'actual-native-terminal-01.json'), 'terminal must be exact original content.text bytes')
    start_wrapper, text = original_text(PYTHON / 'start-01.json')
    start = json.loads(text)
    expected_request = json.loads(read(BASE / 'benchmark-r29/ci-actual-generation-01/python-delivery-01/ci-request.json'))
    need(start_wrapper['request'] == expected_request and start['job']['id'] == JOBS['python_ci01']
         and start['job']['idempotency_key'] == 'hepta-r29-python-ci-20261105-01'
         and start['job']['request_digest'] == 'c02e11eb85544837a6b6e2a336c3d70205793c5124e52c32aa43cc94c125e254'
         and start['reused'] is False, 'different original Python submission')
    _, text = original_text(PYTHON / 'read-complete-01.json')
    original_read = json.loads(text)
    terminal = json.loads(read(PYTHON / 'actual-native-terminal-01.json'))
    need(original_read['job_id'] == JOBS['python_ci01'], 'different original Python read')
    for stream in ('stdout', 'stderr'):
        row = original_read[stream]
        raw = bytes.fromhex(row['bytes_hex'])
        need(row['offset'] == 0 and row['eof'] is True and row['next_offset'] == row['size'] == len(raw)
             == terminal['log_bytes'][stream]['seen'] == terminal['log_bytes'][stream]['stored']
             and row['text'].encode() == raw and read(PYTHON / ('complete-' + stream + '-01.log')) == raw,
             'original Python stream is incomplete or differs')
    parent = json.loads(read(PYTHON / 'actual-launch-receipt-01.json'))
    child_raw = read(PYTHON / 'actual-report-01.json')
    child = json.loads(child_raw)
    need(parent['report'] == {'path': str(ROOT / 'python-ci-01/report.json'), **identity(child_raw)}, 'outer/inner original report differs')
    manifest = json.loads(read(BASE / 'r25-integration-audit/ci-gate-manifest.json'))
    if parent.get('passed') is True:
        need(parent['runner_returncode'] == 0 and parent['retry_count'] == 0 and parent['gates_executed'] == 18
             and parent['failed_gates'] == [] and parent['candidate_binding_before'] == parent['candidate_binding_after']
             and child['passed'] is True and child['retry_count'] == 0 and child['final_inputs_unchanged'] is True
             and len(child['gates']) == len(manifest['python_gates']) == 18, 'positive original Python summary differs')
        for actual, expected in zip(child['gates'], manifest['python_gates'], strict=True):
            need({k: actual[k] for k in ('id', 'argv', 'workflow_step')} == expected
                 and actual['passed'] is True and actual['returncode'] == 0, 'original Python command differs')
    value['actual_outcomes_supplied'] = True
    module['validate_input'](value)
    input_raw = encode(value)
    entry = json.loads(read(EXPORT_DIR / 'entry-templates-01.json'))
    native_request = entry['native_request_template']
    need(native_request['args'][-2:] == ['--input-sha256', None], 'native capture template differs')
    native_request['args'][-1] = identity(input_raw)['sha256']
    terminal_raw = read(PYTHON / 'actual-native-terminal-01.json')
    output_files = {
        'actual-input-01.json': input_raw,
        'input-write.request.json': encode({'host': 'x230', 'path': str(module['INPUT']), 'data_base64': base64.b64encode(input_raw).decode(), 'expected_version': 'absent'}),
        'input-file-info.request.json': encode({'host': 'x230', 'path': str(module['INPUT'])}),
        'python-terminal-write.request.json': encode({'host': 'x230', 'path': str(module['NATIVE_PATHS']['python_ci01']), 'data_base64': base64.b64encode(terminal_raw).decode(), 'expected_version': 'absent'}),
        'python-terminal-file-info.request.json': encode({'host': 'x230', 'path': str(module['NATIVE_PATHS']['python_ci01'])}),
        'native-export.request.json': encode(native_request),
    }
    for path, expected in originals.items():
        need(identity(Path(path).read_bytes()) == expected, 'local original changed during materialization')
    OUT.mkdir(mode=0o700)
    for name, raw in output_files.items():
        with (OUT / name).open('xb') as stream:
            stream.write(raw)
    receipt = {'schema': 'hepta-r29-local-actual-qc-input-materialization/v1',
               'passed': True, 'original_outcomes': outcomes, 'original_files': originals,
               'files': {name: identity(raw) for name, raw in output_files.items()},
               'original_Python_native_and_report_bindings_verified': True,
               'complete_CI_gate_log_bodies_verified_here': False,
               'complete_CI_gate_log_bodies_pending_frozen_QC_capture_and_consumer': True,
               'qualification_and_Rust_terminal_already_staged_by_root': True,
               'native_capture_submitted': False, 'remote_calls': 0,
               'execute_only_outside_measurement_window': True,
               'candidate_adopted': False, 'performance_or_lifecycle_result_inferred': False}
    with (OUT / 'materialization-receipt-01.json').open('xb') as stream:
        stream.write(encode(receipt))
    print(json.dumps({'passed': True, 'output': str(OUT), 'actual_input': identity(input_raw),
                      'native_capture_submitted': False, 'remote_calls': 0}), flush=True)


if __name__ == '__main__':
    main()
