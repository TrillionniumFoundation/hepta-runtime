#!/usr/bin/env python3
# Copyright 2026 TrillionniumFoundation
# SPDX-License-Identifier: Apache-2.0
"""Qualify exact R29 source once, after one admitted R28-owned cache move.
Unbound cache/QC/writer evidence rejects before any directory or file mutation.
No service change, cache copy, cleanup, automatic move retry or rollback.
"""
import argparse
import ctypes
import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import stat
import subprocess
import sys
import time
import traceback

ROOT = Path('/home/qian/hepta-runtime-optimization-20261105-r29')
PARENT = Path('/home/qian/hepta-runtime-optimization-20261105-r28')
ACCEPTED = Path('/home/qian/hepta-runtime-optimization-20261105-r24')
OLD_SOURCE = PARENT / 'source'
SOURCE = ROOT / 'source'
TARGET = ROOT / 'target-build'
OUTPUT = ROOT / 'qualification-01'
INPUT = Path('/home/qian/hepta-runtime-optimization-20261105-r25/tools/r29-qualification-01-input.json')
ROOT24 = str(ACCEPTED)
ROOT26 = '/home/qian/hepta-runtime-optimization-20261105-r26'
ROOT28 = str(PARENT)
ROOT29 = str(ROOT)
CACHE = ROOT28 + '/target-build'
OWNER = 1000
CACHES = (('owned_r28_target', CACHE, False),)
FIELDS = ('st_dev', 'st_ino', 'st_uid', 'st_gid', 'st_mode', 'st_nlink', 'st_size', 'st_mtime_ns', 'st_ctime_ns')
EXPORT_FIELDS = ('st_dev', 'st_ino', 'st_uid', 'st_mode', 'st_nlink', 'st_size', 'st_mtime_ns', 'st_ctime_ns')
DEAD = {'Z', 'X', 'x'}
START = time.monotonic_ns()
MAX_DURATION_NS = 120 * 10**9
MAX_TREE_ENTRIES = 200000
MAX_PROCESSES = 16384
MAX_PROC_BYTES = 1048576
PROTECTED_ELF_INODES = set()
RESERVE_BYTES = 3 * 1024**3
CHANGED_PATHS = ('src/mcp/server.rs', 'src/mcp/server_tests.rs')
STAGES = ['format', 'fmt-check', 'harness-tests', 'clippy', 'test-build',
          'isolated-tests', 'audit-isolated-tests', 'release']
PUBLICATION_SHA = '38866c01fac54133c8a88e25bee90ea4a551e7273614f493bf44522a8273d3ca'
PROBE_SOURCE_SHA = '088b102aec64ea0606ba1dfb09dfc73b5d332f76a08b5ad68cd1847300a914d2'
QC_CONSUMER_SHA = 'c949b88484f348a53e9aadde9b92c248d08c507347faea2e978ed0639dd3df73'
QC_ARCHIVE = {'bytes': 1915620, 'sha256': '442586ded13a4cfde54531e6f05ddddcf26c2f53d40d15b04c5993ece5f04186'}
QC_EXPORT_JOB = '1a1acd29fba-fc05-5724'
REJECTION_REPORT_SHA = '9fd45bf5f9987b849c637bdf3ed61f3b49b4f98b615dd914d16e0afa80822ba5'
REJECTION_SUMMARY_SHA = 'c1df02071f3ebecde73de47cc3fe62daef2908981486db40287a995daabf5a0c'
REJECTION_NATIVE_SHA = '3df7bbc9acc621a6c1eeaf85e4fe21870cb62ba5df0f423e2b67a6e8f236860e'
NEW_EXACT_TESTS = (
    'mcp::server::server_tests::cached_router_keeps_mcp_sessions_and_teardown_independent',
    'mcp::server::server_tests::cached_router_rechecks_runtime_mode_and_native_session_owner')
BOUND = {'isolated_summary': ('/home/qian/hepta-runtime-optimization-20261105-r28/qualification-01/isolated-tests/summary.json',
                      6878,
                      'a6645dbb6a0208fdbca1a3dd6308c55f7d6b876ef4ddf70f02a2b4c58c9db46d'),
 'preparation': ('/home/qian/hepta-runtime-optimization-20261105-r28/preparation-02.json',
                 96494,
                 '4ece02608c423456d0996de39c54129c6c759a1973a0e11f22b04f936b113cc3'),
 'qc_export': ('/home/qian/hepta-runtime-optimization-20261105-r28/qualification-ci-evidence-01/report.json',
               11627,
               'e150979b4024edf8c82450b6c18beb7492306928f7f61a3b8247e4977e7862d0'),
 'qc_manifest': ('/home/qian/hepta-runtime-optimization-20261105-r28/qualification-ci-evidence-01/manifest.json',
                 2745831,
                 '9ed5ce8099685e6fff9e1f0ecb2b7b980f6e2dc410cf2413bd189d72a8395a9d'),
 'qualification': ('/home/qian/hepta-runtime-optimization-20261105-r28/qualification-01/report.json',
                   83735,
                   '9e564f3950575313034f55974303e56c236ac030e2c5f121d49791da0c4c09fa'),
 'qualified_source_map': ('/home/qian/hepta-runtime-optimization-20261105-r28/qualification-01/source-map.json',
                          24278,
                          'da8cbdfef75c1c9fc5861e4fe0bd96aeb98f635e95fc122610021cd725db1d28'),
 'rust_ci': ('/home/qian/hepta-runtime-optimization-20261105-r28/rust-ci-01/report.json',
             14131,
             '89478d995d449181fb8066165c0802f8d11770254b9deea13bc3b28c8f5e3dbc')}
KNOWN_OPERATIONS = {'python_ci01': {'exit_code': 1,
                 'job_id': '1a1ac97d8cb-fc05-55a2',
                 'report': {'bytes': 1506,
                            'path': '/home/qian/hepta-runtime-optimization-20261105-r28/python-ci-launch-01/receipt.json',
                            'sha256': '3b24569825c641d07249d71d9e064d703ee760e728eac96c979345bb2774dd96'},
                 'state': 'failed',
                 'terminal': {'bytes': 728,
                              'path': '/home/qian/hepta-runtime-optimization-20261105-r28/python-ci-terminal-status-01.json',
                              'sha256': '9979d74c66b765d8ac10de4e42b224cca7f2c26c6df7030457e09a029abb2d60'}},
 'python_ci02': {'exit_code': 0,
                 'job_id': '1a1acb64a3e-fc05-5682',
                 'report': {'bytes': 11546,
                            'path': '/home/qian/hepta-runtime-optimization-20261105-r28/python-ci-launch-02/receipt.json',
                            'sha256': 'f525b13f3f225635d7e2e745cd2d9befe1962162e682031056431c31d4ae1d91'},
                 'state': 'succeeded',
                 'terminal': {'bytes': 731,
                              'path': '/home/qian/hepta-runtime-optimization-20261105-r28/python-ci-terminal-status-02.json',
                              'sha256': '5075b6bdfffd058d59d385daae74ffb831959ebcd2d9c1daaa259c3424ff291c'}},
 'qualification02': {'exit_code': 0,
                     'job_id': '1a1ac5d5a29-fc05-53d9',
                     'report': {'bytes': 83735,
                                'path': '/home/qian/hepta-runtime-optimization-20261105-r28/qualification-01/report.json',
                                'sha256': '9e564f3950575313034f55974303e56c236ac030e2c5f121d49791da0c4c09fa'},
                     'state': 'succeeded',
                     'terminal': {'bytes': 731,
                                  'path': '/home/qian/hepta-runtime-optimization-20261105-r28/qualification-terminal-status-02.json',
                                  'sha256': '3325b116b998ddff0e586a3b983a2715339acb1b48e9215f5b92e9abfdde4946'}},
 'qualification_failed01': {'exit_code': 1,
                            'job_id': '1a1ac274e49-fc05-5286',
                            'report': {'bytes': 4671,
                                       'path': '/home/qian/hepta-runtime-optimization-20261105-r28/preparation-01.json',
                                       'sha256': 'abc26b3d49c2e57b608fe3aba792708e80de95340c1c8c210dced2844953fade'},
                            'state': 'failed',
                            'terminal': {'bytes': 726,
                                         'path': '/home/qian/hepta-runtime-optimization-20261105-r28/qualification-terminal-status-01.json',
                                         'sha256': '8dee0438ff40dc85288ff6d9ff6da9dfcdfc36092bbc12995bd99018f3d00d31'}},
 'rust_ci01': {'exit_code': 0,
               'job_id': '1a1ac8bfc0c-fc05-552c',
               'report': {'bytes': 14131,
                          'path': '/home/qian/hepta-runtime-optimization-20261105-r28/rust-ci-01/report.json',
                          'sha256': '89478d995d449181fb8066165c0802f8d11770254b9deea13bc3b28c8f5e3dbc'},
               'state': 'succeeded',
               'terminal': {'bytes': 731,
                            'path': '/home/qian/hepta-runtime-optimization-20261105-r28/rust-ci-terminal-status-01.json',
                            'sha256': '24c48bc1d951fee3e22dd06a4502834b3a19bda089b00eac4be5cd666046369e'}}}
FAILED_PROBE_SPEC = {'job_id': '1a1acfe317a-fc05-57ee',
 'native_read_page_identities': [{'bytes': 50981,
                                  'sha256': '0453204d61dcfea47fe301271eede5c0890a082619ab3b92599fb4a07c1f251c'},
                                 {'bytes': 17245,
                                  'sha256': 'eb4926d5ef4db33ea106b777abb262716f0a1007b7f48518c31dbfe0cfcdbcde'}],
 'native_terminal_identity': {'bytes': 730,
                              'sha256': 'cba5670b8ed6e516258728bea1c32224e70393d71f0e112e9fa9f8f09482ba6a'},
 'source_sha256': '9242d4b6f2d9b21b80b7cba7f1aabb23e6f9e222a43b7000d064b7edf532b9a0',
 'stdout_identity': {'bytes': 21898,
                     'sha256': '7d96f345114fcad140b40f69804df679f68b8e67d57a1c46941d809cedb3c58f'}}
TRANSFORM_SHA = '550080227753a739cf753c9ec5a03a81c40305a5ca1858d133d9d23718471e94'
CANDIDATE_MAP_SHA = 'ce3e814a7bfeb7f0d168782dc325e643550cc0c768b606d90c4d45693fbe4853'
CANDIDATE_MANIFEST = {'bytes': 81083, 'sha256': '16316a0064564f74cdfe747e1c7a2a046317970b3c62ccea33aa9489b32e2af1'}

def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()

def encoded(value):
    return (json.dumps(value, sort_keys=True, indent=2, allow_nan=False) + '\n').encode()

def stamp(value):
    return tuple(getattr(value, key) for key in ('st_dev', 'st_ino', 'st_mode',
                 'st_uid', 'st_nlink', 'st_size', 'st_mtime_ns', 'st_ctime_ns'))

def read(path, expected=None, retain=False):
    path = Path(path)
    assert path.is_absolute() and path.resolve(strict=True) == path, str(path)
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_CLOEXEC | os.O_NONBLOCK)
    try:
        before = os.fstat(fd)
        assert stat.S_ISREG(before.st_mode) and before.st_uid == os.geteuid()
        assert before.st_nlink == 1 and not before.st_mode & (stat.S_ISUID | stat.S_ISGID)
        assert 0 <= before.st_size <= 1024**3
        digest, size, blocks = hashlib.sha256(), 0, []
        while block := os.read(fd, 1024 * 1024):
            size += len(block)
            assert size <= before.st_size
            digest.update(block)
            if retain:
                blocks.append(block)
        assert size == before.st_size and stamp(before) == stamp(os.fstat(fd)) == stamp(path.lstat())
        assert expected is None or digest.hexdigest() == expected, str(path)
        return {'path': str(path), 'bytes': size, 'sha256': digest.hexdigest()}, b''.join(blocks)
    finally:
        os.close(fd)

def source_map(root):
    paths = [root / name for name in ('Cargo.toml', 'Cargo.lock', 'rustfmt.toml')]
    for name in ('src', 'examples'):
        paths.extend(path for path in (root / name).rglob('*') if path.is_file())
    return {path.relative_to(root).as_posix(): read(path)[0]['sha256'] for path in sorted(paths)}

def harness_map(root):
    return {path.name: read(path)[0]['sha256']
            for path in sorted((root / 'tools/x230/20261028').glob('*.py'))}

def check_terminal(raw, job_id, state="succeeded", exit_code=0):
    value = json.loads(raw)
    assert value['job_id'] == job_id and value['state'] == state and value['exit_code'] == exit_code
    assert all(value[k] is True for k in ('output_complete', 'output_durable', 'terminal_publication_confirmed'))
    assert all(value[k] is False for k in ('automatic_retry', 'cancelled', 'timed_out'))
    assert value['terminal_publication_protocol'] == 1
    for name in ('stdout', 'stderr'):
        assert value['log_synced'][name] is True and value['log_truncated'][name] is False
        assert value['log_errors'][name] is None
        assert value['log_bytes'][name]['seen'] == value['log_bytes'][name]['stored']

def quiescence():
    deadline, samples = time.monotonic() + 300, []
    while True:
        active = []
        for path in Path('/proc').glob('[0-9]*/comm'):
            try:
                name = path.read_text().strip()
                if name in ('cargo', 'rustc', 'rust-lld', 'ld.lld'):
                    active.append({'pid': int(path.parent.name), 'name': name})
            except (FileNotFoundError, ProcessLookupError, PermissionError):
                pass
        samples.append({'utc': utc(), 'compiler_processes': active})
        if not active:
            return samples
        assert time.monotonic() < deadline, 'compiler quiescence unavailable; no cache copy or qualification started'
        if len(samples) == 1:
            print(json.dumps({'waiting_for_compiler_quiescence': active}), flush=True)
        time.sleep(2)

def byte_identity(body):
    return {'bytes': len(body), 'sha256': hashlib.sha256(body).hexdigest()}

def need(value, reason):
    if not value:
        raise RuntimeError(reason)

def budget():
    need(time.monotonic_ns() - START <= MAX_DURATION_NS, 'bounded inventory duration exceeded')

def metadata_stamp(value):
    return {key: getattr(value, key) for key in FIELDS}

def directory_id(value):
    need(stat.S_ISDIR(value.st_mode), 'fixed path is not a directory')
    return (value.st_dev, value.st_ino, value.st_uid, value.st_mode)

def check_chain(chain):
    for item in chain:
        linked = (os.lstat('/') if item['parent'] is None else
                  os.stat(item['name'], dir_fd=item['parent'], follow_symlinks=False))
        need(directory_id(os.fstat(item['fd'])) == item['identity'] == directory_id(linked),
             'fixed directory chain changed')

def close_chain(chain):
    for item in reversed(chain):
        os.close(item['fd'])

def open_directory(path, *, fixed_space_parent=False):
    permitted = (path == '/home/qian' if fixed_space_parent is True
                 else path.startswith('/home/qian/'))
    need(permitted and os.path.normpath(path) == path,
         'directory outside exact task parent')
    chain = []
    try:
        for number, name in enumerate(('/', *path.split('/')[1:])):
            parent = chain[-1]['fd'] if chain else None
            fd = os.open(name, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW | os.O_CLOEXEC,
                         **({'dir_fd': parent} if parent is not None else {}))
            item = {'fd': fd, 'parent': parent, 'name': name}
            chain.append(item)
            item['identity'] = directory_id(os.fstat(fd))
            need(item['identity'][2] == (0 if number < 2 else OWNER), 'fixed directory owner differs')
            check_chain(chain)
        need(os.path.realpath(path) == path, 'fixed root realpath differs')
        return chain
    except BaseException:
        close_chain(chain)
        raise

def read_bound(spec):
    path, size, expected_sha = spec
    chain = open_directory(os.path.dirname(path))
    fd = None
    try:
        owner_fd = chain[-1]['fd']
        fd = os.open(os.path.basename(path), os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK | os.O_CLOEXEC,
                     dir_fd=owner_fd)
        before = os.fstat(fd)
        need(stat.S_ISREG(before.st_mode) and before.st_uid == OWNER and before.st_nlink == 1
             and before.st_size == size <= 4 * 1048576, 'fixed evidence file metadata differs')
        with os.fdopen(os.dup(fd), 'rb') as stream:
            raw = stream.read(size + 1)
        actual_sha = hashlib.sha256(raw).hexdigest()
        need(len(raw) == size and actual_sha == expected_sha
             and metadata_stamp(before) == metadata_stamp(os.fstat(fd))
             == metadata_stamp(os.stat(os.path.basename(path), dir_fd=owner_fd, follow_symlinks=False)),
             'fixed evidence bytes or descriptor changed')
        check_chain(chain)
        return {'path': path, 'bytes': size, 'sha256': actual_sha, 'identity': metadata_stamp(before)}, json.loads(raw)
    finally:
        if fd is not None:
            os.close(fd)
        close_chain(chain)

def inventory_tree(path):
    chain = open_directory(path)
    started = time.monotonic_ns()
    try:
        root_fd = chain[-1]['fd']
        root = os.fstat(root_fd)
        totals = {'entries': 0, 'directories_including_root': 0, 'directory_logical_bytes': 0,
                  'directory_allocated_bytes': 0, 'regular_files': 0,
                  'regular_logical_bytes': 0, 'unique_regular_logical_bytes': 0,
                  'unique_regular_allocated_bytes': 0, 'symlinks': 0, 'other_nonregular': 0,
                  'other_device_entries': 0, 'other_owner_entries': 0, 'multiply_linked_regular_files': 0}
        incidents, inodes = [], set()
        inode_links, retained_aliases = {}, []
        accumulator = hashlib.sha256()
        descendants = hashlib.sha256()

        def account(relative, current):
            budget()
            totals['entries'] += 1
            need(totals['entries'] <= MAX_TREE_ENTRIES, 'bounded cache entry count exceeded')
            record = {'relative': relative, 'identity': metadata_stamp(current), 'st_blocks': current.st_blocks}
            record_raw = (json.dumps(record, sort_keys=True, separators=(',', ':')) + '\n').encode()
            accumulator.update(record_raw)
            if relative != '.':
                descendants.update(record_raw)
            foreign_device = current.st_dev != root.st_dev
            foreign_owner = current.st_uid != OWNER
            totals['other_device_entries'] += int(foreign_device)
            totals['other_owner_entries'] += int(foreign_owner)
            mode = current.st_mode
            if stat.S_ISDIR(mode):
                totals['directories_including_root'] += 1
                totals['directory_logical_bytes'] += current.st_size
                totals['directory_allocated_bytes'] += current.st_blocks * 512
            elif stat.S_ISREG(mode):
                totals['regular_files'] += 1
                totals['regular_logical_bytes'] += current.st_size
                totals['multiply_linked_regular_files'] += int(current.st_nlink != 1)
                key = (current.st_dev, current.st_ino)
                prior = inode_links.setdefault(key, [0, current.st_nlink])
                need(prior[1] == current.st_nlink, 'cache inode link count changed during scan')
                prior[0] += 1
                if key in PROTECTED_ELF_INODES:
                    retained_aliases.append(relative)
                if key not in inodes:
                    inodes.add(key)
                    totals['unique_regular_logical_bytes'] += current.st_size
                    totals['unique_regular_allocated_bytes'] += current.st_blocks * 512
            elif stat.S_ISLNK(mode):
                totals['symlinks'] += 1
            else:
                totals['other_nonregular'] += 1
            if foreign_device or foreign_owner or not (stat.S_ISDIR(mode) or stat.S_ISREG(mode)):
                if len(incidents) < 32:
                    incidents.append(record)
            return not foreign_device and not foreign_owner

        def walk(fd, relative, depth):
            budget()
            need(depth <= 64, 'bounded cache directory depth exceeded')
            before = os.fstat(fd)
            account(relative, before)
            names = []
            with os.scandir(fd) as scan:
                for item in scan:
                    need(len(names) < MAX_TREE_ENTRIES, 'bounded directory entry count exceeded')
                    names.append(item.name)
            for name in sorted(names):
                budget()
                current = os.stat(name, dir_fd=fd, follow_symlinks=False)
                child_relative = name if relative == '.' else relative + '/' + name
                if stat.S_ISDIR(current.st_mode) and current.st_dev == root.st_dev and current.st_uid == OWNER:
                    child = os.open(name, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW | os.O_CLOEXEC,
                                    dir_fd=fd)
                    try:
                        need(metadata_stamp(current) == metadata_stamp(os.fstat(child)), 'cache directory replaced before scan')
                        walk(child, child_relative, depth + 1)
                        need(metadata_stamp(os.fstat(child)) == metadata_stamp(os.stat(name, dir_fd=fd, follow_symlinks=False)),
                             'cache directory path changed during scan')
                    finally:
                        os.close(child)
                else:
                    account(child_relative, current)
            need(metadata_stamp(before) == metadata_stamp(os.fstat(fd)), 'cache directory metadata changed during scan')

        walk(root_fd, '.', 0)
        check_chain(chain)
        need(metadata_stamp(root) == metadata_stamp(os.fstat(root_fd)), 'cache root metadata changed during scan')
        return {'path': path, 'root_identity': metadata_stamp(root), 'realpath_matches_literal': True,
                'counts': totals, 'metadata_sha256': accumulator.hexdigest(),
                'descendants_metadata_sha256': descendants.hexdigest(),
                'external_or_unaccounted_hardlink_inodes': sum(seen != links for seen, links in inode_links.values()),
                'all_regular_links_accounted_within_target': all(seen == links for seen, links in inode_links.values()),
                'retained_qualification_elf_aliases': retained_aliases,
                'anomaly_examples_maximum_32': incidents,
                'foreign_subtrees_and_symlinks_not_followed': True,
                'all_entries_traversed': totals['other_device_entries'] == totals['other_owner_entries'] == 0,
                'started_monotonic_ns': started, 'finished_monotonic_ns': time.monotonic_ns()}
    finally:
        close_chain(chain)

def proc_bytes(fd, name, maximum):
    child = os.open(name, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK | os.O_CLOEXEC, dir_fd=fd)
    try:
        with os.fdopen(os.dup(child), 'rb') as stream:
            raw = stream.read(maximum + 1)
        need(len(raw) <= maximum, 'bounded process metadata exceeded')
        return raw
    finally:
        os.close(child)

def proc_stat(raw, expected_pid):
    closing = raw.rfind(b')')
    need(closing > 0, 'malformed bounded process stat')
    pid = int(raw[:raw.find(b'(')].strip())
    fields = raw[closing + 1:].split()
    need(pid == expected_pid and len(fields) >= 20, 'process stat identity differs')
    state = fields[0].decode('ascii')
    birth = int(fields[19])
    need(len(state) == 1 and birth > 0, 'invalid process state or birth')
    return pid, birth, state

def matches_cache(value, cache, cwd=None):
    # Values remain private to this predicate and are never emitted or hashed.
    value = value.removesuffix(' (deleted)')
    start = 0
    while True:
        pos = value.find(cache, start)
        if pos < 0:
            break
        end = pos + len(cache)
        before_ok = pos == 0 or value[pos - 1] in '=,: \t'
        after_ok = end == len(value) or value[end] == '/'
        if before_ok and after_ok:
            return True
        start = pos + 1
    if cwd and value and not value.startswith('-') and not os.path.isabs(value):
        candidate = os.path.normpath(os.path.join(cwd.removesuffix(' (deleted)'), value))
        return candidate == cache or candidate.startswith(cache + '/')
    return False

def scan_references():
    started = time.monotonic_ns()
    summary = {'scope': ['cwd', 'argv', 'CARGO_TARGET_DIR'], 'started_monotonic_ns': started,
               'processes_enumerated': 0, 'live_processes_examined': 0, 'dead_processes_skipped': 0,
               'vanished_before_live_observation': 0, 'processes_indeterminate': 0,
               'same_owner_processes_indeterminate': 0, 'foreign_owner_processes_indeterminate': 0,
               'unknown_owner_processes_indeterminate': 0,
               'channel_error_counts': {}, 'matched_live_processes': [],
               'unknown_process_examples_maximum_16': [],
               'same_owner_unknown_processes_maximum_32': [], 'complete': False,
               'raw_argv_or_environment_or_unrelated_cwd_emitted': False}
    proc_fd = os.open('/proc', os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW | os.O_CLOEXEC)
    try:
        pids = []
        with os.scandir(proc_fd) as scan:
            for entry in scan:
                if entry.name.isascii() and entry.name.isdecimal():
                    need(len(pids) < MAX_PROCESSES, 'bounded process inventory exceeded')
                    pids.append(int(entry.name))
        summary['processes_enumerated'] = len(pids)
        for pid in sorted(pids):
            budget()
            fd = None
            uid = None
            first = None
            comm = None
            errors = []
            matches = {name: [] for name, _, _ in CACHES}
            try:
                fd = os.open(str(pid), os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW | os.O_CLOEXEC,
                             dir_fd=proc_fd)
                proc_identity = os.fstat(fd)
                uid = proc_identity.st_uid
                first_raw = proc_bytes(fd, 'stat', 16384)
                first = proc_stat(first_raw, pid)
                if uid == OWNER:
                    comm_raw = first_raw[first_raw.find(b'(') + 1:first_raw.rfind(b')')]
                    need(0 < len(comm_raw) <= 256, 'bounded same-owner process comm exceeded')
                    comm = comm_raw.decode('utf-8', errors='backslashreplace')
                del first_raw
                if first[2] in DEAD:
                    summary['dead_processes_skipped'] += 1
                    continue
                summary['live_processes_examined'] += 1
                cwd = None
                try:
                    cwd = os.readlink('cwd', dir_fd=fd)
                    for name, cache, _ in CACHES:
                        if matches_cache(cwd, cache):
                            matches[name].append('cwd')
                except OSError as error:
                    errors.append(('cwd', error.errno))
                try:
                    argv = proc_bytes(fd, 'cmdline', MAX_PROC_BYTES).split(b'\0')
                    for value in argv:
                        token = os.fsdecode(value)
                        for name, cache, _ in CACHES:
                            if matches_cache(token, cache, cwd) and 'argv' not in matches[name]:
                                matches[name].append('argv')
                    del argv
                except OSError as error:
                    errors.append(('argv', error.errno))
                try:
                    environment = proc_bytes(fd, 'environ', MAX_PROC_BYTES)
                    for value in environment.split(b'\0'):
                        if value.startswith(b'CARGO_TARGET_DIR='):
                            target = os.fsdecode(value[len(b'CARGO_TARGET_DIR='):])
                            for name, cache, _ in CACHES:
                                if matches_cache(target, cache, cwd):
                                    matches[name].append('CARGO_TARGET_DIR')
                    del environment
                except OSError as error:
                    errors.append(('CARGO_TARGET_DIR', error.errno))
                second = proc_stat(proc_bytes(fd, 'stat', 16384), pid)
                after = os.fstat(fd)
                linked = os.stat(str(pid), dir_fd=proc_fd, follow_symlinks=False)
                need(first[:2] == second[:2]
                     and (proc_identity.st_dev, proc_identity.st_ino, uid)
                     == (after.st_dev, after.st_ino, after.st_uid)
                     == (linked.st_dev, linked.st_ino, linked.st_uid), 'process identity changed during inspection')
                states = [first[2], second[2]]
            except FileNotFoundError:
                if first is None:
                    summary['vanished_before_live_observation'] += 1
                    continue
                errors.append(('identity_after_live_observation', 2))
                states = [first[2]]
            except OSError as error:
                errors.append(('process_metadata', error.errno))
                states = [first[2]] if first else []
            except (RuntimeError, ValueError, UnicodeError):
                errors.append(('process_identity_or_bounds', None))
                states = [first[2]] if first else []
            finally:
                if fd is not None:
                    os.close(fd)
            selected = {name: channels for name, channels in matches.items() if channels}
            if selected:
                summary['matched_live_processes'].append({'pid': pid, 'uid': uid,
                    'birth_ticks': first[1] if first else None, 'observed_states': states,
                    'cache_reference_channels': selected, 'inspection_complete': not errors})
            if errors:
                summary['processes_indeterminate'] += 1
                category = ('unknown_owner_processes_indeterminate' if uid is None else
                            'same_owner_processes_indeterminate' if uid == OWNER else
                            'foreign_owner_processes_indeterminate')
                summary[category] += 1
                if uid == OWNER and len(summary['same_owner_unknown_processes_maximum_32']) < 32:
                    summary['same_owner_unknown_processes_maximum_32'].append({
                        'pid': pid, 'uid': uid, 'birth_ticks': first[1] if first else None,
                        'comm': comm, 'comm_source': 'first_pid_birth_bound_stat' if comm is not None else None,
                        'observed_states': states, 'inspection_complete': False,
                        'unreadable_or_raced_channels': [
                            {'channel': channel, 'errno': code,
                             'classification': ('permission_denied' if code in (1, 13)
                                                else 'vanished_or_missing' if code == 2
                                                else 'identity_or_bounds' if code is None else 'os_error')}
                            for channel, code in errors]})
                for channel, code in errors:
                    key = channel + ':' + str(code)
                    summary['channel_error_counts'][key] = summary['channel_error_counts'].get(key, 0) + 1
                if len(summary['unknown_process_examples_maximum_16']) < 16:
                    summary['unknown_process_examples_maximum_16'].append({'pid': pid, 'uid': uid,
                        'birth_ticks': first[1] if first else None, 'observed_states': states,
                        'unreadable_or_raced_channels': [channel for channel, _ in errors]})
        summary['same_owner_unknown_examples_truncated'] = (
            summary['same_owner_processes_indeterminate']
            > len(summary['same_owner_unknown_processes_maximum_32']))
        summary['complete'] = summary['processes_indeterminate'] == 0
        summary['all_same_owner_live_process_channels_inspected'] = (
            summary['same_owner_processes_indeterminate'] == 0
            and summary['unknown_owner_processes_indeterminate'] == 0)
        summary['finished_monotonic_ns'] = time.monotonic_ns()
        summary['single_scan_only_no_continuous_liveness_claim'] = True
        return summary
    finally:
        os.close(proc_fd)

def inspect_fixed_directory(path, allow_absent=False):
    try:
        chain = open_directory(path)
    except FileNotFoundError:
        need(allow_absent, 'required fixed directory missing: ' + path)
        return {'path': path, 'exists': False, 'identity': None}
    try:
        value = metadata_stamp(os.fstat(chain[-1]['fd']))
        check_chain(chain)
        return {'path': path, 'exists': True, 'identity': value}
    finally:
        close_chain(chain)

def preserved_elf_metadata(manifest, qualification, ci, summary):
    expected = {value['path']: value['sha256'] for value in qualification['binaries'].values()}
    tests = {row['path']: row['sha256'] for row in summary['binaries']}
    need(len(expected) == 3 and len(tests) == 5 and len(set(expected) | set(tests)) == 8,
         'original retained 3 release plus 5 test ELF set differs')
    expected.update(tests)
    listed = ci['structured_inventory']['binary_paths']
    need(len(listed) == 5 and {r['qualified']['path']: r['qualified']['sha256'] for r in listed.values()} == tests,
         'actual nextest binaries do not bind all five retained qualification copies')
    need(all(r['path'].startswith(CACHE + '/debug/') and r['qualified']['path'].startswith(ROOT28 + '/qualification-01/test-binaries/') for r in listed.values()),
         'original CI or retained ELF path differs')
    omissions = manifest['omissions']
    need(isinstance(omissions, dict) and len(omissions) == 8, 'original eight ELF omissions differ')
    records = {row['identity']['source_path']: row for row in omissions.values()}
    need(set(records) == set(expected), 'exported retained ELF set differs')
    results = []
    for path in sorted(expected):
        budget()
        saved = records[path]
        value = saved['identity']
        need(path.startswith(ROOT28 + '/qualification-01/') and value['is_elf'] is True
             and value['sha256'] == expected[path]
             and saved['reason'] == 'ELF body omitted; complete observed file identity retained',
             'original full-export ELF identity differs')
        chain = open_directory(os.path.dirname(path))
        fd = None
        try:
            parent = chain[-1]['fd']
            fd = os.open(os.path.basename(path), os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK | os.O_CLOEXEC, dir_fd=parent)
            current = os.fstat(fd)
            need(stat.S_ISREG(current.st_mode) and current.st_uid == OWNER and current.st_nlink == 1
                 and current.st_size == value['bytes'] and {k: getattr(current, k) for k in EXPORT_FIELDS} == value['original_identity'],
                 'retained ELF metadata differs from original SHA-bound export: ' + path)
            need(metadata_stamp(current) == metadata_stamp(os.fstat(fd)) == metadata_stamp(os.stat(os.path.basename(path), dir_fd=parent, follow_symlinks=False)),
                 'retained ELF descriptor or path changed')
            check_chain(chain)
            PROTECTED_ELF_INODES.add((current.st_dev, current.st_ino))
            results.append({'path': path, 'bytes': value['bytes'], 'exported_sha256': value['sha256'],
                            'current_identity': metadata_stamp(current), 'full_export_identity_unchanged': True,
                            'sha256_recomputed_by_this_metadata_probe': False, 'payload_read_bytes': 0})
        finally:
            if fd is not None:
                os.close(fd)
            close_chain(chain)
    return results

