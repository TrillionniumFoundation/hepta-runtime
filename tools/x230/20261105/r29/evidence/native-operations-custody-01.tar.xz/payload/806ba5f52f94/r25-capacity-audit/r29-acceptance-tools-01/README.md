# R29 acceptance templates

These local templates derive the original R28 observation, lifecycle and saturation route from its actual 50-file installation. No host action, workload, test or archived code was executed. The comparison baseline remains accepted R24; the source parent is qualified but unadopted R28, whose observation rejection remains preserved.

The shared R29 qualification validator is embedded byte-for-byte in the observation parent and installer template. Its two final entry/input identities remain None and reject all invocations. The final reviewed canonical function must be substituted exactly before freezing deployment files. Runtime qualification, formatted source, native job, binary identities, CI, installation and performance results remain unknown.

The six-receipt interface is recorded in acceptance-interface-01.json. The original observation input preparer accepts five explicit arguments; lifecycle preparation still requires a successful completed observation including its gate and compiler monitor. Lifecycle owns the original 14 helper tests, normal ABBA and required gates, then saturation and required gates. No separate saturation dispatch is introduced.

All five shared monitor/summary files and 24 native payloads are byte-identical. Only the three native fixed-root guards move to R29; the four outer paths and shared qualification binding move to R29. Both owned run_stage functions retain identical AST. No six-host or six-fixture count is changed. The candidate changes two paths relative to actual R28, eight paths relative to accepted R24 (including one added source file).

The two holder request templates preserve the original Mac holder, its 3600-second deadline and 3900-second native timeout. They are not launch authorization or proof of readiness. Original data-only installer custody/extraction is retained; its ARCHIVES and materializer installer SHA remain unbound. No archive, binary_write payload or executable installation request is produced at this template stage.

A local construction assertion initially assumed R24 also had 221 entries; the actual map has 220. The failed construction and two preliminary never-executed source versions are retained under draft-construction-01. The final source comparison counts the union of map keys, and canonical historical R28 literals are preserved exactly.
