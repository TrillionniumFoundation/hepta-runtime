"""Read only one fixed R28 cached ELF and its retained qualification copy."""
import hashlib
import json
import os
from pathlib import Path
import stat
import sys
import time

ROOT = "/home/qian/hepta-runtime-optimization-20261105-r28"
NAME = "hepta_runtime-1b8b761b89392e3b"
FILES = (("cache", ROOT + "/target-build/debug/deps/" + NAME),
         ("retained", ROOT + "/qualification-01/test-binaries/" + NAME))
EXPECTED_BYTES = 542867656
EXPECTED_SHA256 = "6bdc7febf11b0f41d64ae2c36f78f690309e0345729b147a73b1b2662fe15360"
FIELDS = ("st_dev", "st_ino", "st_mode", "st_uid", "st_gid", "st_nlink",
          "st_size", "st_mtime_ns", "st_ctime_ns", "st_blocks")
DIR_FIELDS = ("st_dev", "st_ino", "st_mode", "st_uid", "st_gid")


def need(value, message):
    if not value:
        raise RuntimeError(message)


def stamp(value, fields=FIELDS):
    return {key: getattr(value, key) for key in fields}


def disk():
    value = os.statvfs("/home/qian")
    return {"available_bytes": value.f_bavail * value.f_frsize,
            "unchanged_required_reserve_bytes": 3221225472}


def parent_fd(path, directories):
    current = Path("/")
    fd = os.open("/", os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW | os.O_CLOEXEC)
    directories.append((str(current), fd, stamp(os.fstat(fd), DIR_FIELDS)))
    for component in Path(path).parent.parts[1:]:
        fd = os.open(component, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW | os.O_CLOEXEC, dir_fd=fd)
        current = current / component
        value = os.fstat(fd)
        original = stamp(value, DIR_FIELDS)
        directories.append((str(current), fd, original))
        need(stat.S_ISDIR(value.st_mode) and value.st_uid in (0, 1000)
             and value.st_mode & 0o022 == 0
             and original == stamp(os.stat(current, follow_symlinks=False), DIR_FIELDS),
             "fixed directory ownership, mode or linked descriptor differs")
    need(os.fstat(fd).st_uid == 1000, "fixed task directory must be owned by UID 1000")
    return fd


def inspect(role, path, directories, retained):
    row = {"role": role, "path": path, "exists": False, "full_sha256_recomputed": False}
    try:
        directory = parent_fd(path, directories)
        before_path = os.stat(NAME, dir_fd=directory, follow_symlinks=False)
        row.update(exists=True, path_identity_before=stamp(before_path),
                   regular=stat.S_ISREG(before_path.st_mode),
                   allocated_bytes_from_st_blocks=before_path.st_blocks * 512)
        need(stat.S_ISREG(before_path.st_mode) and before_path.st_uid == 1000,
             "fixed ELF is not a regular file owned by UID 1000")
        need(before_path.st_size == EXPECTED_BYTES, "fixed ELF length differs; do not perform an unbounded read")
        fd = os.open(NAME, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK | os.O_CLOEXEC, dir_fd=directory)
        retained.append((role, path, directory, fd, row))
        before = stamp(os.fstat(fd))
        need(before == row["path_identity_before"], "fixed ELF changed while opening its descriptor")
        hasher, size, prefix = hashlib.sha256(), 0, b""
        while block := os.read(fd, min(1024 * 1024, EXPECTED_BYTES - size + 1)):
            if not prefix:
                prefix = block[:4]
            size += len(block)
            need(size <= EXPECTED_BYTES, "fixed ELF grew during full hash")
            hasher.update(block)
        row.update(bytes=size, sha256=hasher.hexdigest(), full_sha256_recomputed=True,
                   elf_magic=prefix == b"\x7fELF", descriptor_identity_before=before,
                   descriptor_identity_after=stamp(os.fstat(fd)),
                   path_identity_after=stamp(os.stat(NAME, dir_fd=directory, follow_symlinks=False)))
        row["descriptor_and_path_stable"] = before == row["descriptor_identity_after"] == row["path_identity_after"]
        row["matches_original_retained_sha_and_bytes"] = size == EXPECTED_BYTES and hasher.hexdigest() == EXPECTED_SHA256
        row["single_link"] = before["st_nlink"] == 1
        need(row["descriptor_and_path_stable"] and row["elf_magic"], "fixed ELF identity or magic differs")
    except FileNotFoundError as error:
        row["error"] = {"type": type(error).__name__, "reason": str(error)}
    except Exception as error:
        row["error"] = {"type": type(error).__name__, "reason": str(error)[:2000]}
    return row


def main():
    directories, retained = [], []
    report = {"schema": "hepta-r29-fixed-elf-pair-readonly/v1", "passed": False,
              "read_only": True, "files_created_or_deleted": 0, "automatic_retries": 0,
              "directories_enumerated": 0, "proc_argv_environment_or_other_task_files_read": False,
              "expected_bytes": EXPECTED_BYTES, "expected_sha256": EXPECTED_SHA256,
              "started_monotonic_ns": time.monotonic_ns(), "files": [],
              "current_process_references_not_assessed": True,
              "cleanup_authorized_by_this_report": False, "reclaimable_bytes_established": False}
    try:
        need(sys.platform == "linux" and os.geteuid() == 1000, "fixed native Linux operator required")
        report["disk_before"] = disk()
        report["files"] = [inspect(role, path, directories, retained) for role, path in FILES]
        for path, fd, original in directories:
            need(original == stamp(os.fstat(fd), DIR_FIELDS)
                 == stamp(os.stat(path, follow_symlinks=False), DIR_FIELDS), "fixed directory changed")
        report["directories"] = [{"path": path, "identity": original} for path, _, original in directories]
        for role, path, directory, fd, row in retained:
            row["final_descriptor_identity"] = stamp(os.fstat(fd))
            row["final_path_identity"] = stamp(os.stat(NAME, dir_fd=directory, follow_symlinks=False))
            row["stable_after_both_full_reads"] = (row.get("descriptor_identity_before")
                == row["final_descriptor_identity"] == row["final_path_identity"])
        cache, copy = report["files"]
        complete = all(row.get("full_sha256_recomputed") is True
                       and row.get("stable_after_both_full_reads") is True
                       and row.get("matches_original_retained_sha_and_bytes") is True
                       and row.get("elf_magic") is True and "error" not in row for row in (cache, copy))
        report["both_complete_stable_expected_sha_and_bytes"] = complete
        report["distinct_inodes"] = (complete and
            (cache["final_descriptor_identity"]["st_dev"], cache["final_descriptor_identity"]["st_ino"])
            != (copy["final_descriptor_identity"]["st_dev"], copy["final_descriptor_identity"]["st_ino"]))
        report["both_single_link"] = complete and all(row["single_link"] for row in (cache, copy))
        report["exact_duplicate_with_two_single_link_inodes_observed"] = (
            complete and report["distinct_inodes"] and report["both_single_link"])
        report["passed"] = complete
        report["disk_after"] = disk()
    except Exception as error:
        report["passed"] = False
        report["error"] = {"type": type(error).__name__, "reason": str(error)[:2000]}
    finally:
        for _, _, _, fd, _ in reversed(retained):
            os.close(fd)
        for _, fd, _ in reversed(directories):
            os.close(fd)
        report["finished_monotonic_ns"] = time.monotonic_ns()
        print(json.dumps(report, sort_keys=True, separators=(",", ":"), allow_nan=False), flush=True)
    return 0 if report["passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
