#!/usr/bin/env python3
"""Read-only R28-owned Cargo target metadata for a possible later R29 transfer.
No rename, deletion, chmod, process launch, file write, lock acquisition or cache-file payload read.
This point-in-time report never grants transfer or declares all writers absent.
"""
import hashlib
import json
import os
import stat
import sys
import time

ROOT24 = '/home/qian/hepta-runtime-optimization-20261105-r24'
ROOT26 = '/home/qian/hepta-runtime-optimization-20261105-r26'
ROOT28 = '/home/qian/hepta-runtime-optimization-20261105-r28'
ROOT29 = '/home/qian/hepta-runtime-optimization-20261105-r29'
CACHE = ROOT28 + '/target-build'
OWNER = 1000
CACHES = (('owned_r28_target', CACHE, False),)
FIELDS = ('st_dev', 'st_ino', 'st_uid', 'st_gid', 'st_mode', 'st_nlink', 'st_size', 'st_mtime_ns', 'st_ctime_ns')
EXPORT_FIELDS = ('st_dev', 'st_ino', 'st_uid', 'st_mode', 'st_nlink', 'st_size', 'st_mtime_ns', 'st_ctime_ns')
DEAD = {'Z', 'X', 'x'}
START = time.monotonic_ns()
MAX_DURATION_NS = 120 * 10**9
MAX_TREE_ENTRIES = 200000
MAX_PROCESSES = 16384
MAX_PROC_BYTES = 1048576
PROTECTED_ELF_INODES = set()
RESERVE_BYTES = 3 * 1024**3
BOUND = {'preparation': ('/home/qian/hepta-runtime-optimization-20261105-r28/preparation-02.json', 96494, '4ece02608c423456d0996de39c54129c6c759a1973a0e11f22b04f936b113cc3'), 'qualification': ('/home/qian/hepta-runtime-optimization-20261105-r28/qualification-01/report.json', 83735, '9e564f3950575313034f55974303e56c236ac030e2c5f121d49791da0c4c09fa'), 'qualified_source_map': ('/home/qian/hepta-runtime-optimization-20261105-r28/qualification-01/source-map.json', 24278, 'da8cbdfef75c1c9fc5861e4fe0bd96aeb98f635e95fc122610021cd725db1d28'), 'isolated_summary': ('/home/qian/hepta-runtime-optimization-20261105-r28/qualification-01/isolated-tests/summary.json', 6878, 'a6645dbb6a0208fdbca1a3dd6308c55f7d6b876ef4ddf70f02a2b4c58c9db46d'), 'rust_ci': ('/home/qian/hepta-runtime-optimization-20261105-r28/rust-ci-01/report.json', 14131, '89478d995d449181fb8066165c0802f8d11770254b9deea13bc3b28c8f5e3dbc'), 'qc_export': ('/home/qian/hepta-runtime-optimization-20261105-r28/qualification-ci-evidence-01/report.json', 11627, 'e150979b4024edf8c82450b6c18beb7492306928f7f61a3b8247e4977e7862d0'), 'qc_manifest': ('/home/qian/hepta-runtime-optimization-20261105-r28/qualification-ci-evidence-01/manifest.json', 2745831, '9ed5ce8099685e6fff9e1f0ecb2b7b980f6e2dc410cf2413bd189d72a8395a9d')}

def need(value, reason):
    if not value:
        raise RuntimeError(reason)

def budget():
    need(time.monotonic_ns() - START <= MAX_DURATION_NS, 'bounded inventory duration exceeded')

def stamp(value):
    return {key: getattr(value, key) for key in FIELDS}

def directory_id(value):
    need(stat.S_ISDIR(value.st_mode), 'fixed path is not a directory')
    return (value.st_dev, value.st_ino, value.st_uid, value.st_mode)

def check_chain(chain):
    for item in chain:
        linked = (os.lstat('/') if item['parent'] is None else
                  os.stat(item['name'], dir_fd=item['parent'], follow_symlinks=False))
        need(directory_id(os.fstat(item['fd'])) == item['identity'] == directory_id(linked),
             'fixed directory chain changed')

def close_chain(chain):
    for item in reversed(chain):
        os.close(item['fd'])

def open_directory(path):
    need(path.startswith('/home/qian/') and os.path.normpath(path) == path,
         'directory outside exact task parent')
    chain = []
    try:
        for number, name in enumerate(('/', *path.split('/')[1:])):
            parent = chain[-1]['fd'] if chain else None
            fd = os.open(name, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW | os.O_CLOEXEC,
                         **({'dir_fd': parent} if parent is not None else {}))
            item = {'fd': fd, 'parent': parent, 'name': name}
            chain.append(item)
            item['identity'] = directory_id(os.fstat(fd))
            need(item['identity'][2] == (0 if number < 2 else OWNER), 'fixed directory owner differs')
            check_chain(chain)
        need(os.path.realpath(path) == path, 'fixed root realpath differs')
        return chain
    except BaseException:
        close_chain(chain)
        raise

def read_bound(spec):
    path, size, expected_sha = spec
    chain = open_directory(os.path.dirname(path))
    fd = None
    try:
        owner_fd = chain[-1]['fd']
        fd = os.open(os.path.basename(path), os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK | os.O_CLOEXEC,
                     dir_fd=owner_fd)
        before = os.fstat(fd)
        need(stat.S_ISREG(before.st_mode) and before.st_uid == OWNER and before.st_nlink == 1
             and before.st_size == size <= 4 * 1048576, 'fixed evidence file metadata differs')
        with os.fdopen(os.dup(fd), 'rb') as stream:
            raw = stream.read(size + 1)
        actual_sha = hashlib.sha256(raw).hexdigest()
        need(len(raw) == size and actual_sha == expected_sha
             and stamp(before) == stamp(os.fstat(fd))
             == stamp(os.stat(os.path.basename(path), dir_fd=owner_fd, follow_symlinks=False)),
             'fixed evidence bytes or descriptor changed')
        check_chain(chain)
        return {'path': path, 'bytes': size, 'sha256': actual_sha, 'identity': stamp(before)}, json.loads(raw)
    finally:
        if fd is not None:
            os.close(fd)
        close_chain(chain)

def inventory_tree(path):
    chain = open_directory(path)
    started = time.monotonic_ns()
    try:
        root_fd = chain[-1]['fd']
        root = os.fstat(root_fd)
        totals = {'entries': 0, 'directories_including_root': 0, 'directory_logical_bytes': 0,
                  'directory_allocated_bytes': 0, 'regular_files': 0,
                  'regular_logical_bytes': 0, 'unique_regular_logical_bytes': 0,
                  'unique_regular_allocated_bytes': 0, 'symlinks': 0, 'other_nonregular': 0,
                  'other_device_entries': 0, 'other_owner_entries': 0, 'multiply_linked_regular_files': 0}
        incidents, inodes = [], set()
        inode_links, retained_aliases = {}, []
        accumulator = hashlib.sha256()

        def account(relative, current):
            budget()
            totals['entries'] += 1
            need(totals['entries'] <= MAX_TREE_ENTRIES, 'bounded cache entry count exceeded')
            record = {'relative': relative, 'identity': stamp(current), 'st_blocks': current.st_blocks}
            accumulator.update((json.dumps(record, sort_keys=True, separators=(',', ':')) + '\n').encode())
            foreign_device = current.st_dev != root.st_dev
            foreign_owner = current.st_uid != OWNER
            totals['other_device_entries'] += int(foreign_device)
            totals['other_owner_entries'] += int(foreign_owner)
            mode = current.st_mode
            if stat.S_ISDIR(mode):
                totals['directories_including_root'] += 1
                totals['directory_logical_bytes'] += current.st_size
                totals['directory_allocated_bytes'] += current.st_blocks * 512
            elif stat.S_ISREG(mode):
                totals['regular_files'] += 1
                totals['regular_logical_bytes'] += current.st_size
                totals['multiply_linked_regular_files'] += int(current.st_nlink != 1)
                key = (current.st_dev, current.st_ino)
                prior = inode_links.setdefault(key, [0, current.st_nlink])
                need(prior[1] == current.st_nlink, 'cache inode link count changed during scan')
                prior[0] += 1
                if key in PROTECTED_ELF_INODES:
                    retained_aliases.append(relative)
                if key not in inodes:
                    inodes.add(key)
                    totals['unique_regular_logical_bytes'] += current.st_size
                    totals['unique_regular_allocated_bytes'] += current.st_blocks * 512
            elif stat.S_ISLNK(mode):
                totals['symlinks'] += 1
            else:
                totals['other_nonregular'] += 1
            if foreign_device or foreign_owner or not (stat.S_ISDIR(mode) or stat.S_ISREG(mode)):
                if len(incidents) < 32:
                    incidents.append(record)
            return not foreign_device and not foreign_owner

        def walk(fd, relative, depth):
            budget()
            need(depth <= 64, 'bounded cache directory depth exceeded')
            before = os.fstat(fd)
            account(relative, before)
            names = []
            with os.scandir(fd) as scan:
                for item in scan:
                    need(len(names) < MAX_TREE_ENTRIES, 'bounded directory entry count exceeded')
                    names.append(item.name)
            for name in sorted(names):
                budget()
                current = os.stat(name, dir_fd=fd, follow_symlinks=False)
                child_relative = name if relative == '.' else relative + '/' + name
                if stat.S_ISDIR(current.st_mode) and current.st_dev == root.st_dev and current.st_uid == OWNER:
                    child = os.open(name, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW | os.O_CLOEXEC,
                                    dir_fd=fd)
                    try:
                        need(stamp(current) == stamp(os.fstat(child)), 'cache directory replaced before scan')
                        walk(child, child_relative, depth + 1)
                        need(stamp(os.fstat(child)) == stamp(os.stat(name, dir_fd=fd, follow_symlinks=False)),
                             'cache directory path changed during scan')
                    finally:
                        os.close(child)
                else:
                    account(child_relative, current)
            need(stamp(before) == stamp(os.fstat(fd)), 'cache directory metadata changed during scan')

        walk(root_fd, '.', 0)
        check_chain(chain)
        need(stamp(root) == stamp(os.fstat(root_fd)), 'cache root metadata changed during scan')
        return {'path': path, 'root_identity': stamp(root), 'realpath_matches_literal': True,
                'counts': totals, 'metadata_sha256': accumulator.hexdigest(),
                'external_or_unaccounted_hardlink_inodes': sum(seen != links for seen, links in inode_links.values()),
                'all_regular_links_accounted_within_target': all(seen == links for seen, links in inode_links.values()),
                'retained_qualification_elf_aliases': retained_aliases,
                'anomaly_examples_maximum_32': incidents,
                'foreign_subtrees_and_symlinks_not_followed': True,
                'all_entries_traversed': totals['other_device_entries'] == totals['other_owner_entries'] == 0,
                'started_monotonic_ns': started, 'finished_monotonic_ns': time.monotonic_ns()}
    finally:
        close_chain(chain)

def proc_bytes(fd, name, maximum):
    child = os.open(name, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK | os.O_CLOEXEC, dir_fd=fd)
    try:
        with os.fdopen(os.dup(child), 'rb') as stream:
            raw = stream.read(maximum + 1)
        need(len(raw) <= maximum, 'bounded process metadata exceeded')
        return raw
    finally:
        os.close(child)

def proc_stat(raw, expected_pid):
    closing = raw.rfind(b')')
    need(closing > 0, 'malformed bounded process stat')
    pid = int(raw[:raw.find(b'(')].strip())
    fields = raw[closing + 1:].split()
    need(pid == expected_pid and len(fields) >= 20, 'process stat identity differs')
    state = fields[0].decode('ascii')
    birth = int(fields[19])
    need(len(state) == 1 and birth > 0, 'invalid process state or birth')
    return pid, birth, state

def matches_cache(value, cache, cwd=None):
    # Values remain private to this predicate and are never emitted or hashed.
    value = value.removesuffix(' (deleted)')
    start = 0
    while True:
        pos = value.find(cache, start)
        if pos < 0:
            break
        end = pos + len(cache)
        before_ok = pos == 0 or value[pos - 1] in '=,: \t'
        after_ok = end == len(value) or value[end] == '/'
        if before_ok and after_ok:
            return True
        start = pos + 1
    if cwd and value and not value.startswith('-') and not os.path.isabs(value):
        candidate = os.path.normpath(os.path.join(cwd.removesuffix(' (deleted)'), value))
        return candidate == cache or candidate.startswith(cache + '/')
    return False

def scan_references():
    started = time.monotonic_ns()
    summary = {'scope': ['cwd', 'argv', 'CARGO_TARGET_DIR'], 'started_monotonic_ns': started,
               'processes_enumerated': 0, 'live_processes_examined': 0, 'dead_processes_skipped': 0,
               'vanished_before_live_observation': 0, 'processes_indeterminate': 0,
               'same_owner_processes_indeterminate': 0, 'foreign_owner_processes_indeterminate': 0,
               'unknown_owner_processes_indeterminate': 0,
               'channel_error_counts': {}, 'matched_live_processes': [],
               'unknown_process_examples_maximum_16': [], 'complete': False,
               'raw_argv_or_environment_or_unrelated_cwd_emitted': False}
    proc_fd = os.open('/proc', os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW | os.O_CLOEXEC)
    try:
        pids = []
        with os.scandir(proc_fd) as scan:
            for entry in scan:
                if entry.name.isascii() and entry.name.isdecimal():
                    need(len(pids) < MAX_PROCESSES, 'bounded process inventory exceeded')
                    pids.append(int(entry.name))
        summary['processes_enumerated'] = len(pids)
        for pid in sorted(pids):
            budget()
            fd = None
            uid = None
            first = None
            errors = []
            matches = {name: [] for name, _, _ in CACHES}
            try:
                fd = os.open(str(pid), os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW | os.O_CLOEXEC,
                             dir_fd=proc_fd)
                proc_identity = os.fstat(fd)
                uid = proc_identity.st_uid
                first = proc_stat(proc_bytes(fd, 'stat', 16384), pid)
                if first[2] in DEAD:
                    summary['dead_processes_skipped'] += 1
                    continue
                summary['live_processes_examined'] += 1
                cwd = None
                try:
                    cwd = os.readlink('cwd', dir_fd=fd)
                    for name, cache, _ in CACHES:
                        if matches_cache(cwd, cache):
                            matches[name].append('cwd')
                except OSError as error:
                    errors.append(('cwd', error.errno))
                try:
                    argv = proc_bytes(fd, 'cmdline', MAX_PROC_BYTES).split(b'\0')
                    for value in argv:
                        token = os.fsdecode(value)
                        for name, cache, _ in CACHES:
                            if matches_cache(token, cache, cwd) and 'argv' not in matches[name]:
                                matches[name].append('argv')
                    del argv
                except OSError as error:
                    errors.append(('argv', error.errno))
                try:
                    environment = proc_bytes(fd, 'environ', MAX_PROC_BYTES)
                    for value in environment.split(b'\0'):
                        if value.startswith(b'CARGO_TARGET_DIR='):
                            target = os.fsdecode(value[len(b'CARGO_TARGET_DIR='):])
                            for name, cache, _ in CACHES:
                                if matches_cache(target, cache, cwd):
                                    matches[name].append('CARGO_TARGET_DIR')
                    del environment
                except OSError as error:
                    errors.append(('CARGO_TARGET_DIR', error.errno))
                second = proc_stat(proc_bytes(fd, 'stat', 16384), pid)
                after = os.fstat(fd)
                linked = os.stat(str(pid), dir_fd=proc_fd, follow_symlinks=False)
                need(first[:2] == second[:2]
                     and (proc_identity.st_dev, proc_identity.st_ino, uid)
                     == (after.st_dev, after.st_ino, after.st_uid)
                     == (linked.st_dev, linked.st_ino, linked.st_uid), 'process identity changed during inspection')
                states = [first[2], second[2]]
            except FileNotFoundError:
                if first is None:
                    summary['vanished_before_live_observation'] += 1
                    continue
                errors.append(('identity_after_live_observation', 2))
                states = [first[2]]
            except OSError as error:
                errors.append(('process_metadata', error.errno))
                states = [first[2]] if first else []
            except (RuntimeError, ValueError, UnicodeError):
                errors.append(('process_identity_or_bounds', None))
                states = [first[2]] if first else []
            finally:
                if fd is not None:
                    os.close(fd)
            selected = {name: channels for name, channels in matches.items() if channels}
            if selected:
                summary['matched_live_processes'].append({'pid': pid, 'uid': uid,
                    'birth_ticks': first[1] if first else None, 'observed_states': states,
                    'cache_reference_channels': selected, 'inspection_complete': not errors})
            if errors:
                summary['processes_indeterminate'] += 1
                category = ('unknown_owner_processes_indeterminate' if uid is None else
                            'same_owner_processes_indeterminate' if uid == OWNER else
                            'foreign_owner_processes_indeterminate')
                summary[category] += 1
                for channel, code in errors:
                    key = channel + ':' + str(code)
                    summary['channel_error_counts'][key] = summary['channel_error_counts'].get(key, 0) + 1
                if len(summary['unknown_process_examples_maximum_16']) < 16:
                    summary['unknown_process_examples_maximum_16'].append({'pid': pid, 'uid': uid,
                        'birth_ticks': first[1] if first else None, 'observed_states': states,
                        'unreadable_or_raced_channels': [channel for channel, _ in errors]})
        summary['complete'] = summary['processes_indeterminate'] == 0
        summary['all_same_owner_live_process_channels_inspected'] = (
            summary['same_owner_processes_indeterminate'] == 0
            and summary['unknown_owner_processes_indeterminate'] == 0)
        summary['finished_monotonic_ns'] = time.monotonic_ns()
        summary['single_scan_only_no_continuous_liveness_claim'] = True
        return summary
    finally:
        os.close(proc_fd)


def inspect_fixed_directory(path, allow_absent=False):
    try:
        chain = open_directory(path)
    except FileNotFoundError:
        need(allow_absent, 'required fixed directory missing: ' + path)
        return {'path': path, 'exists': False, 'identity': None}
    try:
        value = stamp(os.fstat(chain[-1]['fd']))
        check_chain(chain)
        return {'path': path, 'exists': True, 'identity': value}
    finally:
        close_chain(chain)


def preserved_elf_metadata(manifest, qualification, ci, summary):
    expected = {value['path']: value['sha256'] for value in qualification['binaries'].values()}
    tests = {row['path']: row['sha256'] for row in summary['binaries']}
    need(len(expected) == 3 and len(tests) == 5 and len(set(expected) | set(tests)) == 8,
         'original retained 3 release plus 5 test ELF set differs')
    expected.update(tests)
    listed = ci['structured_inventory']['binary_paths']
    need(len(listed) == 5 and {r['qualified']['path']: r['qualified']['sha256'] for r in listed.values()} == tests,
         'actual nextest binaries do not bind all five retained qualification copies')
    need(all(r['path'].startswith(CACHE + '/debug/') and r['qualified']['path'].startswith(ROOT28 + '/qualification-01/test-binaries/') for r in listed.values()),
         'original CI or retained ELF path differs')
    omissions = manifest['omissions']
    need(isinstance(omissions, dict) and len(omissions) == 8, 'original eight ELF omissions differ')
    records = {row['identity']['source_path']: row for row in omissions.values()}
    need(set(records) == set(expected), 'exported retained ELF set differs')
    results = []
    for path in sorted(expected):
        budget()
        saved = records[path]
        value = saved['identity']
        need(path.startswith(ROOT28 + '/qualification-01/') and value['is_elf'] is True
             and value['sha256'] == expected[path]
             and saved['reason'] == 'ELF body omitted; complete observed file identity retained',
             'original full-export ELF identity differs')
        chain = open_directory(os.path.dirname(path))
        fd = None
        try:
            parent = chain[-1]['fd']
            fd = os.open(os.path.basename(path), os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK | os.O_CLOEXEC, dir_fd=parent)
            current = os.fstat(fd)
            need(stat.S_ISREG(current.st_mode) and current.st_uid == OWNER and current.st_nlink == 1
                 and current.st_size == value['bytes'] and {k: getattr(current, k) for k in EXPORT_FIELDS} == value['original_identity'],
                 'retained ELF metadata differs from original SHA-bound export: ' + path)
            need(stamp(current) == stamp(os.fstat(fd)) == stamp(os.stat(os.path.basename(path), dir_fd=parent, follow_symlinks=False)),
                 'retained ELF descriptor or path changed')
            check_chain(chain)
            PROTECTED_ELF_INODES.add((current.st_dev, current.st_ino))
            results.append({'path': path, 'bytes': value['bytes'], 'exported_sha256': value['sha256'],
                            'current_identity': stamp(current), 'full_export_identity_unchanged': True,
                            'sha256_recomputed_by_this_metadata_probe': False, 'payload_read_bytes': 0})
        finally:
            if fd is not None:
                os.close(fd)
            close_chain(chain)
    return results


report = {'schema': 'hepta-r28-owned-target-readonly-review/v1', 'passed': False,
          'read_only': True, 'started_unix_ns': time.time_ns(), 'bound_inputs': {},
          'files_created_or_deleted': 0, 'rename_executed': False, 'cleanup_executed': False,
          'compilers_or_workloads_started': False, 'cache_file_payload_read_bytes': 0,
          'transfer_authorized_by_this_report': False, 'transfer_eligibility_established': False,
          'protected_roots': [ROOT24, ROOT26, ROOT28 + '/source', ROOT28 + '/qualification-01', ROOT28 + '/rust-ci-01', ROOT28 + '/qualification-ci-evidence-01'],
          'point_in_time_metadata_only': True, 'future_target': ROOT29 + '/target-build'}
cpu_start = time.process_time_ns()
try:
    need(sys.platform == 'linux' and os.geteuid() == OWNER, 'fixed native Linux operator required')
    documents = {}
    for name, spec in BOUND.items():
        ident, value = read_bound(spec)
        report['bound_inputs'][name] = ident
        documents[name] = value
    prep, qualified, ci, summary, exported, manifest = (documents[k] for k in
        ('preparation', 'qualification', 'rust_ci', 'isolated_summary', 'qc_export', 'qc_manifest'))
    need(prep['passed'] is True and prep['candidate_qualified'] is True and prep['target'] == CACHE
         and prep['source'] == ROOT28 + '/source' and prep['cache_source'] == ROOT26 + '/target-build'
         and prep['shared_hardlinks_created'] is False, 'actual private R28 cache provenance differs')
    need(qualified['qualified'] is True and len(qualified['stages']) == 8
         and all(s['returncode'] == 0 for s in qualified['stages'])
         and qualified['source_after'] == qualified['source_tested'] == documents['qualified_source_map']
         and len(qualified['source_after']) == 221, 'actual completed R28 qualification differs')
    need(ci['passed'] is True and ci['owned_children_closed'] is True and ci['source_inputs_unchanged'] is True
         and ci['explicit_environment']['CARGO_TARGET_DIR'] == CACHE
         and len(ci['stages']) == 6
         and all(s['returncode'] == 0 and s['waited_and_reaped'] is True and s['owned_process_absent'] is True
                 and s['owned_process_group_absent'] is True for s in ci['stages']), 'actual completed Rust CI custody differs')
    need(exported['passed'] is True and exported['original_inputs_unchanged'] is True
         and exported['archive']['verified'] is True and exported['omission_count'] == 8
         and manifest['compiler_cache_body_outside_scope'] == CACHE
         and exported['manifest']['sha256'] == BOUND['qc_manifest'][2], 'actual full QC export binding differs')
    report['original_cache_writer_reports'] = {'qualification_complete': True, 'rust_ci_complete': True,
        'known_ci_children_waited_and_reaped': True, 'reports_do_not_prove_current_global_quiescence': True}
    report['protected_directories'] = [inspect_fixed_directory(path) for path in report['protected_roots']]
    report['retained_elf_copies_before'] = preserved_elf_metadata(manifest, qualified, ci, summary)
    report['future_root'] = inspect_fixed_directory(ROOT29, allow_absent=True)
    report['future_target_metadata'] = inspect_fixed_directory(ROOT29 + '/target-build', allow_absent=True)
    report['process_reference_scans'] = [scan_references()]
    report['cache_passes'] = [inventory_tree(CACHE), inventory_tree(CACHE)]
    first, second = report['cache_passes']
    stable_keys = ('path', 'root_identity', 'counts', 'metadata_sha256', 'all_entries_traversed',
                   'all_regular_links_accounted_within_target', 'external_or_unaccounted_hardlink_inodes',
                   'retained_qualification_elf_aliases')
    report['cache_metadata_stable_across_two_passes'] = all(first[k] == second[k] for k in stable_keys)
    need(report['cache_metadata_stable_across_two_passes'], 'R28 cache metadata changed between complete passes')
    report['process_reference_scans'].append(scan_references())
    report['retained_elf_copies_after'] = preserved_elf_metadata(manifest, qualified, ci, summary)
    need(report['retained_elf_copies_before'] == report['retained_elf_copies_after'], 'protected retained ELF metadata changed')
    for name, spec in BOUND.items():
        identity, _ = read_bound(spec)
        need(identity == report['bound_inputs'][name], 'bound original evidence changed: ' + name)
    home = open_directory('/home/qian')
    try:
        target_parent_device = (report['future_root']['identity']['st_dev'] if report['future_root']['exists']
                                else os.fstat(home[-1]['fd']).st_dev)
        disk = os.fstatvfs(home[-1]['fd'])
        check_chain(home)
    finally:
        close_chain(home)
    available = disk.f_bavail * disk.f_frsize
    cache_bytes = second['counts']['regular_logical_bytes']
    report['space'] = {'available_bytes': available, 'available_blocks': disk.f_bavail,
        'filesystem_fragment_size': disk.f_frsize, 'available_inodes': disk.f_favail,
        'unchanged_required_headroom_bytes': RESERVE_BYTES,
        'cache_regular_logical_bytes': cache_bytes,
        'cache_unique_allocated_bytes': second['counts']['unique_regular_allocated_bytes'],
        'same_filesystem_parent': target_parent_device == second['root_identity']['st_dev'],
        'move_only_extra_full_cache_copy_bytes': 0,
        'headroom_after_move_only_before_future_source_or_outputs': available - RESERVE_BYTES,
        'original_copy_path_required_available_bytes': cache_bytes + RESERVE_BYTES,
        'original_copy_path_satisfied_now': available >= cache_bytes + RESERVE_BYTES,
        'move_does_not_free_bytes': True, 'future_build_growth_bytes_unknown': True}
    report['current_reference_observed'] = any(s['matched_live_processes'] for s in report['process_reference_scans'])
    report['same_owner_channels_complete_in_both_snapshots'] = all(s['all_same_owner_live_process_channels_inspected'] for s in report['process_reference_scans'])
    report['reference_scan_limits'] = 'Original bounded cwd/argv/CARGO_TARGET_DIR channels only; fd/mmap and future writers are not covered. Unknowns remain unknown. No all-writers-absent or continuous-quiet claim.'
    report['original_evidence_files_unchanged'] = True
    report['protected_elf_original_export_metadata_unchanged'] = True
    report['passed'] = True
except BaseException as error:
    report['error'] = {'type': type(error).__name__, 'message': str(error)}
finally:
    report['finished_unix_ns'] = time.time_ns()
    report['probe_cpu_ns'] = time.process_time_ns() - cpu_start
    report['probe_wall_ns'] = time.monotonic_ns() - START
    print(json.dumps(report, sort_keys=True, separators=(',', ':')))
sys.exit(0 if report['passed'] else 1)
