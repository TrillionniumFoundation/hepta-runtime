INVENTORY_SOURCE_SHA256 = "15c11209468fb73313486ceb383aadaf2d3766149f19eb11aeb82709d483b8c4"
ACTUAL_INVENTORY_BINDING = None  # REAL_ORIGINAL_INVENTORY_ONLY
OUTPUT_ROOT = "/home/qian/hepta-runtime-optimization-20261105-r25"
OUTPUT_NAME = "transport-chunk-retirement-01"


def verify_prior_inventory():
    binding = ACTUAL_INVENTORY_BINDING
    need(type(binding) is dict, "actual original inventory binding is absent")
    decoded = {}
    for key in ("report", "terminal"):
        item = binding[key]
        raw = base64.b64decode(item["base64"], validate=True)
        need(0 < len(raw) <= 131072 and identity(raw) == {name: item[name] for name in ("bytes", "sha256")}
             and base64.b64encode(raw).decode() == item["base64"], "original inventory bytes differ")
        decoded[key] = json.loads(raw)
    report, terminal = decoded["report"], decoded["terminal"]
    need(terminal["job_id"] == binding["job_id"] and terminal["state"] == "succeeded"
         and terminal["exit_code"] == 0 and terminal["audit_recorded"] is True
         and terminal["output_complete"] is True and terminal["output_durable"] is True
         and terminal["terminal_publication_confirmed"] is True
         and terminal["terminal_publication_protocol"] == 1
         and terminal["automatic_retry"] is False and terminal["timed_out"] is False
         and terminal["cancelled"] is False, "original inventory did not strongly succeed")
    for stream, length in (("stdout", binding["report"]["bytes"]), ("stderr", 0)):
        need(terminal["log_bytes"][stream] == {"seen": length, "stored": length}
             and terminal["log_synced"][stream] is True
             and terminal["log_truncated"][stream] is False
             and terminal["log_errors"][stream] is None, "original inventory stream is not complete")
    need(report["schema"] == "hepta-r29-fixed-chunk-inventory/v1"
         and report["operation"] == "read_only_inventory" and report["passed"] is True
         and report["entry_source_sha256_from_original_request"] == INVENTORY_SOURCE_SHA256
         and report["scope_sha256"] == SCOPE_SHA256 and report["errors"] == []
         and report["files_created"] == 0 and report["files_removed"] == 0
         and report["archive_or_manifest_modified"] is False
         and report["automatic_retries"] == 0 and report["verified_chunk_count"] == 555
         and report["logical_bytes"] == 35205396 and len(report["groups"]) == 10,
         "actual fixed inventory facts differ")
    need([row["id"] for row in report["groups"]] == [row["id"] for row in SPECS],
         "actual inventory group order differs")
    return report


def write_all(fd, body):
    position = 0
    while position < len(body):
        count = os.write(fd, body[position:])
        need(count > 0, "zero-length write to new evidence file")
        position += count


def create_output(state):
    parent = open_directory(OUTPUT_ROOT, state)
    try:
        os.stat(OUTPUT_NAME, dir_fd=parent, follow_symlinks=False)
    except FileNotFoundError:
        pass
    else:
        raise RuntimeError("one-time retirement output already exists; automatic retry forbidden")
    os.mkdir(OUTPUT_NAME, 0o700, dir_fd=parent)
    os.fsync(parent)
    path = Path(OUTPUT_ROOT) / OUTPUT_NAME
    fd = os.open(OUTPUT_NAME, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW | os.O_CLOEXEC, dir_fd=parent)
    value = os.fstat(fd)
    state["directories"].append((path, fd, directory_identity(value)))
    need(stat.S_ISDIR(value.st_mode) and value.st_uid == OWNER and value.st_gid == OWNER
         and stat.S_IMODE(value.st_mode) == 0o700
         and stamp(value) == stamp(os.stat(OUTPUT_NAME, dir_fd=parent, follow_symlinks=False)),
         "fresh operation directory identity differs")
    return fd


def create_journal(directory):
    name = "operations.jsonl"
    fd = os.open(name, os.O_RDWR | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW | os.O_CLOEXEC,
                 0o600, dir_fd=directory)
    before = stamp(os.fstat(fd))
    try:
        need(before["st_uid"] == OWNER and before["st_gid"] == OWNER and before["st_nlink"] == 1
             and before["st_mode"] == stat.S_IFREG | 0o600 and before["st_size"] == 0
             and before == stamp(os.stat(name, dir_fd=directory, follow_symlinks=False)),
             "fresh journal is not its owned private original")
        os.fsync(fd)
        os.fsync(directory)
        return {"fd": fd, "directory": directory, "name": name,
                "opened": before, "latest": before, "bytes": 0, "sha": hashlib.sha256(), "events": 0}
    except BaseException:
        os.close(fd)
        raise


def append_journal(journal, row):
    fd, directory, name = journal["fd"], journal["directory"], journal["name"]
    need(stamp(os.fstat(fd)) == journal["latest"]
         == stamp(os.stat(name, dir_fd=directory, follow_symlinks=False)),
         "operation journal was modified or replaced")
    body = (json.dumps(row, sort_keys=True, separators=(",", ":"), allow_nan=False) + "\n").encode()
    need(len(body) <= 16384 and journal["bytes"] + len(body) <= 4 * 1024 * 1024,
         "bounded operation journal exceeded")
    write_all(fd, body)
    os.fsync(fd)
    after = stamp(os.fstat(fd))
    immutable = ("st_dev", "st_ino", "st_mode", "st_uid", "st_gid", "st_nlink")
    need(all(after[key] == journal["opened"][key] for key in immutable)
         and after["st_size"] == journal["bytes"] + len(body)
         and after == stamp(os.stat(name, dir_fd=directory, follow_symlinks=False)),
         "written journal lost its original file identity")
    journal["sha"].update(body)
    journal["bytes"] += len(body)
    journal["events"] += 1
    journal["latest"] = after


def seal_journal(journal, state):
    os.fsync(journal["fd"])
    need(stamp(os.fstat(journal["fd"])) == journal["latest"]
         == stamp(os.stat(journal["name"], dir_fd=journal["directory"], follow_symlinks=False)),
         "final journal descriptor differs from its path")
    expected = {"bytes": journal["bytes"], "sha256": journal["sha"].hexdigest()}
    _, observed, _ = read_regular(journal["directory"], journal["name"], expected, state,
                                 maximum=4 * 1024 * 1024)
    need(observed["identity"] == journal["latest"], "final journal readback changed inode")
    return {"path": OUTPUT_ROOT + "/" + OUTPUT_NAME + "/" + journal["name"],
            **observed, "events": journal["events"], "all_completed_events_fsynced": True}


def open_original_chunk(group, record):
    name = record["name"]
    need(re.fullmatch(r"chunk-[0-9]{5}\.b64", name)
         and record["path"] == group["spec"]["chunks_directory"] + "/" + name,
         "unlink target is not one fixed verified transfer chunk")
    directory = group["directory_fd"]
    fd = os.open(name, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK | os.O_CLOEXEC, dir_fd=directory)
    try:
        before = stamp(os.fstat(fd))
        need(before == record["identity"]
             == stamp(os.stat(name, dir_fd=directory, follow_symlinks=False))
             and stat.S_ISREG(before["st_mode"]) and before["st_uid"] == OWNER
             and before["st_nlink"] == 1 and before["st_size"] == record["bytes"]
             and before["st_dev"] == os.fstat(directory).st_dev,
             "chunk is no longer its original verified single-link descriptor")
        blocks, size = [], 0
        while block := os.read(fd, min(64001 - size, record["bytes"] - size + 1)):
            size += len(block)
            need(size <= record["bytes"] <= 64000, "chunk grew before unlink")
            blocks.append(block)
        need(identity(b"".join(blocks)) == {key: record[key] for key in ("bytes", "sha256")}
             and before == stamp(os.fstat(fd))
             == stamp(os.stat(name, dir_fd=directory, follow_symlinks=False)),
             "chunk bytes or identity changed before unlink")
        return fd
    except BaseException:
        os.close(fd)
        raise


def retire_chunk(group, record, index, journal, state, report):
    verify_originals(state)
    fd = open_original_chunk(group, record)
    try:
        intent = {"event": "intent", "index": index, "group": group["spec"]["id"],
                  "path": record["path"], "bytes": record["bytes"], "sha256": record["sha256"],
                  "original_identity": record["identity"], "monotonic_ns": time.monotonic_ns()}
        append_journal(journal, intent)
        verify_originals(state)
        need(stamp(os.fstat(fd)) == record["identity"]
             == stamp(os.stat(record["name"], dir_fd=group["directory_fd"], follow_symlinks=False)),
             "chunk changed after durable intent; no unlink performed for this record")
        os.unlink(record["name"], dir_fd=group["directory_fd"])
        report["unlink_calls_completed"] += 1
        report["logical_bytes_unlinked"] += record["bytes"]
        os.fsync(group["directory_fd"])
        after = stamp(os.fstat(fd))
        unchanged = ("st_dev", "st_ino", "st_mode", "st_uid", "st_gid", "st_size", "st_mtime_ns")
        need(after["st_nlink"] == 0
             and all(after[key] == record["identity"][key] for key in unchanged),
             "unlink did not detach the exact held original inode")
        try:
            os.stat(record["name"], dir_fd=group["directory_fd"], follow_symlinks=False)
        except FileNotFoundError:
            pass
        else:
            raise RuntimeError("a path reappeared after unlink; preserve it and stop")
    finally:
        os.close(fd)
    append_journal(journal, {"event": "completed", "index": index, "group": group["spec"]["id"],
                            "path": record["path"], "unlinked_descriptor_identity": after,
                            "original_descriptor_closed": True, "directory_fsynced": True,
                            "monotonic_ns": time.monotonic_ns()})
    report["completed_and_fsynced_receipts"] += 1


def save_final_report(directory, report, state):
    body = encode(report)
    need(len(body) <= 262144, "final operation report unexpectedly large")
    name = "report.json"
    fd = os.open(name, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW | os.O_CLOEXEC,
                 0o600, dir_fd=directory)
    try:
        before = stamp(os.fstat(fd))
        need(before["st_uid"] == OWNER and before["st_gid"] == OWNER and before["st_nlink"] == 1
             and before["st_mode"] == stat.S_IFREG | 0o600 and before["st_size"] == 0,
             "new final report is not its original private file")
        write_all(fd, body)
        os.fsync(fd)
        after = stamp(os.fstat(fd))
        immutable = ("st_dev", "st_ino", "st_mode", "st_uid", "st_gid", "st_nlink")
        need(all(after[key] == before[key] for key in immutable) and after["st_size"] == len(body)
             and after == stamp(os.stat(name, dir_fd=directory, follow_symlinks=False)),
             "final report descriptor/path changed")
    finally:
        os.close(fd)
    os.fsync(directory)
    _, observed, _ = read_regular(directory, name, identity(body), state, maximum=262144)
    need(observed["identity"] == after, "final report fresh descriptor does not name its written inode")
    return {"path": OUTPUT_ROOT + "/" + OUTPUT_NAME + "/" + name, **observed}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source-sha256", required=True)
    args = parser.parse_args()
    need(HEX.fullmatch(args.source_sha256), "original retirement request source SHA required")
    state = {"directories": [], "originals": [], "groups": [], "chunk_inodes": set()}
    report = {"schema": "hepta-r29-fixed-chunk-retirement/v1", "operation": "unlink_exact_transfer_chunks",
              "entry_source_sha256_from_original_request": args.source_sha256,
              "scope_sha256": SCOPE_SHA256, "passed": False, "automatic_retries": 0,
              "started_monotonic_ns": time.monotonic_ns(), "all_555_verified_before_first_unlink": False,
              "unlink_calls_completed": 0, "completed_and_fsynced_receipts": 0, "logical_bytes_unlinked": 0,
              "original_archives_and_manifests_retained": True, "directories_removed": 0,
              "source_cache_elf_logs_or_reports_removed": False,
              "qualifier_reserve_bytes_unchanged": 3221225472,
              "space_sufficient_for_qualification_claimed": False,
              "partial_failure_evidence_preserved": True, "no_automatic_rollback_or_relaunch": True}
    directory, journal = None, None
    try:
        prior = verify_prior_inventory()
        report["original_readonly_inventory"] = {"job_id": ACTUAL_INVENTORY_BINDING["job_id"],
            "source_sha256": INVENTORY_SOURCE_SHA256,
            "report": {key: ACTUAL_INVENTORY_BINDING["report"][key] for key in ("bytes", "sha256")},
            "terminal": {key: ACTUAL_INVENTORY_BINDING["terminal"][key] for key in ("bytes", "sha256")},
            "raw_native_read_bindings": ACTUAL_INVENTORY_BINDING["raw_native_read_bindings"]}
        report["disk_before"] = disk()
        current = inspect_all(state)
        need(current["passed"] is True and current["verified_chunk_count"] == 555
             and current["logical_bytes"] == 35205396
             and current["groups"] == prior["groups"],
             "all fixed chunks/originals must still match the actual readonly inventory before any mutation")
        report["reverified_inventory"] = current
        report["all_555_verified_before_first_unlink"] = True
        verify_originals(state)
        os.umask(0o077)
        directory = create_output(state)
        journal = create_journal(directory)
        append_journal(journal, {"event": "complete_preflight", "verified_chunks": 555,
                                "groups": 10, "scope_sha256": SCOPE_SHA256,
                                "original_inventory_sha256": ACTUAL_INVENTORY_BINDING["report"]["sha256"],
                                "disk": report["disk_before"], "monotonic_ns": time.monotonic_ns()})
        index = 0
        for group in state["groups"]:
            for record in group["records"]:
                retire_chunk(group, record, index, journal, state, report)
                index += 1
            entries = []
            with os.scandir(group["directory_fd"]) as iterator:
                for entry in iterator:
                    entries.append(entry.name)
                    need(len(entries) <= 256, "unknown post-unlink entries; preserve them and stop")
            need(entries == ["manifest.json"], "fixed chunk directory contains unexpected remaining entries")
            verify_originals(state)
        need(index == report["unlink_calls_completed"] == report["completed_and_fsynced_receipts"] == 555
             and report["logical_bytes_unlinked"] == 35205396, "exact retirement totals differ")
        verify_originals(state)
        report["disk_after_unlinks_and_journal"] = disk()
        report["actual_available_byte_change_before_final_report"] = (
            report["disk_after_unlinks_and_journal"]["available_bytes"] - report["disk_before"]["available_bytes"])
        append_journal(journal, {"event": "all_completed", "completed": 555,
                                "disk": report["disk_after_unlinks_and_journal"],
                                "monotonic_ns": time.monotonic_ns()})
        report["passed"] = True
    except Exception as error:
        report["passed"] = False
        report["error"] = {"type": type(error).__name__, "reason": str(error)[:4000]}
        if journal is not None:
            try:
                append_journal(journal, {"event": "stopped", "error": report["error"],
                                        "unlink_calls_completed": report["unlink_calls_completed"],
                                        "completed_receipts": report["completed_and_fsynced_receipts"],
                                        "monotonic_ns": time.monotonic_ns()})
            except Exception as journal_error:
                report["journal_stop_error"] = repr(journal_error)[:2000]
    finally:
        try:
            verify_originals(state)
            report["protected_original_identities_stable_at_final"] = True
        except Exception as error:
            report["passed"] = False
            report["protected_original_identities_stable_at_final"] = False
            report["final_original_error"] = repr(error)[:2000]
        if journal is not None:
            try:
                report["journal"] = seal_journal(journal, state)
            except Exception as error:
                report["passed"] = False
                report["journal_seal_error"] = repr(error)[:2000]
            finally:
                os.close(journal["fd"])
        report["finished_monotonic_ns"] = time.monotonic_ns()
        try:
            report["disk_at_final_report_preparation"] = disk()
        except Exception as error:
            report["passed"] = False
            report["final_disk_error"] = repr(error)[:2000]
        saved = None
        if directory is not None:
            try:
                saved = save_final_report(directory, report, state)
            except Exception as error:
                report["passed"] = False
                report["final_report_write_error"] = repr(error)[:2000]
        close_state(state)
        print(json.dumps({"report": saved, "outcome": report}, sort_keys=True,
                         separators=(",", ":"), allow_nan=False), flush=True)
    return 0 if report["passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
