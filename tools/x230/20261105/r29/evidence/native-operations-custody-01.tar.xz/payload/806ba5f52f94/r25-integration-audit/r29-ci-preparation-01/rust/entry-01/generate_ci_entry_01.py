#!/usr/bin/env python3
"""Generate data-only install and one original CI entry from real frozen receipts."""
import argparse
import ast
import base64
import gzip
import hashlib
import io
import json
import os
from pathlib import Path
import pprint
import stat
import tarfile
import types

WORK = Path('/workspace/scratch/806ba5f52f94')
HERE = WORK / 'r25-integration-audit/r29-ci-preparation-01/rust/entry-01'
ROOT = Path('/home/qian/hepta-runtime-optimization-20261105-r29')
NAMES = ('materialize_rust_ci_plan_01.py', 'run_rust_ci_01.py', 'audit_nextest_0137.py')
DRAFT = WORK / 'r25-integration-audit/r29-ci-preparation-01/rust/rust-ci-draft-01'
DRAFT_PINS = {'audit_nextest_0137.py': '03fc242ae6ba3f5fa2fc948d3401e5f93a7a388ee9edb5b703183d6410aab8d2', 'materialize_rust_ci_plan_01.py': 'efa68bd1526368fd778733dfedd7ff5bddd40384192b4a88f2c6eeeb6a4ae732', 'run_rust_ci_01.py': 'e2a7b4f033d7851d57a1094b7c09a29cbd4c01a503351e0b9021a5e9e5e43215'}
RECEIPT_NAMES = {'report': 'qualification-report-01.json', 'terminal': 'qualification-native-terminal-01.json',
                 'preparation': 'preparation-01.json', 'map': 'qualified-source-map-01.json',
                 'summary': 'isolated-tests-summary-01.json', 'audit': 'isolated-tests-audit-01.json'}
VERIFY_SOURCE = WORK / 'r25-integration-audit/r29-ci-preparation-01/rust/freeze_rust_ci_01.py'
VERIFY_SHA = 'c0ad0085ee846eb7b4867b3d9dec7507fcf6bfc86dcece7bcc030625ac96f553'
FREEZER = VERIFY_SOURCE
FREEZER_SHA = VERIFY_SHA
OLD_LAUNCHER = WORK / 'benchmark-r26/rust-ci-delivery-01/tools/launch_exact_rust_ci_01.py'
OLD_LAUNCHER_SHA = '42f38e773d8a5f7f6b220e010bf4d6da6a33627d92ad631688128a6313bda811'
TEMPLATE_PINS = {'install_rust_ci_tools_01.template.py': '7739024146604fe92b3a51257017746ddc649d8222476da50d2067791154a8e8', 'launch_exact_rust_ci_01.template.py': '521aa6cfa885b568b6b7094acc4872eaf9f6370c084ef464b9d3bfe1aa04e55c'}


def need(value, reason):
    if not value:
        raise ValueError(reason)


def identity(raw):
    return {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


def read(path, expected=None):
    need(path.is_absolute() and path.resolve(strict=True) == path, 'absolute direct local input required')
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK | os.O_CLOEXEC)
    with os.fdopen(fd, 'rb') as stream:
        before = os.fstat(stream.fileno())
        need(stat.S_ISREG(before.st_mode) and before.st_nlink == 1 and 0 < before.st_size <= 16 * 1024 * 1024,
             'unsafe or oversized local input')
        body = stream.read(before.st_size + 1)
        after = os.fstat(stream.fileno())
    fields = ('st_dev', 'st_ino', 'st_mode', 'st_uid', 'st_nlink', 'st_size', 'st_mtime_ns', 'st_ctime_ns')
    need(len(body) == before.st_size and all(getattr(before, k) == getattr(after, k)
         == getattr(path.lstat(), k) for k in fields), 'local input changed during read')
    if expected is not None:
        need(identity(body)['sha256'] == (expected if isinstance(expected, str) else expected['sha256']), 'local SHA differs')
        if isinstance(expected, dict):
            need(type(expected['bytes']) is int and len(body) == expected['bytes'], 'local byte count differs')
    return body


def encode(value):
    return (json.dumps(value, sort_keys=True, indent=2, allow_nan=False) + '\n').encode()


def render(body, specification):
    text = body.decode()
    need(text.count('SPEC = None\n') == 1, 'one explicit unbound template required')
    result = text.replace('SPEC = None\n', 'SPEC = ' + pprint.pformat(specification, sort_dicts=True, width=100) + '\n').encode()
    ast.parse(result)
    return result


def packed(files):
    output = io.BytesIO()
    with gzip.GzipFile(fileobj=output, filename='', mode='wb', compresslevel=9, mtime=0) as gz:
        with tarfile.open(fileobj=gz, mode='w|', format=tarfile.USTAR_FORMAT) as archive:
            for name, body in sorted(files.items()):
                member = tarfile.TarInfo(name)
                member.size, member.mode, member.mtime = len(body), 0o600, 0
                member.uid = member.gid = 0
                member.uname = member.gname = ''
                archive.addfile(member, io.BytesIO(body))
    return output.getvalue()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--frozen-package', type=Path, required=True)
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    need(args.frozen_package.is_absolute() and args.frozen_package.resolve(strict=True) == args.frozen_package,
         'actual absolute frozen package required')
    need(args.out.is_absolute() and args.out.parent.resolve(strict=True) == args.out.parent
         and not os.path.lexists(args.out), 'fresh local delivery directory required')
    need({p.name for p in args.frozen_package.iterdir()} == set(NAMES) | {'package-manifest-01.json', 'local-freeze-receipt.json'},
         'actual freezer five-file output required')
    bound = {}
    def bind(path, expected=None):
        raw = read(path, expected)
        bound[str(path)] = identity(raw)
        return raw
    generator_raw = bind(Path(__file__).resolve())
    freeze_raw = bind(args.frozen_package / 'local-freeze-receipt.json')
    freeze = json.loads(freeze_raw)
    JOB = freeze["original_job_id"]
    need(freeze['schema'] == 'hepta-r29-local-rust-ci-freeze/v1' and freeze['passed'] is True
         and freeze['original_job_id'] == JOB and freeze['remote_installed'] is False
         and freeze['ci_executed'] is False and freeze['hosted_actions_passed'] is False,
         'actual unexecuted successful freeze receipt required')
    manifest_raw = bind(args.frozen_package / 'package-manifest-01.json', freeze['package_manifest'])
    manifest = json.loads(manifest_raw)
    need(manifest['schema'] == 'hepta-r29-exact-rust-ci-tools/v1'
         and manifest['actual_qualification_job_id'] == JOB and manifest['executed'] is False
         and manifest['hosted_actions_passed'] is False and set(manifest['files']) == set(NAMES)
         and manifest['files'] == freeze['files'] and set(freeze['original_receipts']) == set(RECEIPT_NAMES),
         'actual frozen manifest/receipt composition differs')
    receipt_raw = {}
    for key, name in RECEIPT_NAMES.items():
        row = freeze['original_receipts'][key]
        path = Path(row['local_path'])
        need(path.name == name, 'original local receipt name differs')
        receipt_raw[key] = bind(path, row)
    # Reuse the pinned, independently reviewed pure six-receipt validator.
    # Its main is never called and it performs no filesystem reads itself.
    verifier_raw = bind(VERIFY_SOURCE, VERIFY_SHA)
    module = types.ModuleType('_r29_checked_six_receipt_gate')
    module.__file__ = str(VERIFY_SOURCE)
    exec(compile(verifier_raw, str(VERIFY_SOURCE), 'exec'), module.__dict__)
    proof = module.verify_six_receipts(receipt_raw, JOB)
    need(proof['passed'] is True and proof['original_qualification_job_id'] == JOB, 'six actual receipts did not pass')
    actual = {'JOB_ID': JOB, 'SOURCE_MAP_SHA': identity(receipt_raw['map'])['sha256'],
              'ISOLATED_SUMMARY_SHA': identity(receipt_raw['summary'])['sha256'],
              'ISOLATED_AUDIT_SHA': identity(receipt_raw['audit'])['sha256'],
              'QUALIFICATION_REPORT_SHA': identity(receipt_raw['report'])['sha256'],
              'PREPARATION_SHA': identity(receipt_raw['preparation'])['sha256'],
              'NATIVE_TERMINAL_SHA': identity(receipt_raw['terminal'])['sha256']}
    substitutions = {'UNBOUND_ACTUAL_QUALIFICATION_JOB_ID': actual['JOB_ID'],
        'UNBOUND_ACTUAL_SOURCE_MAP_SHA256': actual['SOURCE_MAP_SHA'],
        'UNBOUND_ACTUAL_ISOLATED_SUMMARY_SHA256': actual['ISOLATED_SUMMARY_SHA'],
        'UNBOUND_ACTUAL_ISOLATED_AUDIT_SHA256': actual['ISOLATED_AUDIT_SHA'],
        'UNBOUND_ACTUAL_QUALIFICATION_REPORT_SHA256': actual['QUALIFICATION_REPORT_SHA'],
        'UNBOUND_ACTUAL_PREPARATION_SHA256': actual['PREPARATION_SHA'],
        'UNBOUND_ACTUAL_NATIVE_TERMINAL_SHA256': actual['NATIVE_TERMINAL_SHA']}
    bind(FREEZER, FREEZER_SHA)
    old_launcher = bind(OLD_LAUNCHER, OLD_LAUNCHER_SHA)
    draft = {name: bind(DRAFT / name, DRAFT_PINS[name]) for name in NAMES}
    materialized = draft[NAMES[0]].decode()
    for sentinel, value in substitutions.items():
        need(materialized.count(sentinel) == (2 if sentinel.endswith('QUALIFICATION_JOB_ID') else 1),
             'reviewed draft sentinel differs')
        materialized = materialized.replace(sentinel, value, 1)
    expected_tools = {NAMES[0]: materialized.encode(), NAMES[1]: draft[NAMES[1]], NAMES[2]: draft[NAMES[2]]}
    files = {name: bind(args.frozen_package / name, manifest['files'][name]) for name in NAMES}
    need(files == expected_tools, 'frozen tools differ from reviewed bytes plus the seven actual pins')
    assignments = {target.id: ast.literal_eval(node.value) for node in ast.parse(files[NAMES[0]]).body
                   if isinstance(node, ast.Assign) for target in node.targets
                   if isinstance(target, ast.Name) and target.id in actual}
    need(assignments == actual, 'frozen materializer actual pin constants differ or remain unresolved')
    report_identity = {'path': str(ROOT / 'qualification-01/report.json'), **identity(receipt_raw['report'])}
    need(manifest['qualification_report'] == report_identity, 'manifest qualification report differs')
    launch_template = bind(HERE / 'launch_exact_rust_ci_01.template.py', TEMPLATE_PINS['launch_exact_rust_ci_01.template.py'])
    install_template = bind(HERE / 'install_rust_ci_tools_01.template.py', TEMPLATE_PINS['install_rust_ci_tools_01.template.py'])
    launch_spec = {'manifest': identity(manifest_raw), 'tools': manifest['files'],
                   'qualification_report': report_identity, 'actual_pins': actual}
    launcher = render(launch_template, launch_spec)
    files.update({'package-manifest-01.json': manifest_raw, 'launch_exact_rust_ci_01.py': launcher})
    archive = packed(files)
    # Verify every generated member without extracting or executing it.
    with tarfile.open(fileobj=io.BytesIO(archive), mode='r:gz') as tar:
        need(len(tar.getmembers()) == 5 and {m.name for m in tar.getmembers()} == set(files), 'generated archive inventory differs')
        for member in tar.getmembers():
            need(member.type == tarfile.REGTYPE and member.mode == 0o600
                 and tar.extractfile(member).read() == files[member.name], 'generated archive member differs')
    encoded = base64.b64encode(archive).decode()
    install_spec = {'archive': identity(archive), 'base64_bytes': len(encoded),
                    'files': {name: identity(body) for name, body in files.items()}, 'actual_pins': actual}
    installer = render(install_template, install_spec)
    install_request = {'host': 'x230', 'executable': '/usr/bin/python3',
        'args': ['-I', '-B', '-c', installer.decode()], 'stdin': encoded,
        'cwd': str(ROOT), 'timeout_seconds': 180, 'nice': 5,
        'idempotency_key': 'hepta-r29-exact-rust-ci-tools-install-20261105-01'}
    ci_request = {'host': 'x230', 'executable': '/usr/bin/python3',
        'args': ['-I', '-B', str(ROOT / 'rust-ci-tools-01/launch_exact_rust_ci_01.py'),
                 '--launcher-sha256', identity(launcher)['sha256']], 'cwd': str(ROOT),
        'timeout_seconds': 7200, 'nice': 5, 'cpu_quota_percent': 200,
        'memory_max_bytes': 5 * 1024 ** 3, 'idempotency_key': 'hepta-r29-exact-rust-ci-20261105-01'}
    for path, expected in bound.items():
        read(Path(path), expected)
    args.out.mkdir(mode=0o700)
    tools = args.out / 'tools'
    tools.mkdir(mode=0o700)
    for name, body in files.items():
        with (tools / name).open('xb') as stream:
            stream.write(body)
    products = {'rust-ci-tools-01.tar.gz': archive, 'install_rust_ci_tools_01.py': installer,
                'install-request.json': encode(install_request), 'ci-request.json': encode(ci_request)}
    for name, body in products.items():
        with (args.out / name).open('xb') as stream:
            stream.write(body)
    result = {'schema': 'hepta-r29-original-ci-entry-generation/v1', 'passed': True,
        'remote_installed': False, 'ci_executed': False, 'hosted_actions_passed': False,
        'actual_qualification_pins': actual, 'actual_receipt_validation': proof,
        'generator': {'path': str(Path(__file__).resolve()), **identity(generator_raw)},
        'input_bindings': bound, 'matches_reviewed_r29_draft_plus_seven_actual_pins': True,
        'only_seven_qualification_pins_replaced_in_original_materializer': True,
        'old_successful_launcher': {'path': str(OLD_LAUNCHER), **identity(old_launcher)},
        'workflow_commands_changed': False, 'runner_execution_and_cleanup_changed': False,
        'runner_path_and_preparation_binding_changed_for_R29': True, 'tools': install_spec['files'],
        'products': {name: identity(body) for name, body in products.items()},
        'next_action': 'root reviews actual generated package, performs data-only install once, verifies its original terminal/receipt/files, then launches the original CI request once'}
    with (args.out / 'generation-receipt.json').open('xb') as stream:
        stream.write(encode(result))
    print(json.dumps({'passed': True, 'out': str(args.out), 'actual_qualification_job_id': JOB,
                      'archive': identity(archive), 'launcher': identity(launcher), 'remote_actions': 0}, sort_keys=True))


if __name__ == '__main__':
    raise SystemExit(main())
