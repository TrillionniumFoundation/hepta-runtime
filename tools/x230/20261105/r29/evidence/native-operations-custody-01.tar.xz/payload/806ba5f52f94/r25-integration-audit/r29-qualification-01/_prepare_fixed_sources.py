"""Local artifact construction only; never imports or runs a qualification entry."""
import ast
import difflib
import hashlib
import json
from pathlib import Path
import pprint

BASE = Path('/workspace/scratch/806ba5f52f94')
OUT = Path(__file__).parent
OLD = BASE / 'r25-lifecycle-audit/r28-qualification-recovery-02/prepare_and_qualify_r28_02.py'
PROBE = BASE / 'r25-lifecycle-audit/r29-owned-cache-readonly-02/read_target_metadata_02.py'
CAND = BASE / 'r25-capacity-audit/r29-router-cache-candidate-01'

def encode(value):
    return (json.dumps(value, sort_keys=True, indent=2, allow_nan=False) + '\n').encode()

def identity(raw):
    return {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}

def functions(raw):
    source = raw.decode()
    return {node.name: ast.get_source_segment(source, node)
            for node in ast.parse(source).body if isinstance(node, ast.FunctionDef)}

old_raw, probe_raw = OLD.read_bytes(), PROBE.read_bytes()
old, probe = functions(old_raw), functions(probe_raw)
changed = ['src/mcp/server.rs', 'src/mcp/server_tests.rs']
changes = []
for relative in changed:
    before = (CAND / 'baseline-source' / relative).read_bytes()
    after = (CAND / 'candidate' / relative).read_bytes()
    a, b = before.decode().splitlines(keepends=True), after.decode().splitlines(keepends=True)
    ops = []
    for group in difflib.SequenceMatcher(None, a, b, autojunk=False).get_grouped_opcodes(4):
        old_text = ''.join(a[group[0][1]:group[-1][2]])
        new_text = ''.join(b[group[0][3]:group[-1][4]])
        assert old_text and before.decode().count(old_text) == 1
        ops.append({'old': old_text, 'new': new_text, 'required_matches': 1})
    proof = before.decode()
    for op in ops:
        assert proof.count(op['old']) == 1
        proof = proof.replace(op['old'], op['new'], 1)
    assert proof.encode() == after
    changes.append({'relative_path': relative, 'before': identity(before),
                    'after': identity(after), 'operations': ops})
transform = {'schema': 'hepta-r29-shared-router-fixed-source-transform/v1',
             'production_selection': 'shared unfiltered ToolRouter', 'optional_pidfd_selected': False,
             'files': changes}
transform_raw = encode(transform)
(OUT / 'candidate-transform-01.json').write_bytes(transform_raw)
source_map_raw = (CAND / 'candidate-source-map-01.json').read_bytes()
(OUT / 'candidate-source-map-01.json').write_bytes(source_map_raw)
probe_tree = ast.parse(probe_raw)
bound = next(ast.literal_eval(n.value) for n in probe_tree.body
             if isinstance(n, ast.Assign) and any(isinstance(t, ast.Name) and t.id == 'BOUND' for t in n.targets))
qc_input = json.loads((BASE / 'r25-integration-audit/r28-qualification-ci-export-02/actual-export-input-01.json').read_bytes())
failed_probe_dir = BASE / 'benchmark-r29/cache-metadata-operations-01'
def original_text(path):
    wrapper = json.loads(path.read_bytes())
    texts = [row['text'] for row in wrapper['result']['content'] if row['type'] == 'text']
    assert len(texts) == 1
    return texts[0]
failed_terminal = original_text(failed_probe_dir / 'status-01.json')
failed_pages = [original_text(failed_probe_dir / name) for name in ('read-00-01.json','read-01-01.json')]
failed_probe = {'job_id': '1a1acfe317a-fc05-57ee',
    'source_sha256': '9242d4b6f2d9b21b80b7cba7f1aabb23e6f9e222a43b7000d064b7edf532b9a0',
    'native_terminal_text': failed_terminal,
    'native_terminal_identity': identity(failed_terminal.encode()),
    'native_read_pages': [{'text': raw, 'identity': identity(raw.encode())} for raw in failed_pages],
    'native_read_page_identities': [identity(raw.encode()) for raw in failed_pages],
    'stdout_identity': identity((failed_probe_dir / 'actual-report-01.json').read_bytes())}
failed_spec = {key: value for key, value in failed_probe.items() if key not in ('native_terminal_text','native_read_pages')}
qc_qa_path = BASE / 'benchmark-r28/qualification-ci-export-operations-01/assembled-01/verified-01/independent-verification-01.json'
qc_qa_raw = qc_qa_path.read_bytes()
assert identity(qc_qa_raw) == {'bytes':9585,'sha256':'7342eed4ed17389eb57f5f40111438c5c4e339591ebb77c450a4fb1fe3ae2614'}
known = {}
for name, row in qc_input['stages'].items():
    known[name] = {'job_id': row['job_id'], 'terminal': row['native_terminal'], 'report': row['report'],
                   'state': 'failed' if name in ('qualification_failed01', 'python_ci01') else 'succeeded',
                   'exit_code': 1 if name in ('qualification_failed01', 'python_ci01') else 0}
expected = {
    'schema': 'hepta-r29-shared-router-qualification-input/v1',
    'production_selection': 'shared unfiltered ToolRouter', 'optional_pidfd_selected': False,
    'parent_candidate_adopted': False, 'accepted_production_source_remains_R24': True,
    'transform_text': transform_raw.decode(), 'candidate_source_map': json.loads(source_map_raw),
    'candidate_manifest': identity((CAND / 'source-manifest-01.json').read_bytes()),
    'test_expectation': {'selected': 1689, 'passed': 1655, 'failed': 0, 'ignored': 34, 'retries': 0,
        'new_exact_tests': [
            'mcp::server::server_tests::cached_router_keeps_mcp_sessions_and_teardown_independent',
            'mcp::server::server_tests::cached_router_rechecks_runtime_mode_and_native_session_owner']},
    'cache_admission': {
        'original_failed_probe01': failed_probe,
        'read_only_probe': None,
        'local_QC_full_archive_verification': {
            'original_verification_text': qc_qa_raw.decode(),
            'original_verification_identity': identity(qc_qa_raw),
            'consumer_sha256': 'c949b88484f348a53e9aadde9b92c248d08c507347faea2e978ed0639dd3df73'},
        'root_exclusive_writer_admission': None},
    'unchanged_disk_reserve_bytes': 3221225472,
    'cache_strategy': 'one same-filesystem renameat2(RENAME_NOREPLACE); no cache copy or cleanup',
}
(OUT / 'qualification-input-01.template.json').write_bytes(encode(expected))

header = '''#!/usr/bin/env python3
# Copyright 2026 TrillionniumFoundation
# SPDX-License-Identifier: Apache-2.0
"""Qualify exact R29 source once, after one admitted R28-owned cache move.
Unbound cache/QC/writer evidence rejects before any directory or file mutation.
No service change, cache copy, cleanup, automatic move retry or rollback.
"""
import argparse
import ctypes
import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import stat
import subprocess
import sys
import time
import traceback

ROOT = Path('/home/qian/hepta-runtime-optimization-20261105-r29')
PARENT = Path('/home/qian/hepta-runtime-optimization-20261105-r28')
ACCEPTED = Path('/home/qian/hepta-runtime-optimization-20261105-r24')
OLD_SOURCE = PARENT / 'source'
SOURCE = ROOT / 'source'
TARGET = ROOT / 'target-build'
OUTPUT = ROOT / 'qualification-01'
INPUT = Path('/home/qian/hepta-runtime-optimization-20261105-r25/tools/r29-qualification-01-input.json')
ROOT24 = str(ACCEPTED)
ROOT26 = '/home/qian/hepta-runtime-optimization-20261105-r26'
ROOT28 = str(PARENT)
ROOT29 = str(ROOT)
CACHE = ROOT28 + '/target-build'
OWNER = 1000
CACHES = (('owned_r28_target', CACHE, False),)
FIELDS = ('st_dev', 'st_ino', 'st_uid', 'st_gid', 'st_mode', 'st_nlink', 'st_size', 'st_mtime_ns', 'st_ctime_ns')
EXPORT_FIELDS = ('st_dev', 'st_ino', 'st_uid', 'st_mode', 'st_nlink', 'st_size', 'st_mtime_ns', 'st_ctime_ns')
DEAD = {'Z', 'X', 'x'}
START = time.monotonic_ns()
MAX_DURATION_NS = 120 * 10**9
MAX_TREE_ENTRIES = 200000
MAX_PROCESSES = 16384
MAX_PROC_BYTES = 1048576
PROTECTED_ELF_INODES = set()
RESERVE_BYTES = 3 * 1024**3
CHANGED_PATHS = ('src/mcp/server.rs', 'src/mcp/server_tests.rs')
STAGES = ['format', 'fmt-check', 'harness-tests', 'clippy', 'test-build',
          'isolated-tests', 'audit-isolated-tests', 'release']
PUBLICATION_SHA = '38866c01fac54133c8a88e25bee90ea4a551e7273614f493bf44522a8273d3ca'
PROBE_SOURCE_SHA = '088b102aec64ea0606ba1dfb09dfc73b5d332f76a08b5ad68cd1847300a914d2'
QC_CONSUMER_SHA = 'c949b88484f348a53e9aadde9b92c248d08c507347faea2e978ed0639dd3df73'
QC_ARCHIVE = {'bytes': 1915620, 'sha256': '442586ded13a4cfde54531e6f05ddddcf26c2f53d40d15b04c5993ece5f04186'}
QC_EXPORT_JOB = '1a1acd29fba-fc05-5724'
REJECTION_REPORT_SHA = '9fd45bf5f9987b849c637bdf3ed61f3b49b4f98b615dd914d16e0afa80822ba5'
REJECTION_SUMMARY_SHA = 'c1df02071f3ebecde73de47cc3fe62daef2908981486db40287a995daabf5a0c'
REJECTION_NATIVE_SHA = '3df7bbc9acc621a6c1eeaf85e4fe21870cb62ba5df0f423e2b67a6e8f236860e'
NEW_EXACT_TESTS = (
    'mcp::server::server_tests::cached_router_keeps_mcp_sessions_and_teardown_independent',
    'mcp::server::server_tests::cached_router_rechecks_runtime_mode_and_native_session_owner')
'''
header += 'BOUND = ' + pprint.pformat(bound, sort_dicts=True) + '\n'
header += 'KNOWN_OPERATIONS = ' + pprint.pformat(known, sort_dicts=True) + '\n'
header += 'FAILED_PROBE_SPEC = ' + pprint.pformat(failed_spec, sort_dicts=True) + '\n'
header += 'TRANSFORM_SHA = ' + repr(identity(transform_raw)['sha256']) + '\n'
header += 'CANDIDATE_MAP_SHA = ' + repr(identity(source_map_raw)['sha256']) + '\n'
header += 'CANDIDATE_MANIFEST = ' + repr(identity((CAND / 'source-manifest-01.json').read_bytes())) + '\n\n'
chunks = [header]
for name in ('utc','encoded','stamp','read','source_map','harness_map','check_terminal','quiescence','byte_identity'):
    chunks.append(old[name] + '\n\n')
for name in ('need','budget','stamp','directory_id','check_chain','close_chain','open_directory','read_bound',
             'inventory_tree','proc_bytes','proc_stat','matches_cache','scan_references','inspect_fixed_directory',
             'preserved_elf_metadata'):
    code = probe[name].replace('stamp(', 'metadata_stamp(')
    if name == 'inventory_tree':
        code = code.replace('accumulator = hashlib.sha256()',
                            'accumulator = hashlib.sha256()\n        descendants = hashlib.sha256()')
        line = "            accumulator.update((json.dumps(record, sort_keys=True, separators=(',', ':')) + '\\n').encode())"
        replacement = "            record_raw = (json.dumps(record, sort_keys=True, separators=(',', ':')) + '\\n').encode()\n            accumulator.update(record_raw)\n            if relative != '.':\n                descendants.update(record_raw)"
        assert code.count(line) == 1
        code = code.replace(line, replacement)
        line = "'counts': totals, 'metadata_sha256': accumulator.hexdigest(),"
        assert code.count(line) == 1
        code = code.replace(line, line + "\n                'descendants_metadata_sha256': descendants.hexdigest(),")
    chunks.append(code + '\n\n')
(OUT / '_entry_prefix.py').write_text(''.join(chunks))
proof = {'schema': 'hepta-r29-local-source-construction/v1',
         'old_qualifier': {'path': str(OLD), **identity(old_raw)},
         'readonly_probe_source': {'path': str(PROBE), **identity(probe_raw)},
         'candidate_transform': identity(transform_raw), 'candidate_source_map': identity(source_map_raw),
         'exact_two_postimages_reconstructed': True,
         'executed': {'remote': False, 'candidate_build': False, 'candidate_tests': False, 'qualifier_main': False}}
(OUT / 'source-construction-01.json').write_bytes(encode(proof))
