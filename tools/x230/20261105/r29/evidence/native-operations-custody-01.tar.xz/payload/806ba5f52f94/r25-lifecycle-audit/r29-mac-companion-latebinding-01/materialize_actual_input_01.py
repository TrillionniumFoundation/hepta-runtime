#!/usr/bin/env python3
"""Local-only materialization of the two completed, original R29 Mac holders.

No collector, archive, subprocess, network, workload or host operation is run.
Read-only validation definitions come from the exact previously reviewed source.
"""
import argparse
import ast
import base64
import hashlib
import json
import os
from pathlib import Path
import re
import stat
import sys

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
WORK = HERE.parent.parent
FROZEN = WORK / 'r25-lifecycle-audit/r29-mac-companion-01'
COLLECTOR = FROZEN / 'collect_mac_companion_01.py'
COLLECTOR_PIN = (36074, 'da99b0aa491ff62d7144c5d7463624e40075c65e24ae385ae24c506633072af8')
CONSUMER_PIN = (45397, 'f55b3ffedc4152c4e91b8dc2d586a15f687b27892cf64eaed3005cef71f8a2bb')
REMOTE_INPUTS = '/Users/qianqi/work/hepta-runtime-r29-mac-companion-inputs-01'
FUNCTIONS = {'need', 'sha', 'parse', 'scan', 'stamp', 'version', 'read',
             'tool_value', 'terminal', 'native_streams', 'footer', 'validate_input'}
CONSTANTS = {'PLANS', 'HOLDER_PIN', 'HEX', 'JOB', 'KNOWN_ORIGINAL_PINS', 'MAX_FILE', 'SECRET_RULES'}
EXPECTED_JOBS = {'observation01': '1a1ad77dfe5-fc05-59f9',
                 'lifecycle01': '1a1ad8309eb-fc05-5a1b'}
EXPECTED_STATES = {'observation01': ('succeeded', 0, True),
                   'lifecycle01': ('failed', 1, False)}


def checked_bootstrap(path):
    if not path.is_absolute() or path.resolve(strict=True) != path:
        raise ValueError('indirect local source')
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_CLOEXEC)
    try:
        before = os.fstat(fd)
        if not (stat.S_ISREG(before.st_mode) and before.st_uid == os.geteuid()
                and before.st_nlink == 1 and before.st_mode & 0o022 == 0
                and before.st_size <= 1024 * 1024):
            raise ValueError('unsafe or oversized local source')
        with os.fdopen(os.dup(fd), 'rb') as stream:
            raw = stream.read(1024 * 1024 + 1)
        keys = ('st_dev', 'st_ino', 'st_uid', 'st_gid', 'st_mode', 'st_nlink',
                'st_size', 'st_mtime_ns', 'st_ctime_ns')
        stamps = [tuple(getattr(info, key) for key in keys)
                  for info in (before, os.fstat(fd), path.lstat())]
        if len(raw) != before.st_size or stamps[0] != stamps[1] or stamps[0] != stamps[2]:
            raise ValueError('local source changed during read')
        return raw
    finally:
        os.close(fd)


def definitions(raw):
    tree = ast.parse(raw)
    nodes, names = [], set()
    for node in tree.body:
        if isinstance(node, ast.FunctionDef) and node.name in FUNCTIONS:
            nodes.append(node)
            names.add(node.name)
        elif isinstance(node, ast.Assign) and len(node.targets) == 1:
            target = node.targets[0]
            if isinstance(target, ast.Name) and target.id in CONSTANTS:
                nodes.append(node)
                names.add(target.id)
    if names != FUNCTIONS | CONSTANTS:
        raise ValueError('reviewed pure definition selection changed')
    namespace = {'hashlib': hashlib, 'json': json, 'os': os, 'Path': Path,
                 're': re, 'stat': stat}
    exec(compile(ast.Module(body=nodes, type_ignores=[]), str(COLLECTOR), 'exec'), namespace)
    return namespace


def encode(value):
    return (json.dumps(value, sort_keys=True, indent=2, allow_nan=False) + '\n').encode()


def write_new(path, raw):
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW | os.O_CLOEXEC, 0o600)
    with os.fdopen(fd, 'wb') as stream:
        stream.write(raw)
        stream.flush()
        os.fsync(stream.fileno())
    if path.read_bytes() != raw:
        raise ValueError('new local output differs')


def original_inner(helper, raw):
    value = helper['parse'](raw)
    value = value.get('result', value)
    helper['need'](value.get('isError', False) is False, 'original RPC error')
    texts = [block['text'] for block in value.get('content', []) if block.get('type') == 'text']
    helper['need'](len(texts) == 1, 'original RPC has no unique text body')
    return texts[0].encode('utf-8')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--bindings-sha256', required=True)
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    source_raw = checked_bootstrap(COLLECTOR)
    if (len(source_raw), hashlib.sha256(source_raw).hexdigest()) != COLLECTOR_PIN:
        raise ValueError('frozen collector source differs')
    helper = definitions(source_raw)
    need, sha, read, parse = (helper[name] for name in ('need', 'sha', 'read', 'parse'))
    bindings_raw, binding_identity = read(HERE / 'actual-bindings-01.json')
    need(sha(bindings_raw) == args.bindings_sha256, 'actual bindings SHA differs')
    bindings = parse(bindings_raw)
    need(bindings.get('schema') == 'hepta-r29-mac-original-local-bindings/v1'
         and set(bindings['holders']) == set(EXPECTED_JOBS), 'fixed actual originals required')
    captured = {}

    def capture(descriptor):
        path = Path(descriptor['path'])
        raw, identity = read(path)
        need((len(raw), sha(raw)) == (descriptor['bytes'], descriptor['sha256']),
             'actual original bytes differ: ' + str(path))
        if path in captured:
            need(captured[path] == (raw, identity), 'local original changed')
        captured[path] = (raw, identity)
        return raw

    for descriptor in bindings['frozen_inputs'].values():
        capture(descriptor)
    need((len(capture(bindings['frozen_inputs']['consumer'])),
          sha(capture(bindings['frozen_inputs']['consumer']))) == CONSUMER_PIN,
         'frozen consumer differs')
    actual = {'schema': 'hepta-r29-mac-companion-originals/v1',
              'all_originals_terminal_or_unexecuted': True, 'holders': {}}
    payloads, results = {}, {}
    for kind, row in bindings['holders'].items():
        plan, job_id = helper['PLANS'][kind], EXPECTED_JOBS[kind]
        raw = {name: capture(descriptor) for name, descriptor in row['files'].items()}
        status = helper['tool_value'](raw['terminal'])
        helper['terminal'](status, job_id)
        streams = helper['native_streams'](helper['tool_value'](raw['read']), status, job_id)
        need(raw['terminal'] == original_inner(helper, raw['status_rpc'])
             and raw['read'] == original_inner(helper, raw['read_rpc']),
             'native DTO must be the exact original text bytes without reencoding')
        start = helper['tool_value'](raw['start_rpc'])
        request = parse(raw['start_request'])
        expected_args = ['-B', '/Users/qianqi/work/hepta-runtime-x230-r21-20261105/held_agent_campaign_02.py',
                         '--remote-script', plan['script'], '--out', plan['directory'], '--timeout-seconds', '3600']
        need(start.get('reused') is False and start['job']['id'] == job_id
             and start['job']['launch_state'] == 'launched'
             and start['job']['request_digest'] == row['request_digest']
             and request['host'] == start['job']['host'] == 'main'
             and request['executable'] == start['job']['executable'] == '/usr/bin/python3'
             and request['args'] == start['job']['args'] == expected_args
             and request['idempotency_key'] == start['job']['idempotency_key'] == row['idempotency_key'],
             'original start/source/request binding differs')
        report, parent = parse(raw['mac_report']), parse(raw['parent_report'])
        expected_state, expected_exit, expected_passed = EXPECTED_STATES[kind]
        need((status['state'], status['exit_code'], report.get('passed'))
             == (expected_state, expected_exit, expected_passed), 'original outcome differs')
        need(report.get('schema') == 'hepta-x230-r21-held-agent-campaign/v1'
             and isinstance(report.get('finished_utc'), str) and report['finished_utc']
             and report['remote_returncode'] == expected_exit
             and report['holder_script_sha256'] == helper['HOLDER_PIN'][1]
             and report['remote_script_sha256'] == plan['script_sha256']
             and report['automatic_ssh_retries'] == 0
             and all(report.get(key) is True for key in ('owned_agent_reaped',
                 'owned_agent_directory_absent_after_context', 'owned_agent_socket_absent_after_context')),
             'original holder source/completion/cleanup differs')
        need(parent.get('schema') == row['parent_schema'] and parent.get('passed') is expected_passed
             and parent.get(plan['footer_gate']) is expected_passed
             and isinstance(parent.get('finished_utc'), str) and parent['finished_utc'],
             'original parent result or finalization differs')
        native_lines = [parse(line) for line in streams['stdout'].decode('utf-8').splitlines() if line.strip()]
        need(native_lines == [
            {'phase': 'owned_agent_ready', 'identity_count': 5, 'remote_script_sha256': plan['script_sha256']},
            {'passed': expected_passed, 'remote_returncode': expected_exit, 'owned_agent_reaped': True,
             'report': plan['directory'] + '/report.json'}] and streams['stderr'] == b'',
             'original native ready/footer or stderr differs')
        logs = {entry['file']: entry for entry in report['log_files']}
        for key, name in (('forwarded_stdout', 'forwarded.stdout'), ('forwarded_stderr', 'forwarded.stderr'),
                          ('agent_stderr', 'owned-agent.stderr')):
            need(logs[name]['bytes'] == len(raw[key]) and logs[name]['sha256'] == sha(raw[key]),
                 'already read original holder log differs')
        remote_footer = helper['footer'](raw['forwarded_stdout'])
        need(remote_footer['report'] == plan['remote_report']
             and remote_footer['passed'] is parent['passed']
             and remote_footer[plan['footer_gate']] is parent[plan['footer_gate']]
             and remote_footer.get('error') == parent.get('error'), 'original forwarded footer differs')
        if kind == 'lifecycle01':
            need([(stage['name'], stage['returncode']) for stage in parent['stages']]
                 == [('lifecycle-tool-tests', 0), ('normal-lifecycle-abba', 1)],
                 'original lifecycle stage history differs')
        actual['holders'][kind] = {'executed': True, 'job_id': job_id,
            'report_sha256': sha(raw['mac_report']), 'terminal_sha256': sha(raw['terminal']),
            'read_sha256': sha(raw['read']), 'reason': None}
        for suffix in ('terminal', 'read'):
            payloads[kind + '-' + suffix + '.json'] = raw[suffix]
        results[kind] = {'job_id': job_id, 'native_state': status['state'], 'native_exit_code': status['exit_code'],
            'original_stdout_bytes': len(streams['stdout']), 'original_stderr_bytes': len(streams['stderr']),
            'holder_passed': report['passed'], 'remote_returncode': report['remote_returncode'],
            'original_error': report.get('error'), 'original_forwarded_footer': remote_footer,
            'parent_report': row['files']['parent_report'], 'parent_whole_SHA_is_in_native_footer': False,
            'original_full_native_DTO_copied_without_reencoding': True,
            'full_22_file_holder_capture_and_independent_archive_QA_pending': True}
    helper['validate_input'](actual)
    payloads['actual-input-01.json'] = encode(actual)
    input_sha = sha(payloads['actual-input-01.json'])
    request = parse(capture(bindings['frozen_inputs']['capture_template']))
    need(request['args'][-2:] == ['--input-sha256', None], 'capture template is already bound')
    request['args'][-1] = input_sha
    consumer = parse(capture(bindings['frozen_inputs']['consumer_arguments_template']))
    need(consumer['input_sha256'] is None, 'consumer template is already bound')
    consumer['input_sha256'] = input_sha
    for path, original in captured.items():
        need(read(path) == original, 'original changed before local output creation')
    need(read(HERE / 'actual-bindings-01.json') == (bindings_raw, binding_identity), 'bindings changed')
    need(checked_bootstrap(COLLECTOR) == source_raw, 'collector changed')
    out = args.out.absolute()
    need(out.parent.resolve(strict=True) == HERE and not os.path.lexists(out), 'fresh fixed local output required')
    out.mkdir(mode=0o700)
    (out / 'inputs').mkdir(mode=0o700)
    outputs = {}
    for index, (name, body) in enumerate(sorted(payloads.items())):
        write_new(out / 'inputs' / name, body)
        target = REMOTE_INPUTS + '/' + name
        write_new(out / f'input-write-{index:02d}.request.json', encode({
            'host': 'main', 'path': target, 'expected_version': 'absent',
            'data_base64': base64.b64encode(body).decode('ascii')}))
        write_new(out / f'input-info-{index:02d}.request.json', encode({'host': 'main', 'path': target}))
        outputs[name] = {'path': target, 'bytes': len(body), 'sha256': sha(body)}
    write_new(out / 'capture-request-01.json', encode(request))
    write_new(out / 'consumer-arguments-01.json', encode(consumer))
    receipt = {'schema': 'hepta-r29-mac-actual-input-local-materialization/v1', 'passed': True,
        'input_sha256': input_sha, 'source': {'path': str(Path(__file__).absolute()),
            'bytes': len(checked_bootstrap(Path(__file__).absolute())),
            'sha256': sha(checked_bootstrap(Path(__file__).absolute()))},
        'bindings': binding_identity, 'pure_frozen_definitions': sorted(FUNCTIONS | CONSTANTS),
        'collector_main_executed': False, 'consumer_main_executed': False,
        'archive_code_executed': False, 'host_Git_workload_operations': False,
        'capture_not_executed': True, 'runtime_adoption_passed': False,
        'originals': results, 'inputs': outputs,
        'original_input_identities': [identity for _, identity in captured.values()]}
    write_new(out / 'materialization-receipt-01.json', encode(receipt))
    print(json.dumps({'passed': True, 'out': str(out), 'input_sha256': input_sha,
                      'original_states': {kind: row['native_state'] for kind, row in results.items()},
                      'capture_executed': False}, sort_keys=True))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
