# R29 原生调用保管：当前实际快照

快照时点：**2026-11-05T20:56:06.441633+00:00**。本轮只执行本地快照和覆盖审计，各首次退出 0，stderr 0；没有主机调用。原 R28 已验证四步流程和封包保持不变。

在 18 个当前 `benchmark-r29/*operations*` 目录中保存并核了 **234 个原文件、15 个真实原生任务**。最后扫描时，根已落盘 OBS 的新强终态及完整 299/0 原 read，所以当前为 **15/15 强终态、15/15 exact request/start 绑定、15/15 双流完整，gaps=[]**。这只说明原生调用收据完整，不表示 OBS 性能 gate、生命周期或饱和通过。

| 原任务 key | Job | 原终态 | stdout / stderr |
|---|---|---|---:|
| `hepta-r29-owned-r28-target-readonly-metadata-20261105-01` | `1a1acfe317a-fc05-57ee` | failed / 1 | 21898 / 0 |
| `hepta-r29-owned-r28-target-readonly-metadata-20261105-02` | `1a1ad09b4c6-fc05-5831` | succeeded / 0 | 25692 / 0 |
| `hepta-r29-transfer-chunk-readonly-inventory-20261105-01` | `1a1ad1ea349-fc05-589c` | succeeded / 0 | 16965 / 0 |
| `hepta-r29-fixed-cache-elf-pair-readonly-20261105-01` | `1a1ad271c8e-fc05-58bb` | succeeded / 0 | 6305 / 0 |
| `hepta-r29-r28-cache-duplicate-elf-retirement-20261105-01` | `1a1ad3892c1-fc05-590d` | succeeded / 0 | 494 / 0 |
| `hepta-r29-owned-r28-target-readonly-metadata-20261105-03` | `1a1ad39d26b-fc05-5916` | succeeded / 0 | 25692 / 0 |
| `hepta-r29-full-qualification-20261105-01` | `1a1ad4261c8-fc05-593b` | succeeded / 0 | 1221 / 0 |
| `hepta-r29-qualification-receipts-export-20261105-01` | `1a1ad5e3f72-fc05-5994` | succeeded / 0 | 1883 / 0 |
| `hepta-r29-reviewed-tools-install-20261105-01` | `1a1ad657ec4-fc05-59b2` | succeeded / 0 | 394 / 0 |
| `hepta-r29-exact-rust-ci-tools-install-20261105-01` | `1a1ad684c1f-fc05-59bf` | succeeded / 0 | 279 / 0 |
| `hepta-r29-exact-rust-ci-20261105-01` | `1a1ad69c247-fc05-59c8` | succeeded / 0 | 1541 / 0 |
| `hepta-r29-python-ci-tools-install-20261105-01` | `1a1ad7133ed-fc05-59e9` | succeeded / 0 | 281 / 0 |
| `hepta-r29-python-ci-20261105-01` | `1a1ad72111c-fc05-59eb` | succeeded / 0 | 8077 / 0 |
| `hepta-r29-observation-inputs-20261105-01` | `1a1ad76e3cf-fc05-59f6` | succeeded / 0 | 2621 / 0 |
| `mac-x230-runtime-r29-observation-campaign-20261105-01` | `1a1ad77dfe5-fc05-59f9` | succeeded / 0 | 299 / 0 |

## 原失败与传输错误完整保留

- metadata probe01 仍是 failed1，原错误为 `directory outside exact task parent`；原 21,898 字节 stdout 和 stderr EOF 均已闭合。
- 资格 `read-progress-03-01.json` 和 `status-04.json` 的两次 MCP request timeout 保留原错误对象。成功后续页没有覆盖它们。
- Rust `read-progress-01-01.json` 对错误 host `main` 的拒绝保留；它不被当作成功读取。
- 退役前本地 `local-staging-verification-failed-01.json` 的 `KeyError: content` 保留，不混淆为原 native 退役失败。

## 真实源码与最终封包边界

实际 qualification source-map 的 221 个文件均找到本地逐 SHA 相同正文。`server_tests.rs` 选择根读回的 50,094 字节实际格式化正文，SHA `2baea2dc0a15db50fc70a3648f002706fb3a74ca30b3f0c6923a749f0eba1213`；其余 220 个正文也与实际 map 完全相同。完整映射保存在 `qualified-source-local-map-01.json`。

`packaging-strategy-01.json` 列出固定原记录、分片请求/响应、完整原双流、实际工具及源码的最终范围。QC/performance/Mac 三份完整归档、实际 full QA 和 cross-package proof 仍未绑定；future lifecycle/QC capture 不在这次原 job 表中。

最终按原 R28 流程生成 fresh snapshot、coverage、deterministic USTAR/XZ_SHA256 包及独立 verifier 结果。只可省去显式引用的已独立完整验证的重复 archive 本体；不能省掉 payload-bearing 原 API responses、错误或页记录。封包自身的 build/verify 操作与未来 Git 响应留在包外。当前没有构建最终 custody archive。
