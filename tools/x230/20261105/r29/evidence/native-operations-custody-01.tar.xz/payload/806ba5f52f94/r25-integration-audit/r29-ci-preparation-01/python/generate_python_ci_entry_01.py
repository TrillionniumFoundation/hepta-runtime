#!/usr/bin/env python3
"""Generate one fresh R29 Python CI entry from six actual successful qualification receipts."""
import argparse
import ast
import base64
import gzip
import hashlib
import io
import json
import os
from pathlib import Path
import pprint
import stat
import tarfile
import types

WORK = Path('/workspace/scratch/806ba5f52f94')
HERE = WORK / 'r25-integration-audit/r29-ci-preparation-01/python'
ROOT = Path('/home/qian/hepta-runtime-optimization-20261105-r29')
VERIFIER = WORK / 'r25-integration-audit/r29-ci-preparation-01/rust/freeze_rust_ci_01.py'
VERIFIER_SHA = 'c0ad0085ee846eb7b4867b3d9dec7507fcf6bfc86dcece7bcc030625ac96f553'
ORIGINAL = WORK / 'r25-integration-audit'
PACKAGE_SHA = '4063559cfe1cef5952802fdbe038f529ce3be73deb1cdfc3ca71c084dc173270'
MANIFEST_SHA = 'bf0df5f7d19ebd149854fbf75887fb0fb136f18a63a0c240abf8420655fb195e'
RUNNER_SHA = 'de69c48bc00273541f505d4462f57bb40ed85e291847cceb671e700534d822aa'
TEMPLATE_PINS = {'launch_python_ci_01.template.py': '24f6b99986349952f2bda1103cddf6199b5c722d8d4f351824604cf94719ba28', 'install_python_ci_tools_01.template.py': '63433200f92930fe3815cc45cc726e014760ed47a4870ca20ca37353fe03f297'}
PARENT_PROOF_SHA = 'b55a6a6210f3336a163ea6b4a4563b39be46c59e0a9e4c51c49d8008a07c7226'
LOCAL_RECEIPTS = {
    'report': 'qualification-report-01.json', 'terminal': 'qualification-native-terminal-01.json',
    'preparation': 'preparation-01.json', 'map': 'qualified-source-map-01.json',
    'summary': 'isolated-tests-summary-01.json', 'audit': 'isolated-tests-audit-01.json',
}


def need(value, reason):
    if not value:
        raise ValueError(reason)


def identity(raw):
    return {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


def read(path, expected=None):
    need(path.is_absolute() and path.resolve(strict=True) == path, 'absolute direct local input required')
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK | os.O_CLOEXEC)
    with os.fdopen(fd, 'rb') as stream:
        before = os.fstat(stream.fileno())
        need(stat.S_ISREG(before.st_mode) and before.st_nlink == 1 and 0 < before.st_size <= 16 * 1024 * 1024,
             'unsafe or oversized local input')
        body = stream.read(before.st_size + 1)
        after = os.fstat(stream.fileno())
    fields = ('st_dev', 'st_ino', 'st_mode', 'st_uid', 'st_nlink', 'st_size', 'st_mtime_ns', 'st_ctime_ns')
    need(len(body) == before.st_size and all(getattr(before, k) == getattr(after, k)
         == getattr(path.lstat(), k) for k in fields), 'local input changed during read')
    if expected is not None:
        need(identity(body)['sha256'] == (expected if isinstance(expected, str) else expected['sha256']), 'local SHA differs')
        if isinstance(expected, dict):
            need(type(expected['bytes']) is int and len(body) == expected['bytes'], 'local byte count differs')
    return body


def encode(value):
    return (json.dumps(value, sort_keys=True, indent=2, allow_nan=False) + '\n').encode()


def render(body, specification):
    text = body.decode()
    need(text.count('SPEC = None\n') == 1, 'one explicit unbound template required')
    result = text.replace('SPEC = None\n', 'SPEC = ' + pprint.pformat(specification, sort_dicts=True, width=100) + '\n').encode()
    ast.parse(result)
    return result


def packed(files):
    output = io.BytesIO()
    with gzip.GzipFile(fileobj=output, filename='', mode='wb', compresslevel=9, mtime=0) as gz:
        with tarfile.open(fileobj=gz, mode='w|', format=tarfile.USTAR_FORMAT) as archive:
            for name, body in sorted(files.items()):
                member = tarfile.TarInfo(name)
                member.size, member.mode, member.mtime = len(body), 0o600, 0
                member.uid = member.gid = 0
                member.uname = member.gname = ''
                archive.addfile(member, io.BytesIO(body))
    return output.getvalue()


def checked_module(raw, path, name):
    module = types.ModuleType(name)
    module.__file__ = str(path)
    exec(compile(raw, str(path), 'exec'), module.__dict__)
    return module


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--receipts', type=Path, required=True)
    parser.add_argument('--original-job-id', required=True)
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    need(args.receipts.is_absolute() and args.receipts.resolve(strict=True) == args.receipts,
         'actual absolute original qualification receipts required')
    need(args.out.is_absolute() and args.out.parent.resolve(strict=True) == args.out.parent
         and not os.path.lexists(args.out), 'fresh local delivery directory required')
    bound = {}
    def bind(path, expected=None):
        body = read(path, expected)
        bound[str(path)] = identity(body)
        return body
    generator_raw = bind(Path(__file__).resolve())
    raw = {key: bind(args.receipts / name) for key, name in LOCAL_RECEIPTS.items()}
    verifier_raw = bind(VERIFIER, VERIFIER_SHA)
    verifier = checked_module(verifier_raw, VERIFIER, '_r29_python_six_actual_receipts')
    qualification = verifier.verify_six_receipts(raw, args.original_job_id)
    need(qualification['passed'] is True, 'actual original qualification has not passed')
    launcher_raw = bind(HERE / 'launch_python_ci_01.template.py', TEMPLATE_PINS['launch_python_ci_01.template.py'])
    launcher = checked_module(launcher_raw, HERE / 'launch_python_ci_01.template.py', '_r29_python_parent_binding')
    parent_raw = bind(HERE / 'candidate-parent-proof-01.json', PARENT_PROOF_SHA)
    manifest_raw = bind(ORIGINAL / 'ci-gate-manifest.json', MANIFEST_SHA)
    runner_raw = bind(ORIGINAL / 'run_ci_python_gates.py', RUNNER_SHA)
    package_raw = bind(ORIGINAL / 'ci-python-inputs-01.tar.gz', {'bytes': 498954, 'sha256': PACKAGE_SHA})
    manifest = json.loads(manifest_raw)
    original_files = {}
    with tarfile.open(fileobj=io.BytesIO(gzip.decompress(package_raw)), mode='r:') as archive:
        members = archive.getmembers()
        need(len(members) == 103 and sum(row.size for row in members) == 2205863, 'original complete input package differs')
        for member in members:
            need(member.isfile() and not member.issparse() and member.name not in original_files,
                 'original regular package inventory differs')
            original_files[member.name] = archive.extractfile(member).read()
    need(original_files['ci-gate-manifest.json'] == manifest_raw
         and original_files['run_ci_python_gates.py'] == runner_raw, 'frozen package runner/manifest mismatch')
    historical = {name: json.loads(original_files['raw/' + name]) for name in launcher.ORIGINAL_TREE_PREFIXES}
    git_binding = launcher.verify_git_inputs(manifest, json.loads(parent_raw), historical)
    for row in manifest['input_files']:
        body = original_files['ci-inputs/' + row['path']]
        need(identity(body) == {'bytes': row['bytes'], 'sha256': row['sha256']}
             and hashlib.sha1(b'blob ' + str(len(body)).encode() + b'\0' + body).hexdigest() == row['git_blob'],
             'original package dependency bytes/Git blob differs: ' + row['path'])
    source_map = json.loads(raw['map'])
    inputs = {row['path']: row for row in manifest['input_files']}
    overlap = sorted(set(source_map) & set(inputs))
    need(overlap == ['src/mcp/runtime/fileio.py']
         and all(source_map[name] == inputs[name]['sha256'] for name in overlap),
         'actual qualified R29 source changed a Python dependency')
    changed = {row['path'] for row in json.loads(raw['preparation'])['source_changes']}
    need(not changed & set(inputs), 'selected router changes affect Python dependency inputs')
    actual_input = {
        'schema': 'hepta-r29-python-ci-actual-input/v1',
        'original_qualification_job_id': args.original_job_id,
        'candidate_git_parent': launcher.CANDIDATE_GIT_PARENT,
        'manifest_sha256': MANIFEST_SHA, 'parent_proof_sha256': PARENT_PROOF_SHA,
        'qualification_verifier_sha256': VERIFIER_SHA,
        'qualification_receipts': {key: {'path': str(launcher.QUALIFICATION_PATHS[key]), **identity(body)}
                                   for key, body in raw.items()},
        'qualification_validation': qualification,
        'python_ci_executed': False, 'hosted_actions_passed': False,
    }
    files = {'launch_python_ci_01.py': launcher_raw, 'qualification_binding_01.py': verifier_raw,
             'candidate-parent-proof-01.json': parent_raw, 'actual-python-input-01.json': encode(actual_input)}
    manifest_new = {'schema': 'hepta-r29-exact-python-ci-tools/v1',
                    'actual_qualification_job_id': args.original_job_id,
                    'qualification_report': qualification['qualification_report'],
                    'files': {name: identity(body) for name, body in files.items()},
                    'executed': False, 'hosted_actions_passed': False}
    files['package-manifest-01.json'] = encode(manifest_new)
    archive = packed(files)
    with tarfile.open(fileobj=io.BytesIO(gzip.decompress(archive)), mode='r:') as tar:
        need(len(tar.getmembers()) == 5 and {row.name for row in tar.getmembers()} == set(files), 'generated package differs')
        for member in tar.getmembers():
            need(member.type == tarfile.REGTYPE and member.mode == 0o600 and 0 < member.size <= 65536
                 and tar.extractfile(member).read() == files[member.name], 'generated member bytes/type/bound differs')
    encoded = base64.b64encode(archive).decode()
    actual_pins = {'JOB_ID': args.original_job_id,
                   **{key.upper() + '_SHA256': identity(body)['sha256'] for key, body in raw.items()}}
    specification = {'archive': identity(archive), 'base64_bytes': len(encoded),
                     'files': {name: identity(body) for name, body in files.items()}, 'actual_pins': actual_pins}
    installer = render(bind(HERE / 'install_python_ci_tools_01.template.py',
                            TEMPLATE_PINS['install_python_ci_tools_01.template.py']), specification)
    install_request = {'host': 'x230', 'executable': '/usr/bin/python3',
        'args': ['-I', '-B', '-c', installer.decode()], 'stdin': encoded, 'cwd': str(ROOT),
        'timeout_seconds': 180, 'nice': 5, 'idempotency_key': 'hepta-r29-python-ci-tools-install-20261105-01'}
    ci_request = {'host': 'x230', 'executable': '/usr/bin/python3',
        'args': ['-I', '-B', str(ROOT / 'python-ci-tools-01/launch_python_ci_01.py'),
                 '--launcher-sha256', identity(launcher_raw)['sha256'],
                 '--actual-input-sha256', identity(files['actual-python-input-01.json'])['sha256']],
        'cwd': str(ROOT), 'timeout_seconds': 11160, 'nice': 10, 'cpu_quota_percent': 100,
        'memory_max_bytes': 1073741824, 'idempotency_key': 'hepta-r29-python-ci-20261105-01',
        'env': {'PYTHONDONTWRITEBYTECODE': '1', 'PYTHONUNBUFFERED': '1', 'MALLOC_ARENA_MAX': '1'}}
    for path, expected in bound.items():
        read(Path(path), expected)
    args.out.mkdir(mode=0o700)
    target = args.out / 'tools'
    target.mkdir(mode=0o700)
    for name, body in files.items():
        with (target / name).open('xb') as stream:
            stream.write(body)
    products = {'python-ci-tools-01.tar.gz': archive, 'install_python_ci_tools_01.py': installer,
                'install-request.json': encode(install_request), 'ci-request.json': encode(ci_request)}
    for name, body in products.items():
        with (args.out / name).open('xb') as stream:
            stream.write(body)
    result = {'schema': 'hepta-r29-python-ci-entry-generation/v1', 'passed': True,
        'remote_installed': False, 'python_ci_executed': False, 'hosted_actions_passed': False,
        'actual_qualification_validation': qualification, 'candidate_git_parent_binding': git_binding,
        'qualified_python_overlap': {name: source_map[name] for name in overlap},
        'selected_router_changes_outside_python_inputs': True,
        'dependency_input_files': 85, 'workflow_commands': 18,
        'original_runner_and_manifest_unchanged': True, 'historical_input_head_retained': launcher.INPUT_HEAD,
        'original_package': identity(package_raw), 'original_runner': identity(runner_raw),
        'generator': {'path': str(Path(__file__).resolve()), **identity(generator_raw)}, 'input_bindings': bound,
        'actual_pins': actual_pins, 'files': specification['files'],
        'products': {name: identity(body) for name, body in products.items()},
        'next_action': 'root reviews this actual package; install once, verify original install terminal/receipt, then launch once in a non-measurement window',
        'uncertain_dispatch_policy': 'reconcile the identical original key/request; never use a fresh key to replay'}
    with (args.out / 'generation-receipt.json').open('xb') as stream:
        stream.write(encode(result))
    print(json.dumps({'passed': True, 'out': str(args.out), 'actual_qualification_job_id': args.original_job_id,
                      'archive': identity(archive), 'launcher': identity(launcher_raw), 'remote_actions': 0}, sort_keys=True))


if __name__ == '__main__':
    raise SystemExit(main())
