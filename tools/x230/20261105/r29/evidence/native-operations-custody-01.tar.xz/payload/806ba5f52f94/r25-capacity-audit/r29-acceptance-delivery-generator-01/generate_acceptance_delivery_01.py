#!/usr/bin/env python3
"""Finalize fixed local R29 acceptance tools and requests; never execute or upload payloads."""
import argparse
import ast
import base64
import difflib
import gzip
import hashlib
import io
import json
import os
from pathlib import Path
import pprint
import re
import stat
import tarfile
import zlib

BASE = Path('/workspace/scratch/806ba5f52f94')
HERE = Path(__file__).resolve().parent
ROOT = '/home/qian/hepta-runtime-optimization-20261105-r29'
STAGE = '/home/qian/hepta-runtime-optimization-20261105-r25'
KIT = None
TEMPLATE_MANIFEST = HERE / 'template-inputs-02.json'
TEMPLATE_MANIFEST_SHA = 'dbf8260f98115952c02772cd537cc718eb18f11c56c1316e67bec4398ceba837'
CANONICAL_NAME = 'verify_r29_candidate_preparation'
QUALIFIER_REMOTE = STAGE + '/tools/prepare_and_qualify_r29_01.py'
QUALIFIER_INPUT_REMOTE = STAGE + '/tools/r29-qualification-01-input.json'
CHUNK_BYTES = 65535
HEX = re.compile(r'[0-9a-f]{64}\Z')
OLD_PROTOCOL_PINS = {'observation-plan-01.json': {'bytes': 11188, 'sha256': 'e0f76817d9d20c5d2f376374fd36495533962428b836259a520278e29f155d3b'}, 'lifecycle-plan-01.json': {'bytes': 10395, 'sha256': '6ed797ea11d027df742c3d9fe71f1d4472f1e956d663d1caf1bd9f183a67fa30'}, 'tools-02/r28_campaign.py': {'bytes': 64590, 'sha256': '52c2c2777d44d071896b6a25d5c9f178b66989e501abff63fb4fc2a01ee4b2d9'}}

def need(value, message):
    if not value:
        raise RuntimeError(message)

def identity(raw):
    return {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}

def read(path):
    before = path.lstat()
    need(stat.S_ISREG(before.st_mode) and before.st_nlink == 1, 'not an unlinked regular local input')
    raw = path.read_bytes()
    after = path.lstat()
    fields = ('st_dev', 'st_ino', 'st_mode', 'st_uid', 'st_nlink', 'st_size', 'st_mtime_ns', 'st_ctime_ns')
    need(tuple(getattr(before, key) for key in fields) == tuple(getattr(after, key) for key in fields)
         and len(raw) == before.st_size, 'local input changed during read')
    return raw

def write_json(path, value):
    raw = (json.dumps(value, sort_keys=True, indent=2, allow_nan=False) + '\n').encode()
    with path.open('xb') as stream:
        stream.write(raw)
    need(read(path) == raw, 'local JSON readback differs')
    return raw

def pins(bodies):
    return {name: identity(raw) for name, raw in sorted(bodies.items())}

def package(name, bodies):
    tar_buffer = io.BytesIO()
    with tarfile.open(fileobj=tar_buffer, mode='w', format=tarfile.USTAR_FORMAT) as archive:
        for member, raw in sorted(bodies.items()):
            info = tarfile.TarInfo(member)
            info.size = len(raw)
            info.mode = 0o600
            info.uid = info.gid = 0
            info.mtime = 0
            info.uname = info.gname = ''
            archive.addfile(info, io.BytesIO(raw))
    compressed = io.BytesIO()
    with gzip.GzipFile(filename='', mode='wb', compresslevel=9, mtime=0, fileobj=compressed) as stream:
        stream.write(tar_buffer.getvalue())
    raw = compressed.getvalue()
    with (KIT / name).open('xb') as stream:
        stream.write(raw)
    need(read(KIT / name) == raw, 'archive readback differs')
    decoder = zlib.decompressobj(31)
    unpacked = decoder.decompress(raw) + decoder.flush()
    need(decoder.eof and not decoder.unused_data and not decoder.unconsumed_tail
         and unpacked == tar_buffer.getvalue(), 'gzip CRC, EOF, framing or bytes differ')
    checked = {}
    with tarfile.open(fileobj=io.BytesIO(unpacked), mode='r:') as archive:
        members = archive.getmembers()
        need([item.name for item in members] == sorted(bodies), 'tar member order/set differs')
        for item in members:
            need(item.isfile() and not item.issym() and not item.islnk()
                 and item.mode == 0o600 and item.uid == item.gid == item.mtime == 0
                 and not item.linkname and not item.pax_headers, 'tar metadata differs')
            data = archive.extractfile(item).read()
            need(data == bodies[item.name] and len(data) == item.size, 'tar body differs')
            checked[item.name] = identity(data)
    return dict(identity(raw), member_count=len(bodies), expanded_bytes=sum(map(len, bodies.values())),
                path=STAGE + '/staged-r29-' + name, members=checked)


def encoded(value):
    return (json.dumps(value, sort_keys=True, indent=2, allow_nan=False) + '\n').encode()


def bounded_read(path, expected=None):
    need(path.is_absolute() and path.resolve(strict=True) == path
         and path.lstat().st_size <= 2 * 1024 * 1024, 'indirect or oversized fixed local source')
    raw = read(path)
    need(expected is None or identity(raw) == expected, 'fixed local input bytes differ: ' + str(path))
    return raw


def save(relative, raw):
    path = KIT / relative
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('xb') as stream:
        stream.write(raw)
        stream.flush()
        os.fsync(stream.fileno())
    need(read(path) == raw, 'new local output readback differs')
    return {'path': str(path), **identity(raw)}


def function(source, name):
    nodes = [node for node in ast.parse(source).body if isinstance(node, ast.FunctionDef) and node.name == name]
    need(len(nodes) == 1, 'one exact named function required: ' + name)
    return nodes[0], ast.get_source_segment(source, nodes[0])


def replace_function(source, name, replacement):
    node, original = function(source, name)
    lines = source.splitlines(keepends=True)
    result = ''.join(lines[:node.lineno - 1]) + replacement.rstrip() + '\n' + ''.join(lines[node.end_lineno:])
    ast.parse(result)
    need(function(result, name)[1] == replacement.rstrip(), 'canonical function bytes did not bind exactly')
    return result


def canonical_bindings(raw, launcher, launch_input):
    text = raw.decode('utf-8')
    tree = ast.parse(text)
    need(len(tree.body) == 1 and isinstance(tree.body[0], ast.FunctionDef)
         and tree.body[0].name == CANONICAL_NAME and not tree.body[0].decorator_list
         and [arg.arg for arg in tree.body[0].args.args]
         == ['preparation', 'terminal', 'job_id', 'qualified', 'tests'],
         'final canonical validator must be the reviewed standalone function')
    expected = {}
    for name in ('expected_launcher', 'expected_input'):
        values = [node.value for node in tree.body[0].body if isinstance(node, ast.Assign)
                  and len(node.targets) == 1 and isinstance(node.targets[0], ast.Name)
                  and node.targets[0].id == name]
        need(len(values) == 1, 'one literal actual canonical binding required')
        value = ast.literal_eval(values[0])
        need(type(value) is dict and set(value) == {'path', 'bytes', 'sha256'}
             and type(value['bytes']) is int and value['bytes'] > 0
             and isinstance(value['sha256'], str) and HEX.fullmatch(value['sha256']),
             'canonical actual entry/input binding remains unbound')
        expected[name] = value
    need(expected['expected_launcher'] == {'path': QUALIFIER_REMOTE, **identity(launcher)}
         and expected['expected_input'] == {'path': QUALIFIER_INPUT_REMOTE, **identity(launch_input)},
         'final canonical does not bind the actual frozen R29 qualifier and its original input')
    return expected


def preserve_future_unknowns(example):
    need(example['attempt'] == '01' and example['candidate_release'] == 'R29'
         and example['qualification_terminal_status']['job_id'] is None
         and example['source_inputs_sha256'] is None
         and all(value == {'bytes': None, 'sha256': None} for value in example['candidate_binaries'].values()),
         'future source, job or binary facts must remain unknown')
    for key in ('qualification_preparation', 'qualification_terminal_status'):
        need(example[key]['bytes'] is None and example[key]['sha256'] is None,
             'future qualification receipt was populated prematurely')


def upload_requests(label, host, destination, body):
    """Emit the existing native binary_upload protocol; perform no transport."""
    upload_id = 'hepta-r29-' + label + '-20261105-01'
    requests = []
    decoded = []
    for number, offset in enumerate(range(0, len(body), CHUNK_BYTES)):
        chunk = body[offset:offset + CHUNK_BYTES]
        value = {'action': 'chunk', 'host': host, 'path': destination,
                 'upload_id': upload_id, 'offset': offset, 'expected_version': 'absent',
                 'data_base64': base64.b64encode(chunk).decode()}
        need(0 < len(chunk) <= 65535 and offset == sum(map(len, decoded)), 'ordered upload chunk differs')
        decoded.append(base64.b64decode(value['data_base64'], validate=True))
        pin = save('requests/' + label + '-chunk-%02d.request.json' % number, encoded(value))
        requests.append({'tool': 'binary_upload', 'action': 'chunk', 'request': pin,
                         'decoded_offset': offset, 'decoded_chunk': identity(chunk)})
    need(b''.join(decoded) == body, 'full sequential upload payload differs')
    commit = {'action': 'commit', 'host': host, 'path': destination, 'upload_id': upload_id,
              'size': len(body), 'sha256': identity(body)['sha256'], 'expected_version': 'absent'}
    pin = save('requests/' + label + '-commit.request.json', encoded(commit))
    requests.append({'tool': 'binary_upload', 'action': 'commit', 'request': pin})
    info = save('requests/' + label + '-file-info.request.json', encoded({'host': host, 'path': destination}))
    requests.append({'tool': 'file_info', 'request': info})
    return {'label': label, 'host': host, 'destination': destination, 'upload_id': upload_id,
            'body': identity(body), 'sequential_requests': requests,
            'commit_only_after_every_chunk_acknowledged': True,
            'verify_committed_file_info_bytes_and_whole_sha': True,
            'lost_receipt_reconcile_exact_upload_id_offset_and_bytes_only': True,
            'new_upload_id_or_automatic_retry': False, 'remote_actions': 0}


def verify_protocol(templates):
    old_root = BASE / 'r25-integration-audit/r28-acceptance-tools-02'
    obs = json.loads(templates['observation-plan-01.json'])
    life = json.loads(templates['lifecycle-plan-01.json'])
    old_obs = json.loads(bounded_read(old_root / 'observation-plan-01.json', OLD_PROTOCOL_PINS['observation-plan-01.json']))
    old_life = json.loads(bounded_read(old_root / 'lifecycle-plan-01.json', OLD_PROTOCOL_PINS['lifecycle-plan-01.json']))
    for key in ('budgets', 'native_protocol', 'observation_gates', 'correctness_protocol'):
        need(obs[key] == old_obs[key], 'original observation matrix or gate changed: ' + key)
    for key in ('normal_policy', 'native_test_prerequisite', 'status_gate_predicate',
                'campaign_timeout_seconds', 'holder_timeout_seconds'):
        need(life[key] == old_life[key], 'original lifecycle matrix or gate changed: ' + key)
    command_text = function(templates['tools-01/r29_campaign.py'].decode(), 'commands')[1]
    need('("h29" + prefix + attempt)' in command_text and '"h28"' not in command_text,
         'R29 observation socket generation is not fresh')
    legacy_command = function(bounded_read(old_root / 'tools-02/r28_campaign.py', OLD_PROTOCOL_PINS['tools-02/r28_campaign.py']).decode(), 'commands')[1]
    normalized = command_text.replace('r29-cancel-recovery-', 'r28-cancel-recovery-').replace('"h29"', '"h28"')
    need(ast.dump(ast.parse(normalized), include_attributes=False)
         == ast.dump(ast.parse(legacy_command), include_attributes=False),
         'observation argv, stage ordering or matrix differs beyond the fresh R29 paths')
    lifecycle_text = templates['tools-01/r29_lifecycle_campaign.py'].decode()
    need('Path("/home/qian/r29lc1")' in lifecycle_text and 'Path("/home/qian/r29sat1")' in lifecycle_text,
         'lifecycle/saturation socket roots differ')
    for text in (command_text, lifecycle_text):
        need(not re.search(r'/home/qian/(?:h28|r28lc|r28sat)', text), 'old R28 socket remains in active parent')
    return {'observation_matrix_and_thresholds_byte_equivalent_data': True,
            'lifecycle_matrix_and_thresholds_byte_equivalent_data': True,
            'observation_commands_AST_equal_except_fresh_R29_paths': True,
            'socket_paths': {'observation': ['/home/qian/h29n01', '/home/qian/h29b01', '/home/qian/h29c01'],
                             'normal_prefix': '/home/qian/r29lc1', 'saturation': '/home/qian/r29sat1'},
            'normal_gate_before_saturation': True, 'observation_before_lifecycle': True,
            'no_protocol_or_workload_executed': True}


def main():
    global KIT
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--canonical-validator', type=Path, required=True)
    parser.add_argument('--canonical-sha256', required=True)
    parser.add_argument('--qualifier-source', type=Path, required=True)
    parser.add_argument('--qualification-input', type=Path, required=True)
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    need(args.out.is_absolute() and not os.path.lexists(args.out), 'fresh absolute local delivery output required')
    manifest_raw = bounded_read(TEMPLATE_MANIFEST)
    need(identity(manifest_raw)['sha256'] == TEMPLATE_MANIFEST_SHA, 'frozen template manifest changed')
    manifest = json.loads(manifest_raw)
    template_root = Path(manifest['template_root'])
    need(len(manifest['files']) == 47, 'fixed template inventory differs')
    templates = {name: bounded_read(template_root / name, pin) for name, pin in manifest['files'].items()}
    canonical = bounded_read(args.canonical_validator)
    need(isinstance(args.canonical_sha256, str) and HEX.fullmatch(args.canonical_sha256)
         and identity(canonical)['sha256'] == args.canonical_sha256, 'reviewed final canonical bytes differ')
    launcher = bounded_read(args.qualifier_source)
    launch_input = bounded_read(args.qualification_input)
    actual_bindings = canonical_bindings(canonical, launcher, launch_input)
    protocol = verify_protocol(templates)
    final = dict(templates)
    for name in ('tools-01/r29_campaign.py', 'install-01/install_reviewed_tools_01.template.py'):
        final[name] = replace_function(templates[name].decode(), CANONICAL_NAME, canonical.decode()).encode()
    final['canonical-preparation-validator-01.py'] = canonical
    runtime = {name: identity(final['tools-01/' + name]) for name in (
        'r29_campaign.py', 'r29_lifecycle_campaign.py', 'prepare_campaign_inputs.py',
        'prepare_lifecycle_inputs.py', 'summarize_r25_campaign.py')}
    obs_example = json.loads(final['campaign-inputs-01.example.json'])
    life_example = json.loads(final['lifecycle-inputs-01.example.json'])
    preserve_future_unknowns(obs_example)
    preserve_future_unknowns(life_example)
    obs_example['launcher_sha256'] = runtime['r29_campaign.py']['sha256']
    life_example['launcher_sha256'] = runtime['r29_lifecycle_campaign.py']['sha256']
    life_example['campaign_helpers'].update(runtime['r29_campaign.py'])
    final['campaign-inputs-01.example.json'] = encoded(obs_example)
    final['lifecycle-inputs-01.example.json'] = encoded(life_example)
    for name in ('observation-plan-01.json', 'lifecycle-plan-01.json'):
        plan = json.loads(final[name])
        for entry in plan['entrypoints']:
            plan['entrypoints'][entry] = runtime[entry]
        plan['template_only'] = False
        plan['tool_source_bindings_complete'] = True
        plan['executable_ready'] = False
        plan['measurement_readiness_claimed'] = False
        plan['qualification_prerequisites']['canonical_validator_final'] = identity(canonical)
        plan['qualification_prerequisites']['launcher'] = actual_bindings['expected_launcher']
        plan['qualification_prerequisites']['input'] = actual_bindings['expected_input']
        final[name] = encoded(plan)
    need(all(json.loads(final[name])['qualification_prerequisites']['actual_job_id'] is None
             for name in ('observation-plan-01.json', 'lifecycle-plan-01.json')),
         'qualification outcome is not a tool-generation input')
    native_manifest = json.loads(final['lifecycle-tools-01/lifecycle-tools-manifest-01.json'])
    native = {name: final['lifecycle-tools-01/' + name] for name in
              list(native_manifest['files']) + ['lifecycle-tools-manifest-01.json']}
    need(len(native) == 28 and pins({name: raw for name, raw in native.items()
                                    if name != 'lifecycle-tools-manifest-01.json'}) == native_manifest['files'],
         'original reviewed native payload or its manifest differs')
    need(life_example['tools_manifest']['sha256'] == identity(native['lifecycle-tools-manifest-01.json'])['sha256'],
         'native manifest dependency differs')
    # All final caller inputs and immutable template bytes are known before any output exists.
    for name, pin in manifest['files'].items():
        bounded_read(template_root / name, pin)
    for path, body in ((args.canonical_validator, canonical), (args.qualifier_source, launcher),
                       (args.qualification_input, launch_input)):
        need(bounded_read(path) == body, 'final caller input changed during preparation')
    KIT = args.out
    KIT.mkdir(mode=0o700)
    for name, body in final.items():
        save(name, body)
    changed = {name: {'before': identity(templates[name]), 'after': identity(body)}
               for name, body in final.items() if name in templates and body != templates[name]}
    derivation = {'schema': 'hepta-r29-acceptance-final-source-bindings/v1',
                  'template_manifest': identity(manifest_raw), 'final_canonical': identity(canonical),
                  'actual_qualifier_and_input': actual_bindings, 'changed_templates': changed,
                  'runtime_entrypoints': runtime, 'protocol': protocol,
                  'actual_qualification_or_CI_or_measurement': None, 'remote_actions': 0,
                  'archive_code_or_test_execution': False}
    write_json(KIT / 'derivation-inputs-01.json', derivation)
    verification = {'schema': 'hepta-r29-local-acceptance-generation-proof/v1',
                    'tool_bytes_and_bindings_complete': True, 'protocol': protocol,
                    'runtime_entrypoints': runtime, 'future_R29_success_constructed': False,
                    'runtime_functions_or_tests_executed': False, 'remote_operations': 0}
    write_json(KIT / 'local-verification-01.json', verification)
    delta = ''.join(''.join(difflib.unified_diff(templates[name].decode().splitlines(True),
                       final[name].decode().splitlines(True), fromfile='frozen02/' + name, tofile='final01/' + name))
                    for name in sorted(changed))
    save('source-delta-01.patch', delta.encode())
    save('README.md', ('# R29 acceptance tools\n\nPrepared from the frozen R29 socket-corrected templates. '
         'Only actual final qualifier/input identities have been bound. Qualification, Rust/Python CI, '
         'installation, observation, lifecycle and saturation outcomes remain unknown. '
         'The accepted comparison remains R24; the qualified R28 parent remains rejected.\n\n'
         'Run the unchanged six-receipt materializer only after original R29 strong success and complete '
         'receipt readback. The installer verifies that input. Run observation after original CI and '
         'installation gates; normal lifecycle requires the actual passing observation, and saturation '
         'runs inside the same parent only after the original normal gates pass. No retries are added.\n').encode())
    obs_names = ['campaign-inputs-01.example.json', 'observation-plan-01.json'] + ['tools-01/' + name for name in (
        'compiler-monitor-policy-01.json', 'compiler_monitor.py', 'compiler_state.py', 'prepare_campaign_inputs.py',
        'r29_campaign.py', 'summarize_r25_campaign.py', 'validate_compiler_monitor.py')]
    observation = {name: final[name] for name in obs_names}
    obs_manifest = {'schema': 'hepta-r29-observation-tools-install/v2', 'tool_revision': '01',
        'prepared_only': True, 'create_only': True, 'actual_future_evidence_included': False,
        'destination_root': ROOT, 'root_must_be_created_by_successful_qualifier_first': True,
        'qualified_R28_parent_rejection_preserved': True, 'files': pins(observation),
        'mac_copy': {'source': 'tools-01/r29_campaign.py',
                     'destination': '/Users/qianqi/work/hepta-runtime-r29-observation-campaign-01.py'}}
    observation['observation-tools-manifest-01.json'] = write_json(KIT / 'observation-tools-manifest-01.json', obs_manifest)
    parent_names = ['tools-01/r29_lifecycle_campaign.py', 'tools-01/prepare_lifecycle_inputs.py',
                    'lifecycle-inputs-01.example.json', 'lifecycle-plan-01.json', 'README.md',
                    'derivation-inputs-01.json', 'source-delta-01.patch', 'local-verification-01.json']
    parent = {name: read(KIT / name) for name in parent_names}
    installations = {name: ROOT + '/' + name for name in (
        'tools-01/r29_lifecycle_campaign.py', 'tools-01/prepare_lifecycle_inputs.py', 'lifecycle-inputs-01.example.json')}
    parent_manifest = {'schema': 'hepta-r29-lifecycle-launcher-bundle/v2', 'tool_revision': '01',
        'prepared_only': True, 'create_only': True, 'actual_future_evidence_included': False,
        'files': pins(parent), 'installations': installations, 'preserve_bundle_at': ROOT + '/lifecycle-launcher-bundle-01',
        'mac_copy': {'source': 'tools-01/r29_lifecycle_campaign.py',
                    'destination': '/Users/qianqi/work/hepta-runtime-r29-lifecycle-campaign-01.py'},
        'requires_observation_tools_manifest': identity(observation['observation-tools-manifest-01.json']),
        'requires_native_tools_manifest': identity(native['lifecycle-tools-manifest-01.json'])}
    parent['lifecycle-launcher-manifest-01.json'] = write_json(KIT / 'lifecycle-launcher-manifest-01.json', parent_manifest)
    archives = {'observation': package('observation-tools-01.tar.gz', observation),
                'lifecycle': package('lifecycle-tools-01.tar.gz', native),
                'parent': package('lifecycle-launcher-bundle-01.tar.gz', parent)}
    write_json(KIT / 'archive-map-01.json', archives)
    installed = []
    for label, prefix, bodies in (('observation', '', observation), ('lifecycle', 'lifecycle-tools-01/', native),
                                 ('parent', 'lifecycle-launcher-bundle-01/', parent)):
        for name, body in sorted(bodies.items()):
            installed.append({'remote_path': ROOT + '/' + prefix + name, 'archive': label,
                              'member': name, **identity(body)})
    for name, target in sorted(installations.items()):
        installed.append({'remote_path': target, 'archive': 'parent', 'member': name, **identity(parent[name])})
    need(len(installed) == len({row['remote_path'] for row in installed}) == 50, 'installed fixed map differs')
    installer_template = final['install-01/install_reviewed_tools_01.template.py'].decode()
    needle = 'ARCHIVES = None  # FROZEN_ARCHIVE_MAP'
    need(installer_template.count(needle) == 1, 'one unbound installer archive map required')
    installer = installer_template.replace(needle, 'ARCHIVES = ' + pprint.pformat(archives, width=110, sort_dicts=True))
    ast.parse(installer)
    installer_pin = save('install-01/install_r29_reviewed_tools_01.py', installer.encode())
    materializer_template = final['install-01/materialize_installation_qualification_01.template.py'].decode()
    needle = 'INSTALLER_SHA = None  # FROZEN_INSTALLER_SHA'
    need(materializer_template.count(needle) == 1, 'one unbound materializer installer identity required')
    materializer = materializer_template.replace(needle, 'INSTALLER_SHA = ' + repr(installer_pin['sha256']))
    ast.parse(materializer)
    materializer_pin = save('install-01/materialize_installation_qualification_01.py', materializer.encode())
    upload_groups = []
    for label, filename in (('observation', 'observation-tools-01.tar.gz'), ('lifecycle', 'lifecycle-tools-01.tar.gz'),
                            ('parent', 'lifecycle-launcher-bundle-01.tar.gz')):
        upload_groups.append(upload_requests(label + '-reviewed-tools', 'x230', archives[label]['path'], read(KIT / filename)))
    upload_groups.append(upload_requests('reviewed-installer', 'x230', STAGE + '/tools/install_r29_reviewed_tools_01.py',
                                         installer.encode()))
    for label, member in (('observation', 'r29_campaign.py'), ('lifecycle', 'r29_lifecycle_campaign.py')):
        upload_groups.append(upload_requests('mac-' + label + '-parent', 'main',
            '/Users/qianqi/work/hepta-runtime-r29-' + label + '-campaign-01.py', final['tools-01/' + member]))
    native_install = {'host': 'x230', 'executable': '/usr/bin/python3',
        'args': ['-B', STAGE + '/tools/install_r29_reviewed_tools_01.py', '--installer-sha256', installer_pin['sha256']],
        'cwd': STAGE, 'nice': 19, 'timeout_seconds': 120,
        'idempotency_key': 'hepta-r29-reviewed-tools-install-20261105-01'}
    install_request = save('requests/native-install.request.json', encoded(native_install))
    holder_requests = {}
    for label in ('observation', 'lifecycle'):
        raw = final['requests/' + label + '-holder.request.template.json']
        holder_requests[label] = save('requests/' + label + '-holder.request.json', raw)
    workflow = {'schema': 'hepta-r29-local-acceptance-delivery/v1', 'tool_bytes_final': True,
        'actual_qualification': None, 'actual_Rust_CI': None, 'actual_Python_CI': None,
        'actual_installation': None, 'actual_observation': None, 'actual_lifecycle': None, 'actual_saturation': None,
        'measurement_ready': False, 'uploads': upload_groups, 'upload_groups_sequential': True,
        'installed_file_count': 50,
        'installed_files': installed, 'native_install_request': install_request,
        'native_install_blocked_until_actual_six_receipt_input_materialized': True,
        'local_six_receipt_materializer': materializer_pin,
        'local_materializer_required_args': ['--receipts', 'ABSOLUTE_ACTUAL_SIX_RECEIPT_DIRECTORY',
                                            '--original-job-id', 'ACTUAL_NEW_R29_QUALIFICATION_JOB', '--out', 'FRESH_ABSOLUTE_LOCAL_OUTPUT'],
        'holder_requests': holder_requests, 'holder_protocol_unchanged': True,
        'observation_requires_actual_original_CI_and_installation_and_input_gates': True,
        'lifecycle_requires_actual_observation_gate': True, 'saturation_has_no_separate_dispatch_request': True,
        'remote_actions': 0, 'automatic_workload_retries': 0,
        'archive_contents_or_runtime_tools_executed': False, 'protocol': protocol}
    write_json(KIT / 'stage-plan-01.json', workflow)
    ready = {'schema': 'hepta-r29-acceptance-delivery-review-ready/v1',
             'prepared_only': True, 'remote_actions': 0, 'actual_qualification_and_measurements': None,
             'template_manifest': identity(manifest_raw), 'canonical': identity(canonical),
             'source_bindings': actual_bindings, 'runtime_entrypoints': runtime,
             'archives': archives, 'installer': installer_pin, 'materializer': materializer_pin,
             'stage_plan': identity(read(KIT / 'stage-plan-01.json')), 'installed_file_count': len(installed),
             'sequential_upload_groups': len(upload_groups), 'socket_and_matrix_proof': protocol,
             'new_payload_executed': False, 'candidate_adopted': False}
    write_json(KIT / 'review-ready-01.json', ready)
    print(json.dumps({'output': str(KIT), 'prepared_only': True, 'remote_actions': 0,
                      'runtime_entrypoints': runtime, 'installed_file_count': len(installed)}, sort_keys=True), flush=True)


if __name__ == '__main__':
    main()

