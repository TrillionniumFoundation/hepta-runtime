# R29: fixed original qualification receipt retrieval

This directory contains a local plan and exact read-only `file_info` requests.
No host operation, future file size/hash, terminal outcome, or CI pass is supplied.
The actual original qualification job is `1a1ad4261c8-fc05-593b`.

## Fixed local interface

The fresh directory `benchmark-r29/actual-qualification-receipts-01/` must contain
exactly the six original receipt bodies named in `fixed-six-retrieval-plan-01.json`.
These names match the reviewed CI02 freezer and both CI generators. Preserve
complete API requests/results and any failed read attempts separately in
`benchmark-r29/qualification-receipt-retrieval-operations-01/`.

## Original terminal write

After root obtains the actual strong terminal, take the unique original
`content[].text` from the actual tool result (unwrap the saved outer `result`
only if present). Parse a separate copy to verify the original job identity,
state/exit code, complete durable publication, full synced logs and flags.
Encode the original text itself as UTF-8 **without reformatting or adding a
newline**. Fill `terminal-write.template.json.data_base64` from those exact
bytes and retain the original status envelope. The fixed write uses
`expected_version: absent`; it is not an overwrite interface. Never submit
the null-valued template as a request.

Verify actual write size/SHA and independent `file_info`. The remote path is
`ROOT29/qualification-terminal-status-01.json`; its local consumer alias is
`qualification-native-terminal-01.json`. A failed native terminal remains an
actual failure and stops successful CI freezing.

## Download

All six `file-info-NN.request.json` files are exact, ready read-only interfaces;
root must invoke them only when the original output is complete. Bind each
actual size/SHA/version from its original response. The direct fallback is the
previously used `binary_read` interface with `limit: 48000`, the exact returned
version, and contiguous offsets beginning at zero. The number of requests is
computed from real metadata, never predicted. Verify every chunk and full file,
then re-read metadata to confirm stability. The exact-byte terminal already
saved locally can be reused after its remote readback identity is established.

For fewer RPCs on the large original audit, the plan also identifies the
previously successful R28 fixed-six archive exporter/assembler. Those references
are not yet an adapted R29 executable. Either transport must produce these same
six original bodies; neither transport substitutes for the reviewed actual
six-receipt qualification gate.

The original Rust freezer and Rust/Python entry generators are in
`r25-integration-audit/r29-ci-preparation-02/`. Their seven qualification outcome
pins remain unbound until these six actual original bodies are provided.
