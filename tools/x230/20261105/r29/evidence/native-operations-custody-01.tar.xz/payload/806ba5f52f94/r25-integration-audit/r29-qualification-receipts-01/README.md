# R29 fixed six original qualification receipts

This is a narrow local preparation derived from the actually used R28 fixed-six
exporter and assembler. It does not launch qualification, CI or any test.
The unchanged 12,842-byte helper (`34ce88cc…`) remains separately installed under
ROOT25/tools/r26_export_stable_archive_03.py and loaded by exact identity.

Only the six original JSON files are included, with their original bytes.
The archive still contains those six files plus `_export-manifest.json`, uses
the same single-gzip/CRC/EOF/USTAR checks, and publishes the same 48,000-byte
base64 chunk protocol. No source, ELF or benchmark body is collected here.

R29 path/schema/local-alias changes are explicit. The preparation check uses the
exact final canonical function `2892bd35…`; full original qualification checks
remain eight stages, 221 compiler inputs, 19 harness files and required counts
1655 passed / 34 ignored / 1689 selected / zero failed / zero retries.
These values are requirements, not results. All future input file size/hash,
original terminal outcome and export job bindings remain unresolved.

## Root execution interface after actual qualification

1. Save the strong original terminal text create-only at ROOT29/
   qualification-terminal-status-01.json, preserving the original UTF-8 bytes.
2. Obtain the six exact file_info pins from the companion fixed path plan.
3. Fill actual-input-01.template.json only from those original responses. Retain
   that exact input body, then write it create-only using input-write.template.json.
4. Review/stage exporter-write.request.json, independently check file_info, and
   fill the one null input-SHA argument in native-request-01.template.json.
   Invoke that one original key only when root authorizes the data-only export.
5. Save its complete native terminal/read and original report/transfer metadata.
   Read the listed chunk paths four at a time into exact `{request,result}`
   read-batch-NNN.json envelopes. Preserve any failed original RPC separately.
6. Fill actual-binding-01.template.json from those actual original inputs.
   Run the existing assembler CLI shown in usage-01.json once, with fresh local
   evidence and six-receipt output directories. Preserve stdout/stderr/exit.
7. Run the reviewed CI02 six-receipt freezer. Local assembly does not replace it.

No null-valued template is executable. The direct original binary_read route
remains available; root does not need to wait for this optional compressed route.
The original R28 files and all earlier R29 preparation snapshots are unchanged.
