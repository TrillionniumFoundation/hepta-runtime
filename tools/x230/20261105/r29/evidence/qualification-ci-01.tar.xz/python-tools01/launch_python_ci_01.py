#!/usr/bin/env python3
"""Verify the installed fixed Python CI subset and execute each gate once."""

import argparse
import base64
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import signal
import stat
import subprocess
import sys
import tarfile
import time

ROOT = Path("/home/qian/hepta-runtime-optimization-20261105-r29")
SOURCE_ROOT = Path("/home/qian/hepta-runtime-optimization-20261105-r25")
PACKAGE = Path("/home/qian/hepta-runtime-r25-ci-inputs-01.tar.gz")
PACKAGE_BYTES = 498954
PACKAGE_SHA256 = "4063559cfe1cef5952802fdbe038f529ce3be73deb1cdfc3ca71c084dc173270"
MANIFEST_SHA256 = "bf0df5f7d19ebd149854fbf75887fb0fb136f18a63a0c240abf8420655fb195e"
RUNNER_SHA256 = "de69c48bc00273541f505d4462f57bb40ed85e291847cceb671e700534d822aa"
INPUT_HEAD = "1aa98d3c94d0253999a491c967ccc94b314e87c8"
SOURCE = SOURCE_ROOT / "ci-gates"
OUTPUT = ROOT / "python-ci-01"
LAUNCH = ROOT / "python-ci-launch-01"
INSTALL_RECEIPT = SOURCE_ROOT / "tool-package-install-01.json"
INSTALL_RECEIPT_SHA256 = "6f8adc4698405c93f632a2c3534c1cba8337e57522c08ca94b2be2ba23f4a7d7"
DEPENDENCY_RECEIPT = SOURCE_ROOT / "ci-toolchain/nextest-0.9.137/receipt.json"
DEPENDENCY_RECEIPT_SHA256 = "2bbae481b3fbc6ac6d06a22bfe22e9500f5190b97ccddb16e8aba1ef1ed34f9d"
REMOVE_PREFIXES = ("HEPTA_", "SSH_", "RUST_TEST_", "NEXTEST_")
REMOVE_KEYS = ("PYTHONPATH", "PYTHONHOME", "RUSTFLAGS", "CARGO_ENCODED_RUSTFLAGS",
               "RUSTDOCFLAGS", "RUSTC_WRAPPER", "RUSTC_WORKSPACE_WRAPPER", "RUST_LOG")


TOOLS = ROOT / "python-ci-tools-01"
QUALIFIED_SOURCE = ROOT / "source"
QUALIFICATION_VERIFIER = TOOLS / "qualification_binding_01.py"
QUALIFICATION_VERIFIER_SHA256 = 'b57b1f39182f393a834162f0fb685f967b110e66e9c92cca886f1ad21855707a'
ACTUAL_BINDING = TOOLS / "actual-python-input-01.json"
PARENT_PROOF = TOOLS / "candidate-parent-proof-01.json"
PARENT_PROOF_SHA256 = 'b55a6a6210f3336a163ea6b4a4563b39be46c59e0a9e4c51c49d8008a07c7226'
CANDIDATE_GIT_PARENT = "06530d71f82e925ba1766c0e63f54798b3ba0cb6"
CANDIDATE_GIT_TREE = "ed8983ddfb866075673286af806fdb491acb2ed4"
CANDIDATE_GIT_GRANDPARENT = "bfa0d6113d675bb9f597baa474f913c3a12df37a"
QUALIFICATION_PATHS = {
    "report": ROOT / "qualification-01/report.json",
    "terminal": ROOT / "qualification-terminal-status-01.json",
    "preparation": ROOT / "preparation-01.json",
    "map": ROOT / "qualification-01/source-map.json",
    "summary": ROOT / "qualification-01/isolated-tests/summary.json",
    "audit": ROOT / "qualification-01/isolated-tests.audit.json",
}
ORIGINAL_TREE_PREFIXES = {
    "github_tree.json": ".github", "workflows_tree.json": ".github/workflows",
    "tests_tree_recursive.json": "tests", "deploy_tree_recursive.json": "deploy",
    "src_tree_recursive.json": "src", "20261028_tree_recursive.json": "tools/x230/20261028",
    "20261029_tree_recursive.json": "tools/x230/20261029", "20261030_tree_recursive.json": "tools/x230/20261030",
}


def identity(path):
    body = path.read_bytes()
    return {"bytes": len(body), "sha256": hashlib.sha256(body).hexdigest()}


def write_json(path, value):
    with path.open("x") as stream:
        json.dump(value, stream, indent=2, sort_keys=True)
        stream.write("\n")
        stream.flush()
        os.fsync(stream.fileno())


def verify_installed_package():
    if not stat.S_ISREG(PACKAGE.lstat().st_mode):
        raise ValueError("staged archive is not a regular file")
    actual = identity(PACKAGE)
    if actual != {"bytes": PACKAGE_BYTES, "sha256": PACKAGE_SHA256}:
        raise ValueError("staged archive identity mismatch")
    if not stat.S_ISREG(INSTALL_RECEIPT.lstat().st_mode):
        raise ValueError("package install receipt is not a regular file")
    installed = identity(INSTALL_RECEIPT)
    if installed["sha256"] != INSTALL_RECEIPT_SHA256:
        raise ValueError("package install receipt identity mismatch")
    installation = json.loads(INSTALL_RECEIPT.read_text())
    if (installation["passed"] is not True or installation["tests_executed"] is not False
            or installation["qualified_source_modified"] is not False):
        raise ValueError("package installation receipt is not the qualified preparation")
    matches = [p for p in installation["packages"] if p["destination"] == str(SOURCE_ROOT / "ci-gates")]
    if len(matches) != 1:
        raise ValueError("install receipt lacks the unique expected CI destination")
    package = matches[0]
    if (package["archive_bytes"] != PACKAGE_BYTES or package["archive_sha256"] != PACKAGE_SHA256
            or package["archive"] != "/home/qian/hepta-runtime-r25-ci-inputs-01.tar.gz"):
        raise ValueError("install receipt does not identify the frozen package")
    recorded = {row["path"]: {key: row[key] for key in ("bytes", "sha256")} for row in package["files"]}
    if len(recorded) != 103 or len(package["files"]) != 103:
        raise ValueError("install receipt has a different member set")
    if SOURCE.resolve(strict=True) != SOURCE or not stat.S_ISDIR(SOURCE.lstat().st_mode):
        raise ValueError("existing CI package directory is not a direct real directory")
    with tarfile.open(PACKAGE, "r:gz") as archive:
        members = archive.getmembers()
        seen = set()
        if len(members) != 103 or sum(m.size for m in members) != 2205863:
            raise ValueError("frozen package member count or expanded bytes mismatch")
        for member in members:
            relative = PurePosixPath(member.name)
            if (not member.isfile() or member.issparse() or relative.is_absolute()
                    or not relative.parts or ".." in relative.parts or "\\" in member.name
                    or member.name in seen or member.mode & 0o022):
                raise ValueError("unsafe, duplicate or writable archive member")
            if member.size < 0 or member.size > 1024 * 1024:
                raise ValueError("archive member outside frozen package bounds")
            seen.add(member.name)
            target = SOURCE / member.name
            source = archive.extractfile(member)
            if source is None:
                raise ValueError("missing regular archive content")
            body = source.read(member.size + 1)
            source.close()
            if len(body) != member.size:
                raise ValueError("archive member content length mismatch")
            if target.resolve(strict=True) != target or not stat.S_ISREG(target.lstat().st_mode):
                raise ValueError("installed member is not a direct regular file")
            info = target.stat()
            if info.st_mode & 0o022 or bool(info.st_mode & 0o111) != bool(member.mode & 0o111):
                raise ValueError("installed member has different or writable mode")
            expected = {"bytes": len(body), "sha256": hashlib.sha256(body).hexdigest()}
            if identity(target) != expected or recorded.get(member.name) != expected:
                raise ValueError("installed member differs from archive/install receipt: " + member.name)
        actual_names = set()
        for path in SOURCE.rglob("*"):
            info = path.lstat()
            if stat.S_ISDIR(info.st_mode):
                continue
            if not stat.S_ISREG(info.st_mode):
                raise ValueError("unexpected special or symlink member in installed package")
            actual_names.add(path.relative_to(SOURCE).as_posix())
        if actual_names != seen or set(recorded) != seen:
            raise ValueError("installed package file set differs from frozen archive")
    return {"archive": actual, "installation_receipt": installed, "verified_regular_members": len(seen)}


def need(value, reason):
    if not value:
        raise ValueError(reason)


def body_identity(body):
    return {"bytes": len(body), "sha256": hashlib.sha256(body).hexdigest()}


# Parent R28 source identities were confirmed by metadata job 1a1aca4ad22-fc05-561a.
# Every R29 read still checks its actual descriptor and bytes. No JSON, tool or
# unlisted source is eligible for this exact mode exception.
SOURCE_MODE_EXCEPTIONS = {
    QUALIFIED_SOURCE / "src/mcp/runtime/jobs_cancel_io_tests.rs": {
        "bytes": 17145,
        "sha256": "b9553137fe32d873536252c4371bcb57dfceb4e8fac988937b7c552a871f889a",
    },
    QUALIFIED_SOURCE / "src/mcp/runtime/jobs_cancel_read_tests.rs": {
        "bytes": 14542,
        "sha256": "ff92e72b71a8afc23edda7e686c66f87c13ac76dfa3b5c8a8b8e124383b3bf87",
    },
}


def qualified_source_mode_allowed(path, expected, info):
    known = SOURCE_MODE_EXCEPTIONS.get(path)
    return bool(known is not None and type(expected) is str
                and expected == known["sha256"]
                and info.st_mode == 0o100660 and info.st_uid == 1000
                and info.st_gid == 1000 and info.st_nlink == 1
                and info.st_size == known["bytes"])


def checked_read(path, expected=None, *, qualified_source=False):
    need(path.is_absolute() and path.resolve(strict=True) == path, "direct absolute input required")
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK | os.O_CLOEXEC)
    with os.fdopen(fd, "rb") as stream:
        before = os.fstat(stream.fileno())
        mode_allowed = (not before.st_mode & 0o022 or
                        (qualified_source is True and qualified_source_mode_allowed(path, expected, before)))
        need(stat.S_ISREG(before.st_mode) and before.st_uid == os.geteuid()
             and before.st_nlink == 1 and mode_allowed
             and 0 < before.st_size <= 16 * 1024 * 1024,
             "unsafe or oversized bound input: " + str(path))
        body = stream.read(before.st_size + 1)
        after = os.fstat(stream.fileno())
    current = path.lstat()
    fields = ("st_dev", "st_ino", "st_mode", "st_uid", "st_gid", "st_nlink", "st_size", "st_mtime_ns", "st_ctime_ns")
    need(len(body) == before.st_size and all(getattr(before, key) == getattr(after, key)
         == getattr(current, key) for key in fields), "bound input changed during read")
    if expected is not None:
        need(body_identity(body)["sha256"] == (expected if isinstance(expected, str) else expected["sha256"]),
             "bound input SHA differs: " + str(path))
        if isinstance(expected, dict):
            need(type(expected["bytes"]) is int and len(body) == expected["bytes"], "bound input size differs")
    return body


def checked_tree(document):
    """Rebuild the represented complete directories using the original Git tree ordering."""
    need(document.get("truncated") is False, "a complete Git tree response is required")
    entries = document["tree"]
    need(isinstance(entries, list) and len({row["path"] for row in entries}) == len(entries),
         "duplicate Git tree path")
    by_parent = {}
    for entry in entries:
        relative = PurePosixPath(entry["path"])
        need(not relative.is_absolute() and relative.as_posix() == entry["path"]
             and ".." not in relative.parts and relative.parts, "unsafe Git tree path")
        parent, _, leaf = entry["path"].rpartition("/")
        by_parent.setdefault(parent, []).append({**entry, "leaf": leaf})
    expected = {"": document["sha"], **{row["path"]: row["sha"] for row in entries if row["type"] == "tree"}}
    need(set(by_parent) <= set(expected), "tree response omits an ancestor")
    for directory, children in sorted(by_parent.items()):
        ordered = sorted(children, key=lambda row: (row["leaf"] + ("/" if row["type"] == "tree" else "")).encode())
        body = b"".join(row["mode"].lstrip("0").encode() + b" " + row["leaf"].encode()
                        + b"\0" + bytes.fromhex(row["sha"]) for row in ordered)
        actual = hashlib.sha1(b"tree " + str(len(body)).encode() + b"\0" + body).hexdigest()
        need(actual == expected[directory], "Git tree body does not match its immutable object")
    need("" in by_parent, "empty or omitted Git root tree")
    return {row["path"]: row for row in entries}


def verify_git_inputs(manifest, proof, historical):
    need(proof["schema"] == "hepta-r29-published-python-parent-proof/v1"
         and proof["repository"] == "TrillionniumFoundation/hepta-runtime"
         and proof["candidate_git_parent"] == CANDIDATE_GIT_PARENT
         and proof["candidate_git_parent_tree"] == CANDIDATE_GIT_TREE
         and proof["candidate_git_parent_parent"] == CANDIDATE_GIT_GRANDPARENT
         and proof["origin_input_head"] == INPUT_HEAD
         and proof["origin_manifest_sha256"] == MANIFEST_SHA256,
         "candidate Git parent proof differs")
    documents = proof["fetched_documents"]
    need(set(documents) == {"commit", "root", "tools", "x230"}, "four immutable Git GET documents required")
    commit = documents["commit"]
    need(commit["sha"] == CANDIDATE_GIT_PARENT and commit["tree"]["sha"] == CANDIDATE_GIT_TREE
         and [row["sha"] for row in commit["parents"]] == [CANDIDATE_GIT_GRANDPARENT],
         "original Git commit metadata binding differs")
    root = checked_tree(documents["root"])
    tools = checked_tree(documents["tools"])
    x230 = checked_tree(documents["x230"])
    need(documents["root"]["sha"] == CANDIDATE_GIT_TREE
         and root["tools"]["sha"] == documents["tools"]["sha"]
         and tools["x230"]["sha"] == documents["x230"]["sha"], "candidate tools tree chain differs")
    need(set(historical) == set(ORIGINAL_TREE_PREFIXES), "exact original package tree documents required")
    entries = {}
    trees = {}
    for name, prefix in ORIGINAL_TREE_PREFIXES.items():
        document = historical[name]
        need(document["sha"] == manifest["git_tree_proofs"][name]["root_tree"],
             "original package tree differs from its frozen manifest")
        trees[prefix] = checked_tree(document)
        for relative, entry in trees[prefix].items():
            if entry["type"] == "blob":
                full = prefix + "/" + relative
                need(full not in entries or entries[full] == entry, "overlapping original blob proof differs")
                entries[full] = entry
    for prefix in (".github", "tests", "deploy", "src"):
        name = next(name for name, value in ORIGINAL_TREE_PREFIXES.items() if value == prefix)
        need(root[prefix]["type"] == "tree" and root[prefix]["sha"] == historical[name]["sha"],
             "published candidate subtree differs from original Python inputs: " + prefix)
    need(trees[".github"]["workflows"]["sha"] == historical["workflows_tree.json"]["sha"],
         "workflow directory chain differs")
    for day in ("20261028", "20261029", "20261030"):
        need(x230[day]["type"] == "tree" and x230[day]["sha"] == historical[day + "_tree_recursive.json"]["sha"],
             "candidate discovery subtree differs: " + day)
    inputs = manifest["input_files"]
    need(len(inputs) == 85 and len({row["path"] for row in inputs}) == 85
         and manifest["head_commit"] == INPUT_HEAD and len(manifest["python_gates"]) == 18,
         "original 85 dependency inputs and 18 workflow commands required")
    for row in inputs:
        actual = entries[row["path"]]
        need(actual["type"] == "blob" and actual["mode"] == row["git_mode"]
             and actual["sha"] == row["git_blob"] and actual["size"] == row["bytes"],
             "candidate parent input blob/mode/length differs: " + row["path"])
    need(entries[manifest["workflow_path"]]["sha"] == manifest["workflow_git_blob"],
         "candidate workflow blob differs from frozen 18-command workflow")
    discovery = {}
    for directory in ("tools/x230/20261028", "tools/x230/20261029", "tools/x230/20261030"):
        discovery[directory] = sorted(directory + "/" + name for name, row in trees[directory].items()
                                      if row["type"] == "blob" and PurePosixPath(name).name.endswith("_tests.py"))
    need(discovery == manifest["python_discovery_files"], "candidate Git discovery set differs")
    return {"passed": True, "candidate_git_parent": CANDIDATE_GIT_PARENT,
            "candidate_git_parent_tree": CANDIDATE_GIT_TREE, "historical_input_head": INPUT_HEAD,
            "dependency_inputs": 85, "workflow_commands": 18, "workflow_git_blob": manifest["workflow_git_blob"],
            "discovery_sets": discovery, "candidate_qualification_result_inferred": False,
            "remote_git_required_at_execution": False}


def verify_candidate_binding(manifest, binding_sha):
    binding_raw = checked_read(ACTUAL_BINDING, binding_sha)
    binding = json.loads(binding_raw)
    need(binding["schema"] == "hepta-r29-python-ci-actual-input/v1"
         and binding["candidate_git_parent"] == CANDIDATE_GIT_PARENT
         and binding["manifest_sha256"] == MANIFEST_SHA256
         and binding["parent_proof_sha256"] == PARENT_PROOF_SHA256
         and binding["qualification_verifier_sha256"] == QUALIFICATION_VERIFIER_SHA256
         and binding["python_ci_executed"] is False and binding["hosted_actions_passed"] is False
         and set(binding["qualification_receipts"]) == set(QUALIFICATION_PATHS),
         "actual R29 Python candidate binding differs")
    raw = {}
    for key, path in QUALIFICATION_PATHS.items():
        expected = binding["qualification_receipts"][key]
        need(expected["path"] == str(path), "actual qualification receipt path differs")
        raw[key] = checked_read(path, expected)
    verifier_raw = checked_read(QUALIFICATION_VERIFIER, QUALIFICATION_VERIFIER_SHA256)
    namespace = {"__name__": "_checked_r29_python_qualification_gate", "__file__": str(QUALIFICATION_VERIFIER)}
    exec(compile(verifier_raw, str(QUALIFICATION_VERIFIER), "exec"), namespace)
    validation = namespace["verify_six_receipts"](raw, binding["original_qualification_job_id"])
    need(validation == binding["qualification_validation"], "actual qualification proof differs")
    proof = json.loads(checked_read(PARENT_PROOF, PARENT_PROOF_SHA256))
    historical = {name: json.loads(checked_read(SOURCE / "raw" / name)) for name in ORIGINAL_TREE_PREFIXES}
    git_binding = verify_git_inputs(manifest, proof, historical)
    source_map = json.loads(raw["map"])
    original_inputs = {row["path"]: row for row in manifest["input_files"]}
    overlap = sorted(set(source_map) & set(original_inputs))
    need(overlap == ["src/mcp/runtime/fileio.py"], "qualified source and Python dependency overlap differs")
    for relative in overlap:
        need(source_map[relative] == original_inputs[relative]["sha256"],
             "R29 qualified Python dependency differs from its Git-parent input")
    changes = json.loads(raw["preparation"])["source_changes"]
    need(not {row["path"] for row in changes} & set(original_inputs), "selected Rust router changes affect Python inputs")
    for relative, expected_sha in source_map.items():
        path = PurePosixPath(relative)
        need(not path.is_absolute() and path.as_posix() == relative and path.parts and ".." not in path.parts,
             "unsafe actual qualified source path")
        checked_read(QUALIFIED_SOURCE / relative, expected_sha, qualified_source=True)
    return {"passed": True, "actual_input": {"path": str(ACTUAL_BINDING), **body_identity(binding_raw)},
            "qualification_validation": validation, "candidate_git_parent_binding": git_binding,
            "qualified_source_map": body_identity(raw["map"]), "qualified_sources_rechecked": len(source_map),
            "qualified_python_overlap": {name: source_map[name] for name in overlap},
            "selected_router_changes_outside_python_inputs": True,
            "private_compiler_snapshot_not_required_to_contain_all_published_python_inputs": True,
            "python_ci_result_reused_from_R25": False}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--launcher-sha256", required=True)
    parser.add_argument("--actual-input-sha256", required=True)
    args = parser.parse_args()
    need(Path(__file__) == TOOLS / "launch_python_ci_01.py", "fixed installed R29 Python launcher path required")
    checked_read(Path(__file__), args.launcher_sha256)
    if os.geteuid() == 0:
        raise SystemExit("Python fixture gates must run as the unprivileged X230 user")
    if sys.version_info < (3, 11):
        raise SystemExit("Python 3.11 or newer is required")
    for path in (Path("/home"), Path("/home/qian"), ROOT):
        if not stat.S_ISDIR(path.lstat().st_mode):
            raise SystemExit("expected real task parent is unavailable")
    if OUTPUT.exists() or OUTPUT.is_symlink():
        raise SystemExit("Python CI output attempt already exists; refusing reuse")
    LAUNCH.mkdir(mode=0o700, exist_ok=False)
    receipt = {"schema": "hepta-r29-python-ci-one-time-launch-v1", "passed": False,
               "started_unix": time.time(), "launcher_source": identity(Path(__file__)),
               "input_head_commit": INPUT_HEAD,
               "scope": "18 published workflow commands with 85 dependency inputs, bound to the immutable dependency reference 06530d71 and actual qualified R29 source",
               "historical_runner_schema_retained": True, "hosted_actions_passed": False,
               "rust_executed": False, "performance_executed": False,
               "lifecycle_harness_tests_executed": False, "retry_count": 0}
    try:
        if (DEPENDENCY_RECEIPT.resolve(strict=True) != DEPENDENCY_RECEIPT
                or not stat.S_ISREG(DEPENDENCY_RECEIPT.lstat().st_mode)):
            raise ValueError("dependency receipt is not a direct regular file")
        receipt["dependency_receipt"] = identity(DEPENDENCY_RECEIPT)
        if receipt["dependency_receipt"] != {"bytes": 3554, "sha256": DEPENDENCY_RECEIPT_SHA256}:
            raise ValueError("dependency receipt identity mismatch")
        dependencies = json.loads(DEPENDENCY_RECEIPT.read_text())
        jsonschema = dependencies["jsonschema_probe"]
        if (dependencies["passed"] is not True or jsonschema["returncode"] != 0
                or json.loads(jsonschema["stdout"])["discoverable"] is not True
                or dependencies["rg_probe"]["returncode"] != 0):
            raise ValueError("required existing Python CI dependencies were not verified")
        receipt["package_verification"] = verify_installed_package()
        runner = SOURCE / "run_ci_python_gates.py"
        manifest_path = SOURCE / "ci-gate-manifest.json"
        receipt["runner"] = identity(runner)
        receipt["manifest"] = identity(manifest_path)
        if receipt["runner"]["sha256"] != RUNNER_SHA256 or receipt["manifest"]["sha256"] != MANIFEST_SHA256:
            raise ValueError("extracted runner/manifest identity mismatch")
        manifest = json.loads(manifest_path.read_text())
        if manifest["head_commit"] != INPUT_HEAD or len(manifest["python_gates"]) != 18:
            raise ValueError("unexpected Python input commit or gate count")
        receipt["candidate_binding_before"] = verify_candidate_binding(manifest, args.actual_input_sha256)
        environment = dict(os.environ)
        original_home = environment.get("HOME")
        removed = sorted(key for key in environment if key.startswith(REMOVE_PREFIXES) or key in REMOVE_KEYS)
        for key in removed:
            environment.pop(key)
        environment["PATH"] = "/usr/bin:/bin"
        environment["PYTHONDONTWRITEBYTECODE"] = "1"
        environment["PYTHONUNBUFFERED"] = "1"
        if environment.get("HOME") != original_home:
            raise ValueError("HOME must remain unchanged")
        command = ["/usr/bin/python3", "-B", str(runner), "--source", str(SOURCE / "ci-inputs"),
                   "--manifest", str(manifest_path), "--manifest-sha256", MANIFEST_SHA256,
                   "--out", str(OUTPUT), "--gate-timeout", "600"]
        receipt["argv"] = command
        receipt["environment"] = {"removed_key_names": removed, "removed_prefixes": REMOVE_PREFIXES,
                                  "removed_keys": REMOVE_KEYS, "home_unchanged": True,
                                  "path": "/usr/bin:/bin", "no_environment_values_dumped": True,
                                  "set": {"PYTHONDONTWRITEBYTECODE": "1", "PYTHONUNBUFFERED": "1"}}
        write_json(LAUNCH / "preflight.json", receipt)
        # The original runner owns per-gate timeout/cleanup; propagate signals to
        # that runner and allow it to close its owned fixture process group.
        with (LAUNCH / "runner.stdout.log").open("xb") as stdout, (LAUNCH / "runner.stderr.log").open("xb") as stderr:
            child = subprocess.Popen(command, cwd=ROOT, env=environment, stdin=subprocess.DEVNULL,
                                     stdout=stdout, stderr=stderr)
            def relay(signum, _frame):
                if child.poll() is None:
                    child.send_signal(signum)
            signal.signal(signal.SIGINT, relay)
            signal.signal(signal.SIGTERM, relay)
            receipt["runner_pid"] = child.pid
            receipt["runner_returncode"] = child.wait()
            stdout.flush()
            stderr.flush()
            os.fsync(stdout.fileno())
            os.fsync(stderr.fileno())
        receipt["runner_stdout"] = identity(LAUNCH / "runner.stdout.log")
        receipt["runner_stderr"] = identity(LAUNCH / "runner.stderr.log")
        report_path = OUTPUT / "report.json"
        receipt["report"] = {"path": str(report_path), **identity(report_path)}
        report = json.loads(report_path.read_text())
        receipt["gates_executed"] = len(report["gates"])
        receipt["failed_gates"] = [gate["id"] for gate in report["gates"] if not gate["passed"]]
        receipt["candidate_binding_after"] = verify_candidate_binding(manifest, args.actual_input_sha256)
        need(receipt["candidate_binding_after"] == receipt["candidate_binding_before"], "candidate binding changed during Python CI")
        checked_read(Path(__file__), args.launcher_sha256)
        receipt["passed"] = (receipt["runner_returncode"] == 0 and report["passed"] is True
                             and len(report["gates"]) == 18 and report["retry_count"] == 0
                             and report["head_commit"] == INPUT_HEAD
                             and report["manifest_sha256"] == MANIFEST_SHA256
                             and report["harness_sha256"] == RUNNER_SHA256
                             and report["final_inputs_unchanged"] is True)
    except Exception as error:
        receipt["error"] = {"type": type(error).__name__, "message": str(error)[:2000]}
    receipt["finished_unix"] = time.time()
    write_json(LAUNCH / "receipt.json", receipt)
    print(json.dumps(receipt), flush=True)
    return 0 if receipt["passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
