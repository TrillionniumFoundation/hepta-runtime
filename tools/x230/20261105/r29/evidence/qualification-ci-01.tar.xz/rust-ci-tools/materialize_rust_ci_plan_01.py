#!/usr/bin/env python3
"""Bind successful qualification01 to the two exact workflow commands; never run them."""
import argparse
import datetime
import hashlib
import json
import os
import re
from pathlib import Path
import shlex
import stat

ROOT = Path("/home/qian/hepta-runtime-optimization-20261105-r29")
SOURCE = ROOT / "source"
QUALIFICATION = ROOT / "qualification-01"
CANDIDATE_DIR = QUALIFICATION
JOB_ID = "1a1ad4261c8-fc05-593b"
SOURCE_MAP_SHA = "58ca6700a4378d14912358f9bb787d395ef5f86f17d7bf373af2525ee55ae88b"
ISOLATED_SUMMARY_SHA = "517a269344974176d7f713589915190068f72b5d40d0d91deaaad610aa5765da"
ISOLATED_AUDIT_SHA = "cee3be54342f396bd7438bf1f604ca2fa6658e35e8489c9b7d4189544326f8e4"
CI_MANIFEST_SHA = "bf0df5f7d19ebd149854fbf75887fb0fb136f18a63a0c240abf8420655fb195e"
NEXTEST_ROOT = Path("/home/qian/hepta-runtime-optimization-20261105-r25/ci-toolchain/nextest-0.9.137")
NEXTEST_RECEIPT_SHA = "2bbae481b3fbc6ac6d06a22bfe22e9500f5190b97ccddb16e8aba1ef1ed34f9d"
NEXTEST_BINARY = {
    "path": str(NEXTEST_ROOT / "bin/cargo-nextest"),
    "bytes": 33831936,
    "sha256": "9c05bd3c7c5da1286b193873f12b37db386485fa483d8fa0554e68a53d9df550",
}
QUALIFICATION_REPORT_SHA = "942a570097ab3c751e9969f3d13924dec474888e85e0ce176ee7943547d12b62"
PREPARATION_SHA = "fcc7bd5ee050a60b38c047ea9b06ac0bae1d7ebf927b67af60b620af18012782"
NATIVE_TERMINAL_SHA = "582adb11fde3f248411fa5daf25a235cc352bfae28fa3605f2898779b8b48462"
STAGES = ["format", "fmt-check", "harness-tests", "clippy", "test-build", "isolated-tests", "audit-isolated-tests", "release"]
COMMANDS = [
    {"workflow_step": "Check all targets", "argv": ["cargo", "check", "--locked", "--all-targets", "--all-features"]},
    {"workflow_step": "Test in isolated processes", "argv": ["cargo", "nextest", "run", "--locked", "--all-targets", "--all-features", "--test-threads", "1", "--retries", "0", "--no-fail-fast"]},
]
INVENTORY_COMMAND = ["cargo", "nextest", "list", "--locked", "--all-targets", "--all-features", "--message-format", "json"]
BINARY_NAMES = {"hepta-runtime", "hepta-runtime-jobctl", "native_process_driver"}


def need(value, message):
    if not value:
        raise RuntimeError(message)


def require_frozen_qualification():
    pins = [SOURCE_MAP_SHA, ISOLATED_SUMMARY_SHA, ISOLATED_AUDIT_SHA,
            QUALIFICATION_REPORT_SHA, PREPARATION_SHA, NATIVE_TERMINAL_SHA]
    need(all(type(pin) is str and len(pin) == 64
             and all(char in "0123456789abcdef" for char in pin) for pin in pins)
         and type(JOB_ID) is str and JOB_ID != "UNBOUND_ACTUAL_QUALIFICATION_JOB_ID"
         and len(JOB_ID.split("-")) == 3,
         "R29 qualification has not been frozen from actual original receipts; no plan or command may run")


def verify_r29_candidate_preparation(preparation, terminal, job_id, qualified, tests):
    """Verify actual R29 source/qualification/cache custody; never infer future passes."""
    import hashlib
    import json
    # Filled only from the reviewed final entry and its actual cache/QC/window
    # input. An unbound template cannot qualify any existing or future version.
    expected_launcher = {'path': '/home/qian/hepta-runtime-optimization-20261105-r25/tools/prepare_and_qualify_r29_01.py', 'bytes': 67635, 'sha256': '7ce339aa261fdf6acbc8e0ca8cf67f5c5d3a7b56fcc34d51ed4ee56ea4fe389a'}
    expected_input = {'path': '/home/qian/hepta-runtime-optimization-20261105-r25/tools/r29-qualification-01-input.json', 'bytes': 311502, 'sha256': '60bfe1ef593ad58d528f6e508d3f6e0a1e4f76183f1293b40f36b7ee6bb3f8a8'}
    need(isinstance(expected_launcher, dict) and isinstance(expected_input, dict),
         "R29 actual qualification entry/input identities remain unbound")
    need(isinstance(job_id, str) and re.fullmatch(r"[0-9a-f]{11,16}-[0-9a-f]{4}-[0-9a-f]{4}", job_id)
         and job_id not in {"1a1aa7fa690-fc05-43af", "1a1aaa6552d-fc05-459f", "1a1ab4cb0fc-fc05-4c3c",
                            "1a1ac274e49-fc05-5286", "1a1ac456b07-fc05-532a", "1a1ac5d5a29-fc05-53d9",
                            "1a1acfe317a-fc05-57ee"},
         "the actual new R29 qualification job is required")
    need(terminal.get("job_id") == job_id and terminal.get("state") == "succeeded"
         and type(terminal.get("exit_code")) is int and terminal["exit_code"] == 0
         and all(terminal.get(key) is False for key in ("automatic_retry", "timed_out", "cancelled"))
         and all(terminal.get(key) is True for key in ("output_complete", "output_durable", "terminal_publication_confirmed"))
         and type(terminal.get("terminal_publication_protocol")) is int and terminal["terminal_publication_protocol"] == 1
         and terminal.get("log_synced") == {"stdout": True, "stderr": True}
         and terminal.get("log_errors") == {"stdout": None, "stderr": None}
         and terminal.get("log_truncated") == {"stdout": False, "stderr": False},
         "original R29 qualification has no complete successful native terminal proof")
    for stream in ("stdout", "stderr"):
        counts = terminal["log_bytes"][stream]
        need(set(counts) == {"seen", "stored"} and all(type(value) is int and value >= 0 for value in counts.values())
             and counts["seen"] == counts["stored"], "qualification native log byte custody differs")
    need(preparation["schema"] == "hepta-r29-qualified-parent-preparation/v1"
         and preparation["selected_proposal"] == "shared unfiltered ToolRouter"
         and preparation.get("optional_pidfd_selected") is False and preparation.get("finished_utc")
         and all(preparation.get(key) is True for key in ("passed", "candidate_qualified", "parent_source_qualified",
             "parent_observation_rejection_preserved", "parent_inputs_unchanged", "cache_reused",
             "cache_source_source_qualified", "cache_moved_by_single_no_replace_rename"))
         and all(preparation.get(key) is False for key in ("candidate_adopted", "parent_candidate_adopted",
             "production_services_modified", "shared_hardlinks_created", "cache_copy_executed", "cache_cleanup_executed")),
         "actual R29 preparation is incomplete or changed the private cache scope")
    need(preparation["source"] == str(SOURCE) and preparation["target"] == str(ROOT / "target-build")
         and preparation["qualification_output"] == str(CANDIDATE_DIR)
         and preparation["launcher"] == expected_launcher and preparation["input"] == expected_input,
         "R29 qualification launcher, actual input or private paths differ")
    need(expected_launcher["path"] == "/home/qian/hepta-runtime-optimization-20261105-r25/tools/prepare_and_qualify_r29_01.py"
         and expected_input["path"] == "/home/qian/hepta-runtime-optimization-20261105-r25/tools/r29-qualification-01-input.json",
         "R29 entry belongs to another runtime attempt")
    source_cache = "/home/qian/hepta-runtime-optimization-20261105-r28/target-build"
    need(preparation["cache_source"] == source_cache and preparation["unchanged_disk_reserve_bytes"] == 3221225472
         and preparation["new_full_cache_copy_bytes"] == 0, "R29 cache reuse weakened allocation or reserve policy")
    admission = preparation["admission"]
    need(admission["original_failed_probe01_preserved_as_failed"] is True
         and admission["original_failed_probe01_error"] == {"type": "RuntimeError", "message": "directory outside exact task parent"}
         and admission["original_failed_probe01"]["job_id"] == "1a1acfe317a-fc05-57ee"
         and admission["original_failed_probe01"]["stdout_identity"] == {
             "bytes": 21898, "sha256": "7d96f345114fcad140b40f69804df679f68b8e67d57a1c46941d809cedb3c58f"}
         and admission["readonly_probe_does_not_authorize_transfer"] is True
         and admission["all_user_process_channels_readable_claimed"] is False,
         "original failed readonly probe or reference limits were promoted")
    need(admission["downloaded_QC_full_verification"] == {
        "bytes": 9585, "sha256": "7342eed4ed17389eb57f5f40111438c5c4e339591ebb77c450a4fb1fe3ae2614"}
         and admission["downloaded_QC_archive"] == {
        "bytes": 1915620, "sha256": "442586ded13a4cfde54531e6f05ddddcf26c2f53d40d15b04c5993ece5f04186"},
         "R28 full downloaded QC archive was not independently verified")
    writer = admission["root_writer_admission"]
    need(writer["schema"] == "hepta-r29-owned-cache-writer-admission/v1"
         and writer["source_cache"] == source_cache and writer["destination_cache"] == str(ROOT / "target-build")
         and writer["exclusive_compilation_window_held"] is True
         and writer["no_later_R28_cache_use_scheduled"] is True
         and writer["original_native_raw_custody_retained"] is True
         and writer["same_owner_unknowns_reviewed_without_claiming_all_channels_readable"] is True
         and writer["fd_and_mmap_reference_channels_not_covered"] is True
         and writer["root_reviewed_readonly_probe_stdout"] == admission["original_probe_stdout"]
         and writer["root_reviewed_downloaded_QC_verification"] == admission["downloaded_QC_full_verification"],
         "the actual root execution window is not bound to the preserved original evidence")
    transfer = preparation["cache_transfer"]
    need(transfer["schema"] == "hepta-r29-owned-cache-transfer/v1"
         and transfer["source_cache"] == source_cache and transfer["destination_cache"] == str(ROOT / "target-build")
         and transfer["root_writer_admission"] == writer and transfer["original_cache_probe"] == admission["original_probe_stdout"]
         and all(transfer.get(key) is True for key in ("passed", "rename_attempted", "rename_returned_success",
             "old_path_absent", "destination_is_original_inode", "descendants_metadata_unchanged"))
         and all(transfer.get(key) is False for key in ("copy_executed", "cleanup_executed", "automatic_retry", "automatic_rollback"))
         and transfer.get("finished_utc") and "error" not in transfer and "rename_errno" not in transfer,
         "the one original no-replace cache transfer did not close")
    before, immediate, after = (transfer[key] for key in ("metadata_before", "immediate_metadata_before", "metadata_after"))
    for row in (before, immediate, after):
        need(row["all_entries_traversed"] is True and row["all_regular_links_accounted_within_target"] is True
             and row["external_or_unaccounted_hardlink_inodes"] == 0 and row["retained_qualification_elf_aliases"] == []
             and row["anomaly_examples_maximum_32"] == []
             and all(row["counts"][key] == 0 for key in ("symlinks", "other_nonregular", "other_device_entries", "other_owner_entries")),
             "cache metadata escaped the original owned regular/directory scope")
    need(before["path"] == immediate["path"] == source_cache and after["path"] == str(ROOT / "target-build")
         and before["counts"] == immediate["counts"] == after["counts"]
         and before["root_identity"] == immediate["root_identity"]
         and before["metadata_sha256"] == immediate["metadata_sha256"]
         and before["descendants_metadata_sha256"] == immediate["descendants_metadata_sha256"] == after["descendants_metadata_sha256"],
         "cache descendants or pre-transfer identity changed")
    root_fields = ("st_dev", "st_ino", "st_uid", "st_gid", "st_mode", "st_nlink", "st_size", "st_mtime_ns")
    need(all(immediate["root_identity"][key] == after["root_identity"][key] for key in root_fields)
         and after["root_identity"]["st_ctime_ns"] >= immediate["root_identity"]["st_ctime_ns"]
         and transfer["root_ctime_before"] == immediate["root_identity"]["st_ctime_ns"]
         and transfer["root_ctime_after"] == after["root_identity"]["st_ctime_ns"],
         "cache root identity changed beyond rename ctime")
    need(preparation["cache_bytes"] == before["counts"]["regular_logical_bytes"]
         and preparation["cache_file_count"] == before["counts"]["regular_files"], "cache size accounting differs")
    for scan in (preparation["cache_reference_scan_before_source"], transfer["immediate_reference_scan"]):
        need(scan["matched_live_processes"] == [] and scan["raw_argv_or_environment_or_unrelated_cwd_emitted"] is False,
             "an observed cache reference was ignored")
    for samples in (preparation["compiler_quiescence"], preparation["compiler_quiescence_immediately_before_move"]):
        need(isinstance(samples, list) and samples and samples[-1]["compiler_processes"] == [],
             "compiler quiet admission did not finish")
    for disk in (preparation["disk_after_fresh_source_before_move"], transfer["disk_before_move"],
                 preparation["disk_immediately_before_compiler"]):
        need(disk["unchanged_required_headroom_bytes"] == 3221225472
             and type(disk["available_bytes"]) is int and disk["available_bytes"] >= 3221225472
             and disk["new_full_cache_copy_bytes"] == 0 and disk["move_frees_bytes"] is False
             and disk["future_build_growth_guaranteed_to_fit"] is False,
             "the unchanged 3 GiB reserve was not checked at the actual admission boundaries")
    retained = preparation["retained_parent_ELFs_before"]
    need(len(retained) == 8 and len({row["path"] for row in retained}) == 8
         and retained == preparation["retained_parent_ELFs_after_qualification"]
         == transfer["retained_parent_ELFs_before"] == transfer["retained_parent_ELFs_after"],
         "the eight retained R28 ELF copies were not preserved")
    for row in retained:
        d = row["current_identity"]
        need(row["path"].startswith("/home/qian/hepta-runtime-optimization-20261105-r28/qualification-01/")
             and d["st_uid"] == 1000 and d["st_nlink"] == 1 and d["st_mode"] & 0o170000 == 0o100000
             and d["st_size"] == row["bytes"] and row["full_export_identity_unchanged"] is True
             and row["sha256_recomputed_by_this_metadata_probe"] is False and row["payload_read_bytes"] == 0,
             "an original retained ELF descriptor was substituted or reclassified")
    transfer_raw = (json.dumps(transfer, sort_keys=True, indent=2, allow_nan=False) + "\n").encode()
    need(preparation["cache_transfer_receipt"] == {"path": str(ROOT / "target-transfer-01.json"),
         "bytes": len(transfer_raw), "sha256": hashlib.sha256(transfer_raw).hexdigest()},
         "embedded transfer proof differs from the original closed receipt")
    expected_changes = [
        {"path": "src/mcp/server.rs", "before": {"bytes": 118630, "sha256": "875785604d51feba6b02fdf1a6699b8d361d065a44cc4ef7bee6f931521e7e71"},
         "after": {"bytes": 118947, "sha256": "e6f34ef9ace819f72ceafaeee40a957210362f87cc4317d6ebfe4b76ba2fa4d4"}},
        {"path": "src/mcp/server_tests.rs", "before": {"bytes": 38983, "sha256": "003fa3365b3af0302c4a8e19f9230cea35f3366878898c1cf0920b2b6d47cddb"},
         "after": {"bytes": 49832, "sha256": "f4dfdc9c26ef3fdbba4dd2b5d0cfe3f239230a43cb78162bbba21a1c0499cc7f"}}]
    need(preparation["source_changes"] == expected_changes, "R29 is not the exact selected two-file router change")
    before_map = preparation["source_before"]
    expected = dict(before_map)
    changed_paths = {change["path"] for change in expected_changes}
    need(len(before_map) == 221 and len(changed_paths) == 2, "R29 source/change inventory differs")
    for change in expected_changes:
        need(before_map[change["path"]] == change["before"]["sha256"], "R29 qualified parent preimage differs")
        expected[change["path"]] = change["after"]["sha256"]
    need(hashlib.sha256((json.dumps(before_map, sort_keys=True, indent=2) + "\n").encode()).hexdigest()
         == "da8cbdfef75c1c9fc5861e4fe0bd96aeb98f635e95fc122610021cd725db1d28",
         "the R29 parent is not the actual complete qualified R28 map")
    need(preparation["candidate_compilation_inputs"] == expected
         and hashlib.sha256((json.dumps(expected, sort_keys=True, indent=2) + "\n").encode()).hexdigest()
         == "ce3e814a7bfeb7f0d168782dc325e643550cc0c768b606d90c4d45693fbe4853",
         "R29 pre-format compilation input differs")
    stages = ["format", "fmt-check", "harness-tests", "clippy", "test-build", "isolated-tests", "audit-isolated-tests", "release"]
    need(qualified["schema"] == "hepta-x230-composed-qualification/v1" and qualified["qualified"] is True
         and qualified.get("finished_utc") and qualified["source"] == str(SOURCE)
         and qualified["jobs"] == 2 and qualified["service_changes"] is False
         and type(qualified["automatic_test_retries"]) is int and qualified["automatic_test_retries"] == 0
         and [row["name"] for row in qualified["stages"]] == stages
         and all(type(row["returncode"]) is int and row["returncode"] == 0 for row in qualified["stages"]),
         "all eight original R29 qualification stages must pass")
    need(qualified["source_input"] == expected and qualified["source_tested"] == qualified["source_after"] == preparation["source_tested"]
         and set(qualified["source_after"]) == set(expected)
         and all(qualified["source_after"][name] == value for name, value in expected.items() if name not in changed_paths),
         "actual formatted R29 source differs from its qualification")
    need(preparation["formatter_changed_paths"] == [name for name in expected if qualified["source_after"][name] != expected[name]]
         and qualified["harness_before"] == qualified["harness_after"] == preparation["harness_before"]
         and len(qualified["harness_after"]) == 19, "qualification formatter or original harness binding differs")
    counts = ("passed", "failed", "ignored", "selected", "retries")
    need(all(type(tests[key]) is int for key in counts) and [tests[key] for key in counts] == [1655, 0, 34, 1689, 0]
         and tests["success"] is True and tests["filter"] == "" and not tests["enumeration_errors"]
         and preparation["tests"] == tests and preparation["qualification_returncode"] == 0
         and preparation["automatic_test_retries"] == 0, "original full R29 isolated result is incomplete")
    new_names = ["mcp::server::server_tests::cached_router_keeps_mcp_sessions_and_teardown_independent",
                 "mcp::server::server_tests::cached_router_rechecks_runtime_mode_and_native_session_owner"]
    need([row["name"] for row in preparation["new_exact_tests"]] == new_names
         and all(row["status"] == "passed" and row["executed"] is True and row["attempt"] == 1
                 and row["exit_code"] == 0 and row["timed_out"] is False for row in preparation["new_exact_tests"]),
         "the two new original exact cases were not executed once successfully")
    need(preparation["qualification_argv"] == ["/usr/bin/python3", "-B", str(SOURCE / "tools/x230/20261028/qualify.py"),
         "--source", str(SOURCE), "--output", str(CANDIDATE_DIR), "--target", str(ROOT / "target-build"),
         "--cargo-home", "/home/qian/hepta-runtime-optimization-20261023/cargo-home-a32-a33-r02",
         "--jobs", "2", "--stage-timeout", "3600"], "the original qualification argv was weakened")
    return {"passed": True, "original_job_id": job_id, "selected_proposal": "shared unfiltered ToolRouter",
            "optional_pidfd_selected": False, "qualified_source_files": 221, "harness_files": 19, "stages": stages,
            "tests": {key: tests[key] for key in counts}, "candidate_adopted": False,
            "qualified_parent_R28_observation_rejection_preserved": True,
            "original_failed_readonly_probe01_preserved": True, "single_no_replace_cache_move_verified": True,
            "cache_copy_executed": False, "cache_cleanup_executed": False, "unchanged_disk_reserve_bytes": 3221225472}

def verify_preparation(value, qualified, qualification_identity, terminal):
    """Reuse the one canonical R29 gate plus the exact original report binding."""
    verify_r29_candidate_preparation(value, terminal, JOB_ID, qualified, value["tests"])
    need(type(value.get("finished_utc")) is str and bool(value["finished_utc"])
         and value["qualification_report"] == qualification_identity,
         "actual R29 preparation report identity differs")


def read_file(path, retain=False):
    path = Path(path)
    need(path.is_absolute() and path.resolve(strict=True) == path, "indirect input: " + str(path))
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK | os.O_CLOEXEC)
    try:
        before = os.fstat(fd)
        need(stat.S_ISREG(before.st_mode), "nonregular input: " + str(path))
        with os.fdopen(os.dup(fd), "rb") as stream:
            if retain:
                raw = stream.read()
                digest = hashlib.sha256(raw).hexdigest()
            else:
                raw = None
                digest = hashlib.file_digest(stream, "sha256").hexdigest()
        after = os.fstat(fd)
        fields = ("st_dev", "st_ino", "st_size", "st_mode", "st_uid", "st_mtime_ns", "st_ctime_ns")
        need(tuple(getattr(before, k) for k in fields) == tuple(getattr(after, k) for k in fields)
             == tuple(getattr(path.lstat(), k) for k in fields), "input changed: " + str(path))
    finally:
        os.close(fd)
    return {"path": str(path), "bytes": before.st_size, "sha256": digest}, raw


def verify_terminal(value):
    need(value.get("job_id") == JOB_ID and value.get("state") == "succeeded"
         and type(value.get("exit_code")) is int and value["exit_code"] == 0
         and all(value.get(k) is False for k in ("automatic_retry", "cancelled", "timed_out"))
         and all(value.get(k) is True for k in ("output_complete", "output_durable", "terminal_publication_confirmed"))
         and type(value.get("terminal_publication_protocol")) is int and value["terminal_publication_protocol"] == 1
         and value.get("log_synced") == {"stdout": True, "stderr": True}
         and value.get("log_errors") == {"stdout": None, "stderr": None}
         and value.get("log_truncated") == {"stdout": False, "stderr": False},
         "original qualification01 job lacks complete successful terminal proof")


def verify_qualification(value):
    need(value.get("schema") == "hepta-x230-composed-qualification/v1"
         and value.get("qualified") is True and value.get("finished_utc")
         and value.get("source") == str(SOURCE), "qualification01 is not completed and successful")
    need([row["name"] for row in value["stages"]] == STAGES
         and all(type(row["returncode"]) is int and row["returncode"] == 0 for row in value["stages"]),
         "all eight original qualification stages must pass")
    need(type(value.get("automatic_test_retries")) is int and value["automatic_test_retries"] == 0,
         "qualification retries must be zero")
    need(value["source_tested"] == value["source_after"] and len(value["source_after"]) == 221,
         "qualified source changed or inventory differs")
    need(value["harness_before"] == value["harness_after"] and len(value["harness_after"]) == 19,
         "original 19 qualification harness inputs changed")
    need(set(value["binaries"]) == BINARY_NAMES, "retained qualified binary set differs")


def main():
    require_frozen_qualification()
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--qualification", type=Path, default=QUALIFICATION / "report.json")
    parser.add_argument("--qualification-sha256", required=True)
    parser.add_argument("--terminal-status", type=Path, default=ROOT / "qualification-terminal-status-01.json")
    parser.add_argument("--terminal-status-sha256", required=True)
    parser.add_argument("--ci-manifest", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    need(args.qualification == QUALIFICATION / "report.json", "qualification path must be attempt01")
    need(args.terminal_status == ROOT / "qualification-terminal-status-01.json", "terminal path must be attempt01")
    need(args.out.is_absolute() and args.out.parent.resolve(strict=True) == args.out.parent
         and args.out.is_relative_to(ROOT) and not os.path.lexists(args.out), "fresh private plan output required")
    need(args.qualification_sha256 == QUALIFICATION_REPORT_SHA
         and args.terminal_status_sha256 == NATIVE_TERMINAL_SHA, "frozen actual R29 report or terminal pin differs")
    bindings = []

    def bind(path, digest=None, json_value=False, retain=False):
        identity, raw = read_file(path, retain=json_value or retain)
        need(digest is None or identity["sha256"] == digest, "bound SHA differs: " + str(path))
        bindings.append(identity)
        return identity, json.loads(raw) if json_value else raw

    terminal_identity, terminal = bind(args.terminal_status, args.terminal_status_sha256, json_value=True)
    verify_terminal(terminal)
    qualification_identity, qualified = bind(args.qualification, args.qualification_sha256, json_value=True)
    verify_qualification(qualified)
    preparation_identity, preparation = bind(ROOT / "preparation-01.json", PREPARATION_SHA, json_value=True)
    verify_preparation(preparation, qualified, qualification_identity, terminal)
    for key in ("launcher", "input"):
        actual_preparation_input, _ = bind(Path(preparation[key]["path"]), preparation[key]["sha256"])
        need(actual_preparation_input == preparation[key], "actual preparation input differs: " + key)
    ci_identity, ci = bind(args.ci_manifest, CI_MANIFEST_SHA, json_value=True)
    map_identity, source_map = bind(QUALIFICATION / "source-map.json", SOURCE_MAP_SHA, json_value=True)
    need(source_map == qualified["source_after"], "actual qualification source map differs")
    files = [SOURCE / name for name in ("Cargo.toml", "Cargo.lock", "rustfmt.toml")]
    for directory in ("src", "examples"):
        files.extend(path for path in (SOURCE / directory).rglob("*") if path.is_file())
    actual = {path.relative_to(SOURCE).as_posix(): bind(path)[0]["sha256"] for path in sorted(files)}
    need(actual == source_map, "actual compiler inputs differ from successful qualification01")
    harness = {path.name: bind(path)[0]["sha256"] for path in sorted((SOURCE / "tools/x230/20261028").glob("*.py"))}
    need(harness == qualified["harness_after"], "actual qualification harness differs")
    binaries = {}
    for name, expected in qualified["binaries"].items():
        path = Path(expected["path"])
        need(path == QUALIFICATION / name and os.access(path, os.X_OK), "qualified executable path differs")
        binaries[name] = bind(path, expected["sha256"])[0]

    summary_identity, summary = bind(QUALIFICATION / "isolated-tests/summary.json", ISOLATED_SUMMARY_SHA, json_value=True)
    need(preparation.get("tests") == summary, "preparation tests differ from the complete actual isolated summary")
    audit_identity, audit = bind(QUALIFICATION / "isolated-tests.audit.json", ISOLATED_AUDIT_SHA, json_value=True)
    need(summary.get("schema") == "hepta-isolated-libtest/v1" and summary.get("success") is True
         and summary.get("filter") == "" and summary.get("enumeration_errors") == []
         and summary.get("retries") == 0 and summary.get("failed") == 0,
         "isolated suite must be complete, unfiltered, successful and unretried")
    need(audit.get("schema") == "hepta-isolated-libtest-audit/v1" and audit.get("success") is True
         and audit.get("errors") == [] and "fatal_error" not in audit and audit.get("expected_filter") == "",
         "independent isolated-suite audit did not pass")
    counts = {key: summary[key] for key in ("passed", "failed", "ignored", "selected", "retries")}
    need(all(type(value) is int and value >= 0 for value in counts.values())
         and counts["passed"] > 0 and counts["selected"] == counts["passed"] + counts["ignored"],
         "invalid complete test counts")
    need(counts == {"passed": 1655, "failed": 0, "ignored": 34, "selected": 1689, "retries": 0},
         "full selected R29 suite counts differ")
    need(all(audit[key] == counts[key] for key in ("passed", "failed", "ignored", "selected"))
         and audit["executed"] == counts["passed"], "audited test counts differ")
    need(summary["source_manifest_path"] == str(QUALIFICATION / "source-map.json")
         and summary["source_manifest_sha256"] == map_identity["sha256"], "suite source binding differs")
    need(audit["input_sha256"]["summary.json"] == summary_identity["sha256"], "audited summary changed")
    for filename, digest in audit["input_sha256"].items():
        need(Path(filename).name == filename and filename not in {".", ".."}, "unsafe audit input name")
        bind(QUALIFICATION / "isolated-tests" / filename, digest)
    need(summary["artifacts_path"] == str(QUALIFICATION / "retained-artifacts.jsonl"), "Cargo artifact path differs")
    bind(QUALIFICATION / "retained-artifacts.jsonl", summary["artifacts_sha256"])
    target_inventory = []
    targets = {}
    for row in summary["binaries"]:
        path = Path(row["path"])
        need(path.parent == QUALIFICATION / "test-binaries", "retained test executable outside qualification01")
        test_binary = bind(path, row["sha256"])[0]
        target = {"target_name": row["target"]["name"], "target_kind": row["target"]["kind"]}
        need(str(path) not in targets, "duplicate test executable")
        targets[str(path)] = target
        target_inventory.append(dict(target, inventory_count=row["inventory_count"], ignored_names=row["ignored_names"], qualified_test_binary=test_binary))
    _, raw = bind(QUALIFICATION / "isolated-tests/tests.jsonl", audit["input_sha256"]["tests.jsonl"], retain=True)
    cases = []
    for line in raw.splitlines():
        row = json.loads(line)
        ignored = row["status"] == "ignored"
        need(row["status"] in {"passed", "ignored"} and row["attempt"] == (0 if ignored else 1)
             and row["executed"] is (not ignored), "invalid or retried case record")
        cases.append(dict(targets[row["binary"]], name=row["name"], ignored=ignored))
    cases.sort(key=lambda row: (row["target_name"], row["target_kind"], row["name"]))
    need(len(cases) == counts["selected"] and sum(row["ignored"] for row in cases) == counts["ignored"],
         "complete case ledger counts differ")
    need(len({(row["target_name"], tuple(row["target_kind"]), row["name"]) for row in cases}) == len(cases),
         "duplicate exact qualified case")

    for job_name in ("runtime-head-ci", "runtime-merge-ci"):
        commands = []
        for step in ci["workflow"]["jobs"][job_name]["steps"]:
            for line in step.get("run", "").replace("\\\n", " ").splitlines():
                if line.startswith("cargo check ") or line.startswith("cargo nextest run "):
                    commands.append({"workflow_step": step["name"], "argv": shlex.split(line)})
        need(commands == COMMANDS, "workflow Cargo check/nextest commands differ")
    nextest_identity, nextest = bind(NEXTEST_ROOT / "receipt.json", NEXTEST_RECEIPT_SHA, json_value=True)
    need(nextest.get("schema") == "hepta-r25-private-nextest-install-v1" and nextest.get("passed") is True
         and nextest["release_id"] == 329695549 and nextest["asset_id"] == 430502414
         and nextest["archive"]["sha256"] == "38fd6275e111b200bbbed1bd2ae91cbb0d7edd28504879875cff2b3d96f3f311"
         and nextest["nextest_version"]["returncode"] == 0
         and nextest["nextest_version"]["stdout"].startswith("cargo-nextest 0.9.137 (75ddba7e9 2026-05-26)"),
         "installed nextest receipt differs")
    need({key: nextest["binary"][key] for key in NEXTEST_BINARY} == NEXTEST_BINARY, "installed binary receipt differs")
    nextest_binary, _ = bind(Path(NEXTEST_BINARY["path"]), NEXTEST_BINARY["sha256"])
    need(nextest_binary == NEXTEST_BINARY and os.access(nextest_binary["path"], os.X_OK), "installed nextest binary differs")

    config_inventory = []
    for name in (".cargo/config", ".cargo/config.toml", ".config/nextest.toml", "rust-toolchain", "rust-toolchain.toml"):
        path = SOURCE / name
        config_inventory.append({"path": str(path), "exists": os.path.lexists(path),
                                 "identity": bind(path)[0] if os.path.lexists(path) else None})
    for expected in bindings:
        need(read_file(Path(expected["path"]))[0] == expected, "input changed before plan publication")
    for row in config_inventory:
        need(os.path.lexists(row["path"]) is row["exists"], "tool configuration appeared or disappeared")
    report = {
        "schema": "hepta-r29-materialized-exact-rust-ci-plan/v1", "attempt": "01",
        "created_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
        "executed": False, "hosted_actions_passed": False,
        "preparation": preparation_identity,
        "qualification": qualification_identity, "qualification_terminal_status": terminal_identity,
        "qualification_job_id": JOB_ID, "source_map": map_identity,
        "source": str(SOURCE), "source_files": actual, "qualified_binaries": binaries,
        "qualification_harness": harness, "qualification_summary": summary_identity,
        "qualification_independent_audit": audit_identity, "qualification_counts": counts,
        "workflow_head": ci["head_commit"], "workflow_git_blob": ci["workflow_git_blob"], "ci_manifest": ci_identity,
        "commands": [dict(row, cwd=str(SOURCE)) for row in COMMANDS],
        "inventory_command": {"argv": INVENTORY_COMMAND, "cwd": str(SOURCE), "timeout_seconds": 900,
            "scope": "One unfiltered structured inventory; Cargo may build and test binaries execute --list, but no test case is executed by this command."},
        "nextest_install_receipt": nextest_identity, "nextest_binary": nextest_binary,
        "expected_nextest": {"passed": counts["passed"], "failed": 0, "skipped": counts["ignored"],
            "total": counts["selected"], "retries": 0, "test_target_inventory": target_inventory,
            "exact_cases": cases,
            "case_inventory_sha256": hashlib.sha256(json.dumps(cases, sort_keys=True, separators=(",", ":")).encode()).hexdigest(),
            "comparison": "Require full exact unfiltered case inventory and ignored set, plus footer counts; zero-test targets may be omitted from a runner's display, but no nonempty target or case may disappear."},
        "environment": {"PATH": str(NEXTEST_ROOT / "bin") + ":/home/qian/.cargo/bin:/usr/local/bin:/usr/bin:/bin",
            "RUSTUP_TOOLCHAIN": "1.95.0", "CARGO_HOME": "/home/qian/hepta-runtime-optimization-20261023/cargo-home-a32-a33-r02",
            "CARGO_TARGET_DIR": str(ROOT / "target-build"), "CARGO_BUILD_JOBS": "2", "CARGO_INCREMENTAL": "0",
            "CARGO_NET_OFFLINE": "true", "RUST_TEST_THREADS": "1", "TOKIO_WORKER_THREADS": "2",
            "PYTHONDONTWRITEBYTECODE": "1", "PYTHONNOUSERSITE": "1",
            "CARGO_TERM_COLOR": "never", "NEXTEST_STATUS_LEVEL": "pass",
            "NEXTEST_FINAL_STATUS_LEVEL": "fail", "NEXTEST_SUCCESS_OUTPUT": "never"},
        "reporting_environment_note": "Pinned nextest0.9.137 supported reporting-only environment settings preserve original run argv, emit every completed success once, suppress successful test stdout and keep color-free evidence. They do not alter case selection, retries or execution concurrency.",
        "remove_environment_prefixes": ["HEPTA_", "SSH_", "RUST_TEST_", "NEXTEST_"],
        "remove_environment_keys": ["RUSTFLAGS", "CARGO_ENCODED_RUSTFLAGS", "RUSTDOCFLAGS", "RUSTC_WRAPPER", "RUSTC_WORKSPACE_WRAPPER", "PYTHONPATH", "PYTHONHOME", "RUST_LOG"],
        "tool_configuration_inventory": config_inventory, "umask": "0022", "input_bindings": bindings,
        "execution_contract": {"fresh_evidence_directory": str(ROOT / "rust-ci-01"), "automatic_retries": 0,
            "cargo_clean": False, "check_timeout_seconds": 1800, "nextest_timeout_seconds": 3600,
            "combined_timeout_seconds": 5400, "inventory_timeout_seconds": 900,
            "outer_budget_seconds": 6600, "retain_full_original_stdout_stderr": True,
            "no_extra_nextest_filters_or_weaker_flags": True, "no_candidate_workload_or_service_change": True,
            "exact_version_preflight": "Record cargo/rustc 1.95.0 and cargo nextest 0.9.137; verify which cargo-nextest resolves to the bound private binary.",
            "scheduling": "Run only after the bound original qualification01 terminal success, with no overlapping compiler or measurement campaign.",
            "ownership": "Record original Popen PID/birth/group, supervise and wait/reap only that owned process group; unknown cleanup or timed-out dispatch must be reconciled before any resubmission.",
            "identity": "Recheck every bound input and configuration presence immediately before and after; require unchanged source, retained qualified binaries and nextest executable.",
            "pass_requires": "Both exact commands exit0, no timeout or automatic retry, complete case/count match to actual qualified inventory, unchanged inputs, and original owned child/group absent."},
        "limits": ["External command evidence does not mark hosted GitHub Actions passed.",
            "Offline Cargo, private completed qualification01 target/cache and prebuilt pinned nextest are explicit environment differences from GitHub's online clean runner and cargo-install step.",
            "Publishing the tested source and prospective-merge Git tree binding remain separate.",
            "No measurement, deployment or candidate adoption is implied by materializing this plan."],
    }
    with args.out.open("x") as stream:
        json.dump(report, stream, sort_keys=True, indent=2)
        stream.write("\n")
    print(json.dumps({"plan": read_file(args.out)[0], "executed": False, "qualification_counts": counts}))


if __name__ == "__main__":
    main()
