#!/usr/bin/env python3
# Copyright 2026 TrillionniumFoundation
# SPDX-License-Identifier: Apache-2.0
"""Qualify exact R29 source once, after one admitted R28-owned cache move.
Unbound cache/QC/writer evidence rejects before any directory or file mutation.
No service change, cache copy, cleanup, automatic move retry or rollback.
"""
import argparse
import ctypes
import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import stat
import subprocess
import sys
import time
import traceback

ROOT = Path('/home/qian/hepta-runtime-optimization-20261105-r29')
PARENT = Path('/home/qian/hepta-runtime-optimization-20261105-r28')
ACCEPTED = Path('/home/qian/hepta-runtime-optimization-20261105-r24')
OLD_SOURCE = PARENT / 'source'
SOURCE = ROOT / 'source'
TARGET = ROOT / 'target-build'
OUTPUT = ROOT / 'qualification-01'
INPUT = Path('/home/qian/hepta-runtime-optimization-20261105-r25/tools/r29-qualification-01-input.json')
ROOT24 = str(ACCEPTED)
ROOT26 = '/home/qian/hepta-runtime-optimization-20261105-r26'
ROOT28 = str(PARENT)
ROOT29 = str(ROOT)
CACHE = ROOT28 + '/target-build'
OWNER = 1000
CACHES = (('owned_r28_target', CACHE, False),)
FIELDS = ('st_dev', 'st_ino', 'st_uid', 'st_gid', 'st_mode', 'st_nlink', 'st_size', 'st_mtime_ns', 'st_ctime_ns')
EXPORT_FIELDS = ('st_dev', 'st_ino', 'st_uid', 'st_mode', 'st_nlink', 'st_size', 'st_mtime_ns', 'st_ctime_ns')
DEAD = {'Z', 'X', 'x'}
START = time.monotonic_ns()
MAX_DURATION_NS = 120 * 10**9
MAX_TREE_ENTRIES = 200000
MAX_PROCESSES = 16384
MAX_PROC_BYTES = 1048576
PROTECTED_ELF_INODES = set()
RESERVE_BYTES = 3 * 1024**3
CHANGED_PATHS = ('src/mcp/server.rs', 'src/mcp/server_tests.rs')
STAGES = ['format', 'fmt-check', 'harness-tests', 'clippy', 'test-build',
          'isolated-tests', 'audit-isolated-tests', 'release']
PUBLICATION_SHA = '38866c01fac54133c8a88e25bee90ea4a551e7273614f493bf44522a8273d3ca'
PROBE_SOURCE_SHA = '088b102aec64ea0606ba1dfb09dfc73b5d332f76a08b5ad68cd1847300a914d2'
QC_CONSUMER_SHA = 'c949b88484f348a53e9aadde9b92c248d08c507347faea2e978ed0639dd3df73'
QC_ARCHIVE = {'bytes': 1915620, 'sha256': '442586ded13a4cfde54531e6f05ddddcf26c2f53d40d15b04c5993ece5f04186'}
QC_EXPORT_JOB = '1a1acd29fba-fc05-5724'
REJECTION_REPORT_SHA = '9fd45bf5f9987b849c637bdf3ed61f3b49b4f98b615dd914d16e0afa80822ba5'
REJECTION_SUMMARY_SHA = 'c1df02071f3ebecde73de47cc3fe62daef2908981486db40287a995daabf5a0c'
REJECTION_NATIVE_SHA = '3df7bbc9acc621a6c1eeaf85e4fe21870cb62ba5df0f423e2b67a6e8f236860e'
NEW_EXACT_TESTS = (
    'mcp::server::server_tests::cached_router_keeps_mcp_sessions_and_teardown_independent',
    'mcp::server::server_tests::cached_router_rechecks_runtime_mode_and_native_session_owner')
BOUND = {'isolated_summary': ('/home/qian/hepta-runtime-optimization-20261105-r28/qualification-01/isolated-tests/summary.json',
                      6878,
                      'a6645dbb6a0208fdbca1a3dd6308c55f7d6b876ef4ddf70f02a2b4c58c9db46d'),
 'preparation': ('/home/qian/hepta-runtime-optimization-20261105-r28/preparation-02.json',
                 96494,
                 '4ece02608c423456d0996de39c54129c6c759a1973a0e11f22b04f936b113cc3'),
 'qc_export': ('/home/qian/hepta-runtime-optimization-20261105-r28/qualification-ci-evidence-01/report.json',
               11627,
               'e150979b4024edf8c82450b6c18beb7492306928f7f61a3b8247e4977e7862d0'),
 'qc_manifest': ('/home/qian/hepta-runtime-optimization-20261105-r28/qualification-ci-evidence-01/manifest.json',
                 2745831,
                 '9ed5ce8099685e6fff9e1f0ecb2b7b980f6e2dc410cf2413bd189d72a8395a9d'),
 'qualification': ('/home/qian/hepta-runtime-optimization-20261105-r28/qualification-01/report.json',
                   83735,
                   '9e564f3950575313034f55974303e56c236ac030e2c5f121d49791da0c4c09fa'),
 'qualified_source_map': ('/home/qian/hepta-runtime-optimization-20261105-r28/qualification-01/source-map.json',
                          24278,
                          'da8cbdfef75c1c9fc5861e4fe0bd96aeb98f635e95fc122610021cd725db1d28'),
 'rust_ci': ('/home/qian/hepta-runtime-optimization-20261105-r28/rust-ci-01/report.json',
             14131,
             '89478d995d449181fb8066165c0802f8d11770254b9deea13bc3b28c8f5e3dbc')}
KNOWN_OPERATIONS = {'python_ci01': {'exit_code': 1,
                 'job_id': '1a1ac97d8cb-fc05-55a2',
                 'report': {'bytes': 1506,
                            'path': '/home/qian/hepta-runtime-optimization-20261105-r28/python-ci-launch-01/receipt.json',
                            'sha256': '3b24569825c641d07249d71d9e064d703ee760e728eac96c979345bb2774dd96'},
                 'state': 'failed',
                 'terminal': {'bytes': 728,
                              'path': '/home/qian/hepta-runtime-optimization-20261105-r28/python-ci-terminal-status-01.json',
                              'sha256': '9979d74c66b765d8ac10de4e42b224cca7f2c26c6df7030457e09a029abb2d60'}},
 'python_ci02': {'exit_code': 0,
                 'job_id': '1a1acb64a3e-fc05-5682',
                 'report': {'bytes': 11546,
                            'path': '/home/qian/hepta-runtime-optimization-20261105-r28/python-ci-launch-02/receipt.json',
                            'sha256': 'f525b13f3f225635d7e2e745cd2d9befe1962162e682031056431c31d4ae1d91'},
                 'state': 'succeeded',
                 'terminal': {'bytes': 731,
                              'path': '/home/qian/hepta-runtime-optimization-20261105-r28/python-ci-terminal-status-02.json',
                              'sha256': '5075b6bdfffd058d59d385daae74ffb831959ebcd2d9c1daaa259c3424ff291c'}},
 'qualification02': {'exit_code': 0,
                     'job_id': '1a1ac5d5a29-fc05-53d9',
                     'report': {'bytes': 83735,
                                'path': '/home/qian/hepta-runtime-optimization-20261105-r28/qualification-01/report.json',
                                'sha256': '9e564f3950575313034f55974303e56c236ac030e2c5f121d49791da0c4c09fa'},
                     'state': 'succeeded',
                     'terminal': {'bytes': 731,
                                  'path': '/home/qian/hepta-runtime-optimization-20261105-r28/qualification-terminal-status-02.json',
                                  'sha256': '3325b116b998ddff0e586a3b983a2715339acb1b48e9215f5b92e9abfdde4946'}},
 'qualification_failed01': {'exit_code': 1,
                            'job_id': '1a1ac274e49-fc05-5286',
                            'report': {'bytes': 4671,
                                       'path': '/home/qian/hepta-runtime-optimization-20261105-r28/preparation-01.json',
                                       'sha256': 'abc26b3d49c2e57b608fe3aba792708e80de95340c1c8c210dced2844953fade'},
                            'state': 'failed',
                            'terminal': {'bytes': 726,
                                         'path': '/home/qian/hepta-runtime-optimization-20261105-r28/qualification-terminal-status-01.json',
                                         'sha256': '8dee0438ff40dc85288ff6d9ff6da9dfcdfc36092bbc12995bd99018f3d00d31'}},
 'rust_ci01': {'exit_code': 0,
               'job_id': '1a1ac8bfc0c-fc05-552c',
               'report': {'bytes': 14131,
                          'path': '/home/qian/hepta-runtime-optimization-20261105-r28/rust-ci-01/report.json',
                          'sha256': '89478d995d449181fb8066165c0802f8d11770254b9deea13bc3b28c8f5e3dbc'},
               'state': 'succeeded',
               'terminal': {'bytes': 731,
                            'path': '/home/qian/hepta-runtime-optimization-20261105-r28/rust-ci-terminal-status-01.json',
                            'sha256': '24c48bc1d951fee3e22dd06a4502834b3a19bda089b00eac4be5cd666046369e'}}}
FAILED_PROBE_SPEC = {'job_id': '1a1acfe317a-fc05-57ee',
 'native_read_page_identities': [{'bytes': 50981,
                                  'sha256': '0453204d61dcfea47fe301271eede5c0890a082619ab3b92599fb4a07c1f251c'},
                                 {'bytes': 17245,
                                  'sha256': 'eb4926d5ef4db33ea106b777abb262716f0a1007b7f48518c31dbfe0cfcdbcde'}],
 'native_terminal_identity': {'bytes': 730,
                              'sha256': 'cba5670b8ed6e516258728bea1c32224e70393d71f0e112e9fa9f8f09482ba6a'},
 'source_sha256': '9242d4b6f2d9b21b80b7cba7f1aabb23e6f9e222a43b7000d064b7edf532b9a0',
 'stdout_identity': {'bytes': 21898,
                     'sha256': '7d96f345114fcad140b40f69804df679f68b8e67d57a1c46941d809cedb3c58f'}}
TRANSFORM_SHA = '550080227753a739cf753c9ec5a03a81c40305a5ca1858d133d9d23718471e94'
CANDIDATE_MAP_SHA = 'ce3e814a7bfeb7f0d168782dc325e643550cc0c768b606d90c4d45693fbe4853'
CANDIDATE_MANIFEST = {'bytes': 81083, 'sha256': '16316a0064564f74cdfe747e1c7a2a046317970b3c62ccea33aa9489b32e2af1'}

def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()

def encoded(value):
    return (json.dumps(value, sort_keys=True, indent=2, allow_nan=False) + '\n').encode()

def stamp(value):
    return tuple(getattr(value, key) for key in ('st_dev', 'st_ino', 'st_mode',
                 'st_uid', 'st_nlink', 'st_size', 'st_mtime_ns', 'st_ctime_ns'))

def read(path, expected=None, retain=False):
    path = Path(path)
    assert path.is_absolute() and path.resolve(strict=True) == path, str(path)
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_CLOEXEC | os.O_NONBLOCK)
    try:
        before = os.fstat(fd)
        assert stat.S_ISREG(before.st_mode) and before.st_uid == os.geteuid()
        assert before.st_nlink == 1 and not before.st_mode & (stat.S_ISUID | stat.S_ISGID)
        assert 0 <= before.st_size <= 1024**3
        digest, size, blocks = hashlib.sha256(), 0, []
        while block := os.read(fd, 1024 * 1024):
            size += len(block)
            assert size <= before.st_size
            digest.update(block)
            if retain:
                blocks.append(block)
        assert size == before.st_size and stamp(before) == stamp(os.fstat(fd)) == stamp(path.lstat())
        assert expected is None or digest.hexdigest() == expected, str(path)
        return {'path': str(path), 'bytes': size, 'sha256': digest.hexdigest()}, b''.join(blocks)
    finally:
        os.close(fd)

def source_map(root):
    paths = [root / name for name in ('Cargo.toml', 'Cargo.lock', 'rustfmt.toml')]
    for name in ('src', 'examples'):
        paths.extend(path for path in (root / name).rglob('*') if path.is_file())
    return {path.relative_to(root).as_posix(): read(path)[0]['sha256'] for path in sorted(paths)}

def harness_map(root):
    return {path.name: read(path)[0]['sha256']
            for path in sorted((root / 'tools/x230/20261028').glob('*.py'))}

def check_terminal(raw, job_id, state="succeeded", exit_code=0):
    value = json.loads(raw)
    assert value['job_id'] == job_id and value['state'] == state and value['exit_code'] == exit_code
    assert all(value[k] is True for k in ('output_complete', 'output_durable', 'terminal_publication_confirmed'))
    assert all(value[k] is False for k in ('automatic_retry', 'cancelled', 'timed_out'))
    assert value['terminal_publication_protocol'] == 1
    for name in ('stdout', 'stderr'):
        assert value['log_synced'][name] is True and value['log_truncated'][name] is False
        assert value['log_errors'][name] is None
        assert value['log_bytes'][name]['seen'] == value['log_bytes'][name]['stored']

def quiescence():
    deadline, samples = time.monotonic() + 300, []
    while True:
        active = []
        for path in Path('/proc').glob('[0-9]*/comm'):
            try:
                name = path.read_text().strip()
                if name in ('cargo', 'rustc', 'rust-lld', 'ld.lld'):
                    active.append({'pid': int(path.parent.name), 'name': name})
            except (FileNotFoundError, ProcessLookupError, PermissionError):
                pass
        samples.append({'utc': utc(), 'compiler_processes': active})
        if not active:
            return samples
        assert time.monotonic() < deadline, 'compiler quiescence unavailable; no cache copy or qualification started'
        if len(samples) == 1:
            print(json.dumps({'waiting_for_compiler_quiescence': active}), flush=True)
        time.sleep(2)

def byte_identity(body):
    return {'bytes': len(body), 'sha256': hashlib.sha256(body).hexdigest()}

def need(value, reason):
    if not value:
        raise RuntimeError(reason)

def budget():
    need(time.monotonic_ns() - START <= MAX_DURATION_NS, 'bounded inventory duration exceeded')

def metadata_stamp(value):
    return {key: getattr(value, key) for key in FIELDS}

def directory_id(value):
    need(stat.S_ISDIR(value.st_mode), 'fixed path is not a directory')
    return (value.st_dev, value.st_ino, value.st_uid, value.st_mode)

def check_chain(chain):
    for item in chain:
        linked = (os.lstat('/') if item['parent'] is None else
                  os.stat(item['name'], dir_fd=item['parent'], follow_symlinks=False))
        need(directory_id(os.fstat(item['fd'])) == item['identity'] == directory_id(linked),
             'fixed directory chain changed')

def close_chain(chain):
    for item in reversed(chain):
        os.close(item['fd'])

def open_directory(path, *, fixed_space_parent=False):
    permitted = (path == '/home/qian' if fixed_space_parent is True
                 else path.startswith('/home/qian/'))
    need(permitted and os.path.normpath(path) == path,
         'directory outside exact task parent')
    chain = []
    try:
        for number, name in enumerate(('/', *path.split('/')[1:])):
            parent = chain[-1]['fd'] if chain else None
            fd = os.open(name, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW | os.O_CLOEXEC,
                         **({'dir_fd': parent} if parent is not None else {}))
            item = {'fd': fd, 'parent': parent, 'name': name}
            chain.append(item)
            item['identity'] = directory_id(os.fstat(fd))
            need(item['identity'][2] == (0 if number < 2 else OWNER), 'fixed directory owner differs')
            check_chain(chain)
        need(os.path.realpath(path) == path, 'fixed root realpath differs')
        return chain
    except BaseException:
        close_chain(chain)
        raise

def read_bound(spec):
    path, size, expected_sha = spec
    chain = open_directory(os.path.dirname(path))
    fd = None
    try:
        owner_fd = chain[-1]['fd']
        fd = os.open(os.path.basename(path), os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK | os.O_CLOEXEC,
                     dir_fd=owner_fd)
        before = os.fstat(fd)
        need(stat.S_ISREG(before.st_mode) and before.st_uid == OWNER and before.st_nlink == 1
             and before.st_size == size <= 4 * 1048576, 'fixed evidence file metadata differs')
        with os.fdopen(os.dup(fd), 'rb') as stream:
            raw = stream.read(size + 1)
        actual_sha = hashlib.sha256(raw).hexdigest()
        need(len(raw) == size and actual_sha == expected_sha
             and metadata_stamp(before) == metadata_stamp(os.fstat(fd))
             == metadata_stamp(os.stat(os.path.basename(path), dir_fd=owner_fd, follow_symlinks=False)),
             'fixed evidence bytes or descriptor changed')
        check_chain(chain)
        return {'path': path, 'bytes': size, 'sha256': actual_sha, 'identity': metadata_stamp(before)}, json.loads(raw)
    finally:
        if fd is not None:
            os.close(fd)
        close_chain(chain)

def inventory_tree(path):
    chain = open_directory(path)
    started = time.monotonic_ns()
    try:
        root_fd = chain[-1]['fd']
        root = os.fstat(root_fd)
        totals = {'entries': 0, 'directories_including_root': 0, 'directory_logical_bytes': 0,
                  'directory_allocated_bytes': 0, 'regular_files': 0,
                  'regular_logical_bytes': 0, 'unique_regular_logical_bytes': 0,
                  'unique_regular_allocated_bytes': 0, 'symlinks': 0, 'other_nonregular': 0,
                  'other_device_entries': 0, 'other_owner_entries': 0, 'multiply_linked_regular_files': 0}
        incidents, inodes = [], set()
        inode_links, retained_aliases = {}, []
        accumulator = hashlib.sha256()
        descendants = hashlib.sha256()

        def account(relative, current):
            budget()
            totals['entries'] += 1
            need(totals['entries'] <= MAX_TREE_ENTRIES, 'bounded cache entry count exceeded')
            record = {'relative': relative, 'identity': metadata_stamp(current), 'st_blocks': current.st_blocks}
            record_raw = (json.dumps(record, sort_keys=True, separators=(',', ':')) + '\n').encode()
            accumulator.update(record_raw)
            if relative != '.':
                descendants.update(record_raw)
            foreign_device = current.st_dev != root.st_dev
            foreign_owner = current.st_uid != OWNER
            totals['other_device_entries'] += int(foreign_device)
            totals['other_owner_entries'] += int(foreign_owner)
            mode = current.st_mode
            if stat.S_ISDIR(mode):
                totals['directories_including_root'] += 1
                totals['directory_logical_bytes'] += current.st_size
                totals['directory_allocated_bytes'] += current.st_blocks * 512
            elif stat.S_ISREG(mode):
                totals['regular_files'] += 1
                totals['regular_logical_bytes'] += current.st_size
                totals['multiply_linked_regular_files'] += int(current.st_nlink != 1)
                key = (current.st_dev, current.st_ino)
                prior = inode_links.setdefault(key, [0, current.st_nlink])
                need(prior[1] == current.st_nlink, 'cache inode link count changed during scan')
                prior[0] += 1
                if key in PROTECTED_ELF_INODES:
                    retained_aliases.append(relative)
                if key not in inodes:
                    inodes.add(key)
                    totals['unique_regular_logical_bytes'] += current.st_size
                    totals['unique_regular_allocated_bytes'] += current.st_blocks * 512
            elif stat.S_ISLNK(mode):
                totals['symlinks'] += 1
            else:
                totals['other_nonregular'] += 1
            if foreign_device or foreign_owner or not (stat.S_ISDIR(mode) or stat.S_ISREG(mode)):
                if len(incidents) < 32:
                    incidents.append(record)
            return not foreign_device and not foreign_owner

        def walk(fd, relative, depth):
            budget()
            need(depth <= 64, 'bounded cache directory depth exceeded')
            before = os.fstat(fd)
            account(relative, before)
            names = []
            with os.scandir(fd) as scan:
                for item in scan:
                    need(len(names) < MAX_TREE_ENTRIES, 'bounded directory entry count exceeded')
                    names.append(item.name)
            for name in sorted(names):
                budget()
                current = os.stat(name, dir_fd=fd, follow_symlinks=False)
                child_relative = name if relative == '.' else relative + '/' + name
                if stat.S_ISDIR(current.st_mode) and current.st_dev == root.st_dev and current.st_uid == OWNER:
                    child = os.open(name, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW | os.O_CLOEXEC,
                                    dir_fd=fd)
                    try:
                        need(metadata_stamp(current) == metadata_stamp(os.fstat(child)), 'cache directory replaced before scan')
                        walk(child, child_relative, depth + 1)
                        need(metadata_stamp(os.fstat(child)) == metadata_stamp(os.stat(name, dir_fd=fd, follow_symlinks=False)),
                             'cache directory path changed during scan')
                    finally:
                        os.close(child)
                else:
                    account(child_relative, current)
            need(metadata_stamp(before) == metadata_stamp(os.fstat(fd)), 'cache directory metadata changed during scan')

        walk(root_fd, '.', 0)
        check_chain(chain)
        need(metadata_stamp(root) == metadata_stamp(os.fstat(root_fd)), 'cache root metadata changed during scan')
        return {'path': path, 'root_identity': metadata_stamp(root), 'realpath_matches_literal': True,
                'counts': totals, 'metadata_sha256': accumulator.hexdigest(),
                'descendants_metadata_sha256': descendants.hexdigest(),
                'external_or_unaccounted_hardlink_inodes': sum(seen != links for seen, links in inode_links.values()),
                'all_regular_links_accounted_within_target': all(seen == links for seen, links in inode_links.values()),
                'retained_qualification_elf_aliases': retained_aliases,
                'anomaly_examples_maximum_32': incidents,
                'foreign_subtrees_and_symlinks_not_followed': True,
                'all_entries_traversed': totals['other_device_entries'] == totals['other_owner_entries'] == 0,
                'started_monotonic_ns': started, 'finished_monotonic_ns': time.monotonic_ns()}
    finally:
        close_chain(chain)

def proc_bytes(fd, name, maximum):
    child = os.open(name, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK | os.O_CLOEXEC, dir_fd=fd)
    try:
        with os.fdopen(os.dup(child), 'rb') as stream:
            raw = stream.read(maximum + 1)
        need(len(raw) <= maximum, 'bounded process metadata exceeded')
        return raw
    finally:
        os.close(child)

def proc_stat(raw, expected_pid):
    closing = raw.rfind(b')')
    need(closing > 0, 'malformed bounded process stat')
    pid = int(raw[:raw.find(b'(')].strip())
    fields = raw[closing + 1:].split()
    need(pid == expected_pid and len(fields) >= 20, 'process stat identity differs')
    state = fields[0].decode('ascii')
    birth = int(fields[19])
    need(len(state) == 1 and birth > 0, 'invalid process state or birth')
    return pid, birth, state

def matches_cache(value, cache, cwd=None):
    # Values remain private to this predicate and are never emitted or hashed.
    value = value.removesuffix(' (deleted)')
    start = 0
    while True:
        pos = value.find(cache, start)
        if pos < 0:
            break
        end = pos + len(cache)
        before_ok = pos == 0 or value[pos - 1] in '=,: \t'
        after_ok = end == len(value) or value[end] == '/'
        if before_ok and after_ok:
            return True
        start = pos + 1
    if cwd and value and not value.startswith('-') and not os.path.isabs(value):
        candidate = os.path.normpath(os.path.join(cwd.removesuffix(' (deleted)'), value))
        return candidate == cache or candidate.startswith(cache + '/')
    return False

def scan_references():
    started = time.monotonic_ns()
    summary = {'scope': ['cwd', 'argv', 'CARGO_TARGET_DIR'], 'started_monotonic_ns': started,
               'processes_enumerated': 0, 'live_processes_examined': 0, 'dead_processes_skipped': 0,
               'vanished_before_live_observation': 0, 'processes_indeterminate': 0,
               'same_owner_processes_indeterminate': 0, 'foreign_owner_processes_indeterminate': 0,
               'unknown_owner_processes_indeterminate': 0,
               'channel_error_counts': {}, 'matched_live_processes': [],
               'unknown_process_examples_maximum_16': [],
               'same_owner_unknown_processes_maximum_32': [], 'complete': False,
               'raw_argv_or_environment_or_unrelated_cwd_emitted': False}
    proc_fd = os.open('/proc', os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW | os.O_CLOEXEC)
    try:
        pids = []
        with os.scandir(proc_fd) as scan:
            for entry in scan:
                if entry.name.isascii() and entry.name.isdecimal():
                    need(len(pids) < MAX_PROCESSES, 'bounded process inventory exceeded')
                    pids.append(int(entry.name))
        summary['processes_enumerated'] = len(pids)
        for pid in sorted(pids):
            budget()
            fd = None
            uid = None
            first = None
            comm = None
            errors = []
            matches = {name: [] for name, _, _ in CACHES}
            try:
                fd = os.open(str(pid), os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW | os.O_CLOEXEC,
                             dir_fd=proc_fd)
                proc_identity = os.fstat(fd)
                uid = proc_identity.st_uid
                first_raw = proc_bytes(fd, 'stat', 16384)
                first = proc_stat(first_raw, pid)
                if uid == OWNER:
                    comm_raw = first_raw[first_raw.find(b'(') + 1:first_raw.rfind(b')')]
                    need(0 < len(comm_raw) <= 256, 'bounded same-owner process comm exceeded')
                    comm = comm_raw.decode('utf-8', errors='backslashreplace')
                del first_raw
                if first[2] in DEAD:
                    summary['dead_processes_skipped'] += 1
                    continue
                summary['live_processes_examined'] += 1
                cwd = None
                try:
                    cwd = os.readlink('cwd', dir_fd=fd)
                    for name, cache, _ in CACHES:
                        if matches_cache(cwd, cache):
                            matches[name].append('cwd')
                except OSError as error:
                    errors.append(('cwd', error.errno))
                try:
                    argv = proc_bytes(fd, 'cmdline', MAX_PROC_BYTES).split(b'\0')
                    for value in argv:
                        token = os.fsdecode(value)
                        for name, cache, _ in CACHES:
                            if matches_cache(token, cache, cwd) and 'argv' not in matches[name]:
                                matches[name].append('argv')
                    del argv
                except OSError as error:
                    errors.append(('argv', error.errno))
                try:
                    environment = proc_bytes(fd, 'environ', MAX_PROC_BYTES)
                    for value in environment.split(b'\0'):
                        if value.startswith(b'CARGO_TARGET_DIR='):
                            target = os.fsdecode(value[len(b'CARGO_TARGET_DIR='):])
                            for name, cache, _ in CACHES:
                                if matches_cache(target, cache, cwd):
                                    matches[name].append('CARGO_TARGET_DIR')
                    del environment
                except OSError as error:
                    errors.append(('CARGO_TARGET_DIR', error.errno))
                second = proc_stat(proc_bytes(fd, 'stat', 16384), pid)
                after = os.fstat(fd)
                linked = os.stat(str(pid), dir_fd=proc_fd, follow_symlinks=False)
                need(first[:2] == second[:2]
                     and (proc_identity.st_dev, proc_identity.st_ino, uid)
                     == (after.st_dev, after.st_ino, after.st_uid)
                     == (linked.st_dev, linked.st_ino, linked.st_uid), 'process identity changed during inspection')
                states = [first[2], second[2]]
            except FileNotFoundError:
                if first is None:
                    summary['vanished_before_live_observation'] += 1
                    continue
                errors.append(('identity_after_live_observation', 2))
                states = [first[2]]
            except OSError as error:
                errors.append(('process_metadata', error.errno))
                states = [first[2]] if first else []
            except (RuntimeError, ValueError, UnicodeError):
                errors.append(('process_identity_or_bounds', None))
                states = [first[2]] if first else []
            finally:
                if fd is not None:
                    os.close(fd)
            selected = {name: channels for name, channels in matches.items() if channels}
            if selected:
                summary['matched_live_processes'].append({'pid': pid, 'uid': uid,
                    'birth_ticks': first[1] if first else None, 'observed_states': states,
                    'cache_reference_channels': selected, 'inspection_complete': not errors})
            if errors:
                summary['processes_indeterminate'] += 1
                category = ('unknown_owner_processes_indeterminate' if uid is None else
                            'same_owner_processes_indeterminate' if uid == OWNER else
                            'foreign_owner_processes_indeterminate')
                summary[category] += 1
                if uid == OWNER and len(summary['same_owner_unknown_processes_maximum_32']) < 32:
                    summary['same_owner_unknown_processes_maximum_32'].append({
                        'pid': pid, 'uid': uid, 'birth_ticks': first[1] if first else None,
                        'comm': comm, 'comm_source': 'first_pid_birth_bound_stat' if comm is not None else None,
                        'observed_states': states, 'inspection_complete': False,
                        'unreadable_or_raced_channels': [
                            {'channel': channel, 'errno': code,
                             'classification': ('permission_denied' if code in (1, 13)
                                                else 'vanished_or_missing' if code == 2
                                                else 'identity_or_bounds' if code is None else 'os_error')}
                            for channel, code in errors]})
                for channel, code in errors:
                    key = channel + ':' + str(code)
                    summary['channel_error_counts'][key] = summary['channel_error_counts'].get(key, 0) + 1
                if len(summary['unknown_process_examples_maximum_16']) < 16:
                    summary['unknown_process_examples_maximum_16'].append({'pid': pid, 'uid': uid,
                        'birth_ticks': first[1] if first else None, 'observed_states': states,
                        'unreadable_or_raced_channels': [channel for channel, _ in errors]})
        summary['same_owner_unknown_examples_truncated'] = (
            summary['same_owner_processes_indeterminate']
            > len(summary['same_owner_unknown_processes_maximum_32']))
        summary['complete'] = summary['processes_indeterminate'] == 0
        summary['all_same_owner_live_process_channels_inspected'] = (
            summary['same_owner_processes_indeterminate'] == 0
            and summary['unknown_owner_processes_indeterminate'] == 0)
        summary['finished_monotonic_ns'] = time.monotonic_ns()
        summary['single_scan_only_no_continuous_liveness_claim'] = True
        return summary
    finally:
        os.close(proc_fd)

def inspect_fixed_directory(path, allow_absent=False):
    try:
        chain = open_directory(path)
    except FileNotFoundError:
        need(allow_absent, 'required fixed directory missing: ' + path)
        return {'path': path, 'exists': False, 'identity': None}
    try:
        value = metadata_stamp(os.fstat(chain[-1]['fd']))
        check_chain(chain)
        return {'path': path, 'exists': True, 'identity': value}
    finally:
        close_chain(chain)

def preserved_elf_metadata(manifest, qualification, ci, summary):
    expected = {value['path']: value['sha256'] for value in qualification['binaries'].values()}
    tests = {row['path']: row['sha256'] for row in summary['binaries']}
    need(len(expected) == 3 and len(tests) == 5 and len(set(expected) | set(tests)) == 8,
         'original retained 3 release plus 5 test ELF set differs')
    expected.update(tests)
    listed = ci['structured_inventory']['binary_paths']
    need(len(listed) == 5 and {r['qualified']['path']: r['qualified']['sha256'] for r in listed.values()} == tests,
         'actual nextest binaries do not bind all five retained qualification copies')
    need(all(r['path'].startswith(CACHE + '/debug/') and r['qualified']['path'].startswith(ROOT28 + '/qualification-01/test-binaries/') for r in listed.values()),
         'original CI or retained ELF path differs')
    omissions = manifest['omissions']
    need(isinstance(omissions, dict) and len(omissions) == 8, 'original eight ELF omissions differ')
    records = {row['identity']['source_path']: row for row in omissions.values()}
    need(set(records) == set(expected), 'exported retained ELF set differs')
    results = []
    for path in sorted(expected):
        budget()
        saved = records[path]
        value = saved['identity']
        need(path.startswith(ROOT28 + '/qualification-01/') and value['is_elf'] is True
             and value['sha256'] == expected[path]
             and saved['reason'] == 'ELF body omitted; complete observed file identity retained',
             'original full-export ELF identity differs')
        chain = open_directory(os.path.dirname(path))
        fd = None
        try:
            parent = chain[-1]['fd']
            fd = os.open(os.path.basename(path), os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK | os.O_CLOEXEC, dir_fd=parent)
            current = os.fstat(fd)
            need(stat.S_ISREG(current.st_mode) and current.st_uid == OWNER and current.st_nlink == 1
                 and current.st_size == value['bytes'] and {k: getattr(current, k) for k in EXPORT_FIELDS} == value['original_identity'],
                 'retained ELF metadata differs from original SHA-bound export: ' + path)
            need(metadata_stamp(current) == metadata_stamp(os.fstat(fd)) == metadata_stamp(os.stat(os.path.basename(path), dir_fd=parent, follow_symlinks=False)),
                 'retained ELF descriptor or path changed')
            check_chain(chain)
            PROTECTED_ELF_INODES.add((current.st_dev, current.st_ino))
            results.append({'path': path, 'bytes': value['bytes'], 'exported_sha256': value['sha256'],
                            'current_identity': metadata_stamp(current), 'full_export_identity_unchanged': True,
                            'sha256_recomputed_by_this_metadata_probe': False, 'payload_read_bytes': 0})
        finally:
            if fd is not None:
                os.close(fd)
            close_chain(chain)
    return results

def original_paged_operation(original, state='succeeded', exit_code=0):
    terminal_raw = original['native_terminal_text'].encode('utf-8')
    assert byte_identity(terminal_raw) == original['native_terminal_identity']
    check_terminal(terminal_raw, original['job_id'], state, exit_code)
    terminal = json.loads(terminal_raw)
    streams = {'stdout': bytearray(), 'stderr': bytearray()}
    pages = original['native_read_pages']
    assert isinstance(pages, list) and 1 <= len(pages) <= 16
    assert [page['identity'] for page in pages] == original['native_read_page_identities']
    for page in pages:
        raw = page['text'].encode('utf-8')
        assert byte_identity(raw) == page['identity']
        dto = json.loads(raw)
        assert dto['job_id'] == original['job_id'] and dto['audit_recorded'] is True
        for name in ('stdout', 'stderr'):
            row, prior = dto[name], streams[name]
            body = bytes.fromhex(row['bytes_hex'])
            assert row['offset'] == len(prior) and row['next_offset'] == len(prior) + len(body)
            assert row['size'] == terminal['log_bytes'][name]['stored']
            assert row['eof'] is (row['next_offset'] == row['size'])
            assert row['text'].encode('utf-8') == body
            prior.extend(body)
    for name in ('stdout', 'stderr'):
        assert len(streams[name]) == terminal['log_bytes'][name]['seen'] == terminal['log_bytes'][name]['stored']
    assert streams['stderr'] == b'' and byte_identity(streams['stdout']) == original['stdout_identity']
    return json.loads(streams['stdout'])


def actual_admission(payload):
    """Bind actual evidence; a readonly snapshot never supplies a writer lease."""
    supplied = payload['cache_admission']
    assert set(supplied) == {'original_failed_probe01', 'read_only_probe', 'local_QC_full_archive_verification',
                             'root_exclusive_writer_admission'}
    assert all(isinstance(value, dict) for value in supplied.values()), 'actual cache/QC/writer admission remains unbound'
    original = supplied['read_only_probe']
    assert isinstance(PROBE_SOURCE_SHA, str) and original['source_sha256'] == PROBE_SOURCE_SHA
    assert re.fullmatch(r'[0-9a-f]+-[0-9a-f]+-[0-9a-f]+', original['job_id'])
    observed = original_paged_operation(original)
    failed_original = supplied['original_failed_probe01']
    assert {k: failed_original[k] for k in FAILED_PROBE_SPEC} == FAILED_PROBE_SPEC
    failed_report = original_paged_operation(failed_original, 'failed', 1)
    assert failed_report['schema'] == 'hepta-r28-owned-target-readonly-review/v1'
    assert failed_report['passed'] is False and failed_report['read_only'] is True
    assert failed_report['error'] == {'type': 'RuntimeError', 'message': 'directory outside exact task parent'}
    assert failed_report['files_created_or_deleted'] == 0 and failed_report['rename_executed'] is False
    assert failed_report['cleanup_executed'] is False and failed_report['transfer_authorized_by_this_report'] is False
    assert 'space' not in failed_report
    assert observed['schema'] == 'hepta-r28-owned-target-readonly-review/v1' and observed['passed'] is True
    assert observed['read_only'] is True and observed['files_created_or_deleted'] == 0
    assert observed['rename_executed'] is False and observed['cleanup_executed'] is False
    assert observed['transfer_authorized_by_this_report'] is False
    assert observed['transfer_eligibility_established'] is False
    assert observed['cache_metadata_stable_across_two_passes'] is True
    assert observed['original_evidence_files_unchanged'] is True
    assert observed['protected_elf_original_export_metadata_unchanged'] is True
    assert observed['retained_elf_copies_before'] == observed['retained_elf_copies_after']
    assert len(observed['retained_elf_copies_before']) == 8
    assert observed['future_root']['exists'] is False and observed['future_target_metadata']['exists'] is False
    assert observed['future_root']['path'] == str(ROOT) and observed['future_target_metadata']['path'] == str(TARGET)
    assert observed['current_reference_observed'] is False
    assert len(observed['cache_passes']) == 2 and len(observed['process_reference_scans']) == 2
    for row in observed['cache_passes']:
        check_cache_inventory(row, CACHE)
    for row in observed['process_reference_scans']:
        assert row['matched_live_processes'] == []
    assert observed['cache_passes'][0]['metadata_sha256'] == observed['cache_passes'][1]['metadata_sha256']
    assert set(observed['bound_inputs']) == set(BOUND)
    for name, (path, size, sha) in BOUND.items():
        assert {k: observed['bound_inputs'][name][k] for k in ('path', 'bytes', 'sha256')} == {
            'path': path, 'bytes': size, 'sha256': sha}

    local = supplied['local_QC_full_archive_verification']
    raw = local['original_verification_text'].encode('utf-8')
    assert byte_identity(raw) == local['original_verification_identity']
    assert local['consumer_sha256'] == QC_CONSUMER_SHA
    qa = json.loads(raw)
    assert qa['schema'] == 'hepta-r28-qualification-ci-independent-verification/v1'
    assert qa['passed'] is True and qa['candidate_adopted'] is False
    assert qa['archive'] == QC_ARCHIVE
    assert qa['manifest'] == {'bytes': BOUND['qc_manifest'][1], 'sha256': BOUND['qc_manifest'][2]}
    assert qa['archive_validation']['verified'] is True and qa['archive_validation']['regular_members'] == 3830
    assert qa['original_capture']['job_id'] == QC_EXPORT_JOB
    assert qa['original_capture']['native_outcome']['state'] == 'succeeded'
    assert qa['original_capture']['native_outcome']['exit_code'] == 0
    assert qa['original_capture']['native_outcome']['native_logs_lossless_complete'] is True
    assert qa['original_export_report'] == {'bytes': BOUND['qc_export'][1], 'sha256': BOUND['qc_export'][2]}
    assert qa['original_negative_outcomes_preserved'] is True
    assert qa['archive_code_executed'] is False and qa['remote_operations'] == 0
    for name, original_operation in KNOWN_OPERATIONS.items():
        outcome = qa['original_outcomes'][name]
        assert outcome['native_outcome']['state'] == original_operation['state']
        assert outcome['native_outcome']['exit_code'] == original_operation['exit_code']
    writer = supplied['root_exclusive_writer_admission']
    assert writer['schema'] == 'hepta-r29-owned-cache-writer-admission/v1'
    assert writer['source_cache'] == CACHE and writer['destination_cache'] == str(TARGET)
    assert writer['selected_candidate_source_map_sha256'] == CANDIDATE_MAP_SHA
    assert writer['root_reviewed_readonly_probe_stdout'] == original['stdout_identity']
    assert writer['root_reviewed_downloaded_QC_verification'] == local['original_verification_identity']
    assert writer['exclusive_compilation_window_held'] is True
    assert writer['no_later_R28_cache_use_scheduled'] is True
    assert writer['original_native_raw_custody_retained'] is True
    assert writer['same_owner_unknowns_reviewed_without_claiming_all_channels_readable'] is True
    assert isinstance(writer['window_reference'], str) and 0 < len(writer['window_reference']) <= 256
    assert writer['fd_and_mmap_reference_channels_not_covered'] is True
    # This is the already-authorized root execution window, not proof about all
    # machine users. Concrete observed references and known unclosed writers
    # still block below. All original unknown/error categories remain recorded.
    return observed, qa, {'original_probe_job_id': original['job_id'],
        'original_probe_terminal': original['native_terminal_identity'],
        'original_probe_read_pages': [p['identity'] for p in original['native_read_pages']],
        'original_probe_stdout': original['stdout_identity'],
        'original_probe_reference_scans': observed['process_reference_scans'],
        'original_probe_reference_scan_limits': observed['reference_scan_limits'],
        'downloaded_QC_full_verification': local['original_verification_identity'],
        'downloaded_QC_archive': QC_ARCHIVE, 'root_writer_admission': writer,
        'original_failed_probe01': FAILED_PROBE_SPEC, 'original_failed_probe01_error': failed_report['error'],
        'original_failed_probe01_preserved_as_failed': True,
        'readonly_probe_does_not_authorize_transfer': True,
        'all_user_process_channels_readable_claimed': False}


def check_cache_inventory(row, path):
    assert row['path'] == path and row['realpath_matches_literal'] is True
    assert row['all_entries_traversed'] is True and row['all_regular_links_accounted_within_target'] is True
    assert row['external_or_unaccounted_hardlink_inodes'] == 0
    assert row['retained_qualification_elf_aliases'] == []
    counts = row['counts']
    assert counts['regular_files'] > 0
    assert all(counts[key] == 0 for key in ('symlinks', 'other_nonregular', 'other_device_entries', 'other_owner_entries'))
    assert row['anomaly_examples_maximum_32'] == []


def same_inventory(first, second, moved=False):
    keys = ('counts', 'all_entries_traversed', 'all_regular_links_accounted_within_target',
            'external_or_unaccounted_hardlink_inodes', 'retained_qualification_elf_aliases')
    assert all(first[key] == second[key] for key in keys), 'cache inventory changed'
    if not moved:
        assert first['path'] == second['path'] and first['root_identity'] == second['root_identity']
        assert first['metadata_sha256'] == second['metadata_sha256']
    else:
        assert first['path'] == CACHE and second['path'] == str(TARGET)
        assert first['descendants_metadata_sha256'] == second['descendants_metadata_sha256']
        # The directory inode itself acquires a new ctime on rename; every
        # descendant and every other root metadata field remains exact.
        fields = tuple(key for key in FIELDS if key != 'st_ctime_ns')
        assert all(first['root_identity'][key] == second['root_identity'][key] for key in fields)
        assert second['root_identity']['st_ctime_ns'] >= first['root_identity']['st_ctime_ns']


def owned_receipt(parent_fd, name):
    fd = os.open(name, os.O_RDWR | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW | os.O_CLOEXEC, 0o600, dir_fd=parent_fd)
    os.fsync(parent_fd)
    return fd, (os.fstat(fd).st_dev, os.fstat(fd).st_ino)


def update_receipt(parent_fd, name, opened, value):
    fd, identity = opened
    current, linked = os.fstat(fd), os.stat(name, dir_fd=parent_fd, follow_symlinks=False)
    assert stat.S_ISREG(current.st_mode) and current.st_uid == OWNER and current.st_nlink == 1
    assert (current.st_dev, current.st_ino) == identity == (linked.st_dev, linked.st_ino)
    raw, position = encoded(value), 0
    while position < len(raw):
        size = os.pwrite(fd, raw[position:], position)
        assert size > 0
        position += size
    os.ftruncate(fd, len(raw))
    os.fsync(fd)
    assert os.pread(fd, len(raw) + 1, 0) == raw
    assert stamp(os.fstat(fd)) == stamp(os.stat(name, dir_fd=parent_fd, follow_symlinks=False))


def absent(parent_fd, name):
    try:
        os.stat(name, dir_fd=parent_fd, follow_symlinks=False)
    except FileNotFoundError:
        return True
    return False


def reserve(parent_fd):
    disk = os.fstatvfs(parent_fd)
    available = disk.f_bavail * disk.f_frsize
    assert available >= RESERVE_BYTES, (available, RESERVE_BYTES)
    return {'available_bytes': available, 'available_blocks': disk.f_bavail,
            'filesystem_fragment_size': disk.f_frsize, 'available_inodes': disk.f_favail,
            'unchanged_required_headroom_bytes': RESERVE_BYTES, 'new_full_cache_copy_bytes': 0,
            'move_frees_bytes': False, 'future_build_growth_guaranteed_to_fit': False}


def verify_selected_source(payload, parent_map):
    raw = payload['transform_text'].encode('utf-8')
    assert hashlib.sha256(raw).hexdigest() == TRANSFORM_SHA
    transform = json.loads(raw)
    assert transform['schema'] == 'hepta-r29-shared-router-fixed-source-transform/v1'
    assert transform['production_selection'] == 'shared unfiltered ToolRouter'
    assert transform['optional_pidfd_selected'] is False
    assert [change['relative_path'] for change in transform['files']] == list(CHANGED_PATHS)
    expected, candidates = dict(parent_map), {}
    for change in transform['files']:
        relative = change['relative_path']
        assert change['before']['sha256'] == parent_map[relative]
        identity, original = read(OLD_SOURCE / relative, change['before']['sha256'], retain=True)
        assert identity['bytes'] == change['before']['bytes']
        candidate = original.decode('utf-8')
        for operation in change['operations']:
            assert operation['required_matches'] == candidate.count(operation['old']) == 1
            candidate = candidate.replace(operation['old'], operation['new'], 1)
        candidate_raw = candidate.encode('utf-8')
        assert byte_identity(candidate_raw) == change['after']
        candidates[relative] = candidate_raw
        expected[relative] = change['after']['sha256']
    assert payload['candidate_source_map'] == expected
    assert hashlib.sha256(encoded(expected)).hexdigest() == CANDIDATE_MAP_SHA
    assert payload['candidate_manifest'] == CANDIDATE_MANIFEST
    assert sorted(p for p in expected if expected[p] != parent_map[p]) == sorted(CHANGED_PATHS)
    assert payload['test_expectation'] == {'selected': 1689, 'passed': 1655, 'failed': 0, 'ignored': 34,
        'retries': 0, 'new_exact_tests': list(NEW_EXACT_TESTS)}
    return transform, expected, candidates


def main():
    global START
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--input-sha256', required=True)
    parser.add_argument('--launcher-sha256', required=True)
    args = parser.parse_args()
    assert sys.platform == 'linux' and os.geteuid() == OWNER
    launcher_identity, _ = read(Path(__file__).resolve(), args.launcher_sha256)
    input_identity, input_raw = read(INPUT, args.input_sha256, retain=True)
    payload = json.loads(input_raw)
    assert payload['schema'] == 'hepta-r29-shared-router-qualification-input/v1'
    assert payload['production_selection'] == 'shared unfiltered ToolRouter'
    assert payload['optional_pidfd_selected'] is False and payload['parent_candidate_adopted'] is False
    assert payload['accepted_production_source_remains_R24'] is True
    assert payload['unchanged_disk_reserve_bytes'] == RESERVE_BYTES
    assert payload['cache_strategy'] == 'one same-filesystem renameat2(RENAME_NOREPLACE); no cache copy or cleanup'
    observed, qa, admission = actual_admission(payload)
    # Resolve the required no-replace primitive before creating any fresh path.
    libc = ctypes.CDLL(None, use_errno=True)
    renameat2 = libc.renameat2
    renameat2.argtypes = (ctypes.c_int, ctypes.c_char_p, ctypes.c_int, ctypes.c_char_p, ctypes.c_uint)
    renameat2.restype = ctypes.c_int
    saved_inputs, documents = {}, {}
    for name, spec in BOUND.items():
        identity, value = read_bound(spec)
        assert identity == observed['bound_inputs'][name], 'original probe evidence identity changed: ' + name
        saved_inputs[identity['path']] = {k: identity[k] for k in ('path', 'bytes', 'sha256')}
        documents[name] = value

    def bind(path, digest):
        identity, raw = read(path, digest, retain=True)
        saved_inputs[str(path)] = identity
        return json.loads(raw)

    parent = documents['qualification']
    parent_map = documents['qualified_source_map']
    assert parent['qualified'] is True and parent['finished_utc']
    assert parent['source_tested'] == parent['source_after'] == parent_map == source_map(OLD_SOURCE)
    assert len(parent_map) == 221 and [s['name'] for s in parent['stages']] == STAGES
    assert all(s['returncode'] == 0 for s in parent['stages']) and parent['automatic_test_retries'] == 0
    prep, summary, ci, exported, manifest = (documents[name] for name in
        ('preparation', 'isolated_summary', 'rust_ci', 'qc_export', 'qc_manifest'))
    assert prep['passed'] is True and prep['candidate_qualified'] is True and prep['candidate_adopted'] is False
    assert prep['target'] == CACHE and prep['source'] == str(OLD_SOURCE)
    assert prep['cache_source'] == ROOT26 + '/target-build' and prep['shared_hardlinks_created'] is False
    assert [summary[k] for k in ('passed','failed','ignored','selected','retries')] == [1653,0,34,1687,0]
    assert summary['success'] is True and summary['filter'] == '' and not summary['enumeration_errors']
    assert ci['passed'] is True and ci['owned_children_closed'] is True and ci['source_inputs_unchanged'] is True
    assert ci['explicit_environment']['CARGO_TARGET_DIR'] == CACHE and len(ci['stages']) == 6
    assert all(s['returncode'] == 0 and s['waited_and_reaped'] is True and s['owned_process_absent'] is True
               and s['owned_process_group_absent'] is True for s in ci['stages'])
    for name, declared in KNOWN_OPERATIONS.items():
        pin = declared['terminal']
        identity, raw = read(pin['path'], pin['sha256'], retain=True)
        assert {k: identity[k] for k in ('path', 'bytes', 'sha256')} == pin
        check_terminal(raw, declared['job_id'], declared['state'], declared['exit_code'])
        saved_inputs[identity['path']] = identity
        report_pin = declared['report']
        value = bind(report_pin['path'], report_pin['sha256'])
        assert saved_inputs[report_pin['path']]['bytes'] == report_pin['bytes']
        if name == 'python_ci02':
            assert value['passed'] is True and value['finished_unix']
    assert exported['passed'] is True and exported['original_inputs_unchanged'] is True
    assert exported['archive']['verified'] is True and exported['omission_count'] == 8
    assert manifest['compiler_cache_body_outside_scope'] == CACHE
    assert exported['manifest']['sha256'] == BOUND['qc_manifest'][2]
    archive_pin = exported['archive']['identity']
    archive_identity, _ = read(archive_pin['source_path'], QC_ARCHIVE['sha256'])
    assert {k: archive_identity[k] for k in ('bytes', 'sha256')} == QC_ARCHIVE
    saved_inputs[archive_identity['path']] = archive_identity
    rejection = bind(PARENT / 'campaign-01/report.json', REJECTION_REPORT_SHA)
    rejection_summary = bind(PARENT / 'campaign-01/summary.json', REJECTION_SUMMARY_SHA)
    assert rejection['finished_utc'] and rejection['passed'] is True and rejection['observation_gate_passed'] is False
    assert rejection['measurement_attribution_valid'] is True and rejection['compiler_monitor']['passed'] is True
    assert rejection['inputs_unchanged'] is True and rejection['source_inputs_unchanged'] is True
    assert rejection['rejection_reasons'] == rejection_summary['rejection_reasons'] == ['C1 regression gate']
    assert rejection_summary['observation_gate_passed'] is False and rejection_summary['performance_gates_passed'] is False
    assert {name: {k: v[k] for k in ('path', 'sha256')} for name, v in rejection['binaries']['B'].items()} == parent['binaries']
    native_identity, native_raw = read(PARENT / 'observation-native-terminal-01.json', REJECTION_NATIVE_SHA, retain=True)
    check_terminal(native_raw, '1a1acbbcbec-fc05-56a0')
    saved_inputs[native_identity['path']] = native_identity
    publication = bind(ACCEPTED / 'final-publication-readback.json', PUBLICATION_SHA)
    assert publication['commit'] == 'baab4def80be7af015b2e7a594cb302f66c4130e'
    assert publication['verified'] is True and publication['candidate_adopted'] is True
    transform, expected, candidates = verify_selected_source(payload, parent_map)
    harness = parent['harness_after']
    assert len(harness) == 19 and parent['harness_before'] == harness_map(OLD_SOURCE) == harness
    initial_quiet = quiescence()
    START = time.monotonic_ns()
    retained = preserved_elf_metadata(manifest, parent, ci, summary)
    assert retained == observed['retained_elf_copies_after']
    before = inventory_tree(CACHE)
    check_cache_inventory(before, CACHE)
    same_inventory(observed['cache_passes'][-1], before)
    current_references = scan_references()
    assert not current_references['matched_live_processes'], 'observed live R28 cache reference'
    # Unknown channels are kept with their exact categories. They are not a
    # claim of readable fd/mmap or machine-wide liveness, nor an auto-cleanup.
    home = open_directory('/home/qian', fixed_space_parent=True)
    parent_chain = open_directory(str(PARENT))
    root_chain = None
    root_fd = cache_fd = None
    prep_opened = transfer_opened = None
    receipt = {'schema': 'hepta-r29-qualified-parent-preparation/v1', 'started_utc': utc(),
        'passed': False, 'candidate_qualified': False, 'candidate_adopted': False,
        'parent_source_qualified': True, 'parent_candidate_adopted': False,
        'parent_observation_rejection_preserved': True, 'automatic_test_retries': 0,
        'production_services_modified': False, 'shared_hardlinks_created': False,
        'input': input_identity, 'launcher': launcher_identity,
        'selected_proposal': 'shared unfiltered ToolRouter', 'optional_pidfd_selected': False,
        'cache_source': CACHE, 'cache_source_source_qualified': True, 'cache_reused': False,
        'cache_copy_executed': False, 'cache_cleanup_executed': False,
        'unchanged_disk_reserve_bytes': RESERVE_BYTES, 'new_full_cache_copy_bytes': 0,
        'admission': admission, 'compiler_quiescence': initial_quiet,
        'cache_reference_scan_before_source': current_references,
        'retained_parent_ELFs_before': retained}
    transfer = {'schema': 'hepta-r29-owned-cache-transfer/v1', 'passed': False,
        'source_cache': CACHE, 'destination_cache': str(TARGET), 'copy_executed': False,
        'cleanup_executed': False, 'rename_attempted': False, 'rename_returned_success': False,
        'automatic_retry': False, 'automatic_rollback': False,
        'original_cache_probe': admission['original_probe_stdout'], 'metadata_before': before,
        'root_writer_admission': admission['root_writer_admission'],
        'retained_parent_ELFs_before': retained, 'started_utc': utc()}
    result_code = 1
    try:
        assert absent(home[-1]['fd'], ROOT.name), 'fresh R29 root already exists; reconcile original operation'
        assert before['root_identity']['st_dev'] == os.fstat(home[-1]['fd']).st_dev
        os.mkdir(ROOT.name, 0o700, dir_fd=home[-1]['fd'])
        os.fsync(home[-1]['fd'])
        root_chain = open_directory(str(ROOT))
        root_fd = root_chain[-1]['fd']
        assert stat.S_IMODE(os.fstat(root_fd).st_mode) == 0o700
        prep_opened = owned_receipt(root_fd, 'preparation-01.json')
        transfer_opened = owned_receipt(root_fd, 'target-transfer-01.json')
        update_receipt(root_fd, 'preparation-01.json', prep_opened, receipt)
        update_receipt(root_fd, 'target-transfer-01.json', transfer_opened, transfer)
        input_opened = owned_receipt(root_fd, 'qualification-input-01.json')
        try:
            update_receipt(root_fd, 'qualification-input-01.json', input_opened, payload)
            assert read(ROOT / 'qualification-input-01.json')[0]['sha256'] == args.input_sha256
        finally:
            os.close(input_opened[0])
        preparation_started = time.monotonic()
        shutil.copytree(OLD_SOURCE, SOURCE)
        for relative, candidate_raw in candidates.items():
            (SOURCE / relative).write_bytes(candidate_raw)
        assert source_map(SOURCE) == expected and source_map(OLD_SOURCE) == parent_map
        assert harness_map(SOURCE) == harness_map(OLD_SOURCE) == harness
        check_chain(home)
        check_chain(parent_chain)
        check_chain(root_chain)
        receipt['disk_after_fresh_source_before_move'] = reserve(root_fd)
        receipt['compiler_quiescence_immediately_before_move'] = quiescence()
        START = time.monotonic_ns()
        immediate = inventory_tree(CACHE)
        same_inventory(before, immediate)
        immediate_references = scan_references()
        transfer['immediate_reference_scan'] = immediate_references
        assert not immediate_references['matched_live_processes'], 'live cache reference appeared before move'
        assert preserved_elf_metadata(manifest, parent, ci, summary) == retained
        transfer['immediate_metadata_before'] = immediate
        transfer['disk_before_move'] = reserve(root_fd)
        cache_fd = os.open('target-build', os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW | os.O_CLOEXEC,
                           dir_fd=parent_chain[-1]['fd'])
        assert metadata_stamp(os.fstat(cache_fd)) == immediate['root_identity']
        assert metadata_stamp(os.stat('target-build', dir_fd=parent_chain[-1]['fd'], follow_symlinks=False)) == immediate['root_identity']
        assert absent(root_fd, 'target-build') and absent(root_fd, 'qualification-01')
        check_chain(parent_chain)
        check_chain(root_chain)
        transfer['rename_attempted'] = True
        transfer['rename_started_utc'] = utc()
        update_receipt(root_fd, 'target-transfer-01.json', transfer_opened, transfer)
        move_started = time.monotonic()
        # Exactly one syscall. EEXIST/EXDEV/unsupported errors fail with no
        # fallback to replace/copy. Never retry or reverse an unknown outcome.
        rc = renameat2(parent_chain[-1]['fd'], b'target-build', root_fd, b'target-build', 1)
        if rc != 0:
            error_number = ctypes.get_errno()
            transfer['rename_errno'] = error_number
            raise OSError(error_number, os.strerror(error_number))
        transfer['rename_returned_success'] = True
        transfer['rename_seconds'] = time.monotonic() - move_started
        os.fsync(parent_chain[-1]['fd'])
        os.fsync(root_fd)
        check_chain(home)
        check_chain(parent_chain)
        check_chain(root_chain)
        assert absent(parent_chain[-1]['fd'], 'target-build')
        linked = os.stat('target-build', dir_fd=root_fd, follow_symlinks=False)
        assert metadata_stamp(linked) == metadata_stamp(os.fstat(cache_fd))
        assert (linked.st_dev, linked.st_ino) == (immediate['root_identity']['st_dev'], immediate['root_identity']['st_ino'])
        START = time.monotonic_ns()
        after = inventory_tree(str(TARGET))
        check_cache_inventory(after, str(TARGET))
        same_inventory(immediate, after, moved=True)
        assert preserved_elf_metadata(manifest, parent, ci, summary) == retained
        check_chain(home)
        check_chain(parent_chain)
        check_chain(root_chain)
        transfer.update(passed=True, metadata_after=after,
            old_path_absent=True, destination_is_original_inode=True,
            descendants_metadata_unchanged=True, retained_parent_ELFs_after=retained,
            root_ctime_before=immediate['root_identity']['st_ctime_ns'], root_ctime_after=after['root_identity']['st_ctime_ns'])
        transfer['finished_utc'] = utc()
        update_receipt(root_fd, 'target-transfer-01.json', transfer_opened, transfer)
        receipt.update(source=str(SOURCE), target=str(TARGET), qualification_output=str(OUTPUT),
            source_before=parent_map, candidate_compilation_inputs=expected, harness_before=harness,
            cache_reused=True, cache_file_count=before['counts']['regular_files'],
            cache_bytes=before['counts']['regular_logical_bytes'], cache_moved_by_single_no_replace_rename=True,
            cache_transfer_receipt=read(ROOT / 'target-transfer-01.json')[0],
            cache_transfer=transfer,
            preparation_seconds=time.monotonic()-preparation_started,
            source_changes=[{'path': change['relative_path'], 'before': change['before'], 'after': change['after']}
                            for change in transform['files']])
        # Do not borrow space from the preserved R24/R26/R28 evidence. A move
        # avoids a second full cache allocation, but does not create free space.
        receipt['disk_immediately_before_compiler'] = reserve(root_fd)
        update_receipt(root_fd, 'preparation-01.json', prep_opened, receipt)
        print(json.dumps({'phase': 'prepared', 'source_changes': list(CHANGED_PATHS), 'automatic_test_retries': 0}), flush=True)
        argv = ['/usr/bin/python3', '-B', str(SOURCE / 'tools/x230/20261028/qualify.py'),
            '--source', str(SOURCE), '--output', str(OUTPUT), '--target', str(TARGET),
            '--cargo-home', '/home/qian/hepta-runtime-optimization-20261023/cargo-home-a32-a33-r02',
            '--jobs', '2', '--stage-timeout', '3600']
        receipt['qualification_argv'] = argv
        result = subprocess.run(argv, cwd=SOURCE, timeout=10800)
        receipt['qualification_returncode'] = result.returncode
        for path, identity in saved_inputs.items():
            assert read(path)[0] == identity, 'bound parent evidence changed: ' + path
        assert source_map(OLD_SOURCE) == parent_map and harness_map(OLD_SOURCE) == harness_map(SOURCE) == harness
        read(INPUT, args.input_sha256)
        read(Path(__file__).resolve(), args.launcher_sha256)
        START = time.monotonic_ns()
        assert preserved_elf_metadata(manifest, parent, ci, summary) == retained
        receipt['retained_parent_ELFs_after_qualification'] = retained
        receipt['parent_inputs_unchanged'] = True
        qualified_identity, qualified_raw = read(OUTPUT / 'report.json', retain=True)
        qualified = json.loads(qualified_raw)
        receipt['qualification_report'] = qualified_identity
        receipt['candidate_qualified'] = qualified['qualified'] is True
        if result.returncode != 0:
            assert qualified['qualified'] is False
            result_code = result.returncode
        else:
            assert qualified['qualified'] is True and qualified['finished_utc']
            assert qualified['source_tested'] == qualified['source_after'] == source_map(SOURCE)
            assert all(s['returncode'] == 0 for s in qualified['stages'])
            assert [s['name'] for s in qualified['stages']] == STAGES
            assert qualified['automatic_test_retries'] == 0
            assert all(qualified['source_after'][p] == expected[p] for p in expected if p not in CHANGED_PATHS)
            test_summary = json.loads(read(OUTPUT / 'isolated-tests/summary.json', retain=True)[1])
            audit = json.loads(read(OUTPUT / 'isolated-tests.audit.json', retain=True)[1])
            assert [test_summary[k] for k in ('passed','failed','ignored','selected','retries')] == [1655,0,34,1689,0]
            assert test_summary['success'] is True and test_summary['filter'] == '' and not test_summary['enumeration_errors']
            assert audit['success'] is True and audit['errors'] == [] and audit['expected_filter'] == ''
            assert [audit[k] for k in ('passed','failed','ignored','selected','executed')] == [1655,0,34,1689,1655]
            ledger_identity, ledger_raw = read(OUTPUT / 'isolated-tests/tests.jsonl', audit['input_sha256']['tests.jsonl'], retain=True)
            rows = [json.loads(line) for line in ledger_raw.splitlines()]
            assert len(rows) == 1689
            new_cases = []
            for name in NEW_EXACT_TESTS:
                matched = [row for row in rows if row['name'] == name]
                assert len(matched) == 1
                row = matched[0]
                assert row['status'] == 'passed' and row['executed'] is True and row['attempt'] == 1
                assert row['exit_code'] == 0 and row['timed_out'] is False
                new_cases.append(row)
            receipt.update(passed=True, tests=test_summary, source_tested=qualified['source_after'],
                           new_exact_tests=new_cases, original_test_ledger=ledger_identity,
                           formatter_changed_paths=[p for p in expected if qualified['source_after'][p] != expected[p]])
            result_code = 0
    except Exception as error:
        receipt['error'] = f'{type(error).__name__}: {error}'
        receipt['error_trace'] = traceback.format_exc()
        if transfer['passed'] is not True:
            transfer.setdefault('error', receipt['error'])
            transfer.setdefault('finished_utc', utc())
    finally:
        receipt['finished_utc'] = utc()
        receipt['bound_parent_inputs'] = saved_inputs
        try:
            if transfer_opened is not None:
                update_receipt(root_fd, 'target-transfer-01.json', transfer_opened, transfer)
            if prep_opened is not None:
                update_receipt(root_fd, 'preparation-01.json', prep_opened, receipt)
            print(json.dumps({'preparation_and_qualification_passed': receipt['passed'],
                              'candidate_qualified': receipt['candidate_qualified'], 'error': receipt.get('error')}), flush=True)
        finally:
            for opened in (prep_opened, transfer_opened):
                if opened is not None:
                    os.close(opened[0])
            if cache_fd is not None:
                os.close(cache_fd)
            if root_chain is not None:
                close_chain(root_chain)
            close_chain(parent_chain)
            close_chain(home)
    return result_code


if __name__ == '__main__':
    raise SystemExit(main())
