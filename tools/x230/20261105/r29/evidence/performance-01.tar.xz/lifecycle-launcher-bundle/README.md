# R29 acceptance tools

Prepared from the frozen R29 socket-corrected templates. Only actual final qualifier/input identities have been bound. Qualification, Rust/Python CI, installation, observation, lifecycle and saturation outcomes remain unknown. The accepted comparison remains R24; the qualified R28 parent remains rejected.

Run the unchanged six-receipt materializer only after original R29 strong success and complete receipt readback. The installer verifies that input. Run observation after original CI and installation gates; normal lifecycle requires the actual passing observation, and saturation runs inside the same parent only after the original normal gates pass. No retries are added.
