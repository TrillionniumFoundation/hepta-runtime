#!/usr/bin/env python3
"""Create only the reviewed R29 tools after original qualification; run no tools."""
import argparse
import datetime
import hashlib
import io
import json
import os
from pathlib import Path, PurePosixPath
import re
import stat
import sys
import tarfile

sys.dont_write_bytecode = True
STAGE_ROOT = Path('/home/qian/hepta-runtime-optimization-20261105-r25')
ROOT = Path('/home/qian/hepta-runtime-optimization-20261105-r29')
SOURCE = ROOT / 'source'
CANDIDATE_DIR = ROOT / 'qualification-01'
SCRIPT = STAGE_ROOT / 'tools/install_r29_reviewed_tools_01.py'
QUALIFICATION_INPUT = STAGE_ROOT / 'tools/r29-installation-qualification-01.json'
RECEIPT = 'tools-install-01-receipt.json'
NEW_DIRECTORIES = ('tools-01', 'lifecycle-tools-01', 'lifecycle-launcher-bundle-01',
                   'lifecycle-launcher-bundle-01/tools-01')
PARENT_INSTALL = {
    'tools-01/r29_lifecycle_campaign.py': str(ROOT / 'tools-01/r29_lifecycle_campaign.py'),
    'tools-01/prepare_lifecycle_inputs.py': str(ROOT / 'tools-01/prepare_lifecycle_inputs.py'),
    'lifecycle-inputs-01.example.json': str(ROOT / 'lifecycle-inputs-01.example.json'),
}
ROOT_FILES = {'campaign-inputs-01.example.json', 'observation-plan-01.json',
              'observation-tools-manifest-01.json', 'lifecycle-inputs-01.example.json'}
ARCHIVES = {'lifecycle': {'bytes': 83484,
               'expanded_bytes': 384752,
               'member_count': 28,
               'members': {'README.md': {'bytes': 9053,
                                         'sha256': 'bf5ece8988afa5a91f01da1df0e1740add1390f6653d32c7bd562d99b11529be'},
                           'allocator_environment.py': {'bytes': 5879,
                                                        'sha256': 'f5c8e879c540b3f7cb1b7d3a7a0f5002c2f40c1a87963174b0b00470fa3a4525'},
                           'allocator_environment_audit.py': {'bytes': 6709,
                                                              'sha256': '4b082ce343ae3943e3098baa58af2f5def7198881b9c087d63d88360e9763727'},
                           'analyze_lifecycle_gates.py': {'bytes': 7581,
                                                          'sha256': 'c7a861a94a89dd81debb5c055773918d89a1c9c29b699e2e5a0341e51be69553'},
                           'analyze_native_observation.py': {'bytes': 8708,
                                                             'sha256': 'cc7f6884d581cd1ced430437350e808de51931c50d12441797205501b20cae66'},
                           'audit_native_evidence.py': {'bytes': 17065,
                                                        'sha256': 'b69f6902d2de81eab41b21506f024c002d2f8264d60e86df6b1086623a77fd28'},
                           'cancel_saturation_gate.py': {'bytes': 15789,
                                                         'sha256': '536ebdc5f2b090a8c007f189a895ed2e19d7b8b7e41530ccba94dd826742ef7f'},
                           'lifecycle-gate-policy.json': {'bytes': 1575,
                                                          'sha256': '36658346c4e265bf551a1ae1a4c6210bec8e4729f7961302a203008741cd381e'},
                           'lifecycle-tools-manifest-01.json': {'bytes': 4066,
                                                                'sha256': 'a377791a94e1327bdf3c7da98f30b379caafe6948295d81871f06287bf7c5ef0'},
                           'observation_resources.py': {'bytes': 12382,
                                                        'sha256': 'f3402d51cb37b2fe20f4351b3a81ec5990a9fdaff93a846d21c07ccd557cb894'},
                           'owned_ssh_interruption.py': {'bytes': 7892,
                                                         'sha256': '1989c57f0b944afae1ed759d6529b8f1cc26197e269e2c34c4fd49e43a32aa7b'},
                           'run_lifecycle_abba_01.py': {'bytes': 14787,
                                                        'sha256': '06ff6660bac7f7f97c368a3546d329c40e5f0a30b28545e73f6e9cd5ff30d984'},
                           'run_lifecycle_tool_tests.py': {'bytes': 2224,
                                                           'sha256': 'e3c1e8163249dba14672a3a82b43a2d7b8b4c0802b94b8511bf3db668f865a2d'},
                           'run_native_observation.py': {'bytes': 3279,
                                                         'sha256': '7606648c99b2ff2bbf0bba58384e8cab609ac3899f838c0b80ba54d6288d20bb'},
                           'run_six_host_cancel_recovery.py': {'bytes': 27847,
                                                               'sha256': '698eb7801cde3f2bd5ff202412c0833fc218fd7e912c3c949d2b37fde7a56a12'},
                           'run_six_host_cancel_recovery_timed.py': {'bytes': 30163,
                                                                     'sha256': 'a46e54fec23e34133ddbe789deb171492e8e1c665c3dd8ca5fb1ce44db51620e'},
                           'run_six_host_cancel_saturation.py': {'bytes': 31325,
                                                                 'sha256': 'ae195c895ab58d3bf067e37f30520bf572fd86b6282722dee9a56acc62df85a0'},
                           'source-provenance.json': {'bytes': 2510,
                                                      'sha256': '58d276c8df05dcd95a0a25e6264c3de1b248e8bb821651fb1b52859dd707dbbe'},
                           'status-predicate.json': {'bytes': 875,
                                                     'sha256': '5828c7ba2990f38531cce7e1a42b44315ee42278ccaee361ace8d9472a96da34'},
                           'summarize_lifecycle_abba_01.py': {'bytes': 16065,
                                                              'sha256': '9e050343bb32e7f57148f633ff94bbcfb3a7452b2872ae68404ca642e937af89'},
                           'test_native_harness.py': {'bytes': 13286,
                                                      'sha256': '2b450175b9e6122248ac1bcb51860aa8a6d3eff55f6ac8c877c0a905e3dd7d00'},
                           'test_r25_lifecycle_tools.py': {'bytes': 10026,
                                                           'sha256': '1845cdb48440a03146e337af7baf916bb9cdb76fb46ea0699f79144cf7197566'},
                           'test_verify_saturation_extension.py': {'bytes': 8187,
                                                                   'sha256': '10f2dcbfa9e2b5c625f22c3edc32c9f8a969509345b20d9b135cebc2235c16fb'},
                           'verify_cancel_recovery.py': {'bytes': 16634,
                                                         'sha256': '0116652a0b489dc462f005e01d7c943feda9ba784563d7317c92bb5beb9a701c'},
                           'verify_cancel_saturation.py': {'bytes': 17123,
                                                           'sha256': 'd3b6772ddffc711a23aa4aa9566f903c149535a3d3c4cc3466ee73690cbc1e75'},
                           'verify_saturation_extension.py': {'bytes': 9418,
                                                              'sha256': '23dfd25517b517067a4fbb3f4a3227f12bafff46b828eb05f7bf322596124e6a'},
                           'x230_observation_benchmark.py': {'bytes': 37006,
                                                             'sha256': '4d96f0bf2da2562e788f48be7c37589ab3a513be5f9d8b2d741afe5c08ea9eed'},
                           'x230_six_running_recovery_canary.py': {'bytes': 47298,
                                                                   'sha256': '6219bc556b0ac6d142bd4c731466b959e8a410f0b4b55f3d8b303f8fdbfbaaf4'}},
               'path': '/home/qian/hepta-runtime-optimization-20261105-r25/staged-r29-lifecycle-tools-01.tar.gz',
               'sha256': '6403ce63eb1552f357cbc0e90a3b86bd913ce304064e30febfcd27c6ef6344ee'},
 'observation': {'bytes': 36946,
                 'expanded_bytes': 135631,
                 'member_count': 10,
                 'members': {'campaign-inputs-01.example.json': {'bytes': 3818,
                                                                 'sha256': '04b0c7008b9ed7eb82135c5ceaf69d60d6bffbac66bfad8569aac3a29085e40b'},
                             'observation-plan-01.json': {'bytes': 12542,
                                                          'sha256': 'de24734d5a53bc4fdd28e46fb87d5545e8909aff31a60b1891ba767aa3bb117b'},
                             'observation-tools-manifest-01.json': {'bytes': 1901,
                                                                    'sha256': '22b0f0d2b3c175e0a1f12660b05adcdf34ab4fae780347fafd63a6869c3607e4'},
                             'tools-01/compiler-monitor-policy-01.json': {'bytes': 1001,
                                                                          'sha256': 'ddb2e03d4a1a1610466a5dc2d1a544f554ad12fc31412483101b48a235402368'},
                             'tools-01/compiler_monitor.py': {'bytes': 12510,
                                                              'sha256': 'afb514362a9d8dd573b806f0dc87df16bd3a906e4574d10d91bf483b2e76cdcf'},
                             'tools-01/compiler_state.py': {'bytes': 6243,
                                                            'sha256': '9da718654db04a646e081d2d719a2d6d4655ffe337bc0e3f906e736e4d77a251'},
                             'tools-01/prepare_campaign_inputs.py': {'bytes': 9964,
                                                                     'sha256': '48dad8915c0bce00085590011873a1146840c32ae0a7620f300d6981c7d800c1'},
                             'tools-01/r29_campaign.py': {'bytes': 66141,
                                                          'sha256': '0eaf6dd96e6a69eba4ef382360febefd58e1f0370baf7cd79bb817ac2ce266ec'},
                             'tools-01/summarize_r25_campaign.py': {'bytes': 14456,
                                                                    'sha256': '2418bad36fe4aef75d52c5a00c898ff93fef9bb4b6efb10028105143106a1864'},
                             'tools-01/validate_compiler_monitor.py': {'bytes': 7055,
                                                                       'sha256': 'd2cd009adf1f35a394ffddcc8f8646cc0c1b856b78181ca321ea68f6468218b2'}},
                 'path': '/home/qian/hepta-runtime-optimization-20261105-r25/staged-r29-observation-tools-01.tar.gz',
                 'sha256': 'a3fd4c5d71beeb26917a82811e5ca524ad9abc7d67dc7b9de8f33b11ee1e36c1'},
 'parent': {'bytes': 16381,
            'expanded_bytes': 70044,
            'member_count': 9,
            'members': {'README.md': {'bytes': 704,
                                      'sha256': '1ba763663ea2dd4dd600819b5a12b5278c4b55cad47e90330f47bc5605dd0fe8'},
                        'derivation-inputs-01.json': {'bytes': 4236,
                                                      'sha256': 'a0569d3e86743a7d2fa7a4dec6b6dc1e02786d8f93371875c663dfe5b6b2b811'},
                        'lifecycle-inputs-01.example.json': {'bytes': 2585,
                                                             'sha256': '0d3a7896921a75d64462e09a562b5bba57d34caf4f914c4eb2bc876eeccc7243'},
                        'lifecycle-launcher-manifest-01.json': {'bytes': 2338,
                                                                'sha256': '2e22e99768f4d0ab2f18db5188837ea21cd2b2afb59475738dff0cd7e5b9f777'},
                        'lifecycle-plan-01.json': {'bytes': 11749,
                                                   'sha256': 'edb087e787766f2026a8cb06050a5337f75e76555e6d398d55232ac5f38d8bd6'},
                        'local-verification-01.json': {'bytes': 1568,
                                                       'sha256': '5340250044dbef95288bad1a3b8175fc4cb71365d855a18914a5f528e256989d'},
                        'source-delta-01.patch': {'bytes': 8038,
                                                  'sha256': '5150caf6ac8a8fc4bf45238a78edee31d6f3958ad0d2e35937724939e7a1f137'},
                        'tools-01/prepare_lifecycle_inputs.py': {'bytes': 12066,
                                                                 'sha256': '45efacd48c7b27141f036340c0b9b8f504fb41b43a8b1ddb66dc5fb8172c64f6'},
                        'tools-01/r29_lifecycle_campaign.py': {'bytes': 26760,
                                                               'sha256': '12b9ad142d95148e9d08a69d44be3e4e3d17a03877eadc956a020602aa22e846'}},
            'path': '/home/qian/hepta-runtime-optimization-20261105-r25/staged-r29-lifecycle-launcher-bundle-01.tar.gz',
            'sha256': 'c1882d3546c4e49fcd48e1f46c316850afb7d77b48759e9dab357357f9ac3a6a'}}
HEX = re.compile(r'[0-9a-f]{64}\Z')


def need(value, message):
    if not value:
        raise RuntimeError(message)


def encoded(value):
    return (json.dumps(value, sort_keys=True, indent=2, allow_nan=False) + '\n').encode()


def identity(raw):
    return {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


def stamp(value):
    return tuple(getattr(value, name) for name in
                 ('st_dev', 'st_ino', 'st_uid', 'st_mode', 'st_nlink', 'st_size', 'st_mtime_ns', 'st_ctime_ns'))


def read_path(path, expected=None, maximum=128 * 1024 * 1024, retain=True):
    path = Path(path)
    need(path.is_absolute() and path.resolve(strict=True) == path, 'indirect or missing input path')
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_CLOEXEC | os.O_NONBLOCK)
    try:
        before = os.fstat(fd)
        need(stat.S_ISREG(before.st_mode) and before.st_nlink == 1 and before.st_uid == os.geteuid()
             and 0 <= before.st_size <= maximum, 'unsafe or oversized owned input')
        digest, size, chunks = hashlib.sha256(), 0, []
        while block := os.read(fd, 1024 * 1024):
            size += len(block)
            need(size <= before.st_size, 'input grew while reading')
            digest.update(block)
            if retain:
                chunks.append(block)
        need(size == before.st_size and stamp(before) == stamp(os.fstat(fd)) == stamp(path.lstat()),
             'input identity changed while reading')
    finally:
        os.close(fd)
    result = {'path': str(path), 'bytes': size, 'sha256': digest.hexdigest()}
    if expected is not None:
        need(type(expected.get('bytes')) is int and HEX.fullmatch(expected.get('sha256', ''))
             and result == {key: expected[key] for key in result}, 'actual input identity differs')
    return result, b''.join(chunks)


def read_at(directory, name, expected):
    need(Path(name).name == name, 'only direct file names are permitted')
    fd = os.open(name, os.O_RDONLY | os.O_NOFOLLOW | os.O_CLOEXEC | os.O_NONBLOCK, dir_fd=directory)
    try:
        before = os.fstat(fd)
        need(stat.S_ISREG(before.st_mode) and before.st_nlink == 1 and before.st_uid == os.geteuid()
             and 0 <= before.st_size == expected['bytes'] <= 1048576, 'unsafe installed file')
        with os.fdopen(os.dup(fd), 'rb') as stream:
            raw = stream.read(expected['bytes'] + 1)
        need(stamp(before) == stamp(os.fstat(fd)) == stamp(os.stat(name, dir_fd=directory, follow_symlinks=False))
             and identity(raw) == expected, 'installed file identity differs')
        return {'device': before.st_dev, 'inode': before.st_ino, 'uid': before.st_uid,
                'mode': stat.S_IMODE(before.st_mode), 'links': before.st_nlink, **identity(raw)}
    finally:
        os.close(fd)


def members_from_archive(raw, spec):
    need(identity(raw) == {key: spec[key] for key in ('bytes', 'sha256')}, 'archive identity differs')
    result = {}
    with tarfile.open(fileobj=io.BytesIO(raw), mode='r:gz') as archive:
        entries = archive.getmembers()
        need(len(entries) == spec['member_count'] and sum(entry.size for entry in entries) == spec['expanded_bytes']
             and spec['expanded_bytes'] <= 1048576, 'archive member count or expansion differs')
        for entry in entries:
            path = PurePosixPath(entry.name)
            need(entry.type in (tarfile.REGTYPE, tarfile.AREGTYPE) and not entry.issparse()
                 and not entry.linkname and path.parts and not path.is_absolute()
                 and all(part not in ('.', '..') for part in path.parts)
                 and path.as_posix() == entry.name and entry.name in spec['members']
                 and entry.name not in result, 'unexpected, linked, duplicate or unsafe archive member')
            expected = spec['members'][entry.name]
            need(entry.size == expected['bytes'], 'archive member size differs')
            stream = archive.extractfile(entry)
            need(stream is not None, 'regular member unreadable')
            body = stream.read(expected['bytes'] + 1)
            need(identity(body) == expected, 'archive member SHA differs')
            result[entry.name] = body
        need(set(result) == set(spec['members']), 'archive member set differs')
    return result


def verify_r29_candidate_preparation(preparation, terminal, job_id, qualified, tests):
    """Verify actual R29 source/qualification/cache custody; never infer future passes."""
    import hashlib
    import json
    # Filled only from the reviewed final entry and its actual cache/QC/window
    # input. An unbound template cannot qualify any existing or future version.
    expected_launcher = {'path': '/home/qian/hepta-runtime-optimization-20261105-r25/tools/prepare_and_qualify_r29_01.py', 'bytes': 67635, 'sha256': '7ce339aa261fdf6acbc8e0ca8cf67f5c5d3a7b56fcc34d51ed4ee56ea4fe389a'}
    expected_input = {'path': '/home/qian/hepta-runtime-optimization-20261105-r25/tools/r29-qualification-01-input.json', 'bytes': 311502, 'sha256': '60bfe1ef593ad58d528f6e508d3f6e0a1e4f76183f1293b40f36b7ee6bb3f8a8'}
    need(isinstance(expected_launcher, dict) and isinstance(expected_input, dict),
         "R29 actual qualification entry/input identities remain unbound")
    need(isinstance(job_id, str) and re.fullmatch(r"[0-9a-f]{11,16}-[0-9a-f]{4}-[0-9a-f]{4}", job_id)
         and job_id not in {"1a1aa7fa690-fc05-43af", "1a1aaa6552d-fc05-459f", "1a1ab4cb0fc-fc05-4c3c",
                            "1a1ac274e49-fc05-5286", "1a1ac456b07-fc05-532a", "1a1ac5d5a29-fc05-53d9",
                            "1a1acfe317a-fc05-57ee"},
         "the actual new R29 qualification job is required")
    need(terminal.get("job_id") == job_id and terminal.get("state") == "succeeded"
         and type(terminal.get("exit_code")) is int and terminal["exit_code"] == 0
         and all(terminal.get(key) is False for key in ("automatic_retry", "timed_out", "cancelled"))
         and all(terminal.get(key) is True for key in ("output_complete", "output_durable", "terminal_publication_confirmed"))
         and type(terminal.get("terminal_publication_protocol")) is int and terminal["terminal_publication_protocol"] == 1
         and terminal.get("log_synced") == {"stdout": True, "stderr": True}
         and terminal.get("log_errors") == {"stdout": None, "stderr": None}
         and terminal.get("log_truncated") == {"stdout": False, "stderr": False},
         "original R29 qualification has no complete successful native terminal proof")
    for stream in ("stdout", "stderr"):
        counts = terminal["log_bytes"][stream]
        need(set(counts) == {"seen", "stored"} and all(type(value) is int and value >= 0 for value in counts.values())
             and counts["seen"] == counts["stored"], "qualification native log byte custody differs")
    need(preparation["schema"] == "hepta-r29-qualified-parent-preparation/v1"
         and preparation["selected_proposal"] == "shared unfiltered ToolRouter"
         and preparation.get("optional_pidfd_selected") is False and preparation.get("finished_utc")
         and all(preparation.get(key) is True for key in ("passed", "candidate_qualified", "parent_source_qualified",
             "parent_observation_rejection_preserved", "parent_inputs_unchanged", "cache_reused",
             "cache_source_source_qualified", "cache_moved_by_single_no_replace_rename"))
         and all(preparation.get(key) is False for key in ("candidate_adopted", "parent_candidate_adopted",
             "production_services_modified", "shared_hardlinks_created", "cache_copy_executed", "cache_cleanup_executed")),
         "actual R29 preparation is incomplete or changed the private cache scope")
    need(preparation["source"] == str(SOURCE) and preparation["target"] == str(ROOT / "target-build")
         and preparation["qualification_output"] == str(CANDIDATE_DIR)
         and preparation["launcher"] == expected_launcher and preparation["input"] == expected_input,
         "R29 qualification launcher, actual input or private paths differ")
    need(expected_launcher["path"] == "/home/qian/hepta-runtime-optimization-20261105-r25/tools/prepare_and_qualify_r29_01.py"
         and expected_input["path"] == "/home/qian/hepta-runtime-optimization-20261105-r25/tools/r29-qualification-01-input.json",
         "R29 entry belongs to another runtime attempt")
    source_cache = "/home/qian/hepta-runtime-optimization-20261105-r28/target-build"
    need(preparation["cache_source"] == source_cache and preparation["unchanged_disk_reserve_bytes"] == 3221225472
         and preparation["new_full_cache_copy_bytes"] == 0, "R29 cache reuse weakened allocation or reserve policy")
    admission = preparation["admission"]
    need(admission["original_failed_probe01_preserved_as_failed"] is True
         and admission["original_failed_probe01_error"] == {"type": "RuntimeError", "message": "directory outside exact task parent"}
         and admission["original_failed_probe01"]["job_id"] == "1a1acfe317a-fc05-57ee"
         and admission["original_failed_probe01"]["stdout_identity"] == {
             "bytes": 21898, "sha256": "7d96f345114fcad140b40f69804df679f68b8e67d57a1c46941d809cedb3c58f"}
         and admission["readonly_probe_does_not_authorize_transfer"] is True
         and admission["all_user_process_channels_readable_claimed"] is False,
         "original failed readonly probe or reference limits were promoted")
    need(admission["downloaded_QC_full_verification"] == {
        "bytes": 9585, "sha256": "7342eed4ed17389eb57f5f40111438c5c4e339591ebb77c450a4fb1fe3ae2614"}
         and admission["downloaded_QC_archive"] == {
        "bytes": 1915620, "sha256": "442586ded13a4cfde54531e6f05ddddcf26c2f53d40d15b04c5993ece5f04186"},
         "R28 full downloaded QC archive was not independently verified")
    writer = admission["root_writer_admission"]
    need(writer["schema"] == "hepta-r29-owned-cache-writer-admission/v1"
         and writer["source_cache"] == source_cache and writer["destination_cache"] == str(ROOT / "target-build")
         and writer["exclusive_compilation_window_held"] is True
         and writer["no_later_R28_cache_use_scheduled"] is True
         and writer["original_native_raw_custody_retained"] is True
         and writer["same_owner_unknowns_reviewed_without_claiming_all_channels_readable"] is True
         and writer["fd_and_mmap_reference_channels_not_covered"] is True
         and writer["root_reviewed_readonly_probe_stdout"] == admission["original_probe_stdout"]
         and writer["root_reviewed_downloaded_QC_verification"] == admission["downloaded_QC_full_verification"],
         "the actual root execution window is not bound to the preserved original evidence")
    transfer = preparation["cache_transfer"]
    need(transfer["schema"] == "hepta-r29-owned-cache-transfer/v1"
         and transfer["source_cache"] == source_cache and transfer["destination_cache"] == str(ROOT / "target-build")
         and transfer["root_writer_admission"] == writer and transfer["original_cache_probe"] == admission["original_probe_stdout"]
         and all(transfer.get(key) is True for key in ("passed", "rename_attempted", "rename_returned_success",
             "old_path_absent", "destination_is_original_inode", "descendants_metadata_unchanged"))
         and all(transfer.get(key) is False for key in ("copy_executed", "cleanup_executed", "automatic_retry", "automatic_rollback"))
         and transfer.get("finished_utc") and "error" not in transfer and "rename_errno" not in transfer,
         "the one original no-replace cache transfer did not close")
    before, immediate, after = (transfer[key] for key in ("metadata_before", "immediate_metadata_before", "metadata_after"))
    for row in (before, immediate, after):
        need(row["all_entries_traversed"] is True and row["all_regular_links_accounted_within_target"] is True
             and row["external_or_unaccounted_hardlink_inodes"] == 0 and row["retained_qualification_elf_aliases"] == []
             and row["anomaly_examples_maximum_32"] == []
             and all(row["counts"][key] == 0 for key in ("symlinks", "other_nonregular", "other_device_entries", "other_owner_entries")),
             "cache metadata escaped the original owned regular/directory scope")
    need(before["path"] == immediate["path"] == source_cache and after["path"] == str(ROOT / "target-build")
         and before["counts"] == immediate["counts"] == after["counts"]
         and before["root_identity"] == immediate["root_identity"]
         and before["metadata_sha256"] == immediate["metadata_sha256"]
         and before["descendants_metadata_sha256"] == immediate["descendants_metadata_sha256"] == after["descendants_metadata_sha256"],
         "cache descendants or pre-transfer identity changed")
    root_fields = ("st_dev", "st_ino", "st_uid", "st_gid", "st_mode", "st_nlink", "st_size", "st_mtime_ns")
    need(all(immediate["root_identity"][key] == after["root_identity"][key] for key in root_fields)
         and after["root_identity"]["st_ctime_ns"] >= immediate["root_identity"]["st_ctime_ns"]
         and transfer["root_ctime_before"] == immediate["root_identity"]["st_ctime_ns"]
         and transfer["root_ctime_after"] == after["root_identity"]["st_ctime_ns"],
         "cache root identity changed beyond rename ctime")
    need(preparation["cache_bytes"] == before["counts"]["regular_logical_bytes"]
         and preparation["cache_file_count"] == before["counts"]["regular_files"], "cache size accounting differs")
    for scan in (preparation["cache_reference_scan_before_source"], transfer["immediate_reference_scan"]):
        need(scan["matched_live_processes"] == [] and scan["raw_argv_or_environment_or_unrelated_cwd_emitted"] is False,
             "an observed cache reference was ignored")
    for samples in (preparation["compiler_quiescence"], preparation["compiler_quiescence_immediately_before_move"]):
        need(isinstance(samples, list) and samples and samples[-1]["compiler_processes"] == [],
             "compiler quiet admission did not finish")
    for disk in (preparation["disk_after_fresh_source_before_move"], transfer["disk_before_move"],
                 preparation["disk_immediately_before_compiler"]):
        need(disk["unchanged_required_headroom_bytes"] == 3221225472
             and type(disk["available_bytes"]) is int and disk["available_bytes"] >= 3221225472
             and disk["new_full_cache_copy_bytes"] == 0 and disk["move_frees_bytes"] is False
             and disk["future_build_growth_guaranteed_to_fit"] is False,
             "the unchanged 3 GiB reserve was not checked at the actual admission boundaries")
    retained = preparation["retained_parent_ELFs_before"]
    need(len(retained) == 8 and len({row["path"] for row in retained}) == 8
         and retained == preparation["retained_parent_ELFs_after_qualification"]
         == transfer["retained_parent_ELFs_before"] == transfer["retained_parent_ELFs_after"],
         "the eight retained R28 ELF copies were not preserved")
    for row in retained:
        d = row["current_identity"]
        need(row["path"].startswith("/home/qian/hepta-runtime-optimization-20261105-r28/qualification-01/")
             and d["st_uid"] == 1000 and d["st_nlink"] == 1 and d["st_mode"] & 0o170000 == 0o100000
             and d["st_size"] == row["bytes"] and row["full_export_identity_unchanged"] is True
             and row["sha256_recomputed_by_this_metadata_probe"] is False and row["payload_read_bytes"] == 0,
             "an original retained ELF descriptor was substituted or reclassified")
    transfer_raw = (json.dumps(transfer, sort_keys=True, indent=2, allow_nan=False) + "\n").encode()
    need(preparation["cache_transfer_receipt"] == {"path": str(ROOT / "target-transfer-01.json"),
         "bytes": len(transfer_raw), "sha256": hashlib.sha256(transfer_raw).hexdigest()},
         "embedded transfer proof differs from the original closed receipt")
    expected_changes = [
        {"path": "src/mcp/server.rs", "before": {"bytes": 118630, "sha256": "875785604d51feba6b02fdf1a6699b8d361d065a44cc4ef7bee6f931521e7e71"},
         "after": {"bytes": 118947, "sha256": "e6f34ef9ace819f72ceafaeee40a957210362f87cc4317d6ebfe4b76ba2fa4d4"}},
        {"path": "src/mcp/server_tests.rs", "before": {"bytes": 38983, "sha256": "003fa3365b3af0302c4a8e19f9230cea35f3366878898c1cf0920b2b6d47cddb"},
         "after": {"bytes": 49832, "sha256": "f4dfdc9c26ef3fdbba4dd2b5d0cfe3f239230a43cb78162bbba21a1c0499cc7f"}}]
    need(preparation["source_changes"] == expected_changes, "R29 is not the exact selected two-file router change")
    before_map = preparation["source_before"]
    expected = dict(before_map)
    changed_paths = {change["path"] for change in expected_changes}
    need(len(before_map) == 221 and len(changed_paths) == 2, "R29 source/change inventory differs")
    for change in expected_changes:
        need(before_map[change["path"]] == change["before"]["sha256"], "R29 qualified parent preimage differs")
        expected[change["path"]] = change["after"]["sha256"]
    need(hashlib.sha256((json.dumps(before_map, sort_keys=True, indent=2) + "\n").encode()).hexdigest()
         == "da8cbdfef75c1c9fc5861e4fe0bd96aeb98f635e95fc122610021cd725db1d28",
         "the R29 parent is not the actual complete qualified R28 map")
    need(preparation["candidate_compilation_inputs"] == expected
         and hashlib.sha256((json.dumps(expected, sort_keys=True, indent=2) + "\n").encode()).hexdigest()
         == "ce3e814a7bfeb7f0d168782dc325e643550cc0c768b606d90c4d45693fbe4853",
         "R29 pre-format compilation input differs")
    stages = ["format", "fmt-check", "harness-tests", "clippy", "test-build", "isolated-tests", "audit-isolated-tests", "release"]
    need(qualified["schema"] == "hepta-x230-composed-qualification/v1" and qualified["qualified"] is True
         and qualified.get("finished_utc") and qualified["source"] == str(SOURCE)
         and qualified["jobs"] == 2 and qualified["service_changes"] is False
         and type(qualified["automatic_test_retries"]) is int and qualified["automatic_test_retries"] == 0
         and [row["name"] for row in qualified["stages"]] == stages
         and all(type(row["returncode"]) is int and row["returncode"] == 0 for row in qualified["stages"]),
         "all eight original R29 qualification stages must pass")
    need(qualified["source_input"] == expected and qualified["source_tested"] == qualified["source_after"] == preparation["source_tested"]
         and set(qualified["source_after"]) == set(expected)
         and all(qualified["source_after"][name] == value for name, value in expected.items() if name not in changed_paths),
         "actual formatted R29 source differs from its qualification")
    need(preparation["formatter_changed_paths"] == [name for name in expected if qualified["source_after"][name] != expected[name]]
         and qualified["harness_before"] == qualified["harness_after"] == preparation["harness_before"]
         and len(qualified["harness_after"]) == 19, "qualification formatter or original harness binding differs")
    counts = ("passed", "failed", "ignored", "selected", "retries")
    need(all(type(tests[key]) is int for key in counts) and [tests[key] for key in counts] == [1655, 0, 34, 1689, 0]
         and tests["success"] is True and tests["filter"] == "" and not tests["enumeration_errors"]
         and preparation["tests"] == tests and preparation["qualification_returncode"] == 0
         and preparation["automatic_test_retries"] == 0, "original full R29 isolated result is incomplete")
    new_names = ["mcp::server::server_tests::cached_router_keeps_mcp_sessions_and_teardown_independent",
                 "mcp::server::server_tests::cached_router_rechecks_runtime_mode_and_native_session_owner"]
    need([row["name"] for row in preparation["new_exact_tests"]] == new_names
         and all(row["status"] == "passed" and row["executed"] is True and row["attempt"] == 1
                 and row["exit_code"] == 0 and row["timed_out"] is False for row in preparation["new_exact_tests"]),
         "the two new original exact cases were not executed once successfully")
    need(preparation["qualification_argv"] == ["/usr/bin/python3", "-B", str(SOURCE / "tools/x230/20261028/qualify.py"),
         "--source", str(SOURCE), "--output", str(CANDIDATE_DIR), "--target", str(ROOT / "target-build"),
         "--cargo-home", "/home/qian/hepta-runtime-optimization-20261023/cargo-home-a32-a33-r02",
         "--jobs", "2", "--stage-timeout", "3600"], "the original qualification argv was weakened")
    return {"passed": True, "original_job_id": job_id, "selected_proposal": "shared unfiltered ToolRouter",
            "optional_pidfd_selected": False, "qualified_source_files": 221, "harness_files": 19, "stages": stages,
            "tests": {key: tests[key] for key in counts}, "candidate_adopted": False,
            "qualified_parent_R28_observation_rejection_preserved": True,
            "original_failed_readonly_probe01_preserved": True, "single_no_replace_cache_move_verified": True,
            "cache_copy_executed": False, "cache_cleanup_executed": False, "unchanged_disk_reserve_bytes": 3221225472}


def verify_qualification_documents(value, preparation, terminal, qualified, summary, audit, source_map):
    need(value['schema'] == 'hepta-r29-installation-qualification/v1'
         and value['executed'] is False, 'actual qualification input schema differs')
    proof = verify_r29_candidate_preparation(preparation, terminal, value['original_qualification_job_id'], qualified, summary)
    need(type(preparation.get('finished_utc')) is str and bool(preparation['finished_utc'])
         and preparation['qualification_report'] == value['qualification_report']
         and source_map == qualified['source_after'], 'completed preparation/source-map binding differs')
    need(summary['schema'] == 'hepta-isolated-libtest/v1' and summary['success'] is True
         and summary['filter'] == '' and summary['enumeration_errors'] == []
         and summary['source_manifest_path'] == str(CANDIDATE_DIR / 'source-map.json')
         and summary['source_manifest_sha256'] == value['source_map']['sha256'], 'full actual isolated summary differs')
    need(audit['schema'] == 'hepta-isolated-libtest-audit/v1' and audit['success'] is True
         and audit['errors'] == [] and 'fatal_error' not in audit and audit['expected_filter'] == ''
         and audit['input_sha256']['summary.json'] == value['isolated_summary']['sha256']
         and all(audit[key] == summary[key] for key in ('passed', 'failed', 'ignored', 'selected'))
         and audit['executed'] == 1655, 'original independent isolated audit differs')
    return proof


def qualification_prerequisites(value, bind):
    paths = {
        'preparation': ROOT / 'preparation-01.json',
        'native_terminal': ROOT / 'qualification-terminal-status-01.json',
        'qualification_report': CANDIDATE_DIR / 'report.json',
        'source_map': CANDIDATE_DIR / 'source-map.json',
        'isolated_summary': CANDIDATE_DIR / 'isolated-tests/summary.json',
        'isolated_audit': CANDIDATE_DIR / 'isolated-tests.audit.json',
    }
    documents = {}
    for name, path in paths.items():
        need(value[name]['path'] == str(path), 'actual qualification receipt path differs')
        _, raw = bind(path, value[name])
        documents[name] = json.loads(raw)
    proof = verify_qualification_documents(value, documents['preparation'], documents['native_terminal'],
        documents['qualification_report'], documents['isolated_summary'], documents['isolated_audit'], documents['source_map'])
    qualified = documents['qualification_report']
    paths = [SOURCE / name for name in ('Cargo.toml', 'Cargo.lock', 'rustfmt.toml')]
    for name in ('src', 'examples'):
        paths.extend(path for path in (SOURCE / name).rglob('*') if path.is_file())
    actual = {path.relative_to(SOURCE).as_posix(): bind(path, retain=False)[0]['sha256'] for path in sorted(paths)}
    need(actual == qualified['source_after'], 'actual qualified source changed before tool installation')
    harness = {path.name: bind(path, retain=False)[0]['sha256']
               for path in sorted((SOURCE / 'tools/x230/20261028').glob('*.py'))}
    need(harness == qualified['harness_after'], 'actual qualification harness changed')
    binaries = {}
    need(set(qualified['binaries']) == {'hepta-runtime', 'hepta-runtime-jobctl', 'native_process_driver'},
         'qualified executable set differs')
    for name, item in qualified['binaries'].items():
        path = CANDIDATE_DIR / name
        need(item['path'] == str(path) and os.access(path, os.X_OK), 'qualified artifact path differs')
        row, _ = bind(path, retain=False)
        need(row['sha256'] == item['sha256'], 'actual qualified executable changed')
        binaries[name] = row
    for label in ('launcher', 'input'):
        item = documents['preparation'][label]
        need(Path(item['path']).parent == STAGE_ROOT / 'tools', 'qualification bootstrap input path differs')
        bind(item['path'], item, retain=False)
    proof.update(actual_binaries=binaries, source_files=len(actual), harness_files=len(harness))
    return proof


def build_installation(bundles):
    observation = json.loads(bundles['observation']['observation-tools-manifest-01.json'])
    lifecycle = json.loads(bundles['lifecycle']['lifecycle-tools-manifest-01.json'])
    parent = json.loads(bundles['parent']['lifecycle-launcher-manifest-01.json'])
    need(observation['schema'] == 'hepta-r29-observation-tools-install/v2'
         and observation['prepared_only'] is True and observation['create_only'] is True
         and observation['destination_root'] == str(ROOT) and len(observation['files']) == 9
         and set(observation['files']) == set(bundles['observation']) - {'observation-tools-manifest-01.json'},
         'observation payload manifest differs')
    need(lifecycle['schema'] == 'hepta-r25-lifecycle-tools/v1' and len(lifecycle['files']) == 27
         and set(lifecycle['files']) == set(bundles['lifecycle']) - {'lifecycle-tools-manifest-01.json'},
         'native lifecycle payload manifest differs')
    need(parent['schema'] == 'hepta-r29-lifecycle-launcher-bundle/v2'
         and parent['prepared_only'] is True and parent['create_only'] is True
         and parent['preserve_bundle_at'] == str(ROOT / 'lifecycle-launcher-bundle-01')
         and parent['installations'] == PARENT_INSTALL and len(parent['files']) == 8
         and set(parent['files']) == set(bundles['parent']) - {'lifecycle-launcher-manifest-01.json'},
         'outer lifecycle payload manifest differs')
    for label, manifest in (('observation', observation), ('lifecycle', lifecycle), ('parent', parent)):
        for name, pin in manifest['files'].items():
            need(identity(bundles[label][name]) == pin, 'payload manifest identity differs')
    need(parent['requires_observation_tools_manifest'] == identity(bundles['observation']['observation-tools-manifest-01.json'])
         and parent['requires_native_tools_manifest'] == identity(bundles['lifecycle']['lifecycle-tools-manifest-01.json']),
         'reviewed bundle dependencies disagree')
    obs_example = json.loads(bundles['observation']['campaign-inputs-01.example.json'])
    life_example = json.loads(bundles['parent']['lifecycle-inputs-01.example.json'])
    need(obs_example['launcher_sha256'] == life_example['campaign_helpers']['sha256']
         == identity(bundles['observation']['tools-01/r29_campaign.py'])['sha256']
         and life_example['launcher_sha256'] == identity(bundles['parent']['tools-01/r29_lifecycle_campaign.py'])['sha256']
         and life_example['tools_manifest']['sha256'] == identity(bundles['lifecycle']['lifecycle-tools-manifest-01.json'])['sha256'],
         'example helper identity differs')
    monitor = {}
    for label, name in {'module': 'compiler_monitor.py', 'validator': 'validate_compiler_monitor.py',
                        'reader': 'compiler_state.py', 'policy': 'compiler-monitor-policy-01.json'}.items():
        member = 'tools-01/' + name
        monitor[label] = {'path': str(ROOT / member), **identity(bundles['observation'][member])}
    need(obs_example['compiler_monitor'] == life_example['compiler_monitor'] == monitor,
         'actual four monitor paths or source identities differ between payload and templates')
    for example in (obs_example, life_example):
        need(example['attempt'] == '01' and example['candidate_release'] == 'R29'
             and example['qualification_terminal_status']['job_id'] is None
             and example['source_inputs_sha256'] is None
             and all(row == {'bytes': None, 'sha256': None} for row in example['candidate_binaries'].values()),
             'reviewed example was replaced by premature future evidence')
    plan = []
    for label, prefix in (('observation', ''), ('lifecycle', 'lifecycle-tools-01/'),
                           ('parent', 'lifecycle-launcher-bundle-01/')):
        for name, raw in sorted(bundles[label].items()):
            plan.append((prefix + name, raw, label, name))
    for name, path in sorted(PARENT_INSTALL.items()):
        plan.append((Path(path).relative_to(ROOT).as_posix(), bundles['parent'][name], 'parent', name))
    need(len(plan) == len({row[0] for row in plan}) == 50, 'installation collision or file count differs')
    for relative, _, _, _ in plan:
        path = PurePosixPath(relative)
        need(path.as_posix() == relative and not path.is_absolute() and '..' not in path.parts
             and ((path.parent.as_posix() == '.' and relative in ROOT_FILES)
                  or path.parent.as_posix() in NEW_DIRECTORIES), 'destination is outside fixed new scope')
    return plan


def absent(directory, name):
    try:
        os.stat(name, dir_fd=directory, follow_symlinks=False)
    except FileNotFoundError:
        return
    raise RuntimeError('existing destination must not be replaced: ' + name)


def create_file(directory, name, raw):
    need(Path(name).name == name, 'direct destination required')
    fd = os.open(name, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW | os.O_CLOEXEC, 0o600, dir_fd=directory)
    with os.fdopen(fd, 'wb') as stream:
        stream.write(raw)
        stream.flush()
        os.fsync(stream.fileno())
    result = read_at(directory, name, identity(raw))
    need(result['mode'] == 0o600, 'created file is not private')
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--installer-sha256', required=True)
    args = parser.parse_args()
    need(sys.platform == 'linux' and os.geteuid() != 0 and HEX.fullmatch(args.installer_sha256),
         'native Linux operator and reviewed source SHA required')
    need(Path(__file__).resolve() == SCRIPT and ROOT.resolve(strict=True) == ROOT,
         'fixed installer and existing qualifier-created R29 root required')
    os.umask(0o077)
    bindings, directories, created, created_dirs = [], {}, [], []
    root_fd = os.open(ROOT, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW | os.O_CLOEXEC)

    def bind(path, expected=None, retain=True):
        row, raw = read_path(path, expected, retain=retain)
        bindings.append(row)
        return row, raw

    try:
        before = os.fstat(root_fd)
        need(before.st_uid == os.geteuid() and stat.S_IMODE(before.st_mode) == 0o700,
             'qualifier-created root is not owned private0700')
        own, _ = bind(SCRIPT)
        need(own['sha256'] == args.installer_sha256, 'reviewed installer source changed')
        input_identity, raw = bind(QUALIFICATION_INPUT)
        qualification = qualification_prerequisites(json.loads(raw), bind)
        bundles, archive_rows = {}, {}
        for label, spec in ARCHIVES.items():
            need(Path(spec['path']).parent == STAGE_ROOT, 'staged archive is outside existing R25 root')
            row, raw = bind(spec['path'], spec)
            bundles[label] = members_from_archive(raw, spec)
            archive_rows[label] = dict(row, member_count=len(bundles[label]))
        plan = build_installation(bundles)
        # Only the named destinations are checked. Existing unrelated parent
        # entries, including binary_write's persistent locks, are not enumerated.
        for name in (*[d for d in NEW_DIRECTORIES if '/' not in d], *sorted(ROOT_FILES), RECEIPT):
            absent(root_fd, name)
        for row in bindings:
            need(read_path(row['path'], row, retain=False)[0] == row, 'prerequisite changed before installation')
        # No mutation occurs before all actual qualification and archive gates.
        for relative in NEW_DIRECTORIES:
            path = PurePosixPath(relative)
            owner_fd = root_fd if path.parent.as_posix() == '.' else directories[path.parent.as_posix()]
            os.mkdir(path.name, mode=0o700, dir_fd=owner_fd)
            fd = os.open(path.name, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW | os.O_CLOEXEC, dir_fd=owner_fd)
            current = os.fstat(fd)
            need(current.st_uid == os.geteuid() and stat.S_IMODE(current.st_mode) == 0o700, 'created directory ownership differs')
            directories[relative] = fd
            created_dirs.append(relative)
        installed = []
        for relative, raw, label, member in plan:
            path = PurePosixPath(relative)
            owner_fd = root_fd if path.parent.as_posix() == '.' else directories[path.parent.as_posix()]
            row = create_file(owner_fd, path.name, raw)
            created.append(relative)
            installed.append(dict(row, path=str(ROOT / relative), archive=label, member=member))
        for relative, fd in directories.items():
            os.fsync(fd)
            path = PurePosixPath(relative)
            owner_fd = root_fd if path.parent.as_posix() == '.' else directories[path.parent.as_posix()]
            need(stamp(os.fstat(fd)) == stamp(os.stat(path.name, dir_fd=owner_fd, follow_symlinks=False)),
                 'installed directory identity changed')
        for relative, raw, _, _ in plan:
            path = PurePosixPath(relative)
            read_at(root_fd if path.parent.as_posix() == '.' else directories[path.parent.as_posix()], path.name, identity(raw))
        for row in bindings:
            need(read_path(row['path'], row, retain=False)[0] == row, 'original prerequisite changed during installation')
        need(os.fstat(root_fd).st_ino == ROOT.lstat().st_ino and os.fstat(root_fd).st_dev == ROOT.lstat().st_dev,
             'original root directory was replaced')
        report = {'schema': 'hepta-r29-reviewed-tools-install/v2', 'installed': True,
                  'finished_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
                  'installer': own, 'actual_qualification_input': input_identity, 'qualification': qualification,
                  'archives': archive_rows, 'created_directories': created_dirs, 'installed_file_count': len(installed),
                  'files': installed, 'input_bindings': bindings, 'all_destinations_initially_absent': True,
                  'manual_regular_member_extraction': True, 'all_files_and_archives_rehashed': True,
                  'source_or_cache_modified': False, 'production_services_modified': False,
                  'packaged_code_executed': False, 'tests_run': 0, 'campaigns_started': 0, 'automatic_retries': 0}
        receipt = create_file(root_fd, RECEIPT, encoded(report))
        os.fsync(root_fd)
        print(json.dumps({'installed': True, 'installed_file_count': len(installed),
                          'receipt': dict(receipt, path=str(ROOT / RECEIPT)), 'tests_run': 0,
                          'campaigns_started': 0, 'source_or_cache_modified': False}), flush=True)
    except BaseException as error:
        print(json.dumps({'installed': False, 'created_files': created, 'created_directories': created_dirs,
                          'error': {'type': type(error).__name__, 'reason': str(error)},
                          'automatic_retries': 0, 'tests_run': 0, 'campaigns_started': 0}), flush=True)
        raise
    finally:
        for fd in reversed(list(directories.values())):
            os.close(fd)
        os.close(root_fd)


if __name__ == '__main__':
    main()
