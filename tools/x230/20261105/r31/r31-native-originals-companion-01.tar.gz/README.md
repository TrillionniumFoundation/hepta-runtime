# Original R31 native receipts

This companion preserves three original jobs: the failed initial preparation
(161 stdout bytes and 656 stderr bytes), the successful qualification v2
(1110 stdout bytes and no stderr), and the successful component run
(125 stdout bytes and no stderr). Native terminal `content.text` bytes are
preserved exactly, with no appended newline. Complete tool envelopes are also
retained. Every stdout/stderr byte is reconstructed from original process_read
hex bytes with contiguous offsets and checked against the final durable counts.

No job, test or benchmark was rerun to make this package. The original failed
preparation remains failed. The first actual eight-stage qualification passed
1653 tests, with 34 ignored, 0 failures and 0 retries. Its source map contains
222 inputs and the exact d92b1dba pidfd helper source; the new Rust test file is
the only input differing from the pre-format map. Whole-runtime performance,
saturated cancellation capacity and hosted CI are not established by this
package. Per-case original qualification logs belong to the separate complete
qualification archive, which this companion does not replace.

The owner exporter currently includes the native terminal objects but not the
original outer process_read streams. Publishing this companion alongside the
qualification/component archives closes that limited retention gap. It does
not claim that the native service lacked durable logs.
