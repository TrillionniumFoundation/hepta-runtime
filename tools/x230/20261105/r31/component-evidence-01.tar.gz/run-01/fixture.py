
import json, os, pathlib, select, signal, sys, time
q = json.load(sys.stdin)
job = pathlib.Path(q["job_dir"])
def atomic(name, value):
    temporary = job / (name + ".fixture-tmp")
    fd = os.open(temporary, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    with os.fdopen(fd, "w", encoding="utf-8") as stream:
        stream.write(json.dumps(value, sort_keys=True) + "\n")
        stream.flush(); os.fsync(stream.fileno())
    os.replace(temporary, job / name)
    directory = os.open(job, os.O_RDONLY | os.O_DIRECTORY)
    try: os.fsync(directory)
    finally: os.close(directory)
read_fd, write_fd = os.pipe2(os.O_NONBLOCK | os.O_CLOEXEC)
signal_count, signal_at = 0, None
def requested(signum, frame):
    global signal_count, signal_at
    signal_count += 1
    if signal_at is None: signal_at = time.monotonic_ns()
signal.signal(signal.SIGTERM, requested)
signal.set_wakeup_fd(write_fd)
pid = os.getpid()
own_stat = pathlib.Path("/proc/self/stat").read_text()
if int(own_stat.split(" ", 1)[0]) != pid:
    raise RuntimeError("fixture requires a consistent OS PID and /proc PID view")
ticks = int(own_stat.rsplit(") ", 1)[1].split()[19])
boot = pathlib.Path("/proc/sys/kernel/random/boot_id").read_text().strip()
atomic("started.json", {"job_id": q["job_id"], "launch_nonce": q["launch_nonce"],
       "supervisor_uid": os.geteuid(), "supervisor_pid": pid,
       "supervisor_identity": {"kind": "proc_start_ticks", "value": boot + ":" + str(ticks)}})
print(json.dumps({"ready": True, "pid": pid, "launch_nonce": q["launch_nonce"]}), flush=True)
poller = select.poll(); poller.register(read_fd, select.POLLIN)
deadline = time.monotonic() + 10
while signal_at is None:
    remaining = deadline - time.monotonic()
    if remaining <= 0: raise RuntimeError("fixture received no cancellation")
    poller.poll(max(1, int(remaining * 1000)))
stop_at = signal_at + q["delay_ms"] * 1_000_000
while time.monotonic_ns() < stop_at:
    time.sleep(max(0, (stop_at - time.monotonic_ns()) / 1_000_000_000))
atomic("exit.json", {"component_fixture_terminal": True, "job_id": q["job_id"],
       "launch_nonce": q["launch_nonce"], "exit_code": 0, "signal_count": signal_count,
       "signal_received_monotonic_ns": signal_at,
       "terminal_payload_created_monotonic_ns": time.monotonic_ns(), "delay_ms": q["delay_ms"]})
signal.set_wakeup_fd(-1)
os.close(read_fd); os.close(write_fd)
