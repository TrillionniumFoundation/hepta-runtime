
import os, pathlib, stat, sys
_hepta_directory_pins = []
def private_job_directory(raw, create=False):
    if not isinstance(raw, str) or not raw.startswith("/") or any(p in (".", "..") for p in raw.split("/")):
        raise SystemExit("unsafe remote job path")
    parts = [p for p in raw.split("/") if p]
    if len(parts) < 3 or parts[-2] != "jobs":
        raise SystemExit("remote job path must name a dedicated state/jobs/job directory")
    shared_access = getattr(os, "O_PATH", os.O_RDONLY) if sys.platform == "linux" else os.O_RDONLY
    path_only_shared = shared_access != os.O_RDONLY
    directory_flags = os.O_DIRECTORY | os.O_NOFOLLOW | os.O_CLOEXEC
    fd = os.open("/", shared_access | directory_flags)
    _hepta_directory_pins.append(fd)
    for offset, part in enumerate(parts):
        private = offset >= len(parts) - 3
        if create and private and not path_only_shared:
            try:
                os.mkdir(part, mode=0o700, dir_fd=fd)
                os.fsync(fd)
            except FileExistsError:
                pass
        access = os.O_RDONLY if private else shared_access
        try:
            child = os.open(part, access | directory_flags, dir_fd=fd)
        except FileNotFoundError:
            if not (create and private and path_only_shared):
                raise
            # O_PATH traverses an existing searchable ancestor without reading it.
            # A new child still needs its parent's original durability barrier:
            # acquire a readable handle before mkdir, or refuse without creating.
            sync_parent = os.open(".", os.O_RDONLY | directory_flags, dir_fd=fd)
            _hepta_directory_pins.append(sync_parent)
            pinned = os.fstat(fd)
            readable = os.fstat(sync_parent)
            if (pinned.st_dev, pinned.st_ino) != (readable.st_dev, readable.st_ino):
                raise SystemExit("remote parent directory identity changed; no directory created")
            try:
                os.mkdir(part, mode=0o700, dir_fd=sync_parent)
            except FileExistsError:
                pass
            else:
                os.fsync(sync_parent)
            child = os.open(part, os.O_RDONLY | directory_flags, dir_fd=sync_parent)
        _hepta_directory_pins.append(child)
        info = os.fstat(child)
        if private and (info.st_uid != os.geteuid() or stat.S_IMODE(info.st_mode) != 0o700):
            raise SystemExit("unsafe remote state/jobs/job directory; existing permissions are never repaired")
        fd = child
    os.fchdir(fd)
    return pathlib.Path(".")

def private_bound_job_directory(raw, expected):
    job = private_job_directory(raw)
    info = os.fstat(_hepta_directory_pins[-1])
    if (info.st_dev, info.st_ino) != (expected["device"], expected["inode"]):
        raise SystemExit("remote job directory identity changed; no workload submitted")
    return job

def private_open_job_file(name):
    try:
        fd = os.open(name, os.O_RDONLY | os.O_NOFOLLOW | os.O_CLOEXEC | os.O_NONBLOCK,
                     dir_fd=_hepta_directory_pins[-1])
    except FileNotFoundError:
        return None
    except OSError as error:
        raise SystemExit("unsafe remote job file " + name) from error
    info = os.fstat(fd)
    if (not stat.S_ISREG(info.st_mode) or info.st_nlink != 1 or
            info.st_uid != os.geteuid() or stat.S_IMODE(info.st_mode) & 0o022):
        os.close(fd)
        raise SystemExit("unsafe remote job file " + name + ": non-regular or linked inode")
    return fd

def private_read_json(name):
    import json
    fd = private_open_job_file(name)
    if fd is None: return None
    with os.fdopen(fd, "rb") as stream:
        before = os.fstat(stream.fileno())
        if before.st_size > 4 * 1024 * 1024:
            raise SystemExit("unsafe remote job file " + name + ": linked or oversized inode")
        # Size the common allocation to the fresh snapshot, not the 4 MiB cap.
        # A regular file may underreport its size; retain the original bounded
        # read in that case before the unchanged metadata and JSON checks.
        encoded = stream.read(max(0, before.st_size) + 1)
        if encoded is not None and len(encoded) > before.st_size:
            tail = stream.read(4 * 1024 * 1024 + 1 - len(encoded))
            # BufferedReader preserves an available prefix when a later raw
            # read would block. Keep that behavior without retrying the read.
            if tail is not None:
                encoded += tail
        after = os.fstat(stream.fileno())
        current = os.stat(name, dir_fd=_hepta_directory_pins[-1], follow_symlinks=False)
    def stamp(info):
        return (info.st_dev, info.st_ino, info.st_mode, info.st_uid, info.st_nlink,
                info.st_size, info.st_mtime_ns, info.st_ctime_ns)
    if len(encoded) > 4 * 1024 * 1024 or stamp(before) != stamp(after) or stamp(after) != stamp(current):
        raise SystemExit("unsafe remote job file " + name + ": changed while reading")
    try:
        value = json.loads(encoded)
        if not isinstance(value, dict): raise ValueError("not an object")
        return value
    except (ValueError, UnicodeError) as error:
        raise SystemExit("corrupt remote job file " + name) from error

