
import json, os, pathlib, signal, subprocess, sys, time
q = json.load(sys.stdin)
job = private_job_directory(q["job_dir"])

def read_json(name):
    return private_read_json(name)

def atomic(name, value):
    target = job / name
    tmp = job / (name + ".tmp")
    fd = os.open(tmp, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    with os.fdopen(fd, "w", encoding="utf-8") as stream:
        stream.write(json.dumps(value, sort_keys=True) + "\n")
        stream.flush(); os.fsync(stream.fileno())
    os.replace(tmp, target)
    fd = os.open(job, os.O_RDONLY)
    try: os.fsync(fd)
    finally: os.close(fd)

def process_identity(pid):
    if sys.platform == "linux":
        try:
            ticks = int(pathlib.Path(f"/proc/{pid}/stat").read_text().rsplit(") ", 1)[1].split()[19])
            boot = pathlib.Path("/proc/sys/kernel/random/boot_id").read_text().strip()
            return {"kind": "proc_start_ticks", "value": boot + ":" + str(ticks)} if boot else None
        except Exception:
            return None
    try:
        value = subprocess.check_output(["ps", "-p", str(pid), "-o", "lstart="], text=True, timeout=3).strip()
        return {"kind": "ps_lstart", "value": value} if value else None
    except Exception:
        return None

def valid_owner(request, started, systemd=False):
    nonce = request.get("launch_nonce")
    identity = started.get("supervisor_identity")
    return (isinstance(nonce, str) and len(nonce) == 32 and all(c in "0123456789abcdef" for c in nonce) and
        started.get("job_id") == request.get("job_id") and started.get("launch_nonce") == nonce and
        type(started.get("supervisor_uid")) is int and started["supervisor_uid"] == os.geteuid() and
        type(started.get("supervisor_pid")) is int and 1 < started["supervisor_pid"] <= 2147483647 and
        isinstance(identity, dict) and identity.get("kind") == ("proc_start_ticks" if sys.platform == "linux" else "ps_lstart") and
        isinstance(identity.get("value"), str) and bool(identity["value"]) and
        (not systemd or (isinstance(started.get("invocation_id"), str) and len(started["invocation_id"]) == 32 and
            all(c in "0123456789abcdef" for c in started["invocation_id"]))))

def process_uid(pid):
    if sys.platform == "linux": return pathlib.Path(f"/proc/{pid}").stat().st_uid
    return int(subprocess.check_output(["ps", "-p", str(pid), "-o", "uid="], text=True, timeout=3).strip())

request = read_json("request.json")
if not request or request.get("job_id") != q["job_id"]:
    raise SystemExit("remote job metadata missing or mismatched")
if read_json("exit.json"):
    print(json.dumps({"job_id": q["job_id"], "result": "already_exited"}))
    raise SystemExit(0)
launch = read_json("launch.json") or {}
started = read_json("started.json") or {}
nonce = request.get("launch_nonce")
pid = int(started.get("supervisor_pid") or 0)
expected = started.get("supervisor_identity")
expected_uid = started.get("supervisor_uid")
if not valid_owner(request, started, systemd=launch.get("backend") == "systemd"):
    raise SystemExit("frozen supervisor binding unavailable; no cancellation submitted")
# Never stop by a reusable unit name. This descriptor stays bound to the
# original supervisor even if its PID or systemd unit name is later recycled.
atomic_identity = sys.platform == "linux"
fd = None
try:
    if atomic_identity:
        if not hasattr(os, "pidfd_open") or not hasattr(signal, "pidfd_send_signal"):
            raise SystemExit("atomic supervisor signalling unavailable; no cancellation submitted")
        fd = os.pidfd_open(pid, 0)
    if process_identity(pid) != expected or process_uid(pid) != expected_uid:
        raise SystemExit("frozen supervisor identity or UID changed; no cancellation submitted")
    atomic("cancel-request.json", {"at_unix_ms": int(time.time() * 1000),
           "job_id": q["job_id"], "launch_nonce": nonce})
    if atomic_identity:
        signal.pidfd_send_signal(fd, signal.SIGTERM, None, 0)
    else:
        # macOS has no pidfd. Retain its explicitly non-atomic account scope.
        if process_identity(pid) != expected or process_uid(pid) != expected_uid:
            raise SystemExit("supervisor changed before best-effort signal")
        os.kill(pid, signal.SIGTERM)
    grace = max(0.0, min(float(q.get("grace_seconds", 10)), 30.0))
    deadline = time.monotonic() + grace
    while time.monotonic() < deadline:
        if read_json("exit.json") or process_identity(pid) != expected:
            break
        time.sleep(.1)
    # The original runner owns workload termination, escalation and output
    # drain. Never force-kill a potentially recycled child group from here.
    result = "stop_requested" if launch.get("backend") == "systemd" else "term_sent"
    print(json.dumps({"job_id":q["job_id"],"result":result,
          "atomic_identity":atomic_identity,"supervisor_pid":pid,
          "termination_confirmed":False,"reconcile_via":"process_status"}, sort_keys=True))
finally:
    if fd is not None: os.close(fd)
