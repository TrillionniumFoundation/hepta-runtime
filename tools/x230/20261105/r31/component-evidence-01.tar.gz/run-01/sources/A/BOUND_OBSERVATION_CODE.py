
import io, json
_original_query = json.load(sys.stdin)
_bound_job = private_job_directory(_original_query["job_dir"])
_bound_request = private_read_json("request.json")
_digest = _original_query.get("request_digest")
if (not isinstance(_bound_request, dict) or not isinstance(_digest, str) or len(_digest) != 64 or
        any(c not in "0123456789abcdef" for c in _digest) or
        _bound_request.get("job_id") != _original_query.get("job_id") or
        _bound_request.get("job_dir") != _original_query.get("job_dir") or
        _bound_request.get("unit") != _original_query.get("unit") or
        _bound_request.get("request_digest", _bound_request.get("request_fingerprint")) != _digest):
    raise SystemExit("remote job request binding missing or mismatched")
# Metadata is validated before a status can claim success or cancellation can
# acknowledge a terminal receipt. The status owner interprets a torn private
# started.json as unknown, and a confirmed terminal receipt takes precedence.
# Cancellation still validates its owner record before sending any signal.
for _name in ("launch.json", "exit.json"):
    private_read_json(_name)
sys.stdin = io.StringIO(json.dumps(_original_query))
