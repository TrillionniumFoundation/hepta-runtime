#!/usr/bin/env python3
"""Compare the unmodified R24 and draft cancellation helpers on owned children.

This is a Linux Python-helper component experiment, not runtime qualification.
It uses no SSH, Rust executable, systemd unit, existing job, or workload group.
The private-directory and request-owner helpers come directly from each jobs.rs.
"""

import argparse
import ast
import hashlib
import json
import math
import os
from pathlib import Path
import platform
import re
import secrets
import select
import signal
import statistics
import subprocess
import sys
import time
import traceback


ROOT = Path(__file__).resolve().parent
CONSTANTS = ("PRIVATE_DIRECTORY_CODE", "BOUND_OBSERVATION_CODE", "CANCEL_CODE")
DELAYS_MS = (5, 25, 65)
ORDER = "ABBA"
TIMEOUT = 5
FIXTURE = r'''
import json, os, pathlib, select, signal, sys, time
q = json.load(sys.stdin)
job = pathlib.Path(q["job_dir"])
def atomic(name, value):
    temporary = job / (name + ".fixture-tmp")
    fd = os.open(temporary, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    with os.fdopen(fd, "w", encoding="utf-8") as stream:
        stream.write(json.dumps(value, sort_keys=True) + "\n")
        stream.flush(); os.fsync(stream.fileno())
    os.replace(temporary, job / name)
    directory = os.open(job, os.O_RDONLY | os.O_DIRECTORY)
    try: os.fsync(directory)
    finally: os.close(directory)
read_fd, write_fd = os.pipe2(os.O_NONBLOCK | os.O_CLOEXEC)
signal_count, signal_at = 0, None
def requested(signum, frame):
    global signal_count, signal_at
    signal_count += 1
    if signal_at is None: signal_at = time.monotonic_ns()
signal.signal(signal.SIGTERM, requested)
signal.set_wakeup_fd(write_fd)
pid = os.getpid()
own_stat = pathlib.Path("/proc/self/stat").read_text()
if int(own_stat.split(" ", 1)[0]) != pid:
    raise RuntimeError("fixture requires a consistent OS PID and /proc PID view")
ticks = int(own_stat.rsplit(") ", 1)[1].split()[19])
boot = pathlib.Path("/proc/sys/kernel/random/boot_id").read_text().strip()
atomic("started.json", {"job_id": q["job_id"], "launch_nonce": q["launch_nonce"],
       "supervisor_uid": os.geteuid(), "supervisor_pid": pid,
       "supervisor_identity": {"kind": "proc_start_ticks", "value": boot + ":" + str(ticks)}})
print(json.dumps({"ready": True, "pid": pid, "launch_nonce": q["launch_nonce"]}), flush=True)
poller = select.poll(); poller.register(read_fd, select.POLLIN)
deadline = time.monotonic() + 10
while signal_at is None:
    remaining = deadline - time.monotonic()
    if remaining <= 0: raise RuntimeError("fixture received no cancellation")
    poller.poll(max(1, int(remaining * 1000)))
stop_at = signal_at + q["delay_ms"] * 1_000_000
while time.monotonic_ns() < stop_at:
    time.sleep(max(0, (stop_at - time.monotonic_ns()) / 1_000_000_000))
atomic("exit.json", {"component_fixture_terminal": True, "job_id": q["job_id"],
       "launch_nonce": q["launch_nonce"], "exit_code": 0, "signal_count": signal_count,
       "signal_received_monotonic_ns": signal_at,
       "terminal_payload_created_monotonic_ns": time.monotonic_ns(), "delay_ms": q["delay_ms"]})
signal.set_wakeup_fd(-1)
os.close(read_fd); os.close(write_fd)
'''


def write(path, data):
    with path.open("xb") as stream:
        os.fchmod(stream.fileno(), 0o600)
        stream.write(data if isinstance(data, bytes) else data.encode())


def write_json(path, value):
    write(path, json.dumps(value, indent=2, sort_keys=True) + "\n")


def sha(data):
    return hashlib.sha256(data).hexdigest()


def extract(source, destination):
    raw = source.read_bytes()
    content = raw.decode("utf-8")
    destination.mkdir(mode=0o700)
    write(destination / "jobs.rs", raw)
    bodies, metadata = {}, {"source_path": str(source), "jobs_bytes": len(raw), "jobs_sha256": sha(raw)}
    for name in CONSTANTS:
        matches = re.findall(r'const ' + name + r': &str = r#"(.*?)"#;', content, re.S)
        if len(matches) != 1:
            raise ValueError(f"expected one raw-string {name} in {source}")
        bodies[name] = matches[0]
    helper = ("REMOTE_DIRECTORY_SOURCE = " + json.dumps(bodies[CONSTANTS[0]])
              + "\nexec(REMOTE_DIRECTORY_SOURCE)\n" + bodies[CONSTANTS[1]]
              + "\n" + bodies[CONSTANTS[2]])
    for name, body in {**bodies, "assembled_helper": helper}.items():
        parsed = ast.dump(ast.parse(body), annotate_fields=True, include_attributes=False, indent=2) + "\n"
        write(destination / (name + ".py"), body)
        write(destination / (name + ".ast.txt"), parsed)
        metadata[name] = {"bytes": len(body.encode()), "sha256": sha(body.encode()),
                          "ast_sha256": sha(parsed.encode())}
    return helper, bodies, metadata


def ready_line(child):
    poller = select.poll()
    poller.register(child.stdout, select.POLLIN | select.POLLHUP)
    deadline, received = time.monotonic() + TIMEOUT, b""
    while b"\n" not in received and len(received) < 4096:
        remaining = deadline - time.monotonic()
        if remaining <= 0 or not poller.poll(math.ceil(remaining * 1000)):
            raise TimeoutError("fixture readiness timed out")
        data = os.read(child.stdout.fileno(), 4096 - len(received))
        if not data:
            raise RuntimeError("fixture ended before readiness")
        received += data
    if not received.endswith(b"\n"):
        raise RuntimeError("invalid fixture readiness record")
    return received


def cleanup(child):
    if child is None:
        return None
    killed = child.poll() is None
    try:
        if killed:
            child.kill()
        child.wait(timeout=TIMEOUT)
        return {"pid": child.pid, "returncode": child.returncode, "killed_by_cleanup": killed, "reaped": True}
    except BaseException:
        return {"pid": child.pid, "returncode": child.returncode, "killed_by_cleanup": killed,
                "reaped": False, "error": traceback.format_exc()}


def exercise(case, helper, out):
    name = f"s{case['index']:04d}-{case['arm']}-{case['phase']}-d{case['delay_ms']:03d}"
    directory, job = out / "samples" / name, out / "state" / "jobs" / name
    directory.mkdir(mode=0o700); job.mkdir(mode=0o700)
    nonce = secrets.token_hex(16)
    request = {"job_id": name, "job_dir": str(job), "unit": "hepta-runtime-" + name,
               "request_digest": secrets.token_hex(32), "launch_nonce": nonce}
    query = {**request, "grace_seconds": 1.0}
    write_json(job / "request.json", request)
    write_json(job / "launch.json", {"backend": "detached", "component_fixture": True})
    write_json(directory / "query.json", query)
    fixture, runner = None, None
    record = {**case, "job_id": name, "job_dir": str(job), "launch_nonce": nonce,
              "sample_directory": str(directory), "passed": False}
    stdout, stderr, fixture_stdout, fixture_stderr = b"", b"", b"", b""
    broken_write = None
    try:
        fixture = subprocess.Popen([sys.executable, "-I", "-S", "-c", FIXTURE],
                                   stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        fixture.stdin.write(json.dumps({**request, "delay_ms": case["delay_ms"]}).encode())
        fixture.stdin.close(); fixture.stdin = None
        fixture_stdout = ready_line(fixture)
        ready = json.loads(fixture_stdout)
        assert ready == {"ready": True, "pid": fixture.pid, "launch_nonce": nonce}
        lost_ack = case["phase"] == "lost_ack"
        if lost_ack:
            broken_read, broken_write = os.pipe()
            os.close(broken_read)
        start = time.monotonic_ns()
        runner = subprocess.Popen([sys.executable, "-c", helper], stdin=subprocess.PIPE,
                                  stdout=broken_write if lost_ack else subprocess.PIPE,
                                  stderr=subprocess.PIPE, cwd=directory)
        if broken_write is not None:
            os.close(broken_write); broken_write = None
        stdout, stderr = runner.communicate(json.dumps(query).encode(), timeout=TIMEOUT)
        finish = time.monotonic_ns()
        record.update(helper_start_monotonic_ns=start, helper_return_monotonic_ns=finish,
                      full_helper_ms=(finish - start) / 1_000_000, helper_returncode=runner.returncode)
        if lost_ack:
            assert runner.returncode != 0 and b"BrokenPipeError" in stderr, (runner.returncode, stderr)
            record["ack"] = None
        else:
            assert runner.returncode == 0 and not stderr, (runner.returncode, stderr)
            ack = json.loads(stdout)
            assert ack == {"job_id": name, "result": "term_sent", "atomic_identity": True,
                           "supervisor_pid": fixture.pid, "termination_confirmed": False,
                           "reconcile_via": "process_status"}, ack
            record["ack"] = ack
        extra_stdout, fixture_stderr = fixture.communicate(timeout=TIMEOUT)
        fixture_stdout += extra_stdout
        assert fixture.returncode == 0 and not fixture_stderr, (fixture.returncode, fixture_stderr)
        terminal = json.loads((job / "exit.json").read_bytes())
        cancel = json.loads((job / "cancel-request.json").read_bytes())
        assert terminal["component_fixture_terminal"] is True and terminal["exit_code"] == 0
        assert terminal["job_id"] == name and terminal["launch_nonce"] == nonce
        assert terminal["signal_count"] == 1 and terminal["delay_ms"] == case["delay_ms"]
        assert cancel["job_id"] == name and cancel["launch_nonce"] == nonce
        assert start <= terminal["signal_received_monotonic_ns"] <= terminal["terminal_payload_created_monotonic_ns"] <= finish
        record.update(signal_to_helper_return_ms=(finish - terminal["signal_received_monotonic_ns"]) / 1_000_000,
                      terminal_payload_created_to_helper_return_ms=(finish - terminal["terminal_payload_created_monotonic_ns"]) / 1_000_000,
                      actual_delay_to_terminal_payload_ms=(terminal["terminal_payload_created_monotonic_ns"] - terminal["signal_received_monotonic_ns"]) / 1_000_000,
                      passed=True)
    except BaseException as error:
        if isinstance(error, subprocess.TimeoutExpired):
            if runner is not None and error.cmd == runner.args:
                stdout, stderr = error.output or b"", error.stderr or b""
            else:
                fixture_stdout += error.output or b""
                fixture_stderr = error.stderr or b""
        record["error"] = traceback.format_exc()
    finally:
        if broken_write is not None:
            os.close(broken_write)
        record["helper_cleanup"] = cleanup(runner)
        record["fixture_cleanup"] = cleanup(fixture)
        if any(item and not item["reaped"] for item in (record["helper_cleanup"], record["fixture_cleanup"])):
            record["passed"] = False
        if record["helper_cleanup"] and record["helper_cleanup"]["reaped"] and runner.stdout is not None and not runner.stdout.closed:
            stdout = (stdout or b"") + runner.stdout.read()
        if record["helper_cleanup"] and record["helper_cleanup"]["reaped"] and runner.stderr is not None and not runner.stderr.closed:
            stderr += runner.stderr.read()
        if record["fixture_cleanup"] and record["fixture_cleanup"]["reaped"] and fixture.stdout is not None and not fixture.stdout.closed:
            fixture_stdout += fixture.stdout.read()
        if record["fixture_cleanup"] and record["fixture_cleanup"]["reaped"] and fixture.stderr is not None and not fixture.stderr.closed:
            fixture_stderr += fixture.stderr.read()
        for filename, value in (("helper.stdout", stdout or b""), ("helper.stderr", stderr),
                                ("fixture.stdout", fixture_stdout), ("fixture.stderr", fixture_stderr)):
            write(directory / filename, value)
        write_json(directory / "result.json", record)
    return record


def describe(values):
    ordered = sorted(values)
    return {"n": len(values), "min": ordered[0], "median": statistics.median(values),
            "mean": statistics.mean(values), "p95": ordered[math.ceil(len(values) * .95) - 1],
            "p99": ordered[math.ceil(len(values) * .99) - 1], "max": ordered[-1]}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--baseline-jobs", type=Path, default=ROOT.parent / "src/mcp/runtime/jobs.rs")
    parser.add_argument("--candidate-jobs", type=Path, default=ROOT / "src/mcp/runtime/jobs.rs")
    parser.add_argument("--output", type=Path, required=True, help="new directory; never reused")
    parser.add_argument("--blocks", type=int, default=4, help="measured ABBA blocks per delay (default 4)")
    args = parser.parse_args()
    if sys.platform != "linux" or not hasattr(os, "pidfd_open") or not hasattr(signal, "pidfd_send_signal"):
        parser.error("Linux with Python pidfd_open and pidfd_send_signal is required")
    if sys.flags.optimize:
        parser.error("run without Python -O: the experiment uses assertion checks")
    if not 1 <= args.blocks <= 20:
        parser.error("--blocks must be between 1 and 20")
    os.umask(0o077)
    out = args.output.resolve()
    out.mkdir(mode=0o700)
    for relative in ("sources", "samples", "state", "state/jobs"):
        (out / relative).mkdir(mode=0o700)
    helpers, bodies, sources = {}, {}, {}
    for arm, path in (("A", args.baseline_jobs), ("B", args.candidate_jobs)):
        helpers[arm], bodies[arm], sources[arm] = extract(path.resolve(), out / "sources" / arm)
    assert all(bodies["A"][name] == bodies["B"][name] for name in CONSTANTS[:2]), "owner helpers differ"
    write(out / "fixture.py", FIXTURE)
    script = Path(__file__).read_bytes()
    write(out / "benchmark_cancel_wait.py", script)
    plan = []
    for phase, blocks in (("warmup", 1), ("measured", args.blocks)):
        for block in range(blocks):
            for delay in DELAYS_MS:
                for position, arm in enumerate(ORDER):
                    plan.append({"index": len(plan), "phase": phase, "block": block,
                                 "position": position, "arm": arm, "delay_ms": delay})
    for arm in "AB":
        plan.append({"index": len(plan), "phase": "lost_ack", "arm": arm, "delay_ms": 25})
    pid_view = {"os_getpid": os.getpid(),
                "proc_self_pid": int(Path("/proc/self/stat").read_text().split(" ", 1)[0])}
    write_json(out / "manifest.json", {"scope": "owned Linux Python-helper component only; no runtime adoption claim",
               "created_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
               "platform": platform.platform(), "hostname": platform.node(), "uname": list(os.uname()),
               "python": sys.version, "executable": sys.executable, "logical_cpu_count": os.cpu_count(),
               "pid_view": pid_view,
               "script_sha256": sha(script), "fixture_sha256": sha(FIXTURE.encode()), "sources": sources,
               "helper_invocation": [sys.executable, "-c", "<unmodified assembled helper>"],
               "grace_seconds": 1.0, "timeout_seconds": TIMEOUT, "plan": plan,
               "percentiles": "nearest rank; small samples are descriptive only",
               "fixture_terminal": "isolated fixture receipt, not real workload termination proof",
               "notes": "Full helper includes interpreter startup, real metadata/fsync, signal, wait, stdout and process drain. No wait instrumentation."})
    if pid_view["os_getpid"] != pid_view["proc_self_pid"]:
        summary = {"passed": False, "samples_planned": len(plan), "samples_completed": 0,
                   "not_run_reason": "OS PID and /proc PID views differ; unchanged helpers require consistent process identity",
                   "pid_view": pid_view, "all_owned_children_reaped": True, "cleanup_kills": 0}
        write_json(out / "summary.json", summary)
        print(json.dumps({**summary, "output": str(out)}))
        return 2
    records = []
    with (out / "raw-samples.jsonl").open("x") as stream:
        for case in plan:
            record = exercise(case, helpers[case["arm"]], out)
            records.append(record)
            stream.write(json.dumps(record, sort_keys=True) + "\n"); stream.flush(); os.fsync(stream.fileno())
            if not record["passed"]:
                break
    completed_checks = []
    if all(record["passed"] for record in records):
        for arm in "AB":
            record = next(row for row in records if row["arm"] == arm)
            directory, job = Path(record["sample_directory"]), Path(record["job_dir"])
            control = {"arm": arm, "job_id": record["job_id"], "passed": False}
            stdout, stderr = b"", b""
            try:
                before = (job / "cancel-request.json").read_bytes()
                # subprocess.run kills and waits its child on timeout or exception.
                result = subprocess.run([sys.executable, "-c", helpers[arm]],
                                        input=(directory / "query.json").read_bytes(), capture_output=True,
                                        cwd=directory, timeout=TIMEOUT)
                stdout, stderr = result.stdout, result.stderr
                unchanged = (job / "cancel-request.json").read_bytes() == before
                control.update(returncode=result.returncode, cancel_receipt_unchanged=unchanged)
                control["passed"] = (result.returncode == 0 and not stderr and unchanged
                                     and json.loads(stdout) == {"job_id": record["job_id"], "result": "already_exited"})
            except BaseException as error:
                if isinstance(error, subprocess.TimeoutExpired):
                    stdout, stderr = error.output or b"", error.stderr or b""
                control["error"] = traceback.format_exc()
            write(directory / "completed-control.stdout", stdout)
            write(directory / "completed-control.stderr", stderr)
            write_json(directory / "completed-control.json", control)
            completed_checks.append(control)
            if not control["passed"]:
                break
    metrics = ("full_helper_ms", "signal_to_helper_return_ms", "terminal_payload_created_to_helper_return_ms")
    groups = {}
    for delay in DELAYS_MS:
        for arm in "AB":
            values = [row for row in records if row["phase"] == "measured" and row["passed"]
                      and row["arm"] == arm and row["delay_ms"] == delay]
            if values:
                groups[f"{arm}-delay-{delay}ms"] = {key: describe([row[key] for row in values]) for key in metrics}
    passed = len(records) == len(plan) and all(row["passed"] for row in records) and len(completed_checks) == 2 and all(row["passed"] for row in completed_checks)
    summary = {"passed": passed, "scope": "local Linux Python-helper component; not x230 or whole-runtime performance evidence by itself",
               "samples_planned": len(plan), "samples_completed": len(records), "measured_samples": sum(row["phase"] == "measured" for row in records),
               "lost_ack_controls": [row["passed"] for row in records if row["phase"] == "lost_ack"],
               "already_exited_controls": completed_checks, "all_owned_children_reaped": all(item is None or item["reaped"] for row in records for item in (row["fixture_cleanup"], row["helper_cleanup"])),
               "cleanup_kills": sum(bool(row["fixture_cleanup"] and row["fixture_cleanup"]["killed_by_cleanup"]) + bool(row["helper_cleanup"] and row["helper_cleanup"]["killed_by_cleanup"]) for row in records),
               "distributions_ms": groups}
    write_json(out / "summary.json", summary)
    print(json.dumps({"passed": passed, "output": str(out), "samples": len(records), "cleanup_kills": summary["cleanup_kills"]}))
    return 0 if passed else 1


if __name__ == "__main__":
    raise SystemExit(main())
