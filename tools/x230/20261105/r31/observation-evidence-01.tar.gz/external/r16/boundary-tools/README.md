# Native C32 boundary and recovery diagnostic

Use one already qualified binary, explicit arena1 and workers2, the frozen six
completed jobs, their exact historical profile and the frozen topology manifest.
No new job starts, cancellation, remote cleanup, production service mutation or
automatic RPC retry is part of this diagnostic.

The first private controller performs six complete-output preflight reads and a
balanced C8 warmup of 24 calls. It then runs two separately planned C32 bursts.
Each burst uses a 32-party client barrier; stdio writes remain serialized by the
unchanged Controller. Every attempt retains its gate, RPC and response clocks.
The diagnostic waits for all complete responses and an empty client pending map,
then requires balanced C1 and C8 cells of 24 status/read calls each. A missing
response stops further probes. After both bursts, normal controller shutdown and
restart must preserve all original identities and terminal output. There are
202 planned tool calls and two initialize responses with the default two bursts.

Client in-flight requests are not native observation-pool admission identities:
validation may queue requests before they reach the pool. There is no required
number of rejections. All 32 succeeding is a valid observed result, and cannot
be described as proof that pool capacity exceeds 16. The independent analysis
reports the actual client pending peak, serialized-send span and whether all
RPCs began before the first response, while leaving pool-identity peak unknown.

## Error contract

Each burst row is classified as validated success, exact capacity rejection or
other error. Only success contributes to successful throughput. Rejection and
other-error rates and p50/p95/p99/max latency are separate; empty groups have no
invented latency. CPU is reported per attempted request and is not attributed to
outcome classes. Unknown errors make the diagnostic fail even when all raw
evidence and subsequent recovery are valid.

`capacity-policy.json` pins the narrow accepted rendering and its source basis.
The project handlers propagate the pool error as `Result<String,String>`.
The exact installed rmcp 3.4.1 source converts String to one text content block
and sets the tool-result `is_error` field for the Err branch. The three inspected
dependency files are hashed in the policy. The crates.io package checksum from
Cargo.lock is recorded as an expected identity; the archive is absent locally,
so it is explicitly **not** claimed to have been reverified. Prefixes, suffixes,
multiple content blocks, JSON-RPC errors and unverified error policies are not
accepted by substring matching. Unexpected wrapping remains an other error.

## Reproduce only after the parent authorizes the measurement window

Use the held authenticated foreground SSH-agent route. The output must not
exist; the socket parent must already satisfy the frozen private 0700 directory
contract. Replace the binary path with the exact selected qualification artifact.

```sh
python3 -B /home/qian/hepta-runtime-optimization-20261104-r16/boundary-tools/run_native_boundary.py \
  --binary /absolute/path/to/qualified/hepta-runtime \
  --profile-template /home/qian/hepta-runtime-optimization-20261023/r11-native-observation-abba-20261103-02/profile/profile.json \
  --topology /home/qian/hepta-runtime-optimization-20261104-r16/benchmark-topology.json \
  --frozen-jobs /home/qian/hepta-runtime-optimization-20261023/a31-frozen-originals-r01 \
  --socket-parent /home/qian/h16b1 \
  --out /home/qian/hepta-runtime-optimization-20261104-r16/native-boundary-01 \
  --bursts 2

python3 -B /home/qian/hepta-runtime-optimization-20261104-r16/boundary-tools/audit_native_boundary.py \
  --report /home/qian/hepta-runtime-optimization-20261104-r16/native-boundary-01/report.json \
  --output /home/qian/hepta-runtime-optimization-20261104-r16/native-boundary-01/independent-summary.json
```

The auditor reuses the frozen transport, successful DTO, raw clock/CPU, allocator
and resource validators, and independently adds failure-envelope, gate, drain,
grouped-latency and recovery checks. It rehashes every retained response frame.
`evidence_verified` and `diagnostic_passed` are separate: a fully evidenced
unknown error must not become a passed diagnostic. Both controller generations
have an actual selected `/proc/PID/environ` worker2 observation; allocator1 uses
the frozen live allocator observation. Resource sampling remains incomplete,
keeps all missing observations, and separates controller from SSH descendants.

## Preparation selftest

```sh
python3 -B /home/qian/hepta-runtime-optimization-20261104-r16/boundary-tools/test_native_boundary.py
```

Only Python fake-MCP peers run. One case supplies mixed success, capacity and
unrecognized errors; another lets every burst request succeed. Both execute the
complete burst/drain/C1/C8/normal-restart path and re-audit every fake wire frame.
They prove strict classification and tamper rejection without an SSH connection
or a HeptaRuntime process. The preparation is accepted only with zero skips on
X230; environments denying child `/proc/environ` report that limitation.
