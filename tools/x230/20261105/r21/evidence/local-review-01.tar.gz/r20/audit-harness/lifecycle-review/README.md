# R20 bounded lifecycle ABBA

The frozen source bundle is `../lifecycle-tools`. Its manifest is
`lifecycle-tools-manifest-01.json` (2,582 bytes), SHA256
`1418eae54d13ce0907926615927b7cb51fae38f4f1329aad4b4ae14040dcf9bb`.
It binds 17 files; the manifest is the eighteenth installed file.

## Invocation and output

The unified campaign invokes this once, after fresh qualification and its native
observation and C32 stages. It supplies the actual qualified R20 runtime hash.
No workload has been run while preparing these tools.

```sh
/usr/bin/python3 -B /home/qian/hepta-runtime-optimization-20261105-r20/lifecycle-tools/run_lifecycle_abba_01.py \
  --baseline /home/qian/hepta-runtime-optimization-20261104-r19/qualification-02/hepta-runtime \
  --candidate /home/qian/hepta-runtime-optimization-20261105-r20/qualification-01/hepta-runtime \
  --expected-baseline-sha256 adab5f27f89b3cac6adaec916110a48d80697db9667e3bd7ee0fc713fe770a09 \
  --expected-candidate-sha256 ACTUAL_R20_QUALIFIED_RUNTIME_SHA256 \
  --profile-template /home/qian/hepta-runtime-optimization-20261023/r11-native-observation-abba-20261103-02/profile/profile.json \
  --topology /home/qian/hepta-runtime-optimization-20261104-r16/benchmark-topology.json \
  --frozen-jobs /home/qian/hepta-runtime-optimization-20261023/a31-frozen-originals-r01 \
  --out /home/qian/hepta-runtime-optimization-20261105-r20/lifecycle-abba-01 \
  --socket-prefix /home/qian/h20lc1 \
  --expected-tools-manifest-sha256 1418eae54d13ce0907926615927b7cb51fae38f4f1329aad4b4ae14040dcf9bb \
  --workers 2 --arena-max 1
```

The socket prefix is an absent name, not a directory the caller creates. The
helper checks all four derived names before the first workload and creates each
private `h20lc1-{0-A,1-B,2-B,3-A}` directory when its round starts.

All workload output is under the new R20 `lifecycle-abba-01`. Its control
`report.json` contains nine sequential child stages: four canary/auditor pairs,
then the aggregate. Every stage records argv, PID, Linux start ticks, complete
stdout/stderr identities, exit, wait/reap, owned process-group absence and errors.
The immutable `round-index.json` binds four complete original round reports,
four original independent audits, and 44 new phase sidecars. The final
`summary.json` binds that index without a cyclic report hash.

Four rounds mean one ABBA sequence: 24 new starts, 48 same-key lookups and 48
cancellations. Total observation calls are counted from raw records because the
original bounded confirmation loops may add calls. No maximum launch rate or
maximum sustainable concurrency is claimed.

## Source preservation and compatibility

The original twelve measurement tools are byte-exact copies of the accepted R19
archive. `run_six_host_cancel_recovery_timed.py` changes only the `DEV_ROOT`
constant and the nested `parallel` function. `source-delta.json` and
`instrumentation.patch` describe those edits. Replacing these two regions back
reconstructs the original bytes; the original executor/future/checkpoint/error
handling statements also have exactly equal Python ASTs inside the new timing
`try` block. The small workload, six host routes, deadlines, private SSH master
interruption, owned-controller crash, cancellation, restart and cleanup remain
the original operations.

The old report schema stays `hepta-six-host-cancel-recovery/v2`. Sidecars are
written after each measured interval, so the original in-phase report checkpoint
payload stays unchanged. `verify_cancel_recovery.py` is byte-exact and accepts
the original report plus raw transport/resource/SSH/state evidence; it does not
assume there are no additional sidecars. It runs exactly once per round.

## Raw metric meaning

Each phase sidecar stores both monotonic endpoints, realtime endpoints,
operation-sequence bounds, complete before/after raw `/proc/PID/stat` records,
the active Controller PID/start-ticks/directory and any capture error.

| Phase | Active Controller generation |
| --- | --- |
| prepare | None; CPU is null |
| launch, before_crash_running, after_transport_running | first-controller |
| after_crash_running, same_key_after_crash, concurrent_cancel, terminal | after-crash-controller |
| terminal_after_restart, same_key_after_cancel, cancel_after_terminal | after-cancel-controller |

The first CPU sample completes before the entire six-host phase starts; the last
sample begins after the phase ends. The aggregate independently parses each raw
stat line, checks the same PID/start ticks against the original startup, checks
all native calls fit in the phase interval, checks the global operation sequence
has no gap or duplicate, and recomputes `(utime + stime) / clock_ticks` deltas.
CPU belongs only to that Controller process. It excludes SSH children and remote
workers. Wall time includes original confirmation loops and independent SSH
inspections, so it is whole lifecycle-phase throughput, not a pure RPC service
time. Original sampled resource traces remain available; no new memory estimator
is introduced.

The aggregate reports each raw-derived round value, the A and B arithmetic means
and adjacent B/A ratios. Two samples per arm are descriptive; the aggregate
does not decide adoption or claim statistical confidence.

## Validation and failure limits

`local-arithmetic-check-01.json` (SHA256
`25dec023ed20ed1d94a69b1747427e7ce178335a36c1192084339e08a8342c36`)
records nine passing local checks. These use synthetic raw counters and sequence
rows only, including rejection of PID mismatch and a CPU window that fails to
cover the phase. They are not hardware or workload measurements. All 15 Python
files parse successfully. No canary main, SSH call or remote job was run.

Normal completion requires all original audits, all sidecars, final input/tool
stability and owned child/group absence. A timeout first signals only the owned
stage session with SIGINT so the original canary may execute its cleanup, then
uses bounded TERM/KILL escalation. A failed timeout can leave independently
sessioned Controllers or an uncertain remote effect; the report does not claim
otherwise. Such a run stops, retains all raw output, and is never automatically
retried. The parent still owns its held-agent cleanup and campaign-wide final
verification. The original remote workload timeout remains 240 seconds.
