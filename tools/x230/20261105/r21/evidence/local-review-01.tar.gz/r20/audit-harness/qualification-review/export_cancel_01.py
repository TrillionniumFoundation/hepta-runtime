#!/usr/bin/env python3
# Copyright 2026 TrillionniumFoundation; SPDX-License-Identifier: Apache-2.0
"""Export one closed CANCEL probe plus its exact inputs; never run a workload."""
import gzip
import hashlib
import io
import json
import os
from pathlib import Path
import stat
import tarfile

ROOT = Path('/home/qian/hepta-runtime-optimization-20261105-r20')
SOURCE = ROOT / 'cancelprocess-probe-01'
OUT = ROOT / 'export-cancel-01'
REPORTS = {
    'semantics.json': 'a2ae38a6ca341a5691b106866fdafadb24221d959c1f914e608adc67ec8ce8f0',
    'abba.json': '75f332197907803ed9099caaeb5101092dfae63441a619a4ce9d4764f8b53929',
    'screen.json': '8fc41fa2f8f79c50f9a6875385f3798008ee057804876acf89a62805eb2d1dd8',
}
EXTRAS = {
    'baseline-jobs.rs': (ROOT / 'source/src/mcp/runtime/jobs.rs', '2f751c09a9a29bebb0cda0a9bd2bb522d145ee8183740ed1442d77666ee44aa7'),
    'candidate-jobs.rs': (ROOT / 'cancel-candidate-01/jobs.rs', '1f1f086e3bc0fc62184ed51949964e1f82e337b87d330225097ae38722e4ac8c'),
    'cancelprocess_probe_01.py': (ROOT / 'cancel-tools-01/cancelprocess_probe_01.py', 'ae5d82307c4ab36ff6b37e76deeaf0b71259f8c852ac4a2e8ae333a111731daa'),
    'measurement-plan-01.json': (ROOT / 'cancel-tools-01/measurement-plan-01.json', 'a44c750c4b0efc67123b02085194628062884be72d40c0830e6fe85e201c8c96'),
}


def need(value, reason):
    if not value:
        raise ValueError(reason)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def stamp(info):
    return tuple(getattr(info, key) for key in ('st_dev', 'st_ino', 'st_mode', 'st_uid',
                 'st_nlink', 'st_size', 'st_mtime_ns', 'st_ctime_ns'))


def read(path):
    need(path.resolve() == path, 'noncanonical input: ' + str(path))
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_CLOEXEC)
    try:
        before = os.fstat(fd)
        need(stat.S_ISREG(before.st_mode) and before.st_nlink == 1 and before.st_uid == os.geteuid()
             and before.st_size <= 128 * 1024 * 1024, 'unsafe/oversize input: ' + str(path))
        with os.fdopen(os.dup(fd), 'rb') as stream:
            data = stream.read(128 * 1024 * 1024 + 1)
        need(len(data) == before.st_size and stamp(before) == stamp(os.fstat(fd)) == stamp(path.lstat()),
             'input changed while reading: ' + str(path))
        return data, stat.S_IMODE(before.st_mode)
    finally:
        os.close(fd)


def enumerate_files():
    need(SOURCE.resolve() == SOURCE and SOURCE.is_dir(), 'probe root is not canonical')
    files = []
    for path in sorted(SOURCE.rglob('*')):
        need(not path.is_symlink(), 'symlink in probe tree')
        mode = path.lstat().st_mode
        if stat.S_ISDIR(mode):
            continue
        need(stat.S_ISREG(mode), 'special file in probe tree')
        files.append(('cancel/' + path.relative_to(SOURCE).as_posix(), path))
    files.extend((name, item[0]) for name, item in EXTRAS.items())
    need(len({name for name, path in files}) == len(files), 'duplicate member')
    return sorted(files)


def main():
    os.umask(0o077)
    OUT.mkdir(mode=0o700, exist_ok=False)
    result = {'schema': 'hepta-r20-cancel-archive/v1', 'passed': False,
              'exporter_sha256': sha(read(Path(__file__).resolve())[0]),
              'expected_report_sha256': REPORTS, 'workloads_started': False,
              'original_files_modified': False, 'automatic_retries': 0}
    try:
        documents = {}
        for name, expected in REPORTS.items():
            raw, _ = read(SOURCE / name)
            need(sha(raw) == expected, 'original report identity differs: ' + name)
            documents[name] = json.loads(raw)
        need(documents['semantics.json']['passed'] is True
             and documents['abba.json']['completed'] is True
             and documents['abba.json']['benchmark_performed'] is True
             and documents['screen.json']['assessed'] is True, 'original campaign not closed/assessed')
        for name, (path, expected) in EXTRAS.items():
            need(sha(read(path)[0]) == expected, 'source/tool/plan identity differs: ' + name)
        files = enumerate_files()
        manifest = {'schema': 'hepta-r20-cancel-export/v1', 'files': [],
                    'expected_report_sha256': REPORTS, 'exporter_sha256': result['exporter_sha256']}
        for name, path in files:
            raw, mode = read(path)
            manifest['files'].append({'path': name, 'original_path': str(path), 'size': len(raw),
                                      'sha256': sha(raw), 'mode': mode})
        manifest_raw = (json.dumps(manifest, sort_keys=True, indent=2) + '\n').encode()
        archive = OUT / 'cancelprocess.tar.gz'
        with archive.open('xb') as raw_archive, gzip.GzipFile(filename='', mode='wb', fileobj=raw_archive, mtime=0) as zipped:
            with tarfile.open(mode='w|', fileobj=zipped, format=tarfile.PAX_FORMAT) as tar:
                for row in manifest['files']:
                    raw, mode = read(Path(row['original_path']))
                    need(len(raw) == row['size'] and sha(raw) == row['sha256'] and mode == row['mode'],
                         'member changed before archive')
                    item = tarfile.TarInfo(row['path'])
                    item.size, item.mode, item.mtime = len(raw), mode, 0
                    tar.addfile(item, io.BytesIO(raw))
                item = tarfile.TarInfo('_export-manifest.json')
                item.size, item.mode, item.mtime = len(manifest_raw), 0o600, 0
                tar.addfile(item, io.BytesIO(manifest_raw))
        need(enumerate_files() == files, 'probe file set changed')
        for row in manifest['files']:
            raw, mode = read(Path(row['original_path']))
            need(len(raw) == row['size'] and sha(raw) == row['sha256'] and mode == row['mode'],
                 'original member changed after archive')
        with (OUT / 'manifest.json').open('xb') as stream:
            stream.write(manifest_raw)
        raw, _ = read(archive)
        result.update(passed=True, archive=str(archive), size=len(raw), sha256=sha(raw),
                      manifest=str(OUT / 'manifest.json'), manifest_size=len(manifest_raw),
                      manifest_sha256=sha(manifest_raw), files=len(files), archive_members=len(files) + 1,
                      file_set_before_after_equal=True, all_input_bytes_unchanged=True,
                      original_screen_passed=documents['screen.json']['passed'])
    except BaseException as error:
        result['error'] = {'type': type(error).__name__, 'reason': str(error)}
    with (OUT / 'receipt.json').open('x') as stream:
        json.dump(result, stream, sort_keys=True, indent=2)
        stream.write('\n')
    print(json.dumps(result), flush=True)
    return 0 if result['passed'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
