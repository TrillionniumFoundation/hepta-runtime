#!/usr/bin/env python3
"""Assemble pinned transport chunks, then verify and safely extract CANCEL raw evidence."""
import datetime
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import tarfile

BASE = Path(__file__).resolve().parent
ARCHIVE_SHA = 'd6d49b9f90dae87ca97ccc5470e9d2bcc20ba3d9988861e9f1789928b7b30256'
MANIFEST_SHA = '66bf95749b0ee6d5be351b970c26c13d811ec81351877ef163c016694709e987'
VERSION = '2053:1979161:325563:1793842063018811869:1793842063018811869'
ROOT = PurePosixPath('/home/qian/hepta-runtime-optimization-20261105-r20')


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def need(value, reason):
    if not value:
        raise ValueError(reason)


def save(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, sort_keys=True, indent=2)
        stream.write('\n')


def relative(name):
    path = PurePosixPath(name)
    need(name and path.as_posix() == name and not path.is_absolute()
         and not any(part in ('', '.', '..') for part in path.parts), 'unsafe relative member')
    return path


def main():
    rows = [json.loads(p.read_bytes()) for p in (BASE / 'chunks').glob('*.verified.json')]
    rows.sort(key=lambda row: row['offset'])
    offset, digestor = 0, hashlib.sha256()
    archive = BASE / 'cancelprocess.tar.gz'
    with archive.open('xb') as stream:
        for row in rows:
            need(row['verified'] is True and row['offset'] == offset and row['version'] == VERSION,
                 'chunk sequence/version differs')
            data = Path(row['local_path']).read_bytes()
            need(len(data) == row['bytes'] == row['next_offset'] - row['offset']
                 and sha(data) == row['sha256'], 'chunk bytes differ')
            need(sha(Path(row['response_path']).read_bytes()) == row['response_sha256'], 'response bytes differ')
            stream.write(data); digestor.update(data); offset = row['next_offset']
    need(offset == 325563 and digestor.hexdigest() == ARCHIVE_SHA
         and archive.stat().st_size == offset and sha(archive.read_bytes()) == ARCHIVE_SHA
         and rows[-1]['eof'] is True and all(row['eof'] is False for row in rows[:-1]), 'whole archive identity differs')
    failures = sorted((BASE / 'chunks').glob('*.failure-*.json'))
    download = {'schema': 'hepta-r20-cancel-download/v1', 'passed': True,
                'finished_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
                'archive': {'path': str(archive), 'bytes': offset, 'sha256': ARCHIVE_SHA},
                'chunk_count': len(rows), 'chunks': rows, 'read_limit': 32768,
                'maximum_remote_concurrency': 2, 'maximum_binary_reads_per_exec': 2,
                'all_remote_calls_awaited_and_finished': True, 'remote_reading_complete': True,
                'transport_rereads': len(failures), 'workload_retries': 0,
                'pause_for_64b_measurement': {'after_offset': 131072, 'continued_same_version': True},
                'failures': [{'path': str(p), 'sha256': sha(p.read_bytes())} for p in failures]}
    save(BASE / 'download-receipt-01.json', download)
    wrapper = json.loads((BASE / 'receipt-read-01.json').read_bytes())['value']
    envelope = wrapper.get('structuredContent') or json.loads(wrapper['content'][0]['text'])
    item = envelope['files'][0]
    candidates = [item['text'].encode()]
    try:
        candidates.append(json.loads('"' + item['text'] + '"').encode())
    except (ValueError, TypeError):
        pass
    exact = [raw for raw in candidates if len(raw) == item['size'] and sha(raw) == item['sha256']]
    need(exact and item['size'] == 1113
         and item['sha256'] == '11c1f2cbf683efeb21b219b9afc8a1a576208c286a6fe09dc2ccdd36d36a003b', 'export receipt transfer differs')
    with (BASE / 'export-receipt.json').open('xb') as stream:
        stream.write(exact[0])
    receipt = json.loads(exact[0])
    need(receipt['passed'] is True and receipt['sha256'] == ARCHIVE_SHA
         and receipt['manifest_sha256'] == MANIFEST_SHA and receipt['files'] == 1922,
         'export receipt binding differs')
    destination = BASE / 'extracted'
    need(not destination.exists(), 'fresh extraction required')
    with tarfile.open(archive, 'r:gz') as tar:
        members = tar.getmembers()
        names = [member.name for member in members]
        need(len(names) == len(set(names)) == 1923, 'member count/uniqueness differs')
        by_name = {member.name: member for member in members}
        for member in members:
            relative(member.name)
            need(member.isfile() and not member.linkname and 0 <= member.mode <= 0o777,
                 'link/special member/mode rejected')
        manifest_raw = tar.extractfile(by_name['_export-manifest.json']).read()
        need(len(manifest_raw) == 699224 and sha(manifest_raw) == MANIFEST_SHA, 'embedded manifest identity differs')
        manifest = json.loads(manifest_raw)
        need(manifest['schema'] == 'hepta-r20-cancel-export/v1' and len(manifest['files']) == 1922,
             'manifest schema/count differs')
        payload = {row['path']: row for row in manifest['files']}
        need(len(payload) == 1922 and set(names) == set(payload) | {'_export-manifest.json'},
             'extra/missing member')
        extras = {
            'baseline-jobs.rs': ('source/src/mcp/runtime/jobs.rs', '2f751c09a9a29bebb0cda0a9bd2bb522d145ee8183740ed1442d77666ee44aa7'),
            'candidate-jobs.rs': ('cancel-candidate-01/jobs.rs', '1f1f086e3bc0fc62184ed51949964e1f82e337b87d330225097ae38722e4ac8c'),
            'cancelprocess_probe_01.py': ('cancel-tools-01/cancelprocess_probe_01.py', 'ae5d82307c4ab36ff6b37e76deeaf0b71259f8c852ac4a2e8ae333a111731daa'),
            'measurement-plan-01.json': ('cancel-tools-01/measurement-plan-01.json', 'a44c750c4b0efc67123b02085194628062884be72d40c0830e6fe85e201c8c96'),
        }
        for name, row in payload.items():
            relative(name)
            if name in extras:
                original, expected = extras[name]
                need(row['original_path'] == str(ROOT / original) and row['sha256'] == expected, 'extra source/tool differs')
            else:
                need(name.startswith('cancel/') and row['original_path'] == str(ROOT / 'cancelprocess-probe-01' / name[7:]),
                     'raw source path differs')
            member = by_name[name]
            raw = tar.extractfile(member).read()
            need(len(raw) == row['size'] == member.size and sha(raw) == row['sha256'] and member.mode == row['mode'],
                 'raw member bytes/mode differ: ' + name)
        for name, expected in receipt['expected_report_sha256'].items():
            need(payload['cancel/' + name]['sha256'] == expected, 'original report pin differs')
        destination.mkdir(mode=0o700)
        for member in members:
            path = destination.joinpath(*relative(member.name).parts)
            path.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
            need(path.parent.resolve().is_relative_to(destination), 'extraction parent escaped')
            raw = tar.extractfile(member).read()
            fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, member.mode)
            with os.fdopen(fd, 'wb') as stream:
                stream.write(raw)
            os.chmod(path, member.mode)
            need(path.stat().st_size == len(raw) and sha(path.read_bytes()) == sha(raw), 'extracted bytes differ')
        with (BASE / 'manifest.json').open('xb') as stream:
            stream.write(manifest_raw)
    need(sha(archive.read_bytes()) == ARCHIVE_SHA, 'archive changed')
    result = {'schema': 'hepta-r20-cancel-export-verification/v1', 'passed': True,
              'archive': download['archive'], 'manifest': {'path': str(BASE / 'manifest.json'), 'bytes': 699224, 'sha256': MANIFEST_SHA},
              'payload_files': 1922, 'original_probe_files': 1918, 'input_files': 4, 'archive_members': 1923,
              'extracted_root': str(destination), 'all_file_sizes_sha256_modes_and_original_paths_match': True,
              'embedded_manifest_bytes_equal_external_copy': True,
              'no_links_duplicates_escape_missing_or_extra_members': True, 'original_report_sha256': receipt['expected_report_sha256'],
              'behavior_audit_performed': False, 'remote_calls_from_this_verifier': 0,
              'all_remote_calls_complete': True, 'archive_unchanged': True}
    save(BASE / 'extraction-receipt-01.json', result)
    print(json.dumps({'passed': True, 'archive_sha256': ARCHIVE_SHA,
          'download_receipt_sha256': sha((BASE / 'download-receipt-01.json').read_bytes()),
          'extraction_receipt_sha256': sha((BASE / 'extraction-receipt-01.json').read_bytes()),
          'extracted_root': str(destination), 'all_remote_calls_complete': True}))


if __name__ == '__main__':
    main()
