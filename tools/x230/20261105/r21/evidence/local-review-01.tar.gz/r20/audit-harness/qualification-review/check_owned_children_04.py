#!/usr/bin/env python3
"""Exercise only the actual R20 controller child-stage function with tiny children."""
import ast
import copy
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import sys
import tempfile

sys.dont_write_bytecode = True
ROOT = Path('/workspace/scratch/846f8b2ab644/r20/audit-harness')
SOURCE = ROOT / 'r20-tools/qualify_candidate_01.py'
EXPECTED = 'afbaa71ddc6843ce96006695954ac7148908591a8e7da6e849a29feb89696ad2'
raw = SOURCE.read_bytes()
assert hashlib.sha256(raw).hexdigest() == EXPECTED
spec = importlib.util.spec_from_file_location('r20_qualification_child_test', SOURCE)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
tree = ast.parse(raw)
main = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == 'main')
actual_stage = copy.deepcopy(next(n for n in main.body if isinstance(n, ast.FunctionDef) and n.name == 'child_stage'))
factory = ast.FunctionDef(name='make_stage',
    args=ast.arguments(posonlyargs=[], args=[ast.arg(arg=n) for n in ('source', 'control', 'report', 'persist')],
                       kwonlyargs=[], kw_defaults=[], defaults=[]),
    body=[ast.Assign(targets=[ast.Name(id='owned', ctx=ast.Store())], value=ast.Constant(value=None)),
          actual_stage, ast.Return(value=ast.Name(id='child_stage', ctx=ast.Load()))], decorator_list=[])
namespace = dict(vars(module))
# Cloud exec exposes child process handles without matching /proc/PID entries.
# Stub this metadata-only read in this local fixture; production is unchanged.
namespace['start_ticks'] = lambda pid: 100000 + pid
class FixtureProcPath:
    def exists(self):
        return False
namespace['Path'] = lambda *args: FixtureProcPath() if args and args[0] == '/proc' else Path(*args)
exec(compile(ast.fix_missing_locations(ast.Module(body=[factory], type_ignores=[])), str(SOURCE), 'exec'), namespace)
results = []
if True:
    root = Path(tempfile.mkdtemp(prefix='owned-child-attempt04-', dir=ROOT / 'qualification-review'))
    source, control = root / 'source', root / 'control'
    source.mkdir()
    control.mkdir()
    report = {'stages': []}
    stage = namespace['make_stage'](source, control, report, lambda: module.save(control / 'report.json', report, replace=True))
    fixtures = [('success', "print('stdout marker');import sys;print('stderr marker',file=sys.stderr)", 5, None),
                ('nonzero', 'import sys;sys.exit(7)', 5, ValueError),
                ('timeout', 'import time;time.sleep(30)', 1, TimeoutError),
                ('observer-failure', 'import time;time.sleep(30)', 5, RuntimeError)]
    for name, code, timeout, expected_error in fixtures:
        def observe(_row):
            raise RuntimeError('fixture observation failure')
        caught = None
        try:
            stage(name, [sys.executable, '-B', '-c', code], timeout, module.clean_environment(), report['stages'],
                  observe=observe if name == 'observer-failure' else None)
        except BaseException as error:
            caught = error
        row = report['stages'][-1]
        print(json.dumps({'fixture':name,'caught':None if caught is None else repr(caught),'row':row,'persistent_root':str(root)}), flush=True)
        assert (caught is None) if expected_error is None else isinstance(caught, expected_error)
        assert row['waited_and_reaped'] is row['proc_absent'] is row['process_group_absent'] is True
        assert module.group_absent(row['process_group'])
        assert row['automatic_retries'] == 0 and row['start_ticks'] > 0
        if name == 'success':
            assert row['returncode'] == 0
            assert Path(row['stdout']['path']).read_bytes() == b'stdout marker\n'
            assert Path(row['stderr']['path']).read_bytes() == b'stderr marker\n'
        if name == 'nonzero':
            assert row['returncode'] == 7
        if name == 'timeout':
            assert row['timed_out'] is True and row['cleanup_signals'] == ['SIGTERM']
        if name == 'observer-failure':
            assert row['error'] == 'RuntimeError: fixture observation failure'
        for stream in ('stdout', 'stderr'):
            data = Path(row[stream]['path']).read_bytes()
            assert len(data) == row[stream]['size'] and hashlib.sha256(data).hexdigest() == row[stream]['sha256']
        results.append({'fixture': name, 'passed': True, 'exception': None if caught is None else type(caught).__name__, 'row': row})
    saved = json.loads((control / 'report.json').read_bytes())
    assert saved['stages'] == report['stages']
assert hashlib.sha256(SOURCE.read_bytes()).hexdigest() == EXPECTED
value = {'schema': 'hepta-r20-qualification-local-child-check/v1', 'passed': True,
         'launcher_sha256': EXPECTED, 'compilation_started': False, 'remote_operations': False,
         'scope': 'four tiny direct children in their own local sessions; start_ticks and proc-path existence are metadata stubs because cloud exec PID handles differ from visible procfs; no Linux process-identity or escaped-descendant coverage claimed',
         'linux_proc_identity_verified': False, 'metadata_only_fixture_stub': 'start_ticks(pid)->100000+pid; child /proc-path existence->False; real Popen wait and process-group signal/probe calls retained',
         'fixtures': results}
output = ROOT / 'qualification-review/owned-child-check-01.json'
with output.open('x') as f:
    json.dump(value, f, indent=2, sort_keys=True)
    f.write('\n')
print(json.dumps({'passed': True, 'fixtures': len(results), 'receipt': str(output), 'sha256': hashlib.sha256(output.read_bytes()).hexdigest()}))
