#!/usr/bin/env python3
"""Read a completed fixed probe; create one new bounded evidence archive only."""
import argparse
import gzip
import hashlib
import io
import json
import os
from pathlib import Path
import stat
import tarfile

ROOT = Path('/home/qian/hepta-runtime-optimization-20261105-r20')
PROBE = ROOT / 'request-hash-probe-64b-01'
OUT = ROOT / 'request-hash-probe-64b-export-01'
REPORT_SHA = '347626e60c950bcaeacafaaa6c863834d9dac0c75524372612cc93f402800d4b'
BUNDLE_SHA = 'ccb0092124f14438c37de36ee89ca08e22bbb3aab88f8b245502e73c4187050b'


def need(ok, message):
    if not ok:
        raise RuntimeError(message)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def read(path, compiler_binary=False):
    path = Path(path)
    need(path.is_absolute() and path.resolve() == path, 'indirect input')
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK | os.O_CLOEXEC)
    try:
        before = os.fstat(fd)
        need(stat.S_ISREG(before.st_mode) and (before.st_nlink >= 1 if compiler_binary else before.st_nlink == 1)
             and 0 <= before.st_size <= 4 * 1024 * 1024, 'unsafe input')
        parts = []
        left = before.st_size + 1
        while left:
            part = os.read(fd, min(left, 65536))
            if not part:
                break
            parts.append(part)
            left -= len(part)
        raw = b''.join(parts)
        stamp = lambda x: tuple(getattr(x, f) for f in (
            'st_dev', 'st_ino', 'st_mode', 'st_uid', 'st_nlink', 'st_size', 'st_mtime_ns', 'st_ctime_ns'))
        need(len(raw) == before.st_size and stamp(before) == stamp(os.fstat(fd)) == stamp(path.lstat()),
             'changed input')
        return raw
    finally:
        os.close(fd)


def ident(raw):
    return {'bytes': len(raw), 'sha256': sha(raw)}


def canonical(value):
    return (json.dumps(value, sort_keys=True, indent=2, allow_nan=False) + '\n').encode()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--bundle', required=True, type=Path)
    args = parser.parse_args()
    bundle = args.bundle.absolute()
    need(bundle.is_relative_to(ROOT) and bundle.resolve() == bundle and bundle.is_dir(), 'bundle outside R20')
    need(OUT.resolve() == OUT and not os.path.lexists(OUT), 'fresh export directory required')
    report_raw = read(PROBE / 'report.json')
    need(sha(report_raw) == REPORT_SHA, 'actual report differs')
    report = json.loads(report_raw)
    need(report['passed'] is report['source_stable'] is True and report['cells'] == 96
         and len(report['stages']) == 102 and report['automatic_retries'] == 0,
         'completed probe contract differs')
    manifest_raw = read(bundle / 'bundle-manifest.json')
    need(sha(manifest_raw) == BUNDLE_SHA == report['bundle_manifest_sha256'], 'actual bundle differs')
    bundle_manifest = json.loads(manifest_raw)
    payload, sources = {}, {}

    def add(name, path, expected=None):
        need(name not in payload and not name.startswith('/') and '..' not in Path(name).parts,
             'unsafe/repeated archive member')
        raw = read(path)
        if expected is not None:
            need(ident(raw) == expected, 'bound bytes differ: ' + str(path))
        payload[name] = raw
        sources[name] = {'source_path': str(path), **ident(raw)}

    for name in ('report.json', 'protocol.json', 'freeze.json', 'raw-cells.jsonl'):
        add('probe/' + name, PROBE / name, report['raw_cells'] if name == 'raw-cells.jsonl' else None)
    for stage in report['stages']:
        name = stage['name']
        need(Path(name).name == name and stage['returncode'] == 0 and stage['waited_and_reaped'] is True,
             'invalid successful stage')
        add('probe/' + name + '.stage.json', PROBE / (name + '.stage.json'))
        need(json.loads(payload['probe/' + name + '.stage.json']) == stage, 'stage receipt differs')
        for stream in ('stdout', 'stderr'):
            binding = stage[stream]
            need(binding['path'] == name + '.' + stream, 'stage stream path differs')
            add('probe/' + binding['path'], PROBE / binding['path'],
                {key: binding[key] for key in ('bytes', 'sha256')})
    expected_top = {name.split('/', 1)[1] for name in payload if name.startswith('probe/')}
    actual_top = {p.name for p in PROBE.iterdir() if p.is_file()}
    need(actual_top == expected_top, 'unexpected or omitted top-level probe evidence')
    add('bundle/bundle-manifest.json', bundle / 'bundle-manifest.json')
    for name, expected in sorted(bundle_manifest['files'].items()):
        add('bundle/' + name, bundle / name, expected)
        if name in ('Cargo.toml', 'rustfmt.toml') or name.startswith('src/'):
            add('probe/project/' + name, PROBE / 'project' / name, expected)
    add('probe/project/Cargo.lock', PROBE / 'project/Cargo.lock', report['resolved_cargo_lock'])
    baseline = Path(report['baseline_jobs'])
    need(baseline == Path('/home/qian/hepta-runtime-optimization-20261104-r19/source/src/mcp/runtime/jobs.rs'),
         'unexpected baseline source path')
    add('baseline/jobs.rs', baseline)
    need(sources['baseline/jobs.rs']['sha256'] == report['baseline_jobs_sha256'], 'actual baseline changed')
    binary = PROBE / 'target/release/hepta-r20-request-hash-probe'
    binary_id = ident(read(binary, compiler_binary=True))
    binary_link_count = binary.lstat().st_nlink
    need(binary_id == report['binary'], 'actual probe ELF changed')
    for name, row in sources.items():
        need(ident(read(Path(row['source_path']))) == {k: row[k] for k in ('bytes', 'sha256')},
             'source changed before archive: ' + name)
    export_manifest = {'schema': 'hepta-r20-request-hash-export/v1', 'source_root': str(PROBE),
        'original_report_sha256': REPORT_SHA, 'files': sources, 'source_file_count': len(sources),
        'actual_probe_binary_excluded': {'path': str(binary), 'observed_link_count': binary_link_count, **binary_id},
        'compiled_target_files_archived': False, 'original_files_modified': False,
        'source_hashes_checked_before_archive': True, 'archiver_identity_scope': 'stdin source recorded by caller'}
    payload['export-manifest.json'] = canonical(export_manifest)
    OUT.mkdir(mode=0o700)
    archive = OUT / 'request-hash-probe-64b-evidence-01.tar.gz'
    with archive.open('xb') as destination:
        with gzip.GzipFile(filename='', fileobj=destination, mode='wb', mtime=0, compresslevel=6) as compressed:
            with tarfile.open(fileobj=compressed, mode='w', format=tarfile.PAX_FORMAT) as tar:
                for name, raw in sorted(payload.items()):
                    entry = tarfile.TarInfo(name)
                    entry.size, entry.mode, entry.uid, entry.gid, entry.mtime = len(raw), 0o600, 0, 0, 0
                    tar.addfile(entry, io.BytesIO(raw))
    for name, row in sources.items():
        need(ident(read(Path(row['source_path']))) == {k: row[k] for k in ('bytes', 'sha256')},
             'source changed after archive: ' + name)
    need(ident(read(binary, compiler_binary=True)) == binary_id
         and binary.lstat().st_nlink == binary_link_count, 'probe ELF changed while archiving')
    receipt = {'schema': 'hepta-r20-request-hash-export-result/v1', 'passed': True,
        'archive': {'path': str(archive), **ident(read(archive))}, 'member_count': len(payload),
        'export_manifest': ident(payload['export-manifest.json']), 'original_sources_unchanged': True,
        'actual_probe_binary_excluded': {**binary_id, 'observed_link_count': binary_link_count},
        'original_report_sha256': REPORT_SHA}
    with (OUT / 'export-receipt.json').open('xb') as stream:
        stream.write(canonical(receipt))
    print(json.dumps({**receipt, 'producer_mechanism_screen_passed': report['mechanism_screen_passed'],
        'producer_cpu_summary': [{'case': row['case'],
            'block_change_percent': row['cpu_paired_block_change_percent'],
            'median_change_percent': row['cpu_paired_block_change_median_percent']}
            for row in report['summary']]}, sort_keys=True))


if __name__ == '__main__':
    main()
