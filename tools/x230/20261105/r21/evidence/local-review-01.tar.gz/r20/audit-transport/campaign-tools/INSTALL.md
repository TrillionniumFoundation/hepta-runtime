# R20 six-host campaign launcher

This is a local preparation deliverable. Preparing it did not start a remote job,
compile a runtime, exercise SSH, alter a production service, or execute a campaign.
The final source manifest covers the installed launcher and five unchanged boundary
files. Qualification and lifecycle tool manifests are separate immutable inputs.

## Installation layout

Install the files below under `/home/qian/hepta-runtime-optimization-20261105-r20`:

| Local bundle file | Relative remote location |
| --- | --- |
| `run_six_host_campaign_01.py` | `campaign-tools/run_six_host_campaign_01.py` |
| `boundary-tools/run_native_boundary.py` | `boundary-tools/run_native_boundary.py` |
| `boundary-tools/audit_native_boundary.py` | `boundary-tools/audit_native_boundary.py` |
| `boundary-tools/test_native_boundary.py` | `boundary-tools/test_native_boundary.py` |
| `boundary-tools/harness-freeze.json` | `boundary-tools/harness-freeze.json` |
| `boundary-tools/capacity-policy.json` | `boundary-tools/capacity-policy.json` |

All five boundary files are byte-identical to the original R16 versions recovered
from the R19 archive. `boundary-copy-receipt.json` records the local source hashes
before and after copying and the copied identities. The launcher also hashes the
actual R16 originals and R20 copies before/after every stage. It performs no install.

The boundary producer's output guard is relative to `HERE.parent`, so installing
the unchanged files at `R20/boundary-tools` permits `R20/native-boundary-01`.
Both boundary commands receive explicit `--harness-root R16/measurement-tools`.
The frozen twelve-file measurement library is never rewritten. The legacy wording
in an error message is retained to preserve exact original bytes.

The separately prepared lifecycle tools install at `R20/lifecycle-tools` and are
bound by their final `lifecycle-tools-manifest-01.json` SHA256 in the launcher.

## Startup contract

The existing Mac holder sends only `python3 -B - --launcher-sha256 <stdin SHA>`.
After actual qualification closes, the root workflow prepares one short stdin
bootstrap that reads the fixed installed launcher, verifies its frozen source SHA,
and executes those same bytes with these four additional actual proof values:

- `--expected-acceptance-sha256`: `R20/independent-acceptance-01.json`.
- `--expected-control-report-sha256`: terminal `R20/qualification-control-01/report.json`.
- `--expected-qualification-report-sha256`: `R20/qualification-01/report.json`.
- `--expected-candidate-sha256`: actual `R20/qualification-01/hepta-runtime` ELF.

No future candidate ELF hash is embedded in this bundle or its manifest. The Mac
`--launcher-sha256` value describes the **stdin bootstrap**, not an independent
remote self-hash of the installed launcher. The campaign separately records the
current installed launcher's complete file identity; the bootstrap supplies the
execution-time source verification.

The launcher requires Linux UID 1000, the reserved direct R20 root, the same host
as the accepted qualification, an existing held `SSH_AUTH_SOCK`, and entirely new
campaign output/socket names. Existing paths are not deleted or reused.

## Gates

The actual startup hashes must bind a successful independent acceptance, terminal
qualification control report, all eight successful qualification stages, and the
actual candidate runtime bytes. The gate also verifies:

- 281 source files and 219 compiler inputs against before/middle/after proof,
  with exactly the frozen `jobs.rs` change relative to accepted R19.
- All three retained candidate ELF files against qualification, acceptance,
  terminal control and the actual fresh-target release copies; jobctl remains
  exactly SHA256 `61c90260057a405626a24a36ad43303c632f72d2d97929296acdffd748b79d62`.
- The semantic report belongs to these baseline/candidate sources and all its
  checks pass; qualifier and verifier source identities remain fixed.
- Accepted R19 baseline source/proof and runtime SHA256
  `adab5f27f89b3cac6adaec916110a48d80697db9667e3bd7ee0fc713fe770a09` remain unchanged.
- Every recorded qualifier/control child has a successful wait/reap receipt.
  The current process scan refuses the same original identities, matching
  qualification wrappers, readable cargo/rustc processes, or scan uncertainty.
- Frozen profile `fe1e9551b5b8812ad6ed3da018c282b7261f7caeb2f49e4dcfefba7ff784ab08`,
  topology `8c0767d3318131a7d470d9cde8e327a59ce18adf022c8bc1b1d5a0fa9a865287`,
  original six job records, twelve measurement tools, five boundary tools, and
  the lifecycle tool manifest match their bindings.

The host set is `ai395`, `mac`, `main`, `pocket4`, `rog`, `x230`; historical `main`
is the separate Linux qian-qi machine, not the connector's current Mac main.
No rejected R19 qualification attempt or wrapper-causality experiment is required
by this new gate. The accepted baseline proof is sufficient for that lineage.

## Fixed execution order

1. Validate all input identities and terminal qualification; wait at least 90
   seconds, with progress and read-only compiler checks every approximately 15
   seconds. This is not an automatic retry loop for an active compiler.
2. Run the unchanged native ABBA command: C1/C8/C16, 192 timed +24 warmup calls
   per cell, workers2 and arena1. Run the unchanged independent raw analyzer.
3. Run two C32 bursts with the unchanged boundary tools and the original raw
   auditor. Separate success, exact capacity refusal and other-error classes;
   do not require a manufactured 16/16 split or count refusal as success.
4. Run one lifecycle helper: four rounds A/B/B/A, C6, six new private jobs per
   round. The helper itself runs the original recovery auditor once per round
   and the final aggregate analysis. The unified launcher does not run those
   audits a second time.

Stage timeouts are fixed: native 1,800 seconds, native audit 180 seconds, boundary
600 seconds, boundary audit 180 seconds, complete lifecycle helper 3,600 seconds.
Normal duration is expected to be much shorter; no unmeasured completion-time
promise is made.

New raw output paths are `R20/native-observation-01`, `R20/native-boundary-01`,
`R20/lifecycle-abba-01` and `R20/campaign-control-01`. Native/boundary socket parents
are `/home/qian/h20n1` and `/home/qian/h20b1`. The lifecycle helper receives the
nonexistent prefix `/home/qian/h20lc1`, then checks/creates four distinct parents
ending `-0-A`, `-1-B`, `-2-B`, `-3-A`; the unified launcher does not create the prefix.

Every stage retains original stdout/stderr, command, script hash, timeout,
PID/start-ticks, wait/reap, before/after read-only system snapshots and input gates.
Native p99 and both neighboring A/B pair directions are retained even though p99
is not an adoption gate. A failed native performance screen does not suppress
the remaining correctness stages. No RPC, stage or campaign retry is attempted.

## Failure and interpretation limits

On interruption/timeout, the launcher first sends SIGINT to its exact `Popen`
child and gives the frozen harness time to run its own private cleanup. Signals
to a stage process group are permitted only while its original unreaped leader
still anchors that newly created group. Once the leader is reaped, the launcher
does not infer signal authority from the numeric PGID alone. Forced termination,
cleanup errors and uncertain escaped descendants are retained, and the campaign
fails instead of continuing or retrying.

Success requires the original analyzers' cleanup and raw-evidence contracts, but
is not a proof that every unobserved descendant anywhere in the cluster is gone.
Compiler snapshots are read-only observations, not continuous whole-machine
inactivity proof. The launcher never signals a compiler, shared service or
unrelated process found during preflight.

Native rate/CPU cover completed observation calls, not launch throughput. The
lifecycle data cover four bounded C6 rounds; original bounded status/terminal
polling remains intact, so the launcher does not hardcode a total of 90 RPCs per
round. The fixed counts are 24 new starts, 48 same-key lookups and 48 cancellations
across the four rounds. Resource traces retain their original sampling limits.
The unified launcher reports the finite native nonregression screen and
correctness outcome; it does not decide production adoption or claim global
optimality, statistical significance, or cluster RSS/throughput improvements.
