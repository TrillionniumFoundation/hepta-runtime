#!/usr/bin/env python3
# Copyright 2026 TrillionniumFoundation
# SPDX-License-Identifier: Apache-2.0
"""Copy only the previously qualified R19 source into a new R21 experiment."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import stat

BASE = Path('/home/qian/hepta-runtime-optimization-20261104-r19')
ROOT = Path('/home/qian/hepta-runtime-optimization-20261105-r21')
FREEZE_SHA = '31f90b50d22ff8c8ac3a188f1bad47c844b4e2e68784277a87a671c916f7cb6a'

def need(ok, message):
    if not ok:
        raise RuntimeError(message)

def stable_bytes(path):
    before = path.lstat()
    need(stat.S_ISREG(before.st_mode) and before.st_nlink == 1, 'not a private regular source file: ' + str(path))
    fd = os.open(path, os.O_RDONLY | os.O_CLOEXEC | os.O_NOFOLLOW | os.O_NONBLOCK)
    try:
        opened = os.fstat(fd)
        data = bytearray()
        while True:
            chunk = os.read(fd, 65536)
            if not chunk:
                break
            data.extend(chunk)
        def stamp(s):
            return (s.st_dev, s.st_ino, s.st_mode, s.st_uid, s.st_nlink, s.st_size, s.st_mtime_ns, s.st_ctime_ns)
        need(stamp(before) == stamp(opened) == stamp(os.fstat(fd)) == stamp(path.lstat()), 'source changed during read')
        need(len(data) == before.st_size, 'source size differs')
        return bytes(data), stat.S_IMODE(before.st_mode)
    finally:
        os.close(fd)

def snapshot(source):
    need(source.resolve() == source and source.is_dir(), 'source root is not an ordinary absolute directory')
    result = {}
    for base, directories, files in os.walk(source, followlinks=False):
        for name in directories:
            need(stat.S_ISDIR((Path(base) / name).lstat().st_mode), 'source contains a symlink directory')
        for name in files:
            path = Path(base) / name
            data, mode = stable_bytes(path)
            result[path.relative_to(source).as_posix()] = {'size': len(data), 'sha256': hashlib.sha256(data).hexdigest()}
    return dict(sorted(result.items()))

def main():
    os.umask(0o077)
    need(os.getuid() != 0, 'run under the original operator account')
    source = BASE / 'source'
    raw, _ = stable_bytes(BASE / 'source-freeze-02.json')
    need(hashlib.sha256(raw).hexdigest() == FREEZE_SHA, 'R19 freeze identity changed')
    expected = json.loads(raw)['source_full_before']
    before = snapshot(source)
    need(before == expected and len(before) == 281, 'R19 source differs from accepted qualification')
    need(before['src/mcp/runtime/jobs.rs']['sha256'] == 'c9080de8aa9a35f7495aa2822a1495d297903900ae0f0de26d7b0c86d043d3c9', 'R19 jobs source differs')
    ROOT.mkdir(mode=0o700, exist_ok=False)
    destination = ROOT / 'source'
    destination.mkdir(mode=0o700)
    for relative, identity in before.items():
        data, mode = stable_bytes(source / relative)
        need({'size': len(data), 'sha256': hashlib.sha256(data).hexdigest()} == identity, 'copy source identity changed')
        path = destination / relative
        path.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
        with path.open('xb') as stream:
            stream.write(data)
        path.chmod(mode)
    need(snapshot(source) == before == snapshot(destination), 'source copy verification failed')
    (ROOT / 'tools').mkdir(mode=0o700)
    receipt = {'schema': 'hepta-r21-source-preparation/v1', 'passed': True,
               'created_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
               'source': str(source), 'candidate_root': str(ROOT),
               'baseline_commit': 'acdd07363cbff335e50c2944e02143d44ab03d6b',
               'baseline_freeze_sha256': FREEZE_SHA,
               'files': [{'path': key, **value} for key, value in before.items()],
               'source_file_count': len(before), 'original_source_unchanged': True}
    encoded = (json.dumps(receipt, sort_keys=True, indent=2) + '\n').encode()
    with (ROOT / 'preparation.json').open('xb') as stream:
        stream.write(encoded)
    print(json.dumps({'passed': True, 'root': str(ROOT), 'source_files': len(before),
                      'receipt_sha256': hashlib.sha256(encoded).hexdigest()}), flush=True)

if __name__ == '__main__':
    main()
