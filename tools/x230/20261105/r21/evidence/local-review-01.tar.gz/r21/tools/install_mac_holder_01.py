#!/usr/bin/env python3
# Copyright 2026 TrillionniumFoundation
# SPDX-License-Identifier: Apache-2.0
"""Copy the already reviewed holder unchanged into a fresh owned R21 directory."""
import hashlib
import json
import os
from pathlib import Path
import stat
import sys

old = Path('/Users/qianqi/work/hepta-runtime-x230-r19-20261104/held_agent_campaign.py')
root = Path('/Users/qianqi/work/hepta-runtime-x230-r21-20261105')
expected = '287d5026951923728c9b7661f5e3f843045791fbdb0b766c396b7331d45e5dce'
assert sys.platform == 'darwin' and os.geteuid() != 0
assert old.resolve() == old and root.resolve() == root
before = old.lstat()
assert stat.S_ISREG(before.st_mode) and before.st_nlink == 1 and before.st_uid == os.geteuid()
data = old.read_bytes()
assert len(data) == 10636 and hashlib.sha256(data).hexdigest() == expected
assert old.lstat() == before
os.umask(0o077)
root.mkdir(mode=0o700, exist_ok=False)
new = root / 'held_agent_campaign.py'
with new.open('xb') as stream:
    stream.write(data)
assert new.read_bytes() == data and old.read_bytes() == data and old.lstat() == before
receipt = {'schema': 'hepta-r21-mac-holder-install/v1', 'passed': True,
    'source': str(old), 'installed': str(new), 'sha256': expected, 'bytes': len(data),
    'source_unchanged': True, 'holder_executed': False,
    'python_executable': sys.executable, 'python_version': sys.version.split()[0],
    'source_schema_labels_preserved': 'The unchanged holder keeps its original R19 schema and temporary-name prefix; the supplied bootstrap and this new directory identify the R21 campaign.'}
with (root / 'holder-installed-01.json').open('x') as stream:
    json.dump(receipt, stream, sort_keys=True, indent=2)
    stream.write('\n')
print(json.dumps(receipt), flush=True)
