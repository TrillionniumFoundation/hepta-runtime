#!/usr/bin/env python3
# Copyright 2026 TrillionniumFoundation
# SPDX-License-Identifier: Apache-2.0
"""Install the selected STATUS+CANCEL source into the new isolated R21 copy."""
import base64,gzip,hashlib,json,os,stat,sys
from pathlib import Path
ROOT=Path('/home/qian/hepta-runtime-optimization-20261105-r21')
BASELINE_SHA='c9080de8aa9a35f7495aa2822a1495d297903900ae0f0de26d7b0c86d043d3c9'
CANDIDATE_SHA='1f1f086e3bc0fc62184ed51949964e1f82e337b87d330225097ae38722e4ac8c'
assert ROOT.resolve()==ROOT and ROOT.is_dir() and ROOT.stat().st_uid==os.geteuid()
prep=ROOT/'preparation.json'
assert hashlib.sha256(prep.read_bytes()).hexdigest()=='48a4713e5eb593edefed29a178781ff39c083cad8c90b784d49e8e633449bce0'
p=ROOT/'source/src/mcp/runtime/jobs.rs'
assert p.resolve()==p
before=p.lstat();assert stat.S_ISREG(before.st_mode) and before.st_nlink==1 and before.st_uid==os.geteuid()
assert hashlib.sha256(p.read_bytes()).hexdigest()==BASELINE_SHA
raw=sys.stdin.buffer.read(1048577);assert len(raw)<=1048576
candidate=gzip.decompress(base64.b64decode(raw,validate=True))
assert len(candidate)==186546 and hashlib.sha256(candidate).hexdigest()==CANDIDATE_SHA
assert hashlib.sha256(Path('/home/qian/hepta-runtime-optimization-20261105-r20/cancel-candidate-01/jobs.rs').read_bytes()).hexdigest()==CANDIDATE_SHA
assert not os.path.lexists(ROOT/'candidate-installed-01.json')
os.umask(0o077)
tmp=p.with_name('jobs.rs.r21-install-01')
with tmp.open('xb') as f:f.write(candidate);f.flush();os.fsync(f.fileno())
assert p.lstat()==before and hashlib.sha256(p.read_bytes()).hexdigest()==BASELINE_SHA
os.replace(tmp,p)
assert p.read_bytes()==candidate and p.lstat().st_nlink==1
report={'schema':'hepta-r21-source-install/v1','passed':True,'path':str(p),'size':len(candidate),'sha256':CANDIDATE_SHA,'previous_sha256':BASELINE_SHA,'changes':'STATUS and CANCEL subprocess imports only','qualified':False}
with (ROOT/'candidate-installed-01.json').open('x') as f:json.dump(report,f,sort_keys=True,indent=2);f.write('\n')
print(json.dumps(report,sort_keys=True),flush=True)
