#!/usr/bin/env python3
# Copyright 2026 TrillionniumFoundation
# SPDX-License-Identifier: Apache-2.0
"""Install frozen R21 qualification tools and final protocol without executing them."""
import base64,gzip,hashlib,json,os,stat,sys
from pathlib import Path
ROOT=Path('/home/qian/hepta-runtime-optimization-20261105-r21')
EXPECTED={'tools/create_component_chain_01.py': {'size': 11378, 'sha256': '4a0a72aa649c44d83299eb8bb85ce7d3aa40c3b961ca9b5b0e2cf8ef56a4a610'}, 'tools/qualify_candidate_01.py': {'size': 28022, 'sha256': '81b226f6e7d3a529ff2d0040124e661cb5e3316017e5b9c748b58d75bf4aa4c5'}, 'tools/verify_qualification_01.py': {'size': 36806, 'sha256': '216eb5e0cb922263d748f6dfefc8db00da88d00e8d021690246d7ab8e7183c95'}, 'tools/qualification-tools-manifest-01.json': {'size': 509, 'sha256': '126976a5005fbbb5b09360d6999c85fd46d14e96e9b7d037c55ea2d40b40cc8d'}, 'measurement-plan-01.json': {'size': 5302, 'sha256': 'aa4ad30b746b267d005c675f81ba634c43cd81a6f5893963445949abaa6e82f6'}}
assert ROOT.resolve()==ROOT and ROOT.is_dir() and ROOT.stat().st_uid==os.geteuid()
assert (ROOT/'tools').resolve()==ROOT/'tools'
source=ROOT/'source/src/mcp/runtime/jobs.rs'
assert hashlib.sha256(source.read_bytes()).hexdigest()=='1f1f086e3bc0fc62184ed51949964e1f82e337b87d330225097ae38722e4ac8c'
encoded=sys.stdin.buffer.read(1048577);assert len(encoded)<=1048576
raw=gzip.decompress(base64.b64decode(encoded,validate=True))
assert len(raw)==110079 and hashlib.sha256(raw).hexdigest()=='a42622a4fd075ee193d9562b77b6410c1c670c9e1ff4709a856df15324508192'
rows=json.loads(raw);assert len(rows)==len(EXPECTED) and {r['path'] for r in rows}==set(EXPECTED)
prepared=[]
for r in rows:
 p=ROOT/r['path']; e=EXPECTED[r['path']]; b=base64.b64decode(r['data'],validate=True)
 assert p.resolve()==p and not os.path.lexists(p)
 assert len(b)==r['size']==e['size'] and hashlib.sha256(b).hexdigest()==r['sha256']==e['sha256']
 prepared.append((p,b,e))
assert not os.path.lexists(ROOT/'tools-installed-01.json')
os.umask(0o077)
for p,b,e in prepared:
 with p.open('xb') as f:f.write(b)
 s=p.lstat();assert stat.S_ISREG(s.st_mode) and s.st_nlink==1 and s.st_uid==os.geteuid() and p.read_bytes()==b
assert hashlib.sha256(source.read_bytes()).hexdigest()=='1f1f086e3bc0fc62184ed51949964e1f82e337b87d330225097ae38722e4ac8c'
report={'schema':'hepta-r21-tools-install/v1','passed':True,'executed':False,'files':EXPECTED,'source_unchanged':True}
with (ROOT/'tools-installed-01.json').open('x') as f:json.dump(report,f,sort_keys=True,indent=2);f.write('\n')
print(json.dumps({'passed':True,'files':len(EXPECTED),'executed':False,'receipt_sha256':hashlib.sha256((ROOT/'tools-installed-01.json').read_bytes()).hexdigest()}),flush=True)
