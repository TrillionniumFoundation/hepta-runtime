#!/usr/bin/env python3
# Copyright 2026 TrillionniumFoundation
# SPDX-License-Identifier: Apache-2.0
"""Install two frozen tool manifests into new R21 directories; execute nothing."""
import base64
import gzip
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import stat
import sys

ROOT = Path('/home/qian/hepta-runtime-optimization-20261105-r21')
R16 = Path('/home/qian/hepta-runtime-optimization-20261104-r16')
MANIFESTS = {
    'campaign-tools/manifest.freeze-01.json': '5e74bf124730a8dae41b30b2296ed0481277d4baa72139a4aab628b04a343afd',
    'lifecycle-tools/lifecycle-tools-manifest-01.json': '445a325931f2a9147401ea241782a29617480c2047c6d5b760f2e59f9037cb1f',
}
SOURCE = ROOT / 'source/src/mcp/runtime/jobs.rs'
SOURCE_SHA = '1f1f086e3bc0fc62184ed51949964e1f82e337b87d330225097ae38722e4ac8c'

def digest(raw):
    return hashlib.sha256(raw).hexdigest()

def read(path):
    assert path.resolve() == path
    before = path.lstat()
    assert stat.S_ISREG(before.st_mode) and before.st_nlink == 1
    raw = path.read_bytes()
    after = path.lstat()
    fields = ('st_dev', 'st_ino', 'st_mode', 'st_uid', 'st_nlink', 'st_size', 'st_mtime_ns', 'st_ctime_ns')
    assert len(raw) == before.st_size and all(getattr(before, k) == getattr(after, k) for k in fields)
    return raw

assert ROOT.resolve() == ROOT and ROOT.stat().st_uid == os.geteuid()
assert digest(read(SOURCE)) == SOURCE_SHA
transport = json.load(sys.stdin)
assert set(transport) == {'encoding', 'data'} and transport['encoding'] == 'gzip-base64'
encoded_payload = gzip.decompress(base64.b64decode(transport['data'], validate=True))
assert len(encoded_payload) == 419350 and digest(encoded_payload) == '27349b737c0940e40dca9944957bbba9d777eb0a02601d4c354893639cba999e'
payload = json.loads(encoded_payload)
manifests, expected = {}, {}
for name, sha in MANIFESTS.items():
    raw = payload[name].encode('utf-8')
    assert digest(raw) == sha
    manifests[name] = json.loads(raw)
    expected[name] = {'bytes': len(raw), 'sha256': sha}
unified = manifests['campaign-tools/manifest.freeze-01.json']
assert unified['remote_root'] == str(ROOT) and unified['file_count'] == 6
for name, row in unified['files'].items():
    expected[name] = {key: row[key] for key in ('bytes', 'sha256')}
lifecycle = manifests['lifecycle-tools/lifecycle-tools-manifest-01.json']
assert len(lifecycle['files']) == 17
for name, row in lifecycle['files'].items():
    assert PurePosixPath(name).name == name
    expected['lifecycle-tools/' + name] = {key: row[key] for key in ('bytes', 'sha256')}
assert len(expected) == 25 and set(payload) == set(expected)
for name, row in expected.items():
    path = PurePosixPath(name)
    assert path.as_posix() == name and not path.is_absolute() and '..' not in path.parts
    raw = payload[name].encode('utf-8')
    assert {'bytes': len(raw), 'sha256': digest(raw)} == row
originals = []
original_measurement_names = set(json.loads(payload['boundary-tools/harness-freeze.json'])['files'])
assert len(original_measurement_names) == 12
for name, row in expected.items():
    path = PurePosixPath(name)
    old = None
    if path.parts[0] == 'boundary-tools':
        old = R16 / name
    elif path.parts[0] == 'lifecycle-tools' and path.name in original_measurement_names:
        old = R16 / 'measurement-tools' / path.name
    if old is not None:
        raw = read(old)
        assert digest(raw) == row['sha256'] and len(raw) == row['bytes']
        originals.append({'path': str(old), **row})
assert len(originals) == 17
for name in ('campaign-tools', 'boundary-tools', 'lifecycle-tools'):
    assert not os.path.lexists(ROOT / name)
os.umask(0o077)
for name in ('campaign-tools', 'boundary-tools', 'lifecycle-tools'):
    (ROOT / name).mkdir(mode=0o700)
for name, row in sorted(expected.items()):
    path = ROOT / name
    with path.open('xb') as stream:
        stream.write(payload[name].encode('utf-8'))
    raw = read(path)
    assert digest(raw) == row['sha256'] and len(raw) == row['bytes']
for row in originals:
    raw = read(Path(row['path']))
    assert digest(raw) == row['sha256'] and len(raw) == row['bytes']
assert digest(read(SOURCE)) == SOURCE_SHA
receipt = {'schema': 'hepta-r21-campaign-tools-install/v1', 'passed': True, 'executed': False,
           'manifests': MANIFESTS, 'files': expected, 'original_files_unchanged': originals,
           'candidate_jobs_source_unchanged': True}
path = ROOT / 'campaign-tools-installed-01.json'
with path.open('x') as stream:
    json.dump(receipt, stream, sort_keys=True, indent=2)
    stream.write('\n')
print(json.dumps({'passed': True, 'files': len(expected), 'receipt': str(path),
                  'receipt_sha256': digest(read(path))}), flush=True)
