import base64, gzip, hashlib, json, os, stat, sys
from pathlib import Path
root = Path('/Users/qianqi/work/hepta-runtime-x230-r21-20261105')
expected = '57871a6197cfb59086b26d5f4b80832c5f015c00989a1029e9be07fccb97b7d1'
protected = {
    'campaign-01/report.json': '085d95d9f8aad6c23fb70a69f0860d0f16798f0f05c260776f44a91f7f967c6e',
    'held_agent_campaign_02.py': '715e996217c7d33a7483354f16f2d39c9a033f51f3a20a52484495a00262dd65',
    'campaign-bootstrap-01.py': 'de42d946174b996d14c5e04892c0eeea9436d578d7ded6e2f8c0298b8bf5d0b1',
    'campaign-tools-installed-01.json': '43e80b18f9dbf944dedd7fd72ec2168ceaea4d8c3975421e4025f72d73eeaab3',
    'held_agent_campaign.py': '287d5026951923728c9b7661f5e3f843045791fbdb0b766c396b7331d45e5dce',
    'holder-installed-01.json': None,
}
assert sys.platform == 'darwin' and os.geteuid() != 0
assert root.resolve() == root and root.is_dir() and root.stat().st_uid == os.geteuid()
def read(path):
    assert path.resolve() == path
    before = path.lstat()
    assert stat.S_ISREG(before.st_mode) and before.st_nlink == 1 and before.st_uid == os.geteuid()
    raw = path.read_bytes()
    fields = ('st_dev','st_ino','st_mode','st_uid','st_nlink','st_size','st_mtime_ns','st_ctime_ns')
    assert len(raw) == before.st_size and all(getattr(before,k) == getattr(path.lstat(),k) for k in fields)
    return raw
before = {name: read(root / name) for name in protected}
for name, pin in protected.items():
    assert pin is None or hashlib.sha256(before[name]).hexdigest() == pin
path = root / 'export_mac_holder_01.py'
receipt_path = root / 'holder-exporter-installed-01.json'
assert not os.path.lexists(path) and not os.path.lexists(receipt_path)
raw = gzip.decompress(base64.b64decode(sys.argv[1], validate=True))
assert len(raw) == 21697 and hashlib.sha256(raw).hexdigest() == expected
compile(raw, str(path), 'exec')
os.umask(0o077)
with path.open('xb') as stream:
    stream.write(raw)
assert read(path) == raw
assert all(read(root / name) == data for name, data in before.items())
receipt = {'schema':'hepta-r21-mac-holder-exporter-install/v1','passed':True,'executed':False,
    'path':str(path),'size':len(raw),'sha256':expected,'protected_originals_unchanged':True,
    'protected_sha256':{name:hashlib.sha256(data).hexdigest() for name,data in before.items()}}
data = (json.dumps(receipt,sort_keys=True,indent=2)+'\n').encode()
with receipt_path.open('xb') as stream:
    stream.write(data)
assert read(receipt_path) == data
print(json.dumps({'passed':True,'installed':str(path),'size':len(raw),'sha256':expected,
    'receipt':str(receipt_path),'receipt_size':len(data),'receipt_sha256':hashlib.sha256(data).hexdigest(),
    'protected_originals_unchanged':True}),flush=True)
