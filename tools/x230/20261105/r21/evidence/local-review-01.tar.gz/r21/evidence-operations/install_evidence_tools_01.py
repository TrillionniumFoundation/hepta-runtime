#!/usr/bin/env python3
# Copyright 2026 TrillionniumFoundation
# SPDX-License-Identifier: Apache-2.0
"""Install four frozen evidence files into a new directory; execute no tools."""
import base64
import gzip
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import stat
import sys

ROOT = Path('/home/qian/hepta-runtime-optimization-20261105-r21')
DEST = ROOT / 'evidence-tools'
RECEIPT = ROOT / 'evidence-tools-installed-01.json'
SOURCE = ROOT / 'source/src/mcp/runtime/jobs.rs'
SOURCE_SHA = '1f1f086e3bc0fc62184ed51949964e1f82e337b87d330225097ae38722e4ac8c'
MANIFEST = 'evidence-tools-manifest-01.json'
MANIFEST_SHA = 'b1cfed72230d585f7393c2a75f06062b2cc22f0571f5d9b525195b7f78c59f75'
FIELDS = ('st_dev', 'st_ino', 'st_mode', 'st_uid', 'st_nlink', 'st_size', 'st_mtime_ns', 'st_ctime_ns')

def digest(raw):
    return hashlib.sha256(raw).hexdigest()

def stamp(value):
    return {key: getattr(value, key) for key in FIELDS}

def read(path):
    assert path.resolve() == path
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_CLOEXEC)
    try:
        before = os.fstat(fd)
        assert stat.S_ISREG(before.st_mode) and before.st_nlink == 1
        assert before.st_uid == os.geteuid() and 0 <= before.st_size <= 1024 * 1024
        with os.fdopen(fd, 'rb', closefd=False) as stream:
            raw = stream.read(before.st_size + 1)
        after = os.fstat(fd)
        named = path.lstat()
        assert len(raw) == before.st_size and stamp(before) == stamp(after) == stamp(named)
        return raw, {'path': str(path), 'bytes': len(raw), 'sha256': digest(raw), 'stamp': stamp(named)}
    finally:
        os.close(fd)

assert ROOT.resolve() == ROOT and ROOT.is_dir() and ROOT.stat().st_uid == os.geteuid()
source_raw, source_before = read(SOURCE)
assert digest(source_raw) == SOURCE_SHA
transport = json.load(sys.stdin)
assert set(transport) == {'encoding', 'data'} and transport['encoding'] == 'gzip-base64'
raw_payload = gzip.decompress(base64.b64decode(transport['data'], validate=True))
assert len(raw_payload) == 64969 and digest(raw_payload) == 'a50e6f4a7b33512bb2e470dc12f3c72a64fec0cf3ac9e7400f8c239dace0db23'
payload = json.loads(raw_payload)
manifest_raw = payload[MANIFEST].encode('utf-8')
assert digest(manifest_raw) == MANIFEST_SHA
manifest = json.loads(manifest_raw)
assert manifest['schema'] == 'hepta-r21-campaign-evidence-tools/v1'
assert manifest['file_count'] == 3 and manifest['self_included'] is False
assert set(manifest['files']) == {'README.md', 'export_campaign_01.py', 'replay_campaign_01.py'}
expected = dict(manifest['files'])
expected[MANIFEST] = {'bytes': len(manifest_raw), 'sha256': MANIFEST_SHA}
assert len(expected) == 4 and set(payload) == set(expected)
for name, row in expected.items():
    assert PurePosixPath(name).name == name and name not in ('.', '..')
    raw = payload[name].encode('utf-8')
    assert {'bytes': len(raw), 'sha256': digest(raw)} == row
assert not os.path.lexists(DEST) and not os.path.lexists(RECEIPT)
os.umask(0o077)
DEST.mkdir(mode=0o700)
installed = []
for name, row in sorted(expected.items()):
    path = DEST / name
    with path.open('xb') as stream:
        stream.write(payload[name].encode('utf-8'))
        stream.flush()
        os.fsync(stream.fileno())
    raw, identity = read(path)
    assert {'bytes': len(raw), 'sha256': digest(raw)} == row
    installed.append(identity)
_, source_after = read(SOURCE)
assert source_before == source_after
receipt = {
    'schema': 'hepta-r21-campaign-evidence-tools-install/v1', 'passed': True,
    'tools_executed': False, 'installed_file_count': 4, 'files': installed,
    'manifest_sha256': MANIFEST_SHA, 'candidate_source_before': source_before,
    'candidate_source_after': source_after, 'candidate_source_unchanged': True,
    'payload_bytes': len(raw_payload), 'payload_sha256': digest(raw_payload),
}
receipt_raw = (json.dumps(receipt, sort_keys=True, indent=2) + '\n').encode('utf-8')
with RECEIPT.open('xb') as stream:
    stream.write(receipt_raw)
    stream.flush()
    os.fsync(stream.fileno())
_, receipt_identity = read(RECEIPT)
print(json.dumps({'passed': True, 'files': 4, 'tools_executed': False, 'receipt': receipt_identity}), flush=True)
