#!/usr/bin/env python3
"""Validate one saved MCP binary_read response and persist its exact bytes."""
import argparse
import base64
import hashlib
import json
import os
from pathlib import Path

p = argparse.ArgumentParser()
p.add_argument('--response', required=True)
p.add_argument('--piece', required=True)
p.add_argument('--remote-path', required=True)
p.add_argument('--version', required=True)
p.add_argument('--size', required=True, type=int)
p.add_argument('--offset', required=True, type=int)
p.add_argument('--limit', required=True, type=int)
a = p.parse_args()
response_path = Path(a.response)
response_raw = response_path.read_bytes()
envelope = json.loads(response_raw)
assert not envelope.get('isError', False)
value = envelope.get('structuredContent')
if value is None:
    value = json.loads('\n'.join(row['text'] for row in envelope['content'] if row['type'] == 'text'))
assert value['path'] == a.remote_path and value['version'] == a.version
assert value['size'] == a.size and value['offset'] == a.offset
raw = base64.b64decode(value['data_base64'], validate=True)
assert len(value['data_base64']) == 4 * ((len(raw) + 2) // 3)
assert base64.b64encode(raw).decode() == value['data_base64']
assert len(raw) == min(a.limit, a.size - a.offset)
assert value['next_offset'] == a.offset + len(raw)
assert value['eof'] is (value['next_offset'] == a.size)
sha = hashlib.sha256(raw).hexdigest()
assert sha == value['chunk_sha256']
piece = Path(a.piece)
with piece.open('xb') as stream:
    stream.write(raw)
    stream.flush()
    os.fsync(stream.fileno())
assert hashlib.sha256(piece.read_bytes()).hexdigest() == sha
receipt = {
    'path': str(piece), 'offset': a.offset, 'next_offset': value['next_offset'],
    'bytes': len(raw), 'sha256': sha, 'version': a.version, 'eof': value['eof'],
    'response': {'path': str(response_path), 'bytes': len(response_raw),
                 'sha256': hashlib.sha256(response_raw).hexdigest()},
}
with piece.with_suffix('.receipt.json').open('x') as stream:
    json.dump(receipt, stream, sort_keys=True, indent=2)
    stream.write('\n')
print(json.dumps(receipt, sort_keys=True))
