# R21 terminal capture, download and replay commands

Prepared locally while the formal campaign is running. No command or remote
read in this note has been executed. Wait for root's explicit terminal notice
before exporting or downloading. This note does not infer completion from time.

## Known actual identities

- R21 qualified runtime:
  `7709579269d5c7ec1eba8512dd7cc028ecc602c08156f8172a15203080e39878`.
- R21 original qualification report:
  `301e50f699d7a967d977add6d8da6872a3e09cedaabf1b0366658f6cf26af06a`.
- Frozen evidence-tools manifest:
  `b1cfed72230d585f7393c2a75f06062b2cc22f0571f5d9b525195b7f78c59f75`.
- Actual campaign report SHA256, archive SHA256/size and embedded manifest
  SHA256 are not known yet. Obtain them from the actual terminal report and
  exporter receipt; do not substitute qualification or earlier campaign hashes.

## 1. Capture on X230 after terminal

Use the fixed installed exporter. Supply the actual campaign-control report
SHA256 in the task-specific variable `R21_CAMPAIGN_REPORT_SHA`:

```sh
: "${R21_CAMPAIGN_REPORT_SHA:?actual terminal campaign report SHA256 required}"
/usr/bin/python3 -B /home/qian/hepta-runtime-optimization-20261105-r21/evidence-tools/export_campaign_01.py \
  --expected-campaign-report-sha256 "$R21_CAMPAIGN_REPORT_SHA" \
  --expected-candidate-sha256 7709579269d5c7ec1eba8512dd7cc028ecc602c08156f8172a15203080e39878 \
  --expected-evidence-tools-manifest-sha256 b1cfed72230d585f7393c2a75f06062b2cc22f0571f5d9b525195b7f78c59f75 \
  --out /home/qian/hepta-runtime-optimization-20261105-r21/export-campaign-01
```

Keep the actual invocation, job receipt, stdout/stderr and exit status. The
three output paths are:

```text
/home/qian/hepta-runtime-optimization-20261105-r21/export-campaign-01/campaign-evidence-01.tar.gz
/home/qian/hepta-runtime-optimization-20261105-r21/export-campaign-01/manifest.json
/home/qian/hepta-runtime-optimization-20261105-r21/export-campaign-01/receipt.json
```

An exporter `passed: true` means the archive is stable; read its separate
`campaign_passed`, terminal-stage and native-screen fields. A failed campaign
can still be archived without becoming an accepted experiment.

## 2. Versioned binary download

Use the existing purpose-built tools. Their metadata was inspected locally;
no call was made while the performance window was active.

```javascript
await tools.mcp__codex_apps__heptaruntime_mac_controller_file_info({
  host: "x230",
  path: "/home/qian/hepta-runtime-optimization-20261105-r21/export-campaign-01/campaign-evidence-01.tar.gz"
});
```

Persist the complete returned tool-result object before decoding its JSON text.
Require its `path`, `size` and `sha256` to equal the actual exporter receipt.
Retain its `version` unchanged for all subsequent reads. The tool schemas are:

```text
file_info({host: string, path: string})
binary_read({host: string, path: string, offset?: number,
             limit?: number, expected_version?: string})
```

The following call is the first chunk once `R21_ARCHIVE_VERSION` is the verified
actual version token. Use the prior successful response's `next_offset` for
each subsequent chunk, not an inferred base64 length:

```javascript
await tools.mcp__codex_apps__heptaruntime_mac_controller_binary_read({
  host: "x230",
  path: "/home/qian/hepta-runtime-optimization-20261105-r21/export-campaign-01/campaign-evidence-01.tar.gz",
  expected_version: R21_ARCHIVE_VERSION,
  offset: 0,
  limit: 65536
});
```

Use one in-flight call unless root explicitly allocates a second independent
read. The declared tool cap is 64 KiB. Record the actual returned byte count;
do not claim a 32 KiB limit. Each response must be durably saved before parsing
or base64 decoding. Store metadata and progress summaries without printing
base64 to chat.

For each chunk, verify exact host/path/version, full file size, requested
offset, returned `next_offset`, `eof`, strict base64 length and decoded byte
count, and the independent `chunk_sha256`. Preserve errors and unexpected
responses in separate numbered attempt records. A same-byte retry may only
reuse the original fixed version and must remain visible; it is not a new
performance sample. Never overwrite an earlier chunk or response.

Use the new local directory
`/workspace/scratch/846f8b2ab644/r21/campaign-download-01` for the received archive,
raw response records, verified chunk receipts and original exporter receipts.
Before extraction, require contiguous offset coverage from zero to the actual
full size, one pinned version, and a complete SHA256 matching the exporter.
Save the archive as `campaign-evidence-01.tar.gz`. Also download the original
external `manifest.json` and `receipt.json` with their observed file identities;
the replay checks the embedded manifest independently.

If root chooses a preverified Mac-side byte-for-byte copy to reduce SSH
round trips, bind its complete SHA256 and size to the same X230 archive before
changing `host` or `path`. Keep the X230 source and Mac-copy identities distinct.
No Mac-copy stage has been executed while preparing this note.

## 3. Exact local replay command

Fill these three task-specific values from the actual terminal/export records:
`R21_CAMPAIGN_REPORT_SHA`, `R21_ARCHIVE_SHA`, and `R21_ARCHIVE_MANIFEST_SHA`.
The extraction and output directories below must not already exist.

```sh
: "${R21_CAMPAIGN_REPORT_SHA:?actual campaign report SHA256 required}"
: "${R21_ARCHIVE_SHA:?actual original archive SHA256 required}"
: "${R21_ARCHIVE_MANIFEST_SHA:?actual embedded/export manifest SHA256 required}"
python3 -B /workspace/scratch/846f8b2ab644/r21/evidence-tools/replay_campaign_01.py \
  --archive /workspace/scratch/846f8b2ab644/r21/campaign-download-01/campaign-evidence-01.tar.gz \
  --expected-archive-sha256 "$R21_ARCHIVE_SHA" \
  --expected-manifest-sha256 "$R21_ARCHIVE_MANIFEST_SHA" \
  --expected-campaign-report-sha256 "$R21_CAMPAIGN_REPORT_SHA" \
  --expected-candidate-sha256 7709579269d5c7ec1eba8512dd7cc028ecc602c08156f8172a15203080e39878 \
  --extract-root /workspace/scratch/846f8b2ab644/r21/campaign-download-01/extracted \
  --output-root /workspace/scratch/846f8b2ab644/r21/campaign-replay-01
```

Preserve this actual invocation, its stdout/stderr and exit status. Replay
performs the seven original offline audits, checks their JSON objects against
the archived originals, and recomputes the original native gate and pair views.
The expected counts remain 2,304 measured +288 warmup +72 preflight/restart,
two C32 bursts with refusal kept separate, and lifecycle 24/48/48. Any deviation
must be reported from actual raw evidence, not rewritten to those expected values.

The actual replay report is
`/workspace/scratch/846f8b2ab644/r21/campaign-replay-01/report.json`.
It is independent of the producer's correctness flag and its performance
screen. No adoption, cluster RSS improvement or maximum throughput conclusion
follows from archive creation alone. Mac holder terminal/cleanup closure remains
a separate package bound by root's final orchestration.
