# X230 R21：STATUS／CANCEL 冷进程成本与六机生命周期验收

**当前为待完成验收的报告草稿。** 最终候选只在 `src/mcp/runtime/jobs.rs` 中延后 STATUS 和 CANCEL 的 `subprocess` 导入，共 7 行新增、2 行删除。两个组件的原始证据已通过离线独立审计；R21 全新构建资格已启动，正式六机结果尚未取得，**目前没有采用 R21 的结论**。

本轮也测试了固定 4 KiB 和 64 字节的 request-hash 缓冲。两者都通过正确性检查，但小请求 CPU 回退超过事先约定的 2% 门槛，均被拒绝。最终候选不包含任何 hash-buffer 改动。

STATUS 的两个原生 Linux 场景测得 fresh-helper CPU 下降约 13%，但代码未变的 READ 同时下降约 6%。CANCEL 的两个原生场景分别下降约 8% 和 11%，它的 READ 对照却上升约 3%。这些数字支持继续验证延后导入这一机制，同时表明有限 ABBA 测量存在不可忽略的对照波动；它们不能直接换算为六机吞吐、常驻内存或最大并发能力的收益。

完整文件身份、原始包位置和各结果的来源列在附属 [evidence-identities.json](../tools/x230/20261105/r21/evidence-identities.json)。本文用短源码标识区分实验，不把长哈希表放入正文。

## 被测对象与证据链

基线是已发布的 R19 提交 `acdd07363cbff335e50c2944e02143d44ab03d6b`，正式对照使用 X230 上其有效 `qualification-02` 的实际产物。硬件、历史六机拓扑与资源解释沿用 [R19 报告](X230_OPTIMIZATION_20261104_R19.md)：ThinkPad X230、i5-3230M、2 个物理核／4 个硬件线程、约 7.46 GiB 内存。本轮实际 Python 为 3.12.3，内核为 Linux 6.8.0-142，Rust 为 1.95.0。计划不修改 governor、sysctl、生产服务或全局机器配置。

| 对象 | 源码关系 | 已取得的证据 | 当前范围 |
|---|---|---|---|
| R19 基线 `c908…` | 已发布源码 | 有效完整资格与历史六机验收 | 本轮 A 产物来源 |
| R20 中间态 `2f751c…` | R19 + STATUS 延后导入 | 352 个 fresh helper；完整资格；219 项输入绑定 | STATUS-only 已 qualified |
| R21 最终候选 `1f1f08…` | R20 + CANCEL 延后导入 | 228 个 fresh helper、66 个自有目标；组合链已实读绑定 | R21 完整资格与六机待完成 |
| 4 KiB／64 B hash-buffer | 独立组件方向 | 各 96 cells、102 stages；两次原门槛均拒绝 | 不进入最终源码 |

R20 正式六机工具曾准备、审查并安装，但没有执行。STATUS-only 中间态在正式性能测量前被组合后的 R21 取代；保留其完整资格与所有组件结果，避免再运行一次已经不打算采用的整链候选。

实际 [component-chain-01.json](../tools/x230/20261105/r21/component-chain-01.json) 绑定 `c908… → 2f751c… → 1f1f08…` 两段来源、两份真实 producer 语义报告、实际工具与计划，以及当前 R21 文件的完整字节。第一段只改变 `STATUS_CODE`，第二段只改变 `CANCEL_CODE`；其它 Rust 文本、READ／START 等嵌入式代码保持字节相同，六段 Python 去掉 import 后的 AST 相同。完整 [production.diff](../tools/x230/20261105/r21/production.diff) 可直接审阅。

这条链没有把早期冷进程测试改写为最终源码的直接测试：STATUS 的原测试对象是 `2f751c…`，CANCEL 的实际候选才是最终 `1f1f08…`。链内明确记录 `final_was_directly_coldprocess_tested=false`。creator、资格 launcher 和 verifier 共用冻结的链验证策略并重读实际文件；完整构建／测试日志审计、组件 raw 离线审计以及最终 Git 源码绑定是另行完成的证据层，不声称同一链策略有两套独立实现。

## 代码改动与行为边界

原 STATUS 和 CANCEL helper 在启动时就导入 `subprocess`，而常见 Linux 路径可直接使用 `/proc`、已有状态文件或 pidfd，并不需要该模块。候选将导入移到实际调用点：STATUS 的非 Linux `ps` 路径和 systemd 查询分支，以及 CANCEL 的非 Linux `ps` 路径。需要子进程的分支仍然导入并使用原模块；没有替换命令、调整超时、修改进程身份检查或取消信号策略。

这项改动针对每次调用都启动新 Python 解释器的 operator helper 路线。测量包含解释器启动和真实 helper 执行成本，不能解释为 Rust 函数本体的 CPU 降幅，也不覆盖 isolated jobctl 的执行成本。jobctl 源码没有改变，完整资格仍要求其新产物与已接受基线逐字节相同。

在正常 Python 环境下，固定语义矩阵的输出、错误、状态文件和资源关闭行为通过检查。另有刻意阻止未使用 `subprocess` 导入的环境边界：候选允许不需要该模块的 Linux 路径继续执行，基线可能在顶层导入时退出。这是延后导入带来的明确行为差异，不以“所有环境下行为完全相同”概括。

## STATUS 冷进程实测

实际执行一轮 ABBA、5 个场景、每 cell 16 次独立 fresh-helper 调用，共 20 cells／320 次计时进程；另有 15 对语义检查和 2 个依赖缺失边界进程，合计 352 个。每个场景每个 arm 有 32 次计时调用。原生 benchmark 直接运行从实际源码抽取的完整 PRIVATE 包装＋BOUND＋STATUS／READ 文本，计时版本没有模块诊断前后缀；systemd 与非 Linux `ps` 场景保留所需 mock，仅作诊断。

CPU 是串行启动并回收的 fresh child 的 `RUSAGE_CHILDREN` user+system 增量；wall 包括 `Popen`、通信与回收。下表为各 arm 的总量除以调用数，变化为 B/A−1；不是函数内循环微基准。

| 场景 | A CPU ms/调用 | B CPU ms/调用 | CPU 变化 | A wall ms/调用 | B wall ms/调用 | wall 变化 |
|---|---:|---:|---:|---:|---:|---:|
| completed STATUS | 59.367 | 51.599 | −13.085% | 59.931 | 52.177 | −12.938% |
| completed READ，未改动对照 | 45.326 | 42.557 | −6.108% | 45.997 | 43.130 | −6.232% |
| detached live STATUS | 55.307 | 47.984 | −13.241% | 55.852 | 48.559 | −13.059% |
| systemd mock，仅诊断 | 56.637 | 58.640 | +3.536% | 57.244 | 59.131 | +3.297% |
| non-Linux ps mock，仅诊断 | 55.576 | 56.768 | +2.144% | 56.161 | 57.314 | +2.052% |

两个相邻配对分别比较 round 1 的 B 对 round 0 的 A，以及 round 2 的 B 对 round 3 的 A。completed STATUS 的 CPU B/A 为 0.876874／0.861459，detached live 为 0.872549／0.862542。两条原生 STATUS 路径的聚合 CPU 均低于 0.95，两个配对均低于 1.0；READ 对照低于原先约定的 1.10，组件筛选通过。

READ 在两 arm 的执行脚本字节相同，却同样出现 CPU 与 wall 下降。因此不能把 STATUS 约 13% 的完整差异都归因于代码，也不直接用 READ 百分比相减当成经过证明的因果校正。mock 的小幅回退完整保留，不当作生产 systemd／Mac 性能结论。

独立 [cold offline audit](../tools/x230/20261105/r20/reviews/cold/x230-cold-offline-audit-01.json) 从全部 raw 进程记录、stdout/stderr、时钟端点、累计计数器和固定夹具重算结果，14 项检查通过。原 archive 的 840 个成员另经外部 manifest 核对大小、SHA、原路径与模式；其中语义夹具故意包含的非私有模式也按原记录验证，未用解包后的权限替代原始证据。该测量的 `ru_maxrss` 是累计 child 高水位观察，不能证明单 helper 的 RSS 或每次调用分配下降。

## CANCEL 冷进程与自有目标实测

CANCEL 对照直接使用 `2f751c…` 与 `1f1f08…`，固定三场景 ABBA，每 cell 16 次，共 192 个计时 helper；17 对语义检查和 2 个依赖缺失边界 helper 使总数达到 228。独立创建并清理 66 个自有目标，进程身份以 PID/start-ticks 绑定。已退出场景、真实 Linux owned-pidfd 取消，以及未改动 READ 对照分别保留完整原始证据。

| 场景 | A helper CPU ms/调用 | B helper CPU ms/调用 | CPU 变化 | A helper wall ms/调用 | B helper wall ms/调用 | wall 变化 |
|---|---:|---:|---:|---:|---:|---:|
| 已退出作业 CANCEL | 55.327 | 50.875 | −8.045% | 55.873 | 51.448 | −7.920% |
| Linux 自有 live 目标／pidfd CANCEL | 52.082 | 46.324 | −11.055% | 56.075 | 50.062 | −10.723% |
| READ，未改动对照 | 43.289 | 44.606 | +3.042% | 43.886 | 45.149 | +2.880% |

两个 CANCEL 场景的 CPU B/A 配对分别为 0.928040／0.909988 与 0.884830／0.894240。聚合均低于 0.95，每个配对均不超过 1.0；READ 聚合不超过 1.10，全部正确性与自有目标范围检查通过，原 screen 为 true。READ 在本次窗口向相反方向变化，再次提示组件百分比不等于无噪声的普遍收益。

helper 的 CPU 采样在目标进程 wait/reap 前结束；66 个目标的回收和 CPU 另行记录，不混入 helper 分子。离线审计核对 294 个不同 PID/start-ticks 身份；全部 helper 的 CPU 总量为 12.400775 秒，另行排除的目标 CPU 总量为 2.458898 秒。这两项是完整试验生命周期计数，不是表中三个 benchmark 场景均值的简单相加。观察到的 30,984 KiB child HWM 仍是累计高水位，不能当作单次取消的内存占用。

这些是真实 fresh helper 与受控自有目标的本机组件证据，尚不包含 SSH 端到端多机取消吞吐。完整 [CANCEL raw archive](../tools/x230/20261105/r20/evidence/cancelprocess-01.tar.gz) 含 1,918 个原始 probe 文件和 4 个冻结输入，另带 manifest。独立审计第 02 版的 15 项检查全部通过，重算 screen 为 true。

### 保留首次离线审计失败及修正

第 01 版离线 auditor 错把原生成功路径的模块导入断言扩展到了 mock 异常和提前退出路径，因而失败。原 producer 证据没有改变，性能没有重跑。第 02 版将该机制断言限定为原生成功路径和显式 blocked-import 边界，其余脚本、元数据、stdout/stderr、信号事件、关闭行为、夹具、时钟、统计和筛选检查保留。

具体而言，binding mismatch 可在 BOUND 中提前退出，尚未执行 CANCEL 顶层导入；非 Linux mock 又会主动导入模块以安装 mock。另有三个 B 异常路径在退出时观察到 `subprocess` 已加载，但现有记录没有定位由谁导入，不能把原因写成已证明的异常格式化行为。

原失败报告、两个 auditor 原文、差异、修正说明、两次 invocation 与 stdout/stderr 共 12 件材料由 [audit-evidence-manifest-01.json](../tools/x230/20261105/r20/reviews/cancel/audit-evidence-manifest-01.json) 全量列出。通过的第 02 版没有覆盖第 01 版。

## 被拒绝的 request-hash 缓冲方向

两个独立 bundle 分别测试 4,096 字节和唯一一次原则明确的 64 字节 follow-up。每个 bundle 都使用原六个固定场景、四个 ABBA blocks、96 个 fresh worker cells；加六个准备／检查阶段共 102 stages。每次有两个实际 Cargo tests，独立 check 进程检查六个 canonical fixtures 和七个 buffer 边界。离线各 225 项检查通过，全部 raw、源码和实际 reduced lock 闭合。

下表百分比为四个 block 内 B/A CPU 比率的中位变化，不是把两个 arm 的总体中位数相除。负数表示每次 digest 使用的 CPU 更少。

| 场景 | 4 KiB buffer | 64 B buffer | 原门槛及结果 |
|---|---:|---:|---|
| small_176 | +10.9944% | +5.1977% | 小／plain 输入至多 +2%；两次拒绝 |
| escaped_small | +5.9705% | +5.1194% | 至多 +2%；两次拒绝 |
| plain_64k | +5.9758% | −1.6945% | 至多 +2%；4 KiB 拒绝 |
| escaped_64k | −11.8187% | −15.6258% | 大 escaped 至少改善 5%；均通过此分项 |
| plain_1mib | +0.8723% | +0.5405% | 至多 +2%；均通过此分项 |
| escaped_1mib | −14.9052% | −10.6079% | 大 escaped 至少改善 5%；均通过此分项 |

两个大 escaped 场景在各自全部四个 block 中改善，但这不能覆盖小请求失败。64 B 的两个 small 场景更是四个 block 全部回退。按预先约定的停止规则，本轮结束这一方向，不继续扫 buffer 大小，也不采用条件性的 hash-buffer integration draft。

CPU 只计 digest loop，包含两 arm 共同的 full-hash 相等断言，排除启动、fixture、warmup 和资源读取。全部 worker 的生命周期 HWM 在 4 KiB 试验为 21,098,496 B，在 64 B 试验为 21,102,592 B，均没有建立 RSS 收益证据。不能从 fragment 减少单独推断栈初始化就是小请求回退的原因。四个 block 的完整方向和资源列表保留在 [4 KiB 结果](../tools/x230/20261105/r20/reviews/hash4096/RESULTS.md) 与 [64 B 结果](../tools/x230/20261105/r20/reviews/hash64/RESULTS.md)。

## 完整资格与源码绑定

### 已完成的 R20 STATUS-only 资格

R20 在新的空 target 中完成 format、fmt-check、harness tests、all-targets/all-features strict Clippy、test-build、逐项 isolated tests、独立测试日志审计及 release 八个阶段，均退出 0。**1,637 passed／0 failed／33 ignored，1,670 selected，5 个 test binaries，0 test retries。** 33 个 ignored 项没有在此流程中执行；根 crate library 与五个测试 artifact 为 `fresh=false`。

完整资格阶段耗时 1,997.827 秒，随后独立验收耗时 13.020 秒，31 项检查全部通过。源码前／中／后 281 文件全等，219 个编译输入保持一致；实际 jobctl 新产物通过严格基线 SHA 与逐字节比较。新 runtime 与 driver 分别绑定本次实际产物，不根据源码变化小就推定二进制相同。

原 [R20 qualification archive](../tools/x230/20261105/r20/evidence/qualification-01.tar.gz) 保留 3,362 个源码／收据／完整日志文件和 embedded manifest。8 个 ELF 没有作为二进制内容入包；导出时的稳定全文件 SHA，已在离线 sidecar 中逐项对齐 acceptance 的 3 个 release 与 5 个 retained test binaries 的 exact path、SHA 和可用 size。这是实际远端字节身份与原验收的绑定，不声称在本地复现 ELF。

独立 [qualified-source-binding-01.json](../tools/x230/20261105/r20/reviews/qualification/qualified-source-binding-01.json) 核对七份 219 输入 map、三份 281 全树快照及实际产物，10 项检查通过。R20 `src` 树重新算得 `7e5e1984…`，其 218 个未改输入的 SHA256↔Git blob 对应关系来自固定 R19 提交和已发布完整证明，改变的 jobs.rs 本地重新哈希。该证明没有冒称重新下载了所有 218 个叶字节，也不绑定尚未产生的最终发布 commit。

R21 沿用成功的显式构建环境白名单，四种 Cargo／rustc wrapper 环境键全部缺席，不设为空字符串；这样保留 R19 已诊断并验证的构建身份约束。仍使用冻结原 qualifier、offline／locked Rust 1.95、jobs=2，以及原测试 runner／auditor，不因资格耗时而跳过阶段。

### R21 最终资格：待填

<!-- R21_PENDING: qualification -->

R21 的最终源码已经安装并经真实 component chain 绑定，fresh qualification 已启动；此草稿尚未取得最终报告。发布前必须补齐实际八阶段退出、测试计数、31 项 independent checks、219/281 输入绑定、3 个 release／5 个 test artifact、全日志导出核验、独立最终源码树证明和自有进程回收。

| 项目 | R21 实际值 |
|---|---|
| 完整资格与独立验收 | 待填 |
| 测试 passed／failed／ignored／retries | 待填 |
| runtime／jobctl／driver 身份 | 待填，不能沿用 R20 ELF |
| 最终 qualified source tree | 待填，需绑定实际资格 |
| 原始 archive 与离线重算 | 待填 |

## 六机验收：计划、口径与待填结果

正式对照为 R19 A → 最终 R21 B，固定历史六台主机 ai395、mac、main、pocket4、rog、x230。历史拓扑中的 main 是独立 Linux 机器，不能替换成连接器当前同名别名。workers=2、`MALLOC_ARENA_MAX=1`，资格结束及自有进程回收后按原计划静置 90 秒。完整 [measurement-plan-01.json](../tools/x230/20261105/r21/measurement-plan-01.json) 在正式测量前冻结；计划值和实际结果在本节明确区分。

### 已完成作业的 native observation

计划按 ABBA × C1/C8/C16 执行 12 cells，每 cell 192 measured＋24 warmup，status/read 在六个 host 间平衡。每个 arm／并发档的成功 rate 用成功调用总数除以 cell 耗时总和；p95/p99 合并原延迟后取 nearest-rank。CPU 是同一 controller PID/start-ticks 的同步计数器差，不包含 SSH、远端 Python 或整个集群。

原有限样本筛选要求三个并发档均满足 B/A 成功吞吐 ≥0.95、pooled p95 ≤1.10，所有正确性、恢复及来源门通过。C8 为主工作点；p99 和两个配对的全部方向仍须报告。该门槛不是统计显著性或非劣性置信区间，也不能用聚合过门掩盖某个配对回退。

<!-- R21_PENDING: native -->

| 并发 | A/B 成功调用/秒 | 吞吐变化 | A/B controller CPU ms/调用 | A/B p95／p99 | 两配对方向 |
|---|---|---|---|---|---|
| C1 | 待填 | 待填 | 待填 | 待填 | 待填 |
| C8 | 待填 | 待填 | 待填 | 待填 | 待填 |
| C16 | 待填 | 待填 | 待填 | 待填 | 待填 |

这条 workload 测量已完成作业的 observation 调用，不等于启动新作业吞吐。为覆盖实际 start/live/cancel，本轮另有下述有限生命周期对照。

### C6 实际生命周期 ABBA

计划总共四轮 A/B/B/A，每轮六台主机各创建一个新 job，合计 24 个新 job；不是四个 ABBA blocks。继续使用原 canary 的 new-start、same-key lookup、live status/read、取消、中断和重启恢复行为，不更改夹具与清理策略。

新增 phase sidecar 在整个六 host 并行 phase 外记录 monotonic 起止，以及同一 active controller PID/start-ticks 的原始 CPU 快照。CPU 只在存在 active controller 且前后身份可绑定时计算；prepare 等阶段明确为 None。窗口包含原 phase 内 checkpoint、轮询及 SSH 证明开销，sidecar 写入位于计时后。它补齐有限 C6 生命周期成本，不能证明最大可持续启动吞吐或新的最大并发上限。

<!-- R21_PENDING: lifecycle -->

四轮原 canary／独立 auditor、11 个 phase sidecar 每轮、最终 aggregate 与原 native／SSH 回复的完整复算：**待填**。应补齐每阶段 A/B wall、controller CPU、配对方向、24 个真实 start、计划 48 次 same-key reuse／48 次 cancel 的实际计数、各 host execution count、终态不变和自有资源回收证据。

### C32 突发、资源与恢复

计划用当前 R21 实际 artifact 执行两次各 32 个请求的 burst，成功与 capacity rejection 分开统计；拒绝不算成功吞吐。保留排空、后续新请求和重启恢复。客户端 pending=32 不能单独证明内部 admission identities 的峰值为 32，实测分类数量也不是预设强制成功数。

<!-- R21_PENDING: boundary_and_resources -->

两次突发的成功／capacity refusal／其它错误、成功 rate、成功与拒绝 p95、排空及恢复结果：**待填**。主 controller 的生命周期 HWM、RSS 样本与异步进程树 RSS 应分别报告；树采样存在短命后代缺测和共享页重复计数，不能作为精确独占内存或全六机资源总量。不能把组件的 child HWM 与 controller HWM 合并成一项“内存降低”。

## 保留的开发、导出和传输异常

以下事件均单独保留，不计入性能自动重试，也不以重新运行 workload 获取替代样本。

- 冷进程证据初次并发读取所在 exec cell 在等待时变为不可用，原响应和内存 store 未恢复；原因未知。随后按相同固定 file version 以较小分片重新读取，最终 archive／外部 manifest 大小与 SHA 全部闭合。
- R20 qualification 下载在 offset 1,245,184 的一次读取返回非 JSON 文本，解析失败发生在保存完整原返回之前。原请求和 parser exception 保留，但完整错误原文丢失，不能据此断定是 timeout 或远端文件问题。同版本只读重取后完整 archive 通过；后续读取先持久化 raw response 再解析。
- 一次本地 exec-server 断连影响的是已返回远端启动收据的本地落盘，原远端 job 没有重复启动；恢复后查询同一 job 的权威终态并保存收据。
- 4 KiB 组件第一个 exporter 将普通证据的 nlink=1 规则误用于 Cargo target ELF，因此在建输出目录前退出 1。修正版只对明确选定的 compiler ELF 允许稳定 hardlink 哈希见证，其余源码／证据仍要求单链接；原失败、两版工具与成功输出均保留。这不是组件正确性或性能失败。
- CANCEL 第 01 次离线审计失败和第 02 次有限修正按前文完整保留；未改 producer、原源码或 raw，也没有重跑性能。
- CANCEL 下载在没有在途调用时暂停，让独立 64 B 性能窗口先结束，再继续原 file version。十个分片最终全部核验，0 transport rereads；这是取证调度，不是实验重跑。

开发期间取得的一个本地 jobs.rs 副本曾截断为 147,456 B，原完整文件为 186,456 B；该副本被保留并恢复核验，没有用于正式候选。最终组合链要求各源完整 SHA、大小与逐段源码差分；相关本地失败及更正属于开发证据，不能省略成“所有准备尝试一次成功”。

## 归档与发布状态

原始证据按四类、五个不可变 archive 保存，复用原字节，不把其数千个展开成员再重复提交为 Git 文件。

| 类别 | 仓库 archive | 原始内容范围 |
|---|---|---|
| 中间完整资格 | `r20/evidence/qualification-01.tar.gz` | 3,362 个文件＋embedded manifest；8 ELF 只保留完整身份见证 |
| STATUS 冷进程 | `r20/evidence/coldprocess-01.tar.gz` | 840 个 payload；外部 `coldprocess-01.manifest.json` 必须一起保留 |
| CANCEL | `r20/evidence/cancelprocess-01.tar.gz` | 1,922 个 payload＋embedded manifest |
| 拒绝的 hash 方向 | `r20/evidence/request-hash-4096-01.tar.gz` | 332 个 payload＋export manifest |
| 拒绝的 hash 方向 | `r20/evidence/request-hash-64-01.tar.gz` | 332 个 payload＋export manifest |

表中路径均相对 `tools/x230/20261105/`。可读原计划、工具源码、独立审计与修正材料另行选择；本地运输分片和同内容 base64 不作为第二套原始实验数据重复提交。所有原 archive、外部 manifest 与独立收据通过索引关联，索引保留完整 size／SHA256／Git blob 身份。

R21 最终 qualification 和正式 campaign 的完整 raw 包为必须补齐的待定项，包括完整 transport frames／index／resource samples、四轮 lifecycle 原回复与清理证据、C32 原始分类和 drain 证据、control 与 Mac holder 的终态日志。最终源码 binder、离线重算、orchestration 说明以及最终 report／README 在关闭 publication selector 前绑定。凭证、私钥、agent socket、target ELF／object／rlib 与重复展开目录不入证据包；ELF 仅按明确的原始全文件身份见证关联。

<!-- R21_PENDING: final_adoption_and_publication -->

**最终采用／拒绝结论、发布 commit／PR、R21 raw package 索引：待填。** 当前可成立的结论是两个延后导入组件通过固定筛选、两个 hash-buffer 候选被拒绝、R20 中间源码通过完整资格。R21 的完整采用结论仍取决于最终资格、当前 artifact 的六机有限回退筛选、生命周期／边界恢复及独立 raw 审计。即使全部通过，也不据此宣称全局最优、所有优化空间耗尽，或未经测量的集群吞吐／内存收益。
