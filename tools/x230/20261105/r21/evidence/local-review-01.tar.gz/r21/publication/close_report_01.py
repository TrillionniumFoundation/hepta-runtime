#!/usr/bin/env python3
"""Close the report from the already verified R21 metric projection; no workloads."""
from pathlib import Path

root = Path(__file__).resolve().parents[2]
p = root / 'r21/publication/docs/X230_OPTIMIZATION_20261105_R21.md'
s = p.read_text()
m = (root / 'r21/campaign-metrics-02/METRICS.md').read_text()

def section(start, end):
    return m.split(start, 1)[1].split(end, 1)[0].strip()

s = s.replace('完整 raw 离线复算正在闭合，本轮不会将候选应用到运行时源码。',
              '完整 raw 离线复算已通过，结果与原汇总精确相同；本轮不会将候选应用到运行时源码。')
s = s.replace('最终六机性能门拒绝；完整 raw 离线闭合待完成', '最终六机性能门拒绝；完整 raw 离线复算通过')
s = s.replace('本次组合候选已被下面的整链性能门拒绝，完整 raw 离线复算继续闭合其证据。',
              '本次组合候选已被下面的整链性能门拒绝，完整 raw 离线复算确认了相同结果。')
s = s.replace('计划按 ABBA × C1/C8/C16 执行 12 cells', '实际按 ABBA × C1/C8/C16 完成 12 cells')
s = s.replace('完整计划包含 2,304 measured', '实际计数为 2,304 measured')
s = s.replace('<!-- R21_PENDING: native -->\n\n', '')
s = s.replace('以下为绑定实际 campaign report 的结果；完整 raw 离线重算状态在发布前补齐。',
              '以下结果已经完整 raw 离线重算；七个冻结原分析入口均退出 0，结果与原生汇总 JSON 精确相同，原 payload 保持不变。')
anchor = '`native_regression_screen_passed=false` 与整体 `passed=true`'
maxtext = '''最大 B 延迟已定位到 round 2 的 pocket4 `process_read`：7,689.390513 ms，RPC id 41，job `1a16a40534e-b1270-4`，开始于 2026-11-05T02:26:58.208766+00:00。其原 transport 帧位于 `round-2-B/first/transport-responses.jsonl` 的 offset 24,879，长 615 B；原帧完整 SHA 与提取字节均已核对。READ helper 在该候选中没有改动，但当前证据没有定位这次延迟的原因，不能据此排除该样本或归因于网络。A 的最大值来自 round 0 的同一主机 `process_status`。两个调用均成功、没有自动重试；具体原帧和身份见 [C1 maximum identities](../tools/x230/20261105/r21/reviews/c1-max-identities-01.json)。

'''
assert s.count(anchor) == 1
s = s.replace(anchor, maxtext + anchor)
start = s.index('计划总共四轮 A/B/B/A')
end = s.index('## 保留的开发、导出和传输异常')
life_wall = section('## 生命周期：11 个 C6 phase 的 wall time', '## 生命周期：同 controller phase CPU')
life_cpu = section('## 生命周期：同 controller phase CPU', '## C32 边界：成功和拒绝分开')
boundary = section('## C32 边界：成功和拒绝分开', '## RSS、FD 与观测范围')
resources = section('## RSS、FD 与观测范围', '## 原运行时间与机器快照')
new = '''实际完成四轮 A/B/B/A，每轮六台主机各创建一个新 job，合计 24 个新 job；不是四个 ABBA blocks。四轮 canary、四份原恢复 auditor 和最终聚合均通过，完整 raw 离线复算重复得到原结论。新启动、同键复用、live status/read、取消、transport 中断和 controller 重启恢复都保留原夹具与清理策略；记录的每 host execution count、终态不变和自有资源回收证据完整通过。

phase sidecar 在整个六 host 并行 phase 外记录 monotonic 起止与同一 active controller PID/start-ticks 的原始 CPU 快照。CPU 只在前后进程身份相符时计算；prepare 明确为不可用。sidecar 写入位于计时后。

''' + life_wall + '\n\n#### 生命周期 controller CPU\n\n' + life_cpu + '''

launch 的 wall 均值下降 8.727%，但该 phase controller CPU 均值上升 11.111%；concurrent_cancel wall 均值上升 5.490%。这些混合方向、短窗口与每 arm 两个样本不足以形成全面性能收益，不能覆盖前述 native 失败门。

### C32 突发、资源与恢复

两次 burst 均使用此次 qualified R21 artifact；成功与拒绝分别计量：

''' + boundary + '''

| burst | 成功 p95 ms | capacity refusal p95 ms | other error |
|---|---:|---:|---:|
| 0 | 788.445451 | 45.759556 | 0 |
| 1 | 728.691484 | 48.485177 | 0 |

每类每 burst 只有 16 个样本，nearest-rank p95 与最大值相同。全部 202 次计划调用和 204 个 transport frames 已独立复核；96 次 post-drain 是新的计划请求，不是自动重试。资源含义与实际测量如下：

''' + resources + '''

完整的 12 个 native 计时窗口、44 个 lifecycle phase 原计数器、资源缺测计数与机器阶段快照保存在 [campaign-metrics-01.json](../tools/x230/20261105/r21/reviews/campaign-metrics-01.json)，便于复查汇总公式与范围。主 controller 最高采样 RSS 约 17.2 MiB，主阶段 tree RSS 约 106.1–121.3 MiB；后者包含子进程、非同一时刻采样且共享页可能重复，不能当作精确独占占用。

'''
s = s[:start] + new + s[end:]
s = s.replace('- CANCEL 下载在没有在途调用时暂停', '- R21 一次 whole-file 读取因超过工具单文件上限被拒绝，随后通过固定版本 binary 分片取回；一次本地 JSON 嵌入 Python 的布尔字面量错误由已保存 raw response 恢复，未重复启动远端工作。另一次 Git blob 等待调用在 dispatch 前中断，随后继续等待同一 cell 并确认原操作成功；未重复写入或移动分支。原错误及更正记录保留。\n- CANCEL 下载在没有在途调用时暂停')
tail = s.index('R21 最终 qualification 和正式 campaign 的完整 raw 包为必须补齐的待定项')
s = s[:tail] + '''R21 新增的四类包与 R20 证据一并闭合：

| 类别 | 仓库 archive | 原始内容范围 |
|---|---|---|
| 最终完整资格 | `r21/evidence/qualification-01.tar.gz` | 3,364 payload＋manifest；8 ELF 完整远端身份；全部原测试流 |
| 六机正式 campaign | `r21/evidence/campaign-01.tar.gz` | 5,379 payload＋manifest；9 ELF 完整远端身份；四个原证据树、全部 transport、资源与 lifecycle |
| Mac holder | `r21/evidence/holder-01.tar.gz` | 28 payload＋manifest；实际 holder/bootstrap、全部原日志、安装与回收收据 |
| 本地 review | `r21/evidence/local-review-01.tar.gz` | 冻结 exact inventory；原开发失败、转运收据、离线工具与完整审计、最终 orchestration |

资格、campaign 和 Mac 包分别为 1,483,427 B、5,204,365 B 和 15,653 B；完整 SHA、Git blob、全部被选路径和本地 review 成员在索引中绑定。离线 qualification 的 9 项 export、6 项 raw-replay、12 项 source checks 全通过，campaign 的七个冻结分析入口与原汇总相等，Mac 独立审计 24 项检查通过。三包固定 version 下载分别为 46、80、1 个分片，均 0 transport errors／retries。没有重跑正式性能试验。

Mac holder 的 SSH foreground 命令成功返回，所持 agent 已 wait/reap，自有 agent 目录和 socket 的退出后不存在记录也由随后导出独立观察。Mac footer 保留远端 `passed=true` 与 `native_regression_screen_passed=false`，但没有 X230 report SHA；[orchestration-final-01.json](../tools/x230/20261105/r21/reviews/orchestration-final-01.json) 将真实 Mac report／bootstrap 身份、footer 路径与另行读取的 X230 完整 control report 跨包绑定，不声称 Mac exporter 独立读取过 X230 report。五个 campaign 外层阶段、四轮 lifecycle 和全部记录的自有子进程完成并回收，没有在途远端任务。

凭证、私钥、agent socket、target ELF／object／rlib 与重复展开目录不入证据包。ELF 仅按明确的原始全文件身份见证关联，没有冒称本地复现机器码。离线工具、原计划、原始归档、代码差分与精确执行命令可从 [README](../tools/x230/20261105/r21/README.md) 和索引逐项追溯。

## 最终决定与可复查停止点

**拒绝 R21 STATUS＋CANCEL 组合候选，拒绝两个 hash-buffer 候选，保留已验收 R19。** 组件 CPU 的局部改善没有转化为通过原门槛的六机端到端表现；本轮也没有建立稳定内存下降或最大并发能力增长。原生 observation 在本次 A 的 C8／C16 约为 23.44／23.40 successful calls/s，提高客户端并发没有继续增加该 workload 的吞吐，且 C16 的 p95 更高；这限定于当前六机和当前 workload，不是整个系统的理论上限。

本轮向现有 [draft PR #87](https://github.com/TrillionniumFoundation/hepta-runtime/pull/87) 添加报告、原始证据、工具和拒绝记录，编译源码仍保持 R19：`src` 树 `3aa8c9aadbf42b6a0ebdac3954bd1e64b4055e20`，jobs.rs 的 SHA256 `c9080de8aa9a35f7495aa2822a1495d297903900ae0f0de26d7b0c86d043d3c9`。qualified 候选树 `5f814d4f…` 只存在于证据关系中，候选 diff 未应用到源码。本次 publication selector 只允许 `docs/` 和 `tools/` 条目；创建实际 tree 后再以 Git 根树身份、固定 R19 发布证明和 ref 读回核对源码保持不变。自身尚未生成的 commit SHA 不写入同一提交的文件，实际发布身份在 PR 中记录。

当前停止点来自真实组件实验、完整资格、六机正式 ABBA、容量／生命周期恢复和完整离线审计。所有拒绝、控制波动、失败的准备尝试和不利尾部指标均保留；没有改变容量、完整 digest、nonce／UID／pidfd、持久化或取消保证，没有修改机器 governor、sysctl 或生产服务。后续若出现新的实际 workload、硬件、profile 或可验证机制，可以以新的预定试验继续；现有证据不支持宣称“永远不能再优化”。
'''
assert 'R21_PENDING' not in s and '待填' not in s
p.write_text(s)
print('closed_report', len(s.encode()))
