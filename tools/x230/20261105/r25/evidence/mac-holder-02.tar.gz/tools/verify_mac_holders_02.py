#!/usr/bin/env python3
# Copyright 2026 TrillionniumFoundation; SPDX-License-Identifier: Apache-2.0
"""Independently verify selected Mac holder export, raw text transport and native logs.

No network, subprocess, archived-code execution or Mac cleanup operation.
"""
import argparse
import base64
import datetime
import hashlib
import io
import json
import os
from pathlib import Path, PurePosixPath
import re
import stat
import sys
import tarfile

sys.dont_write_bytecode = True
WORK = '/Users/qianqi/work'
REMOTE = WORK + '/hepta-runtime-r25-mac-holder-export-02'
NATIVE_INPUTS = WORK + '/hepta-runtime-r25-mac-holder-inputs-02'
TOOLS = WORK + '/hepta-runtime-r25-mac-evidence-tools-02'
HOLDER = WORK + '/hepta-runtime-x230-r21-20261105/held_agent_campaign_02.py'
HOLDER_SHA = '715e996217c7d33a7483354f16f2d39c9a033f51f3a20a52484495a00262dd65'
PINS = {
    'observation': (38105, '304d3af82dc3f544dd25fc6f576af288852b7b46b7532aebe73f1351d4788ddc',
                    'campaign-02', 'observation_gate_passed'),
    'lifecycle': (25412, '0ed646ca0fe9425f5ab04bf430b499e6143ea722f2fd6395eff0d51cf3f556ff',
                  'lifecycle-campaign-02', 'adoption_passed'),
}
JOB = re.compile(r'[0-9a-f]{11,16}-[0-9a-f]{4}-[0-9a-f]{4}\Z')
HEX = re.compile(r'[0-9a-f]{64}\Z')
VERSION = re.compile(r'[0-9]+:[0-9]+:[0-9]+:[0-9]+:[0-9]+\Z')
LOG = re.compile(r'(?:report\.json|remote-script\.py|forwarded\.(?:stdout|stderr)|owned-agent\.stderr|'
                 r'identity-discovery-[0-9]{2,}\.stderr|identity-load-[0-9]{2,}\.(?:stdout|stderr))\Z')
MAX_FILE = 32 * 1024 * 1024
MAX_TOTAL = 128 * 1024 * 1024
SECRET_PATTERNS = [
    re.compile(b'-----BEGIN ' + b'(?:OPENSSH |RSA |EC |DSA |ENCRYPTED )?' + b'PRIVATE ' + b'KEY-----'),
    re.compile(rb'\bgh[pousr]_[A-Za-z0-9]{30,}\b'),
    re.compile(rb'\bgithub_pat_[A-Za-z0-9_]{40,}\b'),
    re.compile(rb'\bsk-(?:proj-|svcacct-)?[A-Za-z0-9_-]{32,}\b'),
    re.compile(rb'(?i)\bauthorization\s*:\s*bearer\s+[A-Za-z0-9._~+/-]{20,}'),
    re.compile(rb'''(?i)["'](?:api[_-]?key|access_token|refresh_token|client_secret|password|private_key)["']\s*:\s*["'][^"'\r\n]{8,}'''),
]


def need(value, message):
    if not value:
        raise ValueError(message)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def parse(raw):
    def unique(items):
        output = {}
        for key, value in items:
            need(key not in output, 'duplicate JSON key')
            output[key] = value
        return output
    return json.loads(raw, object_pairs_hook=unique)


def scan(raw):
    need(not any(pattern.search(raw) for pattern in SECRET_PATTERNS), 'sensitive marker in received evidence')


def read(path, limit=MAX_FILE):
    need(path.is_absolute() and path.resolve(strict=True) == path, 'indirect local input')
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK | os.O_CLOEXEC)
    try:
        before = os.fstat(fd)
        need(stat.S_ISREG(before.st_mode) and before.st_nlink == 1 and before.st_size <= limit, 'unbounded or nonregular local input')
        with os.fdopen(os.dup(fd), 'rb') as stream:
            raw = stream.read(limit + 1)
        fields = ('st_dev', 'st_ino', 'st_size', 'st_mode', 'st_nlink', 'st_mtime_ns', 'st_ctime_ns')
        need(len(raw) == before.st_size and all(getattr(before, key) == getattr(after, key)
             for after in (os.fstat(fd), path.lstat()) for key in fields), 'local input changed')
        return raw
    finally:
        os.close(fd)


def unwrap(raw):
    value = parse(raw)
    if isinstance(value, dict) and 'result' in value:
        value = value['result']
    if isinstance(value, dict) and 'content' in value:
        need(value.get('isError', False) is False, 'recorded MCP error')
        text = [item['text'] for item in value['content'] if item.get('type') == 'text']
        need(len(text) == 1, 'ambiguous native tool result')
        value = parse(text[0])
    need(isinstance(value, dict), 'native result must be an object')
    return value


def last_json(raw):
    lines = [line for line in raw.decode('utf-8').splitlines() if line.strip()]
    need(lines, 'missing original final stdout')
    value = parse(lines[-1])
    need(isinstance(value, dict), 'final stdout is not an object')
    return value


def native_proof(status_raw, read_raw, job_id):
    status, original = unwrap(status_raw), unwrap(read_raw)
    need(status.get('job_id') == original.get('job_id') == job_id
         and status.get('state') == 'succeeded' and type(status.get('exit_code')) is int and status['exit_code'] == 0
         and all(status.get(name) is False for name in ('automatic_retry', 'timed_out', 'cancelled'))
         and all(status.get(name) is True for name in ('output_complete', 'output_durable', 'terminal_publication_confirmed'))
         and type(status.get('terminal_publication_protocol')) is int and status['terminal_publication_protocol'] == 1
         and status.get('log_synced') == {'stdout': True, 'stderr': True}
         and status.get('log_errors') == {'stdout': None, 'stderr': None}
         and status.get('log_truncated') == {'stdout': False, 'stderr': False}, 'original native terminal proof failed')
    streams = {}
    for name in ('stdout', 'stderr'):
        row = original[name]
        need(isinstance(row.get('bytes_hex'), str), 'original native byte stream missing')
        raw = bytes.fromhex(row['bytes_hex'])
        need(type(row.get('offset')) is int and row['offset'] == 0
             and type(row.get('next_offset')) is int and row['next_offset'] == len(raw)
             and type(row.get('size')) is int and row['size'] == len(raw)
             and row.get('eof') is True and row.get('text') == raw.decode('utf-8')
             and status['log_bytes'][name] == {'seen': len(raw), 'stored': len(raw)}
             and all(type(value) is int for value in status['log_bytes'][name].values()), 'native stream is partial or inconsistent')
        scan(raw)
        streams[name] = raw
    return streams


def transport(rows, files, expected_versions):
    """Validate original successful read_multiple_files request/reply envelopes."""
    found = {}
    for raw in rows:
        envelope = parse(raw)
        request = envelope['request']
        need(request.get('host') == 'main' and 1 <= len(request['paths']) <= 4
             and len(set(request['paths'])) == len(request['paths'])
             and 1 <= request.get('max_file_bytes', 16384) <= 65536
             and 1024 <= request.get('max_response_bytes', 65536) <= 262144, 'unbounded or wrong-host transport request')
        result = unwrap(json.dumps(envelope['result']))
        need(result.get('truncated') is False and result.get('encoding') == 'utf-8'
             and result.get('atomic_snapshot') is False and result.get('snapshot_scope') == 'independent_file',
             'transport result is truncated or lacks independent-file provenance')
        returned = result['files']
        need(len(returned) == len(request['paths']) and {row['path'] for row in returned} == set(request['paths']),
             'transport returned a different file set')
        for row in returned:
            path = row['path']
            need(path.startswith(REMOTE + '/'), 'transport path is outside fixed exporter')
            name = path[len(REMOTE) + 1:]
            need(name in files and row.get('eof') is True and isinstance(row.get('text'), str), 'unexpected or incomplete transported file')
            raw_file = row['text'].encode('utf-8')
            need(type(row.get('size')) is int and row['size'] == len(raw_file) <= 65536
                 and row.get('sha256') == sha(raw_file) and raw_file == files[name]
                 and row.get('version') == expected_versions[name] and VERSION.fullmatch(row['version'])
                 and int(row['version'].split(':')[2]) == len(raw_file), 'transported bytes, SHA or pinned version differ')
            identity = {key: row[key] for key in ('path', 'size', 'sha256', 'version')}
            need(name not in found or found[name] == identity, 'repeated transport observed changing input')
            found[name] = identity
    need(set(found) == set(files), 'not every received text file has an original pinned transport receipt')
    return found


def restore_archive(raw, manifest_raw, records):
    need(0 < len(raw) <= 48000 * 128, 'archive exceeds fixed chunk budget')
    by_name = {row['path']: row for row in records}
    need(len(by_name) == len(records) <= 300, 'duplicate or excessive archive inventory')
    restored = {}
    total = 0
    with tarfile.open(fileobj=io.BytesIO(raw), mode='r:gz') as archive:
        for member in archive:
            path = PurePosixPath(member.name)
            need(not path.is_absolute() and str(path) == member.name and all(part not in ('', '.', '..') for part in path.parts)
                 and member.isfile() and not member.issym() and not member.islnk() and not member.sparse
                 and not member.pax_headers and member.mode == 0o600 and member.name not in restored
                 and 0 <= member.size <= MAX_FILE and member.name in set(by_name) | {'_export-manifest.json'},
                 'unsafe, duplicated or unexpected archive member')
            total += member.size
            need(total <= MAX_TOTAL and len(restored) < 301, 'expanded archive exceeds fixed bounds')
            content = archive.extractfile(member).read(MAX_FILE + 1)
            need(len(content) == member.size, 'archive member is truncated')
            scan(content)
            if member.name == '_export-manifest.json':
                need(content == manifest_raw, 'embedded and external manifests differ')
            else:
                row = by_name[member.name]
                need(type(row['bytes']) is int and row['bytes'] == len(content) and row['sha256'] == sha(content), 'archive member identity differs')
            restored[member.name] = content
    need(set(restored) == set(by_name) | {'_export-manifest.json'}, 'archive does not contain the complete exact manifest')
    return restored


def original_paths(records):
    uid = set()
    for row in records:
        name = row['path']
        if name.startswith('native-decoded/'):
            match = re.fullmatch(r'native-decoded/(observation|lifecycle)\.(stdout|stderr)', name)
            need(match is not None and row.get('derived_from') == 'native/' + match[1] + '-read.json'
                 and row.get('mode') == 0o600 and 'original_path' not in row, 'invalid decoded native stream provenance')
            continue
        if name.startswith('holders/'):
            parts = name.split('/')
            need(len(parts) == 3 and parts[1] in PINS and LOG.fullmatch(parts[2]), 'unsafe original holder member')
            expected = WORK + '/hepta-runtime-r25-' + parts[1] + '-evidence-02/' + parts[2]
        elif name == 'sources/held_agent_campaign_02.py':
            expected = HOLDER
        elif name in ('sources/observation-campaign.py', 'sources/lifecycle-campaign.py'):
            expected = WORK + '/hepta-runtime-r25-' + name.split('/')[1]
            expected = expected.replace('-campaign.py', '-campaign-02.py')
        elif name in ('tools/export_mac_holders_02.py', 'tools/verify_mac_holders_02.py'):
            expected = TOOLS + '/' + name.split('/')[1]
        elif re.fullmatch(r'native/(observation|lifecycle)-(terminal|read)\.json', name):
            expected = NATIVE_INPUTS + '/' + name.split('/')[1]
        else:
            raise ValueError('unexpected original source member')
        need(row.get('original_path') == expected, 'captured source path differs')
        stamp = row['stamp']
        need(all(type(value) is int and value >= 0 for value in stamp.values())
             and stat.S_ISREG(stamp['st_mode']) and stamp['st_mode'] & 0o022 == 0
             and stamp['st_nlink'] == 1 and stamp['st_uid'] > 0 and stamp['st_size'] == row['bytes']
             and stat.S_IMODE(stamp['st_mode']) == row['mode'], 'captured source owner/mode/link/type/length differs')
        actual_version = ':'.join(str(stamp[key]) for key in ('st_dev', 'st_ino', 'st_size', 'st_mtime_ns', 'st_ctime_ns'))
        need(row['version'] == actual_version, 'captured source version differs from stat witness')
        uid.add(stamp['st_uid'])
    need(len(uid) == 1, 'captured files have inconsistent Mac owners')


def verify_holders(restored, manifest, jobs):
    verified = {}
    need(set(jobs) in ({'observation'}, {'observation', 'lifecycle'})
         and jobs['observation'] == '1a1aacd207e-fc05-4774'
         and len(set(jobs.values())) == len(jobs) and all(JOB.fullmatch(value) for value in jobs.values()),
         'selected original native job IDs differ')
    need(set(manifest['campaigns']) == set(jobs) and set(manifest['source_inventories']) == set(jobs), 'unselected original proof was added or omitted')
    fixed = {'sources/held_agent_campaign_02.py', 'tools/export_mac_holders_02.py', 'tools/verify_mac_holders_02.py'}
    for kind in jobs:
        fixed.add('sources/' + kind + '-campaign.py')
        fixed.update('native/' + kind + '-' + suffix + '.json' for suffix in ('terminal', 'read'))
        fixed.update('native-decoded/' + kind + '.' + suffix for suffix in ('stdout', 'stderr'))
        fixed.update(name for name in restored if name.startswith('holders/' + kind + '/'))
    need(set(restored) - {'_export-manifest.json'} == fixed, 'unselected holder data or source was added')
    for kind in jobs:
        size, digest, report_dir, gate_name = PINS[kind]
        directory = WORK + '/hepta-runtime-r25-' + kind + '-evidence-02'
        prefix = 'holders/' + kind + '/'
        files = {name[len(prefix):]: raw for name, raw in restored.items() if name.startswith(prefix)}
        report = parse(files['report.json'])
        proof = manifest['campaigns'][kind]
        need(report.get('schema') == 'hepta-x230-r21-held-agent-campaign/v1' and report.get('passed') is True
             and isinstance(report.get('finished_utc'), str) and report['finished_utc']
             and isinstance(report.get('started_utc'), str) and report['started_utc']
             and type(report.get('remote_returncode')) is int and report['remote_returncode'] == 0
             and 'error' not in report and report.get('foreground_timed_out') is not True
             and report.get('remote_completion_unknown') is not True, 'holder is incomplete or unsuccessful')
        started = datetime.datetime.fromisoformat(report['started_utc'])
        finished = datetime.datetime.fromisoformat(report['finished_utc'])
        need(started.tzinfo is not None and finished.tzinfo is not None and finished >= started, 'holder UTC interval is invalid')
        need(report.get('holder_script_sha256') == HOLDER_SHA and report.get('remote_script_sha256') == digest
             and len(files['remote-script.py']) == size and sha(files['remote-script.py']) == digest
             and files['remote-script.py'] == restored['sources/' + kind + '-campaign.py'], 'holder/source script identity differs')
        need(type(report.get('automatic_ssh_retries')) is int and report['automatic_ssh_retries'] == 0
             and all(report.get(key) is False for key in ('services_modified', 'key_bytes_retained', 'complete_environment_retained', 'ssh_configuration_dump_retained'))
             and type(report.get('timeout_seconds')) is int and report['timeout_seconds'] == 3600,
             'holder execution/retry/sensitive-input contract differs')
        need(report.get('owned_agent_reaped') is True and type(report.get('owned_agent_returncode')) is int
             and report.get('owned_agent_directory_absent_after_context') is True
             and report.get('owned_agent_socket_absent_after_context') is True,
             'original holder did not prove agent reap and path absence')
        owned_dir, owned_socket = report.get('owned_agent_directory'), report.get('owned_agent_socket')
        need(isinstance(owned_dir, str) and re.fullmatch(r'/tmp/hr19a-[A-Za-z0-9_-]+', owned_dir)
             and owned_socket == owned_dir + '/agent.sock' and proof.get('owned_directory') == owned_dir
             and proof.get('owned_socket') == owned_socket and proof.get('current_owned_directory_absent') is True
             and proof.get('current_owned_socket_absent') is True, 'exporter cleanup metadata scope differs')
        start, end = report.get('foreground_start_monotonic_ns'), report.get('foreground_end_monotonic_ns')
        need(type(start) is int and type(end) is int and end >= start
             and report.get('foreground_seconds') == (end - start) / 1e9
             and all(type(report.get(key)) is int and report[key] > 1 for key in ('foreground_pid', 'owned_agent_pid')),
             'foreground process completion fields are inconsistent')
        expected_argv = ['/usr/bin/ssh', '-A', '-T', '-o', 'BatchMode=yes', '-o', 'ConnectTimeout=10',
                         '-o', 'StrictHostKeyChecking=yes', '-o', 'ControlMaster=no', '-o', 'ControlPath=none',
                         '-o', 'ControlPersist=no', 'x230-ts', '/usr/bin/python3', '-B', '-', '--launcher-sha256', digest]
        need(report.get('foreground_argv') == expected_argv, 'foreground argv differs')
        logs = report['log_files']
        names = [row['file'] for row in logs]
        need(len(names) == len(set(names)) and set(names) == set(files) - {'report.json'}, 'original log set is incomplete')
        for row in logs:
            need(type(row.get('bytes')) is int and row['bytes'] == len(files[row['file']])
                 and row['sha256'] == sha(files[row['file']]), 'original log hashes or sizes differ')
        required = {'report.json', 'remote-script.py', 'forwarded.stdout', 'forwarded.stderr', 'owned-agent.stderr'}
        for field, count_key, label, suffixes in (
            ('identity_discovery', 'configured_target_count', 'identity-discovery', ('stderr',)),
            ('identity_loads', 'configured_identity_count', 'identity-load', ('stdout', 'stderr')),
        ):
            rows = report[field]
            count = report[count_key]
            need(type(count) is int and 1 <= count <= 64 and len(rows) == count
                 and [row['index'] for row in rows] == list(range(count)), 'identity operation sequence/count differs')
            for row in rows:
                need(type(row['returncode']) is int and row['returncode'] == 0, 'identity operation failed')
                for stream in suffixes:
                    name = f"{label}-{row['index']:02d}.{stream}"
                    required.add(name)
                    need(row[stream] == {'file': name, 'bytes': len(files[name]), 'sha256': sha(files[name])}, 'identity original stream differs')
                if field == 'identity_loads':
                    need(row['ttl_seconds'] == 3720 and type(row['start_monotonic_ns']) is int
                         and type(row['end_monotonic_ns']) is int and row['end_monotonic_ns'] >= row['start_monotonic_ns'],
                         'identity load lifetime differs')
        need(set(files) == required, 'unknown or missing original holder file')
        inventory = manifest['source_inventories'][kind]
        need(len(inventory) == len(files) and {row['name'] for row in inventory} == set(files), 'exported directory inventory differs')
        records = {row['path']: row for row in manifest['files']}
        for row in inventory:
            identity = records[prefix + row['name']]
            need(row['stamp'] == identity['stamp'] and row['version'] == identity['version'], 'directory and file identity witnesses differ')
        remote_footer = last_json(files['forwarded.stdout'])
        expected_report = '/home/qian/hepta-runtime-optimization-20261105-r25/' + report_dir + '/report.json'
        need(remote_footer.get('passed') is True and remote_footer.get('error') is None
             and remote_footer.get('report') == expected_report and type(remote_footer.get(gate_name)) is bool,
             'original forwarded terminal line differs')
        streams = native_proof(restored['native/' + kind + '-terminal.json'], restored['native/' + kind + '-read.json'], jobs[kind])
        for stream, raw in streams.items():
            need(restored['native-decoded/' + kind + '.' + stream] == raw, 'decoded native stream was substituted')
        lines = [parse(line) for line in streams['stdout'].decode().splitlines() if line.strip()]
        need(len(lines) == 2 and lines[0] == {'phase': 'owned_agent_ready', 'identity_count': report['configured_identity_count'], 'remote_script_sha256': digest}
             and lines[1] == {'passed': True, 'remote_returncode': 0, 'owned_agent_reaped': True, 'report': directory + '/report.json'},
             'original native holder output sequence differs')
        need(proof.get('job_id') == jobs[kind] and proof.get('holder_report_sha256') == sha(files['report.json'])
             and proof.get('holder_report_bytes') == len(files['report.json']) and proof.get('original_logs') == len(logs)
             and proof.get('remote_final_line') == remote_footer and proof.get('native_holder_final_line') == lines[1]
             and proof.get('started_utc') == report['started_utc'] and proof.get('finished_utc') == report['finished_utc']
             and proof.get('performance_gate_observed') is remote_footer[gate_name], 'manifest holder proof differs from original bytes')
        verified[kind] = {'job_id': jobs[kind], 'holder_report_sha256': sha(files['report.json']),
            'original_logs': len(logs), 'foreground_seconds': report['foreground_seconds'], 'performance_gate_observed': remote_footer[gate_name],
            'owned_agent_reaped': True, 'owned_paths_absent_as_recorded': True,
            'started_utc': report['started_utc'], 'finished_utc': report['finished_utc'],
            'native_stdout_bytes': len(streams['stdout']), 'native_stderr_bytes': len(streams['stderr'])}
    if 'lifecycle' in verified:
        need(datetime.datetime.fromisoformat(verified['lifecycle']['started_utc']) >=
             datetime.datetime.fromisoformat(verified['observation']['finished_utc']), 'original Mac holders overlap')
    return verified


def write_new(path, raw):
    with path.open('xb') as stream:
        stream.write(raw)
        stream.flush()
        os.fsync(stream.fileno())


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, required=True)
    parser.add_argument('--campaign', choices=('observation', 'both'), required=True)
    parser.add_argument('--lifecycle-job-id')
    for name in ('receipt-sha256', 'receipt-version', 'exporter-sha256', 'verifier-sha256', 'observation-job-id'):
        parser.add_argument('--' + name, required=True)
    args = parser.parse_args()
    selected = ['observation'] if args.campaign == 'observation' else ['observation', 'lifecycle']
    need((args.lifecycle_job_id is None) if args.campaign == 'observation' else isinstance(args.lifecycle_job_id, str),
         'only selected actual lifecycle native ID may be supplied')
    root = args.root.absolute()
    need(root.resolve(strict=True) == root and root.is_dir(), 'canonical received directory required')
    need(all(HEX.fullmatch(value) for name, value in vars(args).items() if name.endswith('_sha256'))
         and VERSION.fullmatch(args.receipt_version), 'invalid external identity pin')
    need(sha(read(Path(__file__).absolute())) == args.verifier_sha256, 'local verifier is not the reviewed source')
    destination, audit_path, archive_path = root / 'extracted-02', root / 'independent-verification-02.json', root / 'holder-evidence-02.tar.gz'
    need(not any(os.path.lexists(path) for path in (destination, audit_path, archive_path)), 'fresh verification outputs required')
    text_files = {name: read(root / name, 65536) for name in ('receipt.json', 'manifest.json', 'chunks-manifest.json')}
    receipt, manifest, chunks = (parse(text_files[name]) for name in ('receipt.json', 'manifest.json', 'chunks-manifest.json'))
    need(sha(text_files['receipt.json']) == args.receipt_sha256, 'actual exporter receipt SHA differs')
    need(receipt.get('schema') == 'hepta-r25-mac-holder-export-receipt/v1' and receipt.get('attempt') == '02'
         and receipt.get('passed') is True and receipt.get('source_inputs_unchanged') is True
         and receipt.get('included_original_holders_complete') is True and receipt.get('campaign_names') == selected
         and receipt.get('automatic_retries') == 0,
         'exporter receipt is not complete and successful')
    need(manifest.get('schema') == 'hepta-r25-mac-holder-export/v1' and manifest.get('attempt') == '02'
         and manifest.get('included_original_holders_complete') is True and manifest.get('campaign_names') == selected
         and manifest.get('sensitive_marker_scan', {}).get('passed') is True
         and manifest.get('new_ssh_workload_cleanup_or_service_operation') is False and manifest.get('automatic_retries') == 0,
         'manifest scope or completion differs')
    need(all(value.get('runtime_adoption_assessed') is False and value.get('x230_report_bytes_read') is False for value in (receipt, manifest))
         and manifest.get('cross_package_report_binding_required') is True and manifest.get('hosted_actions_passed') is False,
         'export falsely broadens its scope')
    need(receipt['exporter_sha256'] == args.exporter_sha256 and receipt['verifier_sha256'] == args.verifier_sha256,
         'exported tool identities differ')
    versions = {'receipt.json': args.receipt_version}
    for key, name in (('manifest', 'manifest.json'), ('chunks_manifest', 'chunks-manifest.json')):
        row = receipt[key]
        need(row['original_path'] == REMOTE + '/' + name and row['bytes'] == len(text_files[name])
             and row['sha256'] == sha(text_files[name]), 'receipt metadata binding differs')
        versions[name] = row['version']
    need(chunks.get('schema') == 'hepta-r25-mac-holder-text-chunks/v1' and chunks.get('chunk_bytes') == 48000
         and 1 <= len(chunks['chunks']) <= 128 and chunks['archive'] == receipt['archive'], 'chunk contract or original archive binding differs')
    pieces, offset = [], 0
    for index, row in enumerate(chunks['chunks']):
        name = f'chunks/chunk-{index:04d}.b64'
        need(row['path'] == name and row['offset'] == offset and 0 < row['bytes'] <= 48000
             and (index == len(chunks['chunks']) - 1 or row['bytes'] == 48000), 'chunk sequence or boundary differs')
        raw = read(root / name, 64000)
        decoded = base64.b64decode(raw, validate=True)
        need(base64.b64encode(decoded) == raw and len(decoded) == row['bytes'] and sha(decoded) == row['sha256']
             and len(raw) == row['text_bytes'] and sha(raw) == row['text_sha256'], 'text chunk bytes differ')
        text_files[name], versions[name] = raw, row['version']
        pieces.append(decoded)
        offset += len(decoded)
    need({path.name for path in (root / 'chunks').iterdir()} == {Path(name).name for name in text_files if name.startswith('chunks/')},
         'unexpected received chunk')
    archive_raw = b''.join(pieces)
    need(receipt['archive']['original_path'] == REMOTE + '/holder-evidence-02.tar.gz'
         and offset == receipt['archive']['bytes'] and sha(archive_raw) == receipt['archive']['sha256'], 'reassembled archive differs')
    operation_paths = sorted((root / 'operations').glob('read-*.json'))
    need(operation_paths and all(re.fullmatch(r'read-[0-9]{4}\.json', path.name) for path in operation_paths), 'original transport envelopes absent')
    operation_raw = [read(path) for path in operation_paths]
    transported = transport(operation_raw, text_files, versions)
    restored = restore_archive(archive_raw, text_files['manifest.json'], manifest['files'])
    need(receipt['files'] == len(manifest['files']) and receipt['archive_members'] == len(restored), 'archive member counts differ')
    original_paths(manifest['files'])
    need((len(restored['sources/held_agent_campaign_02.py']), sha(restored['sources/held_agent_campaign_02.py'])) == (11374, HOLDER_SHA), 'holder source pin differs')
    need(sha(restored['tools/export_mac_holders_02.py']) == args.exporter_sha256
         and sha(restored['tools/verify_mac_holders_02.py']) == args.verifier_sha256, 'archived tool bytes differ')
    need(manifest.get('source_script_pins') == {'holder': [11374, HOLDER_SHA],
         'exporter_sha256': args.exporter_sha256, 'verifier_sha256': args.verifier_sha256}, 'manifest source pin declarations differ')
    need(set(manifest['fixed_plans']) == set(selected), 'manifest fixed plans include an unselected campaign')
    jobs = {'observation': args.observation_job_id}
    if 'lifecycle' in selected:
        jobs['lifecycle'] = args.lifecycle_job_id
    need(receipt['original_jobs'] == jobs, 'receipt original native IDs differ')
    verified = verify_holders(restored, manifest, jobs)
    need(receipt['holder_report_sha256'] == {key: row['holder_report_sha256'] for key, row in verified.items()}, 'receipt report identities differ')
    for name, raw in text_files.items():
        need(read(root / name, 65536) == raw, 'received text input changed during audit')
    need([read(path) for path in operation_paths] == operation_raw, 'original transport envelope changed during audit')
    os.umask(0o077)
    write_new(archive_path, archive_raw)
    destination.mkdir(mode=0o700)
    for name, raw in sorted(restored.items()):
        path = destination.joinpath(*PurePosixPath(name).parts)
        path.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
        write_new(path, raw)
    need({path.relative_to(destination).as_posix() for path in destination.rglob('*') if path.is_file()} == set(restored)
         and all(read(destination / name) == raw for name, raw in restored.items()), 'fresh restore bytes differ')
    result = {'schema': 'hepta-r25-mac-holder-offline-audit/v1', 'passed': True, 'campaign_names': selected,
        'finished_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'campaigns': verified,
        'archive_sha256': sha(archive_raw), 'archive_bytes': len(archive_raw), 'archive_members': len(restored),
        'receipt_sha256': args.receipt_sha256, 'receipt_version': args.receipt_version,
        'manifest_sha256': sha(text_files['manifest.json']), 'chunks': len(pieces), 'transported_files': transported,
        'source_tool_sha256': args.verifier_sha256, 'remote_operations': 0, 'archived_code_executed': False,
        'current_mac_cleanup_probed': False, 'cleanup_scope': 'source-bound holder evidence and exporter original Mac metadata witness',
        'x230_report_bytes_read': False, 'cross_package_report_binding_required': True, 'runtime_adoption_assessed': False}
    write_new(audit_path, (json.dumps(result, sort_keys=True, indent=2) + '\n').encode())
    print(json.dumps({'passed': True, 'audit': str(audit_path), 'audit_sha256': sha(read(audit_path)),
                      'archive_sha256': sha(archive_raw), 'archive_members': len(restored)}, sort_keys=True))
    return 0


if __name__ == '__main__':
    try:
        raise SystemExit(main())
    except Exception as error:
        print(json.dumps({'passed': False, 'error_type': type(error).__name__, 'reason': str(error), 'remote_operations': 0}), flush=True)
        raise SystemExit(1)
