#!/usr/bin/env python3
# Copyright 2026 TrillionniumFoundation; SPDX-License-Identifier: Apache-2.0
"""Export selected closed original R25 Mac holders. No SSH, workload or cleanup.

A completed observation performance rejection remains a rejection in this export.
Unselected or nonexistent lifecycle evidence is neither read nor synthesized.
"""
import argparse
import base64
import datetime
import gzip
import hashlib
import io
import json
import os
from pathlib import Path
import re
import stat
import sys
import tarfile

sys.dont_write_bytecode = True
WORK = Path('/Users/qianqi/work')
INPUTS = WORK / 'hepta-runtime-r25-mac-holder-inputs-02'
TOOLS = WORK / 'hepta-runtime-r25-mac-evidence-tools-02'
OUT = WORK / 'hepta-runtime-r25-mac-holder-export-02'
HOLDER = WORK / 'hepta-runtime-x230-r21-20261105/held_agent_campaign_02.py'
HOLDER_PIN = (11374, '715e996217c7d33a7483354f16f2d39c9a033f51f3a20a52484495a00262dd65')
PLANS = {
    'observation': {
        'directory': str(WORK / 'hepta-runtime-r25-observation-evidence-02'),
        'script': str(WORK / 'hepta-runtime-r25-observation-campaign-02.py'),
        'script_bytes': 38105,
        'script_sha256': '304d3af82dc3f544dd25fc6f576af288852b7b46b7532aebe73f1351d4788ddc',
        'remote_report': '/home/qian/hepta-runtime-optimization-20261105-r25/campaign-02/report.json',
        'footer_gate': 'observation_gate_passed',
        'known_job_id': '1a1aacd207e-fc05-4774',
    },
    'lifecycle': {
        'directory': str(WORK / 'hepta-runtime-r25-lifecycle-evidence-02'),
        'script': str(WORK / 'hepta-runtime-r25-lifecycle-campaign-02.py'),
        'script_bytes': 25412,
        'script_sha256': '0ed646ca0fe9425f5ab04bf430b499e6143ea722f2fd6395eff0d51cf3f556ff',
        'remote_report': '/home/qian/hepta-runtime-optimization-20261105-r25/lifecycle-campaign-02/report.json',
        'footer_gate': 'adoption_passed',
        'known_job_id': None,
    },
}
HEX = re.compile(r'[0-9a-f]{64}\Z')
JOB = re.compile(r'[0-9a-f]{11,16}-[0-9a-f]{4}-[0-9a-f]{4}\Z')
LOG_NAME = re.compile(r'(?:report\.json|remote-script\.py|forwarded\.(?:stdout|stderr)|owned-agent\.stderr|'
                      r'identity-discovery-[0-9]{2,}\.stderr|identity-load-[0-9]{2,}\.(?:stdout|stderr))\Z')
MAX_FILE = 32 * 1024 * 1024
MAX_TOTAL = 128 * 1024 * 1024
CHUNK_BYTES = 48000
MAX_CHUNKS = 128
SECRET_RULES = [
    ('private_key_pem', re.compile(b'-----BEGIN ' + b'(?:OPENSSH |RSA |EC |DSA |ENCRYPTED )?' + b'PRIVATE ' + b'KEY-----')),
    ('github_token', re.compile(rb'\bgh[pousr]_[A-Za-z0-9]{30,}\b')),
    ('github_fine_grained_token', re.compile(rb'\bgithub_pat_[A-Za-z0-9_]{40,}\b')),
    ('api_secret_token', re.compile(rb'\bsk-(?:proj-|svcacct-)?[A-Za-z0-9_-]{32,}\b')),
    ('authorization_bearer', re.compile(rb'(?i)\bauthorization\s*:\s*bearer\s+[A-Za-z0-9._~+/-]{20,}')),
    ('named_secret_value', re.compile(rb'''(?i)["'](?:api[_-]?key|access_token|refresh_token|client_secret|password|private_key)["']\s*:\s*["'][^"'\r\n]{8,}''')),
]


def need(value, message):
    if not value:
        raise ValueError(message)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def encode(value):
    return (json.dumps(value, sort_keys=True, separators=(',', ':')) + '\n').encode()


def parse(raw):
    def unique(pairs):
        value = {}
        for key, item in pairs:
            need(key not in value, 'duplicate JSON key')
            value[key] = item
        return value
    return json.loads(raw, object_pairs_hook=unique)


def scan(raw):
    for label, pattern in SECRET_RULES:
        need(pattern.search(raw) is None, 'sensitive marker rejected: ' + label)


def stamp(info):
    return {key: getattr(info, key) for key in ('st_dev', 'st_ino', 'st_uid', 'st_gid', 'st_mode',
            'st_nlink', 'st_size', 'st_mtime_ns', 'st_ctime_ns')}


def version(info):
    return ':'.join(str(getattr(info, key)) for key in ('st_dev', 'st_ino', 'st_size', 'st_mtime_ns', 'st_ctime_ns'))


def directory(path):
    need(path.is_absolute() and path.resolve(strict=True) == path, 'indirect directory')
    info = path.lstat()
    need(stat.S_ISDIR(info.st_mode) and info.st_uid == os.geteuid() and info.st_mode & 0o022 == 0,
         'directory owner/mode/type differs')
    return stamp(info)


def read(path, *, text_scan=True):
    need(path.is_absolute() and path.resolve(strict=True) == path, 'indirect input')
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK | os.O_CLOEXEC)
    try:
        before = os.fstat(fd)
        need(stat.S_ISREG(before.st_mode) and before.st_nlink == 1 and before.st_uid == os.geteuid()
             and before.st_mode & 0o022 == 0 and before.st_size <= MAX_FILE, 'input owner/mode/type/link/size differs')
        with os.fdopen(os.dup(fd), 'rb') as stream:
            raw = stream.read(MAX_FILE + 1)
        need(len(raw) == before.st_size and stamp(before) == stamp(os.fstat(fd)) == stamp(path.lstat()),
             'input changed during read')
        if text_scan:
            scan(raw)
        return raw, {'original_path': str(path), 'bytes': len(raw), 'sha256': sha(raw),
                     'mode': stat.S_IMODE(before.st_mode), 'version': version(before), 'stamp': stamp(before)}
    finally:
        os.close(fd)


def inventory(path):
    directory(path)
    rows = []
    for child in sorted(path.iterdir()):
        info = child.lstat()
        need(LOG_NAME.fullmatch(child.name) and stat.S_ISREG(info.st_mode), 'unexpected holder entry; contents not read')
        rows.append({'name': child.name, 'stamp': stamp(info), 'version': version(info)})
    need(4 <= len(rows) <= 128, 'holder inventory exceeds fixed bounds')
    return rows


def absent(path):
    try:
        os.lstat(path)
    except FileNotFoundError:
        return True
    return False


def tool_value(raw):
    value = parse(raw)
    if isinstance(value, dict) and 'result' in value:
        value = value['result']
    if isinstance(value, dict) and 'content' in value:
        need(value.get('isError', False) is False, 'native tool returned an error')
        texts = [block['text'] for block in value['content'] if block.get('type') == 'text']
        need(len(texts) == 1, 'native tool envelope is ambiguous')
        value = parse(texts[0])
    need(isinstance(value, dict), 'native evidence is not an object')
    return value


def terminal(value, job_id):
    need(value.get('job_id') == job_id and value.get('state') == 'succeeded'
         and type(value.get('exit_code')) is int and value['exit_code'] == 0
         and all(value.get(key) is False for key in ('automatic_retry', 'timed_out', 'cancelled'))
         and all(value.get(key) is True for key in ('output_complete', 'output_durable', 'terminal_publication_confirmed'))
         and type(value.get('terminal_publication_protocol')) is int and value['terminal_publication_protocol'] == 1
         and value.get('log_synced') == {'stdout': True, 'stderr': True}
         and value.get('log_errors') == {'stdout': None, 'stderr': None}
         and value.get('log_truncated') == {'stdout': False, 'stderr': False},
         'original native job lacks successful complete durable terminal proof')


def native_streams(value, status, job_id):
    need(value.get('job_id') == job_id, 'native read belongs to another job')
    streams = {}
    for key in ('stdout', 'stderr'):
        row = value[key]
        need(isinstance(row.get('bytes_hex'), str), 'original native bytes are absent')
        raw = bytes.fromhex(row['bytes_hex'])
        need(type(row.get('size')) is int and row['size'] == len(raw)
             and type(row.get('offset')) is int and row['offset'] == 0
             and type(row.get('next_offset')) is int and row['next_offset'] == len(raw)
             and row.get('eof') is True and row.get('text') == raw.decode('utf-8'),
             'native stream is partial or decoded bytes differ')
        need(status['log_bytes'][key] == {'seen': len(raw), 'stored': len(raw)}
             and all(type(value) is int for value in status['log_bytes'][key].values()), 'native terminal byte count differs')
        scan(raw)
        streams[key] = raw
    return streams


def footer(raw):
    lines = [line for line in raw.decode('utf-8').splitlines() if line.strip()]
    need(lines, 'original stdout has no final nonempty line')
    value = parse(lines[-1])
    need(isinstance(value, dict), 'final stdout line is not an object')
    return value


def validate_holder(kind, files, status, streams, expected_report_sha, job_id):
    plan = PLANS[kind]
    need(JOB.fullmatch(job_id) and (plan['known_job_id'] is None or plan['known_job_id'] == job_id), 'original job identity differs')
    terminal(status, job_id)
    need(sha(files['report.json']) == expected_report_sha, 'actual holder report SHA differs')
    report = parse(files['report.json'])
    need(report.get('schema') == 'hepta-x230-r21-held-agent-campaign/v1' and report.get('passed') is True
         and isinstance(report.get('finished_utc'), str) and report['finished_utc']
         and isinstance(report.get('started_utc'), str) and report['started_utc']
         and type(report.get('remote_returncode')) is int and report['remote_returncode'] == 0
         and 'error' not in report and report.get('foreground_timed_out') is not True
         and report.get('remote_completion_unknown') is not True, 'holder is not a completed successful original')
    started = datetime.datetime.fromisoformat(report['started_utc'])
    finished = datetime.datetime.fromisoformat(report['finished_utc'])
    need(started.tzinfo is not None and finished.tzinfo is not None and finished >= started, 'holder UTC interval is invalid')
    need(report.get('holder_script_sha256') == HOLDER_PIN[1]
         and report.get('remote_script_sha256') == plan['script_sha256']
         and len(files['remote-script.py']) == plan['script_bytes'] and sha(files['remote-script.py']) == plan['script_sha256'],
         'holder or remote script identity differs')
    need(type(report.get('automatic_ssh_retries')) is int and report['automatic_ssh_retries'] == 0
         and report.get('services_modified') is False and report.get('key_bytes_retained') is False
         and report.get('complete_environment_retained') is False and report.get('ssh_configuration_dump_retained') is False,
         'holder retry/service/sensitive-data contract differs')
    need(report.get('timeout_seconds') == 3600 and type(report['timeout_seconds']) is int,
         'holder time bound differs from original attempt02')
    need(report.get('owned_agent_reaped') is True and type(report.get('owned_agent_returncode')) is int
         and report.get('owned_agent_directory_absent_after_context') is True
         and report.get('owned_agent_socket_absent_after_context') is True, 'owned agent cleanup is unproved')
    start, end = report.get('foreground_start_monotonic_ns'), report.get('foreground_end_monotonic_ns')
    need(type(start) is int and type(end) is int and end >= start
         and report.get('foreground_seconds') == (end - start) / 1e9
         and type(report.get('foreground_pid')) is int and report['foreground_pid'] > 1
         and type(report.get('owned_agent_pid')) is int and report['owned_agent_pid'] > 1,
         'original foreground/agent process completion fields differ')
    owned_dir, owned_socket = report.get('owned_agent_directory'), report.get('owned_agent_socket')
    need(isinstance(owned_dir, str) and re.fullmatch(r'/tmp/hr19a-[A-Za-z0-9_-]+', owned_dir)
         and owned_socket == owned_dir + '/agent.sock', 'owned cleanup paths are outside holder scope')
    expected_argv = ['/usr/bin/ssh', '-A', '-T', '-o', 'BatchMode=yes', '-o', 'ConnectTimeout=10',
                     '-o', 'StrictHostKeyChecking=yes', '-o', 'ControlMaster=no', '-o', 'ControlPath=none',
                     '-o', 'ControlPersist=no', 'x230-ts', '/usr/bin/python3', '-B', '-', '--launcher-sha256', plan['script_sha256']]
    need(report.get('foreground_argv') == expected_argv, 'original foreground invocation differs')
    logs = report.get('log_files')
    need(isinstance(logs, list) and all(isinstance(row, dict) for row in logs), 'holder log inventory absent')
    names = [row.get('file') for row in logs]
    need(len(names) == len(set(names)) and set(names) == set(files) - {'report.json'}, 'holder log inventory is incomplete or duplicated')
    for row in logs:
        raw = files[row['file']]
        need(row.get('bytes') == len(raw) and type(row.get('bytes')) is int and row.get('sha256') == sha(raw), 'original log bytes differ')
    required = {'report.json', 'remote-script.py', 'forwarded.stdout', 'forwarded.stderr', 'owned-agent.stderr'}
    for group, count_key, prefix, suffixes in (
        ('identity_discovery', 'configured_target_count', 'identity-discovery', ('stderr',)),
        ('identity_loads', 'configured_identity_count', 'identity-load', ('stdout', 'stderr')),
    ):
        rows = report.get(group)
        count = report.get(count_key)
        need(type(count) is int and 1 <= count <= 64 and isinstance(rows, list) and len(rows) == count, 'identity operation count differs')
        need([row.get('index') for row in rows] == list(range(count)), 'identity operation sequence differs')
        for row in rows:
            need(type(row.get('returncode')) is int and row['returncode'] == 0, 'identity operation failed')
            for stream in suffixes:
                name = f"{prefix}-{row['index']:02d}.{stream}"
                required.add(name)
                raw = files[name]
                need(row.get(stream) == {'file': name, 'bytes': len(raw), 'sha256': sha(raw)}, 'identity stream bytes differ')
            if group == 'identity_loads':
                need(row.get('ttl_seconds') == 3720 and type(row.get('start_monotonic_ns')) is int
                     and type(row.get('end_monotonic_ns')) is int and row['end_monotonic_ns'] >= row['start_monotonic_ns'],
                     'identity TTL or operation timing differs')
    need(set(files) == required, 'unrecognized or missing original holder log')
    remote_footer = footer(files['forwarded.stdout'])
    need(remote_footer.get('passed') is True and remote_footer.get('error') is None
         and remote_footer.get('report') == plan['remote_report'] and type(remote_footer.get(plan['footer_gate'])) is bool,
         'remote final stdout does not close the exact original report')
    holder_footer = footer(streams['stdout'])
    need(holder_footer == {'passed': True, 'remote_returncode': 0, 'owned_agent_reaped': True,
                           'report': plan['directory'] + '/report.json'}, 'native holder final stdout differs')
    ready_lines = [parse(line) for line in streams['stdout'].decode().splitlines() if line.strip()]
    need(len(ready_lines) == 2 and ready_lines[0] == {'phase': 'owned_agent_ready',
         'identity_count': report['configured_identity_count'], 'remote_script_sha256': plan['script_sha256']},
         'native holder original ready/final sequence differs')
    return {'job_id': job_id, 'holder_report_sha256': sha(files['report.json']),
            'holder_report_bytes': len(files['report.json']), 'remote_final_line': remote_footer,
            'native_holder_final_line': holder_footer, 'owned_directory': owned_dir, 'owned_socket': owned_socket,
            'original_logs': len(logs), 'foreground_seconds': report['foreground_seconds'],
            'started_utc': report['started_utc'], 'finished_utc': report['finished_utc'],
            'performance_gate_observed': remote_footer[plan['footer_gate']]}


def write_new(path, raw):
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW | os.O_CLOEXEC, 0o600)
    with os.fdopen(fd, 'wb') as stream:
        stream.write(raw)
        stream.flush()
        os.fsync(stream.fileno())


def archive(path, payloads, manifest_raw):
    with path.open('xb') as stream:
        with gzip.GzipFile(fileobj=stream, mode='wb', filename='', mtime=0, compresslevel=9) as compressed:
            with tarfile.open(fileobj=compressed, mode='w', format=tarfile.PAX_FORMAT) as tar:
                for name, raw in [('_export-manifest.json', manifest_raw)] + sorted(payloads.items()):
                    member = tarfile.TarInfo(name)
                    member.size, member.mode, member.mtime = len(raw), 0o600, 0
                    member.uid = member.gid = 0
                    member.uname = member.gname = ''
                    tar.addfile(member, io.BytesIO(raw))
        stream.flush()
        os.fsync(stream.fileno())


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--campaign', choices=('observation', 'both'), required=True)
    for kind in PLANS:
        parser.add_argument('--' + kind + '-job-id', required=(kind == 'observation'))
        for value in ('report', 'terminal', 'read'):
            parser.add_argument('--' + kind + '-' + value + '-sha256', required=(kind == 'observation'))
    parser.add_argument('--exporter-sha256', required=True)
    parser.add_argument('--verifier-sha256', required=True)
    args = parser.parse_args()
    need(sys.platform == 'darwin' and os.geteuid() != 0, 'native nonroot Mac required')
    values = vars(args)
    selected = ['observation'] if args.campaign == 'observation' else ['observation', 'lifecycle']
    for kind in PLANS:
        fields = [kind + '_job_id'] + [kind + '_' + item + '_sha256' for item in ('report', 'terminal', 'read')]
        if kind in selected:
            need(all(isinstance(values[name], str) and values[name] for name in fields), 'selected original requires actual native ID and evidence hashes')
        else:
            need(all(values[name] is None for name in fields), 'unselected lifecycle inputs must not be supplied or assumed')
    need(all(HEX.fullmatch(value) for name, value in values.items() if name.endswith('_sha256') and value is not None), 'invalid required SHA256')
    need(len({values[kind + '_job_id'] for kind in selected}) == len(selected), 'selected original native jobs must differ')
    directory(WORK)
    directory(INPUTS)
    directory(TOOLS)
    need(Path(__file__).absolute() == TOOLS / 'export_mac_holders_02.py', 'exporter must be installed at the reviewed ordinary-file path')
    need(not os.path.lexists(OUT), 'original export directory already exists; do not replay')
    expected_inputs = {kind + '-' + suffix + '.json' for kind in selected for suffix in ('terminal', 'read')}
    need({path.name for path in INPUTS.iterdir()} == expected_inputs, 'staged native evidence set differs')
    payloads, identities, originals, inventories, proofs = {}, {}, {}, {}, {}

    def retain(path, member):
        need(member not in payloads, 'duplicate archive member')
        raw, identity = read(path)
        need(sum(len(item) for item in payloads.values()) + len(raw) <= MAX_TOTAL, 'bounded evidence total exceeded')
        payloads[member], identities[member], originals[member] = raw, identity, path
        return raw

    retain(HOLDER, 'sources/held_agent_campaign_02.py')
    need((len(payloads['sources/held_agent_campaign_02.py']), sha(payloads['sources/held_agent_campaign_02.py'])) == HOLDER_PIN,
         'actual holder source differs')
    for name, pin in [('export_mac_holders_02.py', args.exporter_sha256), ('verify_mac_holders_02.py', args.verifier_sha256)]:
        need(sha(retain(TOOLS / name, 'tools/' + name)) == pin, 'reviewed exporter/verifier source differs')
    for kind in selected:
        plan = PLANS[kind]
        script = retain(Path(plan['script']), 'sources/' + kind + '-campaign.py')
        need((len(script), sha(script)) == (plan['script_bytes'], plan['script_sha256']), 'installed remote script differs')
        path = Path(plan['directory'])
        inventories[kind] = inventory(path)
        files = {row['name']: retain(path / row['name'], 'holders/' + kind + '/' + row['name']) for row in inventories[kind]}
        native = {}
        for suffix in ('terminal', 'read'):
            member = 'native/' + kind + '-' + suffix + '.json'
            raw = retain(INPUTS / (kind + '-' + suffix + '.json'), member)
            need(sha(raw) == values[kind + '_' + suffix + '_sha256'], 'actual native evidence SHA differs')
            native[suffix] = tool_value(raw)
        job_id = values[kind + '_job_id']
        terminal(native['terminal'], job_id)
        streams = native_streams(native['read'], native['terminal'], job_id)
        proofs[kind] = validate_holder(kind, files, native['terminal'], streams, values[kind + '_report_sha256'], job_id)
        for stream, raw in streams.items():
            member = 'native-decoded/' + kind + '.' + stream
            payloads[member] = raw
            identities[member] = {'bytes': len(raw), 'sha256': sha(raw), 'mode': 0o600,
                'derived_from': 'native/' + kind + '-read.json', 'derivation': 'strict original bytes_hex decode; no inferred or substituted bytes'}
        proofs[kind]['current_owned_directory_absent'] = absent(proofs[kind]['owned_directory'])
        proofs[kind]['current_owned_socket_absent'] = absent(proofs[kind]['owned_socket'])
        need(proofs[kind]['current_owned_directory_absent'] and proofs[kind]['current_owned_socket_absent'], 'owned agent path remains at export')
    if 'lifecycle' in selected:
        need(datetime.datetime.fromisoformat(proofs['lifecycle']['started_utc']) >=
             datetime.datetime.fromisoformat(proofs['observation']['finished_utc']), 'original Mac holder intervals overlap')
    need(sum(len(raw) for raw in payloads.values()) <= MAX_TOTAL, 'total with exact native decoded streams exceeds bound')

    def unchanged():
        need({path.name for path in INPUTS.iterdir()} == expected_inputs, 'native evidence inventory changed')
        for member, path in originals.items():
            raw, identity = read(path)
            need(raw == payloads[member] and identity == identities[member], 'captured original changed before export completion')
        for kind in selected:
            plan = PLANS[kind]
            need(inventory(Path(plan['directory'])) == inventories[kind], 'holder directory inventory changed')
            need(absent(proofs[kind]['owned_directory']) and absent(proofs[kind]['owned_socket']), 'owned agent absence no longer confirmed')

    unchanged()
    manifest = {'schema': 'hepta-r25-mac-holder-export/v1', 'attempt': '02',
        'created_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'included_original_holders_complete': True, 'campaign_names': selected,
        'campaigns': proofs, 'fixed_plans': {kind: PLANS[kind] for kind in selected},
        'files': [{'path': member, **identity} for member, identity in sorted(identities.items())],
        'source_inventories': inventories, 'source_script_pins': {'holder': HOLDER_PIN,
            'exporter_sha256': args.exporter_sha256, 'verifier_sha256': args.verifier_sha256},
        'sensitive_marker_scan': {'passed': True, 'rules': [name for name, _ in SECRET_RULES]},
        'x230_report_bytes_read': False, 'cross_package_report_binding_required': True,
        'runtime_adoption_assessed': False, 'hosted_actions_passed': False,
        'foreground_reap_scope': 'Source-bound original holder communicate()/returncode and terminal native job; no invented separate foreground reaped field.',
        'native_stream_scope': 'Every selected original process_read DTO is retained; exact stdout/stderr decoded from original bytes_hex, including observed empty streams.',
        'new_ssh_workload_cleanup_or_service_operation': False, 'automatic_retries': 0}
    manifest_raw = encode(manifest)
    need(len(manifest_raw) <= 65536, 'manifest exceeds one bounded text read')
    scan(manifest_raw)
    os.umask(0o077)
    OUT.mkdir(mode=0o700)
    write_new(OUT / 'manifest.json', manifest_raw)
    archive_path = OUT / 'holder-evidence-02.tar.gz'
    archive(archive_path, payloads, manifest_raw)
    archive_raw, archive_identity = read(archive_path, text_scan=False)
    need(0 < len(archive_raw) <= CHUNK_BYTES * MAX_CHUNKS, 'archive exceeds the frozen 128-chunk transfer bound')
    (OUT / 'chunks').mkdir(mode=0o700)
    chunks = []
    for index, offset in enumerate(range(0, len(archive_raw), CHUNK_BYTES)):
        raw = archive_raw[offset:offset + CHUNK_BYTES]
        encoded = base64.b64encode(raw)
        name = f'chunks/chunk-{index:04d}.b64'
        write_new(OUT / name, encoded)
        _, identity = read(OUT / name, text_scan=False)
        chunks.append({'path': name, 'offset': offset, 'bytes': len(raw), 'sha256': sha(raw),
            'text_bytes': len(encoded), 'text_sha256': sha(encoded), 'version': identity['version']})
    chunk_manifest = {'schema': 'hepta-r25-mac-holder-text-chunks/v1', 'chunk_bytes': CHUNK_BYTES,
        'archive': archive_identity, 'chunks': chunks,
        'read_multiple_files': {'host': 'main', 'paths_per_rpc_max': 4, 'max_file_bytes': 65536, 'max_response_bytes': 262144}}
    chunk_raw = encode(chunk_manifest)
    need(len(chunk_raw) <= 65536, 'chunk manifest exceeds one bounded text read')
    write_new(OUT / 'chunks-manifest.json', chunk_raw)
    unchanged()
    need(read(archive_path, text_scan=False) == (archive_raw, archive_identity), 'archive changed during chunk generation')
    receipt = {'schema': 'hepta-r25-mac-holder-export-receipt/v1', 'attempt': '02', 'passed': True,
        'finished_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'files': len(payloads), 'archive_members': len(payloads) + 1, 'archive': archive_identity,
        'manifest': read(OUT / 'manifest.json')[1], 'chunks_manifest': read(OUT / 'chunks-manifest.json')[1],
        'source_inputs_unchanged': True, 'included_original_holders_complete': True, 'campaign_names': selected,
        'original_jobs': {kind: proof['job_id'] for kind, proof in proofs.items()},
        'holder_report_sha256': {kind: proof['holder_report_sha256'] for kind, proof in proofs.items()},
        'exporter_sha256': args.exporter_sha256, 'verifier_sha256': args.verifier_sha256,
        'automatic_retries': 0, 'x230_report_bytes_read': False, 'runtime_adoption_assessed': False}
    write_new(OUT / 'receipt.json', encode(receipt))
    for path in (OUT / 'chunks', OUT):
        fd = os.open(path, os.O_RDONLY | os.O_DIRECTORY)
        try:
            os.fsync(fd)
        finally:
            os.close(fd)
    print(json.dumps(receipt, sort_keys=True), flush=True)
    return 0


if __name__ == '__main__':
    try:
        raise SystemExit(main())
    except Exception as error:
        # Never echo source bytes or a matching secret. Partial owned output is
        # preserved; it cannot be a completed export without the final receipt.
        print(json.dumps({'passed': False, 'error_type': type(error).__name__, 'reason': str(error),
                          'automatic_retries': 0, 'originals_modified': False}), flush=True)
        raise SystemExit(1)
