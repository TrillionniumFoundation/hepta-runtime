#!/usr/bin/env python3
"""Install the single frozen nextest asset in a fresh private R25 directory.

Execute this saved file, not an inline exec: its actual SHA256 is part of the
receipt. No Cargo build/test, toolchain installation, global writes, or retries.
"""

import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import shutil
import ssl
import stat
import subprocess
import sys
import tarfile
import time
import urllib.parse
import urllib.request

ROOT = Path("/home/qian/hepta-runtime-optimization-20261105-r25/ci-toolchain/nextest-0.9.137")
TOOLCHAIN = Path("/home/qian/.rustup/toolchains/1.95.0-x86_64-unknown-linux-gnu/bin")
URL = "https://github.com/nextest-rs/nextest/releases/download/cargo-nextest-0.9.137/cargo-nextest-0.9.137-x86_64-unknown-linux-gnu.tar.gz"
SIZE = 11729134
SHA256 = "38fd6275e111b200bbbed1bd2ae91cbb0d7edd28504879875cff2b3d96f3f311"
ARCHIVE_NAME = "cargo-nextest-0.9.137.tar.gz.partial"
MAX_BINARY = 128 * 1024 * 1024


def identity(path):
    h = hashlib.sha256()
    count = 0
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(65536), b""):
            count += len(block)
            h.update(block)
    return {"path": str(path), "bytes": count, "sha256": h.hexdigest()}


class HttpsRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, request, fp, code, message, headers, newurl):
        parsed = urllib.parse.urlsplit(newurl)
        if parsed.scheme != "https" or not parsed.hostname or parsed.username or parsed.password:
            raise ValueError("refused non-HTTPS or credential-bearing redirect")
        return super().redirect_request(request, fp, code, message, headers, newurl)


def download_child():
    # The parent kills and waits for this sole child after 180 seconds, bounding
    # DNS/TLS/socket stalls as well as the HTTP read loop. Never retry a request.
    target = ROOT / ARCHIVE_NAME
    opener = urllib.request.build_opener(
        HttpsRedirect(), urllib.request.HTTPSHandler(context=ssl.create_default_context()))
    request = urllib.request.Request(URL, headers={"User-Agent": "hepta-runtime-r25-pinned-tool-installer"})
    fd = os.open(target, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600)
    count = 0
    with os.fdopen(fd, "wb") as destination:
        with opener.open(request, timeout=20) as response:
            if response.status != 200 or urllib.parse.urlsplit(response.geturl()).scheme != "https":
                raise ValueError("unexpected HTTPS download response")
            declared = response.headers.get("Content-Length")
            if declared is not None and int(declared) != SIZE:
                raise ValueError("download Content-Length differs from frozen asset")
            while True:
                block = response.read(min(65536, SIZE + 1 - count))
                if not block:
                    break
                destination.write(block)
                count += len(block)
                if count > SIZE:
                    raise ValueError("download exceeds frozen asset size")
            destination.flush()
            os.fsync(destination.fileno())
            print(json.dumps({"downloaded_bytes": count,
                              "response_host": urllib.parse.urlsplit(response.geturl()).hostname}))


def selected_member(archive):
    selected = None
    total = 0
    for index, member in enumerate(archive):
        if index >= 32:
            raise ValueError("archive has too many members")
        name = PurePosixPath(member.name)
        if (name.is_absolute() or ".." in name.parts or "\\" in member.name
                or not name.parts or len(member.name) > 256):
            raise ValueError("unsafe archive member path")
        total += member.size
        if member.size < 0 or member.size > MAX_BINARY or total > 2 * MAX_BINARY:
            raise ValueError("archive expansion exceeds private bound")
        if name.name == "cargo-nextest":
            if selected is not None or not member.isfile() or member.issparse() or member.size == 0:
                raise ValueError("cargo-nextest must be one regular nonsparse file")
            selected = member
    if selected is None:
        raise ValueError("archive has no cargo-nextest regular file")
    return selected


def extract_binary(archive_path, binary_path):
    with tarfile.open(archive_path, "r:gz") as archive:
        member = selected_member(archive)
        source = archive.extractfile(member)
        if source is None:
            raise ValueError("regular binary member unavailable")
        fd = os.open(binary_path, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600)
        count = 0
        with source, os.fdopen(fd, "wb") as destination:
            while True:
                block = source.read(65536)
                if not block:
                    break
                count += len(block)
                if count > member.size or count > MAX_BINARY:
                    raise ValueError("binary member exceeds verified length")
                destination.write(block)
            if count != member.size:
                raise ValueError("binary member was truncated")
            destination.flush()
            os.fsync(destination.fileno())
            os.fchmod(destination.fileno(), 0o700)
        return {"archive_member": member.name, **identity(binary_path)}


def run_probe(label, argv, *, env=None, timeout=15):
    out, err = ROOT / (label + ".stdout.log"), ROOT / (label + ".stderr.log")
    with out.open("xb") as stdout, err.open("xb") as stderr:
        result = subprocess.run(argv, cwd=ROOT, env=env, stdin=subprocess.DEVNULL,
                                stdout=stdout, stderr=stderr, timeout=timeout, check=False)
    if out.stat().st_size > 65536 or err.stat().st_size > 65536:
        raise ValueError(label + " produced an unexpectedly large version/probe log")
    return {"argv": argv, "returncode": result.returncode,
            "stdout": out.read_text(errors="replace").strip(),
            "stderr": err.read_text(errors="replace").strip()}


def create_fresh_root():
    # Refuse symlink traversal and an existing install directory; preserve all
    # earlier attempts. Only the two new private directories may be created.
    parent = ROOT.parent
    for path in [Path("/home"), Path("/home/qian"), parent.parent]:
        if not stat.S_ISDIR(path.lstat().st_mode):
            raise ValueError("expected real parent directory is unavailable")
    if not parent.exists():
        parent.mkdir(mode=0o700)
    if not stat.S_ISDIR(parent.lstat().st_mode):
        raise ValueError("private toolchain parent is not a real directory")
    ROOT.mkdir(mode=0o700, exist_ok=False)
    (ROOT / "bin").mkdir(mode=0o700)
    (ROOT / "probe-cargo-home").mkdir(mode=0o700)


def main():
    started = time.time()
    try:
        create_fresh_root()
    except Exception as error:
        print(json.dumps({"passed": False, "stage": "fresh_directory", "prior_files_preserved": True,
                          "error": {"type": type(error).__name__, "message": str(error)[:1000]}}))
        return 1
    receipt = {"schema": "hepta-r25-private-nextest-install-v1", "passed": False,
               "install_directory": str(ROOT), "started_unix": started,
               "installer_source": identity(Path(__file__).resolve()),
               "release_id": 329695549, "asset_id": 430502414,
               "asset_url": URL, "expected_archive_bytes": SIZE, "expected_archive_sha256": SHA256,
               "automatic_download_retries": 0, "cargo_build_or_test_run": False,
               "global_install_or_sudo": False, "other_dependencies_installed": False}
    try:
        probe = "import importlib.util,importlib.metadata,json\ns=importlib.util.find_spec('jsonschema')\ntry:v=importlib.metadata.version('jsonschema')\nexcept importlib.metadata.PackageNotFoundError:v=None\nprint(json.dumps({'discoverable':s is not None,'version':v}))"
        receipt["python"] = {"executable": sys.executable, "version": sys.version.split()[0]}
        receipt["jsonschema_probe"] = run_probe("jsonschema", [sys.executable, "-B", "-c", probe])
        rg = shutil.which("rg")
        receipt["rg_probe"] = run_probe("rg-version", [rg, "--version"]) if rg else {"available": False}
        cargo, rustc = TOOLCHAIN / "cargo", TOOLCHAIN / "rustc"
        for executable in [cargo, rustc]:
            if not executable.is_file() or not os.access(executable, os.X_OK):
                raise ValueError("existing Rust 1.95.0 toolchain executable unavailable: " + str(executable))
        env = dict(os.environ)
        env.update(PATH=str(ROOT / "bin") + ":" + str(TOOLCHAIN) + ":/usr/bin:/bin",
                   CARGO_HOME=str(ROOT / "probe-cargo-home"), CARGO_NET_OFFLINE="true", RUSTC=str(rustc))
        receipt["cargo_version"] = run_probe("cargo-version", [str(cargo), "--version"], env=env)
        receipt["rustc_version"] = run_probe("rustc-version", [str(rustc), "--version"], env=env)
        if (receipt["cargo_version"]["returncode"] != 0 or not receipt["cargo_version"]["stdout"].startswith("cargo 1.95.0 ")
                or receipt["rustc_version"]["returncode"] != 0 or not receipt["rustc_version"]["stdout"].startswith("rustc 1.95.0 ")):
            raise ValueError("the existing cargo/rustc versions are not the frozen 1.95.0 toolchain")
        receipt["download"] = run_probe("download", [sys.executable, "-B", str(Path(__file__).resolve()), "--download-child"], timeout=180)
        archive = ROOT / ARCHIVE_NAME
        if receipt["download"]["returncode"] != 0:
            raise ValueError("single HTTPS download failed; partial file and logs retained")
        receipt["archive"] = identity(archive)
        if receipt["archive"]["bytes"] != SIZE or receipt["archive"]["sha256"] != SHA256:
            raise ValueError("downloaded archive differs from the frozen size or SHA256")
        binary = ROOT / "bin/cargo-nextest"
        receipt["binary"] = extract_binary(archive, binary)
        if shutil.which("cargo-nextest", path=env["PATH"]) != str(binary):
            raise ValueError("private Cargo plugin PATH does not select the installed binary")
        receipt["nextest_version"] = run_probe("nextest-version", [str(cargo), "nextest", "--version"], env=env)
        if receipt["nextest_version"]["returncode"] != 0 or receipt["nextest_version"]["stdout"].split()[:2] != ["cargo-nextest", "0.9.137"]:
            raise ValueError("private cargo nextest --version did not report 0.9.137")
        if identity(binary) != {key: value for key, value in receipt["binary"].items() if key != "archive_member"}:
            raise ValueError("binary changed during version verification")
        receipt["passed"] = True
    except Exception as error:
        receipt["error"] = {"type": type(error).__name__, "message": str(error)[:1000]}
    receipt["finished_unix"] = time.time()
    with (ROOT / "receipt.json").open("x") as stream:
        json.dump(receipt, stream, indent=2)
        stream.write("\n")
        stream.flush()
        os.fsync(stream.fileno())
    print(json.dumps({"passed": receipt["passed"], "receipt": str(ROOT / "receipt.json"),
                      "binary": receipt.get("binary"), "error": receipt.get("error")}))
    return 0 if receipt["passed"] else 1


if __name__ == "__main__":
    if sys.argv[1:] == ["--download-child"]:
        download_child()
    elif sys.argv[1:]:
        raise SystemExit("no arguments accepted; root owns the fixed private install path")
    else:
        raise SystemExit(main())
