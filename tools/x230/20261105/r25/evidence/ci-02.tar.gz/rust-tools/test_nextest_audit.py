#!/usr/bin/env python3
"""Offline positive and corruption checks; no Cargo or workload execution."""
import copy
import hashlib
import json
from pathlib import Path
import unittest

import audit_nextest_0137 as audit

SOURCE = Path("/fixture/source-02")
TARGET = Path("/fixture/target-build-02")


def sample():
    cases = [
        {"target_name": "pkg_lib", "target_kind": ["lib"], "name": "same_name", "ignored": False},
        {"target_name": "tool", "target_kind": ["bin"], "name": "ignored_helper", "ignored": True},
        {"target_name": "tool", "target_kind": ["bin"], "name": "same_name", "ignored": False},
    ]
    expected = {"passed": 2, "failed": 0, "skipped": 1, "total": 3, "retries": 0, "exact_cases": cases,
                "case_inventory_sha256": hashlib.sha256(json.dumps(cases, sort_keys=True, separators=(",", ":")).encode()).hexdigest(),
                "test_target_inventory": []}
    value = {"rust-build-meta": {"target-directory": str(TARGET)}, "test-count": 3, "rust-suites": {}}
    for name, kind, binary_id in (("pkg_lib", "lib", "pkg"), ("tool", "bin", "pkg::bin/tool"), ("empty", "example", "pkg::example/empty")):
        chosen = [row for row in cases if row["target_name"] == name]
        expected["test_target_inventory"].append({"target_name": name, "target_kind": [kind], "inventory_count": len(chosen),
            "ignored_names": [row["name"] for row in chosen if row["ignored"]],
            "qualified_test_binary": {"path": "/fixture/qualified/" + name, "bytes": 1, "sha256": "0" * 64}})
        value["rust-suites"][binary_id] = {"package-name": "pkg", "binary-id": binary_id, "binary-name": name,
            "kind": kind, "binary-path": str(TARGET / "debug" / name), "cwd": str(SOURCE), "build-platform": "target", "status": "listed",
            "testcases": {row["name"]: {"kind": "test", "ignored": row["ignored"],
                "filter-match": {"status": "mismatch", "reason": "ignored"} if row["ignored"] else {"status": "matches"}} for row in chosen}}
    output = b"Nextest run ID 123 with nextest profile: default\nStarting 2 tests across 3 binaries (1 test skipped)\n        PASS [   1.000s] (  1/2) pkg same_name\n        PASS [   0.002s] (  2/2) pkg::bin/tool same_name\n     Summary [   2.000s] 2 tests run: 2 passed, 1 skipped\n"
    return value, expected, output


class AuditTests(unittest.TestCase):
    def test_valid_exact_inventory_counter_and_same_name_across_binaries(self):
        value, expected, raw = sample()
        listed = audit.inventory(value, expected, SOURCE, TARGET)
        result = audit.run_output(raw, listed, expected)
        self.assertEqual((result["passed"], result["ignored"], result["retries"]), (2, 1, 0))

    def test_valid_no_counter_and_original_leak_pass_semantics(self):
        value, expected, raw = sample()
        listed = audit.inventory(value, expected, SOURCE, TARGET)
        raw = raw.replace(b" (  1/2)", b"").replace(b" (  2/2)", b"")
        raw = raw.replace(b"PASS [   1.000s]", b"LEAK [   1.000s]").replace(b"2 passed,", b"2 passed (1 leaky),")
        self.assertEqual(audit.run_output(raw, listed, expected)["success_status_counts"], {"LEAK": 1, "PASS": 1})

    def test_reject_all_extra_filter_reasons(self):
        value, expected, _ = sample()
        for reason in ("default-filter", "partition", "expression", "string", "rerun-already-passed"):
            with self.subTest(reason=reason):
                changed = copy.deepcopy(value)
                changed["rust-suites"]["pkg"]["testcases"]["same_name"]["filter-match"] = {"status": "mismatch", "reason": reason}
                with self.assertRaises(RuntimeError):
                    audit.inventory(changed, expected, SOURCE, TARGET)

    def test_reject_missing_zero_test_binary_and_wrong_ignored_set(self):
        value, expected, _ = sample()
        bad = copy.deepcopy(value)
        del bad["rust-suites"]["pkg::example/empty"]
        with self.assertRaises(RuntimeError):
            audit.inventory(bad, expected, SOURCE, TARGET)
        value["rust-suites"]["pkg::bin/tool"]["testcases"]["ignored_helper"]["ignored"] = False
        with self.assertRaises(RuntimeError):
            audit.inventory(value, expected, SOURCE, TARGET)

    def test_reject_missing_duplicate_unknown_case_and_wrong_counters(self):
        value, expected, raw = sample()
        listed = audit.inventory(value, expected, SOURCE, TARGET)
        status = b"        PASS [   1.000s] (  1/2) pkg same_name\n"
        variants = [raw.replace(status, b""), raw.replace(status, status + status),
                    raw.replace(b"pkg same_name", b"pkg unknown"), raw.replace(b"(  2/2)", b"(  1/2)")]
        for changed in variants:
            with self.subTest(changed=changed):
                with self.assertRaises(RuntimeError):
                    audit.run_output(changed, listed, expected)

    def test_reject_partial_wrong_or_duplicate_summary_and_retries(self):
        value, expected, raw = sample()
        listed = audit.inventory(value, expected, SOURCE, TARGET)
        variants = [raw.replace(b"2 tests run:", b"1/2 tests run:"), raw.replace(b"2 passed,", b"1 passed,"),
                    raw + raw.splitlines(keepends=True)[-1], raw.replace(b"PASS [   1", b"TRY 2 PASS [   1"),
                    raw.replace(b"2 passed,", b"2 passed (1 flaky),")]
        for changed in variants:
            with self.subTest(changed=changed):
                with self.assertRaises(RuntimeError):
                    audit.run_output(changed, listed, expected)


if __name__ == "__main__":
    unittest.main(verbosity=2)
