# R25 attempt 02: exact external Rust CI gates

This package never treats an in-progress qualification or queued GitHub job as
passed. It requires the actual successful terminal DTO for original job
`1a1aaa6552d-fc05-459f`, the completed eight-stage qualification02 report, the
actual 221-file source map, the unchanged 19 qualification scripts, three retained
release binaries, and the full audited isolated-test inventory.

Install these regular files together in the fresh private directory
`/home/qian/hepta-runtime-optimization-20261105-r25/rust-ci-tools-02`.
The package contains no executable downloads, install operations or service changes.
The exact already-installed nextest binary and its receipt are independently pinned.

## Materialize only after original qualification02 succeeds

Invoke `/usr/bin/python3 -B` with `materialize_rust_ci_plan_02.py` and these arguments:

- `--qualification-sha256`: SHA256 of the actual final qualification02/report.json.
- `--terminal-status-sha256`: SHA256 of the actual saved qualification-terminal-status-02.json.
- `--ci-manifest`: actual installed path of the independently Git-bound ci-gate-manifest.json (normally ROOT/ci-gates/ci-gate-manifest.json).
- `--out`: `/home/qian/hepta-runtime-optimization-20261105-r25/rust-ci-plan-02.json`.

The materializer reads and verifies inputs, then exclusively creates the plan. It
does not launch Cargo. It binds the exact qualification02 summary SHA
`f6eea0ffc1c8a9638c2e54d2daab778d923178c1f3f9a2df7a0cc5d38a47107d`
and independent audit SHA
`c4a13416ca5f4ed94b30220c48a1600cb83dfce9ce233d171e957fc08aa11101`.
Those already-completed isolated stages recorded 1653 passed, zero failed,
34 ignored, 1687 selected and zero retries. Full qualification and original job
terminal success remain separate mandatory prerequisites.

## Execute once

Invoke `/usr/bin/python3 -B` with `run_rust_ci_02.py` and these arguments:

- `--plan`: ROOT/rust-ci-plan-02.json.
- `--plan-sha256`: the materializer's actual output identity.
- `--materializer-sha256`: the manifest SHA of materialize_rust_ci_plan_02.py.
- `--auditor-sha256`: the manifest SHA of audit_nextest_0137.py.

Use one original native process_start operation and reconcile any uncertain reply
before resubmission. A process_start timeout should allow at least the runner's
6600-second budget plus transport cleanup. The runner exclusively creates
ROOT/rust-ci-02 and refuses an existing attempt directory.

The runner checks actual Cargo/rustc 1.95.0 and nextest0.9.137, then performs:

1. `cargo check --locked --all-targets --all-features` (1800-second bound).
2. `cargo nextest list --locked --all-targets --all-features --message-format json` (900-second bound).
3. `cargo nextest run --locked --all-targets --all-features --test-threads 1 --retries 0 --no-fail-fast` (3600-second bound).

Check and run argv exactly match both current workflow jobs. The separate list
command may compile and invokes test binaries with `--list`; it executes no test
cases. Its entire JSON is retained and must match every qualified binary target,
exact case and ignored test. Only ignored tests may have a filter mismatch, with
the exact `ignored` reason; extra default filters, partitions and replay filters
are rejected. Listed test executable hashes must equal their retained qualified
copies, and remain unchanged after execution.

The run uses the inherited environment after the existing qualification sanitizer
and NEXTEST overrides are removed. Required private paths, Rust1.95.0, two compiler
jobs, offline Cargo, single test thread and existing harness environment are then
set explicitly. HOME remains unchanged. Reporting-only settings force color-free
PASS output, final failure status, and no successful-test stdout. They do not alter
execution flags, retries, concurrency or test selection.

Every original stdout/stderr file, argument list, time bound, PID/birth/process
group and wait/reap result is retained. On interruption/timeout the runner signals
only the still-matching original owned group, using SIGINT120s, SIGTERM10s and
SIGKILL10s. Unknown ownership or any remaining group stops the sequence. No foreign
processes are signalled. Every bound input is rechecked before/after each stage.

## Independent output proof

The JSON listing schema and human output syntax are checked against nextest0.9.137
release commit `75ddba7e911b44c5c0700dac0415d824403de9bd`; exact Git blob identities
and official URLs are in official-source-manifest.json. The auditor binds the
runtime binary IDs from that listing and requires each nonignored exact test to
finish once between the one Starting line and the one successful final Summary.
Optional nextest progress counters must be complete and unique. Duplicate cases,
omissions, unknown cases, wrong ignored counts, partial summaries, retries and flaky
outcomes fail the audit. Original nextest successful LEAK/TIMEOUT-PASS statuses, if
any, are retained separately using their actual CLI success semantics.

Six offline tests cover valid schema/output and corruption cases; actual failed
qualification01 report and terminal DTO are rejected by the new materializer.
Native child execution/cleanup has not been exercised by these local tests.

The authoritative external report is ROOT/rust-ci-02/report.json. Source hashes,
configuration presence, retained qualification artifacts and tool hashes must
remain unchanged. GitHub-hosted Actions status, Git publication, observation and
lifecycle performance remain independently tracked; an external pass cannot make
a queued hosted check pass.
