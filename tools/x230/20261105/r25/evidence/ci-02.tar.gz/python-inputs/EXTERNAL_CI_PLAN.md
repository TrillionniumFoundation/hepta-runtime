# R25 external replay of the current Python CI gates

Source identity: `1aa98d3c94d0253999a491c967ccc94b314e87c8`, root tree `1ff52b8f02a0d97590a24504527b2b15833a9f36`. The currently proposed merge into `94d7fecdb02f5a7ef3d5ff072665360eb0115e0f` is `a7b997cafb61d98754ea83b2e0ecd369c64fef05` and has the identical root tree. The accepted Rust source tree is `b71cac25e2c2138837f27f3c74f6a2dc5c56b565`.

`ci-gate-manifest.json` contains the exact current workflow, both job definitions, the 18 original Python commands, a complete source dependency subset, and the Git object proofs. Its SHA256 is `bf0df5f7d19ebd149854fbf75887fb0fb136f18a63a0c240abf8420655fb195e`.

## Running on X230

Extract the package into a new task directory. Do not overwrite the R24 source or prior results. Run as the existing unprivileged X230 user. Python 3.11 or later and the distribution `python3-jsonschema` dependency are required by the original workflow; `rg` is also installed by that workflow. The gate runner does not install packages, access GitHub, invoke cargo, start remote jobs, or deploy services. The original tests use temporary local fixtures, loopback HTTP, fixture child processes and mocked maintenance commands.

Example after unpacking into `/home/qian/hepta-runtime-optimization-20261105-r25/ci-gates`:

```sh
/usr/bin/python3 -B /home/qian/hepta-runtime-optimization-20261105-r25/ci-gates/run_ci_python_gates.py \
  --source /home/qian/hepta-runtime-optimization-20261105-r25/ci-gates/ci-inputs \
  --manifest /home/qian/hepta-runtime-optimization-20261105-r25/ci-gates/ci-gate-manifest.json \
  --manifest-sha256 bf0df5f7d19ebd149854fbf75887fb0fb136f18a63a0c240abf8420655fb195e \
  --out /home/qian/hepta-runtime-optimization-20261105-r25/ci-gates-results-01
```

The output directory must not exist and must be outside the source subset. The runner binds every file before and after every command, records full stdout/stderr plus their hashes, runs each gate once in workflow order, retains failures, and continues independent gates unless the source changes or it is interrupted. Default timeout is 600 seconds per command. A timeout is a failure and is not retried. Each fixture command gets its own process group; timeout cleanup targets only the still-live owned group. `PYTHONPATH` and `PYTHONHOME` are removed and bytecode writes are disabled so unrelated local modules cannot replace this bound subset. The run records those explicit environment adjustments.

`--verify-only` performs just file/discovery checks. The retained local preflight executed zero gates and intentionally reports `passed=false`, `preflight_passed=true`.

## Exact scope and outstanding GitHub status

This replay covers `file_capabilities.py`, all fourteen control-plane regression scripts, and unittest discovery in `tools/x230/20261028`, `20261029`, and `20261030`. The latter two directories were absent from the earlier local partial R24 checkout and were not covered by its harness-test stage.

The source subset contains the required Python paths and full imported `dc_compat` package, its catalog, V4/V10/V11 contracts, maintenance fixtures, all top-level files in the three harness directories and the current workflow. It is not represented as a complete Git checkout. The manifest also binds the full Rust source, examples and Cargo inputs by their Git tree/blob identities for comparison to the separate R24 qualification.

R24's format, strict Clippy, isolated Rust tests and release qualification remain separate evidence. This Python replay does not execute the workflow's exact `cargo check` or cargo-nextest commands, change any GitHub check conclusion, or qualify a new Rust candidate. Any R25 source change needs its own source binding and qualification.

At the latest recorded read, the hosted push run `41979845223` and PR run `41979855060` are queued, with no runner allocated and no executed steps. They must remain explicitly pending until GitHub returns actual conclusions. Preserve the old cancelled R24 source runs; no blind rerun is planned.

## Existing-base merge criterion

The current base branch reports `protected=false`, required contexts/checks are empty and enforcement is off; the repository ruleset collection is empty. PR87 has no review, no review thread, no comment and no requested reviewer, is mergeable, and remains draft. GitHub therefore exposes no enforced status/review rule for this base. Clearing draft is required before merging. This is a platform requirement observation, not a statement that pending CI has succeeded.

Apply AGENTS' existing source-quality gates and the explicit task's validation requirements. Keep the current base, refresh head/base/merge tree before any authorized merge, and do not retarget the default branch. The old `.agents/release.md` upstream publishing description is stale and supplies no release/tag requirement for this optimization.
