#!/usr/bin/env python3
"""Replay current, source-bound Python CI gates; never mark hosted CI passed."""
import argparse
import datetime
import hashlib
import json
import os
from pathlib import Path
import platform
import signal
import stat
import subprocess
import sys
import time

STOP_SIGNAL = None


def stopped(signum, _frame):
    global STOP_SIGNAL
    STOP_SIGNAL = signum


def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def write_json(path, value):
    with path.open("x", encoding="utf-8") as stream:
        json.dump(value, stream, sort_keys=True, indent=2)
        stream.write("\n")


def checked_inputs(root, manifest):
    observed, problems = {}, []
    for expected in manifest["input_files"]:
        relative = expected["path"]
        path = root / relative
        try:
            assert path.resolve(strict=True) == path, "symlink or non-direct path"
            info = path.stat()
            assert stat.S_ISREG(info.st_mode), "not a regular file"
            body = path.read_bytes()
            blob = hashlib.sha1(b"blob " + str(len(body)).encode() + b"\0" + body).hexdigest()
            row = {"bytes": len(body), "sha256": digest(body), "git_blob": blob,
                   "git_mode": "100755" if info.st_mode & 0o111 else "100644"}
            observed[relative] = row
            for field in row:
                if row[field] != expected[field]:
                    problems.append({"path": relative, "field": field,
                                     "expected": expected[field], "actual": row[field]})
            if info.st_mode & 0o022:
                problems.append({"path": relative, "error": "group/other-writable input"})
        except (OSError, AssertionError) as error:
            problems.append({"path": relative, "error": str(error)})
    for directory, expected in manifest["python_discovery_files"].items():
        actual = sorted(p.relative_to(root).as_posix() for p in (root / directory).rglob("*_tests.py"))
        if actual != expected:
            problems.append({"discovery": directory, "expected": expected, "actual": actual})
    encoded = json.dumps(observed, sort_keys=True, separators=(",", ":")).encode()
    return {"recorded_utc": utc(), "passed": not problems, "file_count": len(observed),
            "identity_map_sha256": digest(encoded), "files": observed, "problems": problems}


def terminate_owned(child):
    """Only signal the new process group while its unreaped leader is live."""
    events = []
    if child.poll() is None:
        try:
            os.killpg(child.pid, signal.SIGTERM)
            events.append("SIGTERM")
        except ProcessLookupError:
            pass
        try:
            child.wait(timeout=10)
        except subprocess.TimeoutExpired:
            try:
                os.killpg(child.pid, signal.SIGKILL)
                events.append("SIGKILL")
            except ProcessLookupError:
                pass
            child.wait()
    return events


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source", type=Path, required=True)
    parser.add_argument("--manifest", type=Path, required=True)
    parser.add_argument("--manifest-sha256", required=True)
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--gate-timeout", type=int, default=600)
    parser.add_argument("--verify-only", action="store_true")
    args = parser.parse_args()
    raw_manifest = args.manifest.read_bytes()
    if digest(raw_manifest) != args.manifest_sha256:
        raise SystemExit("manifest identity mismatch")
    manifest = json.loads(raw_manifest)
    source = args.source.absolute()
    output = args.out.absolute()
    if source.resolve(strict=True) != source or not source.is_dir():
        raise SystemExit("source must be a direct absolute directory")
    if output == source or source in output.parents:
        raise SystemExit("output must be outside source")
    if args.gate_timeout < 1:
        raise SystemExit("positive gate timeout required")
    os.umask(0o022)
    output.mkdir(parents=False, exist_ok=False)
    (output / "manifest.input.json").write_bytes(raw_manifest)
    report = {"schema": "hepta-r25-external-python-ci-results/v1", "started_utc": utc(),
              "source": str(source), "head_commit": manifest["head_commit"],
              "head_root_tree": manifest["head_root_tree"], "workflow_git_blob": manifest["workflow_git_blob"],
              "manifest_sha256": digest(raw_manifest), "harness_sha256": digest(Path(__file__).read_bytes()),
              "scope": "18 original Python CI commands using a byte-bound dependency subset",
              "hosted_actions_passed": False, "rust_executed": False, "performance_executed": False,
              "platform": platform.platform(), "python": sys.version, "python_executable": sys.executable,
              "effective_uid": os.geteuid(), "gate_timeout_seconds": args.gate_timeout,
              "retry_count": 0, "verify_only": args.verify_only, "gates": [], "passed": False}
    before = checked_inputs(source, manifest)
    write_json(output / "inputs-before.json", before)
    if not before["passed"]:
        report["error"] = "input verification failed"
    elif args.verify_only:
        report["preflight_passed"] = True
    elif os.geteuid() == 0:
        report["error"] = "run fixture gates as the unprivileged X230 user, matching CI"
    else:
        signal.signal(signal.SIGINT, stopped)
        signal.signal(signal.SIGTERM, stopped)
        environment = dict(os.environ)
        for key in ("PYTHONPATH", "PYTHONHOME"):
            environment.pop(key, None)
        environment["PYTHONDONTWRITEBYTECODE"] = "1"
        report["environment_adjustments"] = {"removed": ["PYTHONPATH", "PYTHONHOME"],
                                             "set": {"PYTHONDONTWRITEBYTECODE": "1"}, "umask": "0022"}
        for gate in manifest["python_gates"]:
            if STOP_SIGNAL is not None:
                report["stopped_by_signal"] = signal.Signals(STOP_SIGNAL).name
                break
            prefix = gate["id"]
            row = {**gate, "started_utc": utc(), "timeout": False, "signals": [],
                   "stdout_file": prefix + ".stdout", "stderr_file": prefix + ".stderr"}
            start = time.monotonic()
            child = None
            try:
                with (output / row["stdout_file"]).open("xb") as stdout, (output / row["stderr_file"]).open("xb") as stderr:
                    child = subprocess.Popen(gate["argv"], cwd=source, env=environment,
                                             stdout=stdout, stderr=stderr, start_new_session=True)
                    row["original_pid"] = child.pid
                    while True:
                        try:
                            child.wait(timeout=1)
                            break
                        except subprocess.TimeoutExpired:
                            if STOP_SIGNAL is not None or time.monotonic() - start > args.gate_timeout:
                                row["timeout"] = STOP_SIGNAL is None
                                row["signals"] = terminate_owned(child)
                                break
                    row["returncode"] = child.returncode
            except OSError as error:
                row["error"] = str(error)
                row["returncode"] = None
            finally:
                if child is not None and child.poll() is None:
                    row["signals"] += terminate_owned(child)
            row["elapsed_seconds"] = time.monotonic() - start
            row["finished_utc"] = utc()
            for name in ("stdout", "stderr"):
                path = output / row[name + "_file"]
                if path.exists():
                    body = path.read_bytes()
                    row[name + "_sha256"] = digest(body)
                    row[name + "_bytes"] = len(body)
            after = checked_inputs(source, manifest)
            write_json(output / (prefix + ".inputs-after.json"), after)
            row["inputs_unchanged"] = after["passed"] and before["identity_map_sha256"] == after["identity_map_sha256"]
            row["passed"] = row.get("returncode") == 0 and not row["timeout"] and row["inputs_unchanged"] and STOP_SIGNAL is None
            report["gates"].append(row)
            write_json(output / (prefix + ".receipt.json"), row)
            print(json.dumps({"gate": prefix, "returncode": row.get("returncode"), "passed": row["passed"]}), flush=True)
            if not row["inputs_unchanged"]:
                report["error"] = "source changed; remaining gates not executed"
                break
        report["passed"] = (len(report["gates"]) == len(manifest["python_gates"]) and
                             all(g["passed"] for g in report["gates"]) and STOP_SIGNAL is None)
    final = checked_inputs(source, manifest)
    write_json(output / "inputs-after.json", final)
    report["final_inputs_unchanged"] = final["passed"] and before["identity_map_sha256"] == final["identity_map_sha256"]
    report["passed"] = report["passed"] and report["final_inputs_unchanged"]
    report["finished_utc"] = utc()
    write_json(output / "report.json", report)
    print(json.dumps({"report": str(output / "report.json"), "passed": report["passed"],
                      "preflight_passed": report.get("preflight_passed", False),
                      "gates_executed": len(report["gates"]), "hosted_actions_passed": False}))
    return 0 if report["passed"] or report.get("preflight_passed") else 1


if __name__ == "__main__":
    raise SystemExit(main())
