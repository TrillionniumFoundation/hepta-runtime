#!/usr/bin/env python3
"""Independent standard-library byte verification; no extraction or code loading."""
import hashlib
import io
import json
import lzma
from pathlib import Path, PurePosixPath
import stat
import tarfile

WORK = Path('/workspace/scratch/806ba5f52f94')
OUT = WORK / 'r25-evidence/archive-transfer-custody-02'
NAME = 'archive-transfer-custody-02.tar.xz'


def sha(body):
    return hashlib.sha256(body).hexdigest()


def main():
    body = (OUT / NAME).read_bytes()
    decoder = lzma.LZMADecompressor(format=lzma.FORMAT_XZ)
    expanded = decoder.decompress(body)
    assert decoder.eof and not decoder.unused_data and decoder.check == lzma.CHECK_SHA256
    declared = (OUT / 'manifest.json').read_bytes()
    manifest = json.loads(declared)
    assert manifest['schema'] == 'hepta-r25-archive-transfer-custody/v1'
    rows = manifest['original_files'] + manifest['additional_original_source_dependencies'] + manifest['packaging_support_files']
    expected = {r['archive_path']: r for r in rows}
    assert len(expected) == len(rows) == 180
    observed = []
    with tarfile.open(fileobj=io.BytesIO(expanded), mode='r:') as archive:
        members = archive.getmembers()
        assert [m.name for m in members] == ['manifest.json'] + sorted(expected)
        for member in members:
            path = PurePosixPath(member.name)
            assert not path.is_absolute() and str(path) == member.name
            assert all(p not in ('', '.', '..') for p in path.parts)
            assert member.type == tarfile.REGTYPE and not member.linkname and not member.pax_headers
            assert member.uid == member.gid == member.mtime == 0
            assert member.mode == 0o644 and member.uname == member.gname == ''
            stream = archive.extractfile(member)
            raw = stream.read()
            assert len(raw) == member.size
            if member.name == 'manifest.json':
                assert raw == declared
            else:
                record = expected[member.name]
                assert len(raw) == record['bytes'] and sha(raw) == record['sha256']
                local = Path(record['source_path'])
                assert stat.S_ISREG(local.lstat().st_mode) and local.read_bytes() == raw
            observed.append({'path': member.name, 'bytes': len(raw), 'sha256': sha(raw)})
        tail = expanded[archive.offset:]
        assert len(tail) >= 1024 and not any(tail)
    current = []
    for root in manifest['input_roots']:
        for path in sorted((WORK / root).rglob('*')):
            mode = path.lstat().st_mode
            assert stat.S_ISDIR(mode) or stat.S_ISREG(mode)
            if stat.S_ISREG(mode):
                current.append(path.relative_to(WORK).as_posix())
    originals = {r['workspace_relative_path'] for r in manifest['original_files']}
    omitted = manifest['omitted_duplicate_archive_bodies']
    assert len(current) == 179 and len(originals) == 176 and len(omitted) == 3
    assert set(current) == originals | {r['workspace_relative_path'] for r in omitted}
    for record in omitted:
        raw = Path(record['source_path']).read_bytes()
        assert len(raw) == record['bytes'] and sha(raw) == record['sha256']
        gitsha = hashlib.sha1(b'blob ' + str(len(raw)).encode() + b'\0' + raw).hexdigest()
        assert gitsha == record['git_blob_sha1']
    assert all(manifest[k] is False for k in ('archive_code_executed', 'archive_extracted', 'ssh_or_workload_replayed',
               'observation_gate_passed', 'lifecycle_executed', 'candidate_adoption_ready',
               'hosted_actions_passed', 'all_optimization_blockers_closed'))
    assert all(manifest[k] is True for k in ('all_saved_original_api_response_payloads_in_scope_preserved',
               'all_saved_request_envelopes_in_scope_preserved', 'all_failures_and_read_only_retries_in_scope_preserved'))
    report = {'schema': 'hepta-r25-archive-transfer-custody-independent-verification/v1', 'passed': True,
              'archive': {'path': str(OUT / NAME), 'bytes': len(body), 'sha256': sha(body),
                          'git_blob_sha1': hashlib.sha1(b'blob ' + str(len(body)).encode() + b'\0' + body).hexdigest()},
              'manifest': {'bytes': len(declared), 'sha256': sha(declared)},
              'members': observed, 'member_count': len(observed), 'original_scope_file_count': len(current),
              'original_included_file_count': len(originals), 'omitted_duplicate_archive_count': len(omitted),
              'additional_fixed_source_dependencies': 1,
              'xz_sha256_check_and_exact_end_verified': True, 'ustar_and_zero_padding_verified': True,
              'all_members_rehashed_and_compared_to_original_sources': True,
              'all_original_scope_paths_accounted_for': True, 'archive_code_executed': False,
              'archive_extracted': False, 'remote_calls': 0,
              'verifier': {'path': str(Path(__file__).resolve()), 'sha256': sha(Path(__file__).read_bytes())}}
    with (OUT / 'independent-verification.json').open('x') as stream:
        json.dump(report, stream, sort_keys=True, indent=2)
        stream.write('\n')
    print(json.dumps({k: v for k, v in report.items() if k != 'members'}, sort_keys=True))


if __name__ == '__main__':
    main()
