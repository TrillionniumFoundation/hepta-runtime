# R25 archive transfer custody

This package preserves the complete saved transport evidence in three fixed input directories, including every original API response payload, every failed request and read-only retry, source revisions, native output bytes, manifests, and the final archive audits. It does not execute, extract, or adopt runtime code.

The 176 original files are stored under `payload/` at their original workspace-relative paths. The only omitted files from those directories are the three assembled `reconstructed/*.tar.gz` bodies: exact bytes are separately published as `ci-02.tar.gz`, `observation-02.tar.gz`, and `qualification-02.tar.gz` beside this package. Their sizes, SHA256 values, Git blob identities, and omitted local paths are in `manifest.json`. The separately preserved `qualification-01-failed.tar.gz` is also referenced there. No raw response was dropped as a duplicate: the Mac attempt responses and byte-identical selected response copies are both present.

The one additional source dependency is the exact, previously used `r24-transfer/archive_tar_qa.py`. The unchanged original holder is already available as `sources/held_agent_campaign_02.py` inside the published `mac-holder-02.tar.gz`; the original export report is published as `../reviews/export-report-02.json`. The manifest binds those locations and exact identities. Packaging and independent verification sources are included under `meta/`.

## Recovery order

1. Verify this package's SHA256 from its separate publication proof, then its XZ end/checksum and every regular tar member against `manifest.json`. No archive entrypoint needs to be executed.
2. Inspect the saved original X230 chunk manifests and `read-batch-000.json` through `read-batch-013.json`. These contain the first 56 verified chunks. Keep the original timeout record and the exact batch-005 annotation exception.
3. Inspect the original relay holder request, launch, strong native terminal, lossless native read, and holder report. The relay used one original SSH connection. Preserve the original failed decoder and the exact two native binary-write lock identities; decoder03 consumed the existing complete stream without replaying SSH.
4. Inspect Mac `metadata-read-02.raw.json` and all 21 selected batch responses, together with every attempt response and timeout. Verify response text/version/body hashes, the Mac-to-original path map, all 82 remaining chunks, and all 138 original offset/length/digest records.
5. Reconstruct the three original archive bodies and the entire framed holder stdout. Compare the assembled bytes against the companion archive hashes and the original holder's complete stdout identity. `archive-assembly-report-01.json` records that comparison; `archive-integrity-and-semantics-02.json` records the subsequent complete tar/source/terminal/result audit.

The source files retain their recorded workspace and remote paths and original SHA pins. They are audit artifacts, not automatically runnable relocation scripts. No archived installer, holder, benchmark, or runtime entrypoint is run by this package's builder or verifier. Any later path adaptation must be explicit and kept separate from the original files.

Original raw response strings are authoritative where a wrapper also has decoded metadata. Derived stream files are verified byte reconstructions from the original native `bytes_hex` responses. This package preserves all request envelopes that were saved in its input directories; it does not invent missing historical envelopes. The saved final receipts distinguish original responses from derived projections.

R25 qualification02 and external Rust/Python CI passed, but observation02 failed its frozen performance gate. Lifecycle was not executed, R25 was not adopted, and hosted Actions were not marked passed. The original qualification01 failure, decoder failure, and transport-only retries remain part of the evidence.

The separate Mac `gh` capability probe and other tasks are outside this package.
