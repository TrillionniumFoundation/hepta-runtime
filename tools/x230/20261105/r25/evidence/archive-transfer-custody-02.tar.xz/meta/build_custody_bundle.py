#!/usr/bin/env python3
"""Package only fixed local evidence files; never execute packaged code."""
import hashlib
import io
import json
import lzma
import os
from pathlib import Path
import stat
import tarfile

WORK = Path('/workspace/scratch/806ba5f52f94')
OUT = WORK / 'r25-evidence/archive-transfer-custody-02'
ROOTS = ('r25-integration-audit/archive-relay-01',
         'r25-evidence/mac-relay-transfer-01',
         'r25-evidence/rejected-transfer-02')
OMITTED = tuple('r25-evidence/rejected-transfer-02/reconstructed/' + n + '-02.tar.gz'
                for n in ('ci', 'observation', 'qualification'))
HELPER = 'r24-transfer/archive_tar_qa.py'
HELPER_SHA = 'd5cf47fa484d71a78ce07b2154e6c89a268ca18d583263aad387c6b07422237c'
NAME = 'archive-transfer-custody-02.tar.xz'


def digest(body):
    return {'bytes': len(body), 'sha256': hashlib.sha256(body).hexdigest()}


def frozen(path):
    before = path.lstat()
    if not stat.S_ISREG(before.st_mode) or before.st_nlink != 1:
        raise ValueError('non-regular or shared source: ' + str(path))
    descriptor = os.open(path, os.O_RDONLY | os.O_NOFOLLOW)
    with os.fdopen(descriptor, 'rb') as stream:
        if stream_identity(os.fstat(stream.fileno())) != stream_identity(before):
            raise ValueError('source changed during open: ' + str(path))
        body = stream.read()
        if stream_identity(os.fstat(stream.fileno())) != stream_identity(before):
            raise ValueError('source changed during read: ' + str(path))
    if stream_identity(path.lstat()) != stream_identity(before):
        raise ValueError('source path changed: ' + str(path))
    return body, stream_identity(before)


def stream_identity(value):
    return [value.st_dev, value.st_ino, value.st_mode, value.st_nlink,
            value.st_size, value.st_mtime_ns, value.st_ctime_ns]


def inventory():
    result = []
    for root in ROOTS:
        start = WORK / root
        if not start.is_dir() or start.is_symlink():
            raise ValueError('input root is not an original directory')
        for path in sorted(start.rglob('*')):
            info = path.lstat()
            if stat.S_ISDIR(info.st_mode):
                continue
            if not stat.S_ISREG(info.st_mode):
                raise ValueError('unexpected non-regular source: ' + str(path))
            result.append(path.relative_to(WORK).as_posix())
    return sorted(result)


def add(tar, name, body):
    info = tarfile.TarInfo(name)
    info.size = len(body)
    info.mode = 0o644
    info.uid = info.gid = info.mtime = 0
    info.uname = info.gname = ''
    tar.addfile(info, io.BytesIO(body))


def main():
    source_names = inventory()
    if len(source_names) != 179 or not set(OMITTED).issubset(source_names):
        raise ValueError('fixed input scope differs')
    snapshots, original_records, members, omissions = {}, [], {}, []
    publication = json.loads((WORK / 'r25-evidence/rejected-transfer-02/github-archive-blobs-complete-01.json').read_bytes())
    if publication['passed'] is not True or publication['tree_commit_branch_or_pr_mutated'] is not False:
        raise ValueError('companion blob proof did not pass')
    companion = {r['local_path']: r for r in publication['archives']}
    for name in source_names:
        body, identity = frozen(WORK / name)
        record = {'source_path': str(WORK / name), 'workspace_relative_path': name,
                  **digest(body), 'original_stat_identity': identity}
        snapshots[name] = identity
        if name in OMITTED:
            proof = companion[str(WORK / name)]
            if any(record[k] != proof[k] for k in ('bytes', 'sha256')):
                raise ValueError('omitted companion identity differs')
            omissions.append({**record, 'reason': 'exact assembled archive body is a separately published companion',
                              'repository_path': proof['repository_path'], 'git_blob_sha1': proof['git_blob_sha1']})
        else:
            record['archive_path'] = 'payload/' + name
            original_records.append(record)
            members[record['archive_path']] = body
    helper, helper_stat = frozen(WORK / HELPER)
    if hashlib.sha256(helper).hexdigest() != HELPER_SHA or len(helper) != 21835:
        raise ValueError('previously used tar helper identity differs')
    helper_record = {'archive_path': 'payload/' + HELPER, 'source_path': str(WORK / HELPER),
                     'workspace_relative_path': HELPER, **digest(helper), 'original_stat_identity': helper_stat,
                     'role': 'only additional original fixed source dependency; previously used tar reader'}
    members[helper_record['archive_path']] = helper
    support_records = []
    for name in ('README.md', 'build_custody_bundle.py', 'verify_custody_bundle.py'):
        body, identity = frozen(OUT / name)
        record = {'archive_path': 'meta/' + name, 'source_path': str(OUT / name), **digest(body),
                  'original_stat_identity': identity}
        support_records.append(record)
        members[record['archive_path']] = body
    core = json.loads((WORK / 'r25-results/core-publication-readback-01.json').read_bytes())
    if core['verified'] is not True or core['commit'] != 'bfa0d6113d675bb9f597baa474f913c3a12df37a':
        raise ValueError('published external-dependency readback differs')
    core_files = {row['path']: row for row in core['files']}
    export_path = 'tools/x230/20261105/r25/reviews/export-report-02.json'
    holder_archive_path = 'tools/x230/20261105/r25/evidence/mac-holder-02.tar.gz'
    export = core_files[export_path]
    holder_archive = core_files[holder_archive_path]
    for record in (export, holder_archive):
        body, _ = frozen(Path(record['local_path']))
        if any(digest(body)[k] != record[k] for k in ('bytes', 'sha256')):
            raise ValueError('published dependency bytes differ')
    with tarfile.open(holder_archive['local_path'], 'r:gz') as tar:
        holder_member = tar.getmember('sources/held_agent_campaign_02.py')
        if not holder_member.isfile():
            raise ValueError('published holder is not a regular source member')
        holder = tar.extractfile(holder_member).read()
    if digest(holder) != {'bytes': 11374, 'sha256': '715e996217c7d33a7483354f16f2d39c9a033f51f3a20a52484495a00262dd65'}:
        raise ValueError('published original holder source differs')
    manifest = {
        'schema': 'hepta-r25-archive-transfer-custody/v1',
        'repository_full_name': 'TrillionniumFoundation/hepta-runtime',
        'repository_path': 'tools/x230/20261105/r25/evidence/' + NAME,
        'input_roots': list(ROOTS), 'original_scope_file_count': len(source_names),
        'original_scope_total_bytes': sum(r['bytes'] for r in original_records + omissions),
        'original_included_file_count': len(original_records),
        'original_included_total_bytes': sum(r['bytes'] for r in original_records),
        'original_files': original_records, 'omitted_duplicate_archive_bodies': omissions,
        'additional_original_source_dependencies': [helper_record], 'packaging_support_files': support_records,
        'external_dependencies': [
            {'role': 'original export report', 'source_path': str(WORK / 'r25-evidence/rejected-export-02-report.json'),
             'repository_path': export_path, 'published_commit': core['commit'],
             **{k: export[k] for k in ('bytes', 'sha256', 'git_blob_sha1')}},
            {'role': 'unchanged original holder source',
             'source_path': '/workspace/scratch/846f8b2ab644/r21/audit-harness/mac-holder-download-01/extracted/sources/held_agent_campaign_02.py',
             **digest(holder), 'repository_archive_path': holder_archive_path,
             'archive_member': holder_member.name, 'published_commit': core['commit'],
             'archive_identity': {k: holder_archive[k] for k in ('bytes', 'sha256', 'git_blob_sha1')}}],
        'companion_archives': [{k: r[k] for k in ('repository_path', 'bytes', 'sha256', 'git_blob_sha1')}
                               for r in publication['archives']],
        'all_saved_original_api_response_payloads_in_scope_preserved': True,
        'all_saved_request_envelopes_in_scope_preserved': True,
        'historical_unrecorded_envelopes_fabricated': False,
        'original_attempt_responses_and_selected_copies_both_preserved': True,
        'all_failures_and_read_only_retries_in_scope_preserved': True,
        'native_stream_files_preserved_as_exact_bytes': True,
        'source_revisions_and_receipts_preserved': True,
        'gh_probe_and_other_tasks_excluded': True,
        'holder_original_connections': 1, 'ssh_or_workload_replayed': False,
        'archive_code_executed': False, 'archive_extracted': False,
        'qualified': True, 'external_rust_ci_passed': True, 'external_python_ci_passed': True,
        'observation_gate_passed': False, 'lifecycle_executed': False,
        'candidate_adoption_ready': False, 'hosted_actions_passed': False,
        'all_optimization_blockers_closed': False,
        'tar_metadata': {'format': 'ustar', 'regular_files_only': True, 'uid': 0, 'gid': 0,
                         'mtime': 0, 'mode_octal': '0644', 'uname': '', 'gname': ''},
        'compression': {'format': 'xz', 'preset': 6, 'check': 'sha256'},
    }
    manifest_bytes = (json.dumps(manifest, sort_keys=True, indent=2, ensure_ascii=False) + '\n').encode()
    with (OUT / 'manifest.json').open('xb') as stream:
        stream.write(manifest_bytes)
    with (OUT / NAME).open('xb') as stream:
        with lzma.LZMAFile(stream, 'w', format=lzma.FORMAT_XZ, check=lzma.CHECK_SHA256, preset=6) as compressed:
            with tarfile.open(fileobj=compressed, mode='w|', format=tarfile.USTAR_FORMAT) as tar:
                add(tar, 'manifest.json', manifest_bytes)
                for name in sorted(members):
                    add(tar, name, members[name])
    if inventory() != source_names:
        raise ValueError('input directory inventory changed while packaging')
    for name in source_names:
        body, identity = frozen(WORK / name)
        if identity != snapshots[name]:
            raise ValueError('original source changed while packaging: ' + name)
        if name not in OMITTED and body != members['payload/' + name]:
            raise ValueError('source bytes changed while packaging: ' + name)
    archive, _ = frozen(OUT / NAME)
    receipt = {'schema': 'hepta-r25-archive-transfer-custody-build/v1', 'passed': True,
               'archive': {'path': str(OUT / NAME), **digest(archive)},
               'manifest': {'path': str(OUT / 'manifest.json'), **digest(manifest_bytes)},
               'original_source_count': len(source_names), 'original_included_count': len(original_records),
               'omitted_duplicate_archive_count': len(omissions), 'additional_fixed_helper_count': 1,
               'archive_member_count': 1 + len(members), 'originals_unchanged_after_packaging': True,
               'archive_code_executed': False, 'archive_extracted': False, 'remote_calls': 0}
    with (OUT / 'build-receipt.json').open('x') as stream:
        json.dump(receipt, stream, sort_keys=True, indent=2)
        stream.write('\n')
    print(json.dumps(receipt, sort_keys=True))


if __name__ == '__main__':
    main()
