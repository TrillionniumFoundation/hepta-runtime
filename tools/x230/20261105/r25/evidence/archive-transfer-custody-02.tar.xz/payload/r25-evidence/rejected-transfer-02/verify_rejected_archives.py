#!/usr/bin/env python3
"""Inspect all R25 rejected-evidence archive bytes without extracting or executing.

Uses only the frozen local R24 tar-reader definitions, with their SHA pinned.
Remote source identities/omitted bodies are declarations, not local rehashes.
"""
from collections import Counter
import gzip
import hashlib
import json
from pathlib import Path, PurePosixPath
import sys
import tarfile
import types

sys.dont_write_bytecode = True
WORK = Path('/workspace/scratch/806ba5f52f94')
LOCAL = WORK / 'r25-evidence/rejected-transfer-02'
REMOTE = PurePosixPath('/home/qian/hepta-runtime-optimization-20261105-r25')
EXPORT_PATH = WORK / 'r25-evidence/rejected-export-02-report.json'
EXPORT_SHA = 'e89ad03ca9bdeaa4294714ee74b8956e5c9c787acd3d0666de37bbe60d3822d8'
HELPER_PATH = WORK / 'r24-transfer/archive_tar_qa.py'
HELPER_SHA = 'd5cf47fa484d71a78ce07b2154e6c89a268ca18d583263aad387c6b07422237c'
OFFICIAL_ARCHIVE_REASON = 'verified official upstream tool archive body omitted; exact identity and source URL retained in install receipt'
GROUPS = ('ci', 'observation', 'qualification')
ROOTS = {
    'qualification': {'qualification': str(REMOTE / 'qualification-02')},
    'observation': {'observation': str(REMOTE / 'campaign-02'),
        'recovery': '/home/qian/hepta-runtime-optimization-20261104-r16/r25-cancel-recovery-02',
        'campaign-tools': str(REMOTE / 'campaign-tools-02'), 'boundary-tools': str(REMOTE / 'boundary-tools-02')},
    'ci': {'rust': str(REMOTE / 'rust-ci-02'), 'rust-tools': str(REMOTE / 'rust-ci-tools-02'),
        'python': str(REMOTE / 'python-ci-01'), 'python-launch': str(REMOTE / 'python-ci-launch-01'),
        'python-inputs': str(REMOTE / 'ci-gates'), 'private-nextest': str(REMOTE / 'ci-toolchain/nextest-0.9.137')},
}
NATIVE_JOBS = {
    'qualification-terminal-status-02.json': '1a1aaa6552d-fc05-459f',
    'rust-ci-native-terminal-02.json': '1a1aac67f44-fc05-471d',
    'python-ci-native-terminal-01.json': '1a1aaa69a3d-fc05-45a1',
    'observation-native-terminal-02.json': '1a1aacd207e-fc05-4774',
}
REJECTION = ['C1 regression gate', 'C1 controller CPU regression gate']
REPORT_MEMBERS = {'ci': {'rust/report.json', 'python/report.json'},
                  'observation': {'observation/report.json', 'observation/summary.json'},
                  'qualification': {'qualification/report.json'}}


def load_helpers():
    raw = HELPER_PATH.read_bytes()
    if hashlib.sha256(raw).hexdigest() != HELPER_SHA:
        raise ValueError('frozen local tar helper identity differs')
    module = types.ModuleType('_r24_tar_reader')
    module.__file__ = str(HELPER_PATH)
    exec(compile(raw, str(HELPER_PATH), 'exec'), module.__dict__)
    module.OMISSION_REASONS = module.OMISSION_REASONS | {OFFICIAL_ARCHIVE_REASON}
    return module


def read_local(q, path):
    with q.stable_reader(path, 32 * 1024 * 1024) as (stream, _before):
        return stream.read()


def identity(raw):
    return {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


def excluded(name, expected, group):
    path = PurePosixPath(expected['source_path'])
    reasons = []
    if expected['is_elf']:
        reasons.append('elf')
    if path.parent.name == 'profile' and path.name in {'ssh_config', 'known_hosts', 'profile.json'}:
        reasons.append('private_profile_configuration')
    if group == 'observation' and (path.name == 'runtime.json' or path.parent.name == 'bin' and path.name in {'ssh', 'ssh-original'}):
        reasons.append('fixture_transport_configuration_or_wrapper')
    if path == REMOTE / 'ci-toolchain/nextest-0.9.137/cargo-nextest-0.9.137.tar.gz.partial':
        reasons.append('official_upstream_tool_archive')
    return reasons


def manifest_check(q, manifest, group, observed, exporter, all_sources):
    q.need(set(manifest) == {'schema', 'group', 'files', 'omitted_bodies', 'source_trees', 'terminal_inputs',
                             'native_terminals', 'candidate_disposition', 'lifecycle_executed'}, 'manifest fields differ')
    q.need(manifest['schema'] == 'hepta-r25-archive-manifest/v2' and manifest['group'] == group, 'manifest schema/group differs')
    q.need(manifest['candidate_disposition'] == 'rejected_observation_performance'
           and manifest['lifecycle_executed'] is False, 'manifest rejection state differs')
    q.need(manifest['terminal_inputs'] == exporter['terminal_inputs']
           and manifest['native_terminals'] == exporter['native_terminals'], 'terminal identities differ across archives/export')
    files, omissions = manifest['files'], manifest['omitted_bodies']
    q.need(set(observed) == set(files), 'archive payload set differs from manifest')
    declared = {}
    for name, expected in files.items():
        q.archive_path(name)
        q.validate_identity(expected)
        q.need(observed[name]['bytes'] == expected['bytes'] and observed[name]['sha256'] == expected['sha256']
               and observed[name]['is_elf'] is False and not excluded(name, expected, group), 'payload identity/exclusion differs: ' + name)
        declared[name] = expected
    omitted_names, reason_counts = set(), Counter()
    for row in omissions:
        q.validate_identity(row, omitted=True)
        name = row['archive_path']
        q.need(name not in files and name not in omitted_names and name != '_export-manifest.json', 'omitted path duplicates payload/omission')
        omitted_names.add(name)
        reason_counts[row['omission_reason']] += 1
        q.need(excluded(name, row, group) or row['omission_reason'] == 'external system/profile input body omitted; exact identity retained',
               'omission lacks a known exclusion category')
        declared[name] = row
    q.validate_inventory(manifest['source_trees'])
    q.need(set(manifest['source_trees']) == set(ROOTS[group].values()), 'source-tree roots differ from original exporter')
    for prefix, root in ROOTS[group].items():
        inventory = manifest['source_trees'][root]
        expected_files = set(inventory['files'])
        observed_files = {row['source_path'] for row in declared.values() if PurePosixPath(row['source_path']).is_relative_to(root)}
        q.need(expected_files == observed_files, 'source-tree file declaration coverage differs: ' + root)
        q.need(not set(inventory['files']).intersection(inventory['directories']), 'file/directory inventory intersects')
        directory_set = set(inventory['directories'])
        for source in expected_files:
            rel = PurePosixPath(source).relative_to(root).as_posix()
            name = prefix + '/' + rel
            q.need(name in declared and declared[name]['source_path'] == source, 'source-tree archive path mapping differs')
            q.need(str(PurePosixPath(source).parent) in directory_set, 'source file parent missing from declared inventory')
        for directory in directory_set - {root}:
            q.need(str(PurePosixPath(directory).parent) in directory_set, 'source directory parent missing from declared inventory')
    for name, row in declared.items():
        base = {key: row[key] for key in q.IDENTITY_FIELDS}
        source = row['source_path']
        q.need(source not in all_sources or all_sources[source] == base, 'same source has conflicting identities across archives')
        all_sources[source] = base
    expected = exporter['archives'][group]
    q.need(len(files) == expected['payload_files'] and len(omissions) == expected['omitted_bodies']
           and sum(row['bytes'] for row in files.values()) == expected['source_bytes'], 'exported archive counts differ')
    return {'payload_files': len(files), 'payload_bytes': sum(row['bytes'] for row in files.values()),
            'omitted_bodies': len(omissions), 'omitted_declared_bytes': sum(row['bytes'] for row in omissions),
            'omission_reasons': dict(reason_counts), 'source_tree_metadata_consistent_with_manifest': True,
            'payload_member_set_matches_manifest': True, 'all_payload_sha256_and_bytes_recomputed': True,
            'omitted_body_hashes_locally_recomputed': False, 'remote_filesystem_stat_metadata_locally_reverified': False}


def inspect(q, group, exporter, all_sources, retained):
    path = LOCAL / 'reconstructed' / (group + '-02.tar.gz')
    expected = exporter['archives'][group]
    observed, names, manifest, last_end = {}, set(), None, 0
    row = {'group': group, 'path': str(path), 'passed': False}
    with q.stable_reader(path, q.MAX_ARCHIVE_BYTES) as (compressed, before):
        actual = q.hash_file(compressed, before.st_size)
        q.need(actual == {key: expected['archive'][key] for key in ('bytes', 'sha256')}, 'archive SHA/size differs')
        row.update(actual)
        compressed.seek(0)
        with gzip.GzipFile(fileobj=compressed, mode='rb') as unpacked:
            with tarfile.open(fileobj=unpacked, mode='r:', ignore_zeros=False, errorlevel=2) as archive:
                for member in archive:
                    q.archive_path(member.name)
                    q.need(member.name not in names and len(names) < q.MAX_MEMBERS, 'duplicate/too many tar members')
                    names.add(member.name)
                    q.need(member.mode == 0o600 and member.uid == member.gid == member.mtime == 0
                           and member.uname == member.gname == '' and set(member.pax_headers) <= {'path'}, 'noncanonical tar metadata')
                    item, raw = q.read_member(archive, member, retain=True)
                    if member.name == '_export-manifest.json':
                        q.need(len(names) == 1, 'manifest must be the first semantic member')
                        q.need({key: item[key] for key in ('bytes', 'sha256')}
                               == {key: expected['manifest'][key] for key in ('bytes', 'sha256')}, 'manifest SHA/size differs')
                        manifest = q.decode_json(raw)
                        row['manifest'] = {key: item[key] for key in ('bytes', 'sha256')}
                    else:
                        observed[member.name] = item
                        if member.name in REPORT_MEMBERS[group] or member.name.startswith('receipts/') and member.name.split('/')[-1] in NATIVE_JOBS:
                            retained[(group, member.name)] = raw
                        if member.name.startswith(('observation/', 'recovery/', 'control/', 'abba/', 'saturation/')):
                            q.need(not any(marker in raw for marker in (b'-----BEGIN OPENSSH PRIVATE KEY-----',
                                   b'-----BEGIN RSA PRIVATE KEY-----', b'-----BEGIN EC PRIVATE KEY-----',
                                   b'-----BEGIN DSA PRIVATE KEY-----')), 'private key marker in runtime output')
                    end = member.offset_data + member.size
                    padding = (-member.size) % tarfile.BLOCKSIZE
                    unpacked.seek(end)
                    padding_raw = unpacked.read(padding)
                    q.need(len(padding_raw) == padding and not any(padding_raw), 'invalid tar body padding')
                    last_end = end + padding
            unpacked.seek(last_end)
            tail = 0
            while block := unpacked.read(q.CHUNK):
                tail += len(block)
                q.need(last_end + tail <= q.MAX_UNCOMPRESSED_BYTES and not any(block), 'nonzero/excessive tar trailer')
            q.need(tail >= 1024 and tail % 512 == 0, 'invalid tar end padding')
    q.need(manifest is not None, 'archive manifest missing')
    row.update(manifest_check(q, manifest, group, observed, exporter, all_sources))
    row.update({'semantic_members': len(names), 'uncompressed_bytes': last_end + tail,
                'gzip_crc_and_length_verified': True, 'zero_tar_body_and_end_padding': True,
                'only_regular_semantic_members': True, 'canonical_unique_member_paths': True,
                'private_runtime_key_markers_absent': True, 'passed': True})
    return row, manifest


def verify_semantics(q, exporter, manifests, retained):
    report_keys = {'qualification': ('qualification', 'qualification/report.json'),
                   'observation': ('observation', 'observation/report.json'),
                   'rust_ci': ('ci', 'rust/report.json'), 'python_ci': ('ci', 'python/report.json')}
    reports = {}
    for key, member in report_keys.items():
        raw = retained[member]
        expected = exporter['terminal_inputs'][key]
        q.need(identity(raw) == {k: expected[k] for k in ('bytes', 'sha256')}, 'actual report bytes differ: ' + key)
        reports[key] = q.decode_json(raw)
    qualification, observation = reports['qualification'], reports['observation']
    q.need(qualification['qualified'] is True and qualification['source_tested'] == qualification['source_after']
           and len(qualification['source_after']) == 221 and qualification['automatic_test_retries'] == 0, 'qualification semantics differ')
    q.need(len(qualification['stages']) == 8 and all(type(row['returncode']) is int and row['returncode'] == 0
                                                  for row in qualification['stages']), 'qualification stage outcomes differ')
    source = {name[len('source/'):]: row['sha256'] for name, row in manifests['qualification']['files'].items() if name.startswith('source/')}
    q.need(source == qualification['source_after'], 'all 221 archived source hashes do not match actual qualification')
    q.need(observation['passed'] is True and observation['observation_gate_passed'] is False
           and observation['rejection_reasons'] == REJECTION and observation['inputs_unchanged'] is True
           and observation['source_inputs_unchanged'] is True, 'observation rejection state differs')
    summary_raw = retained[('observation', 'observation/summary.json')]
    q.need(identity(summary_raw) == {'bytes': 14430, 'sha256': '68fd9d1cc05d2c0eab670ccd6d3d99ec4922a3eb369b02cb3b3d16e70bc9737c'}, 'actual summary bytes differ')
    summary = q.decode_json(summary_raw)
    q.need(summary['evidence_verified'] is True and summary['correctness_verified'] is True
           and summary['observation_gate_passed'] is False and summary['rejection_reasons'] == REJECTION, 'summary rejection semantics differ')
    for key in ('rust_ci', 'python_ci'):
        q.need(reports[key]['passed'] is True and reports[key]['hosted_actions_passed'] is False, 'external CI scope differs')
    native = {}
    for name, job in NATIVE_JOBS.items():
        candidates = [body for (group, member), body in retained.items() if member == 'receipts/' + name]
        q.need(candidates and all(body == candidates[0] for body in candidates), 'native terminal missing/inconsistent')
        raw = candidates[0]
        expected = exporter['native_terminals'][name]
        q.need(identity(raw) == {k: expected[k] for k in ('bytes', 'sha256')}, 'original native terminal bytes differ')
        terminal = q.decode_json(raw)
        q.need(terminal['job_id'] == job and terminal['state'] == 'succeeded' and type(terminal['exit_code']) is int
               and terminal['exit_code'] == 0 and terminal['terminal_publication_protocol'] == 1, 'native terminal state differs')
        q.need(all(terminal[k] is True for k in ('terminal_publication_confirmed', 'output_durable', 'output_complete', 'audit_recorded'))
               and all(terminal[k] is False for k in ('automatic_retry', 'timed_out', 'cancelled')), 'native terminal durability differs')
        for stream in ('stdout', 'stderr'):
            q.need(terminal['log_synced'][stream] is True and terminal['log_truncated'][stream] is False
                   and terminal['log_errors'][stream] is None
                   and terminal['log_bytes'][stream]['seen'] == terminal['log_bytes'][stream]['stored'], 'native terminal stream proof differs')
        native[name] = {'job_id': job, **identity(raw), 'strong_terminal_proof': True}
    return {'qualified': True, 'qualified_source_files': 221, 'all_archived_source_bytes_bound_to_qualification': True,
            'observation_correctness_passed': True, 'observation_gate_passed': False, 'rejection_reasons': REJECTION,
            'external_rust_ci_passed': True, 'external_python_ci_passed': True, 'hosted_actions_passed': False,
            'lifecycle_executed': False, 'candidate_adoption_ready': False, 'all_optimization_blockers_closed': False,
            'native_terminals': native, 'omitted_bodies_are_metadata_only': True,
            'no_archived_code_executed': True, 'no_workload_reexecuted': True}


def main():
    q = load_helpers()
    output = LOCAL / 'archive-integrity-and-semantics-02.json'
    q.need(not output.exists(), 'fresh audit output required')
    result = {'schema': 'hepta-r25-rejected-evidence-local-audit/v1', 'passed': False, 'started_utc': q.utc(),
              'tar_reader': {'path': str(HELPER_PATH), 'sha256': HELPER_SHA},
              'verifier': {'path': str(Path(__file__).resolve()), **identity(Path(__file__).read_bytes())},
              'scope': 'All payload bytes and inventory/omission metadata checked locally; no extraction, remote access, archived-code execution, or workload replay.',
              'archives': []}
    try:
        raw = read_local(q, EXPORT_PATH)
        q.need(hashlib.sha256(raw).hexdigest() == EXPORT_SHA, 'actual exporter report identity differs')
        exporter = q.decode_json(raw)
        result['actual_export_report'] = {'path': str(EXPORT_PATH), **identity(raw)}
        q.need(exporter['passed'] is True and exporter['candidate_disposition'] == 'rejected_observation_performance'
               and exporter['candidate_adoption_ready'] is False and exporter['observation_gate_passed'] is False
               and exporter['lifecycle_executed'] is False and exporter['all_optimization_blockers_closed'] is False,
               'exporter rejection disposition differs')
        sources, retained, manifests = {}, {}, {}
        for group in GROUPS:
            row, manifests[group] = inspect(q, group, exporter, sources, retained)
            result['archives'].append(row)
        result['semantics'] = verify_semantics(q, exporter, manifests, retained)
        result['unique_remote_source_identity_declarations'] = len(sources)
        result['passed'] = True
    except Exception as error:
        result['error'] = {'type': type(error).__name__, 'reason': str(error)[:800]}
    result['finished_utc'] = q.utc()
    q.write_report(output, result)
    print(json.dumps({'passed': result['passed'], 'report': str(output), 'error': result.get('error'),
                      'archives': [{'group': row['group'], 'payload_files': row['payload_files'],
                                    'omitted_bodies': row['omitted_bodies'], 'passed': row['passed']}
                                   for row in result['archives']]}, sort_keys=True))
    return 0 if result['passed'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
