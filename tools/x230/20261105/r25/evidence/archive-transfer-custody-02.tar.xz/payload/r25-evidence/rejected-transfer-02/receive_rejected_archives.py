#!/usr/bin/env python3
"""Verify exact saved read_multiple_files texts and assemble immutable R25 evidence.

No remote calls, extraction, benchmark execution, or Git mutation. Original
timeout receipts are retained separately and are never treated as chunk data.
"""
import argparse
import base64
import hashlib
import json
import os
from pathlib import Path
import re
import stat

WORK = Path('/workspace/scratch/806ba5f52f94')
ROOT = WORK / 'r25-evidence/rejected-transfer-02'
GROUPS = ('ci', 'observation', 'qualification')
EXPORT = WORK / 'r25-evidence/rejected-export-02-report.json'
EXPORT_SHA = 'e89ad03ca9bdeaa4294714ee74b8956e5c9c787acd3d0666de37bbe60d3822d8'
HEX = re.compile(r'[0-9a-f]{64}\Z')
STAMP = ('st_dev', 'st_ino', 'st_mode', 'st_nlink', 'st_size', 'st_mtime_ns', 'st_ctime_ns')


def need(ok, reason):
    if not ok:
        raise ValueError(reason)


def digest(raw):
    return {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


def decode(raw):
    def pairs(rows):
        result = {}
        for key, value in rows:
            need(key not in result, 'duplicate JSON key')
            result[key] = value
        return result
    def bad(_):
        raise ValueError('nonfinite JSON value')
    return json.loads(raw, object_pairs_hook=pairs, parse_constant=bad)


def read(path):
    need(path.is_absolute() and path.resolve() == path, 'direct absolute local file required')
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_CLOEXEC)
    try:
        before = os.fstat(fd)
        need(stat.S_ISREG(before.st_mode) and before.st_nlink == 1, 'singly linked regular file required')
        need(before.st_size <= 32 * 1024 * 1024, 'input exceeds local bound')
        with os.fdopen(fd, 'rb', closefd=False) as stream:
            raw = stream.read()
        stamps = [tuple(getattr(s, k) for k in STAMP) for s in (before, os.fstat(fd), path.lstat())]
        need(stamps[0] == stamps[1] == stamps[2] and len(raw) == before.st_size, 'local input changed')
        return raw
    finally:
        os.close(fd)


def write_once(path, raw):
    if path.exists():
        need(read(path) == raw, 'existing output differs; refusing overwrite: ' + path.name)
        return
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW | os.O_CLOEXEC, 0o600)
    with os.fdopen(fd, 'wb') as stream:
        stream.write(raw)
        stream.flush()
        os.fsync(stream.fileno())


def encoded(value):
    return (json.dumps(value, sort_keys=True, indent=2, allow_nan=False) + '\n').encode()


def inputs():
    raw = read(EXPORT)
    need(hashlib.sha256(raw).hexdigest() == EXPORT_SHA, 'actual exporter receipt identity differs')
    export = decode(raw)
    need(export['passed'] is True and export['observation_gate_passed'] is False
         and export['candidate_adoption_ready'] is False, 'actual rejection export state differs')
    chunks, manifests, pins = [], {}, {}
    for group in GROUPS:
        path = ROOT / (group + '-chunks-manifest.json')
        raw = read(path)
        expected = export['archives'][group]['transfer']['manifest']
        need(digest(raw) == {k: expected[k] for k in ('bytes', 'sha256')}, 'chunk manifest identity differs')
        value = decode(raw)
        need(value['schema'] == 'hepta-r25-lossless-archive-chunks/v1' and value['encoding'] == 'base64', 'chunk schema differs')
        need(value['maximum_decoded_chunk_bytes'] == 48000 and value['maximum_text_file_bytes'] == 64000, 'chunk bounds differ')
        need(value['archive'] == export['archives'][group]['archive'], 'archive source identity differs')
        offset = 0
        need(len(value['chunks']) == export['archives'][group]['transfer']['chunks'], 'chunk count differs')
        for i, row in enumerate(value['chunks']):
            need(set(row) == {'path', 'offset', 'bytes', 'sha256', 'base64_bytes', 'base64_sha256'}, 'chunk fields differ')
            need(row['path'] == value['archive']['source_path'] + '.chunks/chunk-' + f'{i:05d}' + '.b64', 'chunk path differs')
            size = min(48000, value['archive']['bytes'] - offset)
            need(type(row['offset']) is int and row['offset'] == offset and type(row['bytes']) is int and row['bytes'] == size > 0, 'chunk offset/size differs')
            need(row['base64_bytes'] == 4 * ((size + 2) // 3) <= 64000, 'base64 size differs')
            need(HEX.fullmatch(row['sha256']) and HEX.fullmatch(row['base64_sha256']), 'chunk digest malformed')
            chunks.append(dict(row, group=group))
            offset += size
        need(offset == value['archive']['bytes'], 'chunk coverage differs')
        manifests[group] = value
        pins[group] = {'path': str(path), **digest(raw)}
    need(len(chunks) == 138, 'expected complete 138-chunk inventory')
    return export, manifests, chunks, pins


def verify_batch(number, chunks):
    expected = chunks[number * 4:number * 4 + 4]
    need(expected, 'batch out of range')
    path = ROOT / f'read-batch-{number:03d}.json'
    raw = read(path)
    wrapper = decode(raw)
    metadata = {key: value for key, value in wrapper.items() if key != 'response_text'}
    if metadata:
        need(number == 5 and metadata == {'transport_attempt': 2,
             'prior_timeout_record': 'read-batches-005-008-timeouts.json'}, 'unknown original response wrapper metadata')
    need(isinstance(wrapper.get('response_text'), str), 'not an exact successful response wrapper')
    exact = wrapper['response_text'].encode()
    response = decode(exact)
    need(response['atomic_snapshot'] is False and response['snapshot_scope'] == 'independent_file'
         and response['encoding'] == 'utf-8' and response['truncated'] is False, 'response snapshot/truncation differs')
    need(len(response['files']) == len(expected), 'response file count differs')
    need([r['path'] for r in response['files']] == [r['path'] for r in expected], 'response path/order differs')
    records, bodies = [], []
    for value, wanted in zip(response['files'], expected):
        need(value['eof'] is True and isinstance(value['version'], str) and value['version'], 'incomplete file or missing version')
        text = value['text'].encode('ascii')
        need(digest(text) == {'bytes': value['size'], 'sha256': value['sha256']}
             == {'bytes': wanted['base64_bytes'], 'sha256': wanted['base64_sha256']}, 'remote text size/SHA differs')
        body = base64.b64decode(text, validate=True)
        need(base64.b64encode(body) == text, 'noncanonical base64')
        need(digest(body) == {'bytes': wanted['bytes'], 'sha256': wanted['sha256']}, 'decoded chunk size/SHA differs')
        records.append(dict(wanted, remote_version=value['version']))
        bodies.append(body)
    receipt = {'schema': 'hepta-r25-rejected-evidence-read-batch/v1', 'batch': number,
               'wrapper': {'path': str(path), **digest(raw)}, 'response_text': digest(exact),
               'chunks': records, 'passed': True, 'remote_snapshot_scope': 'independent_file'}
    if metadata:
        timeout_path = ROOT / 'read-batches-005-008-timeouts.json'
        timeout_identity = digest(read(timeout_path))
        need(timeout_identity == {'bytes': 4577, 'sha256':
             '556f405844acf5c7241311c3a6ac714ef23928bd8b302a78c1d9600d45c4c42b'}, 'original timeout receipt changed')
        receipt['original_wrapper_metadata'] = metadata
        receipt['original_timeout_record'] = {'path': str(timeout_path), **timeout_identity}
    return receipt, bodies


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('command', choices=('batch', 'scan', 'assemble'))
    parser.add_argument('--batch', type=int)
    args = parser.parse_args()
    export, manifests, chunks, pins = inputs()
    if args.command == 'batch':
        receipt, _ = verify_batch(args.batch, chunks)
        write_once(ROOT / f'verified-batch-{args.batch:03d}.json', encoded(receipt))
        print(json.dumps({'passed': True, 'batch': args.batch, 'chunks': len(receipt['chunks']), 'wrapper': receipt['wrapper']}))
        return
    receipts, bodies, missing = [], {g: [] for g in GROUPS}, []
    for i in range((len(chunks) + 3) // 4):
        if not (ROOT / f'read-batch-{i:03d}.json').exists():
            missing.append(i)
            continue
        receipt, decoded = verify_batch(i, chunks)
        receipts.append(receipt)
        for row, body in zip(receipt['chunks'], decoded):
            bodies[row['group']].append((row['offset'], body))
    result = {'schema': 'hepta-r25-rejected-evidence-transfer/v1', 'complete': not missing,
              'receiver': {'path': str(Path(__file__).resolve()), **digest(read(Path(__file__).resolve()))},
              'actual_export_report': {'path': str(EXPORT), **digest(read(EXPORT))},
              'chunk_manifests': pins, 'expected_chunks': len(chunks),
              'verified_chunks': sum(len(r['chunks']) for r in receipts),
              'missing_batches': missing, 'read_batches': receipts,
              'workload_reexecuted': False, 'observation_gate_passed': False,
              'candidate_adoption_ready': False}
    if args.command == 'assemble':
        need(not missing, 'missing validated read batches')
        out = ROOT / 'reconstructed'
        out.mkdir(mode=0o700, exist_ok=True)
        need(out.resolve() == out and not out.is_symlink(), 'output directory is indirect')
        artifacts = []
        for group in GROUPS:
            body = b''.join(b for _, b in sorted(bodies[group]))
            expected = manifests[group]['archive']
            need(digest(body) == {k: expected[k] for k in ('bytes', 'sha256')}, 'assembled archive differs')
            target = out / (group + '-02.tar.gz')
            write_once(target, body)
            git_sha = hashlib.sha1(b'blob ' + str(len(body)).encode() + b'\0' + body).hexdigest()
            artifacts.append({'group': group, 'path': str(target), **digest(body),
                              'git_blob_sha1': git_sha, 'remote_source': expected,
                              'repository_path': 'tools/x230/20261105/r25/evidence/' + target.name})
        result['archives'] = artifacts
        result['passed'] = True
        write_once(ROOT / 'archive-assembly-report-02.json', encoded(result))
        print(json.dumps({'passed': True, 'archives': artifacts}, sort_keys=True))
    else:
        print(json.dumps({k: result[k] for k in ('complete', 'expected_chunks', 'verified_chunks', 'missing_batches')}, sort_keys=True))


if __name__ == '__main__':
    main()
