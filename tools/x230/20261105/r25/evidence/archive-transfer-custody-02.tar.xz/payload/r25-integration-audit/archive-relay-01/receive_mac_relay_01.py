#!/usr/bin/env python3
"""Verify saved Mac chunk responses against both relay and original X230 maps.

Reuses the first56 already verified X230 chunks. No remote access, extraction,
workload execution, or archived-code execution is performed by this receiver.
"""
import argparse
import base64
import hashlib
import json
from pathlib import Path
import struct
import sys
import types

sys.dont_write_bytecode = True
WORK = Path('/workspace/scratch/806ba5f52f94')
HERE = WORK / 'r25-integration-audit/archive-relay-01'
TRANSFER = WORK / 'r25-evidence/mac-relay-transfer-01'
REMOTE = '/Users/qianqi/work/hepta-runtime-r25-archive-relay-01'
GROUPS = ('observation', 'qualification')
DECODER_SHA = '3875fed7c5da14fcf787039be3d7f454a80a8946bcf5f8d39d67c929f2960b58'
STREAMER_SHA = '34e720eee4a762c3f0010d90b00bd3eb55878719c1a6f0b1415568dd67673f4c'
HOLDER_JOB = '1a1ab1770a5-fc05-4a36'


def load(name, expected):
    path = WORK / name
    raw = path.read_bytes()
    if hashlib.sha256(raw).hexdigest() != expected:
        raise ValueError('frozen local receiver/helper changed')
    module = types.ModuleType(name)
    module.__file__ = str(path)
    exec(compile(raw, str(path), 'exec'), module.__dict__)
    return module


r = load('r25-evidence/rejected-transfer-02/receive_rejected_archives.py',
         '818865770c5989eeed66def240b1a255664613d53b24c76873fede0e39d48746')
d = load('r25-integration-audit/archive-relay-01/decode_mac_relay_03.py', DECODER_SHA)
need = r.need


def value(path):
    raw = r.read(path)
    wrapper = r.decode(raw)
    need(wrapper.get('isError', False) is False, 'original tool result is an error')
    texts = [item['text'] for item in wrapper['content'] if item['type'] == 'text']
    need(len(texts) == 1, 'ambiguous original tool text')
    return r.decode(texts[0]), {'path': str(path), **r.digest(raw)}


def inputs():
    export, old_manifests, chunks, pins = r.inputs()
    metadata, metadata_identity = value(TRANSFER / 'metadata-read-01.raw.json')
    need(metadata['truncated'] is False and metadata['encoding'] == 'utf-8'
         and metadata['atomic_snapshot'] is False and metadata['snapshot_scope'] == 'independent_file', 'metadata read was incomplete')
    expected_paths = [REMOTE + '/relay-decoder-report-02.json'] + [REMOTE + '/decoded-02/' + g + '-02.tar.gz.chunks/manifest.json' for g in GROUPS]
    need([f['path'] for f in metadata['files']] == expected_paths, 'metadata path/order differs')
    documents, raw_identities = {}, {}
    for f in metadata['files']:
        body = f['text'].encode()
        need(f['eof'] is True and isinstance(f['version'], str) and f['version']
             and r.digest(body) == {'bytes': f['size'], 'sha256': f['sha256']}, 'metadata text bytes/SHA differ')
        documents[f['path']] = r.decode(body)
        raw_identities[f['path']] = {'bytes': f['size'], 'sha256': f['sha256'], 'version': f['version']}
    report = documents[expected_paths[0]]
    start, start_id = value(HERE / 'decode-start-02.raw.json')
    status, status_id = value(HERE / 'decode-status-02.raw.json')
    read, read_id = value(HERE / 'decode-read-02.raw.json')
    request = r.decode(r.read(HERE / 'decode-request-02.json'))
    job = start['job']['id']
    need(start['reused'] is False and start['job']['idempotency_key'] == request['idempotency_key']
         and start['job']['args'] == request['args'] and start['job']['host'] == 'main'
         and start['job']['executable'] == request['executable'], 'original decoder admission differs')
    d.verify_terminal(status, job)
    streams = d.native_streams(read, status, job)
    need(r.decode(streams['stdout']) == {'passed': True, 'report': expected_paths[0], 'archives': list(GROUPS), 'error': None}, 'actual decoder native footer differs')
    need(report['schema'] == 'hepta-r25-mac-frozen-archive-relay/v1' and report['passed'] is True
         and report['original_holder_job_id'] == HOLDER_JOB and report['original_export_report_sha256'] == r.EXPORT_SHA
         and report['decoder']['sha256'] == DECODER_SHA and report['streamer']['sha256'] == STREAMER_SHA
         and report['unchanged_holder']['sha256'] == d.HOLDER_SHA, 'relay report source/native binding differs')
    need(all(report[key] is False for key in ('workload_executed', 'archive_code_executed', 'archive_extracted', 'observation_gate_passed', 'candidate_adoption_ready'))
         and all(report[key] is True for key in ('holder_cleanup_verified', 'strong_original_native_terminal_verified', 'all_origin_archive_bytes_rehashed')),
         'relay report scope or original proof differs')
    need(report['native_terminal']['sha256'] == '68856a16ae5a9662a5ffce68be378974f1082c5b0fa59754b9263ee0d2c693bb'
         and report['native_read']['sha256'] == '3bf3741a0a8e0bf5c27470a008fc51924541cfbbb2c7e28974154f9d4d23d336'
         and report['previous_decode_failure']['sha256'] == '39291f83472808288fea8cb4ccd7812ad57327c2cf347f9c902cb33c3eb93e6b',
         'original holder or preserved failed decode bytes differ')
    mac_chunks = {}
    for g in GROUPS:
        path = REMOTE + '/decoded-02/' + g + '-02.tar.gz.chunks/manifest.json'
        m = documents[path]
        need(m['schema'] == 'hepta-r25-mac-archive-relay-chunks/v1' and m['group'] == g and m['encoding'] == 'base64'
             and m['maximum_decoded_chunk_bytes'] == 48000 and m['maximum_text_file_bytes'] == 64000, 'relay chunk schema/bounds differ')
        need(m['origin_archive'] == export['archives'][g]['archive'] == report['archives'][g]['origin_archive'], 'relay origin archive identity differs')
        need(m['archive'] == report['archives'][g]['archive'] and m['archive']['source_path'] == REMOTE + '/decoded-02/' + g + '-02.tar.gz'
             and all(m['archive'][key] == m['origin_archive'][key] for key in ('bytes', 'sha256')), 'Mac archive is not the exact original byte sequence')
        need(m['original_holder_job_id'] == HOLDER_JOB and m['forwarded_stdout_sha256'] == report['forwarded_stdout']['sha256']
             and m['stream_prefix_sha256'] == report['frame_footer']['stream_sha256'], 'relay manifest framing proof differs')
        need({key: raw_identities[path][key] for key in ('bytes', 'sha256')}
             == {key: report['archives'][g]['manifest'][key] for key in ('bytes', 'sha256')}, 'actual manifest bytes differ from decoder report')
        old = old_manifests[g]['chunks']
        need(len(m['chunks']) == len(old) == report['archives'][g]['chunks'], 'relay chunk count differs')
        for i, (new, original) in enumerate(zip(m['chunks'], old)):
            need(set(new) == set(original) and all(new[k] == original[k] for k in original if k != 'path')
                 and new['path'] == REMOTE + '/decoded-02/' + g + '-02.tar.gz.chunks/' + f'chunk-{i:05d}.b64', 'relay chunk data mapping differs')
            mac_chunks[(g, new['offset'])] = dict(new, group=g, original_path=original['path'])
    legacy, legacy_receipts = {}, []
    for number in range(14):
        receipt, bodies = r.verify_batch(number, chunks)
        legacy_receipts.append(receipt)
        for row, body in zip(receipt['chunks'], bodies):
            legacy[(row['group'], row['offset'])] = body
    need(len(legacy) == 56, 'original verified chunk count differs')
    remaining = [mac_chunks[(row['group'], row['offset'])] for row in chunks if (row['group'], row['offset']) not in legacy]
    need(len(remaining) == 82, 'remaining exact chunk count differs')
    proof = {'metadata_response': metadata_identity, 'metadata_files': raw_identities,
             'actual_decoder_job_id': job, 'actual_decoder_start': start_id, 'actual_decoder_status': status_id,
             'actual_decoder_read': read_id, 'legacy_verified_chunks': 56, 'remaining_mac_chunks': 82,
             'legacy_read_batches': legacy_receipts, 'remaining': remaining}
    return export, report, old_manifests, legacy, remaining, proof


def batch(number, expected):
    rows = expected[number * 4:number * 4 + 4]
    need(rows, 'Mac batch is out of range')
    response, identity = value(TRANSFER / f'read-batch-{number:03d}.raw.json')
    need(response['truncated'] is False and response['atomic_snapshot'] is False
         and response['snapshot_scope'] == 'independent_file' and response['encoding'] == 'utf-8', 'Mac batch is incomplete')
    need([f['path'] for f in response['files']] == [row['path'] for row in rows], 'Mac chunk paths/order differ')
    bodies, versions = {}, []
    for f, row in zip(response['files'], rows):
        encoded = f['text'].encode('ascii')
        need(f['eof'] is True and isinstance(f['version'], str) and f['version']
             and r.digest(encoded) == {'bytes': f['size'], 'sha256': f['sha256']}
             == {'bytes': row['base64_bytes'], 'sha256': row['base64_sha256']}, 'Mac chunk text size/SHA differs')
        body = base64.b64decode(encoded, validate=True)
        need(base64.b64encode(body) == encoded and r.digest(body) == {'bytes': row['bytes'], 'sha256': row['sha256']}, 'Mac chunk decoded bytes/SHA differ')
        bodies[(row['group'], row['offset'])] = body
        versions.append(dict(row, remote_version=f['version']))
    return bodies, {'batch': number, 'original_response': identity, 'chunks': versions, 'passed': True}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('command', choices=('plan', 'batch', 'assemble'))
    parser.add_argument('--batch', type=int)
    args = parser.parse_args()
    export, report, old, data, remaining, proof = inputs()
    if args.command == 'plan':
        r.write_once(TRANSFER / 'remaining-plan-01.json', r.encoded(proof))
        print(json.dumps({'passed': True, 'remaining_chunks': len(remaining), 'batches': 21}))
        return
    if args.command == 'batch':
        _, receipt = batch(args.batch, remaining)
        r.write_once(TRANSFER / f'verified-batch-{args.batch:03d}.json', r.encoded(receipt))
        print(json.dumps({'passed': True, 'batch': args.batch, 'chunks': len(receipt['chunks'])}))
        return
    receipts = []
    for number in range(21):
        bodies, receipt = batch(number, remaining)
        need(not set(data).intersection(bodies), 'duplicate original/relayed chunk')
        data.update(bodies)
        receipts.append(receipt)
    artifacts, payloads = [], {}
    for g in GROUPS:
        body = b''.join(data[(g, row['offset'])] for row in old[g]['chunks'])
        original = export['archives'][g]['archive']
        need(r.digest(body) == {key: original[key] for key in ('bytes', 'sha256')}, 'full relayed archive differs from original export')
        target = r.ROOT / 'reconstructed' / (g + '-02.tar.gz')
        r.write_once(target, body)
        payloads[g] = body
        artifacts.append({'group': g, 'path': str(target), **r.digest(body),
                          'git_blob_sha1': hashlib.sha1(b'blob ' + str(len(body)).encode() + b'\0' + body).hexdigest(),
                          'repository_path': 'tools/x230/20261105/r25/evidence/' + target.name})
    # Independently reconstruct the exact binary stdout from the verified archive
    # bytes and frozen protocol, then match the original holder's full log SHA.
    header = {'schema': 'hepta-r25-frozen-archive-stream/v1', 'export_report_sha256': r.EXPORT_SHA,
              'launcher_sha256': STREAMER_SHA, 'archives': [{'group': g, 'identity': export['archives'][g]['archive']} for g in GROUPS]}
    need(report['frame_header'] == header, 'actual frame header differs')
    encoded = d.encode(header)
    prefix = d.MAGIC + struct.pack('>I', len(encoded)) + encoded
    completed = []
    for g in GROUPS:
        body, original = payloads[g], export['archives'][g]['archive']
        prefix += struct.pack('>Q', len(body)) + body
        completed.append({'group': g, **r.digest(body), 'descriptor_identity_before': original['original_identity'], 'descriptor_identity_after': original['original_identity']})
    footer = {'schema': 'hepta-r25-frozen-archive-stream-result/v1', 'passed': True, 'files': completed,
              'stream_sha256': hashlib.sha256(prefix).hexdigest(), 'workload_executed': False}
    need(report['frame_footer'] == footer, 'actual frame footer differs')
    encoded = d.encode(footer)
    stream = prefix + struct.pack('>I', len(encoded)) + encoded + d.END
    holder_raw = r.read(HERE / 'actual-holder-report-01.json')
    need(hashlib.sha256(holder_raw).hexdigest() == '387e5ec14e0ddcc4b9d8be820e9d2da7ba93d8e05f2ef82462d54f9996240670', 'original independently read holder report changed')
    holder = r.decode(holder_raw)
    original_stream = next(row for row in holder['log_files'] if row['file'] == 'forwarded.stdout')
    need(r.digest(stream) == {key: original_stream[key] for key in ('bytes', 'sha256')}
         == {key: report['forwarded_stdout'][key] for key in ('bytes', 'sha256')}, 'reconstructed full binary stdout differs from original holder log')
    result = {'schema': 'hepta-r25-frozen-relay-local-assembly/v1', 'passed': True, 'archives': artifacts,
              'receipt_proof': proof, 'mac_read_batches': receipts, 'original_full_binary_stdout_reconstructed_and_sha_verified': r.digest(stream),
              'original_x230_chunks_used': 56, 'relayed_mac_chunks_used': 82, 'total_original_chunk_coverage': 138,
              'original_timeouts_and_failed_decode_preserved': True, 'holder_connections': 1,
              'workload_reexecuted': False, 'archive_code_executed': False, 'observation_gate_passed': False,
              'candidate_adoption_ready': False}
    r.write_once(TRANSFER / 'archive-assembly-report-01.json', r.encoded(result))
    print(json.dumps({'passed': True, 'archives': artifacts, 'full_original_stdout': r.digest(stream)}, sort_keys=True))


if __name__ == '__main__':
    main()
