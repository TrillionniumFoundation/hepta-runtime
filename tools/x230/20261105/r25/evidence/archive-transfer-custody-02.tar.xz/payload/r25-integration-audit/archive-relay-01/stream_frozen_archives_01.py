#!/usr/bin/env python3
"""Read two exact frozen X230 archives into one framed SSH stdout; no writes."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import stat
import struct
import sys

EXPORT_REPORT_SHA = 'e89ad03ca9bdeaa4294714ee74b8956e5c9c787acd3d0666de37bbe60d3822d8'
MAGIC = b'HEPTA-R25-FROZEN-ARCHIVE-RELAY/v1\0'
END = b'\0HEPTA-R25-RELAY-END\0'
STAMP = ('st_dev', 'st_ino', 'st_uid', 'st_mode', 'st_nlink', 'st_size', 'st_mtime_ns', 'st_ctime_ns')
ARCHIVES = [
    {'group': 'observation', 'identity': {
        'source_path': '/home/qian/hepta-runtime-optimization-20261105-r25/evidence-export-rejection-02/observation-02.tar.gz',
        'bytes': 3229182, 'sha256': 'b463c80bb3897b4a96ce60d6cb7452ee23b521c50fe9c22048ea23169d180c7c', 'is_elf': False,
        'original_identity': {'st_ctime_ns': 1793868032923569306, 'st_dev': 2053, 'st_ino': 2366354, 'st_mode': 33152,
                              'st_mtime_ns': 1793868032923569306, 'st_nlink': 1, 'st_size': 3229182, 'st_uid': 1000}}},
    {'group': 'qualification', 'identity': {
        'source_path': '/home/qian/hepta-runtime-optimization-20261105-r25/evidence-export-rejection-02/qualification-02.tar.gz',
        'bytes': 2450580, 'sha256': '82164857d78b965910fb5e1f8ae4d3d9769718d7fcafdd32bf2653eb1f1bd893', 'is_elf': False,
        'original_identity': {'st_ctime_ns': 1793868016369398837, 'st_dev': 2053, 'st_ino': 2366298, 'st_mode': 33152,
                              'st_mtime_ns': 1793868016369398837, 'st_nlink': 1, 'st_size': 2450580, 'st_uid': 1000}}},
]


def need(ok, message):
    if not ok:
        raise ValueError(message)


def stamp(value):
    return {key: getattr(value, key) for key in STAMP}


def encode(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), allow_nan=False).encode()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--launcher-sha256', required=True)
    args = parser.parse_args()
    need(re.fullmatch('[0-9a-f]{64}', args.launcher_sha256), 'invalid source SHA')
    opened = []
    try:
        # Establish both exact descriptor identities before publishing any frame.
        for row in ARCHIVES:
            expected = row['identity']
            path = Path(expected['source_path'])
            need(path.resolve() == path, 'archive path is indirect')
            fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK | os.O_CLOEXEC)
            opened.append((row, path, fd))
            actual = os.fstat(fd)
            need(stat.S_ISREG(actual.st_mode) and actual.st_nlink == 1 and actual.st_uid == os.geteuid(), 'archive descriptor is not an owned singly linked regular file')
            need(stamp(actual) == stamp(path.lstat()) == expected['original_identity'], 'archive descriptor differs from frozen exporter identity')
        stream_digest = hashlib.sha256()
        def emit(body):
            sys.stdout.buffer.write(body)
            stream_digest.update(body)
        header = encode({'schema': 'hepta-r25-frozen-archive-stream/v1', 'export_report_sha256': EXPORT_REPORT_SHA,
                         'launcher_sha256': args.launcher_sha256, 'archives': ARCHIVES})
        emit(MAGIC)
        emit(struct.pack('>I', len(header)))
        emit(header)
        completed = []
        for row, path, fd in opened:
            expected = row['identity']
            emit(struct.pack('>Q', expected['bytes']))
            count, digest = 0, hashlib.sha256()
            while block := os.read(fd, 1024 * 1024):
                count += len(block)
                need(count <= expected['bytes'], 'archive grew while streaming')
                digest.update(block)
                emit(block)
            need(count == expected['bytes'] and digest.hexdigest() == expected['sha256'], 'archive byte count or SHA differs')
            need(stamp(os.fstat(fd)) == stamp(path.lstat()) == expected['original_identity'], 'archive identity changed while streaming')
            completed.append({'group': row['group'], 'bytes': count, 'sha256': digest.hexdigest(),
                              'descriptor_identity_before': expected['original_identity'],
                              'descriptor_identity_after': stamp(os.fstat(fd))})
        # Recheck the first source after the second source has been copied too.
        for row, path, fd in opened:
            need(stamp(os.fstat(fd)) == stamp(path.lstat()) == row['identity']['original_identity'], 'source changed across archive copies')
        footer = encode({'schema': 'hepta-r25-frozen-archive-stream-result/v1', 'passed': True,
                         'files': completed, 'stream_sha256': stream_digest.hexdigest(), 'workload_executed': False})
        sys.stdout.buffer.write(struct.pack('>I', len(footer)) + footer + END)
        sys.stdout.buffer.flush()
    finally:
        for _row, _path, fd in reversed(opened):
            os.close(fd)


if __name__ == '__main__':
    main()
