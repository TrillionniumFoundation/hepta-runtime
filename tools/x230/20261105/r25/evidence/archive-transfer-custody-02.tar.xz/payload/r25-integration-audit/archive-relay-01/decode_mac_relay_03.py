#!/usr/bin/env python3
"""Verify the original Mac holder/strong native terminal, then decode frozen data.

No subprocesses, SSH, credential/configuration access, archive extraction or
archive-code execution. All input/output paths are fixed private task paths.
"""
import argparse
import ast
import base64
import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import stat
import struct
import sys

WORK = Path('/Users/qianqi/work')
OUT = WORK / 'hepta-runtime-r25-archive-relay-01'
TOOLS = WORK / 'hepta-runtime-r25-archive-relay-tools-01'
HOLDER = WORK / 'hepta-runtime-x230-r21-20261105/held_agent_campaign_02.py'
HOLDER_SHA = '715e996217c7d33a7483354f16f2d39c9a033f51f3a20a52484495a00262dd65'
STREAMER = TOOLS / 'stream_frozen_archives_01.py'
DECODER = TOOLS / 'decode_mac_relay_03.py'
PREVIOUS_DECODER = TOOLS / 'decode_mac_relay_02.py'
PREVIOUS_DECODER_SHA = '0cd45429c72c940b064da12e4e1761a2eb815bee735467d79fd5f175aa758235'
PREVIOUS_FAILURE = OUT / 'relay-decoder-report-01.json'
LOCK_PRODUCER_SOURCE_SHA = 'c15e8900b0ab867b221ff08d5a10401c8b656c87676f57b478b9a21219f7fe12'
EXACT_RECEIPT_LOCKS = {
    'relay-native-terminal-01.json': '.hepta-lock-b7086d9e9a747361cc2a96ce',
    'relay-native-read-01.json': '.hepta-lock-703b3a16f44486048314b9fb',
}
STREAMER_SHA = '34e720eee4a762c3f0010d90b00bd3eb55878719c1a6f0b1415568dd67673f4c'
EXPORT_REPORT_SHA = 'e89ad03ca9bdeaa4294714ee74b8956e5c9c787acd3d0666de37bbe60d3822d8'
MAGIC = b'HEPTA-R25-FROZEN-ARCHIVE-RELAY/v1\0'
END = b'\0HEPTA-R25-RELAY-END\0'
STAMP = ('st_dev', 'st_ino', 'st_uid', 'st_mode', 'st_nlink', 'st_size', 'st_mtime_ns', 'st_ctime_ns')
LOG_NAME = re.compile(r'(?:remote-script\.py|forwarded\.(?:stdout|stderr)|owned-agent\.stderr|identity-discovery-\d{2}\.stderr|identity-load-\d{2}\.(?:stdout|stderr))\Z')


def need(ok, message):
    if not ok:
        raise ValueError(message)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def encode(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), allow_nan=False).encode()


def stamp(value):
    return {key: getattr(value, key) for key in STAMP}


def read(path, maximum=16 * 1024 * 1024):
    need(path.is_absolute() and path.resolve() == path, 'fixed local path is indirect')
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK | os.O_CLOEXEC)
    try:
        before = os.fstat(fd)
        need(stat.S_ISREG(before.st_mode) and before.st_uid == os.geteuid()
             and before.st_nlink == 1 and 0 <= before.st_size <= maximum, 'input is not a bounded owned regular file')
        with os.fdopen(fd, 'rb', closefd=False) as stream:
            raw = stream.read(maximum + 1)
        need(len(raw) == before.st_size and stamp(before) == stamp(os.fstat(fd)) == stamp(path.lstat()), 'input changed during read')
        return {'source_path': str(path), 'bytes': len(raw), 'sha256': sha(raw),
                'original_identity': stamp(before), 'is_elf': raw.startswith(b'\x7fELF')}, raw
    finally:
        os.close(fd)


def write(path, raw):
    need(path.parent.resolve() == path.parent, 'output parent is indirect')
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW | os.O_CLOEXEC, 0o600)
    with os.fdopen(fd, 'wb') as stream:
        stream.write(raw)
        stream.flush()
        os.fsync(stream.fileno())


def verify_terminal(value, job):
    need(value['job_id'] == job and value['state'] == 'succeeded' and type(value['exit_code']) is int
         and value['exit_code'] == 0 and value['terminal_publication_protocol'] == 1, 'native terminal state differs')
    need(all(value[key] is True for key in ('terminal_publication_confirmed', 'output_durable', 'output_complete', 'audit_recorded'))
         and all(value[key] is False for key in ('automatic_retry', 'timed_out', 'cancelled')), 'native terminal durability differs')
    for stream in ('stdout', 'stderr'):
        count = value['log_bytes'][stream]
        need(value['log_synced'][stream] is True and value['log_truncated'][stream] is False
             and value['log_errors'][stream] is None and type(count['seen']) is int
             and 0 <= count['seen'] == count['stored'] <= 16384, 'native original stream proof differs')


def native_streams(value, terminal, job):
    need(value.get('job_id') == job, 'original native read belongs to another job')
    streams = {}
    for key in ('stdout', 'stderr'):
        row = value[key]
        need(isinstance(row.get('bytes_hex'), str), 'original native byte representation missing')
        body = bytes.fromhex(row['bytes_hex'])
        need(type(row.get('size')) is int and row['size'] == len(body)
             and type(row.get('offset')) is int and row['offset'] == 0
             and type(row.get('next_offset')) is int and row['next_offset'] == len(body)
             and row.get('eof') is True and row.get('text') == body.decode('utf-8'), 'original native read is partial or inconsistent')
        need(terminal['log_bytes'][key] == {'seen': len(body), 'stored': len(body)}
             and all(type(item) is int for item in terminal['log_bytes'][key].values()), 'original native read and terminal counts differ')
        streams[key] = body
    need(streams['stderr'] == b'', 'original native holder stderr is nonempty')
    return streams


def parse_stream(raw, archives):
    position = 0
    def take(length):
        nonlocal position
        need(type(length) is int and 0 <= length <= len(raw) - position, 'truncated/invalid binary frame')
        body = raw[position:position + length]
        position += length
        return body
    def document():
        length = struct.unpack('>I', take(4))[0]
        need(0 < length <= 16384, 'JSON frame exceeds bound')
        body = take(length)
        value = json.loads(body)
        need(encode(value) == body, 'JSON frame is not canonical')
        return value
    need(take(len(MAGIC)) == MAGIC, 'binary stream magic differs')
    header = document()
    need(header == {'schema': 'hepta-r25-frozen-archive-stream/v1', 'export_report_sha256': EXPORT_REPORT_SHA,
                    'launcher_sha256': STREAMER_SHA, 'archives': archives}, 'binary stream source/header differs')
    payloads, completed = {}, []
    for row in archives:
        expected = row['identity']
        size = struct.unpack('>Q', take(8))[0]
        need(size == expected['bytes'], 'binary archive frame length differs')
        body = take(size)
        need(sha(body) == expected['sha256'], 'binary archive SHA differs')
        payloads[row['group']] = body
        completed.append({'group': row['group'], 'bytes': size, 'sha256': sha(body),
                          'descriptor_identity_before': expected['original_identity'],
                          'descriptor_identity_after': expected['original_identity']})
    prefix_sha = sha(raw[:position])
    footer = document()
    need(footer == {'schema': 'hepta-r25-frozen-archive-stream-result/v1', 'passed': True,
                    'files': completed, 'stream_sha256': prefix_sha, 'workload_executed': False}, 'binary stream final identity/digest proof differs')
    need(take(len(END)) == END and position == len(raw), 'binary stream trailer/EOF differs')
    return payloads, header, footer


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--expected-job-id', required=True)
    parser.add_argument('--native-terminal-sha256', required=True)
    parser.add_argument('--native-read-sha256', required=True)
    parser.add_argument('--decoder-sha256', required=True)
    parser.add_argument('--previous-failure-report-sha256', required=True)
    args = parser.parse_args()
    need(sys.platform == 'darwin' and os.geteuid() != 0, 'existing non-root Mac operator required')
    need(re.fullmatch('[0-9a-f]+-[0-9a-f]+-[0-9a-f]+', args.expected_job_id)
         and all(re.fullmatch('[0-9a-f]{64}', value) for value in
                 (args.native_terminal_sha256, args.native_read_sha256, args.decoder_sha256,
                  args.previous_failure_report_sha256)), 'invalid explicit native/source binding')
    need(OUT.resolve() == OUT and OUT.is_dir() and TOOLS.resolve() == TOOLS, 'fixed relay directories differ')
    result_path = OUT / 'relay-decoder-report-02.json'
    decoded = OUT / 'decoded-02'
    need(not os.path.lexists(result_path) and not os.path.lexists(decoded)
         and not os.path.lexists(OUT / 'decoded'), 'fresh decode outputs and no partial prior archive output required')
    result = {'schema': 'hepta-r25-mac-frozen-archive-relay/v1', 'passed': False,
              'started_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
              'original_holder_job_id': args.expected_job_id, 'archives': {},
              'workload_executed': False, 'archive_code_executed': False, 'archive_extracted': False,
              'observation_gate_passed': False, 'candidate_adoption_ready': False,
              'original_export_report_sha256': EXPORT_REPORT_SHA}
    inputs = {}
    def bound(path, maximum=16 * 1024 * 1024):
        item, raw = read(path, maximum)
        inputs[str(path)] = item
        return item, raw
    try:
        need(Path(__file__).absolute() == DECODER, 'decoder executed from an unexpected fixed path')
        decoder_id, _ = bound(DECODER, 65536)
        need(decoder_id['sha256'] == args.decoder_sha256, 'reviewed decoder source bytes differ')
        previous_decoder_id, _ = bound(PREVIOUS_DECODER, 65536)
        need(previous_decoder_id['sha256'] == PREVIOUS_DECODER_SHA, 'original failed decoder source changed')
        previous_failure_id, previous_failure_raw = bound(PREVIOUS_FAILURE, 65536)
        need(previous_failure_id['sha256'] == args.previous_failure_report_sha256, 'original failed decoder report bytes differ')
        previous_failure = json.loads(previous_failure_raw)
        need(previous_failure['schema'] == 'hepta-r25-mac-frozen-archive-relay/v1'
             and previous_failure['passed'] is False and previous_failure['archives'] == {}
             and previous_failure['original_holder_job_id'] == args.expected_job_id
             and previous_failure['original_export_report_sha256'] == EXPORT_REPORT_SHA
             and previous_failure['error'] == {'type': 'ValueError', 'reason': 'unexpected original holder output'}
             and all(previous_failure[key] is False for key in ('workload_executed', 'archive_code_executed', 'archive_extracted',
                                                               'observation_gate_passed', 'candidate_adoption_ready')),
             'prior decode failure is not the preserved exact directory-guard failure')
        lock_metadata = {}
        for basename, name in EXACT_RECEIPT_LOCKS.items():
            need(name == '.hepta-lock-' + hashlib.sha256(basename.encode()).hexdigest()[:24], 'explicit receipt lock name differs from producer rule')
            lock_id, body = bound(OUT / name, 0)
            need(body == b'' and lock_id['bytes'] == 0
                 and stat.S_IMODE(lock_id['original_identity']['st_mode']) == 0o600, 'explicit receipt lock is not private and empty')
            lock_metadata[name] = lock_id
        terminal_id, terminal_raw = bound(OUT / 'relay-native-terminal-01.json', 16384)
        need(terminal_id['sha256'] == args.native_terminal_sha256, 'original native terminal bytes differ')
        terminal = json.loads(terminal_raw)
        verify_terminal(terminal, args.expected_job_id)
        native_read_id, native_read_raw = bound(OUT / 'relay-native-read-01.json', 65536)
        need(native_read_id['sha256'] == args.native_read_sha256, 'original native read bytes differ')
        streams = native_streams(json.loads(native_read_raw), terminal, args.expected_job_id)
        holder_id, _ = bound(HOLDER, 65536)
        need(holder_id['bytes'] == 11374 and holder_id['sha256'] == HOLDER_SHA, 'unchanged original holder identity differs')
        streamer_id, streamer_raw = bound(STREAMER, 65536)
        need(streamer_id['sha256'] == STREAMER_SHA, 'reviewed stream source identity differs')
        literals = {node.targets[0].id: ast.literal_eval(node.value) for node in ast.parse(streamer_raw).body
                    if isinstance(node, ast.Assign) and len(node.targets) == 1 and isinstance(node.targets[0], ast.Name)
                    and node.targets[0].id in {'ARCHIVES', 'EXPORT_REPORT_SHA'}}
        need(literals['EXPORT_REPORT_SHA'] == EXPORT_REPORT_SHA, 'reviewed source exporter binding differs')
        archives = literals['ARCHIVES']
        need([row['group'] for row in archives] == ['observation', 'qualification'], 'fixed archive order differs')
        holder_report_id, report_raw = bound(OUT / 'report.json', 65536)
        report = json.loads(report_raw)
        need(report['schema'] == 'hepta-x230-r21-held-agent-campaign/v1'
             and report['passed'] is True and report['remote_returncode'] == 0 and report.get('finished_utc')
             and 'error' not in report and report.get('foreground_timed_out', False) is False
             and report.get('remote_completion_unknown', False) is False, 'original holder did not complete successfully')
        need(report['holder_script_sha256'] == HOLDER_SHA and report['remote_script_sha256'] == STREAMER_SHA
             and report['timeout_seconds'] == 300 and report['automatic_ssh_retries'] == 0,
             'original holder source/timeout/retry binding differs')
        need(all(report[key] is False for key in ('services_modified', 'key_bytes_retained', 'complete_environment_retained', 'ssh_configuration_dump_retained')),
             'original holder scope differs')
        need(all(report[key] is True for key in ('owned_agent_reaped', 'owned_agent_directory_absent_after_context', 'owned_agent_socket_absent_after_context')),
             'original holder agent cleanup incomplete')
        need(type(report['owned_agent_returncode']) is int and re.fullmatch(r'/tmp/hr19a-[A-Za-z0-9_-]+', report['owned_agent_directory'])
             and report['owned_agent_socket'] == report['owned_agent_directory'] + '/agent.sock', 'owned holder cleanup scope differs')
        need(not os.path.lexists(report['owned_agent_directory']) and not os.path.lexists(report['owned_agent_socket']), 'owned holder agent resources remain')
        start, end = report['foreground_start_monotonic_ns'], report['foreground_end_monotonic_ns']
        need(type(start) is int and type(end) is int and end >= start and report['foreground_seconds'] == (end - start) / 1e9
             and type(report['foreground_pid']) is int and report['foreground_pid'] > 1
             and type(report['owned_agent_pid']) is int and report['owned_agent_pid'] > 1, 'original holder process completion fields differ')
        native_lines = [json.loads(line) for line in streams['stdout'].decode().splitlines() if line.strip()]
        need(native_lines == [
            {'phase': 'owned_agent_ready', 'identity_count': report['configured_identity_count'], 'remote_script_sha256': STREAMER_SHA},
            {'passed': True, 'remote_returncode': 0, 'owned_agent_reaped': True, 'report': str(OUT / 'report.json')}],
            'original native holder ready/footer does not bind this source and report')
        expected_argv = ['/usr/bin/ssh', '-A', '-T', '-o', 'BatchMode=yes', '-o', 'ConnectTimeout=10',
                         '-o', 'StrictHostKeyChecking=yes', '-o', 'ControlMaster=no', '-o', 'ControlPath=none',
                         '-o', 'ControlPersist=no', 'x230-ts', '/usr/bin/python3', '-B', '-', '--launcher-sha256', STREAMER_SHA]
        need(report['foreground_argv'] == expected_argv, 'original single SSH connection differs')
        rows = report['log_files']
        need(len(rows) == len({row['file'] for row in rows}) and all(LOG_NAME.fullmatch(row['file']) for row in rows), 'holder log name inventory differs')
        names = {row['file'] for row in rows}
        need({'remote-script.py', 'forwarded.stdout', 'forwarded.stderr', 'owned-agent.stderr'} <= names, 'required original holder logs missing')
        expected_output_names = names | {'report.json', 'relay-native-terminal-01.json', 'relay-native-read-01.json', PREVIOUS_FAILURE.name} | set(EXACT_RECEIPT_LOCKS.values())
        need({p.name for p in OUT.iterdir()} == expected_output_names, 'unexpected original holder output')
        logs = {}
        for row in rows:
            item, raw = bound(OUT / row['file'])
            need(item['bytes'] == row['bytes'] and item['sha256'] == row['sha256'], 'original whole holder log bytes/SHA differ')
            logs[row['file']] = raw
        need(logs['remote-script.py'] == streamer_raw and logs['forwarded.stderr'] == b'', 'original stream source/stderr differs')
        required = {'remote-script.py', 'forwarded.stdout', 'forwarded.stderr', 'owned-agent.stderr'}
        for key, count_key, prefix, suffixes in (
            ('identity_discovery', 'configured_target_count', 'identity-discovery', ('stderr',)),
            ('identity_loads', 'configured_identity_count', 'identity-load', ('stdout', 'stderr')),
        ):
            operations, count = report[key], report[count_key]
            need(type(count) is int and 1 <= count <= 64 and len(operations) == count
                 and [operation['index'] for operation in operations] == list(range(count)), 'holder identity operation count/sequence differs')
            for operation in operations:
                need(type(operation['returncode']) is int and operation['returncode'] == 0, 'original holder identity operation failed')
                for key_stream in suffixes:
                    name = f'{prefix}-{operation["index"]:02d}.{key_stream}'
                    required.add(name)
                    body = logs[name]
                    need(operation[key_stream] == {'file': name, 'bytes': len(body), 'sha256': sha(body)}, 'holder identity operation stream differs')
                if key == 'identity_loads':
                    need(operation['ttl_seconds'] == 420 and type(operation['start_monotonic_ns']) is int
                         and type(operation['end_monotonic_ns']) is int and operation['end_monotonic_ns'] >= operation['start_monotonic_ns'],
                         'holder identity lifetime/timing differs')
        need(names == required, 'unexpected or missing original holder identity logs')
        payloads, header, footer = parse_stream(logs['forwarded.stdout'], archives)
        decoded.mkdir(mode=0o700)
        for row in archives:
            group, expected = row['group'], row['identity']
            archive = decoded / (group + '-02.tar.gz')
            write(archive, payloads[group])
            actual, body = read(archive)
            need(actual['bytes'] == expected['bytes'] and actual['sha256'] == expected['sha256'], 'decoded archive readback differs')
            directory = decoded / (group + '-02.tar.gz.chunks')
            directory.mkdir(mode=0o700)
            chunks = []
            for i, offset in enumerate(range(0, len(body), 48000)):
                block = body[offset:offset + 48000]
                text = base64.b64encode(block)
                path = directory / f'chunk-{i:05d}.b64'
                write(path, text)
                chunks.append({'path': str(path), 'offset': offset, 'bytes': len(block), 'sha256': sha(block),
                               'base64_bytes': len(text), 'base64_sha256': sha(text)})
            manifest = {'schema': 'hepta-r25-mac-archive-relay-chunks/v1', 'group': group,
                        'archive': actual, 'origin_archive': expected, 'encoding': 'base64',
                        'maximum_decoded_chunk_bytes': 48000, 'maximum_text_file_bytes': 64000,
                        'chunks': chunks, 'original_holder_job_id': args.expected_job_id,
                        'forwarded_stdout_sha256': sha(logs['forwarded.stdout']), 'stream_prefix_sha256': footer['stream_sha256']}
            manifest_path = directory / 'manifest.json'
            write(manifest_path, encode(manifest) + b'\n')
            result['archives'][group] = {'archive': actual, 'origin_archive': expected, 'chunks': len(chunks), 'manifest': read(manifest_path)[0]}
        # Original immutable inputs must still have the same exact identities.
        for path, expected in inputs.items():
            need(read(Path(path))[0] == expected, 'original relay input changed after decoding')
        result.update({'passed': True, 'native_terminal': terminal_id, 'original_holder_report': holder_report_id,
                       'native_read': native_read_id, 'decoder': decoder_id,
                       'previous_decoder': previous_decoder_id, 'previous_decode_failure': previous_failure_id,
                       'exact_receipt_lock_metadata': lock_metadata, 'lock_producer_source_sha256': LOCK_PRODUCER_SOURCE_SHA,
                       'native_stdout': {'bytes': len(streams['stdout']), 'sha256': sha(streams['stdout'])},
                       'native_stderr': {'bytes': len(streams['stderr']), 'sha256': sha(streams['stderr'])},
                       'unchanged_holder': holder_id, 'streamer': streamer_id, 'inputs': inputs,
                       'forwarded_stdout': inputs[str(OUT / 'forwarded.stdout')], 'frame_header': header,
                       'frame_footer': footer, 'holder_cleanup_verified': True, 'strong_original_native_terminal_verified': True,
                       'all_origin_archive_bytes_rehashed': True})
    except Exception as error:
        result['error'] = {'type': type(error).__name__, 'reason': str(error)[:700]}
    result['finished_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    write(result_path, (json.dumps(result, sort_keys=True, indent=2, allow_nan=False) + '\n').encode())
    print(json.dumps({'passed': result['passed'], 'report': str(result_path), 'archives': list(result['archives']),
                      'error': result.get('error')}, sort_keys=True), flush=True)
    return 0 if result['passed'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
