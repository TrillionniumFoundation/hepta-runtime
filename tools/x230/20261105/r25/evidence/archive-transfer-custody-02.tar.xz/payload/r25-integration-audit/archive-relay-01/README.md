# Frozen R25 archive relay

This transport copies exactly the already-frozen R25 observation and qualification archives. It does not run a benchmark, reproduce a test, change a performance gate, or adopt R25. The original observation result remains rejected.

The unchanged Mac `held_agent_campaign_02.py` owns one temporary SSH agent and one foreground connection. The reviewed streamer opens only the two absolute archive paths, checks their complete exported descriptor identities before and after copying, verifies their byte counts and SHA256, and emits a length-framed binary stdout with a final digest. It performs no X230 write or subprocess operation.

The first holder job is `1a1ab1770a5-fc05-4a36`. It completed successfully once, with 292 bytes of original native stdout and no stderr. The exact original native terminal/read DTOs are retained separately; they were not reconstructed through JavaScript numeric JSON serialization. Their ready/footer lines bind the streamer SHA and the exact holder report path.

Decoder revision 02 was independently reviewed, installed, and executed once as job `1a1ab1a14ae-fc05-4a69`. It stopped before producing any decoded archives because the two create-only native receipt writes left their two documented permanent empty lock files. Its original failure report and native output remain preserved. The unchanged original SSH stream is reused; no second SSH copy is required.

Decoder revision 03 admits only those two exact lock names, with owned singly linked regular-file, empty-body, mode0600, and before/after identity checks. It binds the previous failed decoder source and the exact original failure report. All native terminal, original stream, source, frame, archive, and unknown-file guards remain. Its output paths are fresh `decoded-02` and `relay-decoder-report-02.json`; original holder inputs are read only.

The Mac decoder verifies the original strong native terminal and complete original native output before reading the binary stream. It checks every holder log identity, the exact ready/footer sequence, original agent cleanup, and the whole forwarded stdout SHA. It only then creates the two archive files and deterministic 48000-byte Base64 chunks. The local receiver must still verify all read-response versions and chunk hashes, reconstruct the exact archives, and run the separate complete tar/member/omission audit before publication.

`source-manifest-01.json` and decoder01 are retained unrun drafts. Manifest02 and decoder02 retain the executed failure. Manifest03 identifies the narrow correction. Native start/status/read responses, exact requests, tool publication receipts, and the directory metadata diagnosis are preserved beside these sources. A successful transport or decoder result never means that R25 passed its observation gate, its unexecuted lifecycle campaign, or hosted GitHub Actions.
