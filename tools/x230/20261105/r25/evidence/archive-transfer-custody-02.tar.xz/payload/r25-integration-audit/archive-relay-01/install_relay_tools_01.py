#!/usr/bin/env python3
"""Create only the reviewed three data/source files in a fresh private Mac directory."""
import base64
import hashlib
import json
import os
from pathlib import Path
import stat
import sys

ROOT = Path('/Users/qianqi/work/hepta-runtime-r25-archive-relay-tools-01')
EXPECTED = {
    'stream_frozen_archives_01.py': (4974, '34e720eee4a762c3f0010d90b00bd3eb55878719c1a6f0b1415568dd67673f4c'),
    'decode_mac_relay_01.py': (14215, 'c12b2b95a3d90f4904d44f6d6413c7523ed15eba967a87031871648a5ca6bac7'),
    'source-manifest-01.json': (407, 'ac847f9c31b60d7b133c92f9a939a6b0a819e339937d9e17be6944ba31104b31'),
}


def need(ok, why):
    if not ok:
        raise ValueError(why)


def main():
    need(sys.platform == 'darwin' and os.geteuid() != 0, 'existing non-root Mac operator required')
    need(ROOT.parent.resolve() == ROOT.parent and stat.S_ISDIR(ROOT.parent.lstat().st_mode)
         and ROOT.parent.lstat().st_uid == os.geteuid(), 'fixed existing Mac workspace differs')
    need(not os.path.lexists(ROOT), 'fresh relay tools directory required')
    text = sys.stdin.buffer.read(65537)
    need(len(text) <= 65536, 'installer input exceeds bound')
    payload = json.loads(text)
    need(set(payload) == set(EXPECTED), 'fixed source file set differs')
    files = {}
    for name, encoded in payload.items():
        body = base64.b64decode(encoded, validate=True)
        need(base64.b64encode(body).decode() == encoded
             and (len(body), hashlib.sha256(body).hexdigest()) == EXPECTED[name], 'reviewed source bytes differ')
        files[name] = body
    os.umask(0o077)
    ROOT.mkdir(mode=0o700)
    result = {}
    for name, body in sorted(files.items()):
        path = ROOT / name
        fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW | os.O_CLOEXEC, 0o600)
        with os.fdopen(fd, 'wb') as stream:
            stream.write(body)
            stream.flush()
            os.fsync(stream.fileno())
        value = path.lstat()
        need(stat.S_ISREG(value.st_mode) and value.st_nlink == 1 and value.st_uid == os.geteuid()
             and stat.S_IMODE(value.st_mode) == 0o600 and path.read_bytes() == body, 'installed source readback differs')
        result[name] = {'bytes': len(body), 'sha256': hashlib.sha256(body).hexdigest()}
    need({p.name for p in ROOT.iterdir()} == set(EXPECTED), 'installed source inventory differs')
    print(json.dumps({'installed': True, 'root': str(ROOT), 'files': result, 'packaged_code_executed': False}, sort_keys=True), flush=True)


if __name__ == '__main__':
    main()
