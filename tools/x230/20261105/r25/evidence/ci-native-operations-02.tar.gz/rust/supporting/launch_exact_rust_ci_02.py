"""Small original native launcher; materialize once, then replace self with reviewed runner."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

ROOT = Path('/home/qian/hepta-runtime-optimization-20261105-r25')
TOOLS = ROOT / 'rust-ci-tools-02'
PLAN = ROOT / 'rust-ci-plan-02.json'
MANIFEST_SHA = '5a989871bd4f27535d8872f5648bd6c5b2b5c0e8f5b7c3235fe60063d5183aef'
PINS = {
    'materialize_rust_ci_plan_02.py': 'f94fe684a5a968f01fd56b1849fcdaa6d7fa65ac823d4719511161aa4b004987',
    'run_rust_ci_02.py': '27fec14b626cd2d393e3a0b25e1434dc6e190029bed53711813efc9d181f1446',
    'audit_nextest_0137.py': '03fc242ae6ba3f5fa2fc948d3401e5f93a7a388ee9edb5b703183d6410aab8d2',
}


def raw(path):
    if path.resolve(strict=True) != path or not path.is_file():
        raise RuntimeError('indirect or missing reviewed input: ' + str(path))
    return path.read_bytes()


def sha(value):
    return hashlib.sha256(value).hexdigest()


if TOOLS.resolve(strict=True) != TOOLS or os.path.lexists(PLAN) or os.path.lexists(ROOT / 'rust-ci-02'):
    raise RuntimeError('fresh reviewed tools and unused plan/output paths required')
manifest_raw = raw(TOOLS / 'package-manifest-01.json')
if sha(manifest_raw) != MANIFEST_SHA:
    raise RuntimeError('reviewed tools manifest differs')
manifest = json.loads(manifest_raw)
for name, expected in manifest['files'].items():
    if Path(name).name != name or name in {'.', '..'}:
        raise RuntimeError('unsafe manifest member')
    data = raw(TOOLS / name)
    if len(data) != expected['bytes'] or sha(data) != expected['sha256']:
        raise RuntimeError('reviewed tool differs: ' + name)
for name, expected in PINS.items():
    if sha(raw(TOOLS / name)) != expected:
        raise RuntimeError('reviewed executor differs: ' + name)
command = ['/usr/bin/python3', '-I', '-B', str(TOOLS / 'materialize_rust_ci_plan_02.py'),
    '--qualification-sha256', '72a4001ed303d565f5c3300ea8786acf1c4e9d7991e0a1f0486fabc140900e3c',
    '--terminal-status-sha256', '87db6a4da3004f8fe62c94825136a253c6a63b461f0c22cb493462c1f0c48e85',
    '--ci-manifest', str(ROOT / 'ci-gates/ci-gate-manifest.json'), '--out', str(PLAN)]
print(json.dumps({'phase': 'materialize', 'automatic_retries': 0, 'tools_manifest_sha256': MANIFEST_SHA}), flush=True)
result = subprocess.run(command, cwd=ROOT, timeout=300)
if result.returncode != 0:
    raise SystemExit(result.returncode)
plan_sha = sha(raw(PLAN))
print(json.dumps({'phase': 'execute_original_ci', 'plan_sha256': plan_sha, 'automatic_retries': 0}), flush=True)
sys.stdout.flush()
sys.stderr.flush()
os.execv('/usr/bin/python3', ['/usr/bin/python3', '-I', '-B', str(TOOLS / 'run_rust_ci_02.py'),
    '--plan', str(PLAN), '--plan-sha256', plan_sha,
    '--materializer-sha256', PINS['materialize_rust_ci_plan_02.py'],
    '--auditor-sha256', PINS['audit_nextest_0137.py']])
