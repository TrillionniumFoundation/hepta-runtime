#!/usr/bin/env python3
"""Verify the installed fixed Python CI subset and execute each gate once."""

import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import signal
import stat
import subprocess
import sys
import tarfile
import time

ROOT = Path("/home/qian/hepta-runtime-optimization-20261105-r25")
PACKAGE = Path("/home/qian/hepta-runtime-r25-ci-inputs-01.tar.gz")
PACKAGE_BYTES = 498954
PACKAGE_SHA256 = "4063559cfe1cef5952802fdbe038f529ce3be73deb1cdfc3ca71c084dc173270"
MANIFEST_SHA256 = "bf0df5f7d19ebd149854fbf75887fb0fb136f18a63a0c240abf8420655fb195e"
RUNNER_SHA256 = "de69c48bc00273541f505d4462f57bb40ed85e291847cceb671e700534d822aa"
INPUT_HEAD = "1aa98d3c94d0253999a491c967ccc94b314e87c8"
SOURCE = ROOT / "ci-gates"
OUTPUT = ROOT / "python-ci-01"
LAUNCH = ROOT / "python-ci-launch-01"
INSTALL_RECEIPT = ROOT / "tool-package-install-01.json"
INSTALL_RECEIPT_SHA256 = "6f8adc4698405c93f632a2c3534c1cba8337e57522c08ca94b2be2ba23f4a7d7"
DEPENDENCY_RECEIPT = ROOT / "ci-toolchain/nextest-0.9.137/receipt.json"
DEPENDENCY_RECEIPT_SHA256 = "2bbae481b3fbc6ac6d06a22bfe22e9500f5190b97ccddb16e8aba1ef1ed34f9d"
REMOVE_PREFIXES = ("HEPTA_", "SSH_", "RUST_TEST_", "NEXTEST_")
REMOVE_KEYS = ("PYTHONPATH", "PYTHONHOME", "RUSTFLAGS", "CARGO_ENCODED_RUSTFLAGS",
               "RUSTDOCFLAGS", "RUSTC_WRAPPER", "RUSTC_WORKSPACE_WRAPPER", "RUST_LOG")


def identity(path):
    body = path.read_bytes()
    return {"bytes": len(body), "sha256": hashlib.sha256(body).hexdigest()}


def write_json(path, value):
    with path.open("x") as stream:
        json.dump(value, stream, indent=2, sort_keys=True)
        stream.write("\n")
        stream.flush()
        os.fsync(stream.fileno())


def verify_installed_package():
    if not stat.S_ISREG(PACKAGE.lstat().st_mode):
        raise ValueError("staged archive is not a regular file")
    actual = identity(PACKAGE)
    if actual != {"bytes": PACKAGE_BYTES, "sha256": PACKAGE_SHA256}:
        raise ValueError("staged archive identity mismatch")
    if not stat.S_ISREG(INSTALL_RECEIPT.lstat().st_mode):
        raise ValueError("package install receipt is not a regular file")
    installed = identity(INSTALL_RECEIPT)
    if installed["sha256"] != INSTALL_RECEIPT_SHA256:
        raise ValueError("package install receipt identity mismatch")
    installation = json.loads(INSTALL_RECEIPT.read_text())
    if (installation["passed"] is not True or installation["tests_executed"] is not False
            or installation["qualified_source_modified"] is not False):
        raise ValueError("package installation receipt is not the qualified preparation")
    matches = [p for p in installation["packages"] if p["destination"] == str(ROOT / "ci-gates")]
    if len(matches) != 1:
        raise ValueError("install receipt lacks the unique expected CI destination")
    package = matches[0]
    if (package["archive_bytes"] != PACKAGE_BYTES or package["archive_sha256"] != PACKAGE_SHA256
            or package["archive"] != "/home/qian/hepta-runtime-r25-ci-inputs-01.tar.gz"):
        raise ValueError("install receipt does not identify the frozen package")
    recorded = {row["path"]: {key: row[key] for key in ("bytes", "sha256")} for row in package["files"]}
    if len(recorded) != 103 or len(package["files"]) != 103:
        raise ValueError("install receipt has a different member set")
    if SOURCE.resolve(strict=True) != SOURCE or not stat.S_ISDIR(SOURCE.lstat().st_mode):
        raise ValueError("existing CI package directory is not a direct real directory")
    with tarfile.open(PACKAGE, "r:gz") as archive:
        members = archive.getmembers()
        seen = set()
        if len(members) != 103 or sum(m.size for m in members) != 2205863:
            raise ValueError("frozen package member count or expanded bytes mismatch")
        for member in members:
            relative = PurePosixPath(member.name)
            if (not member.isfile() or member.issparse() or relative.is_absolute()
                    or not relative.parts or ".." in relative.parts or "\\" in member.name
                    or member.name in seen or member.mode & 0o022):
                raise ValueError("unsafe, duplicate or writable archive member")
            if member.size < 0 or member.size > 1024 * 1024:
                raise ValueError("archive member outside frozen package bounds")
            seen.add(member.name)
            target = SOURCE / member.name
            source = archive.extractfile(member)
            if source is None:
                raise ValueError("missing regular archive content")
            body = source.read(member.size + 1)
            source.close()
            if len(body) != member.size:
                raise ValueError("archive member content length mismatch")
            if target.resolve(strict=True) != target or not stat.S_ISREG(target.lstat().st_mode):
                raise ValueError("installed member is not a direct regular file")
            info = target.stat()
            if info.st_mode & 0o022 or bool(info.st_mode & 0o111) != bool(member.mode & 0o111):
                raise ValueError("installed member has different or writable mode")
            expected = {"bytes": len(body), "sha256": hashlib.sha256(body).hexdigest()}
            if identity(target) != expected or recorded.get(member.name) != expected:
                raise ValueError("installed member differs from archive/install receipt: " + member.name)
        actual_names = set()
        for path in SOURCE.rglob("*"):
            info = path.lstat()
            if stat.S_ISDIR(info.st_mode):
                continue
            if not stat.S_ISREG(info.st_mode):
                raise ValueError("unexpected special or symlink member in installed package")
            actual_names.add(path.relative_to(SOURCE).as_posix())
        if actual_names != seen or set(recorded) != seen:
            raise ValueError("installed package file set differs from frozen archive")
    return {"archive": actual, "installation_receipt": installed, "verified_regular_members": len(seen)}


def main():
    if os.geteuid() == 0:
        raise SystemExit("Python fixture gates must run as the unprivileged X230 user")
    if sys.version_info < (3, 11):
        raise SystemExit("Python 3.11 or newer is required")
    for path in (Path("/home"), Path("/home/qian"), ROOT):
        if not stat.S_ISDIR(path.lstat().st_mode):
            raise SystemExit("expected real task parent is unavailable")
    if OUTPUT.exists() or OUTPUT.is_symlink():
        raise SystemExit("Python CI output attempt already exists; refusing reuse")
    LAUNCH.mkdir(mode=0o700, exist_ok=False)
    receipt = {"schema": "hepta-r25-python-ci-one-time-launch-v1", "passed": False,
               "started_unix": time.time(), "launcher_source": identity(Path(__file__)),
               "input_head_commit": INPUT_HEAD,
               "scope": "18 original Python commands from 1aa98d3c; not R25 Rust qualification",
               "rust_executed": False, "performance_executed": False,
               "lifecycle_harness_tests_executed": False, "retry_count": 0}
    try:
        if (DEPENDENCY_RECEIPT.resolve(strict=True) != DEPENDENCY_RECEIPT
                or not stat.S_ISREG(DEPENDENCY_RECEIPT.lstat().st_mode)):
            raise ValueError("dependency receipt is not a direct regular file")
        receipt["dependency_receipt"] = identity(DEPENDENCY_RECEIPT)
        if receipt["dependency_receipt"] != {"bytes": 3554, "sha256": DEPENDENCY_RECEIPT_SHA256}:
            raise ValueError("dependency receipt identity mismatch")
        dependencies = json.loads(DEPENDENCY_RECEIPT.read_text())
        jsonschema = dependencies["jsonschema_probe"]
        if (dependencies["passed"] is not True or jsonschema["returncode"] != 0
                or json.loads(jsonschema["stdout"])["discoverable"] is not True
                or dependencies["rg_probe"]["returncode"] != 0):
            raise ValueError("required existing Python CI dependencies were not verified")
        receipt["package_verification"] = verify_installed_package()
        runner = SOURCE / "run_ci_python_gates.py"
        manifest_path = SOURCE / "ci-gate-manifest.json"
        receipt["runner"] = identity(runner)
        receipt["manifest"] = identity(manifest_path)
        if receipt["runner"]["sha256"] != RUNNER_SHA256 or receipt["manifest"]["sha256"] != MANIFEST_SHA256:
            raise ValueError("extracted runner/manifest identity mismatch")
        manifest = json.loads(manifest_path.read_text())
        if manifest["head_commit"] != INPUT_HEAD or len(manifest["python_gates"]) != 18:
            raise ValueError("unexpected Python input commit or gate count")
        environment = dict(os.environ)
        original_home = environment.get("HOME")
        removed = sorted(key for key in environment if key.startswith(REMOVE_PREFIXES) or key in REMOVE_KEYS)
        for key in removed:
            environment.pop(key)
        environment["PATH"] = "/usr/bin:/bin"
        environment["PYTHONDONTWRITEBYTECODE"] = "1"
        environment["PYTHONUNBUFFERED"] = "1"
        if environment.get("HOME") != original_home:
            raise ValueError("HOME must remain unchanged")
        command = ["/usr/bin/python3", "-B", str(runner), "--source", str(SOURCE / "ci-inputs"),
                   "--manifest", str(manifest_path), "--manifest-sha256", MANIFEST_SHA256,
                   "--out", str(OUTPUT), "--gate-timeout", "600"]
        receipt["argv"] = command
        receipt["environment"] = {"removed_key_names": removed, "removed_prefixes": REMOVE_PREFIXES,
                                  "removed_keys": REMOVE_KEYS, "home_unchanged": True,
                                  "path": "/usr/bin:/bin", "no_environment_values_dumped": True,
                                  "set": {"PYTHONDONTWRITEBYTECODE": "1", "PYTHONUNBUFFERED": "1"}}
        write_json(LAUNCH / "preflight.json", receipt)
        # The original runner owns per-gate timeout/cleanup; propagate signals to
        # that runner and allow it to close its owned fixture process group.
        with (LAUNCH / "runner.stdout.log").open("xb") as stdout, (LAUNCH / "runner.stderr.log").open("xb") as stderr:
            child = subprocess.Popen(command, cwd=ROOT, env=environment, stdin=subprocess.DEVNULL,
                                     stdout=stdout, stderr=stderr)
            def relay(signum, _frame):
                if child.poll() is None:
                    child.send_signal(signum)
            signal.signal(signal.SIGINT, relay)
            signal.signal(signal.SIGTERM, relay)
            receipt["runner_pid"] = child.pid
            receipt["runner_returncode"] = child.wait()
            stdout.flush()
            stderr.flush()
            os.fsync(stdout.fileno())
            os.fsync(stderr.fileno())
        receipt["runner_stdout"] = identity(LAUNCH / "runner.stdout.log")
        receipt["runner_stderr"] = identity(LAUNCH / "runner.stderr.log")
        report_path = OUTPUT / "report.json"
        receipt["report"] = {"path": str(report_path), **identity(report_path)}
        report = json.loads(report_path.read_text())
        receipt["gates_executed"] = len(report["gates"])
        receipt["failed_gates"] = [gate["id"] for gate in report["gates"] if not gate["passed"]]
        receipt["passed"] = (receipt["runner_returncode"] == 0 and report["passed"] is True
                             and len(report["gates"]) == 18 and report["retry_count"] == 0
                             and report["head_commit"] == INPUT_HEAD
                             and report["manifest_sha256"] == MANIFEST_SHA256
                             and report["harness_sha256"] == RUNNER_SHA256
                             and report["final_inputs_unchanged"] is True)
    except Exception as error:
        receipt["error"] = {"type": type(error).__name__, "message": str(error)[:2000]}
    receipt["finished_unix"] = time.time()
    write_json(LAUNCH / "receipt.json", receipt)
    print(json.dumps(receipt), flush=True)
    return 0 if receipt["passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
