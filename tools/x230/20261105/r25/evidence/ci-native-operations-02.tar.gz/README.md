# R25 external CI original native operation evidence

This local bundle preserves both original X230 external CI jobs. It performs no native operation, test, compiler invocation, or remote file access.

The two top-level `*-native-terminal-*.json` files and each `original-start.dto.json` are the exact UTF-8 bytes of the original tool response content text. No JSON parse/re-encode or newline addition was applied to these DTO bytes, so large integer tokens are retained exactly. Original tool envelopes, saved requests, read pages, and readback receipts are retained byte for byte. Requests are the original locally saved structured call arguments; they are not represented as raw wire HTTP payloads.

`native-stdout.log` and `native-stderr.log` are reconstructed artifacts, not DTOs: each is decoded from original process_read `bytes_hex`, concatenated only at contiguous offsets, and checked against the original terminal seen/stored counts and complete/durable/synced/nontruncated flags. The Python supporting progress read is a historical partial read of the child runner log, not part of native stdout reconstruction. Both complete child CI log directories remain on X230 and are included separately by the final evidence exporter.

Each request-binding.json independently recomputes the full typed RequestBinding SHA-256, verifies the original start receipt digest, and verifies the exact u64 readable fingerprint using Python integers. The idempotency key is bound separately, as in the runtime. Every job has one original acknowledged start and no automatic retry. The old predispatch Rust binding receipt remains in supporting/ as a historical predispatch record; it is not the final disposition.

Rust job: 1a1aac67f44-fc05-471d; Python job: 1a1aaa69a3d-fc05-45a1. Rust exact workflow commands report 1,653 PASS, 34 ignored, 1,687 selected, zero failures/retries; five suites include the empty example. Case inventory SHA-256: 874de054557c19edef3c0cb291fb6dd75cde32706e5670b851808db0bf1f8cff. Python reports all 18 exact workflow commands passed. External CI does not assert hosted GitHub Actions passed and does not assert performance adoption.
