"""Local synthetic clocks/metadata and wrapper custody checks; no remote workload."""
from dataclasses import asdict, replace
import builtins
import contextlib
import copy
import hashlib
import io
import json
import os
from pathlib import Path
import tempfile
import threading
import time
import types
import unittest
from unittest import mock

import compiler_monitor as cm
import run_monitored_phase_02 as wrapper
import validate_compiler_monitor as validator


def quiet():
    a = time.monotonic_ns()
    return {'schema': 'hepta-compiler-state-sample/v1', 'started_monotonic_ns': a,
            'finished_monotonic_ns': time.monotonic_ns(), 'records': [], 'blocking_records': [],
            'quiescent': True, 'signals_sent': 0, 'cmdline_or_environment_read': False,
            'enumerated_process_directories': 3}


TEST_LIMITS = replace(cm.FROZEN_LIMITS, period_ns=10_000_000, maximum_lateness_ns=100_000_000,
                      maximum_start_gap_ns=200_000_000, maximum_duration_ns=1_000_000_000,
                      ready_timeout_seconds=1, join_timeout_seconds=1)


def good_ledger():
    monitor = cm.CompilerMonitor(quiet, limits=TEST_LIMITS, cpu_clock=lambda: 0)
    assert monitor.start()
    a = time.monotonic_ns(); time.sleep(0.035); b = time.monotonic_ns()
    result = monitor.stop(a, b)
    assert result['passed'], result['errors']
    assert validator.validate(result, asdict(TEST_LIMITS), a, b)['passed']
    return result


class MonitorTests(unittest.TestCase):
    def test_real_thread_ready_final_and_complete_join(self):
        result = good_ledger()
        self.assertTrue(result['thread_joined'])
        self.assertEqual(result['hot_loop_file_writes'], 0)
        self.assertGreaterEqual(result['sample_count'], 4)

    def test_live_or_raced_metadata_cannot_be_accepted(self):
        for raced in (False, True):
            def snapshot():
                row = quiet(); record = {'pid': 123, 'birth_ticks': 7, 'uid': 1000, 'comm': 'rustc', 'state': 'S', 'blocks': not raced}
                if raced: record['reason'] = 'compiler disappeared while reading'
                row['records'] = [record]; row['blocking_records'] = [] if raced else [record]; row['quiescent'] = raced
                return row
            monitor = cm.CompilerMonitor(snapshot, limits=TEST_LIMITS, cpu_clock=lambda: 0)
            self.assertFalse(monitor.start())
            result = monitor.stop(None, None)
            self.assertFalse(result['passed']); self.assertTrue(result['thread_joined'])

    def test_metadata_exception_and_ledger_exhaustion_are_preserved(self):
        def failure(): raise PermissionError('synthetic metadata denial')
        for reader, limits in [(failure, TEST_LIMITS), (quiet, replace(TEST_LIMITS, maximum_serialized_sample_bytes=1))]:
            monitor = cm.CompilerMonitor(reader, limits=limits, cpu_clock=lambda: 0)
            self.assertFalse(monitor.start())
            result = monitor.stop(None, None)
            self.assertFalse(result['passed']); self.assertTrue(result['errors'])

    def test_missing_due_slot_rejected_even_with_rewritten_summary_and_true_flag(self):
        result = good_ledger(); result['samples'].pop(1)
        result['sample_count'] = len(result['samples'])
        result['serialized_sample_bytes'] = sum(len(json.dumps(row, separators=(',', ':')).encode()) for row in result['samples'])
        result['observed_required_slots'] = [row['slot'] for row in result['samples'] if row['slot'] is not None and row['scheduled_monotonic_ns'] <= result['parent_finished_monotonic_ns']]
        self.assertFalse(validator.validate(result, asdict(TEST_LIMITS), result['parent_started_monotonic_ns'], result['parent_finished_monotonic_ns'])['passed'])

    def test_empty_duplicate_clock_or_cost_corruption_rejects(self):
        original = good_ledger()
        def check(value):
            self.assertFalse(validator.validate(value, asdict(TEST_LIMITS), original['parent_started_monotonic_ns'], original['parent_finished_monotonic_ns'])['passed'])
        empty = copy.deepcopy(original); empty['samples'] = []; empty['sample_count'] = 0; check(empty)
        duplicate = copy.deepcopy(original); duplicate['samples'][1]['slot'] = 0; check(duplicate)
        clock = copy.deepcopy(original); clock['samples'][0]['snapshot']['finished_monotonic_ns'] = clock['samples'][0]['finished_monotonic_ns'] + 1; check(clock)
        cpu = copy.deepcopy(original); cpu['thread_cpu_ns'] = cpu['wall_ns']; cpu['thread_cpu_seconds_per_wall_second'] = 1.0; check(cpu)
        late_ack = copy.deepcopy(original); late_ack['samples'][0]['finished_monotonic_ns'] = original['parent_started_monotonic_ns'] + 1; check(late_ack)

    def test_stop_path_checks_total_duration(self):
        monitor = cm.CompilerMonitor(quiet, limits=TEST_LIMITS, cpu_clock=lambda: 0)
        self.assertTrue(monitor.start()); a = time.monotonic_ns(); b = time.monotonic_ns()
        monitor.limits = replace(TEST_LIMITS, maximum_duration_ns=1)
        result = monitor.stop(a, b)
        self.assertFalse(result['passed'])
        self.assertTrue(any('total duration' in message for message in result['errors']))

    def test_scan_lateness_and_missing_slot_fail_without_burst_normalization(self):
        result = good_ledger()
        row = result['samples'][1]
        row['scheduled_monotonic_ns'] -= TEST_LIMITS.maximum_lateness_ns + 1
        proof = validator.validate(result, asdict(TEST_LIMITS), result['parent_started_monotonic_ns'], result['parent_finished_monotonic_ns'])
        self.assertFalse(proof['passed'])

    def test_verified_reader_executes_checked_memory_bytes(self):
        with tempfile.TemporaryDirectory() as temporary:
            path = Path(temporary) / 'reader.py'
            safe = b"def compiler_snapshot(root):\n return {'marker':'verified'}\n"
            path.write_bytes(safe); original = builtins.compile
            def compile_and_replace(raw, filename, mode, *args, **kwargs):
                if filename == str(path): path.write_text("raise RuntimeError('unverified second read executed')\n")
                return original(raw, filename, mode, *args, **kwargs)
            with mock.patch.object(builtins, 'compile', side_effect=compile_and_replace):
                reader = cm.reader_from_pinned_source(path, hashlib.sha256(safe).hexdigest())
            self.assertEqual(reader()['marker'], 'verified')

    def test_proc_inventory_is_bounded_before_materializing_more_entries(self):
        with tempfile.TemporaryDirectory() as temporary:
            path = Path(temporary) / 'reader.py'; source = b"def compiler_snapshot(root):\n return {'count':len(root.glob('[0-9]*'))}\n"; path.write_bytes(source)
            reader = cm.reader_from_pinned_source(path, hashlib.sha256(source).hexdigest(), maximum_process_directories=2)
            consumed = []
            class Entries:
                def __enter__(self):
                    def rows():
                        for value in range(1, 10):
                            consumed.append(value); yield types.SimpleNamespace(name=str(value))
                    return rows()
                def __exit__(self, *_args): return False
            with mock.patch.object(cm.os, 'scandir', return_value=Entries()):
                with self.assertRaisesRegex(ValueError, 'bound exceeded at 3'): reader()
            self.assertEqual(consumed, [1, 2, 3])

    def test_checked_module_and_parent_text_capture_preserve_exact_utf8(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary); source = b"def main():\n print('original parent \\u8bca\\u65ad')\n return 0\n"; path = root / 'parent.py'; path.write_bytes(source)
            parent, _ = wrapper.load_verified_module(path, hashlib.sha256(source).hexdigest(), '_local_original_parent_fixture')
            with (root / 'stdout').open('x', encoding='utf-8', errors='strict', newline='') as stream:
                os.fchmod(stream.fileno(), 0o600)
                opened = wrapper.capture_opened_identity(stream, root / 'stdout')
                with contextlib.redirect_stdout(stream): self.assertEqual(parent.main(), 0)
                seal = wrapper.seal_capture(stream, root / 'stdout', opened)
            identity, raw = wrapper.checked_read(root / 'stdout')
            self.assertEqual(raw, 'original parent 诊断\n'.encode())
            self.assertEqual(identity['bytes'], len(raw))
            self.assertEqual(seal['descriptor_identity'], seal['final_descriptor_identity'])
            self.assertEqual(seal['opened_descriptor_identity']['st_ino'], identity['descriptor_identity']['st_ino'])
            self.assertTrue(seal['original_descriptor_path_bound'])

    def test_capture_rejects_path_replacement_before_and_after_original_close(self):
        for replace_after_close in (False, True):
            with self.subTest(replace_after_close=replace_after_close), tempfile.TemporaryDirectory() as temporary:
                path = Path(temporary) / 'stdout'
                stream = path.open('x', encoding='utf-8', errors='strict', newline='')
                os.fchmod(stream.fileno(), 0o600)
                opened = wrapper.capture_opened_identity(stream, path)
                stream.write('original bytes\n')
                def replace_path():
                    moved = path.with_name('original-retained')
                    path.rename(moved)
                    path.write_bytes(b'replacement bytes\n'); path.chmod(0o600)
                checked_read = wrapper.checked_read
                def replace_then_read(target, *args, **kwargs):
                    self.assertTrue(stream.closed)
                    replace_path()
                    return checked_read(target, *args, **kwargs)
                try:
                    if not replace_after_close: replace_path()
                    with mock.patch.object(wrapper, 'checked_read', side_effect=replace_then_read if replace_after_close else checked_read):
                        with self.assertRaisesRegex(ValueError, 'original descriptor|capture path'):
                            wrapper.seal_capture(stream, path, opened)
                    self.assertTrue(stream.closed)
                    self.assertEqual(path.with_name('original-retained').read_bytes(), b'original bytes\n')
                finally:
                    if not stream.closed: stream.close()

    def test_package_rejects_symlink_directory_and_special_file(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary); (root / 'source.py').write_bytes(b'pass\n')
            body = {'files': {'source.py': {'bytes': 5, 'sha256': hashlib.sha256(b'pass\n').hexdigest()}}}
            raw = json.dumps(body).encode(); (root / 'manifest.json').write_bytes(raw); digest = hashlib.sha256(raw).hexdigest()
            wrapper.verify_package(root, digest, 'manifest.json')
            (root / 'link').symlink_to(root, target_is_directory=True)
            with self.assertRaises(ValueError): wrapper.verify_package(root, digest, 'manifest.json')
            (root / 'link').unlink(); os.mkfifo(root / 'fifo')
            with self.assertRaises(ValueError): wrapper.verify_package(root, digest, 'manifest.json')

    def test_guarded_thread_cannot_restart(self):
        monitor = cm.CompilerMonitor(quiet, limits=TEST_LIMITS, cpu_clock=lambda: 0)
        self.assertTrue(monitor.start()); a = time.monotonic_ns(); b = time.monotonic_ns(); monitor.stop(a, b)
        with self.assertRaisesRegex(ValueError, 'cannot be restarted'): monitor.start()

    def test_unjoined_stalled_reader_is_invalid_and_retained_prefix_does_not_change(self):
        entered, release = threading.Event(), threading.Event()
        calls = [0]
        def snapshot():
            calls[0] += 1
            if calls[0] == 2:
                entered.set(); release.wait(1)
            return quiet()
        monitor = cm.CompilerMonitor(snapshot, limits=replace(TEST_LIMITS, join_timeout_seconds=0.01), cpu_clock=lambda: 0)
        try:
            self.assertTrue(monitor.start()); start = time.monotonic_ns()
            self.assertTrue(entered.wait(1)); end = time.monotonic_ns()
            result = monitor.stop(start, end)
            self.assertFalse(result['thread_joined']); self.assertFalse(result['passed'])
            retained = json.dumps(result, sort_keys=True)
        finally:
            release.set()
            if monitor.thread is not None: monitor.thread.join(1)
        self.assertFalse(monitor.thread.is_alive())
        self.assertEqual(json.dumps(result, sort_keys=True), retained)


if __name__ == '__main__':
    unittest.main(verbosity=2)
