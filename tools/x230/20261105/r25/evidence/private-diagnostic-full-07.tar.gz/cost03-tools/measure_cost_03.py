#!/usr/bin/env python3
"""One 60s read-only monitor-cost probe; never admit a performance campaign."""
import argparse
from dataclasses import asdict
import hashlib
import json
import os
from pathlib import Path
import signal
import stat
import sys
import time
import traceback
import types

ROOT = Path('/home/qian/hepta-runtime-optimization-20261105-r25')
TOOLS = ROOT / 'mechanism-monitor-cost-tools-03'
OUT = ROOT / 'mechanism-monitor-cost-03'
NAMES = {'compiler_state.py', 'compiler_monitor.py', 'validate_compiler_monitor.py', 'measure_cost_03.py'}
FIELDS = ('st_dev', 'st_ino', 'st_uid', 'st_mode', 'st_nlink', 'st_size', 'st_mtime_ns', 'st_ctime_ns')
ACTIVITY_VALIDATION_ERRORS = {
    'monitor did not pass and completely join', 'monitor error/missed ledger is not empty',
    'metadata observed activity/failure or scope differs', 'live or unproved compiler record present',
}


def checked_read(path, maximum=16 * 1024 * 1024):
    if path.resolve(strict=True) != path: raise ValueError('indirect input')
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
    with os.fdopen(fd, 'rb') as stream:
        before = os.fstat(stream.fileno())
        if not stat.S_ISREG(before.st_mode) or before.st_uid != os.geteuid() or before.st_nlink != 1 or not 0 <= before.st_size <= maximum:
            raise ValueError('input descriptor type/owner/links/bound differs')
        body = stream.read(maximum + 1); after = os.fstat(stream.fileno())
    current = path.lstat()
    if len(body) != after.st_size or any(getattr(before, key) != getattr(after, key) or getattr(after, key) != getattr(current, key) for key in FIELDS):
        raise ValueError('input changed during checked read')
    return {'path': str(path), 'bytes': len(body), 'sha256': hashlib.sha256(body).hexdigest(),
            'descriptor_identity': {key: getattr(after, key) for key in FIELDS}}, body


def save_new(path, value):
    body = (json.dumps(value, sort_keys=True, separators=(',', ':'), allow_nan=False) + '\n').encode()
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600)
    with os.fdopen(fd, 'wb') as stream:
        opened = os.fstat(stream.fileno())
        if not stat.S_ISREG(opened.st_mode) or opened.st_uid != os.geteuid() or opened.st_nlink != 1 or opened.st_size != 0:
            raise ValueError('fresh output descriptor identity differs')
        stream.write(body); stream.flush(); os.fsync(stream.fileno())
        final = os.fstat(stream.fileno()); current = path.lstat()
        if (any(getattr(opened, key) != getattr(final, key) for key in ('st_dev', 'st_ino', 'st_uid', 'st_mode', 'st_nlink'))
                or any(getattr(final, key) != getattr(current, key) for key in FIELDS)):
            raise ValueError('original output descriptor/path changed')
    identity, retained = checked_read(path)
    if (identity['descriptor_identity'] != {key: getattr(final, key) for key in FIELDS}
            or identity['bytes'] != len(body) or identity['sha256'] != hashlib.sha256(body).hexdigest()
            or retained != body):
        raise ValueError('original output descriptor/content differs from retained readback')
    return identity


def load(name, source):
    module = types.ModuleType(name); module.__file__ = source[0]['path']; sys.modules[name] = module
    exec(compile(source[1], module.__file__, 'exec'), module.__dict__)
    return module


def cost_checks(ledger, validation, start, end):
    """Keep live observations intact; exempt only activity from this cost-only decision."""
    reasons = []
    def need(value, reason):
        if not value: reasons.append(reason)
    try:
        need(end - start >= 60_000_000_000, 'full fixed60s observation interval did not complete')
        need(ledger['thread_joined'] is True and ledger['errors_dropped'] == 0
             and ledger['missed_scheduled_slots'] == 0, 'join or complete retained schedule failed')
        need(set(ledger['errors']) <= {'observed live compiler or unproved compiler metadata'},
             'monitor had a non-activity error')
        need(set(validation['errors']) <= ACTIVITY_VALIDATION_ERRORS, 'independent structure/cost validation failed')
        need(ledger['thread_cpu_ns'] * 50 <= ledger['wall_ns'], 'original2percent CPU cost bound failed')
        for row in ledger['samples']:
            snapshot = row['snapshot']
            need(row['error'] is None and snapshot['signals_sent'] == 0
                 and snapshot['cmdline_or_environment_read'] is False, 'metadata exception or scope error')
            need(snapshot['blocking_records'] == [record for record in snapshot['records'] if record['blocks']]
                 and snapshot['quiescent'] == (not snapshot['blocking_records']), 'activity ledger consistency failed')
            for record in snapshot['records']:
                need(record.get('reason') is None, 'metadata failure/race cannot qualify a reduced-cost scan')
                states = record.get('observed_states')
                need(isinstance(states, list) and len(states) == 2 and states[-1] == record['state']
                     and record['blocks'] == any(state not in ('Z', 'X', 'x') for state in states),
                     'two-read live visibility was not preserved')
    except (KeyError, TypeError, ValueError, ZeroDivisionError) as error:
        reasons.append('malformed cost ledger: ' + type(error).__name__ + ': ' + str(error))
    return {'cost_probe_passed': not reasons, 'errors': reasons,
            'formal_measurement_passed': False, 'capacity_attribution_allowed': False,
            'scope': 'CPU and complete sampling cost only; live compiler observations are retained and never relabeled quiescent'}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--manifest-sha256', required=True)
    args = parser.parse_args()
    if sys.platform != 'linux' or os.geteuid() == 0 or Path(__file__).resolve() != TOOLS / 'measure_cost_03.py':
        raise ValueError('fixed native unprivileged cost probe required')
    if TOOLS.resolve(strict=True) != TOOLS or {path.name for path in TOOLS.iterdir()} != NAMES | {'package-manifest.json'}:
        raise ValueError('exact direct five-file cost package required')
    manifest_identity, manifest_raw = checked_read(TOOLS / 'package-manifest.json', 65536)
    if manifest_identity['sha256'] != args.manifest_sha256: raise ValueError('cost package manifest differs')
    manifest = json.loads(manifest_raw)
    if set(manifest['files']) != NAMES: raise ValueError('source inventory differs')
    sources = {name: checked_read(TOOLS / name, 65536) for name in NAMES}
    for name, source in sources.items():
        if {key: source[0][key] for key in ('bytes', 'sha256')} != manifest['files'][name]:
            raise ValueError('cost source pin differs: ' + name)
    OUT.mkdir(mode=0o700)
    component = load('_hepta_cost_monitor03', sources['compiler_monitor.py'])
    validator = load('_hepta_cost_validator03', sources['validate_compiler_monitor.py'])
    reader = component.reader_from_pinned_source(TOOLS / 'compiler_state.py', sources['compiler_state.py'][0]['sha256'])
    monitor = component.CompilerMonitor(reader)
    report = {'schema': 'hepta-compiler-monitor-cost-probe/v1', 'fixed_observation_seconds': 60,
              'cost_probe_passed': False, 'formal_measurement_passed': False, 'capacity_attribution_allowed': False,
              'automatic_retries': 0, 'runtime_or_benchmark_started': False, 'children_spawned': 0,
              'source_pins': {name: source[0] for name, source in sources.items()}, 'manifest': manifest_identity}
    start = end = None
    handlers = {number: signal.getsignal(number) for number in (signal.SIGTERM, signal.SIGINT)}
    def interrupted(number, _frame): raise RuntimeError('cost probe interrupted by signal ' + str(number))
    try:
        for number in handlers: signal.signal(number, interrupted)
        report['initial_quiescence_ready'] = monitor.start()
        start = time.monotonic_ns()
        deadline = start + 60_000_000_000
        while time.monotonic_ns() < deadline:
            time.sleep(min(0.25, max(0, (deadline - time.monotonic_ns()) / 1e9)))
    except BaseException as error:
        report['error'] = type(error).__name__ + ': ' + str(error)
        traceback.print_exc()
    finally:
        end = time.monotonic_ns()
        for number in handlers: signal.signal(number, lambda *_: None)
        ledger = monitor.stop(start, end)
        report['ledger'] = save_new(OUT / 'compiler-monitor.json', ledger)
        retained_identity, retained = checked_read(OUT / 'compiler-monitor.json')
        if retained_identity != report['ledger']: raise ValueError('retained ledger changed')
        validation = validator.validate(json.loads(retained), asdict(component.FROZEN_LIMITS), start, end)
        report['independent_validation'] = save_new(OUT / 'compiler-monitor-validation.json', validation)
        report['quiescence_passed'] = ledger['passed'] is True and validation['passed'] is True
        report['cost_checks'] = cost_checks(json.loads(retained), validation, start, end)
        try:
            for name, original in sources.items():
                if checked_read(TOOLS / name, 65536)[0] != original[0]: raise ValueError('cost source changed')
            if checked_read(TOOLS / 'package-manifest.json', 65536)[0] != manifest_identity: raise ValueError('cost manifest changed')
            report['source_pins_stable'] = True
        except BaseException as error:
            report['source_pins_stable'] = False; report['source_error'] = str(error)
        report['cost_probe_passed'] = bool(report['cost_checks']['cost_probe_passed']
                                          and report['source_pins_stable'] and 'error' not in report)
        report['raw_cost'] = {key: ledger[key] for key in ('thread_cpu_ns', 'wall_ns', 'thread_cpu_seconds_per_wall_second', 'sample_count', 'compiler_records')}
        report['limits_unchanged'] = asdict(component.FROZEN_LIMITS)
        for number, handler in handlers.items(): signal.signal(number, handler)
    receipt = save_new(OUT / 'report.json', report)
    print(json.dumps({'cost_probe_passed': report['cost_probe_passed'], 'quiescence_passed': report['quiescence_passed'],
                      'formal_measurement_passed': False, 'capacity_attribution_allowed': False,
                      'raw_cost': report['raw_cost'], 'report': receipt}), flush=True)
    return 0 if report['cost_probe_passed'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
