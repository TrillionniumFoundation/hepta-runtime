#!/usr/bin/env python3
"""Create-only data installation of the frozen monitor02; execute no payload."""
import hashlib
import io
import json
import os
from pathlib import Path
import stat
import sys
import tarfile

ROOT = Path('/home/qian/hepta-runtime-optimization-20261105-r25')
ARCHIVE = 'mechanism-monitor-tools-02.tar.gz'
DEST = 'mechanism-monitor-tools-02'
BOOTSTRAP = 'mechanism-monitor-bootstrap-02.py'
RECEIPT = 'mechanism-monitor-tools-install-02.json'
ARCHIVE_PIN = {'bytes': 24258, 'sha256': '8dba7b85f33b47126f1a82297bde212a6694fccaf17afb787578ae5367c1d31c'}
ARCHIVE_VERSION = '2053:2366462:24258:1793876468595095400:1793876468596095401'
BOOTSTRAP_PIN = {'bytes': 7133, 'sha256': '776fef341b0006af71277e4a2fe0aae31410475182f2f8a299747eb36be3b0b3'}
MANIFEST_SHA = '58a0a8aabd591fd9305eb260cf77aea23c9a3d247f78f56acef4ec5fe3562ec1'
FIELDS = ('st_dev', 'st_ino', 'st_uid', 'st_mode', 'st_nlink', 'st_size', 'st_mtime_ns', 'st_ctime_ns')


def need(value, reason):
    if not value: raise ValueError(reason)


def pin(raw):
    return {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


def stamp(value):
    return {key: getattr(value, key) for key in FIELDS}


def read_file(directory, name, expected):
    need('/' not in name and name not in ('', '.', '..'), 'non-flat file name')
    fd = os.open(name, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK, dir_fd=directory)
    with os.fdopen(fd, 'rb') as stream:
        before = os.fstat(stream.fileno())
        need(stat.S_ISREG(before.st_mode) and before.st_uid == os.geteuid() and before.st_nlink == 1
             and before.st_size == expected['bytes'], 'file descriptor type, owner, links or size differs: ' + name)
        raw = stream.read(expected['bytes'] + 1)
        after = os.fstat(stream.fileno())
    current = os.stat(name, dir_fd=directory, follow_symlinks=False)
    need(stamp(before) == stamp(after) == stamp(current) and pin(raw) == expected, 'file stability/hash differs: ' + name)
    return raw, {**pin(raw), 'descriptor_identity': stamp(after)}


def absent(directory, name):
    try: os.stat(name, dir_fd=directory, follow_symlinks=False)
    except FileNotFoundError: return
    raise ValueError('create-only destination exists: ' + name)


def create_file(directory, name, raw):
    fd = os.open(name, os.O_RDWR | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600, dir_fd=directory)
    with os.fdopen(fd, 'wb') as stream:
        stream.write(raw); stream.flush(); os.fsync(stream.fileno())
        final = stamp(os.fstat(stream.fileno()))
    _, actual = read_file(directory, name, pin(raw))
    need(actual['descriptor_identity'] == final and stat.S_IMODE(final['st_mode']) == 0o600,
         'created original descriptor/readback identity differs: ' + name)
    return actual


def validated_members(raw):
    need(pin(raw) == ARCHIVE_PIN, 'staged archive hash/size differs')
    files = {}
    with tarfile.open(fileobj=io.BytesIO(raw), mode='r:gz') as archive:
        members = archive.getmembers()
        need(len(members) == 19 and sum(row.size for row in members) == 90123, 'archive member/expanded count differs')
        for member in members:
            need(member.isfile() and not member.issparse() and not member.pax_headers and member.mode == 0o600
                 and '/' not in member.name and '\\' not in member.name and member.name not in ('', '.', '..')
                 and member.name not in files and 0 <= member.size <= 65536, 'unsafe or excessive archive member')
            body = archive.extractfile(member).read(member.size + 1)
            need(len(body) == member.size, 'truncated archive member')
            files[member.name] = body
    manifest_raw = files['package-manifest.json']
    need(hashlib.sha256(manifest_raw).hexdigest() == MANIFEST_SHA, 'frozen manifest differs')
    manifest = json.loads(manifest_raw)
    need(manifest['schema'] == 'hepta-r25-private-monitor-tool-package/v2' and manifest['tool_revision'] == '02'
         and manifest['diagnostic_only'] is True and manifest['production_candidate'] is False, 'manifest scope differs')
    need(set(manifest['files']) == set(files) - {'package-manifest.json'}, 'manifest file inventory differs')
    for name, expected in manifest['files'].items():
        need(pin(files[name]) == expected, 'manifest member identity differs: ' + name)
    return files


def main():
    need(sys.platform == 'linux' and os.geteuid() != 0 and ROOT.resolve(strict=True) == ROOT,
         'direct unprivileged Linux task root required')
    root = os.open(ROOT, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
    target = None
    created = []
    try:
        root_initial = os.fstat(root)
        need(root_initial.st_uid == os.geteuid() and stat.S_IMODE(root_initial.st_mode) == 0o700,
             'owned private task root required')
        absent(root, DEST); absent(root, RECEIPT)
        raw, archive_identity = read_file(root, ARCHIVE, ARCHIVE_PIN)
        archive_version = ':'.join(str(archive_identity['descriptor_identity'][key])
                                   for key in ('st_dev', 'st_ino', 'st_size', 'st_mtime_ns', 'st_ctime_ns'))
        need(archive_version == ARCHIVE_VERSION, 'archive version differs from independent staging readback')
        _, bootstrap_identity = read_file(root, BOOTSTRAP, BOOTSTRAP_PIN)
        files = validated_members(raw)
        # All inputs, safe names, exact members and fresh destinations pass before creating payload paths.
        os.mkdir(DEST, mode=0o700, dir_fd=root)
        target = os.open(DEST, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW, dir_fd=root)
        directory_initial = os.fstat(target)
        need(directory_initial.st_uid == os.geteuid() and stat.S_IMODE(directory_initial.st_mode) == 0o700,
             'fresh tools directory owner/mode differs')
        installed = {}
        for name, body in sorted(files.items()):
            installed[name] = create_file(target, name, body); created.append(name)
        need(set(os.listdir(target)) == set(files), 'installed directory inventory differs')
        for name, body in files.items():
            _, actual = read_file(target, name, pin(body))
            need(actual == installed[name], 'installed file changed after original write: ' + name)
        for name, expected, original in [(ARCHIVE, ARCHIVE_PIN, archive_identity), (BOOTSTRAP, BOOTSTRAP_PIN, bootstrap_identity)]:
            need(read_file(root, name, expected)[1] == original, 'staged input changed during data installation')
        for descriptor, current in [(root, ROOT.lstat()), (target, os.stat(DEST, dir_fd=root, follow_symlinks=False))]:
            own = os.fstat(descriptor)
            need(all(getattr(own, key) == getattr(current, key) for key in ('st_dev', 'st_ino', 'st_uid', 'st_mode')),
                 'owned installation directory identity changed')
        report = {'schema': 'hepta-r25-private-monitor-data-install/v2', 'passed': True,
                  'archive': {'path': str(ROOT / ARCHIVE), **archive_identity},
                  'archive_version': archive_version,
                  'bootstrap_verified_without_rewrite': {'path': str(ROOT / BOOTSTRAP), **bootstrap_identity},
                  'manifest_sha256': MANIFEST_SHA, 'destination': str(ROOT / DEST), 'files': installed,
                  'regular_files_created': len(installed), 'all_destinations_initially_absent': True,
                  'automatic_retries': 0, 'packaged_tools_executed': False, 'monitor_started': False,
                  'cargo_executed': False, 'measurement_started': False, 'source_or_cache_modified': False}
        receipt = create_file(root, RECEIPT, (json.dumps(report, sort_keys=True, indent=2) + '\n').encode())
        os.fsync(target); os.fsync(root)
        print(json.dumps({'passed': True, 'regular_files_created': len(installed),
                          'receipt': {'path': str(ROOT / RECEIPT), **receipt}, 'measurement_started': False}), flush=True)
        return 0
    except BaseException as error:
        print(json.dumps({'passed': False, 'created_files': created, 'error': type(error).__name__ + ': ' + str(error),
                          'automatic_retries': 0, 'measurement_started': False}), flush=True)
        raise
    finally:
        if target is not None: os.close(target)
        os.close(root)


if __name__ == '__main__':
    raise SystemExit(main())
