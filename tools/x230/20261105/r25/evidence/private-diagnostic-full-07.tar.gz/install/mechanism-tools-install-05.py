#!/usr/bin/env python3
"""Create-only installation of frozen diagnostic data; never run packaged tools."""
import hashlib
import io
import json
import os
from pathlib import Path, PurePosixPath
import stat
import tarfile

ROOT = Path('/home/qian/hepta-runtime-optimization-20261105-r25')
ARCHIVE = Path('/home/qian/hepta-runtime-r25-phase-tools-05.tar.gz')
DEST = ROOT / 'mechanism-tools-05'
RECEIPT = ROOT / 'mechanism-tools-install-05.json'
ARCHIVE_BYTES = 148507
ARCHIVE_SHA = 'c9f13862968536b3fddcd930a516ae475f1e8f80a1783ea2b1846f1d4bd2c7cf'
ARCHIVE_VERSION = '2053:14482849:148507:1793872269403827426:1793872285674887801'
MANIFEST_SHA = 'ea379a186a0b0bdb214f5fd2e79233add3e685faa7b6f3a97de8d1e9dede2eb5'


def need(value, reason):
    if not value: raise ValueError(reason)


def identity(raw):
    return {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


def validated_members(raw):
    need(identity(raw) == {'bytes': ARCHIVE_BYTES, 'sha256': ARCHIVE_SHA}, 'staged archive identity mismatch')
    files = {}
    with tarfile.open(fileobj=io.BytesIO(raw), mode='r:gz') as archive:
        members = archive.getmembers()
        need(len(members) == 71 and sum(member.size for member in members) == 630291, 'frozen package member count/expanded bytes differ')
        for member in members:
            part = PurePosixPath(member.name)
            need(member.isfile() and not member.issparse() and not member.pax_headers and member.mode == 0o600
                 and not part.is_absolute() and str(part) == member.name
                 and all(piece not in ('', '.', '..') for piece in part.parts)
                 and '\\' not in member.name and member.name not in files and 0 <= member.size <= 200000,
                 'unsafe, duplicate or excessive package member')
            body = archive.extractfile(member).read(member.size + 1)
            need(len(body) == member.size, 'package member truncated')
            files[member.name] = body
    manifest_raw = files['package-manifest-02.json']
    need(identity(manifest_raw)['sha256'] == MANIFEST_SHA, 'frozen manifest hash differs')
    manifest = json.loads(manifest_raw)
    need(manifest['schema'] == 'hepta-r25-private-phase-tool-package/v2' and manifest['tool_revision'] == '05'
         and manifest['diagnostic_only'] is True and manifest['production_candidate'] is False, 'package scope differs')
    need(set(manifest['files']) == set(files) - {'package-manifest-02.json'}, 'manifest file set differs')
    for name, expected in manifest['files'].items():
        need(identity(files[name]) == expected, 'manifest file identity differs: ' + name)
    return files


def main():
    need(os.geteuid() != 0, 'unprivileged X230 operator required')
    need(ROOT.resolve(strict=True) == ROOT, 'task root is indirect')
    need(not os.path.lexists(DEST) and not os.path.lexists(RECEIPT), 'installation path already exists; no reuse or overwrite')
    fd = os.open(ARCHIVE, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
    with os.fdopen(fd, 'rb') as stream:
        before = os.fstat(stream.fileno())
        need(stat.S_ISREG(before.st_mode) and before.st_nlink == 1 and before.st_uid == os.geteuid()
             and before.st_size == ARCHIVE_BYTES, 'staged archive type/owner/size differs')
        raw = stream.read(ARCHIVE_BYTES + 1)
        after = os.fstat(stream.fileno())
    fields = ('st_dev', 'st_ino', 'st_size', 'st_mtime_ns', 'st_ctime_ns')
    need(all(getattr(before, key) == getattr(after, key) == getattr(ARCHIVE.lstat(), key) for key in fields), 'staged archive changed while reading')
    version = ':'.join(str(getattr(after, key)) for key in fields)
    need(version == ARCHIVE_VERSION, 'archive differs from independent readback version')
    files = validated_members(raw)
    DEST.mkdir(mode=0o700)
    observed = []
    directories = {DEST}
    for name, body in sorted(files.items()):
        target = DEST.joinpath(*PurePosixPath(name).parts)
        target.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
        need(target.parent.resolve(strict=True) == target.parent, 'installation parent is indirect')
        directories.update(parent for parent in target.parents if parent == DEST or parent.is_relative_to(DEST))
        fd = os.open(target, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600)
        with os.fdopen(fd, 'wb') as stream:
            stream.write(body); stream.flush(); os.fsync(stream.fileno())
        restored = target.read_bytes()
        need(restored == body and stat.S_IMODE(target.stat().st_mode) == 0o600, 'installed file readback differs')
        observed.append({'path': name, **identity(restored)})
    need({path.relative_to(DEST).as_posix() for path in DEST.rglob('*') if path.is_file()} == set(files), 'installed file inventory differs')
    receipt = {'schema': 'hepta-r25-private-phase-tools-install/v1', 'passed': True,
               'archive': {'path': str(ARCHIVE), **identity(raw)}, 'archive_version': version,
               'manifest_sha256': MANIFEST_SHA, 'destination': str(DEST), 'files': observed,
               'installer': identity(Path(__file__).read_bytes()), 'packaged_tools_executed': False,
               'cargo_executed': False, 'diagnostic_measurement_executed': False,
               'qualified_source_or_target_modified': False}
    with RECEIPT.open('x') as stream:
        json.dump(receipt, stream, sort_keys=True, indent=2); stream.write('\n'); stream.flush(); os.fsync(stream.fileno())
    for directory in sorted(directories, key=lambda path: len(path.parts), reverse=True) + [ROOT]:
        fd = os.open(directory, os.O_RDONLY | os.O_DIRECTORY)
        try: os.fsync(fd)
        finally: os.close(fd)
    print(json.dumps({'passed': True, 'installed_regular_files': len(observed), 'receipt': str(RECEIPT),
                      'receipt_identity': identity(RECEIPT.read_bytes()), 'packaged_tools_executed': False}), flush=True)
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
