#!/usr/bin/env python3
"""Run the corrected phase03 parent once; retain private05 ELF and native workload."""
import argparse
import contextlib
import datetime
import hashlib
import json
import os
from pathlib import Path
import signal
import stat
import sys
import time
import traceback
import types

ROOT = Path('/home/qian/hepta-runtime-optimization-20261105-r25')
TOOLS = ROOT / 'mechanism-tools-05'
PRIVATE = ROOT / 'mechanism-diagnostic-05'
OUT = ROOT / 'mechanism-monitor-campaign-03'
BOOTSTRAP = ROOT / 'mechanism-monitor-bootstrap-03.py'
HERE = Path(__file__).resolve().parent
PARENT_SHA = '77be22e97ae599b5ca43e81c234f399430a2121664729547219dc64457d3a327'
PARENT_MANIFEST_SHA = 'ea379a186a0b0bdb214f5fd2e79233add3e685faa7b6f3a97de8d1e9dede2eb5'
READER_SHA = '9da718654db04a646e081d2d719a2d6d4655ffe337bc0e3f906e736e4d77a251'
OWNERSHIP_SHA = 'c4c95a5d42c1894c592393dd8404d8ccf266cc76eb4a3f82800b0847a2a08850'
DESCRIPTOR_FIELDS = ('st_dev', 'st_ino', 'st_uid', 'st_mode', 'st_nlink', 'st_size', 'st_mtime_ns', 'st_ctime_ns')


def descriptor_identity(value):
    return {key: getattr(value, key) for key in DESCRIPTOR_FIELDS}


def capture_opened_identity(stream, path):
    opened = os.fstat(stream.fileno())
    identity = descriptor_identity(opened)
    if (not stat.S_ISREG(opened.st_mode) or opened.st_uid != os.geteuid() or opened.st_nlink != 1
            or stat.S_IMODE(opened.st_mode) != 0o600 or opened.st_size != 0
            or path.resolve(strict=True) != path or descriptor_identity(path.lstat()) != identity):
        raise ValueError('new original-parent stream descriptor/path identity differs')
    return identity


def seal_capture(stream, path, opened):
    try:
        stream.flush(); os.fsync(stream.fileno())
        final = descriptor_identity(os.fstat(stream.fileno()))
        if any(final[key] != opened[key] for key in ('st_dev', 'st_ino', 'st_uid', 'st_mode', 'st_nlink')):
            raise ValueError('original-parent capture descriptor ownership changed')
        if path.resolve(strict=True) != path or descriptor_identity(path.lstat()) != final:
            raise ValueError('original-parent capture path no longer names its original descriptor')
    finally:
        stream.close()
    identity, _ = checked_read(path)
    if identity['descriptor_identity'] != final or identity['bytes'] != final['st_size']:
        raise ValueError('original-parent capture changed after original descriptor closed')
    return {**identity, 'opened_descriptor_identity': opened, 'final_descriptor_identity': final,
            'original_descriptor_path_bound': True}


def checked_read(path, maximum=16777216):
    if path.resolve(strict=True) != path: raise ValueError('indirect evidence/source path')
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
    with os.fdopen(fd, 'rb') as stream:
        before = os.fstat(stream.fileno())
        if not stat.S_ISREG(before.st_mode) or before.st_uid != os.geteuid() or before.st_nlink != 1 or not 0 <= before.st_size <= maximum:
            raise ValueError('source/evidence descriptor type, owner, links or bound differs')
        raw = stream.read(maximum + 1)
        after = os.fstat(stream.fileno())
    current = path.lstat()
    if path.resolve(strict=True) != path or len(raw) != after.st_size or any(getattr(before, key) != getattr(after, key) or getattr(after, key) != getattr(current, key) for key in DESCRIPTOR_FIELDS):
        raise ValueError('source/evidence changed during descriptor read')
    return {'path': str(path), 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest(),
            'descriptor_identity': descriptor_identity(after)}, raw


def load_verified_module(path, expected_sha, name):
    identity, raw = checked_read(path, 65536)
    if identity['sha256'] != expected_sha: raise ValueError('reviewed Python source hash differs')
    module = types.ModuleType(name); module.__file__ = str(path)
    sys.modules[name] = module
    exec(compile(raw, str(path), 'exec'), module.__dict__)
    return module, identity


def verify_package(directory, expected_sha, manifest_name):
    if directory.resolve(strict=True) != directory or not stat.S_ISDIR(directory.lstat().st_mode):
        raise ValueError('package directory is indirect or non-directory')
    identity, raw = checked_read(directory / manifest_name)
    if identity['sha256'] != expected_sha: raise ValueError('frozen package manifest differs')
    manifest = json.loads(raw)
    actual = set()
    for path in directory.rglob('*'):
        if path.is_symlink() or path.resolve(strict=True) != path:
            raise ValueError('symlink or indirect entry in frozen package')
        mode = path.lstat().st_mode
        if stat.S_ISREG(mode): actual.add(path.relative_to(directory).as_posix())
        elif not stat.S_ISDIR(mode): raise ValueError('nonregular entry in frozen package')
    if actual != set(manifest['files']) | {manifest_name}: raise ValueError('frozen package inventory differs')
    for name, expected in manifest['files'].items():
        if Path(name).is_absolute() or '..' in Path(name).parts: raise ValueError('invalid package path')
        observed, _ = checked_read(directory / name)
        if (observed['bytes'], observed['sha256']) != (expected['bytes'], expected['sha256']):
            raise ValueError('frozen packaged source differs: ' + name)
    return identity, manifest


def save_new(path, value):
    body = (json.dumps(value, sort_keys=True, separators=(',', ':'), allow_nan=False) + '\n').encode()
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600)
    with os.fdopen(fd, 'wb') as stream:
        opened = os.fstat(stream.fileno())
        if not stat.S_ISREG(opened.st_mode) or opened.st_uid != os.geteuid() or opened.st_nlink != 1 or opened.st_size != 0:
            raise ValueError('fresh output descriptor identity differs')
        stream.write(body); stream.flush(); os.fsync(stream.fileno())
        final = os.fstat(stream.fileno()); current = path.lstat()
        if (any(getattr(opened, key) != getattr(final, key) for key in ('st_dev', 'st_ino', 'st_uid', 'st_mode', 'st_nlink'))
                or any(getattr(final, key) != getattr(current, key) for key in DESCRIPTOR_FIELDS)):
            raise ValueError('original output descriptor/path changed')
    identity, retained = checked_read(path)
    if (identity['descriptor_identity'] != {key: getattr(final, key) for key in DESCRIPTOR_FIELDS}
            or identity['bytes'] != len(body) or identity['sha256'] != hashlib.sha256(body).hexdigest()
            or retained != body):
        raise ValueError('original output descriptor/content differs from retained readback')
    return identity


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--build-report-sha256', required=True)
    parser.add_argument('--monitor-package-manifest-sha256', required=True)
    parser.add_argument('--transmitted-bootstrap-sha256', required=True)
    args = parser.parse_args()
    if os.geteuid() == 0 or ROOT.resolve(strict=True) != ROOT: raise ValueError('unprivileged direct task root required')
    OUT.mkdir(mode=0o700)
    report = {'schema': 'hepta-monitored-private-phase/v2', 'passed': False, 'attribution_allowed': False,
              'diagnostic_only': True, 'production_candidate': False, 'baseline_adoption_status': 'qualified_but_unadopted_R25',
              'started_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'parent_invocations': 0,
              'automatic_retries': 0, 'signals_sent': 0, 'extra_processes_spawned': 0,
              'sampling_scope': '1 Hz observations; no proof about activity between samples',
              'original_parent_unchanged': False, 'private05_binary_and_native_tools_unchanged': True,
              'phase_parent_revision': '03-owned-fresh-socket-directory', 'original_matrix_and_disturbance_gates_unchanged': True}
    monitor = None
    parent_start = parent_end = parent_returncode = None
    monitor_source = parent_source = reader_source = ownership_source = validator_source = socket_source = None
    validator = component = None
    observed_signals = []
    previous_handlers = {number: signal.getsignal(number) for number in (signal.SIGTERM, signal.SIGINT)}
    original_argv, original_path = list(sys.argv), list(sys.path)
    def interrupted(number, _frame):
        observed_signals.append(number)
        raise RuntimeError('monitored original phase interrupted by signal ' + str(number))
    def remember_cleanup_signal(number, _frame):
        if len(observed_signals) < 64: observed_signals.append(number)
    stdout = (OUT / 'original-parent.stdout').open('x', encoding='utf-8', errors='strict', newline='')
    stderr = (OUT / 'original-parent.stderr').open('x', encoding='utf-8', errors='strict', newline='')
    os.fchmod(stdout.fileno(), 0o600); os.fchmod(stderr.fileno(), 0o600)
    stdout_opened = capture_opened_identity(stdout, OUT / 'original-parent.stdout')
    stderr_opened = capture_opened_identity(stderr, OUT / 'original-parent.stderr')
    report['original_parent_streams_custody_passed'] = False
    report['original_parent_opened_streams'] = {'stdout': stdout_opened, 'stderr': stderr_opened}
    try:
        for number in previous_handlers: signal.signal(number, interrupted)
        monitor_package, manifest = verify_package(HERE, args.monitor_package_manifest_sha256, 'package-manifest.json')
        parent_package, _ = verify_package(TOOLS, PARENT_MANIFEST_SHA, 'package-manifest-02.json')
        report.update(monitor_package_manifest=monitor_package, original_parent_package_manifest=parent_package,
                      actual_wrapper_source=checked_read(Path(__file__).resolve(), 65536)[0])
        bootstrap_source, _ = checked_read(BOOTSTRAP, 65536)
        if bootstrap_source['sha256'] != args.transmitted_bootstrap_sha256:
            raise ValueError('actual transmitted bootstrap source differs from holder-supplied SHA')
        report['transmitted_bootstrap_source'] = bootstrap_source
        for path in (PRIVATE / 'phase-parent-03', PRIVATE / 'observation-03', Path('/home/qian/hr-r25-ph03')):
            if os.path.lexists(path): raise ValueError('original phase output path already exists; no reuse')
        sys.path.insert(0, str(TOOLS))
        ownership, ownership_source = load_verified_module(TOOLS / 'owned_build_process.py', OWNERSHIP_SHA, '_hepta_phase_ownership')
        ownership.require_native_proc()
        report['wrapper_process_identity'] = ownership.process(os.getpid())
        report['ownership_helper_source'] = ownership_source
        component, monitor_source = load_verified_module(HERE / 'compiler_monitor.py', manifest['files']['compiler_monitor.py']['sha256'], '_hepta_phase_compiler_monitor')
        validator, validator_source = load_verified_module(HERE / 'validate_compiler_monitor.py', manifest['files']['validate_compiler_monitor.py']['sha256'], '_hepta_phase_monitor_validator')
        _, reader_source = load_verified_module(HERE / 'compiler_state.py', READER_SHA, '_hepta_phase_compiler_reader03')
        _, socket_source = load_verified_module(HERE / 'owned_socket_parent03.py', manifest['files']['owned_socket_parent03.py']['sha256'], '_hepta_phase_owned_socket03')
        parent, parent_source = load_verified_module(HERE / 'run_phase_observation_03.py', PARENT_SHA, '_hepta_phase_parent03')
        monitor = component.CompilerMonitor(component.reader_from_pinned_source(HERE / 'compiler_state.py', READER_SHA))
        if not monitor.start(): raise ValueError('initial bounded compiler monitor sample failed; original parent not started')
        sys.argv = [str(HERE / 'run_phase_observation_03.py'), '--build-report-sha256', args.build_report_sha256,
                    '--package-manifest-sha256', PARENT_MANIFEST_SHA]
        report['original_parent_argv'] = list(sys.argv)
        report['parent_invocations'] = 1
        parent_start = time.monotonic_ns()
        with contextlib.redirect_stdout(stdout), contextlib.redirect_stderr(stderr):
            try:
                parent_returncode = parent.main()
            finally:
                parent_end = time.monotonic_ns()
    except BaseException as error:
        report['error'] = type(error).__name__ + ': ' + str(error)
        with contextlib.redirect_stderr(stderr): traceback.print_exc()
    finally:
        # Original parent cleanup has returned before this bounded monitor join.
        # Repeated cancellation cannot turn incomplete monitor coverage into success.
        for number in previous_handlers: signal.signal(number, remember_cleanup_signal)
        try:
            if monitor is not None:
                monitor_result = monitor.stop(parent_start, parent_end)
            else:
                monitor_result = {'passed': False, 'errors': ['monitor did not start'], 'thread_joined': False}
        except BaseException as error:
            monitor_result = {'passed': False, 'errors': ['monitor stop failed: ' + type(error).__name__ + ': ' + str(error)],
                              'thread_joined': False}
        report['monitor_result'] = save_new(OUT / 'compiler-monitor.json', monitor_result)
        try:
            retained_identity, retained_raw = checked_read(OUT / 'compiler-monitor.json')
            if retained_identity != report['monitor_result'] or validator is None or component is None:
                raise ValueError('retained monitor or source-bound validator unavailable')
            monitor_validation = validator.validate(json.loads(retained_raw), component.asdict(component.FROZEN_LIMITS), parent_start, parent_end)
        except BaseException as error:
            monitor_validation = {'passed': False, 'errors': ['monitor validation failed: ' + type(error).__name__ + ': ' + str(error)]}
        report['monitor_validation'] = save_new(OUT / 'compiler-monitor-validation.json', monitor_validation)
        report['monitor_passed'] = monitor_result['passed'] is True and monitor_validation['passed'] is True
        report['parent_returncode'] = parent_returncode
        report['observed_wrapper_signals'] = observed_signals
        custody_errors = []
        for name, stream, opened in [('stdout', stdout, stdout_opened), ('stderr', stderr, stderr_opened)]:
            try:
                report['original_parent_' + name] = seal_capture(stream, OUT / ('original-parent.' + name), opened)
            except BaseException as error:
                custody_errors.append(name + ': ' + type(error).__name__ + ': ' + str(error))
        report['original_parent_stream_custody_errors'] = custody_errors
        report['original_parent_streams_custody_passed'] = not custody_errors
        sys.argv, sys.path = original_argv, original_path
    try:
        for name, expected in [('monitor_component', monitor_source), ('original_parent', parent_source), ('compiler_metadata', reader_source),
                               ('monitor_validator', validator_source), ('ownership_helper', ownership_source), ('socket_parent_helper', socket_source),
                               ('transmitted_bootstrap', report.get('transmitted_bootstrap_source')),
                               ('actual_wrapper', report.get('actual_wrapper_source'))]:
            if expected is None: raise ValueError('required source identity was never established')
            actual, _ = checked_read(Path(expected['path']), 65536)
            if actual != expected: raise ValueError('source changed during original phase: ' + name)
            report[name + '_source'] = actual
        verify_package(HERE, args.monitor_package_manifest_sha256, 'package-manifest.json')
        verify_package(TOOLS, PARENT_MANIFEST_SHA, 'package-manifest-02.json')
        phase_path = PRIVATE / 'phase-parent-03/report.json'
        if report['parent_invocations'] == 1 and phase_path.exists():
            phase_identity, raw = checked_read(phase_path)
            phase = json.loads(raw)
            report['original_parent_report'] = phase_identity
            report['original_parent_passed'] = phase['passed']
            report['original_parent_attribution_allowed'] = phase['attribution_allowed']
        else:
            phase = {'passed': False, 'attribution_allowed': False}
        report['passed'] = report['attribution_allowed'] = bool(
            report.get('error') is None and parent_returncode == 0 and report['monitor_passed'] and
            report['original_parent_streams_custody_passed'] and
            phase['passed'] is True and phase['attribution_allowed'] is True
            and phase.get('socket_parent_cleanup', {}).get('passed') is True and not observed_signals)
    except BaseException as error:
        report['postcheck_error'] = type(error).__name__ + ': ' + str(error)
    finally:
        report['finished_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
        for number, previous in previous_handlers.items(): signal.signal(number, previous)
    result = save_new(OUT / 'report.json', report)
    print(json.dumps({'passed': report['passed'], 'attribution_allowed': report['attribution_allowed'],
                      'report': result}), flush=True)
    return 0 if report['passed'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
