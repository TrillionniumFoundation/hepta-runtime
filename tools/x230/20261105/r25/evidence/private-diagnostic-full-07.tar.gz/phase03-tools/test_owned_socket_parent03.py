"""Three local directory-custody fixtures; no runtime or process observation."""
from pathlib import Path
import tempfile
import unittest

from owned_socket_parent03 import OwnedSocketParent


class SocketParentTests(unittest.TestCase):
    def test_empty_original_directory_is_removed_and_fd_closed(self):
        with tempfile.TemporaryDirectory() as temporary:
            path = Path(temporary) / 'socket-parent'
            owner = OwnedSocketParent(path)
            created = owner.create()
            self.assertTrue(created['created_fresh'])
            self.assertEqual(path.stat().st_mode & 0o777, 0o700)
            proof = owner.cleanup()
            self.assertTrue(proof['passed']); self.assertTrue(proof['descriptor_closed'])
            self.assertEqual(proof['held_descriptor_nlink_after_removal'], 0)
            self.assertFalse(path.exists())

    def test_nonempty_owned_directory_is_retained_and_invalid(self):
        with tempfile.TemporaryDirectory() as temporary:
            path = Path(temporary) / 'socket-parent'; owner = OwnedSocketParent(path); owner.create()
            (path / 'owned-unresolved-entry').write_text('synthetic only')
            proof = owner.cleanup()
            self.assertFalse(proof['passed']); self.assertFalse(proof['removed'])
            self.assertTrue(proof['descriptor_closed']); self.assertEqual(proof['remaining_entry_count'], 1)
            self.assertTrue((path / 'owned-unresolved-entry').exists())

    def test_replaced_path_never_removes_substitute_or_original(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary); path = root / 'socket-parent'
            owner = OwnedSocketParent(path); owner.create()
            original = root / 'original-retained'; path.rename(original); path.mkdir(mode=0o700)
            proof = owner.cleanup()
            self.assertFalse(proof['passed']); self.assertFalse(proof['removed'])
            self.assertTrue(proof['descriptor_closed']); self.assertTrue(original.exists()); self.assertTrue(path.exists())


if __name__ == '__main__':
    unittest.main(verbosity=2)
