#!/usr/bin/env python3
"""Fresh phase03 paths and owned socket parent; unchanged private05 ELF and native matrix."""
import argparse
from collections import Counter
import contextlib
import datetime
import hashlib
import json
import os
from pathlib import Path
import signal
import sys
import time
import traceback

sys.dont_write_bytecode = True
from phase_contract import BASELINE_SHA, OVERLAY_SHA, QUALIFICATION_SHA, identity, map_sha, need, validate_native_matrix, verify_package
from phase_campaign_checks import PHASE_COUNTS, disturbance_gates, independent_phase_gate
from prepare_and_build_diagnostic_02 import BASE_SOURCE, PRIVATE, QUALIFICATION, SELECTED_TESTS, SOURCE, file_identity, source_map
from stderr_custody import controller_with_stderr_seal, seal_capture
import analyze_phase_diagnostic_02 as phase_analyzer
from _hepta_phase_compiler_reader03 import compiler_snapshot
from _hepta_phase_owned_socket03 import OwnedSocketParent

HERE = Path('/home/qian/hepta-runtime-optimization-20261105-r25/mechanism-tools-05')
TOOLS = HERE / 'original-native'
OUT = PRIVATE / 'observation-03'
PARENT = PRIVATE / 'phase-parent-03'
PROFILE = Path('/home/qian/hepta-runtime-optimization-20261023/r11-native-observation-abba-20261103-02/profile/profile.json')
TOPOLOGY = Path('/home/qian/hepta-runtime-optimization-20261104-r16/benchmark-topology.json')
FROZEN_JOBS = Path('/home/qian/hepta-runtime-optimization-20261023/a31-frozen-originals-r01')
SOCKET_PARENT = Path('/home/qian/hr-r25-ph03')
PROFILE_SHA = 'fe1e9551b5b8812ad6ed3da018c282b7261f7caeb2f49e4dcfefba7ff784ab08'
TOPOLOGY_SHA = '8c0767d3318131a7d470d9cde8e327a59ce18adf022c8bc1b1d5a0fa9a865287'


def compiler_processes():
    sample = compiler_snapshot()
    print(json.dumps({'compiler_state_sample': sample}, separators=(',', ':')), flush=True)
    return sample['blocking_records']


def save_new(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, indent=2, allow_nan=False); stream.write('\n')
        stream.flush(); os.fsync(stream.fileno())


def machine_snapshot():
    paths = [Path('/proc/loadavg'), Path('/proc/meminfo'), Path('/proc/uptime'), Path('/proc/sys/kernel/perf_event_paranoid')]
    paths += sorted(Path('/sys/devices/system/cpu').glob('cpu[0-9]*/cpufreq/scaling_cur_freq'))
    paths += sorted(Path('/sys/class/thermal').glob('thermal_zone*/temp'))
    values = {}
    for path in paths:
        try: values[str(path)] = path.read_text()[:32768]
        except OSError as error: values[str(path)] = {'error': type(error).__name__, 'errno': error.errno}
    disk = os.statvfs(PRIVATE)
    return {'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'monotonic_ns': time.monotonic_ns(),
            'loadavg': list(os.getloadavg()), 'disk_available_bytes': disk.f_bavail * disk.f_frsize,
            'cpu_count': os.cpu_count(), 'values': values, 'machine_settings_changed': False}


def require_build(build):
    need(build['schema'] == 'hepta-r25-private-observation-build/v2' and build['passed'] is True, 'private diagnostic build did not pass')
    need(build['diagnostic_only'] is True and build['production_candidate'] is False, 'private build scope differs')
    need(build['qualification_report']['sha256'] == QUALIFICATION_SHA and build['overlay_manifest_sha256'] == OVERLAY_SHA, 'private build source provenance differs')
    need(build['baseline']['binary']['sha256'] == BASELINE_SHA, 'private build baseline differs')
    need(build['baseline_source_unchanged'] is True and build['compiler_quiescent_after'] is True, 'build left changed inputs or active compilation')
    need(build['source02_or_qualified_target_writes'] is False and build['automatic_retries'] == 0, 'build isolation differs')
    need(build['diagnostic_tool_tests'] == {'executed': 11, 'passed': 11, 'skipped': 0, 'native_proc_timeout_cleanup_executed': True}, 'real Linux helper ownership test is incomplete')
    need(len(SELECTED_TESTS) == len(set(SELECTED_TESTS)) == 16, 'recorder/pool/validation selection is incomplete')
    expected_stages = (['diagnostic-tool-tests', 'format', 'fmt-check', 'clippy', 'test-build', 'test-inventory']
                       + ['selected-test-' + str(index + 1) for index in range(16)] + ['release'])
    need([row['name'] for row in build['stages']] == expected_stages and all(row['returncode'] == 0 and row['automatic_retry'] is False for row in build['stages']), 'private build stages incomplete')
    need([row['name'] for row in build['selected_tests']] == SELECTED_TESTS, 'selected recorder/ownership regression set differs')
    need(all(row['attempt'] == 1 and row['stdout_proof']['passed'] is True for row in build['selected_tests']), 'selected recorder/ownership regression did not pass')
    need(build['diagnostic']['source_tested'] == build['diagnostic']['source_after'], 'diagnostic sources changed during build')


def inspect_stderr(native):
    from analyze_phase_diagnostic import PREFIX, validate_trace
    proofs, traces = [], {}
    for index, row in enumerate(native['rounds']):
        for directory, start_key, stop_key, calls in [('first', 'startup', 'shutdown', 654), ('restart', 'restart_startup', 'restart_shutdown', 12)]:
            capture = row[stop_key]['stderr_capture']
            path = OUT / ('round-' + str(index) + '-' + row['version']) / directory / 'stderr.log'
            need(capture['valid'] is True and Path(capture['path']) == path, 'complete stderr capture path/validity differs')
            need((capture['pid'], capture['birth_ticks']) == (row[start_key]['pid'], row[start_key]['birth_ticks']), 'stderr controller generation differs')
            need(capture['binary_sha256'] == native['binary_sha256'][row['version']], 'stderr actual binary differs')
            need(seal_capture(capture) == capture, 'full stderr changed since cleanup seal')
            raw = path.read_bytes()
            proof = {'round': index, 'version': row['version'], 'controller': directory, 'stderr': identity(raw), 'path': str(path), 'passed': True}
            if row['version'] == 'A':
                need(not any(line.startswith(PREFIX) for line in raw.splitlines()), 'normal runtime unexpectedly emitted phase diagnostics')
                proof['diagnostic_dump_count'] = 0
            else:
                trace = validate_trace(raw)
                counts = Counter(event['p'] for event in trace['events'])
                # Startup/master renewal can add gates outside measured cells;
                # retain all events and require at least every ordinary RPC.
                need(all(counts[index] >= calls * count for index, count in enumerate(PHASE_COUNTS)), 'controller trace lacks ordinary RPC phases')
                proof.update(diagnostic_dump_count=1, events=len(trace['events']), phase_counts=dict(counts), ordinary_rpc_minimum=calls)
                traces[(index, directory)] = trace
            proofs.append(proof)
    return proofs, traces


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--build-report-sha256', required=True)
    parser.add_argument('--package-manifest-sha256', required=True)
    args = parser.parse_args()
    need(os.geteuid() != 0, 'diagnostic campaign requires unprivileged operator')
    package_identity = verify_package(HERE, args.package_manifest_sha256)
    build_path = PRIVATE / 'build-report.json'
    build_raw = build_path.read_bytes(); build = json.loads(build_raw)
    need(identity(build_raw)['sha256'] == args.build_report_sha256, 'private build report changed')
    require_build(build)
    qualified_raw = QUALIFICATION.read_bytes()
    need(identity(qualified_raw)['sha256'] == QUALIFICATION_SHA, 'actual qualified R25 report changed')
    baseline = Path(build['baseline']['binary']['path'])
    diagnostic = Path(build['diagnostic']['binary']['path'])
    need(baseline == QUALIFICATION.parent / 'hepta-runtime' and diagnostic == PRIVATE / 'hepta-runtime-diagnostic', 'binary paths escaped qualified/private roots')
    need(file_identity(baseline) == build['baseline']['binary'] and file_identity(diagnostic) == build['diagnostic']['binary'], 'actual binaries changed since build')
    need(source_map(BASE_SOURCE) == build['baseline']['source_map'] and source_map(SOURCE) == build['diagnostic']['source_after'], 'actual baseline/diagnostic sources changed')
    need(file_identity(PROFILE)['sha256'] == PROFILE_SHA and file_identity(TOPOLOGY)['sha256'] == TOPOLOGY_SHA, 'original profile/topology changed')
    need(not compiler_processes(), 'compiler active; diagnostic measurement prohibited')
    need(os.environ.get('SSH_AUTH_SOCK', '').startswith('/'), 'root-owned live held SSH agent required')
    need(not any(os.path.lexists(path) for path in (OUT, PARENT, SOCKET_PARENT)), 'diagnostic attempt paths already exist; no automatic reuse')
    PARENT.mkdir(mode=0o700)
    result = {'schema': 'hepta-r25-phase-diagnostic-campaign/v2', 'passed': False, 'attribution_allowed': False,
              'diagnostic_only': True, 'production_candidate': False,
              'baseline_adoption_status': 'qualified_but_unadopted_R25',
              'started_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
              'tool_package_manifest': package_identity, 'private_build_report': identity(build_raw),
              'qualified_report': identity(qualified_raw), 'automatic_retries': 0,
              'warmup_calls_filtered_from_success_proofs': False,
              'production_comparison_or_adoption': False,
              'actual_phase_parent_source': file_identity(Path(__file__).resolve()),
              'original_native_tools_unchanged': True, 'private05_binary_rebuilt': False}
    result['machine_before_quiescence'] = machine_snapshot()
    socket_parent = OwnedSocketParent(SOCKET_PARENT)
    controller_class = None
    native = None
    original_argv = list(sys.argv)
    handlers = {}
    def interrupted(signum, _frame):
        raise RuntimeError('diagnostic campaign interrupted by signal ' + str(signum))
    try:
        result['socket_parent_created'] = socket_parent.create()
        sys.path.insert(0, str(TOOLS))
        import run_native_observation as native
        import analyze_native_observation as native_analysis
        native.bench.need(native.bench.agent_identity(os.environ['SSH_AUTH_SOCK']), 'held agent cannot be observed')
        controller_class = native.bench.Controller
        native.bench.Controller = controller_with_stderr_seal(controller_class, {str(baseline): BASELINE_SHA, str(diagnostic): build['diagnostic']['binary']['sha256']})
        native_argv = [str(TOOLS / 'run_native_observation.py'), '--baseline', str(baseline), '--candidate', str(diagnostic),
                       '--arena-max', '1', '--profile-template', str(PROFILE), '--topology', str(TOPOLOGY),
                       '--frozen-jobs', str(FROZEN_JOBS), '--out', str(OUT), '--socket-parent', str(SOCKET_PARENT),
                       '--calls', '192', '--concurrency', '1', '8', '16', '--workers', '2', '--order', 'ABBA', '--warmup-calls', '24']
        result['native_argv'] = native_argv
        save_new(PARENT / 'launch-input.json', result)
        # These waits are part of the future root-owned native job, not local preparation.
        # They occur before any measured controller, after source hashing/private build.
        deadline = time.monotonic() + 90
        result['quiescence'] = []
        while time.monotonic() < deadline:
            need(not compiler_processes(), 'compiler started during quiescence')
            result['quiescence'].append(machine_snapshot())
            time.sleep(min(15, max(0, deadline - time.monotonic())))
        need(not compiler_processes(), 'compiler started during quiescence')
        result['machine_before_native'] = machine_snapshot()
        for signum in (signal.SIGTERM, signal.SIGINT, signal.SIGALRM):
            handlers[signum] = signal.signal(signum, interrupted)
        signal.alarm(1800)
        sys.argv = native_argv
        with (PARENT / 'native.stdout').open('x') as stdout, (PARENT / 'native.stderr').open('x') as stderr:
            with contextlib.redirect_stdout(stdout), contextlib.redirect_stderr(stderr):
                native_returncode = native.main()
            stdout.flush(); stderr.flush(); os.fsync(stdout.fileno()); os.fsync(stderr.fileno())
        signal.alarm(0)
        result['native_returncode'] = native_returncode
        raw = (OUT / 'report.json').read_bytes(); report = json.loads(raw)
        result['native_report'] = identity(raw)
        need(native_returncode == 0, 'original native campaign failed; retain original evidence')
        validate_native_matrix(report)
        analysis = native_analysis.analyze(raw, OUT)
        need(analysis['verified'] is True and [analysis[key] for key in ('failed_calls', 'measured_calls', 'warmup_calls', 'preflight_restart_calls', 'total_calls')] == [0, 2304, 288, 72, 2664], 'raw native evidence count gate failed')
        save_new(PARENT / 'native-analysis.json', analysis)
        result['complete_stderr_proofs'], traces = inspect_stderr(report)
        need(source_map(BASE_SOURCE) == build['baseline']['source_map'] and source_map(SOURCE) == build['diagnostic']['source_after'], 'sources changed during diagnostic campaign')
        need(file_identity(baseline) == build['baseline']['binary'] and file_identity(diagnostic) == build['diagnostic']['binary'], 'binaries changed during diagnostic campaign')
        need(QUALIFICATION.read_bytes() == qualified_raw and build_path.read_bytes() == build_raw, 'qualified/private build report changed')
        need(verify_package(HERE, args.package_manifest_sha256) == package_identity, 'tools changed during diagnostic campaign')
        need(not compiler_processes(), 'compiler present after diagnostic campaign')
        binding = {'schema': 'hepta-r25-phase-campaign-bindings/v2', 'diagnostic_only': True, 'production_candidate': False,
                   'native_report': identity(raw), 'qualification_report': identity(qualified_raw), 'overlay_manifest_sha256': OVERLAY_SHA,
                   'baseline_sources_unchanged': True, 'diagnostic_sources_unchanged': True, 'binaries_unchanged': True, 'tools_unchanged': True,
                   'baseline_source_map': build['baseline']['source_map'], 'diagnostic_source_map': build['diagnostic']['source_after'],
                   'baseline_source_map_sha256': map_sha(build['baseline']['source_map']), 'diagnostic_source_map_sha256': map_sha(build['diagnostic']['source_after']),
                   'binary_sha256': report['binary_sha256'], 'build_report': {'passed': True, 'diagnostic_only': True, **identity(build_raw)},
                   'native_analysis': analysis}
        save_new(PARENT / 'bindings.json', binding)
        binding_sha = file_identity(PARENT / 'bindings.json')['sha256']
        result['phase_analyses'] = []
        for index in (1, 2):
            phase_path = PARENT / ('phase-round-' + str(index) + '.json')
            stderr_path = OUT / ('round-' + str(index) + '-B/first/stderr.log')
            # Exercise the same hardened CLI contract that standalone consumers use.
            sys.argv = ['analyze_phase_diagnostic_02.py', '--stderr', str(stderr_path), '--native-report', str(OUT / 'report.json'),
                        '--binding', str(PARENT / 'bindings.json'), '--binding-sha256', binding_sha,
                        '--round', str(index), '--out', str(phase_path)]
            returncode = phase_analyzer.main()
            analyzed = json.loads(phase_path.read_bytes())
            entry = {'round': index, 'analyzer_returncode': returncode, 'result': file_identity(phase_path)}
            result['phase_analyses'].append(entry)
            need(returncode == 0 and analyzed['passed'] is True and analyzed['phase_count_gate_passed'] is True, 'strict phase analyzer failed; preserve count mismatch')
            entry['parent_count_proof'] = independent_phase_gate(analyzed, traces[(index, 'first')], report['rounds'][index])
        result['instrumentation_disturbance'] = disturbance_gates(analysis)
        need(result['instrumentation_disturbance']['passed'], 'diagnostic instrumentation disturbance gates failed; capacity attribution prohibited')
        result['passed'] = result['attribution_allowed'] = True
    except BaseException as error:
        result['error'] = type(error).__name__ + ': ' + str(error)
        with (PARENT / 'failure.traceback').open('x') as stream:
            traceback.print_exc(file=stream)
    finally:
        signal.alarm(0)
        for signum, handler in handlers.items(): signal.signal(signum, handler)
        sys.argv = original_argv
        if native is not None and controller_class is not None: native.bench.Controller = controller_class
        result['socket_parent_cleanup'] = socket_parent.cleanup()
        if not result['socket_parent_cleanup']['passed']:
            result['passed'] = result['attribution_allowed'] = False
        result['machine_after_native'] = machine_snapshot()
        result['finished_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
        save_new(PARENT / 'report.json', result)
    print(json.dumps({'passed': result['passed'], 'attribution_allowed': result['attribution_allowed'], 'report': file_identity(PARENT / 'report.json')}), flush=True)
    return 0 if result['passed'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
