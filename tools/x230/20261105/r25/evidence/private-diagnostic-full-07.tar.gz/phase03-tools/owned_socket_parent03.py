"""Own one fresh private directory; remove it only if still the same empty inode."""
import os
from pathlib import Path
import stat

FIELDS = ('st_dev', 'st_ino', 'st_uid', 'st_mode')


def identity(value):
    return {key: getattr(value, key) for key in FIELDS}


class OwnedSocketParent:
    def __init__(self, path):
        self.path = Path(path)
        self.created = False
        self.fd = self.opened = None

    def same_directory(self):
        held, current = os.fstat(self.fd), self.path.lstat()
        if (self.path.resolve(strict=True) != self.path
                or identity(held) != self.opened or identity(current) != self.opened
                or not stat.S_ISDIR(held.st_mode) or held.st_uid != os.geteuid()
                or stat.S_IMODE(held.st_mode) != 0o700):
            raise ValueError('owned socket parent descriptor/path identity changed')
        return identity(held)

    def create(self):
        if self.created or self.fd is not None:
            raise ValueError('socket parent cannot be reused')
        if self.path.parent.resolve(strict=True) != self.path.parent:
            raise ValueError('socket parent ancestor is indirect')
        os.mkdir(self.path, 0o700)
        self.created = True
        self.fd = os.open(self.path, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW | os.O_CLOEXEC)
        self.opened = identity(os.fstat(self.fd))
        actual = self.same_directory()
        return {'path': str(self.path), 'created_fresh': True, 'opened_directory_identity': actual,
                'descriptor_retained_until_cleanup': True}

    def cleanup(self):
        report = {'path': str(self.path), 'created_by_this_attempt': self.created,
                  'opened_directory_identity': self.opened, 'passed': False,
                  'recursive_removal': False, 'unknown_process_signals': 0,
                  'removed': False, 'descriptor_closed': False}
        try:
            if not self.created:
                report['passed'] = True
                return report
            if self.fd is None:
                raise ValueError('socket parent created but original directory fd was not established')
            report['before_removal_identity'] = self.same_directory()
            entries = os.listdir(self.fd)
            report['remaining_entry_count'] = len(entries)
            report['remaining_entries_first128'] = sorted(entries)[:128]
            if entries:
                raise ValueError('owned socket parent is not empty; preserve it without removal')
            os.rmdir(self.path)
            report['removed'] = True
            report['held_descriptor_nlink_after_removal'] = os.fstat(self.fd).st_nlink
            report['pathname_absent_after_removal'] = not os.path.lexists(self.path)
            if report['held_descriptor_nlink_after_removal'] != 0 or not report['pathname_absent_after_removal']:
                raise ValueError('owned socket parent removal postcondition differs')
            report['passed'] = True
        except BaseException as error:
            report['error'] = type(error).__name__ + ': ' + str(error)
        finally:
            if self.fd is not None:
                os.close(self.fd)
                self.fd = None
                report['descriptor_closed'] = True
        return report
