// Copyright 2026 Muvon Un Limited
// Copyright 2026 TrillionniumFoundation
// SPDX-License-Identifier: Apache-2.0
//! Fixed-capacity private event recorder; output is invalid after any loss.
use super::Phase;
use serde::Serialize;
use std::io::{BufWriter, Write};
use std::sync::atomic::{AtomicU64, Ordering};
use std::sync::{Mutex, OnceLock};

const EVENT_CAPACITY: usize = 65_536;
const COMPLETED: u8 = 1;
const THREAD_CPU: u8 = 2;
const CLOCK_ERROR: u8 = 4;
const PHASE_NAMES: [&str; 22] = [
	"channel_wait",
	"actor_dispatch_wait_including_channel",
	"admission_profile",
	"host_permit_wait",
	"master_ready_wait",
	"capture_permit_wait",
	"pre_capture_profile",
	"capture",
	"response_profile",
	"output_retention",
	"profile_before_agent",
	"agent",
	"profile_after_agent",
	"validation_permit_wait",
	"blocking_queue_wait",
	"worker_read",
	"worker_owner_wait",
	"owner_read",
	"owner_boundaries",
	"validation_permit_held",
	"request_execution",
	"lease_to_capture",
];

// s/e are absolute CLOCK_MONOTONIC nanoseconds; c is thread CPU nanoseconds
// only when f & THREAD_CPU != 0. Small numeric fields avoid recording any
// command, input, output, host, path, credential or request identifier.
#[derive(Serialize)]
struct Event {
	s: u64,
	e: u64,
	c: u64,
	p: u8,
	f: u8,
}

struct Ledger {
	events: Mutex<Vec<Event>>,
	capacity: usize,
	active: AtomicU64,
	dropped: AtomicU64,
	aborted: AtomicU64,
	clock_errors: AtomicU64,
	poisoned: AtomicU64,
}

impl Ledger {
	fn new(capacity: usize) -> Self {
		Self {
			events: Mutex::new(Vec::with_capacity(capacity)),
			capacity,
			active: AtomicU64::new(0),
			dropped: AtomicU64::new(0),
			aborted: AtomicU64::new(0),
			clock_errors: AtomicU64::new(0),
			poisoned: AtomicU64::new(0),
		}
	}

	fn record(&self, event: Event) {
		if event.f & COMPLETED == 0 {
			self.aborted.fetch_add(1, Ordering::Relaxed);
		}
		if event.f & CLOCK_ERROR != 0 {
			self.clock_errors.fetch_add(1, Ordering::Relaxed);
		}
		let Ok(mut events) = self.events.lock() else {
			self.poisoned.fetch_add(1, Ordering::Relaxed);
			self.dropped.fetch_add(1, Ordering::Relaxed);
			return;
		};
		if events.len() == self.capacity {
			self.dropped.fetch_add(1, Ordering::Relaxed);
			return;
		}
		events.push(event);
	}
}

fn ledger() -> &'static Ledger {
	static LEDGER: OnceLock<Ledger> = OnceLock::new();
	LEDGER.get_or_init(|| Ledger::new(EVENT_CAPACITY))
}

fn clock(id: libc::clockid_t) -> Option<u64> {
	let mut value = libc::timespec {
		tv_sec: 0,
		tv_nsec: 0,
	};
	if unsafe { libc::clock_gettime(id, &mut value) } != 0
		|| value.tv_sec < 0
		|| !(0..1_000_000_000).contains(&value.tv_nsec)
	{
		return None;
	}
	(value.tv_sec as u64)
		.checked_mul(1_000_000_000)?
		.checked_add(value.tv_nsec as u64)
}

#[derive(Clone, Copy)]
pub(crate) struct Stamp(Option<u64>);

impl Stamp {
	pub(crate) fn now() -> Self {
		Self(clock(libc::CLOCK_MONOTONIC))
	}
}

pub(crate) struct Scope {
	phase: Phase,
	start: Stamp,
	cpu_start: Option<u64>,
	cpu_requested: bool,
	completed: bool,
}

impl Scope {
	pub(crate) fn wall(phase: Phase) -> Self {
		Self::from_stamp(phase, Stamp::now(), false, false)
	}

	pub(crate) fn thread(phase: Phase) -> Self {
		Self::from_stamp(phase, Stamp::now(), true, false)
	}

	pub(crate) fn lifetime(phase: Phase) -> Self {
		Self::from_stamp(phase, Stamp::now(), false, true)
	}

	fn from_stamp(phase: Phase, start: Stamp, cpu_requested: bool, completed: bool) -> Self {
		ledger().active.fetch_add(1, Ordering::Relaxed);
		Self {
			phase,
			start,
			cpu_start: cpu_requested
				.then(|| clock(libc::CLOCK_THREAD_CPUTIME_ID))
				.flatten(),
			cpu_requested,
			completed,
		}
	}

	pub(crate) fn finish(mut self) {
		self.completed = true;
	}
}

impl Drop for Scope {
	fn drop(&mut self) {
		let end = clock(libc::CLOCK_MONOTONIC);
		let elapsed = self
			.start
			.0
			.zip(end)
			.and_then(|(start, end)| end.checked_sub(start));
		let cpu = if self.cpu_requested {
			self.cpu_start
				.zip(clock(libc::CLOCK_THREAD_CPUTIME_ID))
				.and_then(|(start, end)| end.checked_sub(start))
		} else {
			None
		};
		let mut flags = if self.completed { COMPLETED } else { 0 };
		if cpu.is_some() {
			flags |= THREAD_CPU;
		}
		if elapsed.is_none() || self.cpu_requested && cpu.is_none() {
			flags |= CLOCK_ERROR;
		}
		let collector = ledger();
		collector.record(Event {
			s: self.start.0.unwrap_or(0),
			e: end.unwrap_or(0),
			c: cpu.unwrap_or(0),
			p: self.phase as u8,
			f: flags,
		});
		collector.active.fetch_sub(1, Ordering::Relaxed);
	}
}

pub(crate) fn elapsed(phase: Phase, start: Stamp) {
	Scope::from_stamp(phase, start, false, true).finish();
}

pub(crate) fn dump_after_cleanup() {
	let collector = ledger();
	let Ok(events) = collector.events.lock() else {
		// No complete final report means the diagnostic is invalid. Never
		// recover poisoned observations into a seemingly successful trace.
		return;
	};
	let active = collector.active.load(Ordering::Relaxed);
	let dropped = collector.dropped.load(Ordering::Relaxed);
	let aborted = collector.aborted.load(Ordering::Relaxed);
	let clock_errors = collector.clock_errors.load(Ordering::Relaxed);
	let poisoned = collector.poisoned.load(Ordering::Relaxed);
	#[derive(Serialize)]
	struct Report<'a> {
		schema: &'static str,
		diagnostic_only: bool,
		cleanup_confirmed: bool,
		complete_success_trace: bool,
		capacity: usize,
		allocated_event_bytes: usize,
		active_scopes: u64,
		dropped_events: u64,
		aborted_scopes: u64,
		clock_errors: u64,
		poisoned_writes: u64,
		phase_names: &'a [&'a str],
		events: &'a [Event],
	}
	let report = Report {
		schema: "hepta-observation-phase-diagnostic-v1",
		diagnostic_only: true,
		cleanup_confirmed: true,
		complete_success_trace: active == 0
			&& dropped == 0
			&& aborted == 0
			&& clock_errors == 0
			&& poisoned == 0,
		capacity: collector.capacity,
		allocated_event_bytes: events.capacity() * std::mem::size_of::<Event>(),
		active_scopes: active,
		dropped_events: dropped,
		aborted_scopes: aborted,
		clock_errors,
		poisoned_writes: poisoned,
		phase_names: &PHASE_NAMES,
		events: &events,
	};
	// The caller has already joined original owners and validated cleanup.
	// A streaming serialization avoids a second event vector/large String.
	// Missing/truncated output is rejected by the offline trace analyzer.
	let stderr = std::io::stderr();
	let mut writer = BufWriter::new(stderr.lock());
	if writer
		.write_all(b"HEPTA_OBSERVATION_DIAGNOSTICS_V1 ")
		.is_ok()
		&& serde_json::to_writer(&mut writer, &report).is_ok()
	{
		let _ = writer.write_all(b"\n");
		let _ = writer.flush();
	}
}

#[cfg(test)]
#[path = "ssh_observation_diagnostics_tests.rs"]
mod tests;
