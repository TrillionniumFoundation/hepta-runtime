// Copyright 2026 Muvon Un Limited
// Copyright 2026 TrillionniumFoundation
// SPDX-License-Identifier: Apache-2.0
//! Concrete recorder risks: overflow, incomplete scopes and concurrent writers.
use super::*;

fn event(flags: u8) -> Event {
	Event {
		s: 1,
		e: 2,
		c: 0,
		p: Phase::Capture as u8,
		f: flags,
	}
}

#[test]
fn overflow_preserves_first_records_and_reports_loss() {
	let ledger = Ledger::new(2);
	ledger.record(event(COMPLETED));
	ledger.record(event(COMPLETED));
	ledger.record(event(COMPLETED));
	assert_eq!(ledger.events.lock().unwrap().len(), 2);
	assert_eq!(ledger.dropped.load(Ordering::Relaxed), 1);
	assert_eq!(ledger.aborted.load(Ordering::Relaxed), 0);
	assert_eq!(ledger.clock_errors.load(Ordering::Relaxed), 0);
}

#[test]
fn incomplete_and_invalid_clock_events_cannot_look_complete() {
	let ledger = Ledger::new(3);
	ledger.record(event(0));
	ledger.record(event(COMPLETED | CLOCK_ERROR));
	ledger.record(event(COMPLETED | THREAD_CPU));
	assert_eq!(ledger.events.lock().unwrap().len(), 3);
	assert_eq!(ledger.aborted.load(Ordering::Relaxed), 1);
	assert_eq!(ledger.clock_errors.load(Ordering::Relaxed), 1);
}

#[test]
fn worker_and_owner_writers_keep_one_bounded_ledger() {
	let ledger = std::sync::Arc::new(Ledger::new(64));
	let mut threads = Vec::new();
	for _ in 0..3 {
		let ledger = ledger.clone();
		threads.push(std::thread::spawn(move || {
			for _ in 0..32 {
				ledger.record(event(COMPLETED));
			}
		}));
	}
	for thread in threads {
		thread.join().unwrap();
	}
	assert_eq!(ledger.events.lock().unwrap().len(), 64);
	assert_eq!(ledger.dropped.load(Ordering::Relaxed), 32);
	assert_eq!(ledger.poisoned.load(Ordering::Relaxed), 0);
}
