// Copyright 2026 Muvon Un Limited
// Copyright 2026 TrillionniumFoundation
// SPDX-License-Identifier: Apache-2.0
//! A separate, explicitly opted-in transport; it never falls back or replays.
#[path = "ssh_observation_diagnostics.rs"]
mod diagnostics;
#[path = "ssh_observation_postspawn.rs"]
mod postspawn;
#[path = "ssh_observation_profile.rs"]
mod profile;
#[path = "ssh_observation_validation.rs"]
mod validation;

use anyhow::{anyhow, bail, Context, Result};
use profile::{AgentIdentity, Profile, Stamp};
use ring::rand::{SecureRandom, SystemRandom};
use std::collections::{BTreeMap, VecDeque};
use std::fs::File;
use std::os::fd::{AsRawFd, FromRawFd, OwnedFd};
use std::os::unix::fs::MetadataExt;
use std::path::{Path, PathBuf};
use std::process::{ExitStatus, Output, Stdio};
use std::sync::atomic::{AtomicBool, AtomicU64, AtomicUsize, Ordering};
use std::sync::{Arc, Mutex, OnceLock};
use std::time::Duration;
use tokio::io::{AsyncReadExt, AsyncWriteExt};
use tokio::net::UnixStream;
use tokio::process::{Child, ChildStderr, Command};
use tokio::sync::{
	mpsc, oneshot, watch, Mutex as AsyncMutex, Notify, OwnedSemaphorePermit, Semaphore,
};
use tokio::task::JoinSet;
use tokio::time::{timeout, timeout_at, Instant};
use tokio_util::sync::CancellationToken;

const MAX_MASTERS: usize = 8;
const MAX_SESSIONS: usize = 8;
const HOST_SESSIONS: usize = 2;
const QUEUE: usize = 8;
// Same logical request bound as eight executing/retained outputs plus the
// original eight channel entries. Moving a waiter cannot create new capacity.
const MAX_ADMITTED: usize = MAX_SESSIONS + QUEUE;
const IDLE: Duration = Duration::from_secs(30);
const AGE: Duration = Duration::from_secs(120);
const START: Duration = Duration::from_secs(12);
const REAP: Duration = Duration::from_secs(3);
const STDERR_CAP: usize = 64 * 1024;
// OpenSSH publishes a ControlPath by first binding path + '.' + 16 random
// characters. Linux sun_path must also contain the terminating NUL byte.
const CONTROL_SOCKET_PATH_BYTES: usize = 108 - 17 - 1;
static POOL: OnceLock<Arc<Proxy>> = OnceLock::new();

fn check_control_socket_path(path: &Path) -> Result<()> {
	if path.as_os_str().as_encoded_bytes().len() > CONTROL_SOCKET_PATH_BYTES {
		bail!("observation socket path is too long for OpenSSH temporary publication");
	}
	Ok(())
}

// OpenSSH links its listening temporary socket to the final name before
// unlinking the temporary name. A two-link inode may still be publishing;
// retaining its full stamp would mistake the expected unlink for replacement.
// Only initial readiness waits here. Established-master checks stay exact.
async fn master_socket_readiness(socket: &Path, owned_pid: u32) -> Result<Option<Stamp>> {
	let Ok(stamp) = profile::socket_stamp(socket) else {
		return Ok(None);
	};
	match stamp.link_count() {
		1 => {}
		2 => return Ok(None),
		_ => bail!("observation control socket has unexpected link count"),
	}
	let stream = UnixStream::connect(socket).await?;
	let peer = profile::peer(&stream)?;
	if peer.0 != owned_pid as i32
		|| peer.1 != unsafe { libc::geteuid() }
		|| profile::socket_stamp(socket)? != stamp
	{
		bail!("observation control socket is not the owned master");
	}
	Ok(Some(stamp))
}

struct Request {
	_diagnostic_queued_at: diagnostics::Stamp,
	host: String,
	command: String,
	input: Vec<u8>,
	deadline: Instant,
	cancel: CancellationToken,
	reply: oneshot::Sender<Result<Captured>>,
	admission: Arc<OwnedSemaphorePermit>,
}

/// Capacity also covers completed output until its original caller parses it.
pub(super) struct Captured {
	_diagnostic_retention: diagnostics::Scope,
	output: Output,
	_budget: Arc<OwnedSemaphorePermit>,
	_admission: Arc<OwnedSemaphorePermit>,
}
impl std::ops::Deref for Captured {
	type Target = Output;
	fn deref(&self) -> &Output {
		&self.output
	}
}

struct Proxy {
	sender: mpsc::Sender<Request>,
	admission: Arc<Semaphore>,
	stop: CancellationToken,
	healthy: AtomicBool,
	thread: Mutex<Option<std::thread::JoinHandle<Result<()>>>>,
	// The process-wide proxy outlives a failed owner thread. Quarantined
	// original children and permits must not fall into implicit Drop cleanup.
	custody: Mutex<Option<Arc<Core>>>,
}

/// Drop freezes admission even if startup or the surrounding transport fails.
pub struct PoolGuard(Arc<Proxy>);
impl Drop for PoolGuard {
	fn drop(&mut self) {
		self.0.healthy.store(false, Ordering::Release);
		self.0.stop.cancel();
	}
}
impl PoolGuard {
	pub async fn shutdown(self) -> Result<()> {
		self.0.healthy.store(false, Ordering::Release);
		self.0.stop.cancel();
		let thread = self
			.0
			.thread
			.lock()
			.map_err(|_| anyhow!("observation pool thread unavailable"))?
			.take();
		if let Some(thread) = thread {
			// Only joining happens here; no SSH child is spawned by this worker.
			tokio::task::spawn_blocking(move || thread.join())
				.await
				.context("observation pool join unavailable")?
				.map_err(|_| anyhow!("observation pool owner thread failed"))??;
		}
		Ok(())
	}
}

pub(super) fn requested() -> bool {
	POOL.get().is_some()
}
pub(super) fn freeze() {
	if let Some(pool) = POOL.get() {
		pool.healthy.store(false, Ordering::Release);
		pool.stop.cancel();
	}
}

pub(super) async fn start(path: &Path) -> Result<PoolGuard> {
	if POOL.get().is_some() {
		bail!("observation pool already requested");
	}
	let profile = Arc::new(Profile::load(path)?);
	let root = PrivateRoot::create(&profile)?;
	let (sender, receiver) = mpsc::channel(QUEUE);
	let (ready_tx, ready_rx) = oneshot::channel();
	let proxy = Arc::new(Proxy {
		sender,
		admission: Arc::new(Semaphore::new(MAX_ADMITTED)),
		stop: CancellationToken::new(),
		healthy: AtomicBool::new(false),
		thread: Mutex::new(None),
		custody: Mutex::new(None),
	});
	let guard = PoolGuard(proxy.clone());
	// Publish the sole lifetime owner before its thread can create children.
	// A concurrent losing start must never create an unanchored quarantine.
	if POOL.set(proxy.clone()).is_err() {
		bail!("observation pool already requested");
	}
	let owner = proxy.clone();
	let thread = std::thread::Builder::new()
		.name("hepta-observation-ssh".into())
		.spawn(move || {
			let runtime = tokio::runtime::Builder::new_current_thread()
				.enable_all()
				.build()?;
			let core = Arc::new(Core {
				profile,
				validation: validation::Workers::new(),
				root,
				stop: owner.stop.clone(),
				agent: OnceLock::new(),
				children: AsyncMutex::new(BTreeMap::new()),
				masters: AsyncMutex::new(BTreeMap::new()),
				background: Mutex::new(JoinSet::new()),
				maintenance_changed: Notify::new(),
				sequence: AtomicU64::new(1),
				owner_tid: unsafe { libc::syscall(libc::SYS_gettid) },
			});
			// Register the lifetime ledger before initialization can spawn even
			// an effective-profile probe. Errors and unwinds retain this owner.
			*owner
				.custody
				.lock()
				.map_err(|_| anyhow!("observation original custody unavailable"))? = Some(core.clone());
			// Child ownership lives outside the fallible actor future. All spawning,
			// pipe I/O and waiting occurs on this nonretiring current-thread runtime.
			let outcome = std::panic::catch_unwind(std::panic::AssertUnwindSafe(|| {
				runtime.block_on(async {
					let initialized = core.initialize().await;
					if initialized.is_ok() {
						owner.healthy.store(true, Ordering::Release);
					}
					let accepted = ready_tx
						.send(initialized.map_err(|error| format!("{error:#}")))
						.is_ok();
					if !accepted || !owner.healthy.load(Ordering::Acquire) {
						return Ok(());
					}
					core.clone().run(receiver).await
				})
			}));
			owner.healthy.store(false, Ordering::Release);
			core.stop.cancel();
			let cleanup = runtime.block_on(core.shutdown());
			// Early cleanup errors must not let detached validation outlive its
			// authority owner. Retain the original cleanup/actor error precedence.
			let cleanup = runtime.block_on(core.validation.finish_shutdown(cleanup));
			if cleanup.is_ok() {
				let mut custody = owner
					.custody
					.lock()
					.map_err(|_| anyhow!("observation original custody unavailable"))?;
				if !custody
					.as_ref()
					.is_some_and(|original| Arc::ptr_eq(original, &core))
				{
					bail!("observation original custody identity differs");
				}
				// Only confirmed child/socket cleanup and validation completion
				// retire the ledger; successful shutdown retains no private root.
				*custody = None;
			}
			if cleanup.is_ok() {
				diagnostics::dump_after_cleanup();
			}
			match outcome {
				Ok(result) => {
					result?;
					cleanup
				}
				Err(_) => {
					cleanup?;
					bail!("observation pool owner failed; no request replayed")
				}
			}
		})?;
	*proxy
		.thread
		.lock()
		.map_err(|_| anyhow!("observation pool thread unavailable"))? = Some(thread);
	match ready_rx.await {
		Ok(Ok(())) => Ok(guard),
		Ok(Err(error)) => {
			guard.shutdown().await?;
			bail!("observation pool startup refused: {error}")
		}
		Err(_) => {
			guard.shutdown().await?;
			bail!("observation pool startup owner unavailable")
		}
	}
}

struct CancelOnDrop(CancellationToken);
impl Drop for CancelOnDrop {
	fn drop(&mut self) {
		self.0.cancel();
	}
}

// On this owner runtime, unwinding/drop finishes before any awakened waiter
// can be polled. A failed already-spawned supervisor therefore freezes child
// admission even before the actor observes its JoinError.
struct StopUnlessCompleted {
	stop: CancellationToken,
	completed: bool,
}
impl StopUnlessCompleted {
	fn complete(mut self) {
		self.completed = true;
	}
}
impl Drop for StopUnlessCompleted {
	fn drop(&mut self) {
		if !self.completed {
			self.stop.cancel();
		}
	}
}

pub(super) async fn capture(
	host: &str,
	command: String,
	input: Vec<u8>,
	duration: Duration,
) -> Result<Captured> {
	super::validate_observation_bytes(&command, &input)?;
	let pool = POOL.get().context("observation pool was not requested")?;
	if !pool.healthy.load(Ordering::Acquire) || pool.stop.is_cancelled() {
		bail!("observation pool unavailable; no fallback or automatic retry");
	}
	let deadline = Instant::now() + duration;
	let cancel = CancellationToken::new();
	let _guard = CancelOnDrop(cancel.clone());
	let (reply, receive) = oneshot::channel();
	pool.enqueue(host, command, input, deadline, cancel, reply)
		.await?;
	timeout_at(deadline, receive)
		.await
		.context("observation transport deadline; no automatic retry")?
		.context("observation transport unavailable; no automatic retry")?
}

impl Proxy {
	async fn enqueue(
		&self,
		host: &str,
		command: String,
		input: Vec<u8>,
		deadline: Instant,
		cancel: CancellationToken,
		reply: oneshot::Sender<Result<Captured>>,
	) -> Result<()> {
		let admission = self.admission.clone().try_acquire_owned().map_err(|_| {
			anyhow!("observation pool capacity unavailable; no fallback or automatic retry")
		})?;
		let request = Request {
			_diagnostic_queued_at: diagnostics::Stamp::now(),
			host: host.to_owned(),
			command,
			input,
			deadline,
			cancel,
			reply,
			admission: Arc::new(admission),
		};
		// A channel waiter already owns one of the same sixteen identities.
		// Wait within its original deadline; do not enlarge the channel or retry.
		let diagnostic_wait = diagnostics::Scope::wall(diagnostics::Phase::ChannelWait);
		let slot = tokio::select! {
			value = timeout_at(deadline, self.sender.reserve()) => value
				.context("observation queue admission deadline; no automatic retry")?
				.context("observation queue closed; no fallback or automatic retry")?,
			_ = request.cancel.cancelled() => bail!("observation cancelled before queue submission; no automatic retry"),
			_ = self.stop.cancelled() => bail!("observation pool stopped before queue submission; no automatic retry"),
		};
		diagnostic_wait.finish();
		// Capacity, shutdown and expiry may become ready together. Recheck after
		// reservation and leave no await between these fences and the single send.
		if !self.healthy.load(Ordering::Acquire)
			|| self.stop.is_cancelled()
			|| request.cancel.is_cancelled()
			|| Instant::now() >= deadline
			|| self.sender.is_closed()
		{
			bail!("observation cancelled, expired or unavailable before queue submission; no automatic retry");
		}
		slot.send(request);
		Ok(())
	}
}

struct PrivateRoot {
	path: PathBuf,
	directory: File,
	identity: Stamp,
	parent: Stamp,
}
impl Drop for PrivateRoot {
	fn drop(&mut self) {
		if profile::private_directory(&self.path)
			.ok()
			.is_some_and(|stamp| stamp.same_directory(&self.identity))
			&& self
				.directory
				.metadata()
				.ok()
				.is_some_and(|info| self.identity.same_directory(&Stamp::of(&info)))
			&& self
				.path
				.parent()
				.and_then(|parent| profile::private_directory(parent).ok())
				.is_some_and(|stamp| stamp.same_directory(&self.parent))
		{
			// Only an empty pinned root may be removed on an early error.
			let _ = std::fs::remove_dir(&self.path);
		}
	}
}
impl PrivateRoot {
	fn create(profile: &Profile) -> Result<Self> {
		profile.verify_files()?;
		let parent = profile::open_absolute(&profile.socket_parent, true)?;
		let mut random = [0u8; 16];
		SystemRandom::new()
			.fill(&mut random)
			.map_err(|_| anyhow!("observation socket entropy unavailable"))?;
		let name = format!(
			"hp-o-{}-{}",
			std::process::id(),
			random
				.iter()
				.map(|v| format!("{v:02x}"))
				.collect::<String>()
		);
		let path = profile.socket_parent.join(&name);
		// Reject an unusable parent before creating any private root. Subsequent
		// generations are checked again with their complete sequence number.
		check_control_socket_path(&path.join("m-1"))?;
		let component = std::ffi::CString::new(name)?;
		if unsafe { libc::mkdirat(parent.as_raw_fd(), component.as_ptr(), 0o700) } != 0 {
			return Err(std::io::Error::last_os_error().into());
		}
		// Until an inode is pinned, failure leaves the unpredictable empty name
		// for explicit reconciliation instead of deleting an uncertain path.
		let directory = profile::open_absolute(&path, true).with_context(|| {
			format!(
				"observation private root identity unavailable at {}; reconciliation required",
				path.display()
			)
		})?;
		let identity = Stamp::of(
			&directory
				.metadata()
				.context("observation private root stamp unavailable; reconciliation required")?,
		);
		let root = Self {
			path,
			directory,
			identity,
			parent: profile.parent_stamp.clone(),
		};
		root.verify(profile)?;
		Ok(root)
	}
	fn verify(&self, profile: &Profile) -> Result<()> {
		if !self
			.identity
			.same_directory(&Stamp::of(&self.directory.metadata()?))
			|| !self
				.identity
				.same_directory(&profile::private_directory(&self.path)?)
			|| !self
				.parent
				.same_directory(&profile::private_directory(&profile.socket_parent)?)
		{
			bail!("observation private socket root changed");
		}
		Ok(())
	}
}

#[derive(Clone, Debug, PartialEq, Eq)]
struct ProcessIdentity {
	birth: u64,
	uid: u32,
	dev: u64,
	ino: u64,
	argv: Vec<u8>,
}
fn process_identity(pid: u32) -> Result<ProcessIdentity> {
	let root = PathBuf::from(format!("/proc/{pid}"));
	let status = std::fs::read_to_string(root.join("stat"))?;
	let tail = status
		.rsplit_once(')')
		.context("observation child stat unavailable")?
		.1;
	let birth = tail
		.split_ascii_whitespace()
		.nth(19)
		.context("observation child birth unavailable")?
		.parse()?;
	let exe = std::fs::metadata(root.join("exe"))?;
	Ok(ProcessIdentity {
		birth,
		uid: std::fs::metadata(&root)?.uid(),
		dev: exe.dev(),
		ino: exe.ino(),
		argv: std::fs::read(root.join("cmdline"))?,
	})
}

enum ChildLiveness {
	Live,
	Terminal,
}

struct OwnedChild {
	id: u64,
	pid: u32,
	pidfd: Option<OwnedFd>,
	identity: OnceLock<ProcessIdentity>,
	approved: AtomicBool,
	child: AsyncMutex<Child>,
	// Registry ownership keeps capacity charged through timeout/cancellation
	// until wait/reap proves that this exact child has terminated.
	_permits: Vec<Arc<OwnedSemaphorePermit>>,
}
impl OwnedChild {
	fn signal(&self, signal: i32) -> Result<()> {
		let pidfd = self
			.pidfd
			.as_ref()
			.context("observation child pidfd unavailable")?;
		if self
			.identity
			.get()
			.is_none_or(|expected| process_identity(self.pid).ok().as_ref() != Some(expected))
		{
			bail!("observation child identity unavailable; refusing guessed signal");
		}
		if unsafe {
			libc::syscall(
				libc::SYS_pidfd_send_signal,
				pidfd.as_raw_fd(),
				signal,
				std::ptr::null::<libc::siginfo_t>(),
				0,
			)
		} < 0 && std::io::Error::last_os_error().raw_os_error() != Some(libc::ESRCH)
		{
			return Err(std::io::Error::last_os_error().into());
		}
		Ok(())
	}
	async fn wait(&self) -> Result<ExitStatus> {
		Ok(self.child.lock().await.wait().await?)
	}
	async fn terminal(&self) -> Result<bool> {
		Ok(self.child.lock().await.try_wait()?.is_some())
	}
	async fn liveness(&self) -> Result<ChildLiveness> {
		let mut child = self.child.lock().await;
		if child.try_wait()?.is_some() {
			return Ok(ChildLiveness::Terminal);
		}
		if self
			.identity
			.get()
			.is_none_or(|v| process_identity(self.pid).ok().as_ref() != Some(v))
		{
			bail!("observation SSH child identity changed");
		}
		Ok(ChildLiveness::Live)
	}
	async fn verify_live(&self) -> Result<()> {
		if matches!(self.liveness().await?, ChildLiveness::Terminal) {
			bail!("observation SSH child exited");
		}
		Ok(())
	}
	async fn stop(&self, grace: Duration) -> Result<()> {
		let mut child = self.child.lock().await;
		if child.try_wait()?.is_some() {
			return Ok(());
		}
		if !self.approved.load(Ordering::Acquire) {
			// The original unreaped Child is safe to stop even when pidfd or
			// post-exec proof failed. No caller supplies this process handle.
			child.start_kill()?;
			timeout(REAP, child.wait()).await.context(
				"unapproved observation child reap unavailable; reconciliation required",
			)??;
			return Ok(());
		}
		if !grace.is_zero() {
			if let Err(error) = self.signal(libc::SIGTERM) {
				if child.try_wait()?.is_some() {
					return Ok(());
				}
				return Err(error);
			}
			if let Ok(result) = timeout(grace, child.wait()).await {
				result?;
				return Ok(());
			}
		}
		if child.try_wait()?.is_some() {
			return Ok(());
		}
		if let Err(error) = self.signal(libc::SIGKILL) {
			if child.try_wait()?.is_some() {
				return Ok(());
			}
			return Err(error);
		}
		timeout(REAP, child.wait())
			.await
			.context("observation child reap unavailable; reconciliation required")??;
		Ok(())
	}
}

type Ready = Option<std::result::Result<Arc<Master>, String>>;
#[derive(Clone)]
struct Entry {
	ready: watch::Receiver<Ready>,
	permits: Arc<Semaphore>,
	generation: u64,
	ready_deadline: Instant,
	// Preserve the exact old socket proof outside the fallible renewal task.
	draining: Option<Arc<Master>>,
}
struct Master {
	owned: Arc<OwnedChild>,
	socket: PathBuf,
	stamp: Stamp,
	created: Instant,
	last_use: Mutex<Instant>,
	active: AtomicUsize,
	accepting: AtomicBool,
	// Maintenance and renewal retain one original cleanup result. They never
	// repeat a failed reap or unlink merely because a different waiter arrived.
	retirement: AsyncMutex<Option<std::result::Result<(), String>>>,
}
struct ActiveMaster(Arc<Master>);
impl Drop for ActiveMaster {
	fn drop(&mut self) {
		if let Ok(mut last) = self.0.last_use.lock() {
			*last = Instant::now();
		}
		self.0.active.fetch_sub(1, Ordering::AcqRel);
	}
}

struct Core {
	profile: Arc<Profile>,
	validation: validation::Workers,
	root: PrivateRoot,
	stop: CancellationToken,
	agent: OnceLock<AgentIdentity>,
	children: AsyncMutex<BTreeMap<u64, Arc<OwnedChild>>>,
	masters: AsyncMutex<BTreeMap<String, Entry>>,
	background: Mutex<JoinSet<Result<()>>>,
	maintenance_changed: Notify,
	sequence: AtomicU64,
	owner_tid: libc::c_long,
}

#[derive(Clone, Copy)]
enum Mode {
	Master,
	Slave,
}

enum ProfileCheckScope {
	Lifecycle,
	Request,
}

impl Core {
	async fn initialize(self: &Arc<Self>) -> Result<()> {
		self.profile.verify_files()?;
		self.root.verify(&self.profile)?;
		let agent =
			profile::agent_snapshot(&self.profile.agent, Instant::now() + Duration::from_secs(5))
				.await?;
		self.agent
			.set(agent)
			.map_err(|_| anyhow!("observation agent already bound"))?;
		let deadline = Instant::now() + Duration::from_secs(30);
		self.verify_profile(deadline).await?;
		let socket = self.root.path.join("effective-check");
		for host in self.profile.hosts.keys() {
			self.effective(host, Mode::Master, &socket, deadline)
				.await?;
			self.effective(host, Mode::Slave, &socket, deadline).await?;
		}
		self.verify_profile(deadline).await
	}
	async fn verify_profile(&self, deadline: Instant) -> Result<()> {
		// Initialization and master generations keep the original all-error
		// freeze. A failed generation must not be retired past a stale RPC that
		// has not observed its watch result, allowing that RPC to create another.
		self.verify_profile_for(deadline, ProfileCheckScope::Lifecycle)
			.await
	}
	async fn verify_request_profile(&self, deadline: Instant) -> Result<()> {
		self.verify_profile_for(deadline, ProfileCheckScope::Request)
			.await
	}
	async fn verify_files(&self, deadline: Instant) -> Result<()> {
		let profile = self.profile.clone();
		let ticket = self
			.validation
			.run_retained(&self.stop, deadline, move |ticket| {
				profile.verify_files_checked(&|| ticket.check_current())
			})
			.await?;
		// A same-length change can retain every timestamp/metadata field. Keep
		// the original permit through a second fresh complete read on the owner;
		// metadata-only acceptance after the await is not content validation.
		ticket.finish(|ticket| {
			if unsafe { libc::syscall(libc::SYS_gettid) } != self.owner_tid {
				bail!("observation file acceptance attempted outside its lifetime owner thread");
			}
			let diagnostic_read = diagnostics::Scope::thread(diagnostics::Phase::OwnerRead);
			self.profile
				.verify_files_checked(&|| ticket.check_current())?;
			diagnostic_read.finish();
			let diagnostic_boundary =
				diagnostics::Scope::thread(diagnostics::Phase::OwnerBoundaries);
			self.profile.verify_boundaries(&|| ticket.check_current())?;
			diagnostic_boundary.finish();
			if self.stop.is_cancelled() || Instant::now() >= deadline {
				bail!("observation file validation cancelled or expired before acceptance");
			}
			Ok(())
		})
	}
	async fn verify_profile_for(&self, deadline: Instant, scope: ProfileCheckScope) -> Result<()> {
		let checked: Result<()> = async {
			let diagnostic_before = diagnostics::Scope::wall(diagnostics::Phase::ProfileBeforeAgent);
			self.verify_files(deadline).await?;
			diagnostic_before.finish();
			self.root.verify(&self.profile)?;
			let diagnostic_agent = diagnostics::Scope::wall(diagnostics::Phase::Agent);
			let agent = tokio::select! {
				value = profile::agent_snapshot(&self.profile.agent, deadline.min(Instant::now() + Duration::from_secs(2))) => value?,
				_ = self.stop.cancelled() => bail!("observation profile check stopped"),
			};
			diagnostic_agent.finish();
			if self.agent.get() != Some(&agent) {
				bail!("observation SSH credential identity changed");
			}
			let diagnostic_after = diagnostics::Scope::wall(diagnostics::Phase::ProfileAfterAgent);
			self.verify_files(deadline).await?;
			diagnostic_after.finish();
			Ok(())
		}
		.await;
		// A lookup timer grants no authority: its caller still returns Err and
		// discards any output. Other requests must perform their own complete
		// checks; no credential result is substituted or automatically retried.
		// Every observed mismatch, I/O error and other failure still freezes us.
		if checked.as_ref().is_err_and(|error| match scope {
			ProfileCheckScope::Lifecycle => true,
			ProfileCheckScope::Request => !error.is::<profile::AgentLookupDeadline>(),
		}) {
			self.stop.cancel();
		}
		checked
	}
	fn arguments(
		&self,
		host: &str,
		mode: Mode,
		socket: &Path,
		effective: bool,
	) -> Result<Vec<String>> {
		let target = self
			.profile
			.hosts
			.get(host)
			.context("host is outside observation profile")?;
		let mut args = vec![
			"/usr/bin/ssh".to_owned(),
			"-F".into(),
			self.profile.config.to_string_lossy().into_owned(),
		];
		if effective {
			args.push("-G".into());
		}
		args.push("-T".into());
		let mut options: Vec<(String, String)> = vec![
			("BatchMode", "yes"),
			("ConnectTimeout", "8"),
			("ConnectionAttempts", "1"),
			("StrictHostKeyChecking", "yes"),
			("ForwardAgent", "no"),
			("ForwardX11", "no"),
			("ClearAllForwardings", "yes"),
			("PermitLocalCommand", "no"),
			("RemoteCommand", "none"),
			("ForkAfterAuthentication", "no"),
			("ControlPersist", "no"),
			("ProxyJump", "none"),
			("ProxyUseFdpass", "no"),
			("IdentityFile", "none"),
			("CertificateFile", "none"),
			("PreferredAuthentications", "publickey"),
			("PubkeyAuthentication", "yes"),
			("PasswordAuthentication", "no"),
			("KbdInteractiveAuthentication", "no"),
			("GSSAPIAuthentication", "no"),
			("HostbasedAuthentication", "no"),
			("PKCS11Provider", "none"),
			("SecurityKeyProvider", "internal"),
			("AddKeysToAgent", "no"),
			("UpdateHostKeys", "no"),
			("KnownHostsCommand", "none"),
			("VerifyHostKeyDNS", "no"),
			("CheckHostIP", "no"),
			("CanonicalizeHostname", "no"),
			("GlobalKnownHostsFile", "/dev/null"),
		]
		.into_iter()
		.map(|(key, value)| (key.to_owned(), value.to_owned()))
		.collect();
		options.extend([
			(
				"IdentityAgent".into(),
				self.profile.agent.to_string_lossy().into_owned(),
			),
			(
				"UserKnownHostsFile".into(),
				self.profile.known_hosts.to_string_lossy().into_owned(),
			),
			("ControlPath".into(), socket.to_string_lossy().into_owned()),
			(
				"ControlMaster".into(),
				if matches!(mode, Mode::Master) {
					"yes"
				} else {
					"no"
				}
				.into(),
			),
			(
				"ProxyCommand".into(),
				if matches!(mode, Mode::Slave) {
					"/usr/bin/false"
				} else {
					"none"
				}
				.into(),
			),
		]);
		for (key, value) in options {
			args.extend(["-o".into(), format!("{key}={value}")]);
		}
		if matches!(mode, Mode::Master) {
			args.extend(["-N".into(), "-n".into()]);
		}
		args.extend(["--".into(), target.clone()]);
		Ok(args)
	}
	fn command(&self, args: &[String]) -> Command {
		let mut command = Command::new("/usr/bin/ssh");
		command
			.args(&args[1..])
			.env_clear()
			.env("PATH", "/usr/bin:/bin")
			.env("LANG", "C")
			.env("SHELL", "/bin/sh")
			.env("SSH_AUTH_SOCK", &self.profile.agent)
			.kill_on_drop(true);
		let controller = unsafe { libc::getpid() };
		// No allocation, formatting, locks, environment lookup or Rust error
		// construction is permitted after fork in this multithreaded process.
		unsafe {
			command.pre_exec(move || {
				if libc::prctl(
					libc::PR_SET_PDEATHSIG,
					libc::SIGKILL as libc::c_ulong,
					0 as libc::c_ulong,
					0 as libc::c_ulong,
					0 as libc::c_ulong,
				) != 0 || libc::getppid() != controller
				{
					libc::_exit(127);
				}
				Ok(())
			});
		}
		command
	}
	async fn spawn(
		&self,
		args: &[String],
		mut command: Command,
		permits: Vec<Arc<OwnedSemaphorePermit>>,
		deadline: Instant,
		cancel: &CancellationToken,
	) -> Result<Arc<OwnedChild>> {
		if unsafe { libc::syscall(libc::SYS_gettid) } != self.owner_tid {
			bail!("observation child spawn attempted outside its lifetime owner thread");
		}
		let expected = args
			.iter()
			.flat_map(|arg| arg.as_bytes().iter().copied().chain([0]))
			.collect::<Vec<_>>();
		let mut children = tokio::select! {
			value = timeout_at(deadline, self.children.lock()) => value.context("observation child admission deadline")?,
			_ = cancel.cancelled() => bail!("observation cancelled before child creation"),
			_ = self.stop.cancelled() => bail!("observation pool stopped before child creation"),
		};
		if cancel.is_cancelled() || self.stop.is_cancelled() || Instant::now() >= deadline {
			bail!("observation cancelled or expired before child creation");
		}
		let child = command
			.spawn()
			.context("observation SSH spawn unavailable")?;
		let pid = child.id().unwrap_or(0);
		let fd = if pid == 0 {
			-1
		} else {
			unsafe { libc::syscall(libc::SYS_pidfd_open, pid, 0) }
		};
		let pidfd = if fd < 0 {
			None
		} else {
			Some(unsafe { OwnedFd::from_raw_fd(fd as i32) })
		};
		let id = self.sequence.fetch_add(1, Ordering::Relaxed);
		let owned = Arc::new(OwnedChild {
			id,
			pid,
			pidfd,
			identity: OnceLock::new(),
			approved: AtomicBool::new(false),
			child: AsyncMutex::new(child),
			_permits: permits,
		});
		// Register the original Child before fallible post-exec proof or waiting.
		// Failed pidfd/identity checks use the same bounded cleanup ledger.
		children.insert(id, owned.clone());
		drop(children);
		// The child has not escaped spawn; shutdown joins owner work before
		// reaping its ledger. Keep every proc read and try_wait under the same
		// Child lock used by wait/stop, including the initial observation.
		let (mut identity, mut terminal) = {
			let mut child = owned.child.lock().await;
			let identity = process_identity(pid).ok();
			let terminal = child
				.try_wait()
				.map(|status| status.is_some())
				.map_err(anyhow::Error::from);
			(identity, terminal)
		};
		if owned.pidfd.is_some() && terminal.as_ref().is_ok_and(|done| !*done) {
			if let Some(anchor) = identity.as_ref().filter(|value| {
				value.argv.is_empty()
					&& value.uid == unsafe { libc::geteuid() }
					&& (value.dev, value.ino) == self.profile.ssh_inode
			}) {
				match postspawn::wait_empty_argv(
					&owned,
					anchor,
					&expected,
					self.profile.ssh_inode,
					deadline,
					cancel,
					&self.stop,
				)
				.await
				{
					Ok(ready) => {
						identity = ready.identity;
						terminal = Ok(ready.terminal);
					}
					Err(error) => {
						identity = None;
						terminal = Err(error);
					}
				}
			}
		}
		let matches = identity.as_ref().is_some_and(|value| {
			value.uid == unsafe { libc::geteuid() }
				&& (value.dev, value.ino) == self.profile.ssh_inode
				&& value.argv == expected
		});
		// An empty snapshot must not occupy OnceLock before readiness resolves.
		if let Some(identity) = identity {
			let _ = owned.identity.set(identity);
		}
		let proof = owned.pidfd.is_some() && terminal.as_ref().is_ok_and(|done| *done || matches);
		if !proof {
			self.stop.cancel();
			self.stop_child(&owned, Duration::ZERO)
				.await
				.context("observation early child proof failed; cleanup uncertain")?;
			self.release(&owned).await?;
			bail!("observation SSH pidfd or post-exec identity refused; no fallback");
		}
		owned.approved.store(matches, Ordering::Release);
		Ok(owned)
	}

	async fn release(&self, child: &Arc<OwnedChild>) -> Result<()> {
		if !matches!(child.terminal().await, Ok(true)) {
			self.stop.cancel();
			bail!("observation child is not reaped; reconciliation required");
		}
		self.children.lock().await.remove(&child.id);
		Ok(())
	}
	async fn stop_child(&self, child: &Arc<OwnedChild>, grace: Duration) -> Result<()> {
		let result = child.stop(grace).await;
		if result.is_err() {
			self.stop.cancel();
		}
		result
	}
	async fn captured(
		&self,
		args: Vec<String>,
		input: &[u8],
		deadline: Instant,
		cancel: &CancellationToken,
		permits: Vec<Arc<OwnedSemaphorePermit>>,
	) -> Result<Output> {
		let mut command = self.command(&args);
		command
			.stdin(Stdio::piped())
			.stdout(Stdio::piped())
			.stderr(Stdio::piped());
		let owned = self
			.spawn(&args, command, permits, deadline, cancel)
			.await?;
		let pipes = {
			let mut child = owned.child.lock().await;
			(child.stdin.take(), child.stdout.take(), child.stderr.take())
		};
		let outcome = async {
			let mut stdin = pipes.0.context("observation SSH stdin unavailable")?;
			let stdout = pipes.1.context("observation SSH stdout unavailable")?;
			let stderr = pipes.2.context("observation SSH stderr unavailable")?;
			let io = async {
				let write = async { stdin.write_all(input).await?; stdin.shutdown().await?; drop(stdin); Ok::<(), anyhow::Error>(()) };
				let (_, stdout, stderr, status) = tokio::try_join!(write, super::read_bounded(stdout), super::read_bounded(stderr), owned.wait())?;
				Ok::<_, anyhow::Error>(Output { status, stdout, stderr })
			};
			tokio::select! {
				value = timeout_at(deadline, io) => value.context("observation SSH deadline; no automatic retry")?,
				_ = cancel.cancelled() => Err(anyhow!("observation SSH cancelled; no automatic retry")),
				_ = self.stop.cancelled() => Err(anyhow!("observation pool stopped; no automatic retry")),
			}
		}.await;
		if outcome.is_err() {
			self.stop_child(&owned, Duration::ZERO).await?;
		}
		self.release(&owned).await?;
		outcome
	}
	async fn effective(
		&self,
		host: &str,
		mode: Mode,
		socket: &Path,
		deadline: Instant,
	) -> Result<()> {
		let args = self.arguments(host, mode, socket, true)?;
		let result = self
			.captured(args, &[], deadline, &self.stop, vec![])
			.await?;
		if !result.status.success()
			|| result.stdout.len() > 256 * 1024
			|| result.stderr.len() > 4096
		{
			bail!("observation SSH effective guards unavailable");
		}
		let mut fields = BTreeMap::new();
		for line in std::str::from_utf8(&result.stdout)?.lines() {
			if let Some((key, value)) = line.split_once(' ') {
				if fields.insert(key, value).is_some()
					&& matches!(key, "identityfile" | "certificatefile")
				{
					bail!("observation SSH default credentials are not closed");
				}
			}
		}
		let value = |key: &str| fields.get(key).copied().unwrap_or_default();
		for key in [
			"forwardagent",
			"forwardx11",
			"permitlocalcommand",
			"forkafterauthentication",
			"controlpersist",
			"proxyusefdpass",
			"passwordauthentication",
			"kbdinteractiveauthentication",
			"gssapiauthentication",
			"hostbasedauthentication",
			"addkeystoagent",
			"updatehostkeys",
			"verifyhostkeydns",
			"checkhostip",
			"canonicalizehostname",
		] {
			if !matches!(value(key), "no" | "false") {
				bail!("observation SSH disabled guard is not effective");
			}
		}
		for key in [
			"batchmode",
			"stricthostkeychecking",
			"clearallforwardings",
			"pubkeyauthentication",
		] {
			if !matches!(value(key), "yes" | "true") {
				bail!("observation SSH required guard is not effective");
			}
		}
		for key in ["identityfile", "certificatefile"] {
			if value(key) != "none" {
				bail!("observation SSH undeclared credential/provider");
			}
		}
		// OpenSSH omits NULL-valued provider/command fields in -G output.
		// The explicit argv options are still required; empty is accepted
		// only for these known none representations, never credential lists.
		for key in ["pkcs11provider", "knownhostscommand"] {
			if !matches!(value(key), "none" | "") {
				bail!("observation SSH undeclared credential/provider");
			}
		}
		if value("preferredauthentications") != "publickey"
			|| value("securitykeyprovider") != "internal"
			|| value("identityagent") != self.profile.agent.to_str().unwrap_or_default()
			|| value("userknownhostsfile") != self.profile.known_hosts.to_str().unwrap_or_default()
			|| value("globalknownhostsfile") != "/dev/null"
			|| value("controlpath") != socket.to_str().unwrap_or_default()
			|| (matches!(mode, Mode::Slave) && value("proxycommand") != "/usr/bin/false")
			|| (matches!(mode, Mode::Master) && !matches!(value("proxycommand"), "none" | ""))
			|| !matches!(
				(mode, value("controlmaster")),
				(Mode::Master, "yes" | "true") | (Mode::Slave, "no" | "false")
			) || !matches!(value("remotecommand"), "none" | "")
		{
			bail!("observation SSH effective profile differs");
		}
		Ok(())
	}
	fn background(
		self: &Arc<Self>,
		work: impl std::future::Future<Output = Result<()>> + Send + 'static,
	) -> Result<()> {
		let mut tasks = self
			.background
			.lock()
			.map_err(|_| anyhow!("observation supervisor unavailable"))?;
		if tasks.len() >= MAX_MASTERS * 4 {
			bail!("observation supervisor bound exceeded");
		}
		tasks.spawn(work);
		// The actor may have no master or supervisor left to poll. Retain the
		// wakeup even when its previous maintenance result is still in flight.
		self.maintenance_changed.notify_one();
		Ok(())
	}
	async fn start_master(
		self: &Arc<Self>,
		host: String,
		socket: PathBuf,
		deadline: Instant,
	) -> Result<Arc<Master>> {
		self.verify_profile(deadline).await?;
		self.effective(&host, Mode::Master, &socket, deadline)
			.await?;
		self.effective(&host, Mode::Slave, &socket, deadline)
			.await?;
		if std::fs::symlink_metadata(&socket).is_ok() {
			bail!("observation socket already exists; never adopt");
		}
		let args = self.arguments(&host, Mode::Master, &socket, false)?;
		let mut command = self.command(&args);
		command
			.stdin(Stdio::null())
			.stdout(Stdio::null())
			.stderr(Stdio::piped());
		let created = Instant::now();
		let owned = self
			.spawn(&args, command, vec![], deadline, &self.stop)
			.await?;
		let stderr = owned.child.lock().await.stderr.take();
		let Some(stderr) = stderr else {
			self.stop_child(&owned, Duration::ZERO).await?;
			self.release(&owned).await?;
			bail!("master stderr unavailable");
		};
		let core = self.clone();
		if let Err(error) = self.background(async move { core.drain_master(stderr).await }) {
			self.stop_child(&owned, Duration::ZERO).await?;
			self.release(&owned).await?;
			return Err(error);
		}
		let readiness = async {
			loop {
				owned.verify_live().await?;
				if let Some(stamp) = master_socket_readiness(&socket, owned.pid).await? {
					return Ok(stamp);
				}
				tokio::time::sleep(Duration::from_millis(20)).await;
			}
		};
		let result = tokio::select! {
			value = timeout_at(deadline, readiness) => value.unwrap_or_else(|_| Err(anyhow!("observation master startup deadline"))),
			_ = self.stop.cancelled() => Err(anyhow!("observation master startup stopped")),
		};
		match result {
			Ok(stamp) => Ok(Arc::new(Master {
				owned,
				socket,
				stamp,
				created,
				last_use: Mutex::new(Instant::now()),
				active: AtomicUsize::new(0),
				accepting: AtomicBool::new(true),
				retirement: AsyncMutex::new(None),
			})),
			Err(error) => {
				self.stop_child(&owned, Duration::ZERO).await?;
				self.release(&owned).await?;
				Err(error)
			}
		}
	}
	async fn drain_master(&self, mut stderr: ChildStderr) -> Result<()> {
		let mut bytes = 0usize;
		let mut buffer = [0; 4096];
		loop {
			tokio::select! {
				_ = self.stop.cancelled() => return Ok(()),
				value = stderr.read(&mut buffer) => {
					let read = value?;
					if read == 0 { return Ok(()); }
					bytes = bytes.checked_add(read).context("observation master stderr overflow")?;
					if bytes > STDERR_CAP { self.stop.cancel(); bail!("observation master stderr bound exceeded"); }
				}
			}
		}
	}
	async fn entry(
		self: &Arc<Self>,
		host: &str,
		cancel: &CancellationToken,
		deadline: Instant,
	) -> Result<Entry> {
		let mut entries = tokio::select! {
			value = timeout_at(deadline, self.masters.lock()) => value.context("observation master admission deadline")?,
			_ = cancel.cancelled() => bail!("observation cancelled before master admission"),
			_ = self.stop.cancelled() => bail!("observation pool stopped before master admission"),
		};
		if cancel.is_cancelled() || self.stop.is_cancelled() || Instant::now() >= deadline {
			bail!("observation cancelled or expired before master admission");
		}
		if !entries.contains_key(host) {
			if entries.len() >= MAX_MASTERS {
				bail!("observation master capacity unavailable");
			}
			let socket = self.root.path.join(format!(
				"m-{}",
				self.sequence.fetch_add(1, Ordering::Relaxed)
			));
			check_control_socket_path(&socket)?;
			let (send, receive) = watch::channel(None);
			let generation = self.sequence.fetch_add(1, Ordering::Relaxed);
			let ready_deadline = Instant::now() + START + REAP;
			let core = self.clone();
			let name = host.to_owned();
			let start_deadline = deadline.min(Instant::now() + START);
			self.background(async move {
				let value = core
					.start_master(name, socket, start_deadline)
					.await
					.map_err(|error| format!("{error:#}"));
				let _ = send.send(Some(value));
				Ok(())
			})?;
			entries.insert(
				host.to_owned(),
				Entry {
					ready: receive,
					permits: Arc::new(Semaphore::new(HOST_SESSIONS)),
					generation,
					ready_deadline,
					draining: None,
				},
			);
		}
		let entry = entries
			.get(host)
			.context("observation master unavailable")?;
		Ok(Entry {
			ready: entry.ready.clone(),
			permits: entry.permits.clone(),
			generation: entry.generation,
			ready_deadline: entry.ready_deadline,
			draining: entry.draining.clone(),
		})
	}
	async fn renew(
		self: &Arc<Self>,
		host: &str,
		generation: u64,
		old: &Arc<Master>,
		deadline: Instant,
		cancel: &CancellationToken,
	) -> Result<()> {
		let mut entries = tokio::select! {
			value = timeout_at(deadline, self.masters.lock()) => value.context("observation renewal admission deadline")?,
			_ = cancel.cancelled() => bail!("observation cancelled before renewal"),
			_ = self.stop.cancelled() => bail!("observation pool stopped before renewal"),
		};
		if cancel.is_cancelled() || self.stop.is_cancelled() || Instant::now() >= deadline {
			bail!("observation cancelled or expired before renewal");
		}
		let Some(entry) = entries.get_mut(host) else {
			return Ok(());
		};
		let current = { entry.ready.borrow().clone() };
		if entry.generation != generation
			|| !matches!(current, Some(Ok(ref master)) if Arc::ptr_eq(master, old))
		{
			// An old waiter joins the installed generation; it cannot replace it.
			return Ok(());
		}
		old.accepting.store(false, Ordering::Release);
		let (send, receive) = watch::channel(None);
		let next = self.sequence.fetch_add(1, Ordering::Relaxed);
		// Shared lifecycle ownership does not extend any waiter's RPC deadline.
		let ready_deadline = Instant::now().max(old.created + AGE) + REAP + REAP + START;
		entry.ready = receive;
		entry.generation = next;
		entry.ready_deadline = ready_deadline;
		entry.draining = Some(old.clone());
		let core = self.clone();
		let name = host.to_owned();
		let previous = old.clone();
		if let Err(error) = self.background(async move {
			let value = core
				.renew_generation(&name, next, previous, ready_deadline)
				.await
				.map_err(|error| format!("{error:#}"));
			let _ = send.send(Some(value));
			Ok(())
		}) {
			self.stop.cancel();
			return Err(error);
		}
		Ok(())
	}
	async fn renew_generation(
		self: &Arc<Self>,
		host: &str,
		generation: u64,
		old: Arc<Master>,
		deadline: Instant,
	) -> Result<Arc<Master>> {
		let cleanup = async {
			while old.active.load(Ordering::Acquire) != 0 && Instant::now() < old.created + AGE {
				tokio::select! {
					_ = self.stop.cancelled() => break,
					_ = tokio::time::sleep(Duration::from_millis(20)) => {},
				}
			}
			self.retire_master(&old).await?;
			let mut entries = timeout_at(deadline, self.masters.lock())
				.await
				.context("observation renewal cleanup ledger deadline")?;
			let entry = entries
				.get_mut(host)
				.context("observation renewal ledger missing")?;
			if entry.generation != generation
				|| !entry
					.draining
					.as_ref()
					.is_some_and(|value| Arc::ptr_eq(value, &old))
			{
				bail!("observation renewal cleanup generation changed");
			}
			entry.draining = None;
			Ok::<(), anyhow::Error>(())
		}
		.await;
		if let Err(error) = cleanup {
			self.stop.cancel();
			return Err(error);
		}
		if self.stop.is_cancelled() || Instant::now() >= deadline {
			bail!("observation renewal stopped before new master");
		}
		let socket = self.root.path.join(format!(
			"m-{}",
			self.sequence.fetch_add(1, Ordering::Relaxed)
		));
		check_control_socket_path(&socket)?;
		self.start_master(
			host.to_owned(),
			socket,
			deadline.min(Instant::now() + START),
		)
		.await
	}
	async fn execute(
		self: Arc<Self>,
		request: Request,
		initial: OwnedSemaphorePermit,
		global: Arc<Semaphore>,
	) {
		let diagnostic_request = diagnostics::Scope::wall(diagnostics::Phase::RequestExecution);
		let result = self.clone().execute_inner(&request, initial, global).await;
		if result.is_ok() {
			diagnostic_request.finish();
		}
		let _ = request.reply.send(result);
	}
	async fn admission_profile(
		&self,
		request: &Request,
		initial: OwnedSemaphorePermit,
	) -> Result<()> {
		// The full initial authority check and its bounded agent frame use the
		// same eight-budget pool as capture. No budget waits behind a hot host.
		let _budget = initial;
		let diagnostic_profile = diagnostics::Scope::wall(diagnostics::Phase::AdmissionProfile);
		tokio::select! {
			value = self.verify_request_profile(request.deadline) => value?,
			_ = request.cancel.cancelled() => bail!("observation cancelled during admission profile check"),
			_ = self.stop.cancelled() => bail!("observation pool stopped during admission profile check"),
		};
		diagnostic_profile.finish();
		Ok(())
	}
	async fn request_budget(
		&self,
		request: &Request,
		global: Arc<Semaphore>,
	) -> Result<Arc<OwnedSemaphorePermit>> {
		let diagnostic_wait = diagnostics::Scope::wall(diagnostics::Phase::CapturePermitWait);
		let permit = tokio::select! {
			value = timeout_at(request.deadline, global.acquire_owned()) => value.context("observation global capacity deadline")??,
			_ = request.cancel.cancelled() => bail!("observation request cancelled before global capacity"),
			_ = self.stop.cancelled() => bail!("observation pool stopped before global capacity"),
		};
		diagnostic_wait.finish();
		// A released permit and cancellation can become ready together. Never
		// let select's choice bypass a failed supervisor's synchronous stop.
		if self.stop.is_cancelled()
			|| request.cancel.is_cancelled()
			|| Instant::now() >= request.deadline
		{
			bail!("observation cancelled or expired before global capacity");
		}
		Ok(Arc::new(permit))
	}
	async fn execute_inner(
		self: Arc<Self>,
		request: &Request,
		initial: OwnedSemaphorePermit,
		global: Arc<Semaphore>,
	) -> Result<Captured> {
		self.admission_profile(request, initial).await?;
		let (master, host, budget, _active) = loop {
			let mut entry = self
				.entry(&request.host, &request.cancel, request.deadline)
				.await?;
			let diagnostic_host = diagnostics::Scope::wall(diagnostics::Phase::HostPermitWait);
			let host = tokio::select! {
				value = timeout_at(request.deadline, entry.permits.clone().acquire_owned()) => value.context("observation host capacity deadline")??,
				_ = request.cancel.cancelled() => bail!("observation request cancelled before submission"),
				_ = self.stop.cancelled() => bail!("observation pool stopped before submission"),
			};
			diagnostic_host.finish();
			let ready = async {
				loop {
					let current = { entry.ready.borrow().clone() };
					if let Some(value) = current {
						return value.map_err(|error| anyhow!(error));
					}
					entry
						.ready
						.changed()
						.await
						.context("observation master initializer unavailable")?;
				}
			};
			let diagnostic_ready = diagnostics::Scope::wall(diagnostics::Phase::MasterReadyWait);
			let master = tokio::select! {
				value = timeout_at(request.deadline, ready) => value.context("observation master admission deadline")??,
				_ = request.cancel.cancelled() => bail!("observation request cancelled before submission"),
				_ = self.stop.cancelled() => bail!("observation pool stopped before submission"),
			};
			diagnostic_ready.finish();
			let budget = self.request_budget(request, global.clone()).await?;
			// Recheck immutable policy/credentials after queueing, before the lease.
			let diagnostic_profile =
				diagnostics::Scope::wall(diagnostics::Phase::PreCaptureProfile);
			tokio::select! {
				value = self.verify_request_profile(request.deadline) => value?,
				_ = request.cancel.cancelled() => bail!("observation cancelled before lease"),
				_ = self.stop.cancelled() => bail!("observation pool stopped before lease"),
			};
			diagnostic_profile.finish();
			if request.cancel.is_cancelled()
				|| self.stop.is_cancelled()
				|| Instant::now() >= request.deadline
			{
				bail!("observation cancelled or expired before lease");
			}
			master.active.fetch_add(1, Ordering::AcqRel);
			// No await separates the draining/lifetime check from active ownership.
			if master.accepting.load(Ordering::Acquire) && request.deadline <= master.created + AGE
			{
				let active = ActiveMaster(master.clone());
				// The original Child may terminate before maintenance closes leases.
				// Only that terminal proof can renew before any slave is created.
				match master.owned.liveness().await? {
					ChildLiveness::Live => break (master, host, budget, active),
					ChildLiveness::Terminal => drop(active),
				}
			} else {
				master.active.fetch_sub(1, Ordering::AcqRel);
			}
			drop(host);
			drop(budget);
			// No slave has been created. Join a single bounded admission renewal.
			self.renew(
				&request.host,
				entry.generation,
				&master,
				request.deadline,
				&request.cancel,
			)
			.await?;
		};
		let diagnostic_lease = diagnostics::Scope::wall(diagnostics::Phase::LeaseToCapture);
		self.root.verify(&self.profile)?;
		if profile::socket_stamp(&master.socket)? != master.stamp {
			self.stop.cancel();
			bail!("observation master socket replaced");
		}
		let stream = timeout_at(request.deadline, UnixStream::connect(&master.socket)).await??;
		let peer = profile::peer(&stream)?;
		if peer.0 != master.owned.pid as i32
			|| peer.1 != unsafe { libc::geteuid() }
			|| profile::socket_stamp(&master.socket)? != master.stamp
		{
			self.stop.cancel();
			bail!("observation master peer changed");
		}
		drop(stream);
		let mut args = self.arguments(&request.host, Mode::Slave, &master.socket, false)?;
		args.push(request.command.clone());
		diagnostic_lease.finish();
		let diagnostic_capture = diagnostics::Scope::wall(diagnostics::Phase::Capture);
		let output = self
			.captured(
				args,
				&request.input,
				request.deadline,
				&request.cancel,
				vec![budget.clone(), Arc::new(host), request.admission.clone()],
			)
			.await?;
		diagnostic_capture.finish();
		let diagnostic_response = diagnostics::Scope::wall(diagnostics::Phase::ResponseProfile);
		tokio::select! {
			value = self.verify_request_profile(request.deadline) => value?,
			_ = request.cancel.cancelled() => bail!("observation cancelled before response authority check"),
			_ = self.stop.cancelled() => bail!("observation pool stopped before response authority check"),
		};
		diagnostic_response.finish();
		if profile::socket_stamp(&master.socket)? != master.stamp {
			self.stop.cancel();
			bail!("observation socket changed during response");
		}
		Ok(Captured {
			_diagnostic_retention: diagnostics::Scope::lifetime(
				diagnostics::Phase::OutputRetention,
			),
			output,
			_budget: budget,
			_admission: request.admission.clone(),
		})
	}
	async fn retire_master(&self, master: &Master) -> Result<()> {
		// Only this exact master's lifetime owns the receipt. A concurrent
		// maintenance pass and renewal join the same original cleanup, while
		// another host never waits for its child or socket custody.
		let mut receipt = master.retirement.lock().await;
		if let Some(result) = receipt.as_ref() {
			return result
				.clone()
				.map_err(|error| anyhow!("observation original retirement failed: {error}"));
		}
		let result = async {
			self.stop_child(&master.owned, Duration::from_millis(200))
				.await?;
			self.release(&master.owned).await?;
			self.unlink_socket(master)
		}
		.await;
		if result.is_err() {
			self.stop.cancel();
		}
		*receipt = Some(
			result
				.as_ref()
				.map(|_| ())
				.map_err(|error| format!("{error:#}")),
		);
		result
	}
	async fn maintain(&self) -> Result<()> {
		{
			let mut tasks = self
				.background
				.lock()
				.map_err(|_| anyhow!("observation supervisor unavailable"))?;
			while let Some(result) = tasks.try_join_next() {
				result.context("observation supervisor panicked")??;
			}
		}
		// The table has at most MAX_MASTERS entries. Preserve generation and
		// watch identity in this bounded snapshot, then release the table before
		// waiting on any original Child. A slow host must not stop other hosts.
		let snapshot: Vec<_> = self
			.masters
			.lock()
			.await
			.iter()
			.map(|(host, entry)| (host.clone(), entry.clone()))
			.collect();
		for (host, observed) in snapshot {
			let ready = { observed.ready.borrow().clone() };
			match ready {
				Some(Ok(master)) => {
					let inactive = master.active.load(Ordering::Acquire) == 0;
					let idle = master
						.last_use
						.lock()
						.map_err(|_| anyhow!("observation master clock unavailable"))?
						.elapsed() >= IDLE;
					let timed_out = master.created.elapsed() >= AGE || (inactive && idle);
					let terminal = !timed_out && master.owned.terminal().await?;
					if timed_out || terminal {
						{
							let entries = self.masters.lock().await;
							if !entries.get(&host).is_some_and(|entry| {
								entry.generation == observed.generation
									&& entry.ready.same_channel(&observed.ready)
							}) {
								continue;
							}
							// A request may have acquired this same generation while
							// the snapshot waited. Only original terminal proof is
							// permanent; refresh active/idle immediately before the
							// no-await transition that closes new leases.
							let idle_now = master.active.load(Ordering::Acquire) == 0
								&& master
									.last_use
									.lock()
									.map_err(|_| anyhow!("observation master clock unavailable"))?
									.elapsed() >= IDLE;
							if !terminal && master.created.elapsed() < AGE && !idle_now {
								continue;
							}
							master.accepting.store(false, Ordering::Release);
						}
						self.retire_master(&master).await?;
						let mut entries = self.masters.lock().await;
						// Renewal may install a later generation during cleanup. It
						// retains the original semaphore and must never be removed by
						// this stale snapshot, even when all its permits are free.
						if entries.get(&host).is_some_and(|entry| {
							entry.generation == observed.generation
								&& entry.ready.same_channel(&observed.ready)
								&& master.active.load(Ordering::Acquire) == 0
								&& entry.permits.available_permits() == HOST_SESSIONS
						}) {
							entries.remove(&host);
						}
					}
				}
				Some(Err(_)) => {
					let mut entries = self.masters.lock().await;
					let Some(entry) = entries.get(&host).filter(|entry| {
						entry.generation == observed.generation
							&& entry.ready.same_channel(&observed.ready)
					}) else {
						continue;
					};
					if entry.draining.is_some() {
						bail!("observation renewal cleanup unresolved; reconciliation required");
					}
					if entry.permits.available_permits() == HOST_SESSIONS {
						entries.remove(&host);
					}
				}
				None if Instant::now() > observed.ready_deadline => {
					let entries = self.masters.lock().await;
					if entries.get(&host).is_some_and(|entry| {
						entry.generation == observed.generation
							&& entry.ready.same_channel(&observed.ready)
							&& entry.ready.borrow().is_none()
					}) {
						bail!("observation master initialization did not finish");
					}
				}
				None => {}
			}
		}
		Ok(())
	}
	async fn maintenance_needed(&self) -> Result<bool> {
		if !self.masters.lock().await.is_empty() {
			return Ok(true);
		}
		Ok(!self
			.background
			.lock()
			.map_err(|_| anyhow!("observation supervisor unavailable"))?
			.is_empty())
	}
	fn unlink_socket(&self, master: &Master) -> Result<()> {
		self.root.verify(&self.profile)?;
		match profile::socket_stamp(&master.socket) {
			Ok(stamp) if stamp == master.stamp => {
				let name = std::ffi::CString::new(
					master
						.socket
						.file_name()
						.context("observation socket name missing")?
						.as_encoded_bytes(),
				)?;
				if unsafe { libc::unlinkat(self.root.directory.as_raw_fd(), name.as_ptr(), 0) } != 0
				{
					return Err(std::io::Error::last_os_error().into());
				}
			}
			Err(_)
				if std::fs::symlink_metadata(&master.socket)
					.is_err_and(|v| v.kind() == std::io::ErrorKind::NotFound) => {}
			_ => bail!("observation socket cleanup identity uncertain; reconciliation required"),
		}
		Ok(())
	}
	fn reap_completed_requests(work: &mut JoinSet<()>) -> Result<()> {
		while let Some(result) = work.try_join_next() {
			result.map_err(|error| anyhow!("observation request supervisor failed: {error}"))?;
		}
		Ok(())
	}
	async fn run(self: Arc<Self>, receiver: mpsc::Receiver<Request>) -> Result<()> {
		self.run_with_capacity(receiver, Arc::new(Semaphore::new(MAX_SESSIONS)))
			.await
	}
	async fn run_with_capacity(
		self: Arc<Self>,
		receiver: mpsc::Receiver<Request>,
		global: Arc<Semaphore>,
	) -> Result<()> {
		let request_global = global.clone();
		self.run_with_dispatch(receiver, global, move |core, request, permit| {
			core.execute(request, permit, request_global.clone())
		})
		.await
	}
	// The same actor is exercised with a controlled executor in isolated tests.
	// Production always supplies execute above; no caller chooses this function.
	async fn run_with_dispatch<F, Work>(
		self: Arc<Self>,
		receiver: mpsc::Receiver<Request>,
		global: Arc<Semaphore>,
		dispatch: F,
	) -> Result<()>
	where
		F: Fn(Arc<Self>, Request, OwnedSemaphorePermit) -> Work,
		Work: std::future::Future<Output = ()> + Send + 'static,
	{
		self.run_with_maintenance(receiver, global, dispatch, |core| async move {
			core.maintain().await
		})
		.await
	}
	async fn run_with_maintenance<F, Work, M, Maintenance>(
		self: Arc<Self>,
		mut receiver: mpsc::Receiver<Request>,
		global: Arc<Semaphore>,
		dispatch: F,
		maintain: M,
	) -> Result<()>
	where
		F: Fn(Arc<Self>, Request, OwnedSemaphorePermit) -> Work,
		Work: std::future::Future<Output = ()> + Send + 'static,
		M: Fn(Arc<Self>) -> Maintenance,
		Maintenance: std::future::Future<Output = Result<()>> + Send + 'static,
	{
		let mut work = JoinSet::new();
		let mut maintenance = JoinSet::new();
		let mut pending = VecDeque::with_capacity(MAX_ADMITTED);
		let new_tick = || {
			let mut tick = tokio::time::interval(Duration::from_millis(100));
			tick.set_missed_tick_behavior(tokio::time::MissedTickBehavior::Skip);
			tick
		};
		let mut tick = Some(new_tick());
		let outcome = loop {
			if let Err(error) = Self::reap_completed_requests(&mut work) {
				break Err(error);
			}
			Self::discard_pending(&mut pending, &self.profile.hosts);
			let next_deadline = pending
				.iter()
				.map(|request| request.deadline)
				.min()
				.unwrap_or_else(Instant::now);
			tokio::select! {
				_ = self.stop.cancelled() => break Ok(()),
				_ = async {
					if let Some(tick) = tick.as_mut() { tick.tick().await; }
				}, if tick.is_some() && maintenance.is_empty() => {
					// One bounded owner task may wait for an original master's reap.
					// It cannot stall another host's request admission, and its guard
					// freezes admission if the task unwinds before publishing a result.
					let core = self.clone();
					let guard = StopUnlessCompleted {
						stop: self.stop.clone(), completed: false,
					};
					let task = maintain(core.clone());
					maintenance.spawn(async move {
						let result = match task.await {
							Ok(()) => core.maintenance_needed().await,
							Err(error) => Err(error),
						};
						if result.is_err() {
							core.stop.cancel();
						}
						guard.complete();
						result
					});
				},
				Some(result) = maintenance.join_next(), if !maintenance.is_empty() => {
					match result {
						Ok(Ok(true)) => {},
						Ok(Ok(false)) if pending.is_empty() => {
							// Drop the timer as well as disabling its select branch:
							// an empty pool has no child or queued cancellation to
							// observe. Retained state keeps the original cadence.
							tick = None;
						},
						Ok(Ok(false)) => {},
						Ok(Err(error)) => break Err(error),
						Err(error) => break Err(anyhow!("observation maintenance supervisor failed: {error}")),
					}
				},
				_ = self.maintenance_changed.notified(), if maintenance.is_empty() => {
					if tick.is_none() { tick = Some(new_tick()); }
				},
				_ = tokio::time::sleep_until(next_deadline), if !pending.is_empty() => {},
				Some(result) = work.join_next(), if !work.is_empty() => {
					if let Err(error) = result { break Err(anyhow!("observation request supervisor failed: {error}")); }
				},
				// At most sixteen logical requests exist, including these cheap
				// host waiters. Expensive preflight/capture still share global8.
				permit = global.clone().acquire_owned(), if !pending.is_empty() && work.len() < MAX_ADMITTED => {
					let permit = match permit {
						Ok(permit) => permit,
						Err(_) => break Err(anyhow!("observation global capacity closed")),
					};
					// A failed task may have released capacity while select was
					// asleep. Observe its failure before any replacement is spawned.
					if let Err(error) = Self::reap_completed_requests(&mut work) {
						break Err(error);
					}
					if self.stop.is_cancelled() {
						break Ok(());
					}
					Self::discard_pending(&mut pending, &self.profile.hosts);
					let Some(request) = pending.pop_front() else {
						continue;
					};
					diagnostics::elapsed(diagnostics::Phase::ActorDispatchWait, request._diagnostic_queued_at);
					// Construct outside the async body: abort before its first poll
					// and synchronous dispatcher panic must freeze admission too.
					let guard = StopUnlessCompleted {
						stop: self.stop.clone(), completed: false,
					};
					let task = dispatch(self.clone(), request, permit);
					work.spawn(async move {
						task.await;
						guard.complete();
					});
				},
				// Drain accepted channel requests even when global or the first
				// host is full. Their existing admission16 permit moves with them.
				request = receiver.recv() => {
					let Some(request) = request else { break Ok(()); };
					if pending.len() >= MAX_ADMITTED {
						let _ = request.reply.send(Err(anyhow!("observation pending bound exceeded")));
						break Err(anyhow!("observation pending bound exceeded"));
					}
					pending.push_back(request);
					// A capacity waiter can cancel before it starts any background
					// work. Preserve the original bounded cancellation sweep.
					if tick.is_none() { tick = Some(new_tick()); }
				}
			}
		};
		self.stop.cancel();
		receiver.close();
		for request in pending {
			let _ = request
				.reply
				.send(Err(anyhow!("observation pool stopped before admission")));
		}
		while let Ok(request) = receiver.try_recv() {
			let _ = request
				.reply
				.send(Err(anyhow!("observation pool stopped before admission")));
		}
		// Joining every original task remains mandatory after the first error.
		// Dropping either JoinSet here would abort its cleanup while a caller
		// could mistake the completed actor for a completed lifetime owner.
		let mut cleanup = Ok(());
		while let Some(result) = maintenance.join_next().await {
			let result = result
				.context("observation maintenance supervisor failed during shutdown")
				.and_then(|result| result.map(|_| ()));
			if cleanup.is_ok() {
				cleanup = result;
			}
		}
		while let Some(result) = work.join_next().await {
			if let Err(error) = result {
				if cleanup.is_ok() {
					cleanup =
						Err(error).context("observation request supervisor failed during shutdown");
				}
			}
		}
		outcome.and(cleanup)
	}
	fn discard_pending(pending: &mut VecDeque<Request>, hosts: &BTreeMap<String, String>) {
		// One bounded pass, retaining order and the existing allocation. Neither
		// cancellation nor expiry waits for a global output budget to be returned.
		for _ in 0..pending.len() {
			let Some(request) = pending.pop_front() else {
				break;
			};
			let error = if request.cancel.is_cancelled()
				|| request.reply.is_closed()
				|| Instant::now() >= request.deadline
			{
				Some("observation cancelled before admission")
			} else if !hosts.contains_key(&request.host) {
				Some("host is outside observation profile")
			} else {
				None
			};
			if let Some(error) = error {
				let _ = request.reply.send(Err(anyhow!(error)));
			} else {
				pending.push_back(request);
			}
		}
	}
	async fn shutdown(&self) -> Result<()> {
		self.stop.cancel();
		let mut uncertain = false;
		let mut background = {
			let mut guard = self
				.background
				.lock()
				.map_err(|_| anyhow!("observation supervisor unavailable"))?;
			std::mem::take(&mut *guard)
		};
		while let Some(result) = background.join_next().await {
			if !matches!(result, Ok(Ok(()))) {
				uncertain = true;
			}
		}
		let children: Vec<_> = self.children.lock().await.values().cloned().collect();
		for child in children {
			if self
				.stop_child(&child, Duration::from_millis(200))
				.await
				.is_err() || self.release(&child).await.is_err()
			{
				uncertain = true;
			}
		}
		if uncertain || !self.children.lock().await.is_empty() {
			bail!("observation child cleanup incomplete; reconciliation required");
		}
		self.validation.drain().await?;
		let mut entries = self.masters.lock().await;
		for entry in entries.values() {
			if let Some(master) = &entry.draining {
				self.unlink_socket(master)?;
			}
			if let Some(Ok(master)) = entry.ready.borrow().as_ref() {
				self.unlink_socket(master)?;
			}
		}
		entries.clear();
		self.root.verify(&self.profile)?;
		// Unknown entries are never recursively removed or adopted.
		std::fs::remove_dir(&self.root.path)
			.context("observation private root not empty; reconciliation required")?;
		Ok(())
	}
}

#[cfg(test)]
#[path = "ssh_observation_pool_tests.rs"]
mod tests;
