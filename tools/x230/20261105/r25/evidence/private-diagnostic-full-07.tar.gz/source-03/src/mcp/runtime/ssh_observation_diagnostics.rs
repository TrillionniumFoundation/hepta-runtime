// Copyright 2026 Muvon Un Limited
// Copyright 2026 TrillionniumFoundation
// SPDX-License-Identifier: Apache-2.0
//! Private, bounded phase diagnostics; never supplies authority or resource permits.
//!
//! Enable only in the isolated diagnostic build. Events stay in bounded memory;
//! the lifetime owner emits one final report only after original cleanup succeeds.
//! Wall intervals across await are not thread CPU. Only synchronous worker/owner
//! read scopes request CLOCK_THREAD_CPUTIME_ID, on the same thread at both ends.

#[derive(Clone, Copy)]
#[repr(u8)]
pub(crate) enum Phase {
	ChannelWait,
	ActorDispatchWait,
	AdmissionProfile,
	HostPermitWait,
	MasterReadyWait,
	CapturePermitWait,
	PreCaptureProfile,
	Capture,
	ResponseProfile,
	OutputRetention,
	ProfileBeforeAgent,
	Agent,
	ProfileAfterAgent,
	ValidationPermitWait,
	BlockingQueueWait,
	WorkerRead,
	WorkerOwnerWait,
	OwnerRead,
	OwnerBoundaries,
	ValidationPermitHeld,
	RequestExecution,
	LeaseToCapture,
}

#[cfg(feature = "observation-diagnostics")]
#[path = "ssh_observation_diagnostics_enabled.rs"]
mod enabled;

#[cfg(feature = "observation-diagnostics")]
pub(super) use enabled::{dump_after_cleanup, elapsed, Scope, Stamp};

#[cfg(not(feature = "observation-diagnostics"))]
#[derive(Clone, Copy)]
pub(super) struct Stamp;

#[cfg(not(feature = "observation-diagnostics"))]
impl Stamp {
	#[inline(always)]
	pub(super) fn now() -> Self {
		Self
	}
}

#[cfg(not(feature = "observation-diagnostics"))]
pub(super) struct Scope;

#[cfg(not(feature = "observation-diagnostics"))]
impl Scope {
	#[inline(always)]
	pub(super) fn wall(_: Phase) -> Self {
		Self
	}
	#[inline(always)]
	pub(super) fn thread(_: Phase) -> Self {
		Self
	}
	#[inline(always)]
	pub(super) fn lifetime(_: Phase) -> Self {
		Self
	}
	#[inline(always)]
	pub(super) fn finish(self) {}
}

#[cfg(not(feature = "observation-diagnostics"))]
#[inline(always)]
pub(super) fn elapsed(_: Phase, _: Stamp) {}

#[cfg(not(feature = "observation-diagnostics"))]
#[inline(always)]
pub(super) fn dump_after_cleanup() {}
