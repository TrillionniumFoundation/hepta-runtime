#!/usr/bin/env python3
"""Create exactly five private files, retain installation receipt, exec one cost probe."""
import base64
import hashlib
import io
import json
import os
from pathlib import Path
import stat
import sys
import tarfile

ROOT = Path('/home/qian/hepta-runtime-optimization-20261105-r25')
DEST = 'mechanism-monitor-cost-tools-03'
OUT = 'mechanism-monitor-cost-03'
RECEIPT = 'mechanism-monitor-cost-install-03.json'
MANIFEST_SHA = '45761181d7be6ffe4399e2bd560f4cfcd98dc3267b3d1c45877adfd38af7a062'
ARCHIVE_PIN = {'bytes': 10138, 'sha256': 'e8aba68c9c84eb27d577d1b0e354f9aabd1789b3637f159b4cc76bc515b03dbc'}
ARCHIVE_BASE64 = 'H4sIAAAAAAACA+09a3PbyJH7Wb8Cq/1A0ktSJCVRMm26zrHlnGq91patJJvoWCgQGEqISYABQD3i03+/7p4HZgYDktpdu1J1RCVrCphHT09PT3dPd0+YLpbxnGX+Ik3iIs26y4fv/uinB8+w16N/e5V/D3uHh0P5jr/v94cnx995ve++wbPKiyCD7r/7//ns7+//KV0lEYu8vvff//ZCQQ/eghVBFBSBlweL5TxOrl94SeoF2fVt28vj6ySY516aeTdp0Zmn6dJLV8VyVXShvb1Zli48rBvOgzxnuRcvlmlWeEEexWHRLj/tiQ83QX4zj6fyz3/maSJ/pzlvbhkUWEQ29Qv8KYvABBbyd3GTsSACaNWLeMH29vb+S/XZhOb+zZLxZbZirT165b2PF3GRj/Y8eJYsi9PIT/KRFyeFN/b6PtCk/D8VWQT38WK18OdBwRKW51rhk2N3USSywr8OllrZQW3DeRgkWsHjmmLRKguKOE2MNo/KwtV2cSpZWfiod2h+h7EH8/jfLBJF/elDUZY/9Z55/d7gSPxjVJV042csTLOorNN/PjAKLrM0RJxFMZQEhhOz3Aec05gVyoeHp2bzLMvSSttDC4TlCkYQpknEW7wL5nPxYuTN5mmAdXrdHocH6eTBR/IAypX1ynLHXY66f6ZxUl+qD80Bdb37ePGPsw/++/Ofzy8/wWtOT80WfIrYjLoCeJCO/WWcJIjedJWFrIlU3fbY/RJQgW9vgsHxsL0OV2PCTUvQKlSH7nAxUFMtehvP6EM3Y3k6v2XNvMhg2XGC974f00den/AQxDnz/hrMV+wMkdxsVFnADZsDQj0OtBdHLCni4sGL4tmMZXmDdzuLAJQ076ZLloiBwV8X/se3Fx/e/937X/7Xh4t3F+/fX/yt/PvDn95fvPmJt3EXw4Dg/SyiVmZR22tk00YLWAcsc8DjogR8ymZpxnifM+QBTV6iOwPgk7TZaqmigJFmknJO0f3kn3/6ePbnJq/fzQvY+iLADDCz8tUqjhBV0PQ1Kxj81cQCqkETBqyQAIv8jFX62BB21vNeat9zWFXeS6DZ4+PDYWtktPSEKYhYHmbxEmjBi3PqZiq4d3oHdCWmqNHSpvcOUCQwg4TYRAhOygLBrIB2N2FxFrN5lEOxZgMGE7HbBswM/IqTVPwCHIlfiE7xk7AifiMGZAlcUMC1xJ+h/JP3Fa6yjNECJzKeE1SKtJsbaRsnAGBvwtDpHY1QzYE1i0Hy0IQpDooiExTR9j6zB6oo31MD4jW07XqtlRbgiw/QIv4AjiVwWKEjsfl1+eInqLs37D6Kr1kO48amLQbR+j2rN7wJkmugFNg8YJuEP1n4Gf5E0hD4h/lbzXFhfWn4fhLA1PiNkdfwb9iyCIAnxbew75UMX/aDk+n7SDZUHmaG86RHapTds7Ap6uAY22UBqIdfG/CDdw18E6sg68yTYJmDjNHUx8yKVZaIsldqwL4s25g01zHQNd9ae1r7sjlg4lxKeCM6+plLyiMFpA/LIC58v5mz+aytKra9Z21vTlvB2Ngh2l44T8PPYyT7LsjdaQEthrAA2hUG4+GmppXm8o0vFoyGFOy6W/ZMf/K+cfmr9/yVWYuaF1VUd1BLvFevrL6KdOmzW6J0esE3VHoDlZUg1j3DN02Y3Mors0HRa1nqPbywCwkJRnRJUgEO8GrShv+bRflHP8rS5ZLh3qQ1wOUa+c6WXVBMMNviQMH7D2nCbDyAZMdQYJTNzYAa8hvjFeKw/CsBqe2W+WIuY3e7ixhEZ1jx87RwAIRiCQ3qHcjhrFwvNGhBh9A6CNIajdDuqnBt7kHAWZFnaphrwf6lkVHXLYpVKFZroRsA5pOoKQAxijIAe21lNXE/wp6qMQSaPzHCz3ECEgKiCP4LnAwZQmStC5weTsT0U83InKjLJnuN3m6Rqba9WRDPVyRn4By1zZkqsgdzEFRJ0ZpiXqoMuw+Bi3p/CnJ2Rj9BfEfhhsZsNlV2XDwsWZNKtLqSI3s/esiU4R/ko/zj1ei4PyhXAQ6KIYLgPzohWkO3hp2ld8T6EbfQA0dxA3GMTJ1Q3ShxrXMv/K5NQoWZNeRSsSvxKWqodWN9xzFU2hKLhy8sKCQG63XKqUZA5ZYwktPZIFTB3wK9j7qQiA285PDgRi/bfFm2aU5RSa7NRpImCm5BpR5qINiQYB9vfvkLZ6qNlt1rR/T6yrnkpD5Y27na9LEkERlDmZCruhwMqSyafesTJiVKpHCQiyIpxY4FbB2z9MuxE1ZdKd4CXo4oUK5yUCskwLIfTzYGrCuJ0jsLdm1DIHgVmNqHq05/cuWmvEkdtnVdfeshQPkK4kWLJthyXWvY3qKXijmGi36RJ+Z7ac1tlb9WeJWAhxbGFa3pRQBIAXmzQaJeR3beQQmcdfhAD277Dani9JEIRH2WrBYMSAyw7JCsoN0aellrD6jKQ06Zt0QODQLBE82C3I2yRpo9eLihAt4aLRcShHYI5FOOqIZoygJuhkUlYE0/GXgud0Up44QxiwtBW26QBRDhIgJyYD7sySy5jTNgQzBgn+T5iSQykhIQLXJo3IDn51CUT3nvyeByqwagHFR1qVWshXSK44MZkLIDdFxC9K8VTHzIwRFAo1LnhkpfIek0Z9ktLIQ5yFSl+RJaXiVABPilsojcYKIqyEFDpb/Z4GJLg+tw/AOqcQJgNYjWZhirqzgLQtiMojhHESnIgiSk6aFtQjIIOTIHtG6xFSQllOEqAJqCF5dAmj+xB5rRtncJ4oX4WU50q0YqsYcG6yuYx1Gd3ZhVZZT+sKeBxJIwjVDORd2cw4/m3260WizzJggjKKYsAUOwhvNxs9FGNXOEuiJsaukdSEPJmKi71eVN2XYfJdWKDaHlvXIzIrmTOMw8Vc3hRxPwmo3EbU6t7aEyoe5m7WKt+u1DGofU7MDefQ3/sPubYJUDc3tRiip80YHyG6BqYRGd0Im5trGNPqGjXOkB6V1rbwNexwZibZ0fWUKpC/jZis+thgElqTGXzLtJdXMWc6hrpZIKnMIXBdBIWK8ZyE2mHHKzwc8a4hBoute2YWqNxKirKNNU7W7OdP2CioCQjrZp4+XdDcy/BoHS3rsxbgOGgUU1JMU9pdCUCPuRd/PMoFB1dlJpKmLz4AHNh2WbHQPlLe/A67PnLr7M674CUZSEPAv8uyAumlQEEDYFzHx2tVE76A1VBHRKqCwR4F6b+pHME7YFblGqyI8Omb26KGvFmRpKs9RlN5kpOvrRJiR8EnZf+ILMmuvxBPN64KYRIKG+E3bV+CsCYQ0eDRsJQFpW7VDVjTNQUqMlzoPGwWAL5h3QyWcYFOFNZ7WE39kCufq6mRG4UfAYhX7wzoG6gBZJCgDVBeaZeUWMxjZ2D8J9GBfzBw+NyfF0VcCnG9CMYhDYuHpXpFZzxU2A0ms8n3cyBoJUhgcB0GvXOy9wt4mvqbJSpmhX4BU8YM1zkLy6e19h4UelKUTSB+69svG6raDZoMEKUiUOAA2hQiNMMCV49rffZGjRCUKuRKGxoyjGIi7DPM0KU0JCg5k/OPp0GQqtDaiUDQwLoral6RYPF06re0VpS8M69gYqOZ/AgK6lurQBgS+gSzqMYsBMBCja0vjBe+1FAYPCErGiPOj9JLYXN9DPXYZyglLdut6nVYg/Zqu51hK7xfNHEJc5/QqCx1UEDc9pHc8ZLBq0kL6At3wK6U8cjJBXuzX23XJjv6RfTRgLbPFjKoXyRtvDmR/bGrLAQ6MtxincCxyd8LXUNIRUxa71yaKNTV9kzhPr1ja2AzFJeEoRIxfhIh8fKTIEbDPCydDmbJ1wJ6SxaZrOLdlamo1087zatQUCYO8NcNZNUkyXwqgLwj4qsNwKk+TqBUiQriOPck83JaE1dFzFmIAMicRAuev037E4lTVeDb06VNd083qj9bMWxRylkrJha8B6W06V3M5AtYrzwpwtUy+UZyllOXEOUPaDDhXEhMhEWIpVanMALNMnALvC4eQ3YtaVrxXBwZDoSQzS+kV8SGhkX4JD2iCI1y9BfCx7Fi8PZCNlZ+kty3Kfkxx0yElcszFa1FmxmRrEan91ygr2VF31JmtNSzYE5SvRKRratjB+bg0PNULHARNvPPbE7lwua2uSDXRUCryyoK0sDGMGRp55ktSoLopbMvYIEUfMG/w/e0Benq6ub4ToFM5ZkID4xnmXaZKVpKTRjrJ9y2815stagd8CvLKsi7QISqt8RfTnMhqUQ8V8lQS3sI0FU8MWCICXa0MDvXxZYz9Y4ye1bgiWbESnGWle/EbQKwL8aCPKeGlN/BMU6mjYPEPc3DR9l9YRpKnZPL0zZBiQM9VhrHEGKM10vl5CO4x2s8ntmYb19VVFJB/ZQreComlW/T3KmXuUWXp3xc8GJ9xKmt6hiVQyTBi6XuJJ3FAeRl7VnTZOKpxvYhtcSlhfbTD5ucb3vdgLMzRtN9X7lsNSYpFXqYWVpEpNSpak+FTkBULNBJkThMcVqn94iEIwrUBCnsGviGVrj3bqujeVWjw0UidrYbqacxYKMjuK7NM58WjddYxLeV/k0dBIngsJq2JF+sWjobbXWKLTL54dY+u2DMhFnqqjS4NPDdTiXsK6GNaiRstdr3pEbMuM1eZFibozZoOOoDsxorr+rHXk6E82UNehvTFCn7adUZay3zt6E984cmU9gerqWbkmAsFXscHBe/Grvv01O4c4gqd9Bxo1dnF/Hs9Y+AA7MJbSvzi6EuZgoM8Ej+3JfC/kVTzQd5vU1ZRo7xxt25ZzhQvrPRKA2JkU76EFLCvo+5ajH7kAeQFfrHq/JDJoR/ET6EwxH7MilKqyJUd3fI015C4nnRzU9tcYuTbFtsQ1jUr4VVUbv0lh/lJQssiz7y6LObp7WF0/ReSvMD7AeRQ54mcHrgnHw2UqSEeJyGYoEsE6SAIuncwfQKMHjKD6P2XFHQNpg2OIhCi1dfJzv8bj3ne7Z8NTek/iNHyN6J9N8T/9o/7RoR3/czg42sX/fKP4n3cZy2+8ylGh5lQRJKXoIv00HrxZlJNl/Jfzt14YAKOk4J/fGLdDYTpvLn7+5fz92Uf/w+ufzzCQgmsUaNj50giBt5CzeQZTFsofnfmc/M7nURd/Pbb23p69fut/unx9WWnhH1jwV/zPPRb8+fWv/sezNxcf32LBwfGQ3gAMP/t/+juvLV9ic+olhbRc/HL2AWq/fstd5+0whzfvL85+PXuzKepBBIjAxpAzWoHcNVr5ey/jSEibGA9BImI4T1FWhG6hKEoQIPB5TTwQx78z/qLVUP7yoqL3kkcmyOogO8svIOqvcyiXJ/xolqU5wwM5lMvK0I8lHYrGCYF/NRINT6zQAfwmu8c+J90chFLNtX/Jgy700Utffuk7/9Ib9Mx3V70J+cg/cQwqiAUa4w2JsUj/xyUJYPBfkmYWi8aIBlAibTASg5m0xSaGXoUSJmOjayx5a4ghUaI/IalWOD9dw9pamgUGUMBoYxpnxY2Px0S51dTziXCyl/qWXpTUJMIZfSJIJmQOU68MIOjb03BJnl9xqHDaMPzooQ8tDkqFCzQVI+EmdRX1JAjeCCfiBdSaQ88ZEK2jsWqD92gcuv/AIcS5OyAwUdO6Zgl3UlP8TvNnErIfd4O4Xs2DTGssZ+wzWjE8lIPyrncBSqxsg+whwW0aA51fsvvi/OJv4iwDv3SKtHN28a6tNYZu+e+gnfOLsv9/rRg6v7VJVwKuS2I1bzpP52j2LVIpD3rQXteK8Un5CQEFTUlU7lnu3RQS82osv28KQyIEKgBRqhbGHegoNJVFYb1DHgTybY4m6ea08T9Jo/W0ToSfFZqO4kSavKtKKfYTMfL3aayKWedUBqHZh22AFVymDNAiw/EqASNNBMHP0rQYUyhd4wBfIEt9tn0sXul0UgnraErOQofCKkROdqoRttwf3p7DxnR58fHvciXJuARhVyLtSEUFGGSPS8WyQMmoOtzIAfwmdsr9u5ICx2H5naM5jAyoceIuoc03Fexin904D/IwjilQrvotiq9jp5MJHw7wjWTF9qofcJxOHwS0ftLXV+umaFuvRiLCUrShc3ZO6sq6CRxEHvRSx63q0T/hXpphyuFrZ8GIGnhDRrIU6YVYW07BYmPg6S1nVIZ09MKlq0kt1cGJghKEL9znEvcLPI9EkYn7NI48l08iX3rmCn+sjrLqMVPu/+Zwa92OkSmjRGBsCHwtEHp+9BoHtOm2PVMma3Ux4m/ZdPs0Ikv9kBbvcATCo/EXThPv0/Tzask9G13gcPpD1vwJ+19mrJPwH1S9w+5jEWoZAHkEOflkqGMH7grbdcJ08elJvpWVGdTlkLWzufBWCQJCpvb2RuMqtxH46NUADbicGxxT71yotBKhe1zzQNemED/aro1y6VnW9VoSQp+ChN2h9tHRdRK0ASB/RRNqApsmLrlAxZQu0IvHaXz+gURjRi6+5I6Q4/wjI+gCRIa8mLBrMsmhr8NqDorMKruFP3NHm7AmUqIVdAXiGRZ4kx/ZCj2yZ/QRlSQiN+EWkTE+IkeDUBzqFXcpF71wwnMUDAIRjY2DlL7vCi3dqj+ehu8aIauyFympi/aPSpOzOMt50G6pzNQJfCQvi8Vd6law4aLCU2kZQ5szvxrvbUl/5rE8SU9fD5pK2PQaYATx+SJcH3dirMHxreG0DcRKTs35wwIDp3Ph2Vw/e/6T47Id0ImA4LEVIw/z3tQxryLl17EWXGxaRLVevxoprWGSf9ziREiLv65Ud0Rh+zwRwZaNa8HaNoo3jZqo39a8vh8LQrQ+bNcWbYDUCLFXcmjgjZlfnMEMYlZr5J91m4xQdvGfypazBQ49p5Ch2KekNu6PLJytGls2zAkJGv7y7BkhCQBcEeg2ocLbxy0bJQLibXL8Wo2q9AHYpmNPdEeyCpWARxlfiRnlVoJJW02keDHZapa2gE8/S+C98/hK53GIG8VyvnEZU025r+t2NVwo/CMKstR+6/GPlcm+Ho266FNF4lRIs2ZYf6RY94ePRq02Jdt/XdHQ6eIqz+CVpFHrglfR1a29tF6pLyURGVwmvBJ0bwSpPSvrGEewWHW1p9y10Y8mAtdGNdMpW90RsMNOYDVdHlOWB5OVKLqRGjt8LcPo+PG7+mQ2vC5oUJ7UOc73zEY2RHyOuH6+O4T7j34WwD1WGZ63ww7SO/wqB4Drz/8GR8fDSv6/w/7J7vzvWzw/fH+wyrODaZwcACfwlg/FTZoc7u3v76OBe9jLuQmbVGnh09Ihrz9Y8lP2AvRadMAMokVcgA66ZNkMw2PwgD4EhhkAB9FPBYPsmhSyDSkC/6C8gMS+XKeN+UNuHDzK3xiPMw3Cz+oFbH353t7Hi4tLmWatcXCTLtjBv+IgOeD7RAZMDhrppEv4R4QFdQa9wbDf7x13ssEx6FyXFxfv8eiQWjrwGguGcnCcLzo6TjtFms7zTu+wsXfxl8vNxbGgPCn90qic5DfamsdLmd4TX9MJjpnFyfhe5QqNx71352fv6aj0K+cAe/3m8vyv55d/9//6+v3529eX5xcf/LOPHy8+0jj3dPcq5QeMPmd0cGJ7yZe+XFw0OxBOpMLVU8gkbLEsHsTGXka4q9DyAKC7BXnqQIVmy7h3mQIPT6DRIuQMOxeG1WXGaCdt7z3KkwiefIv2XZEyT9iyx/2hmWxRSMhb5fZzHtrxrRnkoaUK8/jPztj3RyTs25Sgb+zI0Lfl2RghUs/Hh8zigFSyAzLeHHBDupkkkdCQRg9WTj7RJx6Lt15smZJvfZo8PDbAjpwZ8L5l1jvONVrrT5QRlZsT0ylRHQesp5hDsVi4AapxI1uhbHnw0kqxR9/1HHuWYFtOqq+OtEfeFxjQyImGymgfH9s0y2KZ58EtsDZ2J9YY5WcQCBG0oOc8EImK8HjIh1bzMTf2b5kFAY9O8NRVZUNYu9L/9tFwWvl49vpS/nH265v3Ngtoe70UBLn6lX9Xs/KFQf63rnxe3Vj55aualV8WMFd++Z4WQzX1SZU+Z+QgxRMcGxk43YlQuemHhkfukpzeXsh3s/kqv2nC34SLhySsxwWPXFmDtRfruIDMgGEYZGn01eVLPVXJ+bfs9I5zUYvj6J09gYVs9CRQ53GVqTog07uZpEbOXlvlvMCch/aOXOYdleWvnPyBrLEmi6jBqWARexaCyuY5K6MGSy5ulBCMjYps4m12P2qw34+J+6zlzGswisd4SHiC9j2SxlXjiD+UpE3OLUcg+OI8DSJxCsKTkwpYVAJSkr+7P9OfmKWGHy+/EAW6MtsobqZUn0LnaHOYvEAhv8sL5ldYbwLF+N/VhKSien/SttuuJCeFL6ii+L4xMtGwdDBBgRYpKW9yOZOYPkrcoBu0ZcI7lkjnPtCQfmJsyVMYmQ7NCahIxQuEFkRUfqIppVGOcjqrJHWAPkYsjHOoSlqXyHOdp4nmEYIQJoxFcqOppIkUHJg+j2R9Vy5H0+8EmzRS2Y1BfdRTkaMpbDWfA1e7ZxFqltpIcaD4e14Jd9WYKnXBEXplhTxQcBFulKQEyDKWGzyFL/ZM7qQXr/H559UAeoohRx9KGWOuyF2F1fBocxtmdD81YWpMWihrfvlt6avsow2l4tygHxqgL+koIuH5Dh0AlRRpAVWvfwEOQJFgSAi49GE3WoVA/uyALAJlgzVosKZOxKNMQMM5JllcfpcRKehYKTnQYMkytGuWYYdcvK70pBl+ZXsyzGFihUYL9y90RKE4M5U/eM9MdsIodZHAEie1MsBVVKrkVKuSmiS3ssrG3G3SEqtUUpXqr1RB7QkuJ1n148i8NkY7OddLzfRmZa2yMFrO6Q/beL5mbHpCt7E8W14DEQrsimiFdg57TB7nsM2ED9WJVpO9DvSRI3cNTqcrzZuYVh3dQt8/QMOQdM741wrofPZACSeiVUhxcECO6NbhytQmzwD1Lu0zupYbSmDkCZRIQtYUZ3gUkNgSTCsRb1uI34HMgFnwiG18J+dMnDK6z30CcvYyJxcrV87/mob/fMt5BlhzttQo7tIOebISl7uFgU3jOU60TDtGthEt2d2WWera3j9Ylr6Nb2nPqz2Fs/awxiKYo5mSeCtMHae2p2V5sTRS2vLJJOob4Y+i57YWpCVfmTonmU3nvjC8LbjrgmhIcoEwWAYhYM2XqYEw7pwUQFYTYNVQIVXINnX7WBkSSijgsVXWHqQLIug8rbY7yvJBht+MzYMpwwDXcr1L69YCCjfVTRVZTjYNaQHuvs6uVzjMX+hLU0qW0NkYJKw0lAIWr9kNosgPRJVmo9NZBEk8AwG3I2ThtswEE2mpV6BCLn2Asi53BcJ3pZkEhcTlPCgQ/ZT5FFCyuqcEp4ZCORY+9GQDlrJhS5nhSI/hRt4Dp/V0nZBN8pDHozxp1wdynrNrSZ1EVWp0ZWAHdVdrCOTAAMRfSC8k7zJcsaQIwYLltTGIAz2CW49Yh9uS/5cMLOHn4JopLHfRPtF4XDcKdg/cW5z2goh3yzqIJDEE3pw9CNm6X6pi6hX3aTfUMYVfN3RtcbeGxE+ldVNvQjroqjL8y8h5n4I2AFne0vjV6zGdUXRRscmb+lhKggP+Lz9gmg+SS1oK+y4I5LUrKpOt2Tn/jHT+BWd55EYaV7M4hgw3ZOqWa6PydVvd9JLI1pFSFnnT1BK4uluqXvDnxLQecFW2NMVxOquMn+tnmy9FwW2WQ7YkFy1CA+fMpePxxV8uu4vPSNVomhj30hNpsULOBhs8WUtI95R3WtBCFTJ077Ahx59fOc9PRFyTEHfTzNma+mq2t/bgZdJSNxMRr1TwdutvEFKLwnX8Ux2G+jghXVkuCHnxB9ci9J6tSy+aHBIJKJ2Sjdc5TxgHVsTKRJYA4nq+tsfIyHJoZNizBQnnBiv3xa+zd6Jr2KpIFwBcCGupEE4NPQo8pCM/lNunIJzeLILss0wVoPd5E8+jjMHIlsEdD8yvDozPEc4qti6WsFpT26zJR5RYxZKCJip877GMT/HG4jIA5WN9A3v5nGWcfawWU5SDuCaDux//1eQfBN+g37S8RblP53++PPv4s7wWDv8+/3ApQtJQECDdPlstKdyBqrc9oGVcsZLffeQYNXgu7XtaXW/6ILpQspgAzGGOMEGVo1RjMwbW1nvRQ42QvK8aIm2aLyUcmC1KxdbgFiW+fO2sbhLddcFAHDcB6X+ezLD/o2Ux2TOztzra8l6qVqxs71g2nzO2bC5ADOt1B8d0uNgE+m2qjjuuNkUq1lbLEMU3ZVKU2JJK8vbXVmg5c8X5exdkIEyUcB82azzAOBWvQ+7TCGAeLKZR4D3zR1YeSaGJ6hONmepKC14FAbwGYUAd/OBxvsajJVeUgguvYgS5kaDtb7ZRr23ZOAeoNIpbsQ20S/5QXUutvJLrXbP8jMt9sSs3u6YmFMnG8OiKJ3op9xrjkqSWYSd1LEplh/LL7rfCeqcsLyegfFPtSVv2YleZeKWtSr3S7Y+6ac0uUGlfsxZTy7r12I24Gltyfe7pchNRBv11op3hRr5BlsQ9Ck/fRLvw52iD6Oa+KqCurw3Cvui+sufVAqFEdTcYclK0Xdmn5EiM5saYwCekmN3QLAkML+xSJSd18EqDegy5aCLTFjoJzFljK9dw3Vy0ZjRYQGwC0nLEy1dhB72IhGUCmSsTYllVNQnTZqylLWpvlZ2obSUWajuSAbUeq7yc8k/5q0RSC0K6gW85dqC23H/0rUitu5otSZRTEcAsXhYO7sZBlatCRzVtorpngdtMtYaSNIfi0FHDwRnrnMu/moxe+kpLYho56Kst8cRdqRGVj8BI6ShesxcJc16Pb5f1C4wSifb39vZivPxPSDaYGtP30eiF9x/ulTrsp4ccZvrsPkbNH01irf8gl2gne/2m/r+9/vHRkeX/O+gdHu78f7/Fg/6U++sW3j5elSYW3j5mfrll2QPwTG5yh6/7vcE+/xgH1wmsFpDE0ZwMnwoRwbJPdh54wb039x3GD/URPpPVCF70B8d9pTDvc1sFdhjMpsf9o8PhIHgenUbR8cnh9LQ3nPWi8PQkmvWH0+gweN4bsqPjk6Oo34ue96ezo9PD6YCdDMMonPGDcXGIul+xjbhAGQ6ODh2QPI+Ck/7p8PgomvaOguHRkPVO+9EgOuk/DwbRMDoCKWU2Y4eHJ9Owxw5nCNXJIUAWnZxAG30Tkqrd2ImV3rB/5IBleDI8DY8Op9Pj2TCKDk/DYX94eszY8Oj46Pj5cTQ9OR2eng57bDAdnAwOT47DcMD64dHJsD8dwPhMWNYZqlxQnfSOjx1ARYMw6vWeBzAts8Pj4PD50WwWRWF4OjsFbIVhL+xPT4+HAFv/tB8Gh4M+C4anM/h2OuifTgcCqD0B2H6t1WhfWo32a3cag5KBo0erkFqgrBg4VqMAt2jhGNZZtMhj++D2kK8A/MtcGof7e//ZATDr5vkb5X87HvZPLP5/CML9jv9/o/xv56UqPX+QyqV22ifNwlw2z2XMB0j9mKdLZhsARRJdjsgnaZYFofBf4oEU78QLVyTHAkM2+ImhMhhIrymVCowL4lteDqBdC/xbPJ7qL6+tOjwpFxN5e+J4vGWWXGFMETcWVj1IjeZFclxqvoKThrxtUs4Tv/aZN1nXotNuscG3qv2EuAurWyxre0BtdtV6knfW1mEeNRhxJjp1wOHw8zG+16ZANT16BLRldJUZUGIBqbmCyH4q6YInZMduGcBUC+FFWlr/8noMaROk9KqF3b1GNvVpmCdtzypWc4sBHac3NyxllfO5dA2cYhRLcu10tyYrGO9Ps86tTeOswbs+W/PEcp6T94RucxMDb9GxctB/NqBcM6xyf4EcccO8e4OusfZkm9LRsu3V+NWZUPe8l/wi4JcVFgLjr95mYK1P5ZOHc0ft0KoHeF6Zyw+/HaC3ibraQCQM1H30xHaApi/xs0k2rjq41pl2Ji2LWBGoZ6qPLlB2ugDsInDiPgf9swhiRl8iw7lRjmeTv6G8msQxCbUQ165tkT67GaMb/GyeBkWLr2fcJLtxjjNfiGL8g+h+TFNxIMhEGDsYv6SBFzH9tIM7Hp1tLaPyshjbddIEecDdNcvU3AiBWUcY2iZr6U01r+xzIqmbhDbN+KVNdd7A+p0p2hUl6ro77hWnFRJXESiuvf6SE6IJOv07EBewcSCxYN0O+xuvcakAU3dn9biSrJ5OI00AX7/5id8bwC/NyLUbB5awPRf6rJfeiDwduZy/5apd5h0oE6+TXEUXVuL/VCtL1HvSVS7vXld/lwfObTO114yupIrYfVs67KqMAoquTDN60Pamylu3hqXTx018vMrLAwoGLDk2zccUeGywnoD5zewGAaMT5YGWQbC6XclITgNl6/NjELQBzb6OWJ4rtGM3tRZk7XpzHW4iF9xe8aYVEY+Il5o7HW83zDZO1BOcqOmD7RUu9hUBneH4rBKwAXuzACuJF9NGuhq2Z6HmhpIN16GK83q98rMqztV9Ko4zlhIlov4ryZPW33oy1q5QpOI9Tr8d7fW6+ZfXQKrpt67ToatKDtRlkW7qld5seo8GWxpZbEW7A1gO2Eqs40yjxDdIZBJ8h9F2nI7XL7Hlvp5qPSJLf+9VAmoMiPXohpkmHXnXpojpIGgri5cD9bIC00ibWNeORFmfQeXDuAlP59k2IT8hOkELQqjqobV5bNx38PTppivV4IYkL+u3d0cNEobIV15jPaVrI1c/eOT2A2bwIxbqim4ITDhrdkujzJrdeKp7/RMHpzySqyIHzcg9QRbmrQvslU69MQpjsjmO5HeHjTwhk4F9Hm5cLe+IsPjdARm/J0JiXRyHO7JBYsf4KgIkHFEO9TET3yw4AyT6poqz2CoI4wm5KNbi9aqxlBYDE5lGkkP764rXGVuvRc5CGsNWVzm0tDN6RVPSTOHUCHjiTyWnCprVDsCBkW4dSK8C6HW/BXGvlutmNeQ/dJ/aOiHAuFZNYFq0ua2aZNzwLLQllaPa5pZ0jv2UDkZVFmfu47QNl7eiydZbLRs052Vn4qKzA3XP2UHGSO6sDxbcfJeSWE6ib91oUXevEtWw1Z5SaVYSQ0fg+BZ2wOta25wmcr4kPbzc2FD95pOTe3c3KbypXqJYjc0sNS1Nqa65+GqDfl1Xy7hKS1pJeYL/Ffwu6saqMtGXkFX8aNaDVC3uWOdE1gfrQSn7d1815jJbq6mczYNr/E7nfb875qztXYgrI8WfeKRyL36/lve414an2fdsqug08+TlqdeQD3o9sTuL5e1Ds768OoC3ybdOufzbII20SLi1zc2YpzgE/kaeL1fbZk6UR6WaXU1zvqy/LtBONFi530weFCmydlwXV47WHlKlgNy6yzvma6LoeAJvqh4Z8XFtng5FXgiidAd+NJIXL2ArlvVUlKvQNjNSoPD27V2uxN2ze3bP7tk9u2f37J7ds3t2z+7ZPbtn9+ye3bN7ds/u2T27Z/fsnt2ze3bP7tk9u2f37J7ds3t2z+7ZPbtn92zx/B/qj2CuAMgAAA=='
EXPANDED_BYTES = 37290
NAMES = {'compiler_state.py', 'compiler_monitor.py', 'validate_compiler_monitor.py',
         'measure_cost_03.py', 'package-manifest.json'}
FIELDS = ('st_dev', 'st_ino', 'st_uid', 'st_mode', 'st_nlink', 'st_size', 'st_mtime_ns', 'st_ctime_ns')


def need(value, reason):
    if not value: raise ValueError(reason)


def pin(raw):
    return {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


def stamp(value):
    return {key: getattr(value, key) for key in FIELDS}


def read_file(directory, name, expected):
    fd = os.open(name, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK, dir_fd=directory)
    with os.fdopen(fd, 'rb') as stream:
        before = os.fstat(stream.fileno())
        need(stat.S_ISREG(before.st_mode) and before.st_uid == os.geteuid() and before.st_nlink == 1
             and before.st_size == expected['bytes'], 'file descriptor identity differs: ' + name)
        raw = stream.read(expected['bytes'] + 1)
        after = os.fstat(stream.fileno())
    current = os.stat(name, dir_fd=directory, follow_symlinks=False)
    need(stamp(before) == stamp(after) == stamp(current) and pin(raw) == expected,
         'file changed or content differs: ' + name)
    return {**pin(raw), 'descriptor_identity': stamp(after)}


def create_file(directory, name, raw):
    fd = os.open(name, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600, dir_fd=directory)
    with os.fdopen(fd, 'wb') as stream:
        stream.write(raw); stream.flush(); os.fsync(stream.fileno())
        final = stamp(os.fstat(stream.fileno()))
    identity = read_file(directory, name, pin(raw))
    need(identity['descriptor_identity'] == final and stat.S_IMODE(final['st_mode']) == 0o600,
         'original write descriptor/readback differs: ' + name)
    return identity


def absent(directory, name):
    try: os.stat(name, dir_fd=directory, follow_symlinks=False)
    except FileNotFoundError: return
    raise ValueError('create-only path already exists: ' + name)


def payload():
    raw = base64.b64decode(ARCHIVE_BASE64, validate=True)
    need(pin(raw) == ARCHIVE_PIN, 'embedded original archive differs')
    files = {}
    with tarfile.open(fileobj=io.BytesIO(raw), mode='r:gz') as archive:
        members = archive.getmembers()
        need(len(members) == 5 and sum(row.size for row in members) == EXPANDED_BYTES,
             'archive count/expanded bound differs')
        for member in members:
            need(member.isfile() and not member.issparse() and not member.pax_headers
                 and member.mode == 0o600 and member.name in NAMES and member.name not in files
                 and 0 < member.size <= 65536, 'unexpected, unsafe or duplicate flat member')
            body = archive.extractfile(member).read(member.size + 1)
            need(len(body) == member.size, 'truncated member')
            files[member.name] = body
    need(set(files) == NAMES, 'exact five-file inventory differs')
    need(hashlib.sha256(files['package-manifest.json']).hexdigest() == MANIFEST_SHA, 'manifest hash differs')
    manifest = json.loads(files['package-manifest.json'])
    need(manifest['schema'] == 'hepta-compiler-monitor-cost-tools/v3'
         and manifest['diagnostic_only'] is True and manifest['production_candidate'] is False
         and manifest['fixed_observation_seconds'] == 60, 'manifest scope differs')
    need(set(manifest['files']) == NAMES - {'package-manifest.json'}, 'manifest inventory differs')
    for name, expected in manifest['files'].items():
        need(pin(files[name]) == expected, 'member content differs: ' + name)
    return files


def main():
    need(sys.platform == 'linux' and os.geteuid() != 0 and ROOT.resolve(strict=True) == ROOT,
         'native unprivileged direct task root required')
    files = payload()
    root = os.open(ROOT, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
    target = None; created = []
    try:
        initial = os.fstat(root)
        need(initial.st_uid == os.geteuid() and stat.S_IMODE(initial.st_mode) == 0o700, 'private owned task root required')
        for name in (DEST, OUT, RECEIPT): absent(root, name)
        os.mkdir(DEST, mode=0o700, dir_fd=root)
        target = os.open(DEST, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW, dir_fd=root)
        directory_initial = os.fstat(target)
        need(directory_initial.st_uid == os.geteuid() and stat.S_IMODE(directory_initial.st_mode) == 0o700,
             'fresh private directory mode/owner differs')
        installed = {}
        for name, raw in sorted(files.items()):
            installed[name] = create_file(target, name, raw); created.append(name)
        need(set(os.listdir(target)) == NAMES, 'fresh directory exact inventory differs')
        for name, raw in files.items():
            need(read_file(target, name, pin(raw)) == installed[name], 'payload changed after write')
        for descriptor, path, first in ((root, ROOT, initial), (target, ROOT / DEST, directory_initial)):
            current = path.lstat(); held = os.fstat(descriptor)
            need(path.resolve(strict=True) == path and all(getattr(first, key) == getattr(held, key) == getattr(current, key)
                 for key in ('st_dev', 'st_ino', 'st_uid', 'st_mode')), 'installation directory identity changed')
        report = {'schema': 'hepta-compiler-monitor-cost-install/v3', 'passed': True,
                  'archive_embedded_in_retained_installer': ARCHIVE_PIN, 'manifest_sha256': MANIFEST_SHA,
                  'destination': str(ROOT / DEST), 'files': installed, 'regular_payload_files_created': 5,
                  'automatic_retries': 0, 'source_or_cache_modified': False, 'cargo_executed': False,
                  'runtime_or_benchmark_started': False, 'cost_probe_started_before_receipt': False,
                  'next_exec': ['/usr/bin/python3', '-I', '-B', str(ROOT / DEST / 'measure_cost_03.py'),
                                '--manifest-sha256', MANIFEST_SHA]}
        receipt = create_file(root, RECEIPT, (json.dumps(report, sort_keys=True, indent=2) + '\n').encode())
        os.fsync(target); os.fsync(root)
        print(json.dumps({'installed': True, 'receipt': {'path': str(ROOT / RECEIPT), **receipt},
                          'next_action': 'single60s read-only monitor-cost probe'}), flush=True)
    except BaseException as error:
        print(json.dumps({'installed': False, 'created_files': created, 'error': type(error).__name__ + ': ' + str(error),
                          'automatic_retries': 0, 'runtime_or_benchmark_started': False}), flush=True)
        raise
    finally:
        if target is not None: os.close(target)
        os.close(root)
    os.execv('/usr/bin/python3', ['/usr/bin/python3', '-I', '-B', str(ROOT / DEST / 'measure_cost_03.py'),
                                '--manifest-sha256', MANIFEST_SHA])


if __name__ == '__main__':
    main()
