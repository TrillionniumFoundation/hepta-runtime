#!/usr/bin/env python3
"""Bind successful qualification01 to the two exact workflow commands; never run them."""
import argparse
import datetime
import hashlib
import json
import os
import re
from pathlib import Path
import shlex
import stat

ROOT = Path("/home/qian/hepta-runtime-optimization-20261105-r28")
SOURCE = ROOT / "source"
QUALIFICATION = ROOT / "qualification-01"
CANDIDATE_DIR = QUALIFICATION
JOB_ID = "1a1ac5d5a29-fc05-53d9"
SOURCE_MAP_SHA = "da8cbdfef75c1c9fc5861e4fe0bd96aeb98f635e95fc122610021cd725db1d28"
ISOLATED_SUMMARY_SHA = "a6645dbb6a0208fdbca1a3dd6308c55f7d6b876ef4ddf70f02a2b4c58c9db46d"
ISOLATED_AUDIT_SHA = "1212a8fa0b0e3631627fbadc3e5f93e895babfb7b35bf7e0fa740cc01d16e6d6"
CI_MANIFEST_SHA = "bf0df5f7d19ebd149854fbf75887fb0fb136f18a63a0c240abf8420655fb195e"
NEXTEST_ROOT = Path("/home/qian/hepta-runtime-optimization-20261105-r25/ci-toolchain/nextest-0.9.137")
NEXTEST_RECEIPT_SHA = "2bbae481b3fbc6ac6d06a22bfe22e9500f5190b97ccddb16e8aba1ef1ed34f9d"
NEXTEST_BINARY = {
    "path": str(NEXTEST_ROOT / "bin/cargo-nextest"),
    "bytes": 33831936,
    "sha256": "9c05bd3c7c5da1286b193873f12b37db386485fa483d8fa0554e68a53d9df550",
}
QUALIFICATION_REPORT_SHA = "9e564f3950575313034f55974303e56c236ac030e2c5f121d49791da0c4c09fa"
PREPARATION_SHA = "4ece02608c423456d0996de39c54129c6c759a1973a0e11f22b04f936b113cc3"
NATIVE_TERMINAL_SHA = "3325b116b998ddff0e586a3b983a2715339acb1b48e9215f5b92e9abfdde4946"
STAGES = ["format", "fmt-check", "harness-tests", "clippy", "test-build", "isolated-tests", "audit-isolated-tests", "release"]
COMMANDS = [
    {"workflow_step": "Check all targets", "argv": ["cargo", "check", "--locked", "--all-targets", "--all-features"]},
    {"workflow_step": "Test in isolated processes", "argv": ["cargo", "nextest", "run", "--locked", "--all-targets", "--all-features", "--test-threads", "1", "--retries", "0", "--no-fail-fast"]},
]
INVENTORY_COMMAND = ["cargo", "nextest", "list", "--locked", "--all-targets", "--all-features", "--message-format", "json"]
BINARY_NAMES = {"hepta-runtime", "hepta-runtime-jobctl", "native_process_driver"}


def need(value, message):
    if not value:
        raise RuntimeError(message)


def require_frozen_qualification():
    pins = [SOURCE_MAP_SHA, ISOLATED_SUMMARY_SHA, ISOLATED_AUDIT_SHA,
            QUALIFICATION_REPORT_SHA, PREPARATION_SHA, NATIVE_TERMINAL_SHA]
    need(all(type(pin) is str and len(pin) == 64
             and all(char in "0123456789abcdef" for char in pin) for pin in pins)
         and type(JOB_ID) is str and JOB_ID != "UNBOUND_ACTUAL_QUALIFICATION_JOB_ID"
         and len(JOB_ID.split("-")) == 3,
         "R28 qualification has not been frozen from actual original receipts; no plan or command may run")


def verify_r28_candidate_preparation(preparation, terminal, job_id, qualified, tests):
    """Verify the actual new cache-only R28 qualification; no future success is inferred."""
    need(isinstance(job_id, str) and re.fullmatch(r"[0-9a-f]{11,16}-[0-9a-f]{4}-[0-9a-f]{4}", job_id)
         and job_id not in {"1a1aa7fa690-fc05-43af", "1a1aaa6552d-fc05-459f", "1a1ab4cb0fc-fc05-4c3c",
                            "1a1ac274e49-fc05-5286", "1a1ac456b07-fc05-532a"},
         "the actual new R28 qualification job is required")
    need(terminal.get("job_id") == job_id and terminal.get("state") == "succeeded"
         and type(terminal.get("exit_code")) is int and terminal["exit_code"] == 0
         and all(terminal.get(key) is False for key in ("automatic_retry", "timed_out", "cancelled"))
         and all(terminal.get(key) is True for key in ("output_complete", "output_durable", "terminal_publication_confirmed"))
         and type(terminal.get("terminal_publication_protocol")) is int and terminal["terminal_publication_protocol"] == 1
         and terminal.get("log_synced") == {"stdout": True, "stderr": True}
         and terminal.get("log_errors") == {"stdout": None, "stderr": None}
         and terminal.get("log_truncated") == {"stdout": False, "stderr": False},
         "original R28 qualification has no complete successful native terminal proof")
    for stream in ("stdout", "stderr"):
        counts = terminal["log_bytes"][stream]
        need(set(counts) == {"seen", "stored"} and all(type(value) is int and value >= 0 for value in counts.values())
             and counts["seen"] == counts["stored"], "qualification native log byte custody differs")
    need(preparation["schema"] == "hepta-r28-qualified-parent-preparation/v1"
         and preparation["selected_proposal"] == "cache only" and preparation.get("optional_pidfd_selected") is False
         and preparation.get("finished_utc")
         and all(preparation.get(key) is True for key in ("passed", "candidate_qualified", "parent_source_qualified",
             "parent_lifecycle_rejection_preserved", "parent_inputs_unchanged"))
         and all(preparation.get(key) is False for key in ("candidate_adopted", "parent_candidate_adopted",
             "production_services_modified", "shared_hardlinks_created")), "actual R28 preparation is incomplete")
    need(preparation["source"] == str(SOURCE) and preparation["target"] == str(ROOT / "target-build")
         and preparation["qualification_output"] == str(CANDIDATE_DIR)
         and preparation["launcher"] == {"path": "/home/qian/hepta-runtime-optimization-20261105-r25/tools/prepare_and_qualify_r28_02.py",
             "bytes": 30059, "sha256": "6bef1776c36294d05a3796b2b4e3c79a07b15ed69122e3a2685705bfeb031239"}
         and preparation["input"] == {"path": "/home/qian/hepta-runtime-optimization-20261105-r25/tools/r28-qualification-02-input.json",
             "bytes": 82496, "sha256": "9173851d84e44421531df32ae2dcad9fd89a707664b2d7b8853965df2f24d3ae"},
         "R28 qualification launcher, input or private paths differ")
    # These are original negative outcomes and the actual read-only space observation.
    # They remain negative; no cleanup or successful inventory is inferred.
    preserved_admission = {'admission_absent_paths': ['/home/qian/hepta-runtime-optimization-20261105-r28/source',
                            '/home/qian/hepta-runtime-optimization-20261105-r28/target-build',
                            '/home/qian/hepta-runtime-optimization-20261105-r28/qualification-01',
                            '/home/qian/hepta-runtime-optimization-20261105-r28/preparation-02.json',
                            '/home/qian/hepta-runtime-optimization-20261105-r28/qualification-input-02.json',
                            '/home/qian/hepta-runtime-optimization-20261105-r28/qualification-terminal-status-02.json'],
 'cache_retirement_executed_by_this_qualifier': False,
 'cleanup_executed': False,
 'cleanup_operation': None,
 'original_admission_failure_preserved': True,
 'original_candidate_input': {'bytes': 34557,
                              'path': '/home/qian/hepta-runtime-optimization-20261105-r28/qualification-input-01.json',
                              'sha256': '0837e858fddf7df95229a5dac1dafdf6d904800caad46cb238ba18ecfaa93299'},
 'original_failed_admission': {'exit_code': 1,
                               'job_id': '1a1ac274e49-fc05-5286',
                               'label': 'original_failed_admission',
                               'native_read': {'bytes': 723,
                                               'sha256': '5a0beef68de943554f08936dacec1a66c4b8e2af66f6c7ea9aa9387cc852e35a'},
                               'original_complete_streams_proved': True,
                               'state': 'failed',
                               'stderr': {'bytes': 0,
                                          'sha256': 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855'},
                               'stdout': {'bytes': 131,
                                          'sha256': '3613580074731c44ad27d2687ec2e8c177fd81eef7d9b2148d0b8ef10df886fc'},
                               'terminal': {'bytes': 726,
                                            'sha256': '8dee0438ff40dc85288ff6d9ff6da9dfcdfc36092bbc12995bd99018f3d00d31'}},
 'original_failed_admission_inputs_unchanged': True,
 'original_native_read': {'bytes': 723,
                          'path': '/home/qian/hepta-runtime-optimization-20261105-r28/qualification-native-read-01.json',
                          'sha256': '5a0beef68de943554f08936dacec1a66c4b8e2af66f6c7ea9aa9387cc852e35a'},
 'original_native_terminal': {'bytes': 726,
                              'path': '/home/qian/hepta-runtime-optimization-20261105-r28/qualification-terminal-status-01.json',
                              'sha256': '8dee0438ff40dc85288ff6d9ff6da9dfcdfc36092bbc12995bd99018f3d00d31'},
 'original_preparation': {'bytes': 4671,
                          'path': '/home/qian/hepta-runtime-optimization-20261105-r28/preparation-01.json',
                          'sha256': 'abc26b3d49c2e57b608fe3aba792708e80de95340c1c8c210dced2844953fade'},
 'space_recovery_mode': 'observed_space_sufficient_no_cleanup',
 'space_recovery_observation': {'all_same_owner_reference_channels_inspected': False,
                                'available_bytes': 7478648832,
                                'cleanup_executed': False,
                                'cleanup_operation': None,
                                'copy_cache_bytes': 3080991421,
                                'excess_over_required_bytes': 1176431939,
                                'inventory_overall_passed': False,
                                'old_cache_absence_cause_inferred': False,
                                'original_inventory_native_exit_code': 1,
                                'original_inventory_native_state': 'failed',
                                'process_reference_scans_complete': False,
                                'required_headroom_bytes': 3221225472},
 'space_recovery_proofs': {'readonly_inventory': {'exit_code': 1,
                                                  'job_id': '1a1ac456b07-fc05-532a',
                                                  'label': 'readonly_inventory',
                                                  'native_read': {'bytes': 42578,
                                                                  'sha256': 'd232070f29ce310dd2f304f75bc661ebf937582f0b1e179cc94dd88e80e1dcb1'},
                                                  'original_complete_streams_proved': True,
                                                  'state': 'failed',
                                                  'stderr': {'bytes': 0,
                                                             'sha256': 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855'},
                                                  'stdout': {'bytes': 13686,
                                                             'sha256': '3c2e43bbaeb2914c6372653ba1ea79d196af451aed75a9cb9ce4fac313769dda'},
                                                  'terminal': {'bytes': 730,
                                                               'sha256': 'c06d88c67b142ad33bcab37cf4cd51d9235dd14cc0e046927cf5aa53429d365b'}}},
 'unchanged_disk_reserve_bytes': 3221225472}
    for name, expected_value in preserved_admission.items():
        need(preparation.get(name) == expected_value, "R28 preserved admission evidence differs: " + name)
    need(all(preparation.get(name) is True for name in
             ("original_admission_failure_preserved", "original_failed_admission_inputs_unchanged"))
         and all(preparation.get(name) is False for name in
                 ("cache_retirement_executed_by_this_qualifier", "cleanup_executed"))
         and preparation.get("cleanup_operation") is None, "R28 original failures or no-cleanup scope changed")
    original_names = ("original_preparation", "original_candidate_input", "original_native_terminal", "original_native_read")
    originals = {preparation[name]["path"]: preparation[name] for name in original_names}
    descriptors = preparation.get("original_file_identities")
    descriptor_keys = {"st_dev", "st_ino", "st_mode", "st_uid", "st_nlink", "st_size", "st_mtime_ns", "st_ctime_ns"}
    need(isinstance(descriptors, dict) and set(descriptors) == set(originals), "four original file identities required")
    for path, pin in originals.items():
        descriptor = descriptors[path]
        need(isinstance(descriptor, dict) and set(descriptor) == descriptor_keys
             and all(type(value) is int and value >= 0 for value in descriptor.values())
             and descriptor["st_ino"] > 0 and descriptor["st_uid"] == 1000 and descriptor["st_nlink"] == 1
             and descriptor["st_size"] == pin["bytes"] and descriptor["st_mode"] & 0o170000 == 0o100000
             and not descriptor["st_mode"] & 0o6000, "original preserved file descriptor differs: " + path)
        need(preparation["bound_parent_inputs"].get(path) == pin, "original preserved file final byte binding differs: " + path)
    known_original_descriptors = {
        '/home/qian/hepta-runtime-optimization-20261105-r28/preparation-01.json': {'st_ctime_ns': 1793889622435153369, 'st_dev': 2053, 'st_ino': 2259040, 'st_mode': 33152, 'st_mtime_ns': 1793889622435153369, 'st_nlink': 1, 'st_size': 4671, 'st_uid': 1000},
        '/home/qian/hepta-runtime-optimization-20261105-r28/qualification-input-01.json': {'st_ctime_ns': 1793889621996152717, 'st_dev': 2053, 'st_ino': 2259039, 'st_mode': 33152, 'st_mtime_ns': 1793889621996152717, 'st_nlink': 1, 'st_size': 34557, 'st_uid': 1000},
    }
    need(all(descriptors[path] == expected_value for path, expected_value in known_original_descriptors.items()),
         "original preparation/input descriptor identity differs from the actual inventory")
    need(type(preparation["cache_bytes"]) is int and preparation["cache_bytes"] > 0
         and type(preparation["disk_available_before_bytes"]) is int
         and preparation["disk_available_before_bytes"] >= preparation["cache_bytes"] + 3221225472,
         "actual R28 cache admission did not retain the original 3 GiB reserve")
    need(type(preparation["qualification_returncode"]) is int and preparation["qualification_returncode"] == 0
         and type(preparation["automatic_test_retries"]) is int and preparation["automatic_test_retries"] == 0,
         "R28 qualification did not finish once with exit zero")
    expected_changes = [{'path': 'src/mcp/runtime/jobs.rs',
  'before': {'bytes': 186504, 'sha256': '8a80623ccf9131e520ed5f25647200bd2086e4718b892eed90c1530a5ccb9283'},
  'after': {'bytes': 186541, 'sha256': '061c2576e3c1dd8a1e4f5bfd7d3498f7cc4141d6577d53365a9a4738c7980af6'}},
 {'path': 'src/mcp/runtime/ssh.rs',
  'before': {'bytes': 18943, 'sha256': '0c0bf93da7d8d391b79d026544dc7ff71974bd1eabb06e5fe319892174843189'},
  'after': {'bytes': 19820, 'sha256': 'b674dfcb60bc57c46a08f1ab1f424a8aadcdb2078abdcfdff30f71632e807b3d'}},
 {'path': 'src/mcp/runtime/ssh_tests.rs',
  'before': {'bytes': 4652, 'sha256': '39dacf3f7839b7a013b24b2ec63bd9cf7b51599ebaebc1e5e074cfb98ae79893'},
  'after': {'bytes': 4931, 'sha256': '98f18f6cd89776b7589a9864224683d49f4b0cb663467475aa721c52dfff0a57'}}]
    need(preparation["source_changes"] == expected_changes, "qualified selection is not the exact three-file cache-only change")
    before = preparation["source_before"]
    expected = dict(before)
    changed_paths = {change["path"] for change in expected_changes}
    need(len(before) == 221 and len(changed_paths) == 3, "R28 parent source-map or change count differs")
    for change in expected_changes:
        need(before[change["path"]] == change["before"]["sha256"], "R28 exact qualified parent preimage differs")
        expected[change["path"]] = change["after"]["sha256"]
    need(preparation["candidate_compilation_inputs"] == expected, "R28 pre-format source map differs")
    stages = ["format", "fmt-check", "harness-tests", "clippy", "test-build", "isolated-tests", "audit-isolated-tests", "release"]
    need(qualified["schema"] == "hepta-x230-composed-qualification/v1" and qualified["qualified"] is True
         and qualified.get("finished_utc") and qualified["source"] == str(SOURCE)
         and qualified["jobs"] == 2 and qualified["service_changes"] is False
         and type(qualified["automatic_test_retries"]) is int and qualified["automatic_test_retries"] == 0
         and [row["name"] for row in qualified["stages"]] == stages
         and all(type(row["returncode"]) is int and row["returncode"] == 0 for row in qualified["stages"]),
         "all eight original R28 qualification stages must pass")
    need(qualified["source_input"] == expected and qualified["source_tested"] == qualified["source_after"] == preparation["source_tested"]
         and set(qualified["source_after"]) == set(expected)
         and all(qualified["source_after"][name] == value for name, value in expected.items() if name not in changed_paths),
         "actual formatted R28 source differs from its qualified preparation")
    need(preparation["formatter_changed_paths"] == [name for name in expected if qualified["source_after"][name] != expected[name]]
         and qualified["harness_before"] == qualified["harness_after"] == preparation["harness_before"]
         and len(qualified["harness_after"]) == 19, "qualification formatter or original harness binding differs")
    counts = ("passed", "failed", "ignored", "selected", "retries")
    need(all(type(tests[key]) is int for key in counts)
         and [tests[key] for key in counts] == [1653, 0, 34, 1687, 0]
         and preparation["tests"] == tests, "original full R28 isolated test result is incomplete")
    return {"passed": True, "original_job_id": job_id, "selected_proposal": "cache only", "optional_pidfd_selected": False,
            "qualified_source_files": 221, "harness_files": 19, "stages": stages,
            "tests": {key: tests[key] for key in counts}, "candidate_adopted": False,
            "qualified_parent_R26_lifecycle_rejection_preserved": True,
            "original_failed_admission_preserved": True, "original_failed_inventory_preserved": True,
            "space_recovery_mode": "observed_space_sufficient_no_cleanup", "cleanup_executed": False}

def verify_preparation(value, qualified, qualification_identity, terminal):
    """Reuse the reviewed R28 cache-only gate and exact original entry paths."""
    verify_r28_candidate_preparation(value, terminal, JOB_ID, qualified, value["tests"])
    need(type(value.get("finished_utc")) is str and bool(value["finished_utc"])
         and value["qualification_report"] == qualification_identity
         and value["launcher"] == {
             "path": "/home/qian/hepta-runtime-optimization-20261105-r25/tools/prepare_and_qualify_r28_02.py",
             "bytes": 30059, "sha256": "6bef1776c36294d05a3796b2b4e3c79a07b15ed69122e3a2685705bfeb031239"}
         and value["input"] == {
             "path": "/home/qian/hepta-runtime-optimization-20261105-r25/tools/r28-qualification-02-input.json",
             "bytes": 82496, "sha256": "9173851d84e44421531df32ae2dcad9fd89a707664b2d7b8853965df2f24d3ae"},
         "actual R28 preparation path or exact qualifier/input identity differs")


def read_file(path, retain=False):
    path = Path(path)
    need(path.is_absolute() and path.resolve(strict=True) == path, "indirect input: " + str(path))
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK | os.O_CLOEXEC)
    try:
        before = os.fstat(fd)
        need(stat.S_ISREG(before.st_mode), "nonregular input: " + str(path))
        with os.fdopen(os.dup(fd), "rb") as stream:
            if retain:
                raw = stream.read()
                digest = hashlib.sha256(raw).hexdigest()
            else:
                raw = None
                digest = hashlib.file_digest(stream, "sha256").hexdigest()
        after = os.fstat(fd)
        fields = ("st_dev", "st_ino", "st_size", "st_mode", "st_uid", "st_mtime_ns", "st_ctime_ns")
        need(tuple(getattr(before, k) for k in fields) == tuple(getattr(after, k) for k in fields)
             == tuple(getattr(path.lstat(), k) for k in fields), "input changed: " + str(path))
    finally:
        os.close(fd)
    return {"path": str(path), "bytes": before.st_size, "sha256": digest}, raw


def verify_terminal(value):
    need(value.get("job_id") == JOB_ID and value.get("state") == "succeeded"
         and type(value.get("exit_code")) is int and value["exit_code"] == 0
         and all(value.get(k) is False for k in ("automatic_retry", "cancelled", "timed_out"))
         and all(value.get(k) is True for k in ("output_complete", "output_durable", "terminal_publication_confirmed"))
         and type(value.get("terminal_publication_protocol")) is int and value["terminal_publication_protocol"] == 1
         and value.get("log_synced") == {"stdout": True, "stderr": True}
         and value.get("log_errors") == {"stdout": None, "stderr": None}
         and value.get("log_truncated") == {"stdout": False, "stderr": False},
         "original qualification01 job lacks complete successful terminal proof")


def verify_qualification(value):
    need(value.get("schema") == "hepta-x230-composed-qualification/v1"
         and value.get("qualified") is True and value.get("finished_utc")
         and value.get("source") == str(SOURCE), "qualification01 is not completed and successful")
    need([row["name"] for row in value["stages"]] == STAGES
         and all(type(row["returncode"]) is int and row["returncode"] == 0 for row in value["stages"]),
         "all eight original qualification stages must pass")
    need(type(value.get("automatic_test_retries")) is int and value["automatic_test_retries"] == 0,
         "qualification retries must be zero")
    need(value["source_tested"] == value["source_after"] and len(value["source_after"]) == 221,
         "qualified source changed or inventory differs")
    need(value["harness_before"] == value["harness_after"] and len(value["harness_after"]) == 19,
         "original 19 qualification harness inputs changed")
    need(set(value["binaries"]) == BINARY_NAMES, "retained qualified binary set differs")


def main():
    require_frozen_qualification()
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--qualification", type=Path, default=QUALIFICATION / "report.json")
    parser.add_argument("--qualification-sha256", required=True)
    parser.add_argument("--terminal-status", type=Path, default=ROOT / "qualification-terminal-status-02.json")
    parser.add_argument("--terminal-status-sha256", required=True)
    parser.add_argument("--ci-manifest", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    need(args.qualification == QUALIFICATION / "report.json", "qualification path must be attempt01")
    need(args.terminal_status == ROOT / "qualification-terminal-status-02.json", "terminal path must be attempt02")
    need(args.out.is_absolute() and args.out.parent.resolve(strict=True) == args.out.parent
         and args.out.is_relative_to(ROOT) and not os.path.lexists(args.out), "fresh private plan output required")
    need(args.qualification_sha256 == QUALIFICATION_REPORT_SHA
         and args.terminal_status_sha256 == NATIVE_TERMINAL_SHA, "frozen actual R28 report or terminal pin differs")
    bindings = []

    def bind(path, digest=None, json_value=False, retain=False):
        identity, raw = read_file(path, retain=json_value or retain)
        need(digest is None or identity["sha256"] == digest, "bound SHA differs: " + str(path))
        bindings.append(identity)
        return identity, json.loads(raw) if json_value else raw

    terminal_identity, terminal = bind(args.terminal_status, args.terminal_status_sha256, json_value=True)
    verify_terminal(terminal)
    qualification_identity, qualified = bind(args.qualification, args.qualification_sha256, json_value=True)
    verify_qualification(qualified)
    preparation_identity, preparation = bind(ROOT / "preparation-02.json", PREPARATION_SHA, json_value=True)
    verify_preparation(preparation, qualified, qualification_identity, terminal)
    for key in ("launcher", "input"):
        actual_preparation_input, _ = bind(Path(preparation[key]["path"]), preparation[key]["sha256"])
        need(actual_preparation_input == preparation[key], "actual preparation input differs: " + key)
    ci_identity, ci = bind(args.ci_manifest, CI_MANIFEST_SHA, json_value=True)
    map_identity, source_map = bind(QUALIFICATION / "source-map.json", SOURCE_MAP_SHA, json_value=True)
    need(source_map == qualified["source_after"], "actual qualification source map differs")
    files = [SOURCE / name for name in ("Cargo.toml", "Cargo.lock", "rustfmt.toml")]
    for directory in ("src", "examples"):
        files.extend(path for path in (SOURCE / directory).rglob("*") if path.is_file())
    actual = {path.relative_to(SOURCE).as_posix(): bind(path)[0]["sha256"] for path in sorted(files)}
    need(actual == source_map, "actual compiler inputs differ from successful qualification01")
    harness = {path.name: bind(path)[0]["sha256"] for path in sorted((SOURCE / "tools/x230/20261028").glob("*.py"))}
    need(harness == qualified["harness_after"], "actual qualification harness differs")
    binaries = {}
    for name, expected in qualified["binaries"].items():
        path = Path(expected["path"])
        need(path == QUALIFICATION / name and os.access(path, os.X_OK), "qualified executable path differs")
        binaries[name] = bind(path, expected["sha256"])[0]

    summary_identity, summary = bind(QUALIFICATION / "isolated-tests/summary.json", ISOLATED_SUMMARY_SHA, json_value=True)
    need(preparation.get("tests") == summary, "preparation tests differ from the complete actual isolated summary")
    audit_identity, audit = bind(QUALIFICATION / "isolated-tests.audit.json", ISOLATED_AUDIT_SHA, json_value=True)
    need(summary.get("schema") == "hepta-isolated-libtest/v1" and summary.get("success") is True
         and summary.get("filter") == "" and summary.get("enumeration_errors") == []
         and summary.get("retries") == 0 and summary.get("failed") == 0,
         "isolated suite must be complete, unfiltered, successful and unretried")
    need(audit.get("schema") == "hepta-isolated-libtest-audit/v1" and audit.get("success") is True
         and audit.get("errors") == [] and "fatal_error" not in audit and audit.get("expected_filter") == "",
         "independent isolated-suite audit did not pass")
    counts = {key: summary[key] for key in ("passed", "failed", "ignored", "selected", "retries")}
    need(all(type(value) is int and value >= 0 for value in counts.values())
         and counts["passed"] > 0 and counts["selected"] == counts["passed"] + counts["ignored"],
         "invalid complete test counts")
    need(counts == {"passed": 1653, "failed": 0, "ignored": 34, "selected": 1687, "retries": 0},
         "full selected R28 suite counts differ")
    need(all(audit[key] == counts[key] for key in ("passed", "failed", "ignored", "selected"))
         and audit["executed"] == counts["passed"], "audited test counts differ")
    need(summary["source_manifest_path"] == str(QUALIFICATION / "source-map.json")
         and summary["source_manifest_sha256"] == map_identity["sha256"], "suite source binding differs")
    need(audit["input_sha256"]["summary.json"] == summary_identity["sha256"], "audited summary changed")
    for filename, digest in audit["input_sha256"].items():
        need(Path(filename).name == filename and filename not in {".", ".."}, "unsafe audit input name")
        bind(QUALIFICATION / "isolated-tests" / filename, digest)
    need(summary["artifacts_path"] == str(QUALIFICATION / "retained-artifacts.jsonl"), "Cargo artifact path differs")
    bind(QUALIFICATION / "retained-artifacts.jsonl", summary["artifacts_sha256"])
    target_inventory = []
    targets = {}
    for row in summary["binaries"]:
        path = Path(row["path"])
        need(path.parent == QUALIFICATION / "test-binaries", "retained test executable outside qualification01")
        test_binary = bind(path, row["sha256"])[0]
        target = {"target_name": row["target"]["name"], "target_kind": row["target"]["kind"]}
        need(str(path) not in targets, "duplicate test executable")
        targets[str(path)] = target
        target_inventory.append(dict(target, inventory_count=row["inventory_count"], ignored_names=row["ignored_names"], qualified_test_binary=test_binary))
    _, raw = bind(QUALIFICATION / "isolated-tests/tests.jsonl", audit["input_sha256"]["tests.jsonl"], retain=True)
    cases = []
    for line in raw.splitlines():
        row = json.loads(line)
        ignored = row["status"] == "ignored"
        need(row["status"] in {"passed", "ignored"} and row["attempt"] == (0 if ignored else 1)
             and row["executed"] is (not ignored), "invalid or retried case record")
        cases.append(dict(targets[row["binary"]], name=row["name"], ignored=ignored))
    cases.sort(key=lambda row: (row["target_name"], row["target_kind"], row["name"]))
    need(len(cases) == counts["selected"] and sum(row["ignored"] for row in cases) == counts["ignored"],
         "complete case ledger counts differ")
    need(len({(row["target_name"], tuple(row["target_kind"]), row["name"]) for row in cases}) == len(cases),
         "duplicate exact qualified case")

    for job_name in ("runtime-head-ci", "runtime-merge-ci"):
        commands = []
        for step in ci["workflow"]["jobs"][job_name]["steps"]:
            for line in step.get("run", "").replace("\\\n", " ").splitlines():
                if line.startswith("cargo check ") or line.startswith("cargo nextest run "):
                    commands.append({"workflow_step": step["name"], "argv": shlex.split(line)})
        need(commands == COMMANDS, "workflow Cargo check/nextest commands differ")
    nextest_identity, nextest = bind(NEXTEST_ROOT / "receipt.json", NEXTEST_RECEIPT_SHA, json_value=True)
    need(nextest.get("schema") == "hepta-r25-private-nextest-install-v1" and nextest.get("passed") is True
         and nextest["release_id"] == 329695549 and nextest["asset_id"] == 430502414
         and nextest["archive"]["sha256"] == "38fd6275e111b200bbbed1bd2ae91cbb0d7edd28504879875cff2b3d96f3f311"
         and nextest["nextest_version"]["returncode"] == 0
         and nextest["nextest_version"]["stdout"].startswith("cargo-nextest 0.9.137 (75ddba7e9 2026-05-26)"),
         "installed nextest receipt differs")
    need({key: nextest["binary"][key] for key in NEXTEST_BINARY} == NEXTEST_BINARY, "installed binary receipt differs")
    nextest_binary, _ = bind(Path(NEXTEST_BINARY["path"]), NEXTEST_BINARY["sha256"])
    need(nextest_binary == NEXTEST_BINARY and os.access(nextest_binary["path"], os.X_OK), "installed nextest binary differs")

    config_inventory = []
    for name in (".cargo/config", ".cargo/config.toml", ".config/nextest.toml", "rust-toolchain", "rust-toolchain.toml"):
        path = SOURCE / name
        config_inventory.append({"path": str(path), "exists": os.path.lexists(path),
                                 "identity": bind(path)[0] if os.path.lexists(path) else None})
    for expected in bindings:
        need(read_file(Path(expected["path"]))[0] == expected, "input changed before plan publication")
    for row in config_inventory:
        need(os.path.lexists(row["path"]) is row["exists"], "tool configuration appeared or disappeared")
    report = {
        "schema": "hepta-r28-materialized-exact-rust-ci-plan/v1", "attempt": "01",
        "created_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
        "executed": False, "hosted_actions_passed": False,
        "preparation": preparation_identity,
        "qualification": qualification_identity, "qualification_terminal_status": terminal_identity,
        "qualification_job_id": JOB_ID, "source_map": map_identity,
        "source": str(SOURCE), "source_files": actual, "qualified_binaries": binaries,
        "qualification_harness": harness, "qualification_summary": summary_identity,
        "qualification_independent_audit": audit_identity, "qualification_counts": counts,
        "workflow_head": ci["head_commit"], "workflow_git_blob": ci["workflow_git_blob"], "ci_manifest": ci_identity,
        "commands": [dict(row, cwd=str(SOURCE)) for row in COMMANDS],
        "inventory_command": {"argv": INVENTORY_COMMAND, "cwd": str(SOURCE), "timeout_seconds": 900,
            "scope": "One unfiltered structured inventory; Cargo may build and test binaries execute --list, but no test case is executed by this command."},
        "nextest_install_receipt": nextest_identity, "nextest_binary": nextest_binary,
        "expected_nextest": {"passed": counts["passed"], "failed": 0, "skipped": counts["ignored"],
            "total": counts["selected"], "retries": 0, "test_target_inventory": target_inventory,
            "exact_cases": cases,
            "case_inventory_sha256": hashlib.sha256(json.dumps(cases, sort_keys=True, separators=(",", ":")).encode()).hexdigest(),
            "comparison": "Require full exact unfiltered case inventory and ignored set, plus footer counts; zero-test targets may be omitted from a runner's display, but no nonempty target or case may disappear."},
        "environment": {"PATH": str(NEXTEST_ROOT / "bin") + ":/home/qian/.cargo/bin:/usr/local/bin:/usr/bin:/bin",
            "RUSTUP_TOOLCHAIN": "1.95.0", "CARGO_HOME": "/home/qian/hepta-runtime-optimization-20261023/cargo-home-a32-a33-r02",
            "CARGO_TARGET_DIR": str(ROOT / "target-build"), "CARGO_BUILD_JOBS": "2", "CARGO_INCREMENTAL": "0",
            "CARGO_NET_OFFLINE": "true", "RUST_TEST_THREADS": "1", "TOKIO_WORKER_THREADS": "2",
            "PYTHONDONTWRITEBYTECODE": "1", "PYTHONNOUSERSITE": "1",
            "CARGO_TERM_COLOR": "never", "NEXTEST_STATUS_LEVEL": "pass",
            "NEXTEST_FINAL_STATUS_LEVEL": "fail", "NEXTEST_SUCCESS_OUTPUT": "never"},
        "reporting_environment_note": "Pinned nextest0.9.137 supported reporting-only environment settings preserve original run argv, emit every completed success once, suppress successful test stdout and keep color-free evidence. They do not alter case selection, retries or execution concurrency.",
        "remove_environment_prefixes": ["HEPTA_", "SSH_", "RUST_TEST_", "NEXTEST_"],
        "remove_environment_keys": ["RUSTFLAGS", "CARGO_ENCODED_RUSTFLAGS", "RUSTDOCFLAGS", "RUSTC_WRAPPER", "RUSTC_WORKSPACE_WRAPPER", "PYTHONPATH", "PYTHONHOME", "RUST_LOG"],
        "tool_configuration_inventory": config_inventory, "umask": "0022", "input_bindings": bindings,
        "execution_contract": {"fresh_evidence_directory": str(ROOT / "rust-ci-01"), "automatic_retries": 0,
            "cargo_clean": False, "check_timeout_seconds": 1800, "nextest_timeout_seconds": 3600,
            "combined_timeout_seconds": 5400, "inventory_timeout_seconds": 900,
            "outer_budget_seconds": 6600, "retain_full_original_stdout_stderr": True,
            "no_extra_nextest_filters_or_weaker_flags": True, "no_candidate_workload_or_service_change": True,
            "exact_version_preflight": "Record cargo/rustc 1.95.0 and cargo nextest 0.9.137; verify which cargo-nextest resolves to the bound private binary.",
            "scheduling": "Run only after the bound original qualification01 terminal success, with no overlapping compiler or measurement campaign.",
            "ownership": "Record original Popen PID/birth/group, supervise and wait/reap only that owned process group; unknown cleanup or timed-out dispatch must be reconciled before any resubmission.",
            "identity": "Recheck every bound input and configuration presence immediately before and after; require unchanged source, retained qualified binaries and nextest executable.",
            "pass_requires": "Both exact commands exit0, no timeout or automatic retry, complete case/count match to actual qualified inventory, unchanged inputs, and original owned child/group absent."},
        "limits": ["External command evidence does not mark hosted GitHub Actions passed.",
            "Offline Cargo, private completed qualification01 target/cache and prebuilt pinned nextest are explicit environment differences from GitHub's online clean runner and cargo-install step.",
            "Publishing the tested source and prospective-merge Git tree binding remain separate.",
            "No measurement, deployment or candidate adoption is implied by materializing this plan."],
    }
    with args.out.open("x") as stream:
        json.dump(report, stream, sort_keys=True, indent=2)
        stream.write("\n")
    print(json.dumps({"plan": read_file(args.out)[0], "executed": False, "qualification_counts": counts}))


if __name__ == "__main__":
    main()
