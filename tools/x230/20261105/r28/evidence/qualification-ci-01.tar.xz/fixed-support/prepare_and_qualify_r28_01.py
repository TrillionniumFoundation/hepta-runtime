#!/usr/bin/env python3
# Copyright 2026 TrillionniumFoundation
# SPDX-License-Identifier: Apache-2.0
"""Qualify cache-only R28; preserve qualified R26 and its rejected lifecycle."""
import argparse
import datetime
import hashlib
import json
import os
from pathlib import Path
import shutil
import stat
import subprocess
import time
import traceback

ROOT = Path('/home/qian/hepta-runtime-optimization-20261105-r28')
PARENT = Path('/home/qian/hepta-runtime-optimization-20261105-r26')
ACCEPTED = Path('/home/qian/hepta-runtime-optimization-20261105-r24')
OLD_SOURCE = PARENT / 'source'
SOURCE = ROOT / 'source'
TARGET = ROOT / 'target-build'
OUTPUT = ROOT / 'qualification-01'
INPUT = Path('/home/qian/hepta-runtime-optimization-20261105-r25/tools/r28-qualification-01-input.json')
CHANGED_PATHS = ('src/mcp/runtime/jobs.rs', 'src/mcp/runtime/ssh.rs', 'src/mcp/runtime/ssh_tests.rs')
BASE_REPORT_SHA = '2ee6d3b65a04a883acf6200d2802f89f5c934b7f8ed9a3ffc5bfc805cf6fc69b'
BASE_MAP_SHA = '7099d5752076faab911394eb06246c6d2da86c0f9a8bf79faa3ab8403b85a50c'
REJECTION_SHA = '50b745129004ba2e8f85e179bf41930c84588f8bbbf015f3cbc03479b20dcb79'
REJECTION_GATES_SHA = '69ce967668c3bd14c17509afe4d20291c7b9b3ec1ff57feeb850815f78083d3d'
REJECTION_TERMINAL_SHA = 'b35defa7d9127ff0940f41f44eb4c42899ec66377d1dad0c9cefef18a3251ff4'
PUBLICATION_SHA = '38866c01fac54133c8a88e25bee90ea4a551e7273614f493bf44522a8273d3ca'
TRANSFORM_SHA = 'a84556ce097012fc670f8a5fd9856554d0b9f83c04ff131a23e9c0ed06a23bdd'
STAGES = ['format', 'fmt-check', 'harness-tests', 'clippy', 'test-build',
          'isolated-tests', 'audit-isolated-tests', 'release']


def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def encoded(value):
    return (json.dumps(value, sort_keys=True, indent=2, allow_nan=False) + '\n').encode()


def stamp(value):
    return tuple(getattr(value, key) for key in ('st_dev', 'st_ino', 'st_mode',
                 'st_uid', 'st_nlink', 'st_size', 'st_mtime_ns', 'st_ctime_ns'))


def read(path, expected=None, retain=False):
    path = Path(path)
    assert path.is_absolute() and path.resolve(strict=True) == path, str(path)
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_CLOEXEC | os.O_NONBLOCK)
    try:
        before = os.fstat(fd)
        assert stat.S_ISREG(before.st_mode) and before.st_uid == os.geteuid()
        assert before.st_nlink == 1 and not before.st_mode & (stat.S_ISUID | stat.S_ISGID)
        assert 0 <= before.st_size <= 1024**3
        digest, size, blocks = hashlib.sha256(), 0, []
        while block := os.read(fd, 1024 * 1024):
            size += len(block)
            assert size <= before.st_size
            digest.update(block)
            if retain:
                blocks.append(block)
        assert size == before.st_size and stamp(before) == stamp(os.fstat(fd)) == stamp(path.lstat())
        assert expected is None or digest.hexdigest() == expected, str(path)
        return {'path': str(path), 'bytes': size, 'sha256': digest.hexdigest()}, b''.join(blocks)
    finally:
        os.close(fd)


def source_map(root):
    paths = [root / name for name in ('Cargo.toml', 'Cargo.lock', 'rustfmt.toml')]
    for name in ('src', 'examples'):
        paths.extend(path for path in (root / name).rglob('*') if path.is_file())
    return {path.relative_to(root).as_posix(): read(path)[0]['sha256'] for path in sorted(paths)}


def harness_map(root):
    return {path.name: read(path)[0]['sha256']
            for path in sorted((root / 'tools/x230/20261028').glob('*.py'))}


def check_terminal(raw, job_id, state="succeeded", exit_code=0):
    value = json.loads(raw)
    assert value['job_id'] == job_id and value['state'] == state and value['exit_code'] == exit_code
    assert all(value[k] is True for k in ('output_complete', 'output_durable', 'terminal_publication_confirmed'))
    assert all(value[k] is False for k in ('automatic_retry', 'cancelled', 'timed_out'))
    assert value['terminal_publication_protocol'] == 1
    for name in ('stdout', 'stderr'):
        assert value['log_synced'][name] is True and value['log_truncated'][name] is False
        assert value['log_errors'][name] is None
        assert value['log_bytes'][name]['seen'] == value['log_bytes'][name]['stored']


def quiescence():
    deadline, samples = time.monotonic() + 300, []
    while True:
        active = []
        for path in Path('/proc').glob('[0-9]*/comm'):
            try:
                name = path.read_text().strip()
                if name in ('cargo', 'rustc', 'rust-lld', 'ld.lld'):
                    active.append({'pid': int(path.parent.name), 'name': name})
            except (FileNotFoundError, ProcessLookupError, PermissionError):
                pass
        samples.append({'utc': utc(), 'compiler_processes': active})
        if not active:
            return samples
        assert time.monotonic() < deadline, 'compiler quiescence unavailable; no cache copy or qualification started'
        if len(samples) == 1:
            print(json.dumps({'waiting_for_compiler_quiescence': active}), flush=True)
        time.sleep(2)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--input-sha256', required=True)
    parser.add_argument('--launcher-sha256', required=True)
    args = parser.parse_args()
    launcher_identity, _ = read(Path(__file__).resolve(), args.launcher_sha256)
    input_identity, input_raw = read(INPUT, args.input_sha256, retain=True)
    payload = json.loads(input_raw)
    assert payload['schema'] == 'hepta-r28-cache-only-qualification-input/v1'
    assert payload['production_selection'] == 'cache-only: fixed Python cancellation command'
    assert payload['optional_pidfd_selected'] is False
    assert not os.path.lexists(ROOT), str(ROOT)
    ROOT.mkdir(mode=0o700)
    receipt = {'schema': 'hepta-r28-qualified-parent-preparation/v1', 'started_utc': utc(),
               'passed': False, 'candidate_qualified': False, 'candidate_adopted': False,
               'parent_source_qualified': False, 'parent_candidate_adopted': False,
               'parent_lifecycle_rejection_preserved': False, 'automatic_test_retries': 0,
               'production_services_modified': False, 'shared_hardlinks_created': False,
               'input': input_identity, 'launcher': launcher_identity, 'selected_proposal': 'cache only', 'optional_pidfd_selected': False}
    with (ROOT / 'qualification-input-01.json').open('xb') as stream:
        stream.write(input_raw)
    saved_inputs = {}

    def bind(path, digest):
        identity, raw = read(path, digest, retain=True)
        saved_inputs[str(path)] = identity
        return json.loads(raw)

    result_code = 1
    try:
        parent = bind(PARENT / 'qualification-01/report.json', BASE_REPORT_SHA)
        parent_map = bind(PARENT / 'qualification-01/source-map.json', BASE_MAP_SHA)
        assert parent['qualified'] is True and parent['finished_utc']
        assert parent['source_tested'] == parent['source_after'] == parent_map == source_map(OLD_SOURCE)
        assert len(parent_map) == 221 and [s['name'] for s in parent['stages']] == STAGES
        assert all(s['returncode'] == 0 for s in parent['stages']) and parent['automatic_test_retries'] == 0
        native_identity, native_raw = read(PARENT / 'qualification-terminal-status-01.json',
            'ec8c2f665ed87bc361885f97a41ea4774f7840be26f21d1b13be0da6118ab0a7', retain=True)
        check_terminal(native_raw, '1a1ab4cb0fc-fc05-4c3c')
        saved_inputs[native_identity['path']] = native_identity
        rejection = bind(PARENT / 'lifecycle-campaign-02/report.json', REJECTION_SHA)
        gates = bind(PARENT / 'lifecycle-abba-02/gates.json', REJECTION_GATES_SHA)
        assert rejection['finished_utc'] and rejection['passed'] is False
        assert rejection['adoption_passed'] is False and rejection['measurement_attribution_valid'] is True
        assert rejection['inputs_unchanged'] is True and rejection['source_inputs_unchanged'] is True
        assert rejection['candidate_binary_sha256'] == parent['binaries']['hepta-runtime']['sha256']
        assert [stage['name'] for stage in rejection['stages']] == ['lifecycle-tool-tests', 'normal-lifecycle-abba']
        assert [stage['returncode'] for stage in rejection['stages']] == [0, 1]
        assert all(stage['waited_and_reaped'] is True and stage['owned_process_absent'] is True
                   and stage['owned_process_group_absent'] is True for stage in rejection['stages'])
        assert gates['verified'] is True and gates['passed'] is False
        assert gates['order'] == 'ABBA' and gates['round_count'] == 4 and gates['automatic_retries'] == 0
        failures = sorted((name, check) for name, group in gates['comparisons'].items()
                          if group['adoption_required'] for check, passed in group['gates'].items() if not passed)
        assert failures == [('concurrent_cancel', 'rpc_p95'), ('concurrent_cancel', 'throughput')]
        rejection_terminal_raw = payload['parent_lifecycle_terminal_text'].encode()
        assert len(rejection_terminal_raw) == 726 and hashlib.sha256(rejection_terminal_raw).hexdigest() == REJECTION_TERMINAL_SHA
        check_terminal(rejection_terminal_raw, '1a1abcac847-fc05-509a', state='failed', exit_code=1)
        receipt['parent_lifecycle_terminal'] = {
            'origin': 'unchanged actual native terminal bytes embedded in the pinned qualification input',
            'job_id': '1a1abcac847-fc05-509a', 'state': 'failed', 'exit_code': 1,
            'bytes': len(rejection_terminal_raw), 'sha256': REJECTION_TERMINAL_SHA}
        receipt.update(parent_source_qualified=True, parent_lifecycle_rejection_preserved=True)
        publication = bind(ACCEPTED / 'final-publication-readback.json', PUBLICATION_SHA)
        assert publication['commit'] == 'baab4def80be7af015b2e7a594cb302f66c4130e'
        assert publication['verified'] is True and publication['candidate_adopted'] is True
        for binary in parent['binaries'].values():
            identity, _ = read(binary['path'], binary['sha256'])
            saved_inputs[identity['path']] = identity
        transform_raw = payload['transform_text'].encode()
        assert hashlib.sha256(transform_raw).hexdigest() == TRANSFORM_SHA
        transform = json.loads(transform_raw)
        assert transform['schema'] == 'hepta-r28-fixed-cancellation-cache-transform/v1'
        assert transform['optional_pidfd_selected'] is False
        assert [change['relative_path'] for change in transform['files']] == list(CHANGED_PATHS)
        expected, candidates = dict(parent_map), {}
        for change in transform['files']:
            relative = change['relative_path']
            assert change['before']['sha256'] == parent_map[relative]
            identity, original = read(OLD_SOURCE / relative, change['before']['sha256'], retain=True)
            assert identity['bytes'] == change['before']['bytes']
            candidate = original.decode('utf-8')
            for operation in change['operations']:
                assert operation['required_matches'] == candidate.count(operation['old']) == 1
                candidate = candidate.replace(operation['old'], operation['new'], 1)
            candidate_raw = candidate.encode('utf-8')
            assert len(candidate_raw) == change['after']['bytes']
            assert hashlib.sha256(candidate_raw).hexdigest() == change['after']['sha256']
            candidates[relative] = candidate_raw
            expected[relative] = change['after']['sha256']
        assert payload['candidate_source_map'] == expected
        assert sorted(p for p in expected if expected[p] != parent_map[p]) == sorted(CHANGED_PATHS)
        harness = parent['harness_after']
        assert len(harness) == 19 and parent['harness_before'] == harness_map(OLD_SOURCE) == harness
        receipt['compiler_quiescence'] = quiescence()
        cache = PARENT / 'target-build'
        cache_files = [path for path in cache.rglob('*') if path.is_file()]
        cache_bytes = sum(path.stat().st_size for path in cache_files)
        disk = os.statvfs(ROOT)
        available = disk.f_bavail * disk.f_frsize
        assert cache_files and available >= cache_bytes + 3 * 1024**3, (available, cache_bytes)
        preparation_started = time.monotonic()
        shutil.copytree(OLD_SOURCE, SOURCE)
        for relative, candidate_raw in candidates.items():
            (SOURCE / relative).write_bytes(candidate_raw)
        assert source_map(SOURCE) == expected and source_map(OLD_SOURCE) == parent_map
        assert harness_map(SOURCE) == harness_map(OLD_SOURCE) == harness
        copy_started = time.monotonic()
        shutil.copytree(cache, TARGET)
        receipt.update(source=str(SOURCE), target=str(TARGET), qualification_output=str(OUTPUT),
            source_before=parent_map, candidate_compilation_inputs=expected, harness_before=harness,
            cache_source=str(cache), cache_file_count=len(cache_files), cache_bytes=cache_bytes,
            cache_reused=True, cache_source_source_qualified=True, private_cache_copy_seconds=time.monotonic()-copy_started,
            disk_available_before_bytes=available, preparation_seconds=time.monotonic()-preparation_started,
            source_changes=[{'path': change['relative_path'], 'before': change['before'], 'after': change['after']}
                            for change in transform['files']])
        (ROOT / 'preparation-01.json').write_bytes(encoded(receipt))
        print(json.dumps({'phase': 'prepared', 'source_changes': list(CHANGED_PATHS), 'automatic_test_retries': 0}), flush=True)
        argv = ['/usr/bin/python3', '-B', str(SOURCE / 'tools/x230/20261028/qualify.py'),
            '--source', str(SOURCE), '--output', str(OUTPUT), '--target', str(TARGET),
            '--cargo-home', '/home/qian/hepta-runtime-optimization-20261023/cargo-home-a32-a33-r02',
            '--jobs', '2', '--stage-timeout', '3600']
        receipt['qualification_argv'] = argv
        result = subprocess.run(argv, cwd=SOURCE, timeout=10800)
        receipt['qualification_returncode'] = result.returncode
        for path, identity in saved_inputs.items():
            assert read(path)[0] == identity, 'bound parent evidence changed: ' + path
        assert source_map(OLD_SOURCE) == parent_map and harness_map(OLD_SOURCE) == harness_map(SOURCE) == harness
        read(INPUT, args.input_sha256)
        read(Path(__file__).resolve(), args.launcher_sha256)
        receipt['parent_inputs_unchanged'] = True
        qualified_identity, qualified_raw = read(OUTPUT / 'report.json', retain=True)
        qualified = json.loads(qualified_raw)
        receipt['qualification_report'] = qualified_identity
        receipt['candidate_qualified'] = qualified['qualified'] is True
        if result.returncode != 0:
            assert qualified['qualified'] is False
            result_code = result.returncode
        else:
            assert qualified['qualified'] is True and qualified['finished_utc']
            assert qualified['source_tested'] == qualified['source_after'] == source_map(SOURCE)
            assert all(s['returncode'] == 0 for s in qualified['stages'])
            assert [s['name'] for s in qualified['stages']] == STAGES
            assert qualified['automatic_test_retries'] == 0
            assert all(qualified['source_after'][p] == expected[p] for p in expected if p not in CHANGED_PATHS)
            test_summary = json.loads(read(OUTPUT / 'isolated-tests/summary.json', retain=True)[1])
            assert [test_summary[k] for k in ('passed','failed','ignored','selected','retries')] == [1653,0,34,1687,0]
            receipt.update(passed=True, tests=test_summary, source_tested=qualified['source_after'],
                           formatter_changed_paths=[p for p in expected if qualified['source_after'][p] != expected[p]])
            result_code = 0
    except Exception as error:
        receipt['error'] = f'{type(error).__name__}: {error}'
        receipt['error_trace'] = traceback.format_exc()
    finally:
        receipt['finished_utc'] = utc()
        receipt['bound_parent_inputs'] = saved_inputs
        (ROOT / 'preparation-01.json').write_bytes(encoded(receipt))
        print(json.dumps({'preparation_and_qualification_passed': receipt['passed'],
                          'candidate_qualified': receipt['candidate_qualified'], 'error': receipt.get('error')}), flush=True)
    return result_code


if __name__ == '__main__':
    raise SystemExit(main())
