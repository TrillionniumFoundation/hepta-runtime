#!/usr/bin/env python3
"""Verify the installed fixed Python CI subset and execute each gate once."""

import argparse
import base64
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import signal
import stat
import subprocess
import sys
import tarfile
import time

ROOT = Path("/home/qian/hepta-runtime-optimization-20261105-r28")
SOURCE_ROOT = Path("/home/qian/hepta-runtime-optimization-20261105-r25")
PACKAGE = Path("/home/qian/hepta-runtime-r25-ci-inputs-01.tar.gz")
PACKAGE_BYTES = 498954
PACKAGE_SHA256 = "4063559cfe1cef5952802fdbe038f529ce3be73deb1cdfc3ca71c084dc173270"
MANIFEST_SHA256 = "bf0df5f7d19ebd149854fbf75887fb0fb136f18a63a0c240abf8420655fb195e"
RUNNER_SHA256 = "de69c48bc00273541f505d4462f57bb40ed85e291847cceb671e700534d822aa"
INPUT_HEAD = "1aa98d3c94d0253999a491c967ccc94b314e87c8"
SOURCE = SOURCE_ROOT / "ci-gates"
OUTPUT = ROOT / "python-ci-02"
LAUNCH = ROOT / "python-ci-launch-02"
INSTALL_RECEIPT = SOURCE_ROOT / "tool-package-install-01.json"
INSTALL_RECEIPT_SHA256 = "6f8adc4698405c93f632a2c3534c1cba8337e57522c08ca94b2be2ba23f4a7d7"
DEPENDENCY_RECEIPT = SOURCE_ROOT / "ci-toolchain/nextest-0.9.137/receipt.json"
DEPENDENCY_RECEIPT_SHA256 = "2bbae481b3fbc6ac6d06a22bfe22e9500f5190b97ccddb16e8aba1ef1ed34f9d"
REMOVE_PREFIXES = ("HEPTA_", "SSH_", "RUST_TEST_", "NEXTEST_")
REMOVE_KEYS = ("PYTHONPATH", "PYTHONHOME", "RUSTFLAGS", "CARGO_ENCODED_RUSTFLAGS",
               "RUSTDOCFLAGS", "RUSTC_WRAPPER", "RUSTC_WORKSPACE_WRAPPER", "RUST_LOG")


TOOLS = ROOT / "python-ci-tools-02"
QUALIFIED_SOURCE = ROOT / "source"
QUALIFICATION_VERIFIER = TOOLS / "qualification_binding_01.py"
QUALIFICATION_VERIFIER_SHA256 = 'be079079f261668b194d32ba09a1d72ba4051b70d1d71ce7981b06f3be6eaab1'
ACTUAL_BINDING = TOOLS / "actual-python-input-01.json"
PARENT_PROOF = TOOLS / "candidate-parent-proof-01.json"
PARENT_PROOF_SHA256 = "4635a698aa7d61ba8dff66e8e152b7f7398d1b0df9285c147318f2eedb4b5326"
CANDIDATE_GIT_PARENT = "06530d71f82e925ba1766c0e63f54798b3ba0cb6"
CANDIDATE_GIT_TREE = "ed8983ddfb866075673286af806fdb491acb2ed4"
CANDIDATE_GIT_GRANDPARENT = "bfa0d6113d675bb9f597baa474f913c3a12df37a"
QUALIFICATION_PATHS = {
    "report": ROOT / "qualification-01/report.json",
    "terminal": ROOT / "qualification-terminal-status-02.json",
    "preparation": ROOT / "preparation-02.json",
    "map": ROOT / "qualification-01/source-map.json",
    "summary": ROOT / "qualification-01/isolated-tests/summary.json",
    "audit": ROOT / "qualification-01/isolated-tests.audit.json",
}
ORIGINAL_TREE_PREFIXES = {
    "github_tree.json": ".github", "workflows_tree.json": ".github/workflows",
    "tests_tree_recursive.json": "tests", "deploy_tree_recursive.json": "deploy",
    "src_tree_recursive.json": "src", "20261028_tree_recursive.json": "tools/x230/20261028",
    "20261029_tree_recursive.json": "tools/x230/20261029", "20261030_tree_recursive.json": "tools/x230/20261030",
}


def identity(path):
    body = path.read_bytes()
    return {"bytes": len(body), "sha256": hashlib.sha256(body).hexdigest()}


def write_json(path, value):
    with path.open("x") as stream:
        json.dump(value, stream, indent=2, sort_keys=True)
        stream.write("\n")
        stream.flush()
        os.fsync(stream.fileno())


def verify_installed_package():
    if not stat.S_ISREG(PACKAGE.lstat().st_mode):
        raise ValueError("staged archive is not a regular file")
    actual = identity(PACKAGE)
    if actual != {"bytes": PACKAGE_BYTES, "sha256": PACKAGE_SHA256}:
        raise ValueError("staged archive identity mismatch")
    if not stat.S_ISREG(INSTALL_RECEIPT.lstat().st_mode):
        raise ValueError("package install receipt is not a regular file")
    installed = identity(INSTALL_RECEIPT)
    if installed["sha256"] != INSTALL_RECEIPT_SHA256:
        raise ValueError("package install receipt identity mismatch")
    installation = json.loads(INSTALL_RECEIPT.read_text())
    if (installation["passed"] is not True or installation["tests_executed"] is not False
            or installation["qualified_source_modified"] is not False):
        raise ValueError("package installation receipt is not the qualified preparation")
    matches = [p for p in installation["packages"] if p["destination"] == str(SOURCE_ROOT / "ci-gates")]
    if len(matches) != 1:
        raise ValueError("install receipt lacks the unique expected CI destination")
    package = matches[0]
    if (package["archive_bytes"] != PACKAGE_BYTES or package["archive_sha256"] != PACKAGE_SHA256
            or package["archive"] != "/home/qian/hepta-runtime-r25-ci-inputs-01.tar.gz"):
        raise ValueError("install receipt does not identify the frozen package")
    recorded = {row["path"]: {key: row[key] for key in ("bytes", "sha256")} for row in package["files"]}
    if len(recorded) != 103 or len(package["files"]) != 103:
        raise ValueError("install receipt has a different member set")
    if SOURCE.resolve(strict=True) != SOURCE or not stat.S_ISDIR(SOURCE.lstat().st_mode):
        raise ValueError("existing CI package directory is not a direct real directory")
    with tarfile.open(PACKAGE, "r:gz") as archive:
        members = archive.getmembers()
        seen = set()
        if len(members) != 103 or sum(m.size for m in members) != 2205863:
            raise ValueError("frozen package member count or expanded bytes mismatch")
        for member in members:
            relative = PurePosixPath(member.name)
            if (not member.isfile() or member.issparse() or relative.is_absolute()
                    or not relative.parts or ".." in relative.parts or "\\" in member.name
                    or member.name in seen or member.mode & 0o022):
                raise ValueError("unsafe, duplicate or writable archive member")
            if member.size < 0 or member.size > 1024 * 1024:
                raise ValueError("archive member outside frozen package bounds")
            seen.add(member.name)
            target = SOURCE / member.name
            source = archive.extractfile(member)
            if source is None:
                raise ValueError("missing regular archive content")
            body = source.read(member.size + 1)
            source.close()
            if len(body) != member.size:
                raise ValueError("archive member content length mismatch")
            if target.resolve(strict=True) != target or not stat.S_ISREG(target.lstat().st_mode):
                raise ValueError("installed member is not a direct regular file")
            info = target.stat()
            if info.st_mode & 0o022 or bool(info.st_mode & 0o111) != bool(member.mode & 0o111):
                raise ValueError("installed member has different or writable mode")
            expected = {"bytes": len(body), "sha256": hashlib.sha256(body).hexdigest()}
            if identity(target) != expected or recorded.get(member.name) != expected:
                raise ValueError("installed member differs from archive/install receipt: " + member.name)
        actual_names = set()
        for path in SOURCE.rglob("*"):
            info = path.lstat()
            if stat.S_ISDIR(info.st_mode):
                continue
            if not stat.S_ISREG(info.st_mode):
                raise ValueError("unexpected special or symlink member in installed package")
            actual_names.add(path.relative_to(SOURCE).as_posix())
        if actual_names != seen or set(recorded) != seen:
            raise ValueError("installed package file set differs from frozen archive")
    return {"archive": actual, "installation_receipt": installed, "verified_regular_members": len(seen)}


def need(value, reason):
    if not value:
        raise ValueError(reason)


def body_identity(body):
    return {"bytes": len(body), "sha256": hashlib.sha256(body).hexdigest()}


# Exact inherited source identities confirmed by the original read-only metadata
# job 1a1aca4ad22-fc05-561a. No JSON, tool or unlisted source is eligible.
SOURCE_MODE_EXCEPTIONS = {
    QUALIFIED_SOURCE / "src/mcp/runtime/jobs_cancel_io_tests.rs": {
        "bytes": 17145,
        "sha256": "b9553137fe32d873536252c4371bcb57dfceb4e8fac988937b7c552a871f889a",
    },
    QUALIFIED_SOURCE / "src/mcp/runtime/jobs_cancel_read_tests.rs": {
        "bytes": 14542,
        "sha256": "ff92e72b71a8afc23edda7e686c66f87c13ac76dfa3b5c8a8b8e124383b3bf87",
    },
}


def qualified_source_mode_allowed(path, expected, info):
    known = SOURCE_MODE_EXCEPTIONS.get(path)
    return bool(known is not None and type(expected) is str
                and expected == known["sha256"]
                and info.st_mode == 0o100660 and info.st_uid == 1000
                and info.st_gid == 1000 and info.st_nlink == 1
                and info.st_size == known["bytes"])


def checked_read(path, expected=None, *, qualified_source=False):
    need(path.is_absolute() and path.resolve(strict=True) == path, "direct absolute input required")
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK | os.O_CLOEXEC)
    with os.fdopen(fd, "rb") as stream:
        before = os.fstat(stream.fileno())
        mode_allowed = (not before.st_mode & 0o022 or
                        (qualified_source is True and qualified_source_mode_allowed(path, expected, before)))
        need(stat.S_ISREG(before.st_mode) and before.st_uid == os.geteuid()
             and before.st_nlink == 1 and mode_allowed
             and 0 < before.st_size <= 16 * 1024 * 1024,
             "unsafe or oversized bound input: " + str(path))
        body = stream.read(before.st_size + 1)
        after = os.fstat(stream.fileno())
    current = path.lstat()
    fields = ("st_dev", "st_ino", "st_mode", "st_uid", "st_gid", "st_nlink", "st_size", "st_mtime_ns", "st_ctime_ns")
    need(len(body) == before.st_size and all(getattr(before, key) == getattr(after, key)
         == getattr(current, key) for key in fields), "bound input changed during read")
    if expected is not None:
        need(body_identity(body)["sha256"] == (expected if isinstance(expected, str) else expected["sha256"]),
             "bound input SHA differs: " + str(path))
        if isinstance(expected, dict):
            need(type(expected["bytes"]) is int and len(body) == expected["bytes"], "bound input size differs")
    return body


def checked_tree(document):
    """Rebuild the represented complete directories using the original Git tree ordering."""
    need(document.get("truncated") is False, "a complete Git tree response is required")
    entries = document["tree"]
    need(isinstance(entries, list) and len({row["path"] for row in entries}) == len(entries),
         "duplicate Git tree path")
    by_parent = {}
    for entry in entries:
        relative = PurePosixPath(entry["path"])
        need(not relative.is_absolute() and relative.as_posix() == entry["path"]
             and ".." not in relative.parts and relative.parts, "unsafe Git tree path")
        parent, _, leaf = entry["path"].rpartition("/")
        by_parent.setdefault(parent, []).append({**entry, "leaf": leaf})
    expected = {"": document["sha"], **{row["path"]: row["sha"] for row in entries if row["type"] == "tree"}}
    need(set(by_parent) <= set(expected), "tree response omits an ancestor")
    for directory, children in sorted(by_parent.items()):
        ordered = sorted(children, key=lambda row: (row["leaf"] + ("/" if row["type"] == "tree" else "")).encode())
        body = b"".join(row["mode"].lstrip("0").encode() + b" " + row["leaf"].encode()
                        + b"\0" + bytes.fromhex(row["sha"]) for row in ordered)
        actual = hashlib.sha1(b"tree " + str(len(body)).encode() + b"\0" + body).hexdigest()
        need(actual == expected[directory], "Git tree body does not match its immutable object")
    need("" in by_parent, "empty or omitted Git root tree")
    return {row["path"]: row for row in entries}


def verify_git_inputs(manifest, proof, historical):
    need(proof["schema"] == "hepta-r28-published-python-parent-proof/v1"
         and proof["repository"] == "TrillionniumFoundation/hepta-runtime"
         and proof["candidate_git_parent"] == CANDIDATE_GIT_PARENT
         and proof["candidate_git_parent_tree"] == CANDIDATE_GIT_TREE
         and proof["candidate_git_parent_parent"] == CANDIDATE_GIT_GRANDPARENT
         and proof["origin_input_head"] == INPUT_HEAD
         and proof["origin_manifest_sha256"] == MANIFEST_SHA256,
         "candidate Git parent proof differs")
    documents = proof["fetched_documents"]
    need(set(documents) == {"commit", "root", "tools", "x230"}, "four immutable Git GET documents required")
    commit = documents["commit"]
    need(commit["sha"] == CANDIDATE_GIT_PARENT and commit["tree"]["sha"] == CANDIDATE_GIT_TREE
         and [row["sha"] for row in commit["parents"]] == [CANDIDATE_GIT_GRANDPARENT],
         "original Git commit metadata binding differs")
    root = checked_tree(documents["root"])
    tools = checked_tree(documents["tools"])
    x230 = checked_tree(documents["x230"])
    need(documents["root"]["sha"] == CANDIDATE_GIT_TREE
         and root["tools"]["sha"] == documents["tools"]["sha"]
         and tools["x230"]["sha"] == documents["x230"]["sha"], "candidate tools tree chain differs")
    need(set(historical) == set(ORIGINAL_TREE_PREFIXES), "exact original package tree documents required")
    entries = {}
    trees = {}
    for name, prefix in ORIGINAL_TREE_PREFIXES.items():
        document = historical[name]
        need(document["sha"] == manifest["git_tree_proofs"][name]["root_tree"],
             "original package tree differs from its frozen manifest")
        trees[prefix] = checked_tree(document)
        for relative, entry in trees[prefix].items():
            if entry["type"] == "blob":
                full = prefix + "/" + relative
                need(full not in entries or entries[full] == entry, "overlapping original blob proof differs")
                entries[full] = entry
    for prefix in (".github", "tests", "deploy", "src"):
        name = next(name for name, value in ORIGINAL_TREE_PREFIXES.items() if value == prefix)
        need(root[prefix]["type"] == "tree" and root[prefix]["sha"] == historical[name]["sha"],
             "published candidate subtree differs from original Python inputs: " + prefix)
    need(trees[".github"]["workflows"]["sha"] == historical["workflows_tree.json"]["sha"],
         "workflow directory chain differs")
    for day in ("20261028", "20261029", "20261030"):
        need(x230[day]["type"] == "tree" and x230[day]["sha"] == historical[day + "_tree_recursive.json"]["sha"],
             "candidate discovery subtree differs: " + day)
    inputs = manifest["input_files"]
    need(len(inputs) == 85 and len({row["path"] for row in inputs}) == 85
         and manifest["head_commit"] == INPUT_HEAD and len(manifest["python_gates"]) == 18,
         "original 85 dependency inputs and 18 workflow commands required")
    for row in inputs:
        actual = entries[row["path"]]
        need(actual["type"] == "blob" and actual["mode"] == row["git_mode"]
             and actual["sha"] == row["git_blob"] and actual["size"] == row["bytes"],
             "candidate parent input blob/mode/length differs: " + row["path"])
    need(entries[manifest["workflow_path"]]["sha"] == manifest["workflow_git_blob"],
         "candidate workflow blob differs from frozen 18-command workflow")
    discovery = {}
    for directory in ("tools/x230/20261028", "tools/x230/20261029", "tools/x230/20261030"):
        discovery[directory] = sorted(directory + "/" + name for name, row in trees[directory].items()
                                      if row["type"] == "blob" and PurePosixPath(name).name.endswith("_tests.py"))
    need(discovery == manifest["python_discovery_files"], "candidate Git discovery set differs")
    return {"passed": True, "candidate_git_parent": CANDIDATE_GIT_PARENT,
            "candidate_git_parent_tree": CANDIDATE_GIT_TREE, "historical_input_head": INPUT_HEAD,
            "dependency_inputs": 85, "workflow_commands": 18, "workflow_git_blob": manifest["workflow_git_blob"],
            "discovery_sets": discovery, "candidate_qualification_result_inferred": False,
            "remote_git_required_at_execution": False}


def verify_candidate_binding(manifest, binding_sha):
    binding_raw = checked_read(ACTUAL_BINDING, binding_sha)
    binding = json.loads(binding_raw)
    need(binding["schema"] == "hepta-r28-python-ci-actual-input/v1"
         and binding["candidate_git_parent"] == CANDIDATE_GIT_PARENT
         and binding["manifest_sha256"] == MANIFEST_SHA256
         and binding["parent_proof_sha256"] == PARENT_PROOF_SHA256
         and binding["qualification_verifier_sha256"] == QUALIFICATION_VERIFIER_SHA256
         and binding["python_ci_executed"] is False and binding["hosted_actions_passed"] is False
         and set(binding["qualification_receipts"]) == set(QUALIFICATION_PATHS),
         "actual R28 Python candidate binding differs")
    raw = {}
    for key, path in QUALIFICATION_PATHS.items():
        expected = binding["qualification_receipts"][key]
        need(expected["path"] == str(path), "actual qualification receipt path differs")
        raw[key] = checked_read(path, expected)
    verifier_raw = checked_read(QUALIFICATION_VERIFIER, QUALIFICATION_VERIFIER_SHA256)
    namespace = {"__name__": "_checked_r28_python_qualification_gate", "__file__": str(QUALIFICATION_VERIFIER)}
    exec(compile(verifier_raw, str(QUALIFICATION_VERIFIER), "exec"), namespace)
    validation = namespace["verify_six_receipts"](raw, binding["original_qualification_job_id"])
    need(validation == binding["qualification_validation"], "actual qualification proof differs")
    proof = json.loads(checked_read(PARENT_PROOF, PARENT_PROOF_SHA256))
    historical = {name: json.loads(checked_read(SOURCE / "raw" / name)) for name in ORIGINAL_TREE_PREFIXES}
    git_binding = verify_git_inputs(manifest, proof, historical)
    source_map = json.loads(raw["map"])
    original_inputs = {row["path"]: row for row in manifest["input_files"]}
    overlap = sorted(set(source_map) & set(original_inputs))
    need(overlap == ["src/mcp/runtime/fileio.py"], "qualified source and Python dependency overlap differs")
    for relative in overlap:
        need(source_map[relative] == original_inputs[relative]["sha256"],
             "R28 qualified Python dependency differs from its Git-parent input")
    changes = json.loads(raw["preparation"])["source_changes"]
    need(not {row["path"] for row in changes} & set(original_inputs), "selected Rust cache changes affect Python inputs")
    for relative, expected_sha in source_map.items():
        path = PurePosixPath(relative)
        need(not path.is_absolute() and path.as_posix() == relative and path.parts and ".." not in path.parts,
             "unsafe actual qualified source path")
        checked_read(QUALIFIED_SOURCE / relative, expected_sha, qualified_source=True)
    return {"passed": True, "actual_input": {"path": str(ACTUAL_BINDING), **body_identity(binding_raw)},
            "qualification_validation": validation, "candidate_git_parent_binding": git_binding,
            "qualified_source_map": body_identity(raw["map"]), "qualified_sources_rechecked": len(source_map),
            "qualified_python_overlap": {name: source_map[name] for name in overlap},
            "selected_cache_changes_outside_python_inputs": True,
            "private_compiler_snapshot_not_required_to_contain_all_published_python_inputs": True,
            "python_ci_result_reused_from_R25": False}


RECOVERY_INPUT = TOOLS / "original-preflight-recovery-02.json"
ORIGINAL_LAUNCH = ROOT / "python-ci-launch-01"
ORIGINAL_OUTPUT = ROOT / "python-ci-01"
ORIGINAL_LAUNCHER = ROOT / "python-ci-tools-01/launch_python_ci_01.py"
ORIGINAL_LAUNCHER_IDENTITY = {"bytes": 25415, "sha256": "57f0ed9ab6304824e06751ebc0ba1c0fbd406d07f37301c0be81e6ee49c85b5c"}
ORIGINAL_JOB_ID = "1a1ac97d8cb-fc05-55a2"
METADATA_JOB_ID = "1a1aca4ad22-fc05-561a"
ORIGINAL_EVIDENCE = {
    "failed_start": {"bytes": 2474, "sha256": "edc0b84ce9fea731f218fa0ed02c17917c13eb01dadacf84ea6a59a9dc3e7383"},
    "failed_terminal": {"bytes": 1063, "sha256": "ed3d9b76997d3b22eadf8824e3b2472cdb36062cca24512fd4a789476a194a6b"},
    "failed_read": {"bytes": 5033, "sha256": "c154dab11d41b32719f4fa8895e3e5a7325766342a5acf5c3f64edd283b6f79f"},
    "failed_receipt": {"bytes": 1506, "sha256": "3b24569825c641d07249d71d9e064d703ee760e728eac96c979345bb2774dd96"},
    "metadata_terminal": {"bytes": 1066, "sha256": "9f8dbc4876a32dcfb7419cbcfce7a01422b76b4a3b2c7db9f7736475040f9320"},
    "metadata_read": {"bytes": 23051, "sha256": "42bdf14849241988f7b3da42e5abd8b8b66784cfba8bb17e8ce8c136e1e9c935"},
    "metadata_report": {"bytes": 6996, "sha256": "50384e10e6af28703fd4a9f291573719d1ed1653330e2300807d27c3f4fc6650"},
}


def original_dto(raw, expected_job):
    envelope = json.loads(raw)
    need(envelope["request"]["host"] == "x230", "original native host differs")
    result = envelope["result"]
    need(result.get("isError") is False and len(result["content"]) == 1
         and result["content"][0]["type"] == "text", "original native reply is not one successful RPC")
    value = json.loads(result["content"][0]["text"])
    need(value.get("job_id", value.get("job", {}).get("id")) == expected_job,
         "original native job identity differs")
    return envelope["request"], value


def original_complete_streams(terminal_raw, read_raw, job_id, state, exit_code, stdout_bytes):
    status_request, terminal = original_dto(terminal_raw, job_id)
    read_request, reading = original_dto(read_raw, job_id)
    need(status_request["job_id"] == read_request["job_id"] == job_id
         and terminal["state"] == state and type(terminal["exit_code"]) is int
         and terminal["exit_code"] == exit_code
         and all(terminal[k] is True for k in ("output_complete", "output_durable", "terminal_publication_confirmed"))
         and terminal["terminal_publication_protocol"] == 1
         and all(terminal[k] is False for k in ("automatic_retry", "cancelled", "timed_out"))
         and terminal["log_synced"] == {"stdout": True, "stderr": True}
         and terminal["log_errors"] == {"stdout": None, "stderr": None}
         and terminal["log_truncated"] == {"stdout": False, "stderr": False},
         "original native strong terminal differs")
    streams = {}
    for channel, size in (("stdout", stdout_bytes), ("stderr", 0)):
        row = reading[channel]
        body = bytes.fromhex(row["bytes_hex"])
        need(terminal["log_bytes"][channel] == {"seen": size, "stored": size}
             and read_request[channel + "_offset"] == 0
             and row["offset"] == 0 and row["next_offset"] == row["size"] == size == len(body)
             and row["eof"] is True and row["text"] == body.decode("utf-8"),
             "original native complete stream differs")
        streams[channel] = body
    return streams


def verify_original_preflight_failure(recovery_sha):
    raw = checked_read(RECOVERY_INPUT, recovery_sha)
    recovery = json.loads(raw)
    need(recovery["schema"] == "hepta-r28-python-ci-preflight-recovery/v1"
         and recovery["original_failed_job_id"] == ORIGINAL_JOB_ID
         and recovery["metadata_job_id"] == METADATA_JOB_ID
         and recovery["source_modified"] is False and recovery["source_permissions_modified"] is False
         and recovery["old_ci_rerun"] is False and recovery["previous_tests_passed_inferred"] is False
         and set(recovery["originals"]) == set(ORIGINAL_EVIDENCE),
         "fixed original preflight recovery binding differs")
    originals = {}
    for name, expected in ORIGINAL_EVIDENCE.items():
        original = base64.b64decode(recovery["originals"][name], validate=True)
        need(body_identity(original) == expected, "original recovery evidence differs: " + name)
        originals[name] = original
    request, started = original_dto(originals["failed_start"], ORIGINAL_JOB_ID)
    expected_args = ["-I", "-B", str(ORIGINAL_LAUNCHER), "--launcher-sha256",
                     ORIGINAL_LAUNCHER_IDENTITY["sha256"], "--actual-input-sha256",
                     "b60562acab3655df24199a055bc426b998681cd5ba2294967d516e5e59878f73"]
    job = started["job"]
    need(request["args"] == job["args"] == expected_args
         and request["executable"] == job["executable"] == "/usr/bin/python3"
         and request["cwd"] == job["cwd"] == str(ROOT)
         and request["idempotency_key"] == job["idempotency_key"] == "hepta-r28-python-ci-20261105-01"
         and job["request_digest"] == "f72eb31513f0b5b0a21e7a9c7f3c9f1857992058624a1bdf69796f677c20146f"
         and job["launch_state"] == "launched" and started["reused"] is False,
         "original launch binding differs")
    failed = original_complete_streams(originals["failed_terminal"], originals["failed_read"],
                                      ORIGINAL_JOB_ID, "failed", 1, 1356)
    receipt = json.loads(originals["failed_receipt"])
    need(json.loads(failed["stdout"]) == receipt and receipt["passed"] is False
         and receipt["schema"] == "hepta-r28-python-ci-one-time-launch-v1"
         and receipt["launcher_source"] == ORIGINAL_LAUNCHER_IDENTITY
         and receipt["error"] == {"type": "ValueError", "message": "unsafe or oversized bound input"}
         and receipt["retry_count"] == 0 and receipt["package_verification"]["verified_regular_members"] == 103
         and receipt["runner"] == {"bytes": 9723, "sha256": RUNNER_SHA256}
         and receipt["manifest"] == {"bytes": 45857, "sha256": MANIFEST_SHA256}
         and receipt["finished_unix"] >= receipt["started_unix"]
         and not set(receipt) & {"candidate_binding_before", "argv", "environment", "runner_pid",
                                "runner_returncode", "report", "gates_executed"},
         "original failure is not the preserved preflight-only outcome")
    metadata_streams = original_complete_streams(originals["metadata_terminal"], originals["metadata_read"],
                                                METADATA_JOB_ID, "succeeded", 0, 6996)
    need(metadata_streams["stdout"] == originals["metadata_report"], "original metadata stdout differs")
    metadata = json.loads(originals["metadata_report"])
    need(metadata["schema"] == "hepta-r28-python-ci-mode-metadata/v1" and metadata["passed"] is True
         and metadata["original_failed_job_id"] == ORIGINAL_JOB_ID
         and metadata["effective_uid"] == metadata["effective_gid"] == 1000
         and metadata["filesystem_mutated"] is False and metadata["ci_executed"] is False
         and metadata["errors"] == [] and metadata["qualified_runtime_or_ci_pass_inferred"] is False
         and metadata["original_launch_directory_names"] == ["receipt.json"]
         and metadata["only_original_failure_receipt"] is True
         and metadata["original_python_ci_output"] == {
             "path": str(ORIGINAL_OUTPUT), "absent": True, "identity_if_present": None},
         "actual read-only metadata or original absence proof differs")
    directories = {row["path"]: row for row in metadata["directories"]}
    expected_directories = {str(path) for path in (Path("/home"), Path("/home/qian"), ROOT,
                            QUALIFIED_SOURCE, QUALIFIED_SOURCE / "src", QUALIFIED_SOURCE / "src/mcp",
                            QUALIFIED_SOURCE / "src/mcp/runtime", ORIGINAL_LAUNCH)}
    need(len(metadata["directories"]) == 8 and set(directories) == expected_directories,
         "exact original source ancestry required")
    critical = ("st_dev", "st_ino", "st_mode", "st_uid", "st_gid")
    for name, row in directories.items():
        path = Path(name)
        need(row["stable"] is True and row["kind"] == "directory"
             and path.resolve(strict=True) == path, "original directory is indirect or unstable")
        if path not in (Path("/home"), Path("/home/qian")):
            need(row["identity"]["st_mode"] == 0o40700
                 and row["identity"]["st_uid"] == row["identity"]["st_gid"] == 1000,
                 "qualified source ancestry was not private")
        fd = os.open(path, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW | os.O_CLOEXEC)
        try:
            current, linked = os.fstat(fd), path.lstat()
            need(stat.S_ISDIR(current.st_mode) and all(getattr(current, key) == getattr(linked, key)
                 == row["identity"][key] for key in critical), "original directory ownership/path changed")
        finally:
            os.close(fd)
    files = {row["path"]: row for row in metadata["files"]}
    receipt_path = ORIGINAL_LAUNCH / "receipt.json"
    need(len(metadata["files"]) == 3 and set(files) == {str(path) for path in SOURCE_MODE_EXCEPTIONS} | {str(receipt_path)},
         "exact original two sources and failure receipt required")
    fields = ("st_dev", "st_ino", "st_mode", "st_uid", "st_gid", "st_nlink", "st_size", "st_mtime_ns", "st_ctime_ns")
    for name, row in files.items():
        path = Path(name)
        need(row["stable"] is True and row["kind"] == "regular", "original file metadata is unstable")
        if path in SOURCE_MODE_EXCEPTIONS:
            expected = SOURCE_MODE_EXCEPTIONS[path]
            need({key: row[key] for key in ("bytes", "sha256")} == expected
                 and row["matches_actual_qualified_source"] is True
                 and row["identity"]["st_mode"] == 0o100660
                 and row["identity"]["st_uid"] == row["identity"]["st_gid"] == 1000,
                 "original mode exception was not observed for the exact source")
            checked_read(path, expected["sha256"], qualified_source=True)
        else:
            need(row["matches_original_preflight_failure"] is True
                 and base64.b64decode(row["original_bytes_base64"], validate=True) == originals["failed_receipt"],
                 "original remote failure receipt differs")
            need(checked_read(path, ORIGINAL_EVIDENCE["failed_receipt"]) == originals["failed_receipt"],
                 "original failure receipt bytes changed")
        current = path.lstat()
        need(all(getattr(current, key) == row["identity"][key] for key in fields),
             "original source or failure receipt identity changed")
    checked_read(ORIGINAL_LAUNCHER, ORIGINAL_LAUNCHER_IDENTITY)
    need(not os.path.lexists(ORIGINAL_OUTPUT)
         and sorted(path.name for path in ORIGINAL_LAUNCH.iterdir()) == ["receipt.json"],
         "original failed attempt gained CI outputs")
    return {"passed": True, "recovery_input": body_identity(raw), "original_failed_job_id": ORIGINAL_JOB_ID,
            "original_state": "failed", "original_exit_code": 1, "original_native_stdout": body_identity(failed["stdout"]),
            "original_native_stderr": body_identity(failed["stderr"]), "original_evidence": ORIGINAL_EVIDENCE,
            "original_runner_started": False, "original_ci_output_absent": True,
            "metadata_job_id": METADATA_JOB_ID, "qualified_source_permissions_modified": False,
            "previous_tests_passed_inferred": False, "source_exception_count": 2,
            "generic_bound_input_mode_policy_unchanged": True, "bound_input_limit_bytes": 16 * 1024 * 1024}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--launcher-sha256", required=True)
    parser.add_argument("--actual-input-sha256", required=True)
    parser.add_argument("--recovery-input-sha256", required=True)
    args = parser.parse_args()
    need(Path(__file__) == TOOLS / "launch_python_ci_02.py", "fixed installed R28 Python launcher path required")
    checked_read(Path(__file__), args.launcher_sha256)
    if os.geteuid() == 0:
        raise SystemExit("Python fixture gates must run as the unprivileged X230 user")
    if sys.version_info < (3, 11):
        raise SystemExit("Python 3.11 or newer is required")
    for path in (Path("/home"), Path("/home/qian"), ROOT):
        if not stat.S_ISDIR(path.lstat().st_mode):
            raise SystemExit("expected real task parent is unavailable")
    if OUTPUT.exists() or OUTPUT.is_symlink():
        raise SystemExit("Python CI output attempt already exists; refusing reuse")
    LAUNCH.mkdir(mode=0o700, exist_ok=False)
    receipt = {"schema": "hepta-r28-python-ci-one-time-launch-v1", "passed": False,
               "started_unix": time.time(), "launcher_source": identity(Path(__file__)),
               "input_head_commit": INPUT_HEAD,
               "scope": "18 published workflow commands with 85 dependency inputs, bound to the fixed R28 candidate Git parent and actual qualified R28 source",
               "historical_runner_schema_retained": True, "hosted_actions_passed": False,
               "rust_executed": False, "performance_executed": False,
               "lifecycle_harness_tests_executed": False, "retry_count": 0}
    try:
        receipt["original_preflight_failure"] = verify_original_preflight_failure(args.recovery_input_sha256)
        if (DEPENDENCY_RECEIPT.resolve(strict=True) != DEPENDENCY_RECEIPT
                or not stat.S_ISREG(DEPENDENCY_RECEIPT.lstat().st_mode)):
            raise ValueError("dependency receipt is not a direct regular file")
        receipt["dependency_receipt"] = identity(DEPENDENCY_RECEIPT)
        if receipt["dependency_receipt"] != {"bytes": 3554, "sha256": DEPENDENCY_RECEIPT_SHA256}:
            raise ValueError("dependency receipt identity mismatch")
        dependencies = json.loads(DEPENDENCY_RECEIPT.read_text())
        jsonschema = dependencies["jsonschema_probe"]
        if (dependencies["passed"] is not True or jsonschema["returncode"] != 0
                or json.loads(jsonschema["stdout"])["discoverable"] is not True
                or dependencies["rg_probe"]["returncode"] != 0):
            raise ValueError("required existing Python CI dependencies were not verified")
        receipt["package_verification"] = verify_installed_package()
        runner = SOURCE / "run_ci_python_gates.py"
        manifest_path = SOURCE / "ci-gate-manifest.json"
        receipt["runner"] = identity(runner)
        receipt["manifest"] = identity(manifest_path)
        if receipt["runner"]["sha256"] != RUNNER_SHA256 or receipt["manifest"]["sha256"] != MANIFEST_SHA256:
            raise ValueError("extracted runner/manifest identity mismatch")
        manifest = json.loads(manifest_path.read_text())
        if manifest["head_commit"] != INPUT_HEAD or len(manifest["python_gates"]) != 18:
            raise ValueError("unexpected Python input commit or gate count")
        receipt["candidate_binding_before"] = verify_candidate_binding(manifest, args.actual_input_sha256)
        environment = dict(os.environ)
        original_home = environment.get("HOME")
        removed = sorted(key for key in environment if key.startswith(REMOVE_PREFIXES) or key in REMOVE_KEYS)
        for key in removed:
            environment.pop(key)
        environment["PATH"] = "/usr/bin:/bin"
        environment["PYTHONDONTWRITEBYTECODE"] = "1"
        environment["PYTHONUNBUFFERED"] = "1"
        if environment.get("HOME") != original_home:
            raise ValueError("HOME must remain unchanged")
        command = ["/usr/bin/python3", "-B", str(runner), "--source", str(SOURCE / "ci-inputs"),
                   "--manifest", str(manifest_path), "--manifest-sha256", MANIFEST_SHA256,
                   "--out", str(OUTPUT), "--gate-timeout", "600"]
        receipt["argv"] = command
        receipt["environment"] = {"removed_key_names": removed, "removed_prefixes": REMOVE_PREFIXES,
                                  "removed_keys": REMOVE_KEYS, "home_unchanged": True,
                                  "path": "/usr/bin:/bin", "no_environment_values_dumped": True,
                                  "set": {"PYTHONDONTWRITEBYTECODE": "1", "PYTHONUNBUFFERED": "1"}}
        write_json(LAUNCH / "preflight.json", receipt)
        # The original runner owns per-gate timeout/cleanup; propagate signals to
        # that runner and allow it to close its owned fixture process group.
        with (LAUNCH / "runner.stdout.log").open("xb") as stdout, (LAUNCH / "runner.stderr.log").open("xb") as stderr:
            child = subprocess.Popen(command, cwd=ROOT, env=environment, stdin=subprocess.DEVNULL,
                                     stdout=stdout, stderr=stderr)
            def relay(signum, _frame):
                if child.poll() is None:
                    child.send_signal(signum)
            signal.signal(signal.SIGINT, relay)
            signal.signal(signal.SIGTERM, relay)
            receipt["runner_pid"] = child.pid
            receipt["runner_returncode"] = child.wait()
            stdout.flush()
            stderr.flush()
            os.fsync(stdout.fileno())
            os.fsync(stderr.fileno())
        receipt["runner_stdout"] = identity(LAUNCH / "runner.stdout.log")
        receipt["runner_stderr"] = identity(LAUNCH / "runner.stderr.log")
        report_path = OUTPUT / "report.json"
        receipt["report"] = {"path": str(report_path), **identity(report_path)}
        report = json.loads(report_path.read_text())
        receipt["gates_executed"] = len(report["gates"])
        receipt["failed_gates"] = [gate["id"] for gate in report["gates"] if not gate["passed"]]
        receipt["candidate_binding_after"] = verify_candidate_binding(manifest, args.actual_input_sha256)
        need(receipt["candidate_binding_after"] == receipt["candidate_binding_before"], "candidate binding changed during Python CI")
        need(verify_original_preflight_failure(args.recovery_input_sha256) == receipt["original_preflight_failure"],
             "original preflight evidence or private source ancestry changed during Python CI")
        checked_read(Path(__file__), args.launcher_sha256)
        receipt["passed"] = (receipt["runner_returncode"] == 0 and report["passed"] is True
                             and len(report["gates"]) == 18 and report["retry_count"] == 0
                             and report["head_commit"] == INPUT_HEAD
                             and report["manifest_sha256"] == MANIFEST_SHA256
                             and report["harness_sha256"] == RUNNER_SHA256
                             and report["final_inputs_unchanged"] is True)
    except Exception as error:
        receipt["error"] = {"type": type(error).__name__, "message": str(error)[:2000]}
    receipt["finished_unix"] = time.time()
    write_json(LAUNCH / "receipt.json", receipt)
    print(json.dumps(receipt), flush=True)
    return 0 if receipt["passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
