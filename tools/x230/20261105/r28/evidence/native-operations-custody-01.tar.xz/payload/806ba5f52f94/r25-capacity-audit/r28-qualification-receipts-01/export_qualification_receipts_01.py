#!/usr/bin/env python3
"""Export only six actual R28 qualification JSON bodies; no qualification or CI execution."""
import argparse
import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import stat
import types

ROOT = Path('/home/qian/hepta-runtime-optimization-20261105-r28')
STAGE = Path('/home/qian/hepta-runtime-optimization-20261105-r25/tools')
SELF = STAGE / 'r28_export_qualification_receipts_01.py'
INPUT = STAGE / 'r28_qualification_receipts_input_01.json'
HELPER = STAGE / 'r26_export_stable_archive_03.py'
HELPER_SHA = '34ce88cc28da10e1167dabaf6e3480aa42f5e6e76a29472d93959334aa9ec2ed'
OUT = ROOT / 'qualification-receipts-export-01'
ARCHIVE = 'qualification-receipts-01.tar.gz'
FILES = {
    'preparation-02.json': ROOT / 'preparation-02.json',
    'qualification-native-terminal-02.json': ROOT / 'qualification-terminal-status-02.json',
    'qualification-report-01.json': ROOT / 'qualification-01/report.json',
    'qualified-source-map-01.json': ROOT / 'qualification-01/source-map.json',
    'isolated-tests-summary-01.json': ROOT / 'qualification-01/isolated-tests/summary.json',
    'isolated-tests-audit-01.json': ROOT / 'qualification-01/isolated-tests.audit.json',
}
STAGES = ['format', 'fmt-check', 'harness-tests', 'clippy', 'test-build',
          'isolated-tests', 'audit-isolated-tests', 'release']
COUNTS = {'passed': 1653, 'failed': 0, 'ignored': 34, 'selected': 1687, 'retries': 0}
HEX = re.compile(r'[0-9a-f]{64}\Z')
JOB = re.compile(r'[0-9a-f]+-[0-9a-f]+-[0-9a-f]+\Z')
MAX_FILE = 16 * 1024**2
MAX_TOTAL = 32 * 1024**2


def need(value, reason):
    if not value:
        raise RuntimeError(reason)


def load_helper():
    need(HELPER.resolve(strict=True) == HELPER, 'indirect reviewed archive helper')
    fd = os.open(HELPER, os.O_RDONLY | os.O_NOFOLLOW | os.O_CLOEXEC | os.O_NONBLOCK)
    try:
        before = os.fstat(fd)
        need(stat.S_ISREG(before.st_mode) and before.st_uid == os.geteuid()
             and before.st_nlink == 1 and before.st_size == 12842, 'reviewed helper descriptor differs')
        with os.fdopen(os.dup(fd), 'rb') as stream:
            raw = stream.read(131073)
        fields = ('st_dev', 'st_ino', 'st_uid', 'st_mode', 'st_nlink', 'st_size', 'st_mtime_ns', 'st_ctime_ns')
        need(len(raw) == before.st_size and hashlib.sha256(raw).hexdigest() == HELPER_SHA
             and all(getattr(before, key) == getattr(os.fstat(fd), key) == getattr(HELPER.lstat(), key)
                     for key in fields), 'reviewed helper bytes or identity changed')
    finally:
        os.close(fd)
    module = types.ModuleType('_hepta_r28_bound_receipt_archive')
    module.__file__ = str(HELPER)
    exec(compile(raw, str(HELPER), 'exec'), module.__dict__)
    return module


def bind_input(value):
    need(type(value) is dict and set(value) == {'schema', 'original_qualification_job_id', 'files'}
         and value['schema'] == 'hepta-r28-fixed-qualification-receipts-input/v1', 'fixed input schema differs')
    job_id = value['original_qualification_job_id']
    need(type(job_id) is str and JOB.fullmatch(job_id), 'actual original qualification job is unbound')
    need(type(value['files']) is dict and set(value['files']) == set(FILES), 'exact six original inputs required')
    total = 0
    for name, path in FILES.items():
        pin = value['files'][name]
        need(type(pin) is dict and set(pin) == {'source_path', 'bytes', 'sha256'}
             and pin['source_path'] == str(path)
             and type(pin['bytes']) is int and 0 < pin['bytes'] <= MAX_FILE
             and type(pin['sha256']) is str and HEX.fullmatch(pin['sha256']),
             'actual original file bytes/SHA is unbound or outside fixed scope: ' + name)
        total += pin['bytes']
    need(total <= MAX_TOTAL, 'six original JSON bodies exceed fixed bound')
    return job_id


def verify_receipts(raw, identities, job_id):
    p, terminal, q, source, summary, audit = (json.loads(raw[name]) for name in FILES)
    need(all(type(value) is dict for value in (p, terminal, q, source, summary, audit)),
         'six original JSON objects required')
    need(terminal['job_id'] == job_id and terminal['state'] == 'succeeded'
         and type(terminal['exit_code']) is int and terminal['exit_code'] == 0
         and terminal['audit_recorded'] is True, 'original qualification strong success required')
    need(all(terminal[key] is True for key in ('output_complete', 'output_durable', 'terminal_publication_confirmed'))
         and all(terminal[key] is False for key in ('automatic_retry', 'cancelled', 'timed_out'))
         and type(terminal['terminal_publication_protocol']) is int and terminal['terminal_publication_protocol'] == 1,
         'original complete durable terminal required')
    for channel in ('stdout', 'stderr'):
        need(terminal['log_synced'][channel] is True and terminal['log_truncated'][channel] is False
             and terminal['log_errors'][channel] is None
             and type(terminal['log_bytes'][channel]['seen']) is int
             and terminal['log_bytes'][channel]['seen'] >= 0
             and type(terminal['log_bytes'][channel]['stored']) is int
             and terminal['log_bytes'][channel]['seen'] == terminal['log_bytes'][channel]['stored'],
             'original native log seal incomplete')
    need(q['schema'] == 'hepta-x230-composed-qualification/v1' and q['qualified'] is True
         and q['finished_utc'] and q['source'] == str(ROOT / 'source')
         and [row['name'] for row in q['stages']] == STAGES
         and all(type(row['returncode']) is int and row['returncode'] == 0 for row in q['stages'])
         and type(q['automatic_test_retries']) is int and q['automatic_test_retries'] == 0,
         'all eight original qualification stages must pass')
    need(q['source_tested'] == q['source_after'] == source and len(source) == 221
         and q['harness_before'] == q['harness_after'] and len(q['harness_after']) == 19,
         'qualified source or harness inventory differs')
    q_identity = identities['qualification-report-01.json']
    need(p['schema'] == 'hepta-r28-qualified-parent-preparation/v1'
         and p['finished_utc'] and p['qualification_returncode'] == 0
         and p['automatic_test_retries'] == 0
         and all(p[key] is True for key in ('passed', 'candidate_qualified', 'parent_source_qualified',
             'parent_lifecycle_rejection_preserved', 'parent_inputs_unchanged',
             'original_admission_failure_preserved', 'original_failed_admission_inputs_unchanged'))
         and p['candidate_adopted'] is False and p['parent_candidate_adopted'] is False
         and p['production_services_modified'] is False and p['shared_hardlinks_created'] is False
         and p['selected_proposal'] == 'cache only' and p['optional_pidfd_selected'] is False
         and p['qualification_report'] == {'path': q_identity['source_path'],
             'bytes': q_identity['bytes'], 'sha256': q_identity['sha256']}
         and p['source'] == str(ROOT / 'source') and p['target'] == str(ROOT / 'target-build')
         and p['qualification_output'] == str(ROOT / 'qualification-01')
         and p['source_tested'] == source and p['tests'] == summary,
         'actual original R28 preparation02 did not qualify')
    need(p['launcher'] == {'path': str(STAGE / 'prepare_and_qualify_r28_02.py'),
             'bytes': 30059, 'sha256': '6bef1776c36294d05a3796b2b4e3c79a07b15ed69122e3a2685705bfeb031239'}
         and p['input'] == {'path': str(STAGE / 'r28-qualification-02-input.json'),
             'bytes': 82496, 'sha256': '9173851d84e44421531df32ae2dcad9fd89a707664b2d7b8853965df2f24d3ae'}
         and p['space_recovery_mode'] == 'observed_space_sufficient_no_cleanup'
         and p['cleanup_executed'] is False and p['cleanup_operation'] is None
         and p['cache_retirement_executed_by_this_qualifier'] is False
         and p['unchanged_disk_reserve_bytes'] == 3 * 1024**3,
         'fixed original qualifier02 or no-cleanup admission differs')
    need(summary['schema'] == 'hepta-isolated-libtest/v1' and summary['success'] is True
         and summary['filter'] == '' and summary['enumeration_errors'] == []
         and all(type(summary[key]) is int and summary[key] == value for key, value in COUNTS.items())
         and summary['source_manifest_sha256'] == identities['qualified-source-map-01.json']['sha256'],
         'full original isolated test summary differs')
    need(audit['schema'] == 'hepta-isolated-libtest-audit/v1' and audit['success'] is True
         and audit['errors'] == [] and 'fatal_error' not in audit and audit['expected_filter'] == ''
         and audit['input_sha256']['summary.json'] == identities['isolated-tests-summary-01.json']['sha256']
         and all(type(audit[key]) is int and audit[key] == value for key, value in COUNTS.items() if key != 'retries')
         and type(audit['executed']) is int and audit['executed'] == 1653,
         'complete original isolated test audit differs')
    return {'original_qualification_job_id': job_id, 'strong_terminal_succeeded': True,
            'stage_names': STAGES, 'source_files': 221, 'harness_files': 19,
            'isolated_test_counts': COUNTS, 'audit_body_sampled': False,
            'original_preparation02_and_failed01_history_preserved': True,
            'scope': 'six original raw receipt bodies and their cross-links; no test or audit replay',
            'downstream_exact_CI_freezer_still_required': True}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--exporter-sha256', required=True)
    parser.add_argument('--input-sha256', required=True)
    args = parser.parse_args()
    need(os.geteuid() == 1000 and Path(__file__).resolve() == SELF, 'fixed native exporter path/owner required')
    need(HEX.fullmatch(args.exporter_sha256) and HEX.fullmatch(args.input_sha256),
         'actual bound exporter/input SHA required; an unbound template cannot run')
    helper = load_helper()
    exporter, _ = helper.read(SELF)
    helper_identity, _ = helper.read(HELPER)
    input_identity, input_raw = helper.read(INPUT, retain=True)
    need(exporter['sha256'] == args.exporter_sha256 and helper_identity['sha256'] == HELPER_SHA
         and input_identity['sha256'] == args.input_sha256 and input_identity['bytes'] <= 65536,
         'exporter/helper/late-bound input identities differ')
    payload = json.loads(input_raw)
    job_id = bind_input(payload)
    need(ROOT.resolve(strict=True) == ROOT and not os.path.lexists(OUT), 'fresh direct fixed export root required')
    root_before = ROOT.lstat()
    need(stat.S_ISDIR(root_before.st_mode) and root_before.st_uid == os.geteuid()
         and stat.S_IMODE(root_before.st_mode) == 0o700, 'original R28 root ownership differs')
    OUT.mkdir(mode=0o700)
    out_before = OUT.lstat()
    report = {'schema': 'hepta-r28-fixed-six-qualification-receipts-export/v1', 'passed': False,
              'started_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
              'original_qualification_job_id': job_id, 'exporter': exporter,
              'archive_helper': helper_identity, 'input': input_identity,
              'files': {}, 'archive': None, 'transfer': None,
              'expected_original_file_count': 6, 'expected_archive_member_count': 7,
              'only_six_original_JSON_bodies_in_payload': True,
              'qualification_or_CI_or_audit_replayed': False, 'source_or_binary_modified': False,
              'runtime_source_or_elf_bodies_read': False, 'original_json_bodies_reencoded': False,
              'archive_code_executed': False, 'candidate_adoption_assessed': False,
              'automatic_retries': 0, 'partial_failed_output_preserved': True}
    try:
        raw, files = {}, {}
        report['files'] = files
        for name, path in FILES.items():
            actual, body = helper.read(path, retain=True)
            expected = payload['files'][name]
            need(all(actual[key] == expected[key] for key in ('source_path', 'bytes', 'sha256'))
                 and actual['is_elf'] is False, 'original fixed JSON identity differs: ' + name)
            files[name], raw[name] = actual, body
        proof = verify_receipts(raw, files, job_id)
        manifest = {'schema': 'hepta-r28-fixed-six-qualification-receipts-manifest/v1',
                    'files': files, 'original_qualification_job_id': job_id,
                    'qualification_receipt_cross_links': proof,
                    'original_json_bytes_preserved': True, 'omitted_bodies': [],
                    'snapshot_scope': 'six independent original descriptors with whole-byte revalidation',
                    'member_names_match_actual_CI02_receipt_layout': True,
                    'archive_code_executed': False, 'runtime_source_or_elf_bodies_included': False}
        manifest_raw, archive_proof = helper.write_archive(OUT / ARCHIVE, manifest, files)
        helper.create(OUT / 'manifest.json', manifest_raw)
        report['manifest'] = helper.read(OUT / 'manifest.json')[0]
        need(report['manifest']['bytes'] == len(manifest_raw)
             and report['manifest']['sha256'] == hashlib.sha256(manifest_raw).hexdigest(),
             'written original manifest bytes differ')
        report['archive'] = archive_proof['identity']
        report['archive_validation'] = archive_proof
        report['transfer'] = helper.transfer_chunks(OUT / ARCHIVE, OUT)
        for name, path in FILES.items():
            helper.read(path, expected=files[name])
        helper.read(SELF, expected=exporter)
        helper.read(HELPER, expected=helper_identity)
        helper.read(INPUT, expected=input_identity)
        for path, original in ((ROOT, root_before), (OUT, out_before)):
            need(path.resolve(strict=True) == path and all(getattr(path.lstat(), key) == getattr(original, key)
                 for key in ('st_dev', 'st_ino', 'st_uid', 'st_mode')), 'owned directory changed')
        report.update(passed=True, qualification_receipt_cross_links=proof,
                      original_file_count=6, archive_member_count=7,
                      original_six_files_unchanged=True, tool_and_input_identities_unchanged=True,
                      single_gzip_crc_eof_and_all_seven_members_verified=True,
                      maximum_transfer_decoded_chunk_bytes=48000)
    except BaseException as error:
        report['error'] = {'type': type(error).__name__, 'reason': str(error)[:2000]}
    report['finished_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    report_raw = helper.encode(report)
    helper.create(OUT / 'report.json', report_raw)
    final, _ = helper.read(OUT / 'report.json')
    need(final['bytes'] == len(report_raw) and final['sha256'] == hashlib.sha256(report_raw).hexdigest(),
         'written final report bytes differ')
    fd = os.open(OUT, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW | os.O_CLOEXEC)
    try:
        os.fsync(fd)
    finally:
        os.close(fd)
    print(json.dumps({'passed': report['passed'], 'report': final,
                      'archive': report['archive'], 'transfer': report['transfer'],
                      'error': report.get('error')}, sort_keys=True), flush=True)
    return 0 if report['passed'] else 1


if __name__ == '__main__':
    os.umask(0o077)
    raise SystemExit(main())
