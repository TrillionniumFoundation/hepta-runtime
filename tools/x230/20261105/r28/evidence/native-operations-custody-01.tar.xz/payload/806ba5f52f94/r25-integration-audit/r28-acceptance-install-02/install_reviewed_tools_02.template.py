#!/usr/bin/env python3
"""Create only the reviewed R28 tools after original qualification; run no tools."""
import argparse
import datetime
import hashlib
import io
import json
import os
from pathlib import Path, PurePosixPath
import re
import stat
import sys
import tarfile

sys.dont_write_bytecode = True
STAGE_ROOT = Path('/home/qian/hepta-runtime-optimization-20261105-r25')
ROOT = Path('/home/qian/hepta-runtime-optimization-20261105-r28')
SOURCE = ROOT / 'source'
CANDIDATE_DIR = ROOT / 'qualification-01'
SCRIPT = STAGE_ROOT / 'tools/install_r28_reviewed_tools_02.py'
QUALIFICATION_INPUT = STAGE_ROOT / 'tools/r28-installation-qualification-02.json'
RECEIPT = 'tools-install-02-receipt.json'
NEW_DIRECTORIES = ('tools-02', 'lifecycle-tools-02', 'lifecycle-launcher-bundle-02',
                   'lifecycle-launcher-bundle-02/tools-02')
PARENT_INSTALL = {
    'tools-02/r28_lifecycle_campaign.py': str(ROOT / 'tools-02/r28_lifecycle_campaign.py'),
    'tools-02/prepare_lifecycle_inputs.py': str(ROOT / 'tools-02/prepare_lifecycle_inputs.py'),
    'lifecycle-inputs-01.example.json': str(ROOT / 'lifecycle-inputs-01.example.json'),
}
ROOT_FILES = {'campaign-inputs-01.example.json', 'observation-plan-01.json',
              'observation-tools-manifest-01.json', 'lifecycle-inputs-01.example.json'}
ARCHIVES = None  # FROZEN_ARCHIVE_MAP
HEX = re.compile(r'[0-9a-f]{64}\Z')


def need(value, message):
    if not value:
        raise RuntimeError(message)


def encoded(value):
    return (json.dumps(value, sort_keys=True, indent=2, allow_nan=False) + '\n').encode()


def identity(raw):
    return {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


def stamp(value):
    return tuple(getattr(value, name) for name in
                 ('st_dev', 'st_ino', 'st_uid', 'st_mode', 'st_nlink', 'st_size', 'st_mtime_ns', 'st_ctime_ns'))


def read_path(path, expected=None, maximum=128 * 1024 * 1024, retain=True):
    path = Path(path)
    need(path.is_absolute() and path.resolve(strict=True) == path, 'indirect or missing input path')
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_CLOEXEC | os.O_NONBLOCK)
    try:
        before = os.fstat(fd)
        need(stat.S_ISREG(before.st_mode) and before.st_nlink == 1 and before.st_uid == os.geteuid()
             and 0 <= before.st_size <= maximum, 'unsafe or oversized owned input')
        digest, size, chunks = hashlib.sha256(), 0, []
        while block := os.read(fd, 1024 * 1024):
            size += len(block)
            need(size <= before.st_size, 'input grew while reading')
            digest.update(block)
            if retain:
                chunks.append(block)
        need(size == before.st_size and stamp(before) == stamp(os.fstat(fd)) == stamp(path.lstat()),
             'input identity changed while reading')
    finally:
        os.close(fd)
    result = {'path': str(path), 'bytes': size, 'sha256': digest.hexdigest()}
    if expected is not None:
        need(type(expected.get('bytes')) is int and HEX.fullmatch(expected.get('sha256', ''))
             and result == {key: expected[key] for key in result}, 'actual input identity differs')
    return result, b''.join(chunks)


def read_at(directory, name, expected):
    need(Path(name).name == name, 'only direct file names are permitted')
    fd = os.open(name, os.O_RDONLY | os.O_NOFOLLOW | os.O_CLOEXEC | os.O_NONBLOCK, dir_fd=directory)
    try:
        before = os.fstat(fd)
        need(stat.S_ISREG(before.st_mode) and before.st_nlink == 1 and before.st_uid == os.geteuid()
             and 0 <= before.st_size == expected['bytes'] <= 1048576, 'unsafe installed file')
        with os.fdopen(os.dup(fd), 'rb') as stream:
            raw = stream.read(expected['bytes'] + 1)
        need(stamp(before) == stamp(os.fstat(fd)) == stamp(os.stat(name, dir_fd=directory, follow_symlinks=False))
             and identity(raw) == expected, 'installed file identity differs')
        return {'device': before.st_dev, 'inode': before.st_ino, 'uid': before.st_uid,
                'mode': stat.S_IMODE(before.st_mode), 'links': before.st_nlink, **identity(raw)}
    finally:
        os.close(fd)


def members_from_archive(raw, spec):
    need(identity(raw) == {key: spec[key] for key in ('bytes', 'sha256')}, 'archive identity differs')
    result = {}
    with tarfile.open(fileobj=io.BytesIO(raw), mode='r:gz') as archive:
        entries = archive.getmembers()
        need(len(entries) == spec['member_count'] and sum(entry.size for entry in entries) == spec['expanded_bytes']
             and spec['expanded_bytes'] <= 1048576, 'archive member count or expansion differs')
        for entry in entries:
            path = PurePosixPath(entry.name)
            need(entry.type in (tarfile.REGTYPE, tarfile.AREGTYPE) and not entry.issparse()
                 and not entry.linkname and path.parts and not path.is_absolute()
                 and all(part not in ('.', '..') for part in path.parts)
                 and path.as_posix() == entry.name and entry.name in spec['members']
                 and entry.name not in result, 'unexpected, linked, duplicate or unsafe archive member')
            expected = spec['members'][entry.name]
            need(entry.size == expected['bytes'], 'archive member size differs')
            stream = archive.extractfile(entry)
            need(stream is not None, 'regular member unreadable')
            body = stream.read(expected['bytes'] + 1)
            need(identity(body) == expected, 'archive member SHA differs')
            result[entry.name] = body
        need(set(result) == set(spec['members']), 'archive member set differs')
    return result


def verify_r28_candidate_preparation(preparation, terminal, job_id, qualified, tests):
    """Verify the actual new cache-only R28 qualification; no future success is inferred."""
    need(isinstance(job_id, str) and re.fullmatch(r"[0-9a-f]{11,16}-[0-9a-f]{4}-[0-9a-f]{4}", job_id)
         and job_id not in {"1a1aa7fa690-fc05-43af", "1a1aaa6552d-fc05-459f", "1a1ab4cb0fc-fc05-4c3c",
                            "1a1ac274e49-fc05-5286", "1a1ac456b07-fc05-532a"},
         "the actual new R28 qualification job is required")
    need(terminal.get("job_id") == job_id and terminal.get("state") == "succeeded"
         and type(terminal.get("exit_code")) is int and terminal["exit_code"] == 0
         and all(terminal.get(key) is False for key in ("automatic_retry", "timed_out", "cancelled"))
         and all(terminal.get(key) is True for key in ("output_complete", "output_durable", "terminal_publication_confirmed"))
         and type(terminal.get("terminal_publication_protocol")) is int and terminal["terminal_publication_protocol"] == 1
         and terminal.get("log_synced") == {"stdout": True, "stderr": True}
         and terminal.get("log_errors") == {"stdout": None, "stderr": None}
         and terminal.get("log_truncated") == {"stdout": False, "stderr": False},
         "original R28 qualification has no complete successful native terminal proof")
    for stream in ("stdout", "stderr"):
        counts = terminal["log_bytes"][stream]
        need(set(counts) == {"seen", "stored"} and all(type(value) is int and value >= 0 for value in counts.values())
             and counts["seen"] == counts["stored"], "qualification native log byte custody differs")
    need(preparation["schema"] == "hepta-r28-qualified-parent-preparation/v1"
         and preparation["selected_proposal"] == "cache only" and preparation.get("optional_pidfd_selected") is False
         and preparation.get("finished_utc")
         and all(preparation.get(key) is True for key in ("passed", "candidate_qualified", "parent_source_qualified",
             "parent_lifecycle_rejection_preserved", "parent_inputs_unchanged"))
         and all(preparation.get(key) is False for key in ("candidate_adopted", "parent_candidate_adopted",
             "production_services_modified", "shared_hardlinks_created")), "actual R28 preparation is incomplete")
    need(preparation["source"] == str(SOURCE) and preparation["target"] == str(ROOT / "target-build")
         and preparation["qualification_output"] == str(CANDIDATE_DIR)
         and preparation["launcher"] == {"path": "/home/qian/hepta-runtime-optimization-20261105-r25/tools/prepare_and_qualify_r28_02.py",
             "bytes": 30059, "sha256": "6bef1776c36294d05a3796b2b4e3c79a07b15ed69122e3a2685705bfeb031239"}
         and preparation["input"] == {"path": "/home/qian/hepta-runtime-optimization-20261105-r25/tools/r28-qualification-02-input.json",
             "bytes": 82496, "sha256": "9173851d84e44421531df32ae2dcad9fd89a707664b2d7b8853965df2f24d3ae"},
         "R28 qualification launcher, input or private paths differ")
    # These are original negative outcomes and the actual read-only space observation.
    # They remain negative; no cleanup or successful inventory is inferred.
    preserved_admission = {'admission_absent_paths': ['/home/qian/hepta-runtime-optimization-20261105-r28/source',
                            '/home/qian/hepta-runtime-optimization-20261105-r28/target-build',
                            '/home/qian/hepta-runtime-optimization-20261105-r28/qualification-01',
                            '/home/qian/hepta-runtime-optimization-20261105-r28/preparation-02.json',
                            '/home/qian/hepta-runtime-optimization-20261105-r28/qualification-input-02.json',
                            '/home/qian/hepta-runtime-optimization-20261105-r28/qualification-terminal-status-02.json'],
 'cache_retirement_executed_by_this_qualifier': False,
 'cleanup_executed': False,
 'cleanup_operation': None,
 'original_admission_failure_preserved': True,
 'original_candidate_input': {'bytes': 34557,
                              'path': '/home/qian/hepta-runtime-optimization-20261105-r28/qualification-input-01.json',
                              'sha256': '0837e858fddf7df95229a5dac1dafdf6d904800caad46cb238ba18ecfaa93299'},
 'original_failed_admission': {'exit_code': 1,
                               'job_id': '1a1ac274e49-fc05-5286',
                               'label': 'original_failed_admission',
                               'native_read': {'bytes': 723,
                                               'sha256': '5a0beef68de943554f08936dacec1a66c4b8e2af66f6c7ea9aa9387cc852e35a'},
                               'original_complete_streams_proved': True,
                               'state': 'failed',
                               'stderr': {'bytes': 0,
                                          'sha256': 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855'},
                               'stdout': {'bytes': 131,
                                          'sha256': '3613580074731c44ad27d2687ec2e8c177fd81eef7d9b2148d0b8ef10df886fc'},
                               'terminal': {'bytes': 726,
                                            'sha256': '8dee0438ff40dc85288ff6d9ff6da9dfcdfc36092bbc12995bd99018f3d00d31'}},
 'original_failed_admission_inputs_unchanged': True,
 'original_native_read': {'bytes': 723,
                          'path': '/home/qian/hepta-runtime-optimization-20261105-r28/qualification-native-read-01.json',
                          'sha256': '5a0beef68de943554f08936dacec1a66c4b8e2af66f6c7ea9aa9387cc852e35a'},
 'original_native_terminal': {'bytes': 726,
                              'path': '/home/qian/hepta-runtime-optimization-20261105-r28/qualification-terminal-status-01.json',
                              'sha256': '8dee0438ff40dc85288ff6d9ff6da9dfcdfc36092bbc12995bd99018f3d00d31'},
 'original_preparation': {'bytes': 4671,
                          'path': '/home/qian/hepta-runtime-optimization-20261105-r28/preparation-01.json',
                          'sha256': 'abc26b3d49c2e57b608fe3aba792708e80de95340c1c8c210dced2844953fade'},
 'space_recovery_mode': 'observed_space_sufficient_no_cleanup',
 'space_recovery_observation': {'all_same_owner_reference_channels_inspected': False,
                                'available_bytes': 7478648832,
                                'cleanup_executed': False,
                                'cleanup_operation': None,
                                'copy_cache_bytes': 3080991421,
                                'excess_over_required_bytes': 1176431939,
                                'inventory_overall_passed': False,
                                'old_cache_absence_cause_inferred': False,
                                'original_inventory_native_exit_code': 1,
                                'original_inventory_native_state': 'failed',
                                'process_reference_scans_complete': False,
                                'required_headroom_bytes': 3221225472},
 'space_recovery_proofs': {'readonly_inventory': {'exit_code': 1,
                                                  'job_id': '1a1ac456b07-fc05-532a',
                                                  'label': 'readonly_inventory',
                                                  'native_read': {'bytes': 42578,
                                                                  'sha256': 'd232070f29ce310dd2f304f75bc661ebf937582f0b1e179cc94dd88e80e1dcb1'},
                                                  'original_complete_streams_proved': True,
                                                  'state': 'failed',
                                                  'stderr': {'bytes': 0,
                                                             'sha256': 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855'},
                                                  'stdout': {'bytes': 13686,
                                                             'sha256': '3c2e43bbaeb2914c6372653ba1ea79d196af451aed75a9cb9ce4fac313769dda'},
                                                  'terminal': {'bytes': 730,
                                                               'sha256': 'c06d88c67b142ad33bcab37cf4cd51d9235dd14cc0e046927cf5aa53429d365b'}}},
 'unchanged_disk_reserve_bytes': 3221225472}
    for name, expected_value in preserved_admission.items():
        need(preparation.get(name) == expected_value, "R28 preserved admission evidence differs: " + name)
    need(all(preparation.get(name) is True for name in
             ("original_admission_failure_preserved", "original_failed_admission_inputs_unchanged"))
         and all(preparation.get(name) is False for name in
                 ("cache_retirement_executed_by_this_qualifier", "cleanup_executed"))
         and preparation.get("cleanup_operation") is None, "R28 original failures or no-cleanup scope changed")
    original_names = ("original_preparation", "original_candidate_input", "original_native_terminal", "original_native_read")
    originals = {preparation[name]["path"]: preparation[name] for name in original_names}
    descriptors = preparation.get("original_file_identities")
    descriptor_keys = {"st_dev", "st_ino", "st_mode", "st_uid", "st_nlink", "st_size", "st_mtime_ns", "st_ctime_ns"}
    need(isinstance(descriptors, dict) and set(descriptors) == set(originals), "four original file identities required")
    for path, pin in originals.items():
        descriptor = descriptors[path]
        need(isinstance(descriptor, dict) and set(descriptor) == descriptor_keys
             and all(type(value) is int and value >= 0 for value in descriptor.values())
             and descriptor["st_ino"] > 0 and descriptor["st_uid"] == 1000 and descriptor["st_nlink"] == 1
             and descriptor["st_size"] == pin["bytes"] and descriptor["st_mode"] & 0o170000 == 0o100000
             and not descriptor["st_mode"] & 0o6000, "original preserved file descriptor differs: " + path)
        need(preparation["bound_parent_inputs"].get(path) == pin, "original preserved file final byte binding differs: " + path)
    known_original_descriptors = {
        '/home/qian/hepta-runtime-optimization-20261105-r28/preparation-01.json': {'st_ctime_ns': 1793889622435153369, 'st_dev': 2053, 'st_ino': 2259040, 'st_mode': 33152, 'st_mtime_ns': 1793889622435153369, 'st_nlink': 1, 'st_size': 4671, 'st_uid': 1000},
        '/home/qian/hepta-runtime-optimization-20261105-r28/qualification-input-01.json': {'st_ctime_ns': 1793889621996152717, 'st_dev': 2053, 'st_ino': 2259039, 'st_mode': 33152, 'st_mtime_ns': 1793889621996152717, 'st_nlink': 1, 'st_size': 34557, 'st_uid': 1000},
    }
    need(all(descriptors[path] == expected_value for path, expected_value in known_original_descriptors.items()),
         "original preparation/input descriptor identity differs from the actual inventory")
    need(type(preparation["cache_bytes"]) is int and preparation["cache_bytes"] > 0
         and type(preparation["disk_available_before_bytes"]) is int
         and preparation["disk_available_before_bytes"] >= preparation["cache_bytes"] + 3221225472,
         "actual R28 cache admission did not retain the original 3 GiB reserve")
    need(type(preparation["qualification_returncode"]) is int and preparation["qualification_returncode"] == 0
         and type(preparation["automatic_test_retries"]) is int and preparation["automatic_test_retries"] == 0,
         "R28 qualification did not finish once with exit zero")
    expected_changes = [{'path': 'src/mcp/runtime/jobs.rs',
  'before': {'bytes': 186504, 'sha256': '8a80623ccf9131e520ed5f25647200bd2086e4718b892eed90c1530a5ccb9283'},
  'after': {'bytes': 186541, 'sha256': '061c2576e3c1dd8a1e4f5bfd7d3498f7cc4141d6577d53365a9a4738c7980af6'}},
 {'path': 'src/mcp/runtime/ssh.rs',
  'before': {'bytes': 18943, 'sha256': '0c0bf93da7d8d391b79d026544dc7ff71974bd1eabb06e5fe319892174843189'},
  'after': {'bytes': 19820, 'sha256': 'b674dfcb60bc57c46a08f1ab1f424a8aadcdb2078abdcfdff30f71632e807b3d'}},
 {'path': 'src/mcp/runtime/ssh_tests.rs',
  'before': {'bytes': 4652, 'sha256': '39dacf3f7839b7a013b24b2ec63bd9cf7b51599ebaebc1e5e074cfb98ae79893'},
  'after': {'bytes': 4931, 'sha256': '98f18f6cd89776b7589a9864224683d49f4b0cb663467475aa721c52dfff0a57'}}]
    need(preparation["source_changes"] == expected_changes, "qualified selection is not the exact three-file cache-only change")
    before = preparation["source_before"]
    expected = dict(before)
    changed_paths = {change["path"] for change in expected_changes}
    need(len(before) == 221 and len(changed_paths) == 3, "R28 parent source-map or change count differs")
    for change in expected_changes:
        need(before[change["path"]] == change["before"]["sha256"], "R28 exact qualified parent preimage differs")
        expected[change["path"]] = change["after"]["sha256"]
    need(preparation["candidate_compilation_inputs"] == expected, "R28 pre-format source map differs")
    stages = ["format", "fmt-check", "harness-tests", "clippy", "test-build", "isolated-tests", "audit-isolated-tests", "release"]
    need(qualified["schema"] == "hepta-x230-composed-qualification/v1" and qualified["qualified"] is True
         and qualified.get("finished_utc") and qualified["source"] == str(SOURCE)
         and qualified["jobs"] == 2 and qualified["service_changes"] is False
         and type(qualified["automatic_test_retries"]) is int and qualified["automatic_test_retries"] == 0
         and [row["name"] for row in qualified["stages"]] == stages
         and all(type(row["returncode"]) is int and row["returncode"] == 0 for row in qualified["stages"]),
         "all eight original R28 qualification stages must pass")
    need(qualified["source_input"] == expected and qualified["source_tested"] == qualified["source_after"] == preparation["source_tested"]
         and set(qualified["source_after"]) == set(expected)
         and all(qualified["source_after"][name] == value for name, value in expected.items() if name not in changed_paths),
         "actual formatted R28 source differs from its qualified preparation")
    need(preparation["formatter_changed_paths"] == [name for name in expected if qualified["source_after"][name] != expected[name]]
         and qualified["harness_before"] == qualified["harness_after"] == preparation["harness_before"]
         and len(qualified["harness_after"]) == 19, "qualification formatter or original harness binding differs")
    counts = ("passed", "failed", "ignored", "selected", "retries")
    need(all(type(tests[key]) is int for key in counts)
         and [tests[key] for key in counts] == [1653, 0, 34, 1687, 0]
         and preparation["tests"] == tests, "original full R28 isolated test result is incomplete")
    return {"passed": True, "original_job_id": job_id, "selected_proposal": "cache only", "optional_pidfd_selected": False,
            "qualified_source_files": 221, "harness_files": 19, "stages": stages,
            "tests": {key: tests[key] for key in counts}, "candidate_adopted": False,
            "qualified_parent_R26_lifecycle_rejection_preserved": True,
            "original_failed_admission_preserved": True, "original_failed_inventory_preserved": True,
            "space_recovery_mode": "observed_space_sufficient_no_cleanup", "cleanup_executed": False}


def verify_qualification_documents(value, preparation, terminal, qualified, summary, audit, source_map):
    need(value['schema'] == 'hepta-r28-installation-qualification/v1'
         and value['executed'] is False, 'actual qualification input schema differs')
    proof = verify_r28_candidate_preparation(preparation, terminal, value['original_qualification_job_id'], qualified, summary)
    need(type(preparation.get('finished_utc')) is str and bool(preparation['finished_utc'])
         and preparation['qualification_report'] == value['qualification_report']
         and source_map == qualified['source_after'], 'completed preparation/source-map binding differs')
    need(summary['schema'] == 'hepta-isolated-libtest/v1' and summary['success'] is True
         and summary['filter'] == '' and summary['enumeration_errors'] == []
         and summary['source_manifest_path'] == str(CANDIDATE_DIR / 'source-map.json')
         and summary['source_manifest_sha256'] == value['source_map']['sha256'], 'full actual isolated summary differs')
    need(audit['schema'] == 'hepta-isolated-libtest-audit/v1' and audit['success'] is True
         and audit['errors'] == [] and 'fatal_error' not in audit and audit['expected_filter'] == ''
         and audit['input_sha256']['summary.json'] == value['isolated_summary']['sha256']
         and all(audit[key] == summary[key] for key in ('passed', 'failed', 'ignored', 'selected'))
         and audit['executed'] == 1653, 'original independent isolated audit differs')
    return proof


def qualification_prerequisites(value, bind):
    paths = {
        'preparation': ROOT / 'preparation-02.json',
        'native_terminal': ROOT / 'qualification-terminal-status-02.json',
        'qualification_report': CANDIDATE_DIR / 'report.json',
        'source_map': CANDIDATE_DIR / 'source-map.json',
        'isolated_summary': CANDIDATE_DIR / 'isolated-tests/summary.json',
        'isolated_audit': CANDIDATE_DIR / 'isolated-tests.audit.json',
    }
    documents = {}
    for name, path in paths.items():
        need(value[name]['path'] == str(path), 'actual qualification receipt path differs')
        _, raw = bind(path, value[name])
        documents[name] = json.loads(raw)
    proof = verify_qualification_documents(value, documents['preparation'], documents['native_terminal'],
        documents['qualification_report'], documents['isolated_summary'], documents['isolated_audit'], documents['source_map'])
    qualified = documents['qualification_report']
    paths = [SOURCE / name for name in ('Cargo.toml', 'Cargo.lock', 'rustfmt.toml')]
    for name in ('src', 'examples'):
        paths.extend(path for path in (SOURCE / name).rglob('*') if path.is_file())
    actual = {path.relative_to(SOURCE).as_posix(): bind(path, retain=False)[0]['sha256'] for path in sorted(paths)}
    need(actual == qualified['source_after'], 'actual qualified source changed before tool installation')
    harness = {path.name: bind(path, retain=False)[0]['sha256']
               for path in sorted((SOURCE / 'tools/x230/20261028').glob('*.py'))}
    need(harness == qualified['harness_after'], 'actual qualification harness changed')
    binaries = {}
    need(set(qualified['binaries']) == {'hepta-runtime', 'hepta-runtime-jobctl', 'native_process_driver'},
         'qualified executable set differs')
    for name, item in qualified['binaries'].items():
        path = CANDIDATE_DIR / name
        need(item['path'] == str(path) and os.access(path, os.X_OK), 'qualified artifact path differs')
        row, _ = bind(path, retain=False)
        need(row['sha256'] == item['sha256'], 'actual qualified executable changed')
        binaries[name] = row
    for label in ('launcher', 'input'):
        item = documents['preparation'][label]
        need(Path(item['path']).parent == STAGE_ROOT / 'tools', 'qualification bootstrap input path differs')
        bind(item['path'], item, retain=False)
    proof.update(actual_binaries=binaries, source_files=len(actual), harness_files=len(harness))
    return proof


def build_installation(bundles):
    observation = json.loads(bundles['observation']['observation-tools-manifest-01.json'])
    lifecycle = json.loads(bundles['lifecycle']['lifecycle-tools-manifest-01.json'])
    parent = json.loads(bundles['parent']['lifecycle-launcher-manifest-01.json'])
    need(observation['schema'] == 'hepta-r28-observation-tools-install/v2'
         and observation['prepared_only'] is True and observation['create_only'] is True
         and observation['destination_root'] == str(ROOT) and len(observation['files']) == 9
         and set(observation['files']) == set(bundles['observation']) - {'observation-tools-manifest-01.json'},
         'observation payload manifest differs')
    need(lifecycle['schema'] == 'hepta-r25-lifecycle-tools/v1' and len(lifecycle['files']) == 27
         and set(lifecycle['files']) == set(bundles['lifecycle']) - {'lifecycle-tools-manifest-01.json'},
         'native lifecycle payload manifest differs')
    need(parent['schema'] == 'hepta-r28-lifecycle-launcher-bundle/v2'
         and parent['prepared_only'] is True and parent['create_only'] is True
         and parent['preserve_bundle_at'] == str(ROOT / 'lifecycle-launcher-bundle-02')
         and parent['installations'] == PARENT_INSTALL and len(parent['files']) == 8
         and set(parent['files']) == set(bundles['parent']) - {'lifecycle-launcher-manifest-01.json'},
         'outer lifecycle payload manifest differs')
    for label, manifest in (('observation', observation), ('lifecycle', lifecycle), ('parent', parent)):
        for name, pin in manifest['files'].items():
            need(identity(bundles[label][name]) == pin, 'payload manifest identity differs')
    need(parent['requires_observation_tools_manifest'] == identity(bundles['observation']['observation-tools-manifest-01.json'])
         and parent['requires_native_tools_manifest'] == identity(bundles['lifecycle']['lifecycle-tools-manifest-01.json']),
         'reviewed bundle dependencies disagree')
    obs_example = json.loads(bundles['observation']['campaign-inputs-01.example.json'])
    life_example = json.loads(bundles['parent']['lifecycle-inputs-01.example.json'])
    need(obs_example['launcher_sha256'] == life_example['campaign_helpers']['sha256']
         == identity(bundles['observation']['tools-02/r28_campaign.py'])['sha256']
         and life_example['launcher_sha256'] == identity(bundles['parent']['tools-02/r28_lifecycle_campaign.py'])['sha256']
         and life_example['tools_manifest']['sha256'] == identity(bundles['lifecycle']['lifecycle-tools-manifest-01.json'])['sha256'],
         'example helper identity differs')
    monitor = {}
    for label, name in {'module': 'compiler_monitor.py', 'validator': 'validate_compiler_monitor.py',
                        'reader': 'compiler_state.py', 'policy': 'compiler-monitor-policy-01.json'}.items():
        member = 'tools-02/' + name
        monitor[label] = {'path': str(ROOT / member), **identity(bundles['observation'][member])}
    need(obs_example['compiler_monitor'] == life_example['compiler_monitor'] == monitor,
         'actual four monitor paths or source identities differ between payload and templates')
    for example in (obs_example, life_example):
        need(example['attempt'] == '01' and example['candidate_release'] == 'R28'
             and example['qualification_terminal_status']['job_id'] is None
             and example['source_inputs_sha256'] is None
             and all(row == {'bytes': None, 'sha256': None} for row in example['candidate_binaries'].values()),
             'reviewed example was replaced by premature future evidence')
    plan = []
    for label, prefix in (('observation', ''), ('lifecycle', 'lifecycle-tools-02/'),
                           ('parent', 'lifecycle-launcher-bundle-02/')):
        for name, raw in sorted(bundles[label].items()):
            plan.append((prefix + name, raw, label, name))
    for name, path in sorted(PARENT_INSTALL.items()):
        plan.append((Path(path).relative_to(ROOT).as_posix(), bundles['parent'][name], 'parent', name))
    need(len(plan) == len({row[0] for row in plan}) == 50, 'installation collision or file count differs')
    for relative, _, _, _ in plan:
        path = PurePosixPath(relative)
        need(path.as_posix() == relative and not path.is_absolute() and '..' not in path.parts
             and ((path.parent.as_posix() == '.' and relative in ROOT_FILES)
                  or path.parent.as_posix() in NEW_DIRECTORIES), 'destination is outside fixed new scope')
    return plan


def absent(directory, name):
    try:
        os.stat(name, dir_fd=directory, follow_symlinks=False)
    except FileNotFoundError:
        return
    raise RuntimeError('existing destination must not be replaced: ' + name)


def create_file(directory, name, raw):
    need(Path(name).name == name, 'direct destination required')
    fd = os.open(name, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW | os.O_CLOEXEC, 0o600, dir_fd=directory)
    with os.fdopen(fd, 'wb') as stream:
        stream.write(raw)
        stream.flush()
        os.fsync(stream.fileno())
    result = read_at(directory, name, identity(raw))
    need(result['mode'] == 0o600, 'created file is not private')
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--installer-sha256', required=True)
    args = parser.parse_args()
    need(sys.platform == 'linux' and os.geteuid() != 0 and HEX.fullmatch(args.installer_sha256),
         'native Linux operator and reviewed source SHA required')
    need(Path(__file__).resolve() == SCRIPT and ROOT.resolve(strict=True) == ROOT,
         'fixed installer and existing qualifier-created R28 root required')
    os.umask(0o077)
    bindings, directories, created, created_dirs = [], {}, [], []
    root_fd = os.open(ROOT, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW | os.O_CLOEXEC)

    def bind(path, expected=None, retain=True):
        row, raw = read_path(path, expected, retain=retain)
        bindings.append(row)
        return row, raw

    try:
        before = os.fstat(root_fd)
        need(before.st_uid == os.geteuid() and stat.S_IMODE(before.st_mode) == 0o700,
             'qualifier-created root is not owned private0700')
        own, _ = bind(SCRIPT)
        need(own['sha256'] == args.installer_sha256, 'reviewed installer source changed')
        input_identity, raw = bind(QUALIFICATION_INPUT)
        qualification = qualification_prerequisites(json.loads(raw), bind)
        bundles, archive_rows = {}, {}
        for label, spec in ARCHIVES.items():
            need(Path(spec['path']).parent == STAGE_ROOT, 'staged archive is outside existing R25 root')
            row, raw = bind(spec['path'], spec)
            bundles[label] = members_from_archive(raw, spec)
            archive_rows[label] = dict(row, member_count=len(bundles[label]))
        plan = build_installation(bundles)
        # Only the named destinations are checked. Existing unrelated parent
        # entries, including binary_write's persistent locks, are not enumerated.
        for name in (*[d for d in NEW_DIRECTORIES if '/' not in d], *sorted(ROOT_FILES), RECEIPT):
            absent(root_fd, name)
        for row in bindings:
            need(read_path(row['path'], row, retain=False)[0] == row, 'prerequisite changed before installation')
        # No mutation occurs before all actual qualification and archive gates.
        for relative in NEW_DIRECTORIES:
            path = PurePosixPath(relative)
            owner_fd = root_fd if path.parent.as_posix() == '.' else directories[path.parent.as_posix()]
            os.mkdir(path.name, mode=0o700, dir_fd=owner_fd)
            fd = os.open(path.name, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW | os.O_CLOEXEC, dir_fd=owner_fd)
            current = os.fstat(fd)
            need(current.st_uid == os.geteuid() and stat.S_IMODE(current.st_mode) == 0o700, 'created directory ownership differs')
            directories[relative] = fd
            created_dirs.append(relative)
        installed = []
        for relative, raw, label, member in plan:
            path = PurePosixPath(relative)
            owner_fd = root_fd if path.parent.as_posix() == '.' else directories[path.parent.as_posix()]
            row = create_file(owner_fd, path.name, raw)
            created.append(relative)
            installed.append(dict(row, path=str(ROOT / relative), archive=label, member=member))
        for relative, fd in directories.items():
            os.fsync(fd)
            path = PurePosixPath(relative)
            owner_fd = root_fd if path.parent.as_posix() == '.' else directories[path.parent.as_posix()]
            need(stamp(os.fstat(fd)) == stamp(os.stat(path.name, dir_fd=owner_fd, follow_symlinks=False)),
                 'installed directory identity changed')
        for relative, raw, _, _ in plan:
            path = PurePosixPath(relative)
            read_at(root_fd if path.parent.as_posix() == '.' else directories[path.parent.as_posix()], path.name, identity(raw))
        for row in bindings:
            need(read_path(row['path'], row, retain=False)[0] == row, 'original prerequisite changed during installation')
        need(os.fstat(root_fd).st_ino == ROOT.lstat().st_ino and os.fstat(root_fd).st_dev == ROOT.lstat().st_dev,
             'original root directory was replaced')
        report = {'schema': 'hepta-r28-reviewed-tools-install/v2', 'installed': True,
                  'finished_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
                  'installer': own, 'actual_qualification_input': input_identity, 'qualification': qualification,
                  'archives': archive_rows, 'created_directories': created_dirs, 'installed_file_count': len(installed),
                  'files': installed, 'input_bindings': bindings, 'all_destinations_initially_absent': True,
                  'manual_regular_member_extraction': True, 'all_files_and_archives_rehashed': True,
                  'source_or_cache_modified': False, 'production_services_modified': False,
                  'packaged_code_executed': False, 'tests_run': 0, 'campaigns_started': 0, 'automatic_retries': 0}
        receipt = create_file(root_fd, RECEIPT, encoded(report))
        os.fsync(root_fd)
        print(json.dumps({'installed': True, 'installed_file_count': len(installed),
                          'receipt': dict(receipt, path=str(ROOT / RECEIPT)), 'tests_run': 0,
                          'campaigns_started': 0, 'source_or_cache_modified': False}), flush=True)
    except BaseException as error:
        print(json.dumps({'installed': False, 'created_files': created, 'created_directories': created_dirs,
                          'error': {'type': type(error).__name__, 'reason': str(error)},
                          'automatic_retries': 0, 'tests_run': 0, 'campaigns_started': 0}), flush=True)
        raise
    finally:
        for fd in reversed(list(directories.values())):
            os.close(fd)
        os.close(root_fd)


if __name__ == '__main__':
    main()
