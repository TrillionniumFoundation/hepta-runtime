"""Create only the four frozen R28 staging files; never execute their payloads."""
import base64
import hashlib
import json
import os
import stat
import sys

ROOT = '/home/qian/hepta-runtime-optimization-20261105-r25'
OWNER = 1000
PAYLOAD_BYTES = 251903
PAYLOAD_SHA256 = '4d33465209afea55eb5378ee526e946e46b934bf75a8247ce25e4e40da1f976e'
FILES = (
    ('root', 'staged-r28-observation-tools-02.tar.gz', 35760, '250fcac0c9d3cd8cae043f957a3ab6c04c4700fab85e1a66697000c6e1a09718'),
    ('root', 'staged-r28-lifecycle-tools-02.tar.gz', 83479, '2b309d12b7af0116560e2356d9c8b7cf44320adb71b01db7dcba756d3bb31cee'),
    ('root', 'staged-r28-lifecycle-launcher-bundle-02.tar.gz', 21770, 'ded090e4f2754851f06fa7bef51bee0a9100a64e7815fd321c6baeb79ba4958b'),
    ('tools', 'install_r28_reviewed_tools_02.py', 47246, '242701117e8595b16167720c05e6602a221c2db272aef67ccb3abd7c1888c9ae'),
)


def need(value, message):
    if not value:
        raise RuntimeError(message)


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def directory_identity(value):
    need(stat.S_ISDIR(value.st_mode), 'fixed directory is not a directory')
    return (value.st_dev, value.st_ino, value.st_uid, stat.S_IMODE(value.st_mode))


def file_stamp(value):
    return tuple(getattr(value, name) for name in
                 ('st_dev', 'st_ino', 'st_uid', 'st_mode', 'st_nlink', 'st_size', 'st_mtime_ns', 'st_ctime_ns'))


def verify_file(directory_fd, name, body, expected_sha, created_stamp=None):
    fd = os.open(name, os.O_RDONLY | os.O_NONBLOCK | os.O_NOFOLLOW | os.O_CLOEXEC, dir_fd=directory_fd)
    try:
        before = os.fstat(fd)
        need(stat.S_ISREG(before.st_mode) and before.st_uid == OWNER and before.st_nlink == 1
             and stat.S_IMODE(before.st_mode) == 0o600 and before.st_size == len(body),
             'created file metadata differs: ' + name)
        need(created_stamp is None or file_stamp(before) == created_stamp,
             'created file descriptor was replaced before readback: ' + name)
        blocks, count = [], 0
        while count <= len(body):
            block = os.read(fd, len(body) + 1 - count)
            if not block:
                break
            blocks.append(block)
            count += len(block)
        readback = b''.join(blocks)
        linked = os.stat(name, dir_fd=directory_fd, follow_symlinks=False)
        need(readback == body and digest(readback) == expected_sha
             and file_stamp(before) == file_stamp(os.fstat(fd)) == file_stamp(linked),
             'created file bytes or descriptor changed: ' + name)
        return {'bytes': count, 'sha256': expected_sha, 'device': before.st_dev,
                'inode': before.st_ino, 'uid': before.st_uid, 'mode': stat.S_IMODE(before.st_mode),
                'nlink': before.st_nlink, 'mtime_ns': before.st_mtime_ns, 'ctime_ns': before.st_ctime_ns}
    finally:
        os.close(fd)


def check_chain(chain):
    for item in chain:
        linked = (os.lstat('/') if item['parent_fd'] is None else
                  os.stat(item['name'], dir_fd=item['parent_fd'], follow_symlinks=False))
        need(directory_identity(os.fstat(item['fd'])) == item['identity'] == directory_identity(linked),
             'held fixed directory path or identity changed: ' + item['path'])


report = {'schema': 'hepta-r28-fixed-linux-data-staging/v1', 'passed': False,
          'expected_file_count': 4, 'created_files': [], 'directories': [],
          'payload': {'bytes': PAYLOAD_BYTES, 'sha256': PAYLOAD_SHA256},
          'all_inputs_verified_before_writes': False, 'all_four_targets_initially_absent': False,
          'original_eighteen_requests_modified': False, 'payload_executed': False,
          'archives_extracted': False, 'installer_executed': False,
          'qualification_or_measurement_executed': False, 'qualification_success_claimed': False,
          'services_modified': False, 'existing_files_replaced': False,
          'files_deleted': False, 'automatic_retries': 0, 'partial_failure_files_preserved': True}
chain = []
try:
    need(sys.platform == 'linux' and os.geteuid() == OWNER, 'fixed native Linux owner required')
    raw = sys.stdin.buffer.read(1048577)
    need(0 < PAYLOAD_BYTES <= 1048576 and len(raw) == PAYLOAD_BYTES and digest(raw) == PAYLOAD_SHA256,
         'complete frozen staging payload differs')
    value = json.loads(raw)
    need(type(value) is dict and set(value) == {'schema', 'requests'}
         and value['schema'] == 'hepta-r28-fixed-linux-staging-input/v1'
         and type(value['requests']) is list and len(value['requests']) == len(FILES) == 4,
         'fixed four-file payload shape differs')
    prepared = []
    for request, (directory, name, size, expected_sha) in zip(value['requests'], FILES, strict=True):
        path = ROOT + ('/tools/' if directory == 'tools' else '/') + name
        need(directory in ('root', 'tools') and '/' not in name and name not in ('', '.', '..')
             and type(request) is dict and set(request) == {'host', 'path', 'data_base64', 'expected_version'}
             and request['host'] == 'x230' and request['expected_version'] == 'absent'
             and request['path'] == path, 'fixed file request differs')
        body = base64.b64decode(request['data_base64'], validate=True)
        need(base64.b64encode(body).decode() == request['data_base64']
             and len(body) == size and digest(body) == expected_sha, 'frozen file body differs: ' + name)
        prepared.append((directory, name, body, expected_sha))
    report['all_inputs_verified_before_writes'] = True

    # Hold every component. Existing roots are not empty staging directories;
    # inspect only these directory identities and the four exact target names.
    parts = (('/', 0), ('home', 0), ('qian', OWNER),
             ('hepta-runtime-optimization-20261105-r25', OWNER), ('tools', OWNER))
    for name, owner in parts:
        parent_fd = chain[-1]['fd'] if chain else None
        fd = os.open(name, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW | os.O_CLOEXEC,
                     **({'dir_fd': parent_fd} if parent_fd is not None else {}))
        entry = {'fd': fd, 'parent_fd': parent_fd, 'name': name,
                 'path': '/' if not chain else chain[-1]['path'].rstrip('/') + '/' + name}
        chain.append(entry)
        actual = directory_identity(os.fstat(fd))
        need(actual[2] == owner, 'fixed directory owner differs: ' + entry['path'])
        entry['identity'] = actual
        check_chain(chain)
        report['directories'].append({'path': entry['path'], 'device': actual[0],
                                      'inode': actual[1], 'uid': actual[2], 'mode': actual[3]})
    directory_fds = {'root': chain[-2]['fd'], 'tools': chain[-1]['fd']}
    for directory, name, _, _ in prepared:
        try:
            os.stat(name, dir_fd=directory_fds[directory], follow_symlinks=False)
        except FileNotFoundError:
            pass
        else:
            raise RuntimeError('fixed target already exists: ' + name)
    check_chain(chain)
    report['all_four_targets_initially_absent'] = True
    os.umask(0o077)
    for directory, name, body, expected_sha in prepared:
        check_chain(chain)
        fd = os.open(name, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW | os.O_CLOEXEC,
                     0o600, dir_fd=directory_fds[directory])
        row = {'path': ROOT + ('/tools/' if directory == 'tools' else '/') + name,
               'created': True, 'verified': False}
        report['created_files'].append(row)
        try:
            remaining = memoryview(body)
            while remaining:
                count = os.write(fd, remaining)
                need(count > 0, 'file write made no progress')
                remaining = remaining[count:]
            os.fsync(fd)
            created_stamp = file_stamp(os.fstat(fd))
        finally:
            os.close(fd)
        row.update(verify_file(directory_fds[directory], name, body, expected_sha, created_stamp), verified=True)
    for fd in directory_fds.values():
        os.fsync(fd)
    check_chain(chain)
    for (directory, name, body, expected_sha), row in zip(prepared, report['created_files'], strict=True):
        final = verify_file(directory_fds[directory], name, body, expected_sha)
        need(all(row[key] == item for key, item in final.items()), 'staged file changed before final receipt')
    check_chain(chain)
    report['passed'] = True
    report['staged_file_count'] = len(report['created_files'])
except BaseException as error:
    report['error'] = {'type': type(error).__name__, 'reason': str(error)[:2000]}
finally:
    for item in reversed(chain):
        os.close(item['fd'])
print(json.dumps(report, sort_keys=True, allow_nan=False), flush=True)
sys.exit(0 if report['passed'] else 1)
