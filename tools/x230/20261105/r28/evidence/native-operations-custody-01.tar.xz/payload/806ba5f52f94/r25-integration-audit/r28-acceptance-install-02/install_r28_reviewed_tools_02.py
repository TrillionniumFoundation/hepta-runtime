#!/usr/bin/env python3
"""Create only the reviewed R28 tools after original qualification; run no tools."""
import argparse
import datetime
import hashlib
import io
import json
import os
from pathlib import Path, PurePosixPath
import re
import stat
import sys
import tarfile

sys.dont_write_bytecode = True
STAGE_ROOT = Path('/home/qian/hepta-runtime-optimization-20261105-r25')
ROOT = Path('/home/qian/hepta-runtime-optimization-20261105-r28')
SOURCE = ROOT / 'source'
CANDIDATE_DIR = ROOT / 'qualification-01'
SCRIPT = STAGE_ROOT / 'tools/install_r28_reviewed_tools_02.py'
QUALIFICATION_INPUT = STAGE_ROOT / 'tools/r28-installation-qualification-02.json'
RECEIPT = 'tools-install-02-receipt.json'
NEW_DIRECTORIES = ('tools-02', 'lifecycle-tools-02', 'lifecycle-launcher-bundle-02',
                   'lifecycle-launcher-bundle-02/tools-02')
PARENT_INSTALL = {
    'tools-02/r28_lifecycle_campaign.py': str(ROOT / 'tools-02/r28_lifecycle_campaign.py'),
    'tools-02/prepare_lifecycle_inputs.py': str(ROOT / 'tools-02/prepare_lifecycle_inputs.py'),
    'lifecycle-inputs-01.example.json': str(ROOT / 'lifecycle-inputs-01.example.json'),
}
ROOT_FILES = {'campaign-inputs-01.example.json', 'observation-plan-01.json',
              'observation-tools-manifest-01.json', 'lifecycle-inputs-01.example.json'}
ARCHIVES = {'lifecycle': {'bytes': 83479,
               'expanded_bytes': 384752,
               'member_count': 28,
               'members': {'README.md': {'bytes': 9053,
                                         'sha256': 'bf5ece8988afa5a91f01da1df0e1740add1390f6653d32c7bd562d99b11529be'},
                           'allocator_environment.py': {'bytes': 5879,
                                                        'sha256': 'f5c8e879c540b3f7cb1b7d3a7a0f5002c2f40c1a87963174b0b00470fa3a4525'},
                           'allocator_environment_audit.py': {'bytes': 6709,
                                                              'sha256': '4b082ce343ae3943e3098baa58af2f5def7198881b9c087d63d88360e9763727'},
                           'analyze_lifecycle_gates.py': {'bytes': 7581,
                                                          'sha256': 'c7a861a94a89dd81debb5c055773918d89a1c9c29b699e2e5a0341e51be69553'},
                           'analyze_native_observation.py': {'bytes': 8708,
                                                             'sha256': 'cc7f6884d581cd1ced430437350e808de51931c50d12441797205501b20cae66'},
                           'audit_native_evidence.py': {'bytes': 17065,
                                                        'sha256': 'b69f6902d2de81eab41b21506f024c002d2f8264d60e86df6b1086623a77fd28'},
                           'cancel_saturation_gate.py': {'bytes': 15789,
                                                         'sha256': '536ebdc5f2b090a8c007f189a895ed2e19d7b8b7e41530ccba94dd826742ef7f'},
                           'lifecycle-gate-policy.json': {'bytes': 1575,
                                                          'sha256': '36658346c4e265bf551a1ae1a4c6210bec8e4729f7961302a203008741cd381e'},
                           'lifecycle-tools-manifest-01.json': {'bytes': 4066,
                                                                'sha256': 'ef44e7593c124eea2005cd92396d3a95e72ba863ec2035235bb5cd20d082c3d1'},
                           'observation_resources.py': {'bytes': 12382,
                                                        'sha256': 'f3402d51cb37b2fe20f4351b3a81ec5990a9fdaff93a846d21c07ccd557cb894'},
                           'owned_ssh_interruption.py': {'bytes': 7892,
                                                         'sha256': '1989c57f0b944afae1ed759d6529b8f1cc26197e269e2c34c4fd49e43a32aa7b'},
                           'run_lifecycle_abba_01.py': {'bytes': 14787,
                                                        'sha256': '83d0c13934999069526db7daf6191ea5cf5ed9d95cbcbf25c6a43e1b37676520'},
                           'run_lifecycle_tool_tests.py': {'bytes': 2224,
                                                           'sha256': 'e3c1e8163249dba14672a3a82b43a2d7b8b4c0802b94b8511bf3db668f865a2d'},
                           'run_native_observation.py': {'bytes': 3279,
                                                         'sha256': '7606648c99b2ff2bbf0bba58384e8cab609ac3899f838c0b80ba54d6288d20bb'},
                           'run_six_host_cancel_recovery.py': {'bytes': 27847,
                                                               'sha256': '698eb7801cde3f2bd5ff202412c0833fc218fd7e912c3c949d2b37fde7a56a12'},
                           'run_six_host_cancel_recovery_timed.py': {'bytes': 30163,
                                                                     'sha256': '595b5d7bd791d4f9be102e7734c40cabd2ba90412fffaff1f6cc4adb7a8a52c9'},
                           'run_six_host_cancel_saturation.py': {'bytes': 31325,
                                                                 'sha256': '2798148236e1ac802a6c36ef65b65cc91a07a28ef1de1324e8da4c8481e10754'},
                           'source-provenance.json': {'bytes': 2510,
                                                      'sha256': '58d276c8df05dcd95a0a25e6264c3de1b248e8bb821651fb1b52859dd707dbbe'},
                           'status-predicate.json': {'bytes': 875,
                                                     'sha256': '5828c7ba2990f38531cce7e1a42b44315ee42278ccaee361ace8d9472a96da34'},
                           'summarize_lifecycle_abba_01.py': {'bytes': 16065,
                                                              'sha256': '9e050343bb32e7f57148f633ff94bbcfb3a7452b2872ae68404ca642e937af89'},
                           'test_native_harness.py': {'bytes': 13286,
                                                      'sha256': '2b450175b9e6122248ac1bcb51860aa8a6d3eff55f6ac8c877c0a905e3dd7d00'},
                           'test_r25_lifecycle_tools.py': {'bytes': 10026,
                                                           'sha256': '1845cdb48440a03146e337af7baf916bb9cdb76fb46ea0699f79144cf7197566'},
                           'test_verify_saturation_extension.py': {'bytes': 8187,
                                                                   'sha256': '10f2dcbfa9e2b5c625f22c3edc32c9f8a969509345b20d9b135cebc2235c16fb'},
                           'verify_cancel_recovery.py': {'bytes': 16634,
                                                         'sha256': '0116652a0b489dc462f005e01d7c943feda9ba784563d7317c92bb5beb9a701c'},
                           'verify_cancel_saturation.py': {'bytes': 17123,
                                                           'sha256': 'd3b6772ddffc711a23aa4aa9566f903c149535a3d3c4cc3466ee73690cbc1e75'},
                           'verify_saturation_extension.py': {'bytes': 9418,
                                                              'sha256': '23dfd25517b517067a4fbb3f4a3227f12bafff46b828eb05f7bf322596124e6a'},
                           'x230_observation_benchmark.py': {'bytes': 37006,
                                                             'sha256': '4d96f0bf2da2562e788f48be7c37589ab3a513be5f9d8b2d741afe5c08ea9eed'},
                           'x230_six_running_recovery_canary.py': {'bytes': 47298,
                                                                   'sha256': '6219bc556b0ac6d142bd4c731466b959e8a410f0b4b55f3d8b303f8fdbfbaaf4'}},
               'path': '/home/qian/hepta-runtime-optimization-20261105-r25/staged-r28-lifecycle-tools-02.tar.gz',
               'sha256': '2b309d12b7af0116560e2356d9c8b7cf44320adb71b01db7dcba756d3bb31cee'},
 'observation': {'bytes': 35760,
                 'expanded_bytes': 132726,
                 'member_count': 10,
                 'members': {'campaign-inputs-01.example.json': {'bytes': 3818,
                                                                 'sha256': '4f779bbf9f38ea047a684d642c7a71877eb36a8da8d545f817f43f7406f83bb4'},
                             'observation-plan-01.json': {'bytes': 11188,
                                                          'sha256': 'e0f76817d9d20c5d2f376374fd36495533962428b836259a520278e29f155d3b'},
                             'observation-tools-manifest-01.json': {'bytes': 1901,
                                                                    'sha256': '728a4eb154d3317cfd8e668d5f4e63543be9eeacce5752852bf3af1cfbfb70c2'},
                             'tools-02/compiler-monitor-policy-01.json': {'bytes': 1001,
                                                                          'sha256': 'ddb2e03d4a1a1610466a5dc2d1a544f554ad12fc31412483101b48a235402368'},
                             'tools-02/compiler_monitor.py': {'bytes': 12510,
                                                              'sha256': 'afb514362a9d8dd573b806f0dc87df16bd3a906e4574d10d91bf483b2e76cdcf'},
                             'tools-02/compiler_state.py': {'bytes': 6243,
                                                            'sha256': '9da718654db04a646e081d2d719a2d6d4655ffe337bc0e3f906e736e4d77a251'},
                             'tools-02/prepare_campaign_inputs.py': {'bytes': 9964,
                                                                     'sha256': '49920f4f15da8ad635a103b51e136d7fbbaf3002acdd69a7ee2d11ac7511add8'},
                             'tools-02/r28_campaign.py': {'bytes': 64590,
                                                          'sha256': '52c2c2777d44d071896b6a25d5c9f178b66989e501abff63fb4fc2a01ee4b2d9'},
                             'tools-02/summarize_r25_campaign.py': {'bytes': 14456,
                                                                    'sha256': '2418bad36fe4aef75d52c5a00c898ff93fef9bb4b6efb10028105143106a1864'},
                             'tools-02/validate_compiler_monitor.py': {'bytes': 7055,
                                                                       'sha256': 'd2cd009adf1f35a394ffddcc8f8646cc0c1b856b78181ca321ea68f6468218b2'}},
                 'path': '/home/qian/hepta-runtime-optimization-20261105-r25/staged-r28-observation-tools-02.tar.gz',
                 'sha256': '250fcac0c9d3cd8cae043f957a3ab6c04c4700fab85e1a66697000c6e1a09718'},
 'parent': {'bytes': 21770,
            'expanded_bytes': 89369,
            'member_count': 9,
            'members': {'README.md': {'bytes': 3172,
                                      'sha256': '3bc3cd1887ca97cc7a9fc5915ce2e24b30c7be1190e7036ea7ec3360f7d87653'},
                        'derivation-inputs-02.json': {'bytes': 9828,
                                                      'sha256': '7a9aaecfb074b25b3b1676db61f8825e0b619d019115247121acf90f04996a0b'},
                        'lifecycle-inputs-01.example.json': {'bytes': 2585,
                                                             'sha256': '3f63577f0cc3273a76778633cf76ed7806ca3714ced642d029de018e386b6551'},
                        'lifecycle-launcher-manifest-01.json': {'bytes': 2340,
                                                                'sha256': '50342b67d8f0459a58eaf500e99668cbfec80870869841ab721371fd65b3cd15'},
                        'lifecycle-plan-01.json': {'bytes': 10395,
                                                   'sha256': '6ed797ea11d027df742c3d9fe71f1d4472f1e956d663d1caf1bd9f183a67fa30'},
                        'local-verification-02.json': {'bytes': 2232,
                                                       'sha256': '18507ce39cde8ec8aed29261e5d8ce156fc55528985cf3dcb1a68df777c9608c'},
                        'source-delta-02.patch': {'bytes': 19991,
                                                  'sha256': '8fbb106a8d78a74ae11e447803855fe6332f0114891d189f7c7ba21dc7be2f8e'},
                        'tools-02/prepare_lifecycle_inputs.py': {'bytes': 12066,
                                                                 'sha256': 'e45c8333eca30f49505fd8d22955b1a8b6f79d7df8c561643deebf325e9451a7'},
                        'tools-02/r28_lifecycle_campaign.py': {'bytes': 26760,
                                                               'sha256': '5a7f60e4d61ce69ed9962a47956045710908455c90fc3048035287232d4c84ce'}},
            'path': '/home/qian/hepta-runtime-optimization-20261105-r25/staged-r28-lifecycle-launcher-bundle-02.tar.gz',
            'sha256': 'ded090e4f2754851f06fa7bef51bee0a9100a64e7815fd321c6baeb79ba4958b'}}
HEX = re.compile(r'[0-9a-f]{64}\Z')


def need(value, message):
    if not value:
        raise RuntimeError(message)


def encoded(value):
    return (json.dumps(value, sort_keys=True, indent=2, allow_nan=False) + '\n').encode()


def identity(raw):
    return {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


def stamp(value):
    return tuple(getattr(value, name) for name in
                 ('st_dev', 'st_ino', 'st_uid', 'st_mode', 'st_nlink', 'st_size', 'st_mtime_ns', 'st_ctime_ns'))


def read_path(path, expected=None, maximum=128 * 1024 * 1024, retain=True):
    path = Path(path)
    need(path.is_absolute() and path.resolve(strict=True) == path, 'indirect or missing input path')
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_CLOEXEC | os.O_NONBLOCK)
    try:
        before = os.fstat(fd)
        need(stat.S_ISREG(before.st_mode) and before.st_nlink == 1 and before.st_uid == os.geteuid()
             and 0 <= before.st_size <= maximum, 'unsafe or oversized owned input')
        digest, size, chunks = hashlib.sha256(), 0, []
        while block := os.read(fd, 1024 * 1024):
            size += len(block)
            need(size <= before.st_size, 'input grew while reading')
            digest.update(block)
            if retain:
                chunks.append(block)
        need(size == before.st_size and stamp(before) == stamp(os.fstat(fd)) == stamp(path.lstat()),
             'input identity changed while reading')
    finally:
        os.close(fd)
    result = {'path': str(path), 'bytes': size, 'sha256': digest.hexdigest()}
    if expected is not None:
        need(type(expected.get('bytes')) is int and HEX.fullmatch(expected.get('sha256', ''))
             and result == {key: expected[key] for key in result}, 'actual input identity differs')
    return result, b''.join(chunks)


def read_at(directory, name, expected):
    need(Path(name).name == name, 'only direct file names are permitted')
    fd = os.open(name, os.O_RDONLY | os.O_NOFOLLOW | os.O_CLOEXEC | os.O_NONBLOCK, dir_fd=directory)
    try:
        before = os.fstat(fd)
        need(stat.S_ISREG(before.st_mode) and before.st_nlink == 1 and before.st_uid == os.geteuid()
             and 0 <= before.st_size == expected['bytes'] <= 1048576, 'unsafe installed file')
        with os.fdopen(os.dup(fd), 'rb') as stream:
            raw = stream.read(expected['bytes'] + 1)
        need(stamp(before) == stamp(os.fstat(fd)) == stamp(os.stat(name, dir_fd=directory, follow_symlinks=False))
             and identity(raw) == expected, 'installed file identity differs')
        return {'device': before.st_dev, 'inode': before.st_ino, 'uid': before.st_uid,
                'mode': stat.S_IMODE(before.st_mode), 'links': before.st_nlink, **identity(raw)}
    finally:
        os.close(fd)


def members_from_archive(raw, spec):
    need(identity(raw) == {key: spec[key] for key in ('bytes', 'sha256')}, 'archive identity differs')
    result = {}
    with tarfile.open(fileobj=io.BytesIO(raw), mode='r:gz') as archive:
        entries = archive.getmembers()
        need(len(entries) == spec['member_count'] and sum(entry.size for entry in entries) == spec['expanded_bytes']
             and spec['expanded_bytes'] <= 1048576, 'archive member count or expansion differs')
        for entry in entries:
            path = PurePosixPath(entry.name)
            need(entry.type in (tarfile.REGTYPE, tarfile.AREGTYPE) and not entry.issparse()
                 and not entry.linkname and path.parts and not path.is_absolute()
                 and all(part not in ('.', '..') for part in path.parts)
                 and path.as_posix() == entry.name and entry.name in spec['members']
                 and entry.name not in result, 'unexpected, linked, duplicate or unsafe archive member')
            expected = spec['members'][entry.name]
            need(entry.size == expected['bytes'], 'archive member size differs')
            stream = archive.extractfile(entry)
            need(stream is not None, 'regular member unreadable')
            body = stream.read(expected['bytes'] + 1)
            need(identity(body) == expected, 'archive member SHA differs')
            result[entry.name] = body
        need(set(result) == set(spec['members']), 'archive member set differs')
    return result


def verify_r28_candidate_preparation(preparation, terminal, job_id, qualified, tests):
    """Verify the actual new cache-only R28 qualification; no future success is inferred."""
    need(isinstance(job_id, str) and re.fullmatch(r"[0-9a-f]{11,16}-[0-9a-f]{4}-[0-9a-f]{4}", job_id)
         and job_id not in {"1a1aa7fa690-fc05-43af", "1a1aaa6552d-fc05-459f", "1a1ab4cb0fc-fc05-4c3c",
                            "1a1ac274e49-fc05-5286", "1a1ac456b07-fc05-532a"},
         "the actual new R28 qualification job is required")
    need(terminal.get("job_id") == job_id and terminal.get("state") == "succeeded"
         and type(terminal.get("exit_code")) is int and terminal["exit_code"] == 0
         and all(terminal.get(key) is False for key in ("automatic_retry", "timed_out", "cancelled"))
         and all(terminal.get(key) is True for key in ("output_complete", "output_durable", "terminal_publication_confirmed"))
         and type(terminal.get("terminal_publication_protocol")) is int and terminal["terminal_publication_protocol"] == 1
         and terminal.get("log_synced") == {"stdout": True, "stderr": True}
         and terminal.get("log_errors") == {"stdout": None, "stderr": None}
         and terminal.get("log_truncated") == {"stdout": False, "stderr": False},
         "original R28 qualification has no complete successful native terminal proof")
    for stream in ("stdout", "stderr"):
        counts = terminal["log_bytes"][stream]
        need(set(counts) == {"seen", "stored"} and all(type(value) is int and value >= 0 for value in counts.values())
             and counts["seen"] == counts["stored"], "qualification native log byte custody differs")
    need(preparation["schema"] == "hepta-r28-qualified-parent-preparation/v1"
         and preparation["selected_proposal"] == "cache only" and preparation.get("optional_pidfd_selected") is False
         and preparation.get("finished_utc")
         and all(preparation.get(key) is True for key in ("passed", "candidate_qualified", "parent_source_qualified",
             "parent_lifecycle_rejection_preserved", "parent_inputs_unchanged"))
         and all(preparation.get(key) is False for key in ("candidate_adopted", "parent_candidate_adopted",
             "production_services_modified", "shared_hardlinks_created")), "actual R28 preparation is incomplete")
    need(preparation["source"] == str(SOURCE) and preparation["target"] == str(ROOT / "target-build")
         and preparation["qualification_output"] == str(CANDIDATE_DIR)
         and preparation["launcher"] == {"path": "/home/qian/hepta-runtime-optimization-20261105-r25/tools/prepare_and_qualify_r28_02.py",
             "bytes": 30059, "sha256": "6bef1776c36294d05a3796b2b4e3c79a07b15ed69122e3a2685705bfeb031239"}
         and preparation["input"] == {"path": "/home/qian/hepta-runtime-optimization-20261105-r25/tools/r28-qualification-02-input.json",
             "bytes": 82496, "sha256": "9173851d84e44421531df32ae2dcad9fd89a707664b2d7b8853965df2f24d3ae"},
         "R28 qualification launcher, input or private paths differ")
    # These are original negative outcomes and the actual read-only space observation.
    # They remain negative; no cleanup or successful inventory is inferred.
    preserved_admission = {'admission_absent_paths': ['/home/qian/hepta-runtime-optimization-20261105-r28/source',
                            '/home/qian/hepta-runtime-optimization-20261105-r28/target-build',
                            '/home/qian/hepta-runtime-optimization-20261105-r28/qualification-01',
                            '/home/qian/hepta-runtime-optimization-20261105-r28/preparation-02.json',
                            '/home/qian/hepta-runtime-optimization-20261105-r28/qualification-input-02.json',
                            '/home/qian/hepta-runtime-optimization-20261105-r28/qualification-terminal-status-02.json'],
 'cache_retirement_executed_by_this_qualifier': False,
 'cleanup_executed': False,
 'cleanup_operation': None,
 'original_admission_failure_preserved': True,
 'original_candidate_input': {'bytes': 34557,
                              'path': '/home/qian/hepta-runtime-optimization-20261105-r28/qualification-input-01.json',
                              'sha256': '0837e858fddf7df95229a5dac1dafdf6d904800caad46cb238ba18ecfaa93299'},
 'original_failed_admission': {'exit_code': 1,
                               'job_id': '1a1ac274e49-fc05-5286',
                               'label': 'original_failed_admission',
                               'native_read': {'bytes': 723,
                                               'sha256': '5a0beef68de943554f08936dacec1a66c4b8e2af66f6c7ea9aa9387cc852e35a'},
                               'original_complete_streams_proved': True,
                               'state': 'failed',
                               'stderr': {'bytes': 0,
                                          'sha256': 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855'},
                               'stdout': {'bytes': 131,
                                          'sha256': '3613580074731c44ad27d2687ec2e8c177fd81eef7d9b2148d0b8ef10df886fc'},
                               'terminal': {'bytes': 726,
                                            'sha256': '8dee0438ff40dc85288ff6d9ff6da9dfcdfc36092bbc12995bd99018f3d00d31'}},
 'original_failed_admission_inputs_unchanged': True,
 'original_native_read': {'bytes': 723,
                          'path': '/home/qian/hepta-runtime-optimization-20261105-r28/qualification-native-read-01.json',
                          'sha256': '5a0beef68de943554f08936dacec1a66c4b8e2af66f6c7ea9aa9387cc852e35a'},
 'original_native_terminal': {'bytes': 726,
                              'path': '/home/qian/hepta-runtime-optimization-20261105-r28/qualification-terminal-status-01.json',
                              'sha256': '8dee0438ff40dc85288ff6d9ff6da9dfcdfc36092bbc12995bd99018f3d00d31'},
 'original_preparation': {'bytes': 4671,
                          'path': '/home/qian/hepta-runtime-optimization-20261105-r28/preparation-01.json',
                          'sha256': 'abc26b3d49c2e57b608fe3aba792708e80de95340c1c8c210dced2844953fade'},
 'space_recovery_mode': 'observed_space_sufficient_no_cleanup',
 'space_recovery_observation': {'all_same_owner_reference_channels_inspected': False,
                                'available_bytes': 7478648832,
                                'cleanup_executed': False,
                                'cleanup_operation': None,
                                'copy_cache_bytes': 3080991421,
                                'excess_over_required_bytes': 1176431939,
                                'inventory_overall_passed': False,
                                'old_cache_absence_cause_inferred': False,
                                'original_inventory_native_exit_code': 1,
                                'original_inventory_native_state': 'failed',
                                'process_reference_scans_complete': False,
                                'required_headroom_bytes': 3221225472},
 'space_recovery_proofs': {'readonly_inventory': {'exit_code': 1,
                                                  'job_id': '1a1ac456b07-fc05-532a',
                                                  'label': 'readonly_inventory',
                                                  'native_read': {'bytes': 42578,
                                                                  'sha256': 'd232070f29ce310dd2f304f75bc661ebf937582f0b1e179cc94dd88e80e1dcb1'},
                                                  'original_complete_streams_proved': True,
                                                  'state': 'failed',
                                                  'stderr': {'bytes': 0,
                                                             'sha256': 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855'},
                                                  'stdout': {'bytes': 13686,
                                                             'sha256': '3c2e43bbaeb2914c6372653ba1ea79d196af451aed75a9cb9ce4fac313769dda'},
                                                  'terminal': {'bytes': 730,
                                                               'sha256': 'c06d88c67b142ad33bcab37cf4cd51d9235dd14cc0e046927cf5aa53429d365b'}}},
 'unchanged_disk_reserve_bytes': 3221225472}
    for name, expected_value in preserved_admission.items():
        need(preparation.get(name) == expected_value, "R28 preserved admission evidence differs: " + name)
    need(all(preparation.get(name) is True for name in
             ("original_admission_failure_preserved", "original_failed_admission_inputs_unchanged"))
         and all(preparation.get(name) is False for name in
                 ("cache_retirement_executed_by_this_qualifier", "cleanup_executed"))
         and preparation.get("cleanup_operation") is None, "R28 original failures or no-cleanup scope changed")
    original_names = ("original_preparation", "original_candidate_input", "original_native_terminal", "original_native_read")
    originals = {preparation[name]["path"]: preparation[name] for name in original_names}
    descriptors = preparation.get("original_file_identities")
    descriptor_keys = {"st_dev", "st_ino", "st_mode", "st_uid", "st_nlink", "st_size", "st_mtime_ns", "st_ctime_ns"}
    need(isinstance(descriptors, dict) and set(descriptors) == set(originals), "four original file identities required")
    for path, pin in originals.items():
        descriptor = descriptors[path]
        need(isinstance(descriptor, dict) and set(descriptor) == descriptor_keys
             and all(type(value) is int and value >= 0 for value in descriptor.values())
             and descriptor["st_ino"] > 0 and descriptor["st_uid"] == 1000 and descriptor["st_nlink"] == 1
             and descriptor["st_size"] == pin["bytes"] and descriptor["st_mode"] & 0o170000 == 0o100000
             and not descriptor["st_mode"] & 0o6000, "original preserved file descriptor differs: " + path)
        need(preparation["bound_parent_inputs"].get(path) == pin, "original preserved file final byte binding differs: " + path)
    known_original_descriptors = {
        '/home/qian/hepta-runtime-optimization-20261105-r28/preparation-01.json': {'st_ctime_ns': 1793889622435153369, 'st_dev': 2053, 'st_ino': 2259040, 'st_mode': 33152, 'st_mtime_ns': 1793889622435153369, 'st_nlink': 1, 'st_size': 4671, 'st_uid': 1000},
        '/home/qian/hepta-runtime-optimization-20261105-r28/qualification-input-01.json': {'st_ctime_ns': 1793889621996152717, 'st_dev': 2053, 'st_ino': 2259039, 'st_mode': 33152, 'st_mtime_ns': 1793889621996152717, 'st_nlink': 1, 'st_size': 34557, 'st_uid': 1000},
    }
    need(all(descriptors[path] == expected_value for path, expected_value in known_original_descriptors.items()),
         "original preparation/input descriptor identity differs from the actual inventory")
    need(type(preparation["cache_bytes"]) is int and preparation["cache_bytes"] > 0
         and type(preparation["disk_available_before_bytes"]) is int
         and preparation["disk_available_before_bytes"] >= preparation["cache_bytes"] + 3221225472,
         "actual R28 cache admission did not retain the original 3 GiB reserve")
    need(type(preparation["qualification_returncode"]) is int and preparation["qualification_returncode"] == 0
         and type(preparation["automatic_test_retries"]) is int and preparation["automatic_test_retries"] == 0,
         "R28 qualification did not finish once with exit zero")
    expected_changes = [{'path': 'src/mcp/runtime/jobs.rs',
  'before': {'bytes': 186504, 'sha256': '8a80623ccf9131e520ed5f25647200bd2086e4718b892eed90c1530a5ccb9283'},
  'after': {'bytes': 186541, 'sha256': '061c2576e3c1dd8a1e4f5bfd7d3498f7cc4141d6577d53365a9a4738c7980af6'}},
 {'path': 'src/mcp/runtime/ssh.rs',
  'before': {'bytes': 18943, 'sha256': '0c0bf93da7d8d391b79d026544dc7ff71974bd1eabb06e5fe319892174843189'},
  'after': {'bytes': 19820, 'sha256': 'b674dfcb60bc57c46a08f1ab1f424a8aadcdb2078abdcfdff30f71632e807b3d'}},
 {'path': 'src/mcp/runtime/ssh_tests.rs',
  'before': {'bytes': 4652, 'sha256': '39dacf3f7839b7a013b24b2ec63bd9cf7b51599ebaebc1e5e074cfb98ae79893'},
  'after': {'bytes': 4931, 'sha256': '98f18f6cd89776b7589a9864224683d49f4b0cb663467475aa721c52dfff0a57'}}]
    need(preparation["source_changes"] == expected_changes, "qualified selection is not the exact three-file cache-only change")
    before = preparation["source_before"]
    expected = dict(before)
    changed_paths = {change["path"] for change in expected_changes}
    need(len(before) == 221 and len(changed_paths) == 3, "R28 parent source-map or change count differs")
    for change in expected_changes:
        need(before[change["path"]] == change["before"]["sha256"], "R28 exact qualified parent preimage differs")
        expected[change["path"]] = change["after"]["sha256"]
    need(preparation["candidate_compilation_inputs"] == expected, "R28 pre-format source map differs")
    stages = ["format", "fmt-check", "harness-tests", "clippy", "test-build", "isolated-tests", "audit-isolated-tests", "release"]
    need(qualified["schema"] == "hepta-x230-composed-qualification/v1" and qualified["qualified"] is True
         and qualified.get("finished_utc") and qualified["source"] == str(SOURCE)
         and qualified["jobs"] == 2 and qualified["service_changes"] is False
         and type(qualified["automatic_test_retries"]) is int and qualified["automatic_test_retries"] == 0
         and [row["name"] for row in qualified["stages"]] == stages
         and all(type(row["returncode"]) is int and row["returncode"] == 0 for row in qualified["stages"]),
         "all eight original R28 qualification stages must pass")
    need(qualified["source_input"] == expected and qualified["source_tested"] == qualified["source_after"] == preparation["source_tested"]
         and set(qualified["source_after"]) == set(expected)
         and all(qualified["source_after"][name] == value for name, value in expected.items() if name not in changed_paths),
         "actual formatted R28 source differs from its qualified preparation")
    need(preparation["formatter_changed_paths"] == [name for name in expected if qualified["source_after"][name] != expected[name]]
         and qualified["harness_before"] == qualified["harness_after"] == preparation["harness_before"]
         and len(qualified["harness_after"]) == 19, "qualification formatter or original harness binding differs")
    counts = ("passed", "failed", "ignored", "selected", "retries")
    need(all(type(tests[key]) is int for key in counts)
         and [tests[key] for key in counts] == [1653, 0, 34, 1687, 0]
         and preparation["tests"] == tests, "original full R28 isolated test result is incomplete")
    return {"passed": True, "original_job_id": job_id, "selected_proposal": "cache only", "optional_pidfd_selected": False,
            "qualified_source_files": 221, "harness_files": 19, "stages": stages,
            "tests": {key: tests[key] for key in counts}, "candidate_adopted": False,
            "qualified_parent_R26_lifecycle_rejection_preserved": True,
            "original_failed_admission_preserved": True, "original_failed_inventory_preserved": True,
            "space_recovery_mode": "observed_space_sufficient_no_cleanup", "cleanup_executed": False}


def verify_qualification_documents(value, preparation, terminal, qualified, summary, audit, source_map):
    need(value['schema'] == 'hepta-r28-installation-qualification/v1'
         and value['executed'] is False, 'actual qualification input schema differs')
    proof = verify_r28_candidate_preparation(preparation, terminal, value['original_qualification_job_id'], qualified, summary)
    need(type(preparation.get('finished_utc')) is str and bool(preparation['finished_utc'])
         and preparation['qualification_report'] == value['qualification_report']
         and source_map == qualified['source_after'], 'completed preparation/source-map binding differs')
    need(summary['schema'] == 'hepta-isolated-libtest/v1' and summary['success'] is True
         and summary['filter'] == '' and summary['enumeration_errors'] == []
         and summary['source_manifest_path'] == str(CANDIDATE_DIR / 'source-map.json')
         and summary['source_manifest_sha256'] == value['source_map']['sha256'], 'full actual isolated summary differs')
    need(audit['schema'] == 'hepta-isolated-libtest-audit/v1' and audit['success'] is True
         and audit['errors'] == [] and 'fatal_error' not in audit and audit['expected_filter'] == ''
         and audit['input_sha256']['summary.json'] == value['isolated_summary']['sha256']
         and all(audit[key] == summary[key] for key in ('passed', 'failed', 'ignored', 'selected'))
         and audit['executed'] == 1653, 'original independent isolated audit differs')
    return proof


def qualification_prerequisites(value, bind):
    paths = {
        'preparation': ROOT / 'preparation-02.json',
        'native_terminal': ROOT / 'qualification-terminal-status-02.json',
        'qualification_report': CANDIDATE_DIR / 'report.json',
        'source_map': CANDIDATE_DIR / 'source-map.json',
        'isolated_summary': CANDIDATE_DIR / 'isolated-tests/summary.json',
        'isolated_audit': CANDIDATE_DIR / 'isolated-tests.audit.json',
    }
    documents = {}
    for name, path in paths.items():
        need(value[name]['path'] == str(path), 'actual qualification receipt path differs')
        _, raw = bind(path, value[name])
        documents[name] = json.loads(raw)
    proof = verify_qualification_documents(value, documents['preparation'], documents['native_terminal'],
        documents['qualification_report'], documents['isolated_summary'], documents['isolated_audit'], documents['source_map'])
    qualified = documents['qualification_report']
    paths = [SOURCE / name for name in ('Cargo.toml', 'Cargo.lock', 'rustfmt.toml')]
    for name in ('src', 'examples'):
        paths.extend(path for path in (SOURCE / name).rglob('*') if path.is_file())
    actual = {path.relative_to(SOURCE).as_posix(): bind(path, retain=False)[0]['sha256'] for path in sorted(paths)}
    need(actual == qualified['source_after'], 'actual qualified source changed before tool installation')
    harness = {path.name: bind(path, retain=False)[0]['sha256']
               for path in sorted((SOURCE / 'tools/x230/20261028').glob('*.py'))}
    need(harness == qualified['harness_after'], 'actual qualification harness changed')
    binaries = {}
    need(set(qualified['binaries']) == {'hepta-runtime', 'hepta-runtime-jobctl', 'native_process_driver'},
         'qualified executable set differs')
    for name, item in qualified['binaries'].items():
        path = CANDIDATE_DIR / name
        need(item['path'] == str(path) and os.access(path, os.X_OK), 'qualified artifact path differs')
        row, _ = bind(path, retain=False)
        need(row['sha256'] == item['sha256'], 'actual qualified executable changed')
        binaries[name] = row
    for label in ('launcher', 'input'):
        item = documents['preparation'][label]
        need(Path(item['path']).parent == STAGE_ROOT / 'tools', 'qualification bootstrap input path differs')
        bind(item['path'], item, retain=False)
    proof.update(actual_binaries=binaries, source_files=len(actual), harness_files=len(harness))
    return proof


def build_installation(bundles):
    observation = json.loads(bundles['observation']['observation-tools-manifest-01.json'])
    lifecycle = json.loads(bundles['lifecycle']['lifecycle-tools-manifest-01.json'])
    parent = json.loads(bundles['parent']['lifecycle-launcher-manifest-01.json'])
    need(observation['schema'] == 'hepta-r28-observation-tools-install/v2'
         and observation['prepared_only'] is True and observation['create_only'] is True
         and observation['destination_root'] == str(ROOT) and len(observation['files']) == 9
         and set(observation['files']) == set(bundles['observation']) - {'observation-tools-manifest-01.json'},
         'observation payload manifest differs')
    need(lifecycle['schema'] == 'hepta-r25-lifecycle-tools/v1' and len(lifecycle['files']) == 27
         and set(lifecycle['files']) == set(bundles['lifecycle']) - {'lifecycle-tools-manifest-01.json'},
         'native lifecycle payload manifest differs')
    need(parent['schema'] == 'hepta-r28-lifecycle-launcher-bundle/v2'
         and parent['prepared_only'] is True and parent['create_only'] is True
         and parent['preserve_bundle_at'] == str(ROOT / 'lifecycle-launcher-bundle-02')
         and parent['installations'] == PARENT_INSTALL and len(parent['files']) == 8
         and set(parent['files']) == set(bundles['parent']) - {'lifecycle-launcher-manifest-01.json'},
         'outer lifecycle payload manifest differs')
    for label, manifest in (('observation', observation), ('lifecycle', lifecycle), ('parent', parent)):
        for name, pin in manifest['files'].items():
            need(identity(bundles[label][name]) == pin, 'payload manifest identity differs')
    need(parent['requires_observation_tools_manifest'] == identity(bundles['observation']['observation-tools-manifest-01.json'])
         and parent['requires_native_tools_manifest'] == identity(bundles['lifecycle']['lifecycle-tools-manifest-01.json']),
         'reviewed bundle dependencies disagree')
    obs_example = json.loads(bundles['observation']['campaign-inputs-01.example.json'])
    life_example = json.loads(bundles['parent']['lifecycle-inputs-01.example.json'])
    need(obs_example['launcher_sha256'] == life_example['campaign_helpers']['sha256']
         == identity(bundles['observation']['tools-02/r28_campaign.py'])['sha256']
         and life_example['launcher_sha256'] == identity(bundles['parent']['tools-02/r28_lifecycle_campaign.py'])['sha256']
         and life_example['tools_manifest']['sha256'] == identity(bundles['lifecycle']['lifecycle-tools-manifest-01.json'])['sha256'],
         'example helper identity differs')
    monitor = {}
    for label, name in {'module': 'compiler_monitor.py', 'validator': 'validate_compiler_monitor.py',
                        'reader': 'compiler_state.py', 'policy': 'compiler-monitor-policy-01.json'}.items():
        member = 'tools-02/' + name
        monitor[label] = {'path': str(ROOT / member), **identity(bundles['observation'][member])}
    need(obs_example['compiler_monitor'] == life_example['compiler_monitor'] == monitor,
         'actual four monitor paths or source identities differ between payload and templates')
    for example in (obs_example, life_example):
        need(example['attempt'] == '01' and example['candidate_release'] == 'R28'
             and example['qualification_terminal_status']['job_id'] is None
             and example['source_inputs_sha256'] is None
             and all(row == {'bytes': None, 'sha256': None} for row in example['candidate_binaries'].values()),
             'reviewed example was replaced by premature future evidence')
    plan = []
    for label, prefix in (('observation', ''), ('lifecycle', 'lifecycle-tools-02/'),
                           ('parent', 'lifecycle-launcher-bundle-02/')):
        for name, raw in sorted(bundles[label].items()):
            plan.append((prefix + name, raw, label, name))
    for name, path in sorted(PARENT_INSTALL.items()):
        plan.append((Path(path).relative_to(ROOT).as_posix(), bundles['parent'][name], 'parent', name))
    need(len(plan) == len({row[0] for row in plan}) == 50, 'installation collision or file count differs')
    for relative, _, _, _ in plan:
        path = PurePosixPath(relative)
        need(path.as_posix() == relative and not path.is_absolute() and '..' not in path.parts
             and ((path.parent.as_posix() == '.' and relative in ROOT_FILES)
                  or path.parent.as_posix() in NEW_DIRECTORIES), 'destination is outside fixed new scope')
    return plan


def absent(directory, name):
    try:
        os.stat(name, dir_fd=directory, follow_symlinks=False)
    except FileNotFoundError:
        return
    raise RuntimeError('existing destination must not be replaced: ' + name)


def create_file(directory, name, raw):
    need(Path(name).name == name, 'direct destination required')
    fd = os.open(name, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW | os.O_CLOEXEC, 0o600, dir_fd=directory)
    with os.fdopen(fd, 'wb') as stream:
        stream.write(raw)
        stream.flush()
        os.fsync(stream.fileno())
    result = read_at(directory, name, identity(raw))
    need(result['mode'] == 0o600, 'created file is not private')
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--installer-sha256', required=True)
    args = parser.parse_args()
    need(sys.platform == 'linux' and os.geteuid() != 0 and HEX.fullmatch(args.installer_sha256),
         'native Linux operator and reviewed source SHA required')
    need(Path(__file__).resolve() == SCRIPT and ROOT.resolve(strict=True) == ROOT,
         'fixed installer and existing qualifier-created R28 root required')
    os.umask(0o077)
    bindings, directories, created, created_dirs = [], {}, [], []
    root_fd = os.open(ROOT, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW | os.O_CLOEXEC)

    def bind(path, expected=None, retain=True):
        row, raw = read_path(path, expected, retain=retain)
        bindings.append(row)
        return row, raw

    try:
        before = os.fstat(root_fd)
        need(before.st_uid == os.geteuid() and stat.S_IMODE(before.st_mode) == 0o700,
             'qualifier-created root is not owned private0700')
        own, _ = bind(SCRIPT)
        need(own['sha256'] == args.installer_sha256, 'reviewed installer source changed')
        input_identity, raw = bind(QUALIFICATION_INPUT)
        qualification = qualification_prerequisites(json.loads(raw), bind)
        bundles, archive_rows = {}, {}
        for label, spec in ARCHIVES.items():
            need(Path(spec['path']).parent == STAGE_ROOT, 'staged archive is outside existing R25 root')
            row, raw = bind(spec['path'], spec)
            bundles[label] = members_from_archive(raw, spec)
            archive_rows[label] = dict(row, member_count=len(bundles[label]))
        plan = build_installation(bundles)
        # Only the named destinations are checked. Existing unrelated parent
        # entries, including binary_write's persistent locks, are not enumerated.
        for name in (*[d for d in NEW_DIRECTORIES if '/' not in d], *sorted(ROOT_FILES), RECEIPT):
            absent(root_fd, name)
        for row in bindings:
            need(read_path(row['path'], row, retain=False)[0] == row, 'prerequisite changed before installation')
        # No mutation occurs before all actual qualification and archive gates.
        for relative in NEW_DIRECTORIES:
            path = PurePosixPath(relative)
            owner_fd = root_fd if path.parent.as_posix() == '.' else directories[path.parent.as_posix()]
            os.mkdir(path.name, mode=0o700, dir_fd=owner_fd)
            fd = os.open(path.name, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW | os.O_CLOEXEC, dir_fd=owner_fd)
            current = os.fstat(fd)
            need(current.st_uid == os.geteuid() and stat.S_IMODE(current.st_mode) == 0o700, 'created directory ownership differs')
            directories[relative] = fd
            created_dirs.append(relative)
        installed = []
        for relative, raw, label, member in plan:
            path = PurePosixPath(relative)
            owner_fd = root_fd if path.parent.as_posix() == '.' else directories[path.parent.as_posix()]
            row = create_file(owner_fd, path.name, raw)
            created.append(relative)
            installed.append(dict(row, path=str(ROOT / relative), archive=label, member=member))
        for relative, fd in directories.items():
            os.fsync(fd)
            path = PurePosixPath(relative)
            owner_fd = root_fd if path.parent.as_posix() == '.' else directories[path.parent.as_posix()]
            need(stamp(os.fstat(fd)) == stamp(os.stat(path.name, dir_fd=owner_fd, follow_symlinks=False)),
                 'installed directory identity changed')
        for relative, raw, _, _ in plan:
            path = PurePosixPath(relative)
            read_at(root_fd if path.parent.as_posix() == '.' else directories[path.parent.as_posix()], path.name, identity(raw))
        for row in bindings:
            need(read_path(row['path'], row, retain=False)[0] == row, 'original prerequisite changed during installation')
        need(os.fstat(root_fd).st_ino == ROOT.lstat().st_ino and os.fstat(root_fd).st_dev == ROOT.lstat().st_dev,
             'original root directory was replaced')
        report = {'schema': 'hepta-r28-reviewed-tools-install/v2', 'installed': True,
                  'finished_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
                  'installer': own, 'actual_qualification_input': input_identity, 'qualification': qualification,
                  'archives': archive_rows, 'created_directories': created_dirs, 'installed_file_count': len(installed),
                  'files': installed, 'input_bindings': bindings, 'all_destinations_initially_absent': True,
                  'manual_regular_member_extraction': True, 'all_files_and_archives_rehashed': True,
                  'source_or_cache_modified': False, 'production_services_modified': False,
                  'packaged_code_executed': False, 'tests_run': 0, 'campaigns_started': 0, 'automatic_retries': 0}
        receipt = create_file(root_fd, RECEIPT, encoded(report))
        os.fsync(root_fd)
        print(json.dumps({'installed': True, 'installed_file_count': len(installed),
                          'receipt': dict(receipt, path=str(ROOT / RECEIPT)), 'tests_run': 0,
                          'campaigns_started': 0, 'source_or_cache_modified': False}), flush=True)
    except BaseException as error:
        print(json.dumps({'installed': False, 'created_files': created, 'created_directories': created_dirs,
                          'error': {'type': type(error).__name__, 'reason': str(error)},
                          'automatic_retries': 0, 'tests_run': 0, 'campaigns_started': 0}), flush=True)
        raise
    finally:
        for fd in reversed(list(directories.values())):
            os.close(fd)
        os.close(root_fd)


if __name__ == '__main__':
    main()
