# R28 fixed qualification and CI evidence capture

This local kit prepares one `qualification-ci-01.tar.xz` from the original R28
qualification and CI files. The two existing qualification attempts and the
first Python CI failure remain separate records. Export success means that the
fixed original files were captured and verified. It does not adopt the candidate
or establish an observation, lifecycle, saturation, or hosted CI result.

The exporter and consumer have not been executed. The input template contains
four completed known operations and the actual running Python recovery attempt02.
Its final native terminal and report remain unresolved.
`actual_outcomes_supplied` remains false, so that template cannot authorize an
export. Root controls all future staging and execution.

## Fixed original operations

| Original operation | Known original job | Current binding |
|---|---|---|
| Qualification admission01 | `1a1ac274e49-fc05-5286` | Failed before compilation; original preparation and native records retained |
| Qualification02 | `1a1ac5d5a29-fc05-53d9` | Strong success; eight qualification stages, 1,653 passed, 34 ignored, zero failures/retries |
| Exact Rust CI01 | `1a1ac8bfc0c-fc05-552c` | Strong success; original six tool stages and exact nextest 1,653 plain PASS / 34 ignored / zero retries |
| Python CI01 | `1a1ac97d8cb-fc05-55a2` | Failed preflight; original launch receipt retained, runner output directory absent |
| Python recovery02 | `1a1acb64a3e-fc05-5682` | Original launch acknowledged and running; final terminal and report are pending |

The original Python01 error text is retained. The actual metadata diagnosis
identified two inherited source files with mode `0660`; their contents, owner,
group and link count matched. The generic original “unsafe or oversized” error
must not be rewritten as evidence that an audit file exceeded a size limit.
The recovery uses its own six-file tool package and records its original
preflight failure proof. No future success is asserted in this kit.

## Remote coverage

The fixed root is `/home/qian/hepta-runtime-optimization-20261105-r28`.

- All regular original files under `qualification-01`, including all compressed
  per-case stdout/stderr, command and test ledgers, enumeration outputs, stage
  stdout/stderr, retained artifacts, source map, summary and independent audit.
  The recorded SHA of every audit input and every case gzip log must match.
- All 221 original compiler inputs and the exact 19 qualification harness files.
  Their bytes are checked against the actual qualified source map and report.
- Both preparation/input generations, original admission01 native records, the
  two exact qualifier source/input pairs, and the qualification02 strong
  terminal. Qualification02 retains its bound failed inventory/admission proof.
- Full `rust-ci-01`, its five installed tools, install receipt and exact plan.
  All six stage stdout/stderr and their recorded hashes are retained, including
  complete nextest inventory and output audit evidence.
- Full original `python-ci-launch-01`, its five installed tools and receipt.
  The original `python-ci-01` absence is checked at the beginning and end.
- Recovery02 uses `python-ci-tools-02`, `python-ci-tools-install-02.json`,
  `python-ci-launch-02`, and `python-ci-02`. A completed positive recovery must
  bind its actual six-file installation and original 18-command runner result.
  A negative, malformed, or absent original recovery report remains nonpositive
  and is retained with its actual declaration and raw bytes when available.
- The existing published Python CI input package at R25 `ci-gates`, including
  its 85 exact inputs, 18-command workflow manifest and original supporting Git
  documents; its earlier install and dependency receipts are included.

The compiler cache is outside this fixed scope. Qualified and retained test
ELFs retain complete observed byte count, SHA and descriptor metadata; their
bodies are omitted. ELF classification occurs before text key-marker scanning.
The existing explicit private configuration/credential omission rule is
unchanged. Original non-omitted files are streamed without re-encoding.
Parent R26 evidence is already published and is referenced by the original
preparation identities; its archive bodies are not reaudited by this capture.

All included inputs are owned regular files with one link, opened without
following symlinks. Original descriptor/path identity and content are checked
before and after reading; fixed directory inventories and observed absence are
rechecked after writing. The destination is create-only. A failure retains its
partial output and report; there is no automatic retry or workload invocation.

## Compression and independent verification

`stable_xz_archive.py` keeps the reviewed `StableReader`, read/listing/create and
path/name helpers. The new transport uses one XZ stream with a SHA-256 integrity
check and canonical regular USTAR members. It verifies the exact compressed end,
rejects concatenated streams or trailing bytes, checks every member’s order,
type, byte count and SHA, and checks the zero tar tail. No archive member is
extracted to a path or executed.

The 512 MiB expanded-archive limit is an input bound, **not a total RSS limit**.
The XZ decoder, retained blocks, joined tar body and member metadata require
additional memory. Compression ratio and runtime are unknown until the actual
export; no transfer reduction is claimed from a synthetic archive.

The archive embeds `_export-manifest.json`, so the complete member manifest can
be recovered from the verified archive. It also creates a small transfer
manifest and 48,000-byte raw / at most 64,000-byte base64 chunk files. A complete
archive received through another reviewed transport is accepted by the same
consumer using the full archive SHA. Original transport responses must remain
in the separate native custody record.

The local consumer reads only the exact reviewed local exporter/helper source,
never source from the archive. It binds the original exporter’s strong native
terminal and single full original stdout/stderr read to its exact report footer,
then checks the complete compressed archive, embedded manifest, every member,
scope mapping, source/log identities, and all original outcomes. A failed native
operation cannot be promoted by a positive inner report or by capture success.

## Staging and late binding

Two create-only source-write and file-info requests are under `requests/`:

1. `R25/tools/export_r28_qualification_ci_01.py`
2. `R25/tools/r28_qualification_ci_stable_xz_01.py`

Here `R25` means
`/home/qian/hepta-runtime-optimization-20261105-r25`. The shared tools directory
already exists. The local consumer is not a remote executable requirement.

After recovery02 has an actual terminal, root must complete
`export-input.template.json` with the exact report/native file identities for
original job `1a1acb64a3e-fc05-5682`. The source supports an explicitly unexecuted recovery only with null job/report/terminal,
a stated reason and actual output absence; that branch does not describe this
already acknowledged job. Missing terminal or report identities refuse capture. All four known operations must remain present. Root then sets
`actual_outcomes_supplied` true and stages the exact input at
`R25/tools/r28-qualification-ci-export-input-01.json`.

The terminal locations are fixed:

- `R28/qualification-terminal-status-01.json`
- `R28/qualification-terminal-status-02.json`
- `R28/rust-ci-terminal-status-01.json`
- `R28/python-ci-terminal-status-01.json`
- `R28/python-ci-terminal-status-02.json` when recovery02 was executed

`known-originals/` contains exact original terminal text for the first four,
without JSON re-encoding or an added newline. Their provenance is recorded in
`known-original-bindings-01.json`. Existing remote qualification files are
already bound by qualification02. Presence of the Rust/Python terminal copies
is not asserted here; root must reuse verified existing bytes or stage each
original once as needed.

`native-request.template.json` records the fixed executable, key, timeout and
source pins. It deliberately contains no callable `actual_request` until the
final input SHA is known. The original key is
`hepta-r28-qualification-ci-evidence-export-20261105-01`, with nice 19 and an
1,800-second native timeout. The script launches no command or subprocess.

Its fresh output is `R28/qualification-ci-evidence-01`, containing the archive,
manifest, chunks and final `report.json`. Root retains the original native
request, start response, all statuses, full stdout/stderr and all transfer pages.

## Local consumer invocation after an actual successful export

Use absolute paths and the actual report SHA. The native read must be an
original single read from offset zero through EOF, with both original byte
streams; reconstructed stream text is not a replacement DTO.

```sh
python3 -I -B verify_r28_qualification_ci_01.py \
  --archive /absolute/qualification-ci-01.tar.xz \
  --export-report /absolute/report.json \
  --report-sha256 ACTUAL_REPORT_SHA256 \
  --capture-native-terminal /absolute/capture-native-terminal.json \
  --capture-native-read /absolute/capture-native-read.json \
  --out /absolute/fresh-independent-verification.json
```

Save the original local command, exit code, stdout and stderr. A failed local
verification remains its own original result and is not automatically rerun.

## Remaining native custody and measurement boundaries

`native-custody-scope-plan-01.json` identifies the existing local original
operation directories and the remaining late-bound recovery/export entries.
The final local native custody pack must reuse the reviewed fixed XZ pack and
independent verifier with an explicit R28 inventory, after the real operations
finish. It must retain the original qualification01 and cache-inventory02
failures, Python01 failure, all original requests/statuses/read pages, and any
transport errors or exact-key reconciliations. The new full archive and its
own packaging/Git receipts must follow the same no-self-reference convention.
No such final native custody archive or complete coverage claim exists yet.

Observation, lifecycle and saturation outputs will require their own actual
finished-job bindings and fixed evidence scope. They are not inferred from
this qualification/CI capture. B96’s separate compiler exclusion probe remains
its independent operation. All frozen R26 publication directories are unchanged.
