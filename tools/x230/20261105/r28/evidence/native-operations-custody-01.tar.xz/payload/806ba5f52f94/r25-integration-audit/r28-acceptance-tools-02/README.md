# R28 acceptance tools, revision02

This package changes the qualification origin to the preserved-admission qualifier02. It does not contain an R28 success receipt. R28 remains an unadopted cache-only candidate; accepted production and the A arm remain R24.

## Exact scope

The four outer scripts use fresh `tools-02`, `lifecycle-tools-02`, and `lifecycle-launcher-bundle-02` paths. Qualification consumes `preparation-02.json` and `qualification-terminal-status-02.json`, while the first actual source/build/qualification outputs remain `source`, `target-build`, and `qualification-01`. The new launcher and input are pinned in the canonical single preparation validator. Original admission01 failed before copying/building; original read-only inventory02 also failed overall. Their unchanged negative outcomes, four original file identities, and the actual observed sufficient-space/no-cleanup evidence are required. No deletion or successful process-reference scan is inferred. The original 3 GiB reserve is still required at actual cache admission.

Logical observation, lifecycle ABBA, saturation and holder evidence outputs remain first attempt `01`. No R28 workload has been inferred or replayed. Tool revision02 is distinct from runtime attempt01. The 27 native payload files and their 28-member archive are byte-identical to R28 tools01. All original observation calls (192 measured and 24 warmup per cell), C1/C8/C16 ABBA, candidate C32/C6 checks, lifecycle ABBA, saturation matrix, fixed status predicate, 14 tests with zero skips, performance thresholds, compiler monitor code/policy and original owned cleanup are unchanged. R26 rejected history remains historical and does not authorize a repeat of its workload.

## Installation and actual receipts

The data-only installer revision02 installs 50 fixed destination files only after the actual new strong-success terminal, complete eight-stage qualification, 221 exact compiler inputs, 19 harness files, 1653 passed / 34 ignored / zero failed / zero retries, and original independent audit are supplied. Until then, all actual R28 job, source-map, report and binary identities remain null in the templates. Staged archives and scripts may be prepared, but this package is not evidence of a successful install, qualification, measurement or adoption.

Run the reviewed `prepare_campaign_inputs.py` in `tools-02` only with the actual original qualification job and exact preparation/terminal SHA values. It creates first `campaign-inputs-01.json`. The unchanged Mac holder receives `hepta-runtime-r28-observation-campaign-02.py` and writes observation evidence01. Materialize lifecycle inputs only after the actual observation and monitor gates pass; its source is `hepta-runtime-r28-lifecycle-campaign-02.py` and evidence is lifecycle01. Original holder keys and workload attempt01 remain uncalled until root dispatches them.

The frozen revision01 files and packages are retained. `source-delta-02.patch` is the entire four-script delta; `local-verification-02.json` records static equivalence checks, not a runtime test result. `derivation-inputs-02.json` records the exact old and new source identities.
