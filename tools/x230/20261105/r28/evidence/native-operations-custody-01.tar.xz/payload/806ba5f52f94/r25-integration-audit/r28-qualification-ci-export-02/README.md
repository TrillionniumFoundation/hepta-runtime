# R28 qualification and CI evidence — source revision 02, capture attempt 01

This is the reviewed revision to use for the first actual native evidence export. The previous source revision 01 and its historical ready records remain unchanged and unexecuted. Revision 02 adds one missing producer-to-payload relation: each of the original 18 Python workflow gate records must match the frozen gate ID, argv and workflow-step label, and each of its 36 stdout/stderr files must have the recorded exact basename, byte count and SHA-256. No workflow command, outcome, retry policy, workload, threshold or archive scope changes.

## Frozen actual input

`actual-export-input-01.json` is byte-identical to the actual binding completed after Python02: 3,684 bytes, SHA-256 `3943c661df6b1d569889293988098aec1f946dbe1e7576740cd931d66440f0a7`. It retains five originals: failed qualification01, successful qualification02, successful Rust CI01, failed Python preflight01, and successful Python recovery02. It does not infer performance acceptance or adoption.

The native logical attempt and key remain `hepta-r28-qualification-ci-evidence-export-20261105-01`; no previous export invocation occurred. The actual output will be `/home/qian/hepta-runtime-optimization-20261105-r28/qualification-ci-evidence-01`. Only the exporter source and input remote filenames move to revision02. The SHA-bound XZ helper bytes and its original remote filename stay unchanged.

## Root-only staging and execution

`requests/` contains exact create-only source/helper/input writes, file-info readbacks and the original native export request. The three exact original CI terminal write/info pairs remain in the separate frozen `r28-qualification-ci-export-actual-01/requests/` directory. Qualification01/02 original terminal files are already bound by qualification receipts. No remote terminal presence is assumed for the three CI files; the root coordinator must reconcile any exact existing file instead of overwriting or blindly repeating an operation. An existing exact helper may be reused after identity verification.

The root coordinator executes once only outside timed measurement. This package has not been staged or executed by the author. Root must retain the original request/start/terminal/read envelopes. Export success is a transport and evidence-capture result, not product acceptance.

## Complete local verification after actual transfer

The archive is one SHA256-checked XZ stream with an embedded `_export-manifest.json`, every canonical regular member and byte hash independently verified. The prior 512 MiB expanded-byte/decoder limit is not a total process-RSS guarantee. No archive code is imported or executed and no archive member is extracted as a program.

Use absolute paths and the exact original single full native capture terminal/read bodies:

```text
/usr/bin/python3 -I -B /workspace/scratch/806ba5f52f94/r25-integration-audit/r28-qualification-ci-export-02/verify_r28_qualification_ci_02.py
  --archive <absolute actual qualification-ci-01.tar.xz>
  --export-report <absolute original report.json>
  --report-sha256 <actual original report SHA-256>
  --capture-native-terminal <absolute original content.text DTO>
  --capture-native-read <absolute original full content.text DTO>
  --out <absolute fresh independent verification receipt>
```

The local verifier executes only the exact reviewed local exporter/helper definitions, never archive content. Final native request/start/read custody and the independent performance/Mac packages remain separate required evidence. The known rejected observation is outside this qualification/CI package. This file does not claim that the native export, download, full archive verification or final publication has happened.
