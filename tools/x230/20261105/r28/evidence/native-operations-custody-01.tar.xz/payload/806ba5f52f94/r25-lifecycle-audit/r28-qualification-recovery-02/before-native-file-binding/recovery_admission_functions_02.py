"""Narrow original-failure and actual-space-proof admission; no cleanup operations."""

def byte_identity(body):
    return {'bytes': len(body), 'sha256': hashlib.sha256(body).hexdigest()}


def original_operation(label, supplied, expected, state='succeeded', exit_code=0):
    terminal_raw = supplied['native_terminal_text'].encode('utf-8')
    read_raw = supplied['native_read_text'].encode('utf-8')
    assert byte_identity(terminal_raw) == expected['terminal']
    assert byte_identity(read_raw) == expected['read']
    check_terminal(terminal_raw, expected['job_id'], state=state, exit_code=exit_code)
    terminal, dto = json.loads(terminal_raw), json.loads(read_raw)
    assert dto['job_id'] == expected['job_id'] and dto['audit_recorded'] is True
    streams = {}
    for name in ('stdout', 'stderr'):
        row = dto[name]
        raw = bytes.fromhex(row['bytes_hex'])
        assert row['offset'] == 0 and row['next_offset'] == row['size'] == len(raw)
        assert row['eof'] is True and row['text'].encode('utf-8') == raw
        assert terminal['log_bytes'][name] == {'seen': len(raw), 'stored': len(raw)}
        streams[name] = raw
    assert streams['stderr'] == b''
    assert byte_identity(streams['stdout']) == expected['stdout']
    report = json.loads(streams['stdout'])
    return report, {'label': label, 'job_id': expected['job_id'], 'state': state,
                    'exit_code': exit_code, 'terminal': byte_identity(terminal_raw),
                    'native_read': byte_identity(read_raw), 'stdout': byte_identity(streams['stdout']),
                    'stderr': byte_identity(streams['stderr']), 'original_complete_streams_proved': True}


def verify_recovery_admission(payload):
    # This template cannot run until root has reviewed the actual readonly
    # inventory and the actual owned-cache retirement and frozen their pins.
    assert isinstance(SPACE_RECOVERY_SPEC, dict), 'actual space recovery is not bound; no qualification admission'
    assert set(SPACE_RECOVERY_SPEC) == {'readonly_inventory', 'cache_retirement'}
    recovery = payload.pop('preserved_admission_recovery')
    assert recovery['schema'] == 'hepta-r28-preserved-admission-recovery/v1'
    assert set(recovery['space_recovery']) == set(SPACE_RECOVERY_SPEC)
    assert ROOT.resolve(strict=True) == ROOT
    root_info = ROOT.lstat()
    assert stat.S_ISDIR(root_info.st_mode) and root_info.st_uid == os.geteuid()
    assert stat.S_IMODE(root_info.st_mode) == 0o700
    failed_identity, failed_raw = read(ROOT / 'preparation-01.json',
        'abc26b3d49c2e57b608fe3aba792708e80de95340c1c8c210dced2844953fade', retain=True)
    assert failed_identity['bytes'] == 4671
    original_input_identity, original_input_raw = read(ROOT / 'qualification-input-01.json',
        '0837e858fddf7df95229a5dac1dafdf6d904800caad46cb238ba18ecfaa93299', retain=True)
    assert original_input_identity['bytes'] == 34557 and encoded(payload) == original_input_raw
    failed = json.loads(failed_raw)
    assert failed['schema'] == 'hepta-r28-qualified-parent-preparation/v1'
    assert failed['passed'] is False and failed['candidate_qualified'] is False and failed['candidate_adopted'] is False
    assert failed['parent_source_qualified'] is True and failed['parent_lifecycle_rejection_preserved'] is True
    assert failed['selected_proposal'] == 'cache only' and failed['optional_pidfd_selected'] is False
    assert failed['error'] == 'AssertionError: (6285365248, 3080991421)'
    assert 'line 217, in main' in failed['error_trace'] and failed['finished_utc']
    assert not any(name in failed for name in ('qualification_argv', 'qualification_returncode',
        'source', 'target', 'qualification_output', 'source_before', 'candidate_compilation_inputs', 'source_changes', 'tests'))
    original_footer, original_proof = original_operation('original_failed_admission',
        recovery['original_failed_operation'], {
            'job_id': '1a1ac274e49-fc05-5286',
            'terminal': {'bytes': 726, 'sha256': '8dee0438ff40dc85288ff6d9ff6da9dfcdfc36092bbc12995bd99018f3d00d31'},
            'read': {'bytes': 723, 'sha256': '5a0beef68de943554f08936dacec1a66c4b8e2af66f6c7ea9aa9387cc852e35a'},
            'stdout': {'bytes': 131, 'sha256': '3613580074731c44ad27d2687ec2e8c177fd81eef7d9b2148d0b8ef10df886fc'}},
        state='failed', exit_code=1)
    assert original_footer == {'preparation_and_qualification_passed': False,
        'candidate_qualified': False, 'error': failed['error']}
    space_proofs = {}
    for label in ('readonly_inventory', 'cache_retirement'):
        actual, proof = original_operation(label, recovery['space_recovery'][label], SPACE_RECOVERY_SPEC[label])
        assert actual['schema'] == SPACE_RECOVERY_SPEC[label]['report_schema']
        assert SPACE_RECOVERY_SPEC[label]['root_reviewed_for_this_admission'] is True
        # Original reports and native DTOs remain complete in the input. Root
        # must first review their ownership/absence/retirement semantics; their
        # exact hashes become part of this new launcher's reviewed source.
        space_proofs[label] = proof
    absent = [SOURCE, TARGET, OUTPUT, ROOT / 'preparation-02.json', ROOT / 'qualification-input-02.json']
    assert all(not os.path.lexists(path) for path in absent), 'first actual source/cache/qualification paths and new receipts must be absent'
    return {'original_admission_failure_preserved': True,
            'original_failed_admission': original_proof,
            'original_preparation': failed_identity, 'original_candidate_input': original_input_identity,
            'space_recovery_proofs': space_proofs,
            'admission_absent_paths': [str(path) for path in absent],
            'unchanged_disk_reserve_bytes': 3 * 1024**3,
            'cache_retirement_executed_by_this_qualifier': False}
