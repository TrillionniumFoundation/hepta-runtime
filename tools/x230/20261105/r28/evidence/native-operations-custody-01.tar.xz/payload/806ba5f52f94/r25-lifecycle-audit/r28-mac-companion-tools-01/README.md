# R28 original Mac holder evidence

This package prepares one data-only capture of the original R28 observation holder and the explicitly unexecuted R28 lifecycle holder. It derives the collector and independent consumer from the successful R26 Mac capture. It has not staged files, run either program, captured evidence, or contacted a host.

The original observation job is `1a1acbbcbec-fc05-56a0`. Its native state is `succeeded`, its original stdout/stderr are complete at 299/0 bytes, and its holder report records a reaped owned agent and completed remote return code 0. The forwarded result contains `observation_gate_passed=false`. Capture success must preserve that rejection and cannot establish candidate adoption. Root did not schedule lifecycle or saturation for this candidate.

## Fixed scope

| Purpose | Fixed Mac path |
| --- | --- |
| Collector and consumer | `/Users/qianqi/work/hepta-runtime-r28-mac-companion-tools-01` |
| Original declarations and native wrappers | `/Users/qianqi/work/hepta-runtime-r28-mac-companion-inputs-01` |
| Fresh capture output | `/Users/qianqi/work/hepta-runtime-r28-mac-companion-evidence-01` |
| Executed observation | `/Users/qianqi/work/hepta-runtime-r28-observation-evidence-01` |
| Unexecuted lifecycle | `/Users/qianqi/work/hepta-runtime-r28-lifecycle-evidence-01` |

The sole archive group is `formal`; its archive is `formal/formal-holders-01.tar.gz`. The code keeps the original deterministic gzip producer and independent single-member CRC/ISIZE/exact-EOF verification. It adds no compression helper and executes no archive content.

For the executed observation, all 22 allowed holder files are mandatory: the original report, forwarded stdout/stderr, seven identity-discovery stderr files, ten identity-load stdout/stderr files, owned-agent stderr, and the exact retained `remote-script.py`. The original R21 holder source, staged R28 parent source, collector/consumer source, declaration, original native terminal/read wrappers, and strictly decoded original native stdout/stderr are also retained. Identity/key/configuration bodies outside this allowlist are never read. Existing secret-marker, descriptor, owner, mode, link, file-size and directory checks are unchanged.

The lifecycle declaration has `executed=false`, `job_id=null`, and no fabricated report, native result, or stream. Capture must observe its evidence directory absent and repeat that absence check before and after archiving. This preparation has not performed that live-host check. A previously staged lifecycle parent source may be retained as a **prepared source**; it is not described as an executed or transported lifecycle holder. No lifecycle native input files are staged.

## Source and original-input bindings

The collector is 36,384 bytes with SHA-256 `457c62b162ccbd7463254e4c3ed42a969be8cca2b307481e40d77b375340bf46`. The consumer is 45,707 bytes with SHA-256 `ad082087cae141302fd770c77bafe4d0fe64e62b582daccb32e7fd7d9404e5d6`.

The 901-byte declaration binds the exact original saved request/result envelope bytes. `observation01-terminal.json` is the unchanged 1,064-byte `holder-status-02.json`, SHA-256 `caf70250b3408215baf89f0b588e56618bbdcbcd18517fd56e5e26a7e1799353`. `observation01-read.json` is the unchanged 1,646-byte `holder-read-00-01.json`, SHA-256 `abd425abe2e3b1765d221e70ba57cd92a379bcb892931819c86805baa9b4b3bb`. Neither DTO nor wrapper was re-encoded. The original report remains pinned to 9,075 bytes and SHA-256 `288a748ae91e84b409b2bbd903c51bc83d5faca17963f0ddbc638d56a17ea8c9`.

`native-wrapper-mapping-01.json` identifies the exact inner original `result.content` text separately from its outer envelope. The terminal text is 729 bytes with SHA-256 `3df7bbc9acc621a6c1eeaf85e4fe21870cb62ba5df0f423e2b67a6e8f236860e`. If X230 retains this raw DTO, cross-package verification must compare those original text bytes with the X230 file; it must not compare an outer-envelope hash to an inner-DTO hash. Extracting the original text adds no newline and does not serialize the parsed object.

`derivation-proof-01.json` records the old successful source and QA identities, every original function's normalized AST, and the precise allowed changes. After changing only the schema namespace back to R26, every collector and consumer function remains AST-identical to its reviewed predecessor. The other changes are top-level plans, group selection, fixed paths, actual observation pins, and descriptive module text. The R21 holder, 3,600-second holder limit, 3,720-second identity TTL, privacy rules, native terminal/stream checks, cleanup checks, archive algorithms, transfer limits and independent verification remain unchanged.

## Deferred execution

`staging-plan-01.json` lists exactly five files, with local and remote paths and byte hashes. The two fresh directories must be private and all five files must be created without overwriting existing paths. The capture output must remain absent until the one original capture. An existing matching job is reconciled by its exact original key and request; a lost reply is not permission to start a different capture.

`capture-request-01.json` is the exact prepared native request. It is not a launch receipt. Root alone may stage and dispatch it after the current measurement reservation has ended and the declared unexecuted scope has been confirmed. The collector still independently checks absence and original closure during capture. No capture job ID, archive identity, transfer version or verification result has been invented here.

After actual capture terminal completion, retain its full original native terminal/read wrappers. Download `receipt.json`, `formal/manifest.json`, `formal/chunks-manifest.json`, and every listed chunk through the existing bounded text-read protocol: 48,000 binary bytes per base64 chunk, at most four text files per request, 65,536-byte file limit and 262,144-byte response limit. Preserve each original request/result envelope as `operations/read-NNNN.json`, including any separate timeout history. The independent consumer binds every downloaded text file to its original version, bytes and SHA, verifies the full compressed stream and exact regular-only tar inventory, and re-derives the original holder outcome from the original bytes.

`consumer-arguments.template.json` intentionally leaves the capture job ID and original receipt hash/version unset. Supply them only from the actual capture. The local verification output must be fresh. This Mac archive does not read X230 report bytes; final cross-package verification must separately bind its retained parent source and forwarded footer to the independently verified X230 observation evidence. Lifecycle remains unexecuted in both packages.

The complete capture native request/status/read chain and later transfer envelopes remain part of the separate original native custody record. This package does not claim hosted CI, performance acceptance, candidate adoption, current live-host absence, or successful evidence capture.
