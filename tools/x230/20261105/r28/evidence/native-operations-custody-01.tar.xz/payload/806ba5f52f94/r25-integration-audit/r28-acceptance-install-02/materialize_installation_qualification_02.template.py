#!/usr/bin/env python3
"""Create a local installation input from actual original R28 qualification only."""
import argparse
import base64
import hashlib
import types
import json
import os
from pathlib import Path
import stat
import sys

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
INSTALLER = HERE / 'install_r28_reviewed_tools_02.py'
INSTALLER_SHA = None  # FROZEN_INSTALLER_SHA
REMOTE = '/home/qian/hepta-runtime-optimization-20261105-r28'
DESTINATION = '/home/qian/hepta-runtime-optimization-20261105-r25/tools/r28-installation-qualification-02.json'
NAMES = {
    'preparation': ('preparation-02.json', '/preparation-02.json'),
    'native_terminal': ('qualification-native-terminal-02.json', '/qualification-terminal-status-02.json'),
    'qualification_report': ('qualification-report-01.json', '/qualification-01/report.json'),
    'source_map': ('qualified-source-map-01.json', '/qualification-01/source-map.json'),
    'isolated_summary': ('isolated-tests-summary-01.json', '/qualification-01/isolated-tests/summary.json'),
    'isolated_audit': ('isolated-tests-audit-01.json', '/qualification-01/isolated-tests.audit.json'),
}


def need(value, reason):
    if not value:
        raise ValueError(reason)


def identity(body):
    return {'bytes': len(body), 'sha256': hashlib.sha256(body).hexdigest()}


def encode(value):
    return (json.dumps(value, sort_keys=True, indent=2, allow_nan=False) + '\n').encode()


def read(path):
    path = path.absolute()
    need(path.resolve(strict=True) == path, 'indirect local receipt')
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK | os.O_CLOEXEC)
    try:
        before = os.fstat(fd)
        need(stat.S_ISREG(before.st_mode) and before.st_nlink == 1 and before.st_size <= 16 * 1024 * 1024,
             'nonregular or oversized local receipt')
        with os.fdopen(os.dup(fd), 'rb') as stream:
            body = stream.read(16 * 1024 * 1024 + 1)
        fields = ('st_dev', 'st_ino', 'st_uid', 'st_mode', 'st_nlink', 'st_size', 'st_mtime_ns', 'st_ctime_ns')
        stamp = lambda value: tuple(getattr(value, key) for key in fields)
        need(len(body) == before.st_size and stamp(before) == stamp(os.fstat(fd)) == stamp(path.lstat()),
             'local receipt changed while reading')
    finally:
        os.close(fd)
    return {'local_path': str(path), **identity(body)}, body


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--receipts', type=Path, required=True)
    parser.add_argument('--original-job-id', required=True)
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    need(not os.path.lexists(args.out), 'fresh local materialization output required')
    installer_identity, source = read(INSTALLER)
    need(installer_identity['sha256'] == INSTALLER_SHA, 'reviewed installer changed')
    module = types.ModuleType('reviewed_r28_installation_validator')
    module.__file__ = str(INSTALLER)
    exec(compile(source, str(INSTALLER), 'exec'), module.__dict__)
    values, inputs = {}, {}
    result = {'schema': 'hepta-r28-installation-qualification/v1', 'executed': False,
              'original_qualification_job_id': args.original_job_id}
    for key, (local, remote) in NAMES.items():
        row, body = read(args.receipts / local)
        inputs[key] = row
        values[key] = json.loads(body)
        result[key] = {'path': REMOTE + remote, **identity(body)}
    proof = module.verify_qualification_documents(result, values['preparation'], values['native_terminal'],
        values['qualification_report'], values['isolated_summary'], values['isolated_audit'], values['source_map'])
    for row in inputs.values():
        need(read(Path(row['local_path']))[0] == row, 'actual original receipt changed before materialization')
    need(read(INSTALLER)[0] == installer_identity, 'installer changed during materialization')
    raw = encode(result)
    request = {'host': 'x230', 'path': DESTINATION, 'data_base64': base64.b64encode(raw).decode(),
               'expected_version': 'absent'}
    receipt = {'schema': 'hepta-r28-local-installation-input-materialization/v1', 'passed': True,
               'original_qualification_job_id': args.original_job_id, 'qualification_proof': proof,
               'original_local_receipts': inputs, 'installer': installer_identity,
               'installation_input': {'remote_path': DESTINATION, **identity(raw)},
               'remote_actions': 0, 'tools_installed': False, 'workloads_started': 0}
    args.out.mkdir(mode=0o700)
    for name, body in (('qualification-input-02.json', raw),
                       ('qualification-input-write.request.json', encode(request)),
                       ('local-materialization-receipt-02.json', encode(receipt))):
        with (args.out / name).open('xb') as stream:
            stream.write(body)
            stream.flush()
            os.fsync(stream.fileno())
    print(json.dumps(receipt), flush=True)


if __name__ == '__main__':
    main()
