"""Data-only fresh installation of the R28 Python launcher, three unchanged binding files and original failure evidence."""
import base64
import gzip
import hashlib
import io
import json
import os
from pathlib import Path
import stat
import sys
import tarfile

SPEC = {'actual_pins': {'AUDIT_SHA256': '1212a8fa0b0e3631627fbadc3e5f93e895babfb7b35bf7e0fa740cc01d16e6d6',
                 'JOB_ID': '1a1ac5d5a29-fc05-53d9',
                 'MAP_SHA256': 'da8cbdfef75c1c9fc5861e4fe0bd96aeb98f635e95fc122610021cd725db1d28',
                 'PREPARATION_SHA256': '4ece02608c423456d0996de39c54129c6c759a1973a0e11f22b04f936b113cc3',
                 'REPORT_SHA256': '9e564f3950575313034f55974303e56c236ac030e2c5f121d49791da0c4c09fa',
                 'SUMMARY_SHA256': 'a6645dbb6a0208fdbca1a3dd6308c55f7d6b876ef4ddf70f02a2b4c58c9db46d',
                 'TERMINAL_SHA256': '3325b116b998ddff0e586a3b983a2715339acb1b48e9215f5b92e9abfdde4946'},
 'archive': {'bytes': 42863,
             'sha256': '832abaa48dcbd053b681b946a2d689489f41a8d3dc70f2cb795039021519cf55'},
 'base64_bytes': 57152,
 'files': {'actual-python-input-01.json': {'bytes': 2882,
                                           'sha256': 'b60562acab3655df24199a055bc426b998681cd5ba2294967d516e5e59878f73'},
           'candidate-parent-proof-01.json': {'bytes': 31032,
                                              'sha256': '4635a698aa7d61ba8dff66e8e152b7f7398d1b0df9285c147318f2eedb4b5326'},
           'launch_python_ci_02.py': {'bytes': 38679,
                                      'sha256': '7c61fbcb65d71a6c0d9694a837a29c42ac1fc8cb18b46eda53cf4733ed611494'},
           'original-preflight-recovery-02.json': {'bytes': 55425,
                                                   'sha256': 'f20021b3cddab4d7ce989964872e1e16c53dc9e9c4b01f052050cd3cbf3a07a0'},
           'package-manifest-02.json': {'bytes': 1045,
                                        'sha256': '030933b50aebacabb9463bb8cba582119b8334f29a01138da9519e4c2754a633'},
           'qualification_binding_01.py': {'bytes': 24802,
                                           'sha256': 'be079079f261668b194d32ba09a1d72ba4051b70d1d71ce7981b06f3be6eaab1'}}}
ROOT = Path('/home/qian/hepta-runtime-optimization-20261105-r28')
DEST = ROOT / 'python-ci-tools-02'
RECEIPT = ROOT / 'python-ci-tools-install-02.json'
NAMES = {'launch_python_ci_02.py', 'qualification_binding_01.py', 'candidate-parent-proof-01.json',
         'actual-python-input-01.json', 'original-preflight-recovery-02.json', 'package-manifest-02.json'}


def need(value, reason):
    if not value:
        raise ValueError(reason)


def identity(body):
    return {'bytes': len(body), 'sha256': hashlib.sha256(body).hexdigest()}


need(type(SPEC) is dict, 'actual reviewed installation package is not bound')
need(sys.platform == 'linux' and os.geteuid() != 0, 'native Linux operator required')
encoded = sys.stdin.buffer.read(SPEC['base64_bytes'] + 1)
need(len(encoded) == SPEC['base64_bytes'], 'fixed archive stdin length differs')
packed = base64.b64decode(encoded, validate=True)
need(identity(packed) == SPEC['archive'], 'fixed archive bytes/hash differ')
expanded = gzip.decompress(packed)
need(len(expanded) <= 512 * 1024, 'fixed tool archive exceeds expanded bound')
files = {}
with tarfile.open(fileobj=io.BytesIO(expanded), mode='r:') as archive:
    members = archive.getmembers()
    need(len(members) == 6 and {m.name for m in members} == NAMES, 'exact six-file archive required')
    for member in members:
        need(member.type == tarfile.REGTYPE and not member.linkname and not member.pax_headers
             and not member.issparse() and member.mode == 0o600 and member.name not in files
             and Path(member.name).name == member.name and 0 < member.size <= 65536,
             'unsafe, repeated or unexpected archive member')
        body = archive.extractfile(member).read()
        need(len(body) == member.size and identity(body) == SPEC['files'][member.name],
             'fixed member identity differs: ' + member.name)
        files[member.name] = body
    tail = expanded[archive.offset:]
    need(len(tail) >= 1024 and not any(tail), 'tar ending differs')
manifest = json.loads(files['package-manifest-02.json'])
need(set(SPEC['files']) == NAMES and manifest['schema'] == 'hepta-r28-exact-python-ci-tools/v1'
     and manifest['files'] == {name: SPEC['files'][name] for name in NAMES if name not in {
         'package-manifest-02.json'}}
     and manifest['actual_qualification_job_id'] == SPEC['actual_pins']['JOB_ID']
     and manifest['executed'] is False and manifest['hosted_actions_passed'] is False,
     'frozen package manifest composition differs')
need(ROOT.resolve(strict=True) == ROOT, 'R28 root path is indirect')
root_info = ROOT.lstat()
need(stat.S_ISDIR(root_info.st_mode) and root_info.st_uid == os.geteuid(), 'R28 root is not an owned directory')
need(not os.path.lexists(DEST) and not os.path.lexists(RECEIPT), 'fresh tool directory and receipt required')
os.umask(0o077)
root_fd = os.open(ROOT, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW | os.O_CLOEXEC)
try:
    need((os.fstat(root_fd).st_dev, os.fstat(root_fd).st_ino) == (root_info.st_dev, root_info.st_ino),
         'root directory changed before install')
    os.mkdir(DEST.name, mode=0o700, dir_fd=root_fd)
    dest_fd = os.open(DEST.name, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW | os.O_CLOEXEC, dir_fd=root_fd)
    try:
        directory = os.fstat(dest_fd)
        for name, body in sorted(files.items()):
            fd = os.open(name, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW | os.O_CLOEXEC, 0o600, dir_fd=dest_fd)
            with os.fdopen(fd, 'wb') as stream:
                stream.write(body)
                stream.flush()
                os.fsync(stream.fileno())
            fd = os.open(name, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK | os.O_CLOEXEC, dir_fd=dest_fd)
            with os.fdopen(fd, 'rb') as stream:
                before = os.fstat(stream.fileno())
                actual = stream.read(65537)
                after = os.fstat(stream.fileno())
            fields = ('st_dev', 'st_ino', 'st_mode', 'st_uid', 'st_nlink', 'st_size', 'st_mtime_ns', 'st_ctime_ns')
            current = os.stat(name, dir_fd=dest_fd, follow_symlinks=False)
            need(stat.S_ISREG(before.st_mode) and before.st_uid == os.geteuid() and before.st_nlink == 1
                 and stat.S_IMODE(before.st_mode) == 0o600 and actual == body
                 and all(getattr(before, k) == getattr(after, k) == getattr(current, k) for k in fields),
                 'installed file readback/identity differs: ' + name)
        os.fsync(dest_fd)
        need(DEST.resolve(strict=True) == DEST and (DEST.lstat().st_dev, DEST.lstat().st_ino)
             == (directory.st_dev, directory.st_ino) and {p.name for p in DEST.iterdir()} == NAMES,
             'installed directory identity or inventory differs')
    finally:
        os.close(dest_fd)
    receipt = {'schema': 'hepta-r28-exact-python-ci-tools-install/v1', 'passed': True,
               'destination': str(DEST), 'archive': SPEC['archive'], 'files': SPEC['files'],
               'actual_qualification_pins': SPEC['actual_pins'], 'original_file_count': 6,
               'packaged_tools_executed': False, 'cargo_executed': False,
               'source_or_compiler_cache_modified': False}
    receipt_raw = (json.dumps(receipt, sort_keys=True, indent=2) + '\n').encode()
    fd = os.open(RECEIPT.name, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW | os.O_CLOEXEC,
                 0o600, dir_fd=root_fd)
    with os.fdopen(fd, 'wb') as stream:
        stream.write(receipt_raw)
        stream.flush()
        os.fsync(stream.fileno())
    os.fsync(root_fd)
finally:
    os.close(root_fd)
print(json.dumps({'passed': True, 'receipt': {'path': str(RECEIPT), **identity(receipt_raw)},
                  'installed_regular_files': 6, 'packaged_tools_executed': False}, sort_keys=True), flush=True)
