#!/usr/bin/env python3
"""Restore exactly six original R28 qualification JSON files from verified chunks.

Local data reads/writes only. The actual six-receipt CI freezer remains required.
Never extractall, execute archive contents, or replay tests/audits/workloads.
"""
import argparse
import base64
import hashlib
import json
import os
from pathlib import Path
import re
import stat
import tarfile
import types

WORK = Path(__file__).resolve().parents[2]
REMOTE_ROOT = '/home/qian/hepta-runtime-optimization-20261105-r28'
REMOTE = REMOTE_ROOT + '/qualification-receipts-export-01'
ARCHIVE = 'qualification-receipts-01.tar.gz'
OUT = WORK / 'benchmark-r28/actual-qualification-receipts-02'
HELPER = WORK / 'r25-capacity-audit/diagnostic-export-07/stable_archive.py'
HELPER_SHA = '34ce88cc28da10e1167dabaf6e3480aa42f5e6e76a29472d93959334aa9ec2ed'
EXPORTER_PATH = '/home/qian/hepta-runtime-optimization-20261105-r25/tools/r28_export_qualification_receipts_01.py'
EXPORTER_SHA = '0baa7d4088ab5c43f0669621bdf5957bf2a10ab3f0422bfae8083fd286351b80'
INPUT_PATH = '/home/qian/hepta-runtime-optimization-20261105-r25/tools/r28_qualification_receipts_input_01.json'
FILES = {
    'preparation-02.json': REMOTE_ROOT + '/preparation-02.json',
    'qualification-native-terminal-02.json': REMOTE_ROOT + '/qualification-terminal-status-02.json',
    'qualification-report-01.json': REMOTE_ROOT + '/qualification-01/report.json',
    'qualified-source-map-01.json': REMOTE_ROOT + '/qualification-01/source-map.json',
    'isolated-tests-summary-01.json': REMOTE_ROOT + '/qualification-01/isolated-tests/summary.json',
    'isolated-tests-audit-01.json': REMOTE_ROOT + '/qualification-01/isolated-tests.audit.json',
}
FIELDS = ('st_dev', 'st_ino', 'st_uid', 'st_mode', 'st_nlink', 'st_size', 'st_mtime_ns', 'st_ctime_ns')
HEX = re.compile(r'[0-9a-f]{64}\Z')
JOB = re.compile(r'[0-9a-f]+-[0-9a-f]+-[0-9a-f]+\Z')
MAX_TOTAL = 32 * 1024**2
MAX_ARCHIVE = 34 * 1024**2

def need(value, reason):
    if not value:
        raise RuntimeError(reason)


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def stamp(value):
    return {key: getattr(value, key) for key in FIELDS}


def pairs(items):
    result = {}
    for key, value in items:
        need(key not in result, 'duplicate JSON key')
        result[key] = value
    return result


def load(raw):
    return json.loads(raw, object_pairs_hook=pairs)


def stable_read(path, maximum=1024 * 1024):
    path = Path(path).absolute()
    need(path.resolve(strict=True) == path, 'direct local input required')
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK | os.O_CLOEXEC)
    try:
        before = os.fstat(fd)
        need(stat.S_ISREG(before.st_mode) and before.st_uid == os.geteuid()
             and before.st_nlink == 1 and 0 <= before.st_size <= maximum,
             'unsafe or oversized local input')
        with os.fdopen(os.dup(fd), 'rb') as stream:
            raw = stream.read(maximum + 1)
        need(len(raw) == before.st_size
             and stamp(before) == stamp(os.fstat(fd)) == stamp(path.lstat()),
             'local original changed while reading')
    finally:
        os.close(fd)
    return {'local_path': str(path), 'bytes': len(raw), 'sha256': digest(raw),
            'descriptor_identity': stamp(before)}, raw


def recheck(inputs):
    for expected in inputs:
        identity, _ = stable_read(expected['local_path'])
        need(identity == expected, 'local original changed after validation')


def write_new(path, raw):
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW
                 | os.O_CLOEXEC, 0o600)
    try:
        with os.fdopen(os.dup(fd), 'wb') as stream:
            stream.write(raw)
            stream.flush()
            os.fsync(stream.fileno())
        before = stamp(os.fstat(fd))
        need(before == stamp(path.lstat()) and before['st_size'] == len(raw)
             and stat.S_IMODE(before['st_mode']) == 0o600, 'new output identity differs')
    finally:
        os.close(fd)
    identity, body = stable_read(path, max(len(raw), 1))
    need(identity['descriptor_identity'] == before and body == raw, 'new output readback differs')
    return identity


def bound_json(pin, inputs):
    need(type(pin) is dict and set(pin) == {'local_path', 'bytes', 'sha256'}
         and type(pin['local_path']) is str and Path(pin['local_path']).is_absolute()
         and type(pin['bytes']) is int and 0 < pin['bytes'] <= 1024**2
         and type(pin['sha256']) is str and HEX.fullmatch(pin['sha256']),
         'actual local metadata pin is unbound or oversized')
    identity, raw = stable_read(pin['local_path'])
    need((identity['bytes'], identity['sha256']) == (pin['bytes'], pin['sha256']),
         'actual bound metadata bytes differ')
    inputs.append(identity)
    value = load(raw)
    need(type(value) is dict, 'original metadata object required')
    return value, identity


def require_terminal(value, job_id):
    need(value.get('job_id') == job_id and value.get('state') == 'succeeded'
         and type(value.get('exit_code')) is int and value['exit_code'] == 0
         and all(value.get(key) is False for key in ('automatic_retry', 'cancelled', 'timed_out'))
         and all(value.get(key) is True for key in
                 ('output_complete', 'output_durable', 'terminal_publication_confirmed'))
         and type(value.get('terminal_publication_protocol')) is int and value['terminal_publication_protocol'] == 1
         and value.get('log_synced') == {'stdout': True, 'stderr': True}
         and value.get('log_errors') == {'stdout': None, 'stderr': None}
         and value.get('log_truncated') == {'stdout': False, 'stderr': False},
         'original complete successful native terminal required')
    for stream in ('stdout', 'stderr'):
        counts = value['log_bytes'][stream]
        need(set(counts) == {'seen', 'stored'} and all(type(n) is int and n >= 0 for n in counts.values())
             and counts['seen'] == counts['stored'], 'native log custody is incomplete')


def require_files(value):
    need(type(value) is dict and set(value) == set(FILES), 'exact six file pins required')
    total = 0
    for name, path in FILES.items():
        row = value[name]
        need(type(row) is dict and set(row) == {'source_path', 'bytes', 'sha256'}
             and row['source_path'] == path and type(row['bytes']) is int
             and 0 < row['bytes'] <= 16 * 1024**2
             and type(row['sha256']) is str and HEX.fullmatch(row['sha256']),
             'actual six-file identity is unbound or outside fixed scope: ' + name)
        total += row['bytes']
    need(total <= MAX_TOTAL, 'six original JSON bodies exceed fixed bound')


def load_helper(inputs):
    identity, raw = stable_read(HELPER, 16384)
    need(identity['bytes'] == 12842 and identity['sha256'] == HELPER_SHA,
         'reviewed local stable archive helper changed')
    inputs.append(identity)
    module = types.ModuleType('_reviewed_fixed_six_archive_reader')
    module.__file__ = str(HELPER)
    exec(compile(raw, str(HELPER), 'exec'), module.__dict__)
    return module, identity


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--binding', required=True, type=Path)
    parser.add_argument('--binding-sha256', required=True)
    parser.add_argument('--read-dir', required=True, type=Path)
    parser.add_argument('--evidence-out', required=True, type=Path)
    args = parser.parse_args()
    need(HEX.fullmatch(args.binding_sha256), 'actual binding SHA must be frozen before execution')
    binding_id, binding_raw = stable_read(args.binding)
    need(binding_id['sha256'] == args.binding_sha256, 'actual binding SHA differs')
    binding = load(binding_raw)
    need(type(binding) is dict and set(binding) == {'schema', 'original_qualification_job_id',
         'original_export_job_id', 'expected_files', 'export_input', 'export_report',
         'export_terminal', 'transfer_manifest'}
         and binding['schema'] == 'hepta-r28-fixed-six-receipt-local-binding/v1', 'binding shape differs')
    for key in ('original_qualification_job_id', 'original_export_job_id'):
        need(type(binding[key]) is str and JOB.fullmatch(binding[key]), 'actual original job ID is unbound')
    need(binding['original_export_job_id'] != binding['original_qualification_job_id'], 'distinct original jobs required')
    require_files(binding['expected_files'])
    read_dir, evidence = args.read_dir.absolute(), args.evidence_out.absolute()
    need(read_dir.resolve(strict=True) == read_dir and read_dir.is_dir(), 'direct original read directory required')
    need(evidence.parent.resolve(strict=True) == evidence.parent and not os.path.lexists(evidence)
         and OUT.parent.resolve(strict=True) == OUT.parent and not os.path.lexists(OUT)
         and evidence != OUT and not evidence.is_relative_to(OUT) and not OUT.is_relative_to(evidence),
         'two distinct fresh direct output directories required')
    own_identity, _ = stable_read(Path(__file__).absolute())
    inputs = [binding_id, own_identity]
    export_input, input_id = bound_json(binding['export_input'], inputs)
    report, report_id = bound_json(binding['export_report'], inputs)
    terminal, terminal_id = bound_json(binding['export_terminal'], inputs)
    transfer, transfer_id = bound_json(binding['transfer_manifest'], inputs)
    require_terminal(terminal, binding['original_export_job_id'])
    need(export_input == {'schema': 'hepta-r28-fixed-qualification-receipts-input/v1',
         'original_qualification_job_id': binding['original_qualification_job_id'],
         'files': binding['expected_files']}, 'original late-bound export input differs')
    need(report['schema'] == 'hepta-r28-fixed-six-qualification-receipts-export/v1'
         and report.get('error') is None and type(report.get('finished_utc')) is str and bool(report['finished_utc'])
         and report['original_qualification_job_id'] == binding['original_qualification_job_id']
         and all(report.get(key) is True for key in ('passed', 'only_six_original_JSON_bodies_in_payload',
             'original_six_files_unchanged', 'tool_and_input_identities_unchanged',
             'single_gzip_crc_eof_and_all_seven_members_verified'))
         and all(report.get(key) is False for key in ('qualification_or_CI_or_audit_replayed',
             'source_or_binary_modified', 'runtime_source_or_elf_bodies_read',
             'original_json_bodies_reencoded', 'archive_code_executed', 'candidate_adoption_assessed'))
         and report['original_file_count'] == report['expected_original_file_count'] == 6
         and report['archive_member_count'] == report['expected_archive_member_count'] == 7
         and report['maximum_transfer_decoded_chunk_bytes'] == 48000 and report['automatic_retries'] == 0,
         'actual complete fixed-scope export report required')
    for row, path, size, sha in (
        (report['exporter'], EXPORTER_PATH, 15405, EXPORTER_SHA),
        (report['archive_helper'], '/home/qian/hepta-runtime-optimization-20261105-r25/tools/r26_export_stable_archive_03.py', 12842, HELPER_SHA),
        (report['input'], INPUT_PATH, input_id['bytes'], input_id['sha256'])):
        need(row['source_path'] == path and row['bytes'] == size and row['sha256'] == sha
             and row['is_elf'] is False, 'original export source/helper/input binding differs')
    need(set(report['files']) == set(FILES), 'export payload file scope differs')
    for name, expected in binding['expected_files'].items():
        row = report['files'][name]
        need(all(row[key] == value for key, value in expected.items()) and row['is_elf'] is False,
             'actual export file differs from its fixed input')
    archive_pin = report['archive']
    need(archive_pin['source_path'] == REMOTE + '/' + ARCHIVE
         and type(archive_pin['bytes']) is int and 0 < archive_pin['bytes'] <= MAX_ARCHIVE
         and type(archive_pin['sha256']) is str and HEX.fullmatch(archive_pin['sha256'])
         and transfer['archive'] == report['transfer']['archive'] == archive_pin
         and report['archive_validation']['identity'] == archive_pin
         and report['archive_validation']['verified'] is True
         and report['archive_validation']['regular_members'] == 7,
         'whole original archive identity differs')
    manifest_pin = report['manifest']
    need(manifest_pin['source_path'] == REMOTE + '/manifest.json'
         and type(manifest_pin['bytes']) is int and 0 < manifest_pin['bytes'] <= 1024**2
         and type(manifest_pin['sha256']) is str and HEX.fullmatch(manifest_pin['sha256']),
         'original embedded manifest pin differs')
    need(transfer['schema'] == 'hepta-r26-lossless-archive-chunks/v1' and transfer['encoding'] == 'base64'
         and transfer['maximum_decoded_chunk_bytes'] == 48000 and transfer['maximum_text_file_bytes'] == 64000
         and report['transfer']['manifest']['source_path'] == REMOTE + '/' + ARCHIVE + '.chunks/manifest.json'
         and (transfer_id['bytes'], transfer_id['sha256']) ==
             (report['transfer']['manifest']['bytes'], report['transfer']['manifest']['sha256'])
         and type(transfer['chunks']) is list
         and len(transfer['chunks']) == report['transfer']['chunks'] == (archive_pin['bytes'] + 47999) // 48000,
         'actual original transfer manifest differs')
    expected, offset = [], 0
    for number, chunk in enumerate(transfer['chunks']):
        need(set(chunk) == {'path', 'offset', 'bytes', 'sha256', 'base64_bytes', 'base64_sha256'}
             and chunk['path'] == f'{REMOTE}/{ARCHIVE}.chunks/chunk-{number:05d}.b64'
             and chunk['offset'] == offset and type(chunk['bytes']) is int
             and chunk['bytes'] == min(48000, archive_pin['bytes'] - offset)
             and chunk['base64_bytes'] == 4 * ((chunk['bytes'] + 2) // 3) <= 64000
             and all(type(chunk[k]) is str and HEX.fullmatch(chunk[k]) for k in ('sha256', 'base64_sha256')),
             'original chunk sequence or hash differs')
        expected.append(chunk)
        offset += chunk['bytes']
    need(offset == archive_pin['bytes'], 'original chunk total differs')
    body, read_proofs = bytearray(), []
    for number in range((len(expected) + 3) // 4):
        chunks = expected[number * 4:number * 4 + 4]
        request = {'host': 'x230', 'paths': [chunk['path'] for chunk in chunks],
                   'max_file_bytes': 65536, 'max_response_bytes': 262144}
        identity, raw = stable_read(read_dir / f'read-batch-{number:03d}.json')
        envelope = load(raw)
        need(type(envelope) is dict and set(envelope) == {'request', 'result'}
             and envelope['request'] == request, 'original request/result envelope differs')
        result = envelope['result']
        need(type(result) is dict and result.get('isError') is not True
             and type(result.get('content')) is list and len(result['content']) == 1
             and result['content'][0].get('type') == 'text'
             and type(result['content'][0].get('text')) is str, 'successful original text response required')
        dto = load(result['content'][0]['text'])
        need(type(dto) is dict and dto.get('atomic_snapshot') is False
             and dto.get('encoding') == 'utf-8' and dto.get('snapshot_scope') == 'independent_file'
             and dto.get('truncated') is False and type(dto.get('files')) is list
             and len(dto['files']) == len(chunks), 'complete original file response required')
        versions = []
        for current, chunk in zip(dto['files'], chunks, strict=True):
            need(type(current) is dict and set(current) == {'eof', 'path', 'sha256', 'size', 'text', 'version'}
                 and current['path'] == chunk['path'] and current['eof'] is True
                 and type(current['size']) is int and current['size'] == chunk['base64_bytes']
                 and current['sha256'] == chunk['base64_sha256'] and type(current['text']) is str,
                 'original file metadata differs')
            version = current['version']
            need(type(version) is str and re.fullmatch(r'[0-9]+:[0-9]+:[0-9]+:[0-9]+:[0-9]+', version),
                 'original file version is malformed')
            device, inode, size, mtime, ctime = map(int, version.split(':'))
            need(device > 0 and inode > 0 and size == current['size'] and mtime > 0 and ctime > 0,
                 'original file version and size disagree')
            encoded = current['text'].encode('ascii')
            need(len(encoded) == chunk['base64_bytes'] and digest(encoded) == chunk['base64_sha256'],
                 'encoded chunk bytes differ')
            decoded = base64.b64decode(encoded, validate=True)
            need(base64.b64encode(decoded) == encoded and len(decoded) == chunk['bytes']
                 and digest(decoded) == chunk['sha256'], 'decoded chunk bytes differ')
            need(len(body) == chunk['offset'], 'decoded chunk offset differs')
            body.extend(decoded)
            versions.append({'path': current['path'], 'version': version,
                             'bytes': current['size'], 'sha256': current['sha256']})
        inputs.append(identity)
        read_proofs.append({'batch_index': number, 'original_envelope': identity,
                            'original_file_versions': versions})
    need(len(body) == archive_pin['bytes'] and digest(body) == archive_pin['sha256'], 'whole archive differs')
    helper, helper_identity = load_helper(inputs)
    recheck(inputs)
    evidence.mkdir(mode=0o700)
    evidence_identity = stamp(evidence.lstat())
    local_archive = write_new(evidence / ARCHIVE, bytes(body))
    retained, manifest_raw = {}, None
    with tarfile.open(evidence / ARCHIVE, mode='r|gz') as archive:
        for number, member in enumerate(archive):
            names = ['_export-manifest.json', *sorted(FILES)]
            need(number < 7 and member.name == names[number] and member.type == tarfile.REGTYPE
                 and not member.linkname and not member.pax_headers and not member.issparse()
                 and member.mode == 0o600, 'exact seven ordinary regular members required')
            pin = manifest_pin if number == 0 else binding['expected_files'][member.name]
            need(member.size == pin['bytes'], 'original member size differs')
            stream = archive.extractfile(member)
            need(stream is not None, 'original regular member bytes unavailable')
            raw = stream.read(member.size + 1)
            need(len(raw) == pin['bytes'] and digest(raw) == pin['sha256'], 'original member bytes differ')
            value = load(raw)
            need(type(value) is dict, 'original JSON object required')
            if number == 0:
                manifest_raw = raw
                need(value['schema'] == 'hepta-r28-fixed-six-qualification-receipts-manifest/v1'
                     and value['files'] == report['files']
                     and value['original_qualification_job_id'] == binding['original_qualification_job_id']
                     and value['qualification_receipt_cross_links'] == report['qualification_receipt_cross_links']
                     and value['original_json_bytes_preserved'] is True and value['omitted_bodies'] == []
                     and value['member_names_match_actual_CI02_receipt_layout'] is True
                     and value['archive_code_executed'] is False and value['runtime_source_or_elf_bodies_included'] is False,
                     'original embedded manifest/report binding differs')
            else:
                retained[member.name] = raw
    need(manifest_raw is not None and set(retained) == set(FILES), 'all six raw original JSON bodies required')
    proof = helper.verify_archive(evidence / ARCHIVE, manifest_raw, report['files'])
    need(proof['verified'] is True and proof['regular_members'] == 7
         and proof['gzip_integrity'] == report['archive_validation']['gzip_integrity']
         and (proof['identity']['bytes'], proof['identity']['sha256']) == (archive_pin['bytes'], archive_pin['sha256']),
         'complete single-gzip/all-seven-member verification differs')
    require_terminal(load(retained['qualification-native-terminal-02.json']), binding['original_qualification_job_id'])
    local_manifest = write_new(evidence / 'manifest.json', manifest_raw)
    recheck(inputs)
    need(stable_read(evidence / ARCHIVE, MAX_ARCHIVE)[0] == local_archive,
         'assembled archive changed before materialization')
    OUT.mkdir(mode=0o700)
    out_identity = stamp(OUT.lstat())
    outputs = {name: write_new(OUT / name, raw) for name, raw in sorted(retained.items())}
    for name, row in outputs.items():
        identity, raw = stable_read(OUT / name, 16 * 1024**2)
        need(identity == row and raw == retained[name], 'materialized original JSON changed')
    recheck(inputs)
    for directory, original in ((OUT, out_identity), (evidence, evidence_identity)):
        current = stamp(directory.lstat())
        need(directory.resolve(strict=True) == directory and all(current[k] == original[k]
             for k in ('st_dev', 'st_ino', 'st_uid', 'st_mode')), 'owned output directory changed')
        fd = os.open(directory, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW | os.O_CLOEXEC)
        try:
            os.fsync(fd)
        finally:
            os.close(fd)
    need({p.name for p in OUT.iterdir()} == set(FILES), 'materialized output inventory differs')
    receipt = {'schema': 'hepta-r28-fixed-six-local-receipt-materialization/v1', 'materialized': True,
        'original_qualification_job_id': binding['original_qualification_job_id'],
        'original_export_job_id': binding['original_export_job_id'], 'original_bound_inputs': inputs,
        'original_read_batches': read_proofs, 'reviewed_archive_helper': helper_identity,
        'archive': local_archive, 'manifest': local_manifest, 'all_seven_members_verified': proof,
        'original_manifest_six_files': report['files'], 'output_directory': str(OUT), 'outputs': outputs,
        'six_original_JSON_bytes_preserved': True, 'qualification_content_gate_reexecuted': False,
        'downstream_six_receipt_CI_freezer_still_required': True, 'CI_success_claimed': False,
        'candidate_adoption_assessed': False, 'archive_code_executed': False, 'archive_extractall_used': False,
        'tests_or_audits_or_workloads_replayed': False, 'host_RPC_calls': 0,
        'automatic_retries': 0, 'partial_failure_files_preserved': True}
    raw = (json.dumps(receipt, sort_keys=True, indent=2, allow_nan=False) + '\n').encode()
    result = write_new(evidence / 'materialization-receipt-01.json', raw)
    print(json.dumps({'materialized': True, 'files': 6, 'receipt': result,
                      'CI_freezer_still_required': True}, sort_keys=True))


if __name__ == '__main__':
    main()
