# R28 complete performance originals — rejected observation, lifecycle unsubmitted

This package captures the one actual R28 observation attempt and the exact prepared tools. The original Mac native holder `1a1acbbcbec-fc05-56a0` completed with code 0, while the frozen observation gate rejected C1 throughput. Capture success never changes that result. Lifecycle ABBA and saturation were not submitted; their output-path absence must be observed and rechecked during the actual capture. No workload, probe, retry, cleanup, source mutation, threshold change or adoption action is implemented here.

## Exact scope

The exporter includes every original regular file in `ROOT28/campaign-01`, including its nested `native-observation` and `native-boundary`, and in the original canary directory `R16/r28-cancel-recovery-01`. It also includes the complete installed `tools-02`, `boundary-tools-01`, `lifecycle-tools-02` and `lifecycle-launcher-bundle-02` trees, the exact 50 installed asset identities, the original 12 measurement and 5 boundary source files, topology, actual campaign input and installation receipt. A private profile template is retained by complete identity only.

Four small actual qualification references bind the candidate source map, qualified binaries and parent lineage to the separate full qualification/CI package. This performance package does not copy the large isolated test logs, compiler caches or full candidate source bodies from that package. Accepted R24 baseline references remain in the original campaign input and source snapshots. Original parent stage stdout/stderr and seven stage output identities are tied to their producer records; the native/boundary/canary reports and their independent summaries are also bound to the exact rejected summary. All files in the two original output trees remain included, including complete resource traces and other raw logs.

ELF and private transport/configuration files are classified before marker scanning. Their full byte count, SHA-256 and descriptor identity remain in the manifest; their body is not copied. Public source is not scanned as though source literals were actual credentials. Original runtime outputs retain the existing private-marker check.

## Outcome and monitor proof

The actual input pins the exact 106,682-byte parent, 729-byte original native terminal text and 13,588-byte rejected summary. The original terminal body comes directly from the sole original MCP `content.text`, with no reencoding or extra newline. The separate Mac package retains the original outer wrapper. A later cross-package binder must compare that wrapper's exact inner text bytes to this DTO, not equate two different envelope hashes.

The existing pure monitor validator is byte-identical to the actual source used by R28. The exporter checks ledger/audit/parent/source bindings; the local consumer independently recalculates the same result using the reviewed local validator source. It never executes the archived validator or any other archive member. A missing, malformed or inconsistent monitor remains invalid, and a positive original attribution flag cannot override that independent result. The 1 Hz monitor still does not rule out activity between samples.

The original `passed` transport/correctness flag and false `observation_gate_passed` remain separate. The known rejection reason stays `C1 regression gate`. A successful capture or archive verification makes no adoption or hosted-CI claim.

## Execution and transport

Only the root coordinator may stage and execute the exact request in `requests/native-export-01.request.json`, after source peer review and outside timed measurement. Source/helper/input/terminal writes are create-only; reuse an existing shared XZ helper only after exact identity verification. All requests here are prepared data, not proof that a call happened.

Remote output: `/home/qian/hepta-runtime-optimization-20261105-r28/performance-evidence-01`. The archive is `performance-01.tar.xz`, using the exact reviewed single-stream XZ SHA256/USTAR helper. The helper emits 48,000-byte raw chunks with base64 text and per-chunk hashes. Its 512 MiB expanded-byte and decoder limit is not a total RSS guarantee. Full original capture request/start/terminal/read envelopes must be preserved separately.

After the actual archive and its original report are completely downloaded, use only absolute paths:

```text
/usr/bin/python3 -I -B /workspace/scratch/806ba5f52f94/r25-integration-audit/r28-performance-export-01/verify_r28_performance_01.py
  --archive <actual absolute performance-01.tar.xz>
  --export-report <actual original report.json>
  --report-sha256 <actual report SHA-256>
  --capture-native-terminal <exact original full terminal DTO>
  --capture-native-read <exact original single full read DTO>
  --out <fresh absolute verification receipt>
```

The consumer verifies the complete compressed stream, embedded manifest, every regular member, original payload/omission inventories, fixed namespaces, source/log/report bindings, recorded outcomes and unexecuted-output absence records. It performs no extraction or archive-code execution. Full native custody, the Mac holder archive, and the full qualification/CI package remain required companion evidence.

## Review entry points

`source-reuse-proof-01.json` lists all unchanged helper functions and the small set of new fixed composition functions. `exporter-vs-QC02.patch` and `consumer-vs-QC02.patch` show the complete deltas. `actual-binding-01.json` ties the known input to the original parent/summary/monitor/native receipts. The sources and requests have not been executed by their author; archive identity, member count, capture success and local full-QA outcome remain unknown until the actual operation.
