RECOVERY_INPUT = TOOLS / "original-preflight-recovery-02.json"
ORIGINAL_LAUNCH = ROOT / "python-ci-launch-01"
ORIGINAL_OUTPUT = ROOT / "python-ci-01"
ORIGINAL_LAUNCHER = ROOT / "python-ci-tools-01/launch_python_ci_01.py"
ORIGINAL_LAUNCHER_IDENTITY = {"bytes": 25415, "sha256": "57f0ed9ab6304824e06751ebc0ba1c0fbd406d07f37301c0be81e6ee49c85b5c"}
ORIGINAL_JOB_ID = "1a1ac97d8cb-fc05-55a2"
METADATA_JOB_ID = "1a1aca4ad22-fc05-561a"
ORIGINAL_EVIDENCE = {
    "failed_start": {"bytes": 2474, "sha256": "edc0b84ce9fea731f218fa0ed02c17917c13eb01dadacf84ea6a59a9dc3e7383"},
    "failed_terminal": {"bytes": 1063, "sha256": "ed3d9b76997d3b22eadf8824e3b2472cdb36062cca24512fd4a789476a194a6b"},
    "failed_read": {"bytes": 5033, "sha256": "c154dab11d41b32719f4fa8895e3e5a7325766342a5acf5c3f64edd283b6f79f"},
    "failed_receipt": {"bytes": 1506, "sha256": "3b24569825c641d07249d71d9e064d703ee760e728eac96c979345bb2774dd96"},
    "metadata_terminal": {"bytes": 1066, "sha256": "9f8dbc4876a32dcfb7419cbcfce7a01422b76b4a3b2c7db9f7736475040f9320"},
    "metadata_read": {"bytes": 23051, "sha256": "42bdf14849241988f7b3da42e5abd8b8b66784cfba8bb17e8ce8c136e1e9c935"},
    "metadata_report": {"bytes": 6996, "sha256": "50384e10e6af28703fd4a9f291573719d1ed1653330e2300807d27c3f4fc6650"},
}


def original_dto(raw, expected_job):
    envelope = json.loads(raw)
    need(envelope["request"]["host"] == "x230", "original native host differs")
    result = envelope["result"]
    need(result.get("isError") is False and len(result["content"]) == 1
         and result["content"][0]["type"] == "text", "original native reply is not one successful RPC")
    value = json.loads(result["content"][0]["text"])
    need(value.get("job_id", value.get("job", {}).get("id")) == expected_job,
         "original native job identity differs")
    return envelope["request"], value


def original_complete_streams(terminal_raw, read_raw, job_id, state, exit_code, stdout_bytes):
    status_request, terminal = original_dto(terminal_raw, job_id)
    read_request, reading = original_dto(read_raw, job_id)
    need(status_request["job_id"] == read_request["job_id"] == job_id
         and terminal["state"] == state and type(terminal["exit_code"]) is int
         and terminal["exit_code"] == exit_code
         and all(terminal[k] is True for k in ("output_complete", "output_durable", "terminal_publication_confirmed"))
         and terminal["terminal_publication_protocol"] == 1
         and all(terminal[k] is False for k in ("automatic_retry", "cancelled", "timed_out"))
         and terminal["log_synced"] == {"stdout": True, "stderr": True}
         and terminal["log_errors"] == {"stdout": None, "stderr": None}
         and terminal["log_truncated"] == {"stdout": False, "stderr": False},
         "original native strong terminal differs")
    streams = {}
    for channel, size in (("stdout", stdout_bytes), ("stderr", 0)):
        row = reading[channel]
        body = bytes.fromhex(row["bytes_hex"])
        need(terminal["log_bytes"][channel] == {"seen": size, "stored": size}
             and read_request[channel + "_offset"] == 0
             and row["offset"] == 0 and row["next_offset"] == row["size"] == size == len(body)
             and row["eof"] is True and row["text"] == body.decode("utf-8"),
             "original native complete stream differs")
        streams[channel] = body
    return streams


def verify_original_preflight_failure(recovery_sha):
    raw = checked_read(RECOVERY_INPUT, recovery_sha)
    recovery = json.loads(raw)
    need(recovery["schema"] == "hepta-r28-python-ci-preflight-recovery/v1"
         and recovery["original_failed_job_id"] == ORIGINAL_JOB_ID
         and recovery["metadata_job_id"] == METADATA_JOB_ID
         and recovery["source_modified"] is False and recovery["source_permissions_modified"] is False
         and recovery["old_ci_rerun"] is False and recovery["previous_tests_passed_inferred"] is False
         and set(recovery["originals"]) == set(ORIGINAL_EVIDENCE),
         "fixed original preflight recovery binding differs")
    originals = {}
    for name, expected in ORIGINAL_EVIDENCE.items():
        original = base64.b64decode(recovery["originals"][name], validate=True)
        need(body_identity(original) == expected, "original recovery evidence differs: " + name)
        originals[name] = original
    request, started = original_dto(originals["failed_start"], ORIGINAL_JOB_ID)
    expected_args = ["-I", "-B", str(ORIGINAL_LAUNCHER), "--launcher-sha256",
                     ORIGINAL_LAUNCHER_IDENTITY["sha256"], "--actual-input-sha256",
                     "b60562acab3655df24199a055bc426b998681cd5ba2294967d516e5e59878f73"]
    job = started["job"]
    need(request["args"] == job["args"] == expected_args
         and request["executable"] == job["executable"] == "/usr/bin/python3"
         and request["cwd"] == job["cwd"] == str(ROOT)
         and request["idempotency_key"] == job["idempotency_key"] == "hepta-r28-python-ci-20261105-01"
         and job["request_digest"] == "f72eb31513f0b5b0a21e7a9c7f3c9f1857992058624a1bdf69796f677c20146f"
         and job["launch_state"] == "launched" and started["reused"] is False,
         "original launch binding differs")
    failed = original_complete_streams(originals["failed_terminal"], originals["failed_read"],
                                      ORIGINAL_JOB_ID, "failed", 1, 1356)
    receipt = json.loads(originals["failed_receipt"])
    need(json.loads(failed["stdout"]) == receipt and receipt["passed"] is False
         and receipt["schema"] == "hepta-r28-python-ci-one-time-launch-v1"
         and receipt["launcher_source"] == ORIGINAL_LAUNCHER_IDENTITY
         and receipt["error"] == {"type": "ValueError", "message": "unsafe or oversized bound input"}
         and receipt["retry_count"] == 0 and receipt["package_verification"]["verified_regular_members"] == 103
         and receipt["runner"] == {"bytes": 9723, "sha256": RUNNER_SHA256}
         and receipt["manifest"] == {"bytes": 45857, "sha256": MANIFEST_SHA256}
         and receipt["finished_unix"] >= receipt["started_unix"]
         and not set(receipt) & {"candidate_binding_before", "argv", "environment", "runner_pid",
                                "runner_returncode", "report", "gates_executed"},
         "original failure is not the preserved preflight-only outcome")
    metadata_streams = original_complete_streams(originals["metadata_terminal"], originals["metadata_read"],
                                                METADATA_JOB_ID, "succeeded", 0, 6996)
    need(metadata_streams["stdout"] == originals["metadata_report"], "original metadata stdout differs")
    metadata = json.loads(originals["metadata_report"])
    need(metadata["schema"] == "hepta-r28-python-ci-mode-metadata/v1" and metadata["passed"] is True
         and metadata["original_failed_job_id"] == ORIGINAL_JOB_ID
         and metadata["effective_uid"] == metadata["effective_gid"] == 1000
         and metadata["filesystem_mutated"] is False and metadata["ci_executed"] is False
         and metadata["errors"] == [] and metadata["qualified_runtime_or_ci_pass_inferred"] is False
         and metadata["original_launch_directory_names"] == ["receipt.json"]
         and metadata["only_original_failure_receipt"] is True
         and metadata["original_python_ci_output"] == {
             "path": str(ORIGINAL_OUTPUT), "absent": True, "identity_if_present": None},
         "actual read-only metadata or original absence proof differs")
    directories = {row["path"]: row for row in metadata["directories"]}
    expected_directories = {str(path) for path in (Path("/home"), Path("/home/qian"), ROOT,
                            QUALIFIED_SOURCE, QUALIFIED_SOURCE / "src", QUALIFIED_SOURCE / "src/mcp",
                            QUALIFIED_SOURCE / "src/mcp/runtime", ORIGINAL_LAUNCH)}
    need(len(metadata["directories"]) == 8 and set(directories) == expected_directories,
         "exact original source ancestry required")
    critical = ("st_dev", "st_ino", "st_mode", "st_uid", "st_gid")
    for name, row in directories.items():
        path = Path(name)
        need(row["stable"] is True and row["kind"] == "directory"
             and path.resolve(strict=True) == path, "original directory is indirect or unstable")
        if path not in (Path("/home"), Path("/home/qian")):
            need(row["identity"]["st_mode"] == 0o40700
                 and row["identity"]["st_uid"] == row["identity"]["st_gid"] == 1000,
                 "qualified source ancestry was not private")
        fd = os.open(path, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW | os.O_CLOEXEC)
        try:
            current, linked = os.fstat(fd), path.lstat()
            need(stat.S_ISDIR(current.st_mode) and all(getattr(current, key) == getattr(linked, key)
                 == row["identity"][key] for key in critical), "original directory ownership/path changed")
        finally:
            os.close(fd)
    files = {row["path"]: row for row in metadata["files"]}
    receipt_path = ORIGINAL_LAUNCH / "receipt.json"
    need(len(metadata["files"]) == 3 and set(files) == {str(path) for path in SOURCE_MODE_EXCEPTIONS} | {str(receipt_path)},
         "exact original two sources and failure receipt required")
    fields = ("st_dev", "st_ino", "st_mode", "st_uid", "st_gid", "st_nlink", "st_size", "st_mtime_ns", "st_ctime_ns")
    for name, row in files.items():
        path = Path(name)
        need(row["stable"] is True and row["kind"] == "regular", "original file metadata is unstable")
        if path in SOURCE_MODE_EXCEPTIONS:
            expected = SOURCE_MODE_EXCEPTIONS[path]
            need({key: row[key] for key in ("bytes", "sha256")} == expected
                 and row["matches_actual_qualified_source"] is True
                 and row["identity"]["st_mode"] == 0o100660
                 and row["identity"]["st_uid"] == row["identity"]["st_gid"] == 1000,
                 "original mode exception was not observed for the exact source")
            checked_read(path, expected["sha256"], qualified_source=True)
        else:
            need(row["matches_original_preflight_failure"] is True
                 and base64.b64decode(row["original_bytes_base64"], validate=True) == originals["failed_receipt"],
                 "original remote failure receipt differs")
            need(checked_read(path, ORIGINAL_EVIDENCE["failed_receipt"]) == originals["failed_receipt"],
                 "original failure receipt bytes changed")
        current = path.lstat()
        need(all(getattr(current, key) == row["identity"][key] for key in fields),
             "original source or failure receipt identity changed")
    checked_read(ORIGINAL_LAUNCHER, ORIGINAL_LAUNCHER_IDENTITY)
    need(not os.path.lexists(ORIGINAL_OUTPUT)
         and sorted(path.name for path in ORIGINAL_LAUNCH.iterdir()) == ["receipt.json"],
         "original failed attempt gained CI outputs")
    return {"passed": True, "recovery_input": body_identity(raw), "original_failed_job_id": ORIGINAL_JOB_ID,
            "original_state": "failed", "original_exit_code": 1, "original_native_stdout": body_identity(failed["stdout"]),
            "original_native_stderr": body_identity(failed["stderr"]), "original_evidence": ORIGINAL_EVIDENCE,
            "original_runner_started": False, "original_ci_output_absent": True,
            "metadata_job_id": METADATA_JOB_ID, "qualified_source_permissions_modified": False,
            "previous_tests_passed_inferred": False, "source_exception_count": 2,
            "generic_bound_input_mode_policy_unchanged": True, "bound_input_limit_bytes": 16 * 1024 * 1024}
