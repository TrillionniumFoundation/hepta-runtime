#!/usr/bin/env python3
"""Small local permission-boundary and byte/AST checks; never launches CI or reads a host."""
import ast
import base64
import copy
import gzip
import hashlib
import io
import json
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch
import tarfile

BASE = Path(__file__).resolve().parent
WORK = BASE.parents[1]
DELIVERY = BASE / "delivery-02"
OLD = WORK / "r25-capacity-audit/r28-ci02-actual-generation-01/python-delivery-01"


def identity(raw):
    return {"bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest()}


def main():
    new_raw = (DELIVERY / "tools/launch_python_ci_02.py").read_bytes()
    old_raw = (OLD / "tools/launch_python_ci_01.py").read_bytes()
    namespace = {"__name__": "_local_permission_checks", "__file__": str(DELIVERY / "tools/launch_python_ci_02.py")}
    exec(compile(new_raw, namespace["__file__"], "exec"), namespace)
    metadata = json.loads((WORK / "benchmark-r28/python-ci-mode-metadata-01/actual-metadata-report-01.json").read_bytes())
    observed = {row["path"]: row for row in metadata["files"]}
    results = []

    class Stream(io.BytesIO):
        def fileno(self):
            return 42

    def exercise(label, path, expected, info, body, eligible=False, changed_gid=False, succeeds=False):
        after = copy.copy(info)
        if changed_gid:
            after.st_gid += 1
        stream = Stream(body)
        with patch.object(Path, "resolve", lambda self, strict=False: self), \
             patch.object(Path, "lstat", lambda self: after), \
             patch.object(namespace["os"], "open", lambda *a, **k: 42), \
             patch.object(namespace["os"], "fdopen", lambda *a, **k: stream), \
             patch.object(namespace["os"], "fstat", side_effect=[info, after]), \
             patch.object(namespace["os"], "geteuid", lambda: 1000):
            try:
                value = namespace["checked_read"](path, expected, qualified_source=eligible)
            except ValueError as error:
                assert not succeeds, (label, str(error))
                results.append({"case": label, "rejected": True, "reason": str(error)})
            else:
                assert succeeds and value == body, label
                results.append({"case": label, "accepted": True, "body": identity(value)})

    for remote, expected in namespace["SOURCE_MODE_EXCEPTIONS"].items():
        relative = remote.relative_to(namespace["QUALIFIED_SOURCE"])
        body = (WORK / "r26-candidate-proposal/candidate" / relative).read_bytes()
        assert identity(body) == expected
        info = SimpleNamespace(**observed[str(remote)]["identity"])
        exercise("exact observed source " + remote.name, remote, expected["sha256"], info, body, True, succeeds=True)
    remote = next(iter(namespace["SOURCE_MODE_EXCEPTIONS"]))
    expected = namespace["SOURCE_MODE_EXCEPTIONS"][remote]
    body = (WORK / "r26-candidate-proposal/candidate" / remote.relative_to(namespace["QUALIFIED_SOURCE"])).read_bytes()
    info = SimpleNamespace(**observed[str(remote)]["identity"])
    exercise("generic reader rejects listed 0660 source", remote, expected["sha256"], info, body)
    exercise("source flag without expected SHA rejected", remote, None, info, body, True)
    exercise("wrong expected SHA rejected", remote, "0" * 64, info, body, True)
    exercise("unlisted 0660 source rejected", remote.with_name("unknown.rs"), expected["sha256"], info, body, True)
    exercise("JSON/tool 0660 rejected", namespace["TOOLS"] / "actual-python-input-01.json", expected["sha256"], info, body, True)
    for field, value in (("st_mode", 0o100666), ("st_uid", 1001), ("st_gid", 1001), ("st_nlink", 2), ("st_size", 17146)):
        invalid = copy.copy(info)
        setattr(invalid, field, value)
        exercise("different " + field + " rejected", remote, expected["sha256"], invalid, body, True)
    exercise("actual content changed rejected", remote, expected["sha256"], info, bytes([body[0] ^ 1]) + body[1:], True)
    exercise("gid changed during descriptor read rejected", remote, expected["sha256"], info, body, True, changed_gid=True)
    safe = copy.copy(info)
    safe.st_mode = 0o100600
    exercise("ordinary strict input remains accepted", remote.with_name("ordinary.json"), expected["sha256"], safe, body, succeeds=True)

    old_tree, new_tree = ast.parse(old_raw), ast.parse(new_raw)
    functions = lambda tree: {node.name: node for node in tree.body if isinstance(node, ast.FunctionDef)}
    old_functions, new_functions = functions(old_tree), functions(new_tree)
    unchanged = []
    for name in old_functions:
        if name in ("checked_read", "verify_candidate_binding", "main"):
            continue
        assert ast.dump(old_functions[name], include_attributes=False) == ast.dump(new_functions[name], include_attributes=False), name
        unchanged.append(name)
    candidate = copy.deepcopy(new_functions["verify_candidate_binding"])
    calls = [node for node in ast.walk(candidate) if isinstance(node, ast.Call) and isinstance(node.func, ast.Name)
             and node.func.id == "checked_read" and node.keywords]
    assert len(calls) == 1 and ast.unparse(calls[0].args[0]) == "QUALIFIED_SOURCE / relative"
    assert len(calls[0].keywords) == 1 and calls[0].keywords[0].arg == "qualified_source" and calls[0].keywords[0].value.value is True
    calls[0].keywords = []
    assert ast.dump(candidate, include_attributes=False) == ast.dump(old_functions["verify_candidate_binding"], include_attributes=False)
    # Explicitly reverse the four main insertions and the installed filename;
    # the original environment, argv, child ownership, 18 gates and final gate
    # are thereby checked as one unchanged AST, not mirrored test assertions.
    main = copy.deepcopy(new_functions["main"])
    main.body = [node for node in main.body if not (isinstance(node, ast.Expr) and isinstance(node.value, ast.Call)
                 and isinstance(node.value.func, ast.Attribute) and node.value.func.attr == "add_argument"
                 and node.value.args and isinstance(node.value.args[0], ast.Constant)
                 and node.value.args[0].value == "--recovery-input-sha256")]
    for node in ast.walk(main):
        if isinstance(node, ast.Constant) and node.value == "launch_python_ci_02.py":
            node.value = "launch_python_ci_01.py"
    clause = next(node for node in main.body if isinstance(node, ast.Try))
    clause.body = [node for node in clause.body if not (
        isinstance(node, ast.Assign) and isinstance(node.value, ast.Call)
        and isinstance(node.value.func, ast.Name) and node.value.func.id == "verify_original_preflight_failure")
        and not (isinstance(node, ast.Expr) and any(isinstance(child, ast.Call) and isinstance(child.func, ast.Name)
                 and child.func.id == "verify_original_preflight_failure" for child in ast.walk(node)))]
    assert ast.dump(main, include_attributes=False) == ast.dump(old_functions["main"], include_attributes=False)
    for name in ("actual-python-input-01.json", "candidate-parent-proof-01.json", "qualification_binding_01.py"):
        assert (OLD / "tools" / name).read_bytes() == (DELIVERY / "tools" / name).read_bytes()
    recovery_raw = (DELIVERY / "tools/original-preflight-recovery-02.json").read_bytes()
    recovery = json.loads(recovery_raw)
    originals = {name: base64.b64decode(value, validate=True) for name, value in recovery["originals"].items()}
    assert {name: identity(raw) for name, raw in originals.items()} == namespace["ORIGINAL_EVIDENCE"]
    failed = namespace["original_complete_streams"](originals["failed_terminal"], originals["failed_read"],
                                                    namespace["ORIGINAL_JOB_ID"], "failed", 1, 1356)
    assert json.loads(failed["stdout"]) == json.loads(originals["failed_receipt"])
    metadata_streams = namespace["original_complete_streams"](originals["metadata_terminal"], originals["metadata_read"],
                                                             namespace["METADATA_JOB_ID"], "succeeded", 0, 6996)
    assert metadata_streams["stdout"] == originals["metadata_report"]
    package = (DELIVERY / "python-ci-tools-02.tar.gz").read_bytes()
    expanded = gzip.decompress(package)
    with tarfile.open(fileobj=io.BytesIO(expanded), mode="r:") as archive:
        members = archive.getmembers()
        assert len(members) == 6 and {m.name for m in members} == {p.name for p in (DELIVERY / "tools").iterdir()}
        for member in members:
            assert member.isreg() and member.mode == 0o600 and 0 < member.size <= 65536
            assert archive.extractfile(member).read() == (DELIVERY / "tools" / member.name).read_bytes()
        assert len(expanded[archive.offset:]) >= 1024 and not any(expanded[archive.offset:])
    install = json.loads((DELIVERY / "install-request-02.json").read_bytes())
    assert install["args"] == ["-I", "-B", "-c", (DELIVERY / "install_python_ci_tools_02.py").read_text()]
    assert base64.b64decode(install["stdin"], validate=True) == package
    ci = json.loads((DELIVERY / "ci-request-02.json").read_bytes())
    assert ci["args"][4] == identity(new_raw)["sha256"] and ci["args"][8] == identity(recovery_raw)["sha256"]
    receipt = {"schema": "hepta-r28-python-ci-mode-correction-local-check/v1", "passed": True,
               "launcher": identity(new_raw), "permission_cases": results,
               "unchanged_functions": unchanged, "candidate_binding_AST_after_one_explicit_keyword_reversal_equal": True,
               "main_AST_after_explicit_recovery_insertions_and_filename_reversal_equal": True,
               "original_failed_native_stdout": identity(failed["stdout"]), "metadata_stdout": identity(metadata_streams["stdout"]),
               "archive": identity(package), "six_regular_members_exact": True, "three_binding_files_unchanged": True,
               "remote_read_or_execution": False, "original_18_workflow_commands_run": False,
               "new_launcher_main_executed": False}
    with (BASE / "local-correction-checks-02.json").open("x") as stream:
        json.dump(receipt, stream, sort_keys=True, indent=2)
        stream.write("\n")
    print(json.dumps({"passed": True, "permission_cases": len(results), "six_members": True, "main_AST_equal_after_explicit_delta": True}, sort_keys=True))


if __name__ == "__main__":
    main()
