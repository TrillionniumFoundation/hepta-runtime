# Exact inherited source identities confirmed by the original read-only metadata
# job 1a1aca4ad22-fc05-561a. No JSON, tool or unlisted source is eligible.
SOURCE_MODE_EXCEPTIONS = {
    QUALIFIED_SOURCE / "src/mcp/runtime/jobs_cancel_io_tests.rs": {
        "bytes": 17145,
        "sha256": "b9553137fe32d873536252c4371bcb57dfceb4e8fac988937b7c552a871f889a",
    },
    QUALIFIED_SOURCE / "src/mcp/runtime/jobs_cancel_read_tests.rs": {
        "bytes": 14542,
        "sha256": "ff92e72b71a8afc23edda7e686c66f87c13ac76dfa3b5c8a8b8e124383b3bf87",
    },
}


def qualified_source_mode_allowed(path, expected, info):
    known = SOURCE_MODE_EXCEPTIONS.get(path)
    return bool(known is not None and type(expected) is str
                and expected == known["sha256"]
                and info.st_mode == 0o100660 and info.st_uid == 1000
                and info.st_gid == 1000 and info.st_nlink == 1
                and info.st_size == known["bytes"])


def checked_read(path, expected=None, *, qualified_source=False):
    need(path.is_absolute() and path.resolve(strict=True) == path, "direct absolute input required")
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK | os.O_CLOEXEC)
    with os.fdopen(fd, "rb") as stream:
        before = os.fstat(stream.fileno())
        mode_allowed = (not before.st_mode & 0o022 or
                        (qualified_source is True and qualified_source_mode_allowed(path, expected, before)))
        need(stat.S_ISREG(before.st_mode) and before.st_uid == os.geteuid()
             and before.st_nlink == 1 and mode_allowed
             and 0 < before.st_size <= 16 * 1024 * 1024,
             "unsafe or oversized bound input: " + str(path))
        body = stream.read(before.st_size + 1)
        after = os.fstat(stream.fileno())
    current = path.lstat()
    fields = ("st_dev", "st_ino", "st_mode", "st_uid", "st_gid", "st_nlink", "st_size", "st_mtime_ns", "st_ctime_ns")
    need(len(body) == before.st_size and all(getattr(before, key) == getattr(after, key)
         == getattr(current, key) for key in fields), "bound input changed during read")
    if expected is not None:
        need(body_identity(body)["sha256"] == (expected if isinstance(expected, str) else expected["sha256"]),
             "bound input SHA differs: " + str(path))
        if isinstance(expected, dict):
            need(type(expected["bytes"]) is int and len(body) == expected["bytes"], "bound input size differs")
    return body
