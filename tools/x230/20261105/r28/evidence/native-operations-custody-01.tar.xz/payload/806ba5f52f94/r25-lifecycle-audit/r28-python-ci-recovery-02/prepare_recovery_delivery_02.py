#!/usr/bin/env python3
"""Local-only deterministic derivation of the fixed Python CI preflight correction."""
import ast
import base64
import difflib
import gzip
import hashlib
import io
import json
from pathlib import Path
import pprint
import tarfile

BASE = Path(__file__).resolve().parent
WORK = BASE.parents[1]
OLD = WORK / "r25-capacity-audit/r28-ci02-actual-generation-01/python-delivery-01"
DELIVERY = BASE / "delivery-02"
SOURCES = {
    "failed_start": "benchmark-r28/python-ci-operations-01/ci-start-01.json",
    "failed_terminal": "benchmark-r28/python-ci-operations-01/ci-status-01.json",
    "failed_read": "benchmark-r28/python-ci-operations-01/ci-read-00-01.json",
    "failed_receipt": "benchmark-r28/python-ci-operations-01/actual-failed-outer-receipt-01.json",
    "metadata_terminal": "benchmark-r28/python-ci-mode-metadata-01/status-01.json",
    "metadata_read": "benchmark-r28/python-ci-mode-metadata-01/read-full-01.json",
    "metadata_report": "benchmark-r28/python-ci-mode-metadata-01/actual-metadata-report-01.json",
}


def identity(raw):
    return {"bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest()}


def save(path, raw):
    with path.open("xb") as stream:
        stream.write(raw)


def json_body(value):
    return (json.dumps(value, sort_keys=True, indent=2) + "\n").encode()


def main():
    DELIVERY.mkdir(mode=0o700)
    tools = DELIVERY / "tools"
    tools.mkdir(mode=0o700)
    originals = DELIVERY / "original-failure-01"
    originals.mkdir(mode=0o700)
    old = (OLD / "tools/launch_python_ci_01.py").read_text()
    assert identity(old.encode()) == {"bytes": 25415, "sha256": "57f0ed9ab6304824e06751ebc0ba1c0fbd406d07f37301c0be81e6ee49c85b5c"}
    source = old.replace("import argparse\n", "import argparse\nimport base64\n", 1)
    for before, after in (("OUTPUT = ROOT / \"python-ci-01\"", "OUTPUT = ROOT / \"python-ci-02\""),
                          ("LAUNCH = ROOT / \"python-ci-launch-01\"", "LAUNCH = ROOT / \"python-ci-launch-02\""),
                          ("TOOLS = ROOT / \"python-ci-tools-01\"", "TOOLS = ROOT / \"python-ci-tools-02\""),
                          ('TOOLS / "launch_python_ci_01.py"', 'TOOLS / "launch_python_ci_02.py"')):
        assert source.count(before) == 1
        source = source.replace(before, after, 1)
    start, end = source.index("def checked_read("), source.index("def checked_tree(")
    source = source[:start] + (BASE / "source_read_correction_02.py").read_text() + "\n\n" + source[end:]
    old_call = "        checked_read(QUALIFIED_SOURCE / relative, expected_sha)"
    assert source.count(old_call) == 1
    source = source.replace(old_call, old_call[:-1] + ", qualified_source=True)")
    pos = source.index("def main():")
    source = source[:pos] + (BASE / "recovery_admission_02.py").read_text() + "\n\n" + source[pos:]
    old_arg = '    parser.add_argument("--actual-input-sha256", required=True)'
    assert source.count(old_arg) == 1
    source = source.replace(old_arg, old_arg + '\n    parser.add_argument("--recovery-input-sha256", required=True)', 1)
    marker = '    try:\n        if (DEPENDENCY_RECEIPT.resolve(strict=True)'
    assert source.count(marker) == 1
    source = source.replace(marker, '    try:\n        receipt["original_preflight_failure"] = verify_original_preflight_failure(args.recovery_input_sha256)\n        if (DEPENDENCY_RECEIPT.resolve(strict=True)', 1)
    marker = '        need(receipt["candidate_binding_after"] == receipt["candidate_binding_before"], "candidate binding changed during Python CI")'
    assert source.count(marker) == 1
    source = source.replace(marker, marker + '\n        need(verify_original_preflight_failure(args.recovery_input_sha256) == receipt["original_preflight_failure"],\n             "original preflight evidence or private source ancestry changed during Python CI")', 1)
    ast.parse(source)
    save(tools / "launch_python_ci_02.py", source.encode())
    recovery = {"schema": "hepta-r28-python-ci-preflight-recovery/v1",
                "original_failed_job_id": "1a1ac97d8cb-fc05-55a2", "metadata_job_id": "1a1aca4ad22-fc05-561a",
                "source_modified": False, "source_permissions_modified": False,
                "old_ci_rerun": False, "previous_tests_passed_inferred": False, "originals": {}}
    original_inventory = []
    for name, relative in SOURCES.items():
        raw = (WORK / relative).read_bytes()
        recovery["originals"][name] = base64.b64encode(raw).decode("ascii")
        save(originals / (name + ".json"), raw)
        original_inventory.append({"name": name, "original_path": str(WORK / relative), **identity(raw)})
    # Retain the actual metadata start request/code as a separate original. It
    # is not an execution dependency; the seven fixed recovery bodies include
    # that job's strong terminal and complete 6,996-byte original stdout.
    raw = (WORK / "benchmark-r28/python-ci-mode-metadata-01/start-01.json").read_bytes()
    save(originals / "metadata_start.json", raw)
    original_inventory.append({"name": "metadata_start", "original_path": str(WORK / "benchmark-r28/python-ci-mode-metadata-01/start-01.json"), **identity(raw)})
    save(tools / "original-preflight-recovery-02.json", json_body(recovery))
    for name in ("actual-python-input-01.json", "candidate-parent-proof-01.json", "qualification_binding_01.py"):
        save(tools / name, (OLD / "tools" / name).read_bytes())
    spec = {"files": {path.name: identity(path.read_bytes()) for path in sorted(tools.iterdir())}}
    old_spec = next(ast.literal_eval(node.value) for node in ast.parse((OLD / "install_python_ci_tools_01.py").read_text()).body
                    if isinstance(node, ast.Assign) and any(isinstance(n, ast.Name) and n.id == "SPEC" for n in node.targets))
    spec["actual_pins"] = old_spec["actual_pins"]
    manifest = {"schema": "hepta-r28-exact-python-ci-tools/v1", "actual_qualification_job_id": spec["actual_pins"]["JOB_ID"],
                "files": spec["files"].copy(), "executed": False, "hosted_actions_passed": False,
                "preserved_original_failed_job_id": recovery["original_failed_job_id"],
                "original_failure_did_not_start_runner": True}
    save(tools / "package-manifest-02.json", json_body(manifest))
    spec["files"]["package-manifest-02.json"] = identity((tools / "package-manifest-02.json").read_bytes())
    assert len(spec["files"]) == 6 and max(row["bytes"] for row in spec["files"].values()) <= 65536
    buffer = io.BytesIO()
    with tarfile.open(fileobj=buffer, mode="w", format=tarfile.USTAR_FORMAT) as archive:
        for path in sorted(tools.iterdir()):
            raw = path.read_bytes()
            info = tarfile.TarInfo(path.name)
            info.size, info.mode, info.mtime, info.uid, info.gid = len(raw), 0o600, 0, 0, 0
            archive.addfile(info, io.BytesIO(raw))
    packed = gzip.compress(buffer.getvalue(), compresslevel=9, mtime=0)
    save(DELIVERY / "python-ci-tools-02.tar.gz", packed)
    spec["archive"] = identity(packed)
    encoded = base64.b64encode(packed).decode("ascii")
    spec["base64_bytes"] = len(encoded)
    old_installer = (OLD / "install_python_ci_tools_01.py").read_text()
    node = next(node for node in ast.parse(old_installer).body if isinstance(node, ast.Assign)
                and any(isinstance(n, ast.Name) and n.id == "SPEC" for n in node.targets))
    lines = old_installer.splitlines(keepends=True)
    installer = "".join(lines[:node.lineno - 1]) + "SPEC = " + pprint.pformat(spec, sort_dicts=True, width=100) + "\n" + "".join(lines[node.end_lineno:])
    for before, after in (("launcher and four binding files", "launcher, three unchanged binding files and original failure evidence"),
                          ("python-ci-tools-01", "python-ci-tools-02"),
                          ("python-ci-tools-install-01.json", "python-ci-tools-install-02.json"),
                          ("launch_python_ci_01.py", "launch_python_ci_02.py"),
                          ("package-manifest-01.json", "package-manifest-02.json"),
                          ("len(members) == 5", "len(members) == 6"),
                          ("exact five-file archive", "exact six-file archive"),
                          ("'original_file_count': 5", "'original_file_count': 6"),
                          ("'installed_regular_files': 5", "'installed_regular_files': 6")):
        installer = installer.replace(before, after)
    needle = "'actual-python-input-01.json', 'package-manifest-02.json'}"
    assert installer.count(needle) == 1
    installer = installer.replace(needle, "'actual-python-input-01.json', 'original-preflight-recovery-02.json', 'package-manifest-02.json'}")
    ast.parse(installer)
    save(DELIVERY / "install_python_ci_tools_02.py", installer.encode())
    request = json.loads((OLD / "install-request.json").read_bytes())
    request["args"] = ["-I", "-B", "-c", installer]
    assert "stdin" in request
    request["stdin"] = encoded
    request["idempotency_key"] = "hepta-r28-python-ci-tools-install-20261105-02"
    save(DELIVERY / "install-request-02.json", json_body(request))
    request = json.loads((OLD / "ci-request.json").read_bytes())
    root = "/home/qian/hepta-runtime-optimization-20261105-r28"
    request["args"] = ["-I", "-B", root + "/python-ci-tools-02/launch_python_ci_02.py",
                       "--launcher-sha256", spec["files"]["launch_python_ci_02.py"]["sha256"],
                       "--actual-input-sha256", spec["files"]["actual-python-input-01.json"]["sha256"],
                       "--recovery-input-sha256", spec["files"]["original-preflight-recovery-02.json"]["sha256"]]
    request["idempotency_key"] = "hepta-r28-python-ci-20261105-02"
    save(DELIVERY / "ci-request-02.json", json_body(request))
    diff = "".join(difflib.unified_diff(old.splitlines(True), source.splitlines(True),
                  fromfile="original/launch_python_ci_01.py", tofile="fresh/launch_python_ci_02.py"))
    save(DELIVERY / "launcher-correction-02.patch", diff.encode())
    diff = "".join(difflib.unified_diff(old_installer.splitlines(True), installer.splitlines(True),
                  fromfile="original/install_python_ci_tools_01.py", tofile="fresh/install_python_ci_tools_02.py"))
    save(DELIVERY / "installer-correction-02.patch", diff.encode())
    receipt = {"schema": "hepta-r28-python-ci-recovery-delivery/v1", "passed": True,
               "originals": original_inventory, "actual_qualification_pins": spec["actual_pins"],
               "source_exception_count": 2, "source_or_permissions_modified": False,
               "runner_and_18_commands_modified": False, "host_operations_executed": False,
               "new_ci_success_inferred": False, "files": {str(path.relative_to(DELIVERY)): identity(path.read_bytes())
                   for path in sorted(DELIVERY.rglob("*")) if path.is_file()}}
    save(DELIVERY / "generation-receipt-02.json", json_body(receipt))
    print(json.dumps({"passed": True, "delivery": str(DELIVERY), "launcher": spec["files"]["launch_python_ci_02.py"],
                      "archive": spec["archive"], "recovery_input": spec["files"]["original-preflight-recovery-02.json"]}, sort_keys=True))


if __name__ == "__main__":
    main()
