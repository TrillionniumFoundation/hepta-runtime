def verify_r28_candidate_preparation(preparation, terminal, job_id, qualified, tests):
    """Verify the actual new cache-only R28 qualification; no future success is inferred."""
    need(isinstance(job_id, str) and re.fullmatch(r"[0-9a-f]{11,16}-[0-9a-f]{4}-[0-9a-f]{4}", job_id)
         and job_id not in {"1a1aa7fa690-fc05-43af", "1a1aaa6552d-fc05-459f", "1a1ab4cb0fc-fc05-4c3c",
                            "1a1ac274e49-fc05-5286", "1a1ac456b07-fc05-532a"},
         "the actual new R28 qualification job is required")
    need(terminal.get("job_id") == job_id and terminal.get("state") == "succeeded"
         and type(terminal.get("exit_code")) is int and terminal["exit_code"] == 0
         and all(terminal.get(key) is False for key in ("automatic_retry", "timed_out", "cancelled"))
         and all(terminal.get(key) is True for key in ("output_complete", "output_durable", "terminal_publication_confirmed"))
         and type(terminal.get("terminal_publication_protocol")) is int and terminal["terminal_publication_protocol"] == 1
         and terminal.get("log_synced") == {"stdout": True, "stderr": True}
         and terminal.get("log_errors") == {"stdout": None, "stderr": None}
         and terminal.get("log_truncated") == {"stdout": False, "stderr": False},
         "original R28 qualification has no complete successful native terminal proof")
    for stream in ("stdout", "stderr"):
        counts = terminal["log_bytes"][stream]
        need(set(counts) == {"seen", "stored"} and all(type(value) is int and value >= 0 for value in counts.values())
             and counts["seen"] == counts["stored"], "qualification native log byte custody differs")
    need(preparation["schema"] == "hepta-r28-qualified-parent-preparation/v1"
         and preparation["selected_proposal"] == "cache only" and preparation.get("optional_pidfd_selected") is False
         and preparation.get("finished_utc")
         and all(preparation.get(key) is True for key in ("passed", "candidate_qualified", "parent_source_qualified",
             "parent_lifecycle_rejection_preserved", "parent_inputs_unchanged"))
         and all(preparation.get(key) is False for key in ("candidate_adopted", "parent_candidate_adopted",
             "production_services_modified", "shared_hardlinks_created")), "actual R28 preparation is incomplete")
    need(preparation["source"] == str(SOURCE) and preparation["target"] == str(ROOT / "target-build")
         and preparation["qualification_output"] == str(CANDIDATE_DIR)
         and preparation["launcher"] == {"path": "/home/qian/hepta-runtime-optimization-20261105-r25/tools/prepare_and_qualify_r28_02.py",
             "bytes": 30059, "sha256": "6bef1776c36294d05a3796b2b4e3c79a07b15ed69122e3a2685705bfeb031239"}
         and preparation["input"] == {"path": "/home/qian/hepta-runtime-optimization-20261105-r25/tools/r28-qualification-02-input.json",
             "bytes": 82496, "sha256": "9173851d84e44421531df32ae2dcad9fd89a707664b2d7b8853965df2f24d3ae"},
         "R28 qualification launcher, input or private paths differ")
    # These are original negative outcomes and the actual read-only space observation.
    # They remain negative; no cleanup or successful inventory is inferred.
    preserved_admission = {'admission_absent_paths': ['/home/qian/hepta-runtime-optimization-20261105-r28/source',
                            '/home/qian/hepta-runtime-optimization-20261105-r28/target-build',
                            '/home/qian/hepta-runtime-optimization-20261105-r28/qualification-01',
                            '/home/qian/hepta-runtime-optimization-20261105-r28/preparation-02.json',
                            '/home/qian/hepta-runtime-optimization-20261105-r28/qualification-input-02.json',
                            '/home/qian/hepta-runtime-optimization-20261105-r28/qualification-terminal-status-02.json'],
 'cache_retirement_executed_by_this_qualifier': False,
 'cleanup_executed': False,
 'cleanup_operation': None,
 'original_admission_failure_preserved': True,
 'original_candidate_input': {'bytes': 34557,
                              'path': '/home/qian/hepta-runtime-optimization-20261105-r28/qualification-input-01.json',
                              'sha256': '0837e858fddf7df95229a5dac1dafdf6d904800caad46cb238ba18ecfaa93299'},
 'original_failed_admission': {'exit_code': 1,
                               'job_id': '1a1ac274e49-fc05-5286',
                               'label': 'original_failed_admission',
                               'native_read': {'bytes': 723,
                                               'sha256': '5a0beef68de943554f08936dacec1a66c4b8e2af66f6c7ea9aa9387cc852e35a'},
                               'original_complete_streams_proved': True,
                               'state': 'failed',
                               'stderr': {'bytes': 0,
                                          'sha256': 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855'},
                               'stdout': {'bytes': 131,
                                          'sha256': '3613580074731c44ad27d2687ec2e8c177fd81eef7d9b2148d0b8ef10df886fc'},
                               'terminal': {'bytes': 726,
                                            'sha256': '8dee0438ff40dc85288ff6d9ff6da9dfcdfc36092bbc12995bd99018f3d00d31'}},
 'original_failed_admission_inputs_unchanged': True,
 'original_native_read': {'bytes': 723,
                          'path': '/home/qian/hepta-runtime-optimization-20261105-r28/qualification-native-read-01.json',
                          'sha256': '5a0beef68de943554f08936dacec1a66c4b8e2af66f6c7ea9aa9387cc852e35a'},
 'original_native_terminal': {'bytes': 726,
                              'path': '/home/qian/hepta-runtime-optimization-20261105-r28/qualification-terminal-status-01.json',
                              'sha256': '8dee0438ff40dc85288ff6d9ff6da9dfcdfc36092bbc12995bd99018f3d00d31'},
 'original_preparation': {'bytes': 4671,
                          'path': '/home/qian/hepta-runtime-optimization-20261105-r28/preparation-01.json',
                          'sha256': 'abc26b3d49c2e57b608fe3aba792708e80de95340c1c8c210dced2844953fade'},
 'space_recovery_mode': 'observed_space_sufficient_no_cleanup',
 'space_recovery_observation': {'all_same_owner_reference_channels_inspected': False,
                                'available_bytes': 7478648832,
                                'cleanup_executed': False,
                                'cleanup_operation': None,
                                'copy_cache_bytes': 3080991421,
                                'excess_over_required_bytes': 1176431939,
                                'inventory_overall_passed': False,
                                'old_cache_absence_cause_inferred': False,
                                'original_inventory_native_exit_code': 1,
                                'original_inventory_native_state': 'failed',
                                'process_reference_scans_complete': False,
                                'required_headroom_bytes': 3221225472},
 'space_recovery_proofs': {'readonly_inventory': {'exit_code': 1,
                                                  'job_id': '1a1ac456b07-fc05-532a',
                                                  'label': 'readonly_inventory',
                                                  'native_read': {'bytes': 42578,
                                                                  'sha256': 'd232070f29ce310dd2f304f75bc661ebf937582f0b1e179cc94dd88e80e1dcb1'},
                                                  'original_complete_streams_proved': True,
                                                  'state': 'failed',
                                                  'stderr': {'bytes': 0,
                                                             'sha256': 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855'},
                                                  'stdout': {'bytes': 13686,
                                                             'sha256': '3c2e43bbaeb2914c6372653ba1ea79d196af451aed75a9cb9ce4fac313769dda'},
                                                  'terminal': {'bytes': 730,
                                                               'sha256': 'c06d88c67b142ad33bcab37cf4cd51d9235dd14cc0e046927cf5aa53429d365b'}}},
 'unchanged_disk_reserve_bytes': 3221225472}
    for name, expected_value in preserved_admission.items():
        need(preparation.get(name) == expected_value, "R28 preserved admission evidence differs: " + name)
    need(all(preparation.get(name) is True for name in
             ("original_admission_failure_preserved", "original_failed_admission_inputs_unchanged"))
         and all(preparation.get(name) is False for name in
                 ("cache_retirement_executed_by_this_qualifier", "cleanup_executed"))
         and preparation.get("cleanup_operation") is None, "R28 original failures or no-cleanup scope changed")
    original_names = ("original_preparation", "original_candidate_input", "original_native_terminal", "original_native_read")
    originals = {preparation[name]["path"]: preparation[name] for name in original_names}
    descriptors = preparation.get("original_file_identities")
    descriptor_keys = {"st_dev", "st_ino", "st_mode", "st_uid", "st_nlink", "st_size", "st_mtime_ns", "st_ctime_ns"}
    need(isinstance(descriptors, dict) and set(descriptors) == set(originals), "four original file identities required")
    for path, pin in originals.items():
        descriptor = descriptors[path]
        need(isinstance(descriptor, dict) and set(descriptor) == descriptor_keys
             and all(type(value) is int and value >= 0 for value in descriptor.values())
             and descriptor["st_ino"] > 0 and descriptor["st_uid"] == 1000 and descriptor["st_nlink"] == 1
             and descriptor["st_size"] == pin["bytes"] and descriptor["st_mode"] & 0o170000 == 0o100000
             and not descriptor["st_mode"] & 0o6000, "original preserved file descriptor differs: " + path)
        need(preparation["bound_parent_inputs"].get(path) == pin, "original preserved file final byte binding differs: " + path)
    known_original_descriptors = {
        '/home/qian/hepta-runtime-optimization-20261105-r28/preparation-01.json': {'st_ctime_ns': 1793889622435153369, 'st_dev': 2053, 'st_ino': 2259040, 'st_mode': 33152, 'st_mtime_ns': 1793889622435153369, 'st_nlink': 1, 'st_size': 4671, 'st_uid': 1000},
        '/home/qian/hepta-runtime-optimization-20261105-r28/qualification-input-01.json': {'st_ctime_ns': 1793889621996152717, 'st_dev': 2053, 'st_ino': 2259039, 'st_mode': 33152, 'st_mtime_ns': 1793889621996152717, 'st_nlink': 1, 'st_size': 34557, 'st_uid': 1000},
    }
    need(all(descriptors[path] == expected_value for path, expected_value in known_original_descriptors.items()),
         "original preparation/input descriptor identity differs from the actual inventory")
    need(type(preparation["cache_bytes"]) is int and preparation["cache_bytes"] > 0
         and type(preparation["disk_available_before_bytes"]) is int
         and preparation["disk_available_before_bytes"] >= preparation["cache_bytes"] + 3221225472,
         "actual R28 cache admission did not retain the original 3 GiB reserve")
    need(type(preparation["qualification_returncode"]) is int and preparation["qualification_returncode"] == 0
         and type(preparation["automatic_test_retries"]) is int and preparation["automatic_test_retries"] == 0,
         "R28 qualification did not finish once with exit zero")
    expected_changes = [{'path': 'src/mcp/runtime/jobs.rs',
  'before': {'bytes': 186504, 'sha256': '8a80623ccf9131e520ed5f25647200bd2086e4718b892eed90c1530a5ccb9283'},
  'after': {'bytes': 186541, 'sha256': '061c2576e3c1dd8a1e4f5bfd7d3498f7cc4141d6577d53365a9a4738c7980af6'}},
 {'path': 'src/mcp/runtime/ssh.rs',
  'before': {'bytes': 18943, 'sha256': '0c0bf93da7d8d391b79d026544dc7ff71974bd1eabb06e5fe319892174843189'},
  'after': {'bytes': 19820, 'sha256': 'b674dfcb60bc57c46a08f1ab1f424a8aadcdb2078abdcfdff30f71632e807b3d'}},
 {'path': 'src/mcp/runtime/ssh_tests.rs',
  'before': {'bytes': 4652, 'sha256': '39dacf3f7839b7a013b24b2ec63bd9cf7b51599ebaebc1e5e074cfb98ae79893'},
  'after': {'bytes': 4931, 'sha256': '98f18f6cd89776b7589a9864224683d49f4b0cb663467475aa721c52dfff0a57'}}]
    need(preparation["source_changes"] == expected_changes, "qualified selection is not the exact three-file cache-only change")
    before = preparation["source_before"]
    expected = dict(before)
    changed_paths = {change["path"] for change in expected_changes}
    need(len(before) == 221 and len(changed_paths) == 3, "R28 parent source-map or change count differs")
    for change in expected_changes:
        need(before[change["path"]] == change["before"]["sha256"], "R28 exact qualified parent preimage differs")
        expected[change["path"]] = change["after"]["sha256"]
    need(preparation["candidate_compilation_inputs"] == expected, "R28 pre-format source map differs")
    stages = ["format", "fmt-check", "harness-tests", "clippy", "test-build", "isolated-tests", "audit-isolated-tests", "release"]
    need(qualified["schema"] == "hepta-x230-composed-qualification/v1" and qualified["qualified"] is True
         and qualified.get("finished_utc") and qualified["source"] == str(SOURCE)
         and qualified["jobs"] == 2 and qualified["service_changes"] is False
         and type(qualified["automatic_test_retries"]) is int and qualified["automatic_test_retries"] == 0
         and [row["name"] for row in qualified["stages"]] == stages
         and all(type(row["returncode"]) is int and row["returncode"] == 0 for row in qualified["stages"]),
         "all eight original R28 qualification stages must pass")
    need(qualified["source_input"] == expected and qualified["source_tested"] == qualified["source_after"] == preparation["source_tested"]
         and set(qualified["source_after"]) == set(expected)
         and all(qualified["source_after"][name] == value for name, value in expected.items() if name not in changed_paths),
         "actual formatted R28 source differs from its qualified preparation")
    need(preparation["formatter_changed_paths"] == [name for name in expected if qualified["source_after"][name] != expected[name]]
         and qualified["harness_before"] == qualified["harness_after"] == preparation["harness_before"]
         and len(qualified["harness_after"]) == 19, "qualification formatter or original harness binding differs")
    counts = ("passed", "failed", "ignored", "selected", "retries")
    need(all(type(tests[key]) is int for key in counts)
         and [tests[key] for key in counts] == [1653, 0, 34, 1687, 0]
         and preparation["tests"] == tests, "original full R28 isolated test result is incomplete")
    return {"passed": True, "original_job_id": job_id, "selected_proposal": "cache only", "optional_pidfd_selected": False,
            "qualified_source_files": 221, "harness_files": 19, "stages": stages,
            "tests": {key: tests[key] for key in counts}, "candidate_adopted": False,
            "qualified_parent_R26_lifecycle_rejection_preserved": True,
            "original_failed_admission_preserved": True, "original_failed_inventory_preserved": True,
            "space_recovery_mode": "observed_space_sufficient_no_cleanup", "cleanup_executed": False}
