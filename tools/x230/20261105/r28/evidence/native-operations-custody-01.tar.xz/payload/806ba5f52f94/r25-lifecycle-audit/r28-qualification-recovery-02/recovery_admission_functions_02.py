"""Narrow original-failure and actual-space-proof admission; no cleanup operations."""

def byte_identity(body):
    return {'bytes': len(body), 'sha256': hashlib.sha256(body).hexdigest()}


def original_evidence(path, expected_sha):
    assert path.resolve(strict=True) == path
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_CLOEXEC | os.O_NONBLOCK)
    try:
        before = os.fstat(fd)
        assert stat.S_ISREG(before.st_mode) and before.st_uid == os.geteuid() and before.st_nlink == 1
        assert 0 < before.st_size <= 65536 and not before.st_mode & (stat.S_ISUID | stat.S_ISGID)
        with os.fdopen(os.dup(fd), 'rb') as stream:
            body = stream.read(before.st_size + 1)
        assert len(body) == before.st_size and stamp(before) == stamp(os.fstat(fd)) == stamp(path.lstat())
        identity = {'path': str(path), **byte_identity(body)}
        assert identity['sha256'] == expected_sha
        fields = ('st_dev', 'st_ino', 'st_mode', 'st_uid', 'st_nlink', 'st_size', 'st_mtime_ns', 'st_ctime_ns')
        return identity, body, {key: getattr(before, key) for key in fields}
    finally:
        os.close(fd)


def original_operation(label, supplied, expected, state='succeeded', exit_code=0):
    terminal_raw = supplied['native_terminal_text'].encode('utf-8')
    read_raw = supplied['native_read_text'].encode('utf-8')
    assert byte_identity(terminal_raw) == expected['terminal']
    assert byte_identity(read_raw) == expected['read']
    check_terminal(terminal_raw, expected['job_id'], state=state, exit_code=exit_code)
    terminal, dto = json.loads(terminal_raw), json.loads(read_raw)
    assert dto['job_id'] == expected['job_id'] and dto['audit_recorded'] is True
    streams = {}
    for name in ('stdout', 'stderr'):
        row = dto[name]
        raw = bytes.fromhex(row['bytes_hex'])
        assert row['offset'] == 0 and row['next_offset'] == row['size'] == len(raw)
        assert row['eof'] is True and row['text'].encode('utf-8') == raw
        assert terminal['log_bytes'][name] == {'seen': len(raw), 'stored': len(raw)}
        streams[name] = raw
    assert streams['stderr'] == b''
    assert byte_identity(streams['stdout']) == expected['stdout']
    report = json.loads(streams['stdout'])
    return report, {'label': label, 'job_id': expected['job_id'], 'state': state,
                    'exit_code': exit_code, 'terminal': byte_identity(terminal_raw),
                    'native_read': byte_identity(read_raw), 'stdout': byte_identity(streams['stdout']),
                    'stderr': byte_identity(streams['stderr']), 'original_complete_streams_proved': True}


def verify_recovery_admission(payload):
    # The original readonly inventory failed because two old caches were
    # already absent. Its positive space/root facts are used without changing
    # its failed outcome, incomplete process-reference scans or unknown cause.
    assert isinstance(SPACE_RECOVERY_SPEC, dict), 'actual space recovery is not bound; no qualification admission'
    assert set(SPACE_RECOVERY_SPEC) == {'readonly_inventory'}
    recovery = payload.pop('preserved_admission_recovery')
    assert recovery['schema'] == 'hepta-r28-preserved-admission-recovery/v1'
    assert recovery['mode'] == 'observed_space_sufficient_no_cleanup'
    assert recovery['cleanup_executed'] is False and recovery['cleanup_operation'] is None
    assert set(recovery['space_recovery']) == set(SPACE_RECOVERY_SPEC)
    assert ROOT.resolve(strict=True) == ROOT
    root_info = ROOT.lstat()
    assert stat.S_ISDIR(root_info.st_mode) and root_info.st_uid == os.geteuid()
    assert stat.S_IMODE(root_info.st_mode) == 0o700
    failed_identity, failed_raw, failed_descriptor = original_evidence(ROOT / 'preparation-01.json',
        'abc26b3d49c2e57b608fe3aba792708e80de95340c1c8c210dced2844953fade')
    assert failed_identity['bytes'] == 4671
    original_input_identity, original_input_raw, input_descriptor = original_evidence(ROOT / 'qualification-input-01.json',
        '0837e858fddf7df95229a5dac1dafdf6d904800caad46cb238ba18ecfaa93299')
    assert original_input_identity['bytes'] == 34557 and encoded(payload) == original_input_raw
    failed = json.loads(failed_raw)
    assert failed['schema'] == 'hepta-r28-qualified-parent-preparation/v1'
    assert failed['passed'] is False and failed['candidate_qualified'] is False and failed['candidate_adopted'] is False
    assert failed['parent_source_qualified'] is True and failed['parent_lifecycle_rejection_preserved'] is True
    assert failed['selected_proposal'] == 'cache only' and failed['optional_pidfd_selected'] is False
    assert failed['error'] == 'AssertionError: (6285365248, 3080991421)'
    assert 'line 217, in main' in failed['error_trace'] and failed['finished_utc']
    assert not any(name in failed for name in ('qualification_argv', 'qualification_returncode',
        'source', 'target', 'qualification_output', 'source_before', 'candidate_compilation_inputs', 'source_changes', 'tests'))
    terminal_identity, terminal_raw, terminal_descriptor = original_evidence(ROOT / 'qualification-terminal-status-01.json',
        '8dee0438ff40dc85288ff6d9ff6da9dfcdfc36092bbc12995bd99018f3d00d31')
    native_read_identity, native_read_raw, read_descriptor = original_evidence(ROOT / 'qualification-native-read-01.json',
        '5a0beef68de943554f08936dacec1a66c4b8e2af66f6c7ea9aa9387cc852e35a')
    assert recovery['original_failed_operation'] == {'native_terminal_text': terminal_raw.decode('utf-8'),
                                                    'native_read_text': native_read_raw.decode('utf-8')}
    original_footer, original_proof = original_operation('original_failed_admission',
        recovery['original_failed_operation'], {
            'job_id': '1a1ac274e49-fc05-5286',
            'terminal': {'bytes': 726, 'sha256': '8dee0438ff40dc85288ff6d9ff6da9dfcdfc36092bbc12995bd99018f3d00d31'},
            'read': {'bytes': 723, 'sha256': '5a0beef68de943554f08936dacec1a66c4b8e2af66f6c7ea9aa9387cc852e35a'},
            'stdout': {'bytes': 131, 'sha256': '3613580074731c44ad27d2687ec2e8c177fd81eef7d9b2148d0b8ef10df886fc'}},
        state='failed', exit_code=1)
    assert original_footer == {'preparation_and_qualification_passed': False,
        'candidate_qualified': False, 'error': failed['error']}
    space_proofs = {}
    for label in ('readonly_inventory',):
        actual, proof = original_operation(label, recovery['space_recovery'][label], SPACE_RECOVERY_SPEC[label],
                                          state='failed', exit_code=1)
        assert actual['schema'] == SPACE_RECOVERY_SPEC[label]['report_schema']
        assert SPACE_RECOVERY_SPEC[label]['root_reviewed_for_this_admission'] is True
        if label == 'readonly_inventory':
            assert actual['schema'] == 'hepta-r28-cache-readonly-inventory/v1'
            assert actual['passed'] is False and actual['read_only'] is True
            assert actual['files_created_or_deleted'] == 0
            assert actual['deletion_authorized_by_this_report'] is False
            original_root = actual['actual_root28']
            assert original_root['path'] == str(ROOT) and original_root['owner'] == os.geteuid()
            assert original_root['realpath_matches_literal'] is True
            assert original_root['all_three_workload_paths_absent'] is True
            assert original_root['absence'] == [{'path': str(path), 'exists': False, 'identity': None}
                                                for path in (SOURCE, TARGET, OUTPUT)]
            for field in ('st_dev', 'st_ino', 'st_uid', 'st_mode'):
                assert original_root['identity'][field] == getattr(root_info, field)
            for field, identity, descriptor in (
                    ('preparation01', failed_identity, failed_descriptor),
                    ('qualification_input01', original_input_identity, input_descriptor)):
                assert original_root[field] == {**identity, 'identity': descriptor}
            old_caches = actual['cache_inventory']
            assert set(old_caches) == {'candidate_r25', 'candidate_private05', 'protected_r26'}
            for name, path in (
                    ('candidate_r25', '/home/qian/hepta-runtime-optimization-20261105-r25/target-build-02'),
                    ('candidate_private05', '/home/qian/hepta-runtime-optimization-20261105-r25/mechanism-diagnostic-05/target-build')):
                row = old_caches[name]
                assert row['path'] == path and row['exists_at_initial_root_check'] is False
                assert row['complete'] is False and row['passes'] == [] and row['deletion_allowed'] is False
            protected = old_caches['protected_r26']
            assert protected['path'] == str(PARENT / 'target-build') and protected['protected'] is True
            assert protected['deletion_allowed'] is False and protected['complete'] is True
            assert protected['metadata_stable_across_two_passes'] is True and len(protected['passes']) == 2
            assert protected['passes'][0]['metadata_sha256'] == protected['passes'][1]['metadata_sha256']
            assert all(row['all_entries_traversed'] is True for row in protected['passes'])
            disk = actual['disk']
            assert disk['unchanged_required_headroom_bytes'] == 3 * 1024**3
            assert disk['original_copy_cache_bytes'] == protected['passes'][0]['counts']['regular_logical_bytes']
            assert disk['available_bytes'] >= disk['original_copy_cache_bytes'] + 3 * 1024**3
            assert actual['deletion_eligibility_established'] is False
            assert actual['point_in_time_metadata_only_not_a_cleanup_receipt'] is True
            assert actual['process_reference_scan_incompleteness_is_preserved_not_converted_to_no_reference'] is True
            assert len(actual['process_reference_scans']) == 2
            assert all(row['complete'] is False and row['all_same_owner_live_process_channels_inspected'] is False
                       for row in actual['process_reference_scans'])
            observed_space = {'available_bytes': disk['available_bytes'],
                'copy_cache_bytes': disk['original_copy_cache_bytes'],
                'required_headroom_bytes': disk['unchanged_required_headroom_bytes'],
                'excess_over_required_bytes': disk['available_bytes'] - disk['original_copy_cache_bytes'] - 3 * 1024**3,
                'inventory_overall_passed': False, 'original_inventory_native_state': 'failed',
                'original_inventory_native_exit_code': 1, 'process_reference_scans_complete': False,
                'all_same_owner_reference_channels_inspected': False,
                'old_cache_absence_cause_inferred': False, 'cleanup_executed': False, 'cleanup_operation': None}
        # Full original failed inventory and unknown reference records remain
        # in input02. No permission to delete a cache is inferred or exercised.
        space_proofs[label] = proof
    absent = [SOURCE, TARGET, OUTPUT, ROOT / 'preparation-02.json', ROOT / 'qualification-input-02.json',
              ROOT / 'qualification-terminal-status-02.json']
    assert all(not os.path.lexists(path) for path in absent), 'first actual source/cache/qualification paths and new receipts must be absent'
    return {'original_admission_failure_preserved': True,
            'original_failed_admission': original_proof,
            'original_preparation': failed_identity, 'original_candidate_input': original_input_identity,
            'original_native_terminal': terminal_identity, 'original_native_read': native_read_identity,
            'original_file_identities': {failed_identity['path']: failed_descriptor,
                original_input_identity['path']: input_descriptor, terminal_identity['path']: terminal_descriptor,
                native_read_identity['path']: read_descriptor},
            'space_recovery_proofs': space_proofs,
            'space_recovery_mode': 'observed_space_sufficient_no_cleanup',
            'space_recovery_observation': observed_space,
            'cleanup_executed': False, 'cleanup_operation': None,
            'admission_absent_paths': [str(path) for path in absent],
            'unchanged_disk_reserve_bytes': 3 * 1024**3,
            'cache_retirement_executed_by_this_qualifier': False}
