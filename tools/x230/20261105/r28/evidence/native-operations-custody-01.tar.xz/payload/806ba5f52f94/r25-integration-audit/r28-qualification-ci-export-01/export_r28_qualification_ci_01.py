#!/usr/bin/env python3
# Copyright 2026 TrillionniumFoundation; SPDX-License-Identifier: Apache-2.0
"""Fixed R28 qualification/CI originals; XZ transport does not change any outcome."""
import argparse
import datetime
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import stat
import sys
import traceback

ROOT = Path("/home/qian/hepta-runtime-optimization-20261105-r28")
STAGE_ROOT = Path("/home/qian/hepta-runtime-optimization-20261105-r25")
SOURCE = ROOT / "source"
OUT = ROOT / "qualification-ci-evidence-01"
EXPORTER = STAGE_ROOT / "tools/export_r28_qualification_ci_01.py"
HELPER = STAGE_ROOT / "tools/r28_qualification_ci_stable_xz_01.py"
INPUT = STAGE_ROOT / "tools/r28-qualification-ci-export-input-01.json"
HELPER_SHA256 = "8b7aa7ef3b3772da13ea4f7009d8c478e0c92bc207d65db3f45c23453097d7a2"
ARCHIVE_NAME = "qualification-ci-01.tar.xz"
HEX = re.compile(r"[0-9a-f]{64}\Z")
JOB = re.compile(r"[0-9a-f]+-[0-9a-f]+-[0-9a-f]+\Z")
NATIVE_TERMINAL_STATES = {"succeeded", "failed", "cancelled", "timed_out", "effect_unknown"}
PRIVATE_NAMES = {"ssh_config", "known_hosts", "profile.json", "runtime.json"}
STAGES = ("qualification_failed01", "qualification02", "rust_ci01", "python_ci01", "python_ci02")
KNOWN_JOBS = {
    "qualification_failed01": "1a1ac274e49-fc05-5286",
    "qualification02": "1a1ac5d5a29-fc05-53d9",
    "rust_ci01": "1a1ac8bfc0c-fc05-552c",
    "python_ci01": "1a1ac97d8cb-fc05-55a2",
}
NATIVE_PATHS = {
    "qualification_failed01": ROOT / "qualification-terminal-status-01.json",
    "qualification02": ROOT / "qualification-terminal-status-02.json",
    "rust_ci01": ROOT / "rust-ci-terminal-status-01.json",
    "python_ci01": ROOT / "python-ci-terminal-status-01.json",
    "python_ci02": ROOT / "python-ci-terminal-status-02.json",
}
REPORT_PATHS = {
    "qualification_failed01": ROOT / "preparation-01.json",
    "qualification02": ROOT / "qualification-01/report.json",
    "rust_ci01": ROOT / "rust-ci-01/report.json",
    "python_ci01": ROOT / "python-ci-launch-01/receipt.json",
    "python_ci02": ROOT / "python-ci-launch-02/receipt.json",
}
REPORT_SCHEMAS = {
    "qualification_failed01": "hepta-r28-qualified-parent-preparation/v1",
    "qualification02": "hepta-x230-composed-qualification/v1",
    "rust_ci01": "hepta-r28-external-rust-ci/v1",
    "python_ci01": "hepta-r28-python-ci-one-time-launch-v1",
    "python_ci02": "hepta-r28-python-ci-one-time-launch-v1",
}
QUALIFICATION_STAGES = ("format", "fmt-check", "harness-tests", "clippy", "test-build", "isolated-tests", "audit-isolated-tests", "release")
DIRECTORIES = {
    "qualification": ROOT / "qualification-01",
    "rust-ci": ROOT / "rust-ci-01",
    "rust-ci-tools": ROOT / "rust-ci-tools-01",
    "python-ci01": ROOT / "python-ci-01",
    "python-launch01": ROOT / "python-ci-launch-01",
    "python-tools01": ROOT / "python-ci-tools-01",
    "python-ci02": ROOT / "python-ci-02",
    "python-launch02": ROOT / "python-ci-launch-02",
    "python-tools02": ROOT / "python-ci-tools-02",
    "published-python-inputs": STAGE_ROOT / "ci-gates",
}
OPTIONAL_TREES = {"python-ci01", "python-ci02", "python-launch02", "python-tools02"}
ROOT_FILES = ("preparation-01.json", "preparation-02.json", "qualification-input-01.json",
              "qualification-input-02.json", "qualification-native-read-01.json",
              "rust-ci-plan-01.json", "rust-ci-tools-install-01.json",
              "python-ci-tools-install-01.json", "python-ci-tools-install-02.json")
OPTIONAL_ROOT_FILES = {"python-ci-tools-install-02.json"}
QUALIFIER_ASSETS = (
    STAGE_ROOT / "tools/prepare_and_qualify_r28_01.py",
    STAGE_ROOT / "tools/r28-qualification-01-input.json",
    STAGE_ROOT / "tools/prepare_and_qualify_r28_02.py",
    STAGE_ROOT / "tools/r28-qualification-02-input.json",
    STAGE_ROOT / "tool-package-install-01.json",
    STAGE_ROOT / "ci-toolchain/nextest-0.9.137/receipt.json",
)

def need(value, reason):
    if not value:
        raise RuntimeError(reason)


def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def descriptor(value, expected_path):
    need(isinstance(value, dict) and set(value) == {"path", "bytes", "sha256"}
         and value["path"] == str(expected_path)
         and type(value["bytes"]) is int and 0 <= value["bytes"] <= 16 * 1024**2
         and isinstance(value["sha256"], str) and HEX.fullmatch(value["sha256"]),
         "actual bounded input identity required: " + str(expected_path))
    return value


def validate_terminal(value, job_id):
    """Require an authoritative terminal, while preserving negative original fields."""
    need(value.get("job_id") == job_id and value.get("state") in NATIVE_TERMINAL_STATES,
         "same original authoritative native terminal required")
    need(value.get("terminal_publication_confirmed") is True
         and type(value.get("terminal_publication_protocol")) is int
         and value["terminal_publication_protocol"] == 1
         and value.get("automatic_retry") is False,
         "unresolved/retried original terminal cannot authorize stable evidence capture")
    need((type(value.get("exit_code")) is int or value.get("exit_code") is None)
         and all(type(value.get(key)) is bool for key in ("cancelled", "timed_out", "output_complete", "output_durable")),
         "native outcome fields are missing")
    if value["state"] == "succeeded":
        need(value["exit_code"] == 0 and value["cancelled"] is False and value["timed_out"] is False,
             "successful native state contradicts original flags")
    log_complete = value["output_complete"] and value["output_durable"]
    for stream in ("stdout", "stderr"):
        counts = value["log_bytes"][stream]
        need(type(counts.get("seen")) is int and type(counts.get("stored")) is int
             and 0 <= counts["stored"] <= counts["seen"], "invalid original log byte counts")
        need(type(value["log_synced"][stream]) is bool and type(value["log_truncated"][stream]) is bool
             and (value["log_errors"][stream] is None or isinstance(value["log_errors"][stream], str)),
             "invalid original log metadata")
        log_complete = (log_complete and value["log_synced"][stream]
                        and not value["log_truncated"][stream] and value["log_errors"][stream] is None
                        and counts["stored"] == counts["seen"])
    return {"state": value["state"], "exit_code": value["exit_code"],
            "cancelled": value["cancelled"], "timed_out": value["timed_out"],
            "native_logs_lossless_complete": bool(log_complete), "automatic_retry": False}


def omission_reason(path, group, identity):
    if identity["is_elf"]:
        return "ELF body omitted; complete observed file identity retained"
    if path.name in PRIVATE_NAMES or (path.parent.name == "bin" and path.name in ("ssh", "ssh-original")):
        return "private transport configuration or session wrapper body omitted; identity retained"
    if path.name in ("id_rsa", "id_ed25519", "id_ecdsa", "id_dsa") or path.suffix in (".key", ".pem", ".plist"):
        return "private credential or service configuration body is outside approved export scope"
    if path.name == "cargo-nextest-0.9.137.tar.gz.partial":
        return "verified upstream tool archive body omitted; recorded identity and install receipt retained"
    return None


def load_helper(digest):
    """Only the exact reviewed local helper definitions may be loaded."""
    need(isinstance(digest, str) and HEX.fullmatch(digest) and HELPER.resolve(strict=True) == HELPER,
         "fixed hash-bound archive helper required")
    fd = os.open(HELPER, os.O_RDONLY | os.O_NOFOLLOW | os.O_CLOEXEC | os.O_NONBLOCK)
    try:
        before = os.fstat(fd)
        need(stat.S_ISREG(before.st_mode) and before.st_uid == os.geteuid()
             and before.st_nlink == 1 and before.st_size <= 128 * 1024,
             "unsafe archive helper")
        raw = b""
        while block := os.read(fd, 65536):
            raw += block
            need(len(raw) <= before.st_size, "archive helper grew")
        fields = ("st_dev", "st_ino", "st_uid", "st_mode", "st_nlink", "st_size", "st_mtime_ns", "st_ctime_ns")
        stamp = lambda item: tuple(getattr(item, key) for key in fields)
        need(len(raw) == before.st_size and stamp(before) == stamp(os.fstat(fd)) == stamp(HELPER.lstat())
             and hashlib.sha256(raw).hexdigest() == digest, "archive helper differs")
    finally:
        os.close(fd)
    # Execute the checked in-memory bytes, not a second path read after hashing.
    spec = importlib.util.spec_from_loader("r28_bound_stable_xz_archive", loader=None)
    module = importlib.util.module_from_spec(spec)
    module.__file__ = str(HELPER)
    exec(compile(raw, str(HELPER), "exec"), module.__dict__)
    return module


def validate_input(value):
    need(isinstance(value, dict) and value.get("schema") == "hepta-r28-qualification-ci-export-input/v1"
         and value.get("root") == str(ROOT) and value.get("actual_outcomes_supplied") is True
         and value.get("adoption_decision_made_here") is False
         and value.get("native_raw_companion_required") is True
         and set(value.get("stages", {})) == set(STAGES), "actual fixed R28 outcomes are required")
    for name in STAGES:
        row = value["stages"][name]
        need(isinstance(row, dict) and set(row) == {"executed", "job_id", "native_terminal", "report", "reason"}
             and type(row["executed"]) is bool, "unresolved or unexpected stage declaration: " + name)
        if row["executed"]:
            need(isinstance(row["job_id"], str) and JOB.fullmatch(row["job_id"]), "actual original native job required")
            descriptor(row["native_terminal"], NATIVE_PATHS[name])
            if row["report"] is not None:
                descriptor(row["report"], REPORT_PATHS[name])
                need(row["reason"] is None, "present original report retains its own outcome")
            else:
                need(isinstance(row["reason"], str) and row["reason"].strip(), "missing original report needs a reason")
        else:
            need(name == "python_ci02" and row["job_id"] is row["native_terminal"] is row["report"] is None
                 and isinstance(row["reason"], str) and row["reason"].strip(), "known original operation may not be erased")
        if name in KNOWN_JOBS:
            need(row["executed"] is True and row["job_id"] == KNOWN_JOBS[name], "known original job changed: " + name)
    for key, path in (("preparation", ROOT / "preparation-02.json"),
                      ("source_map", ROOT / "qualification-01/source-map.json")):
        descriptor(value.get(key), path)
    return value["stages"]


def report_projection(value):
    if not isinstance(value, dict):
        return {"object": False, "original_value_type": type(value).__name__}
    keys = ("schema", "passed", "qualified", "finished_utc", "finished_unix", "error", "current_stage",
            "automatic_retries", "automatic_test_retries", "retry_count", "runner_returncode",
            "gates_executed", "failed_gates", "owned_children_closed", "source_inputs_unchanged",
            "original_preflight_failure_preserved", "original_preflight_failure")
    return {"object": True, **{key: value[key] for key in keys if key in value}}


def original_outcome(name, declaration, terminal, original):
    if not declaration["executed"]:
        return {"executed": False, "reason": declaration["reason"], "success_inferred": False}
    native = validate_terminal(terminal, declaration["job_id"])
    projection = report_projection(original)
    finished = (isinstance(original, dict)
                and ((isinstance(original.get("finished_utc"), str) and bool(original["finished_utc"].strip()))
                     or (type(original.get("finished_unix")) in (int, float) and original["finished_unix"] > 0)))
    schema_matches = isinstance(original, dict) and original.get("schema") == REPORT_SCHEMAS[name]
    flag = original.get("qualified" if name == "qualification02" else "passed") if isinstance(original, dict) else None
    positive = (native["state"] == "succeeded" and native["exit_code"] == 0
                and native["native_logs_lossless_complete"] and finished and schema_matches and flag is True)
    return {"executed": True, "job_id": declaration["job_id"], "native_outcome": native,
            "original_report": projection, "original_report_finished": bool(finished),
            "original_report_schema_matches": bool(schema_matches),
            "original_positive_report_and_closed_native": bool(positive),
            "original_report_absence_reason": declaration["reason"]}


def check_original_bindings(get_json, identities, stages):
    """Original producer declarations and full source/log bodies; no tests are rerun."""
    def row(path):
        need(str(path) in identities, "required original body/identity absent: " + str(path))
        return identities[str(path)]
    def same(path, recorded):
        actual = row(path)
        need(actual["sha256"] == recorded["sha256"]
             and ("bytes" not in recorded or actual["bytes"] == recorded["bytes"]),
             "original producer recorded a different file: " + str(path))
    qualification = get_json(ROOT / "qualification-01/report.json")
    preparation = get_json(ROOT / "preparation-02.json")
    source_map = get_json(ROOT / "qualification-01/source-map.json")
    need(isinstance(qualification, dict) and qualification.get("qualified") is True
         and qualification.get("schema") == REPORT_SCHEMAS["qualification02"]
         and qualification.get("source") == str(SOURCE)
         and qualification.get("automatic_test_retries") == 0
         and [s["name"] for s in qualification["stages"]] == list(QUALIFICATION_STAGES)
         and all(s["returncode"] == 0 for s in qualification["stages"]), "original full qualification differs")
    need(isinstance(source_map, dict) and len(source_map) == 221
         and qualification["source_tested"] == qualification["source_after"] == source_map
         and preparation["source_tested"] == source_map
         and preparation["passed"] is True and preparation["candidate_qualified"] is True
         and preparation["selected_proposal"] == "cache only" and preparation["optional_pidfd_selected"] is False
         and preparation["parent_lifecycle_rejection_preserved"] is True
         and preparation["original_admission_failure_preserved"] is True,
         "original qualification/preparation/source lineage differs")
    for name, expected in source_map.items():
        need(not Path(name).is_absolute() and ".." not in Path(name).parts, "unsafe original compiler input")
        same(SOURCE / name, {"sha256": expected})
    harness = qualification["harness_before"]
    need(len(harness) == 19 and qualification["harness_after"] == harness == preparation["harness_before"],
         "original 19-file qualification harness differs")
    for name, expected in harness.items():
        need(Path(name).name == name, "unsafe harness name")
        same(SOURCE / "tools/x230/20261028" / name, {"sha256": expected})
    for stage in qualification["stages"]:
        out = "cargo-no-run.jsonl" if stage["name"] == "test-build" else stage["name"] + ".stdout"
        same(ROOT / "qualification-01" / out, {"sha256": stage["stdout_sha256"]})
        same(ROOT / "qualification-01" / (stage["name"] + ".stderr"), {"sha256": stage["stderr_sha256"]})
    for name, record in qualification["binaries"].items():
        need(record["path"] == str(ROOT / "qualification-01" / name), "qualified ELF path differs")
        same(Path(record["path"]), record)
        need(row(Path(record["path"]))["is_elf"] is True, "qualified executable is not an ELF")
    summary = get_json(ROOT / "qualification-01/isolated-tests/summary.json")
    audit = get_json(ROOT / "qualification-01/isolated-tests.audit.json")
    need(summary["success"] is True and audit["success"] is True
         and summary["passed"] == audit["passed"] == 1653
         and summary["failed"] == audit["failed"] == 0
         and summary["ignored"] == audit["ignored"] == 34
         and summary["selected"] == audit["selected"] == 1687 and summary["retries"] == 0,
         "original complete isolated-test counts differ")
    isolated = ROOT / "qualification-01/isolated-tests"
    for filename, expected_sha in audit["input_sha256"].items():
        need(Path(filename).name == filename, "unsafe original isolated input name")
        same(isolated / filename, {"sha256": expected_sha})
    for command in audit["commands"]:
        filename = command["stdout_gzip"]
        need(Path(filename).name == filename and filename.count(".stdout.") == 1,
             "unsafe or unrecognized original case-log filename")
        same(isolated / filename, {"sha256": command["stdout"]["gzip_sha256"]})
        same(isolated / filename.replace(".stdout.", ".stderr."),
             {"sha256": command["stderr"]["gzip_sha256"]})
    for binary in audit["binaries"]:
        path = Path(binary["path"])
        need(path.parent == ROOT / "qualification-01/test-binaries"
             and binary["recorded_before_sha256"] == binary["current_after_sha256"],
             "original retained test ELF path/hash differs")
        same(path, {"sha256": binary["current_after_sha256"]})
        need(row(path)["is_elf"] is True, "original retained test executable is not ELF")
    for prep in (get_json(ROOT / "preparation-01.json"), preparation):
        for key in ("launcher", "input"):
            original = prep[key]
            need(Path(original["path"]) in QUALIFIER_ASSETS, "original qualifier asset escaped scope")
            same(Path(original["path"]), original)
    rust = get_json(ROOT / "rust-ci-01/report.json")
    need(rust["schema"] == REPORT_SCHEMAS["rust_ci01"] and rust["passed"] is True
         and rust["automatic_retries"] == 0 and rust["owned_children_closed"] is True
         and rust["source_inputs_unchanged"] is True and len(rust["stages"]) == 6,
         "original exact Rust CI result differs")
    for name in ("launcher", "materializer", "auditor", "plan"):
        recorded = rust[name]
        path = Path(recorded["path"])
        need(path.parent == ROOT / "rust-ci-tools-01" or path == ROOT / "rust-ci-plan-01.json",
             "original Rust CI tool escaped fixed scope")
        same(path, recorded)
    for stage in rust["stages"]:
        need(stage["returncode"] == 0 and stage["passed"] is True, "original Rust CI stage failed")
        for stream in ("stdout", "stderr"):
            record = stage[stream]
            need(Path(record["path"]).parent == ROOT / "rust-ci-01", "Rust CI stream escaped fixed scope")
            same(Path(record["path"]), record)
    n = rust["nextest_output_audit"]
    need(n["verified"] is True and n["passed"] == 1653 and n["failed"] == 0 and n["ignored"] == 34
         and n["selected"] == 1687 and n["retries"] == 0 and n["success_status_counts"] == {"PASS": 1653},
         "original exact nextest output audit differs")
    manifest = get_json(STAGE_ROOT / "ci-gates/ci-gate-manifest.json")
    same(STAGE_ROOT / "ci-gates/ci-gate-manifest.json",
         {"sha256": "bf0df5f7d19ebd149854fbf75887fb0fb136f18a63a0c240abf8420655fb195e"})
    need(len(manifest["input_files"]) == 85 and len(manifest["python_gates"]) == 18,
         "original Python workflow/dependency inventory differs")
    for item in manifest["input_files"]:
        same(STAGE_ROOT / "ci-gates/ci-inputs" / item["path"], item)
    for kind in ("rust", "python"):
        installed = get_json(ROOT / (kind + "-ci-tools-install-01.json"))
        destination = ROOT / (kind + "-ci-tools-01")
        need(installed["passed"] is True and installed["destination"] == str(destination)
             and installed["original_file_count"] == len(installed["files"]) == 5,
             "original five-file tool installation differs")
        for filename, pin in installed["files"].items():
            need(Path(filename).name == filename, "unsafe original tool name")
            same(destination / filename, pin)
    first = get_json(ROOT / "python-ci-launch-01/receipt.json")
    need(first["passed"] is False and "error" in first and "runner_pid" not in first
         and "runner_returncode" not in first, "original Python preflight failure was erased or promoted")
    for name in ("python_ci01", "python_ci02"):
        if not stages[name]["executed"]:
            continue
        if stages[name]["report"] is None:
            continue
        try:
            parent = get_json(REPORT_PATHS[name])
        except (ValueError, UnicodeError):
            continue
        terminal = validate_terminal(get_json(NATIVE_PATHS[name]), stages[name]["job_id"])
        if terminal["state"] != "succeeded" or terminal["exit_code"] != 0:
            continue
        if not isinstance(parent, dict) or parent.get("passed") is not True:
            continue
        attempt = "01" if name == "python_ci01" else "02"
        report = get_json(ROOT / ("python-ci-" + attempt) / "report.json")
        same(ROOT / ("python-ci-launch-" + attempt) / "runner.stdout.log", parent["runner_stdout"])
        same(ROOT / ("python-ci-launch-" + attempt) / "runner.stderr.log", parent["runner_stderr"])
        same(ROOT / ("python-ci-" + attempt) / "report.json", parent["report"])
        need(parent["runner_returncode"] == 0 and parent["retry_count"] == 0
             and report["passed"] is True and report["retry_count"] == 0
             and len(report["gates"]) == 18 and all(g["passed"] is True for g in report["gates"])
             and report["manifest_sha256"] == "bf0df5f7d19ebd149854fbf75887fb0fb136f18a63a0c240abf8420655fb195e"
             and report["final_inputs_unchanged"] is True, "Python positive original lacks its complete 18-command result")
        if attempt == "02":
            installed = get_json(ROOT / "python-ci-tools-install-02.json")
            need(installed["passed"] is True and installed["destination"] == str(ROOT / "python-ci-tools-02")
                 and installed["original_file_count"] == len(installed["files"]) == 6,
                 "positive recovery requires its actual six-file installation")
            for filename, pin in installed["files"].items():
                need(Path(filename).name == filename, "unsafe actual recovery tool name")
                same(ROOT / "python-ci-tools-02" / filename, pin)
    return {"qualified_compiler_inputs": 221, "qualification_harness_inputs": 19,
            "qualification_stages": 8, "isolated_passed": 1653, "isolated_ignored": 34,
            "isolated_failed": 0, "isolated_retries": 0, "exact_Rust_CI_stages": 6,
            "nextest_plain_PASS": 1653, "nextest_ignored": 34, "nextest_retries": 0,
            "published_Python_dependencies_preserved": 85, "published_Python_workflow_commands": 18,
            "original_Python_preflight_failure_preserved": True, "tests_reexecuted": False}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--exporter-sha256", required=True)
    parser.add_argument("--archive-helper-sha256", required=True)
    parser.add_argument("--input-sha256", required=True)
    args = parser.parse_args()
    need(sys.platform == "linux" and os.geteuid() != 0 and Path(__file__).resolve() == EXPORTER,
         "fixed native operator exporter path required")
    need(args.archive_helper_sha256 == HELPER_SHA256, "reviewed archive helper pin differs")
    helper = load_helper(args.archive_helper_sha256)
    source_identity = helper.read(EXPORTER)[0]
    need(HEX.fullmatch(args.exporter_sha256) and source_identity["sha256"] == args.exporter_sha256,
         "actual exporter source differs")
    input_identity, input_raw = helper.read(INPUT, retain=True)
    need(HEX.fullmatch(args.input_sha256) and input_identity["sha256"] == args.input_sha256, "actual input differs")
    value = json.loads(input_raw)
    declarations = validate_input(value)
    helper.direct(ROOT)
    need(stat.S_ISDIR(ROOT.lstat().st_mode) and ROOT.lstat().st_uid == os.geteuid()
         and not os.path.lexists(OUT), "fresh fixed owned evidence output required")
    OUT.mkdir(mode=0o700)
    report = {"schema": "hepta-r28-qualification-ci-evidence-export/v1", "passed": False,
              "started_utc": utc(), "exporter": source_identity, "input": input_identity,
              "archive_helper": helper.read(HELPER)[0], "original_outcomes": {}, "archive": None,
              "no_workload_executed": True, "automatic_retries": 0, "candidate_adopted": False,
              "performance_or_lifecycle_result_inferred": False, "hosted_actions_passed_inferred": False,
              "native_original_raw_companion_required": True}
    identities, payloads, omitted, inventories, absent = {}, {}, {}, {}, []
    def remember(record):
        key = record["source_path"]
        need(key not in identities or identities[key] == record, "original changed between reads")
        identities[key] = record
        return record
    def expect_absent(path):
        need(not os.path.lexists(path), "declared absent original output now exists: " + str(path))
        absent.append(str(path))
    def include(path, name, scan=False):
        helper.safe_name(name)
        need(name not in payloads and name not in omitted, "duplicate archive member")
        identity = remember(helper.read(path)[0])
        reason = omission_reason(path, "qualification_ci", identity)
        # ELF/config classification deliberately precedes text marker scanning.
        if reason:
            omitted[name] = {"identity": identity, "reason": reason}
        else:
            if scan:
                remember(helper.read(path, expected=identity, scan_private_markers=True)[0])
            payloads[name] = identity
        return identity
    def bound(pin):
        identity, raw = helper.read(Path(pin["path"]), retain=True)
        need(all(identity[k] == pin[k] for k in ("bytes", "sha256")), "actual original receipt identity differs")
        remember(identity)
        return raw
    def get_json(path):
        record, raw = helper.read(path, retain=True, expected=identities.get(str(path)))
        remember(record)
        return json.loads(raw)
    try:
        for name in STAGES:
            row = declarations[name]
            if not row["executed"]:
                for path in (NATIVE_PATHS[name], REPORT_PATHS[name].parent, ROOT / "python-ci-02"):
                    expect_absent(path)
                report["original_outcomes"][name] = original_outcome(name, row, None, None)
                continue
            terminal = json.loads(bound(row["native_terminal"]))
            original = None
            if row["report"] is None:
                expect_absent(REPORT_PATHS[name])
            else:
                raw = bound(row["report"])
                try:
                    original = json.loads(raw)
                except (ValueError, UnicodeError):
                    original = None
            report["original_outcomes"][name] = original_outcome(name, row, terminal, original)
            include(NATIVE_PATHS[name], "native-terminals/" + NATIVE_PATHS[name].name)
        need(report["original_outcomes"]["qualification_failed01"]["native_outcome"]["state"] == "failed"
             and report["original_outcomes"]["python_ci01"]["native_outcome"]["state"] == "failed",
             "known original failed native operation was promoted")
        need(all(report["original_outcomes"][key]["original_positive_report_and_closed_native"] is True
                 for key in ("qualification02", "rust_ci01")),
             "known completed qualification/Rust CI was not bound to its actual strong terminal")
        for label, directory in DIRECTORIES.items():
            if not os.path.lexists(directory):
                need(label in OPTIONAL_TREES, "required original directory is absent: " + label)
                expect_absent(directory)
                continue
            snapshot = helper.listing(directory)
            inventories[str(directory)] = snapshot
            for pathname in snapshot["files"]:
                path = Path(pathname)
                include(path, label + "/" + path.relative_to(directory).as_posix(),
                        label in {"qualification", "rust-ci", "python-ci01", "python-ci02", "python-launch01", "python-launch02"})
        # The known first Python runner never launched; its 18 commands are not inferred.
        expect_absent(ROOT / "python-ci-01")
        for filename in ROOT_FILES:
            path = ROOT / filename
            if not os.path.lexists(path):
                need(filename in OPTIONAL_ROOT_FILES, "required fixed root evidence absent: " + filename)
                expect_absent(path)
            else:
                include(path, "root-receipts/" + filename)
        for path in QUALIFIER_ASSETS:
            include(path, "fixed-support/" + path.name)
        for pin in (value["preparation"], value["source_map"]):
            bound(pin)
        source_map = get_json(ROOT / "qualification-01/source-map.json")
        qualification = get_json(ROOT / "qualification-01/report.json")
        for relative in sorted(source_map):
            helper.safe_name(relative)
            include(SOURCE / relative, "qualified-source/" + relative)
        for filename in sorted(qualification["harness_before"]):
            need(Path(filename).name == filename, "unsafe original harness filename")
            include(SOURCE / "tools/x230/20261028" / filename, "qualification-harness/" + filename)
        include(EXPORTER, "capture-tools/export_r28_qualification_ci_01.py")
        include(HELPER, "capture-tools/stable_xz_archive.py")
        include(INPUT, "capture-tools/actual-input.json")
        bindings = check_original_bindings(get_json, identities, declarations)
        manifest = {"schema": "hepta-r28-qualification-ci-archive-manifest/v1", "root": str(ROOT),
                    "archive_name": ARCHIVE_NAME, "exporter": source_identity,
                    "archive_helper": report["archive_helper"], "input": input_identity,
                    "declarations": declarations, "original_outcomes": report["original_outcomes"],
                    "original_bindings": bindings, "payloads": payloads, "omissions": omitted,
                    "fixed_directory_inventories": inventories, "observed_absent_paths": sorted(set(absent)),
                    "exact_original_bytes_preserved": True, "compiler_cache_body_outside_scope": str(ROOT / "target-build"),
                    "external_parent_bindings_recorded_in_original_preparation": True,
                    "external_parent_bodies_reaudited_here": False, "native_original_raw_companion_required": True,
                    "performance_and_lifecycle_outside_this_fixed_scope": True, "candidate_adopted": False}
        raw, archive_proof = helper.write_archive(OUT / ARCHIVE_NAME, manifest, payloads,
            secret_prefixes=("qualification/", "rust-ci/", "python-ci01/", "python-ci02/", "python-launch01/", "python-launch02/"))
        helper.create(OUT / "manifest.json", raw)
        report["manifest"] = helper.read(OUT / "manifest.json")[0]
        report["archive"] = archive_proof
        report["transfer"] = helper.transfer_chunks(OUT / ARCHIVE_NAME, OUT)
        for pathname, expected in identities.items():
            helper.read(Path(pathname), expected=expected)
        for pathname, expected in inventories.items():
            need(helper.listing(Path(pathname)) == expected, "fixed original inventory changed during capture")
        for pathname in absent:
            need(not os.path.lexists(pathname), "original absent path appeared during capture")
        report.update(passed=True, original_bindings=bindings, payload_count=len(payloads),
                      omission_count=len(omitted), original_inputs_unchanged=True,
                      original_negative_outcomes_preserved=True)
    except Exception as error:
        report["error"] = {"type": type(error).__name__, "message": str(error), "traceback": traceback.format_exc()}
    report["finished_utc"] = utc()
    helper.create(OUT / "report.json", helper.encode(report))
    report_identity = helper.read(OUT / "report.json")[0]
    print(json.dumps({"report": report_identity, "passed": report["passed"],
                      "candidate_adopted": False, "no_workload_executed": True}), flush=True)
    return 0 if report["passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())


