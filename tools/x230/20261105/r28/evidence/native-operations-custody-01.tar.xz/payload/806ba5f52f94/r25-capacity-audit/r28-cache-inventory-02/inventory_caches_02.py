"""Read only fixed task caches, fixed failed preparation, and narrow /proc references."""
import hashlib
import json
import os
import stat
import sys
import time

ROOT25 = '/home/qian/hepta-runtime-optimization-20261105-r25'
ROOT26 = '/home/qian/hepta-runtime-optimization-20261105-r26'
ROOT28 = '/home/qian/hepta-runtime-optimization-20261105-r28'
OWNER = 1000
CACHES = (
    ('candidate_r25', ROOT25 + '/target-build-02', False),
    ('candidate_private05', ROOT25 + '/mechanism-diagnostic-05/target-build', False),
    ('protected_r26', ROOT26 + '/target-build', True),
)
BOUND = (
    (ROOT26 + '/preparation-01.json', 89124, 'f2dfe7d07b9076583b26af075815c16694e71669379c53aa7db48974b506798a'),
    (ROOT25 + '/mechanism-diagnostic-05/build-report.json', 215995, '6364c71ca6567b40fbfe8c211f0479f7a89e1c4dab568e1e7756be36e528f705'),
    (ROOT28 + '/preparation-01.json', 4671, 'abc26b3d49c2e57b608fe3aba792708e80de95340c1c8c210dced2844953fade'),
    (ROOT28 + '/qualification-input-01.json', 34557, '0837e858fddf7df95229a5dac1dafdf6d904800caad46cb238ba18ecfaa93299'),
)
FIELDS = ('st_dev', 'st_ino', 'st_uid', 'st_mode', 'st_nlink', 'st_size', 'st_mtime_ns', 'st_ctime_ns')
DEAD = {'Z', 'X', 'x'}
START = time.monotonic_ns()
MAX_DURATION_NS = 120 * 10**9
MAX_TREE_ENTRIES = 200000
MAX_PROCESSES = 16384
MAX_PROC_BYTES = 1048576


def need(value, reason):
    if not value:
        raise RuntimeError(reason)


def budget():
    need(time.monotonic_ns() - START <= MAX_DURATION_NS, 'bounded inventory duration exceeded')


def stamp(value):
    return {key: getattr(value, key) for key in FIELDS}


def directory_id(value):
    need(stat.S_ISDIR(value.st_mode), 'fixed path is not a directory')
    return (value.st_dev, value.st_ino, value.st_uid, value.st_mode)


def check_chain(chain):
    for item in chain:
        linked = (os.lstat('/') if item['parent'] is None else
                  os.stat(item['name'], dir_fd=item['parent'], follow_symlinks=False))
        need(directory_id(os.fstat(item['fd'])) == item['identity'] == directory_id(linked),
             'fixed directory chain changed')


def close_chain(chain):
    for item in reversed(chain):
        os.close(item['fd'])


def open_directory(path):
    need(path.startswith('/home/qian/') and os.path.normpath(path) == path,
         'directory outside exact task parent')
    chain = []
    try:
        for number, name in enumerate(('/', *path.split('/')[1:])):
            parent = chain[-1]['fd'] if chain else None
            fd = os.open(name, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW | os.O_CLOEXEC,
                         **({'dir_fd': parent} if parent is not None else {}))
            item = {'fd': fd, 'parent': parent, 'name': name}
            chain.append(item)
            item['identity'] = directory_id(os.fstat(fd))
            need(item['identity'][2] == (0 if number < 2 else OWNER), 'fixed directory owner differs')
            check_chain(chain)
        need(os.path.realpath(path) == path, 'fixed root realpath differs')
        return chain
    except BaseException:
        close_chain(chain)
        raise


def read_bound(spec):
    path, size, expected_sha = spec
    chain = open_directory(os.path.dirname(path))
    fd = None
    try:
        owner_fd = chain[-1]['fd']
        fd = os.open(os.path.basename(path), os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK | os.O_CLOEXEC,
                     dir_fd=owner_fd)
        before = os.fstat(fd)
        need(stat.S_ISREG(before.st_mode) and before.st_uid == OWNER and before.st_nlink == 1
             and before.st_size == size <= 1048576, 'fixed evidence file metadata differs')
        with os.fdopen(os.dup(fd), 'rb') as stream:
            raw = stream.read(size + 1)
        actual_sha = hashlib.sha256(raw).hexdigest()
        need(len(raw) == size and actual_sha == expected_sha
             and stamp(before) == stamp(os.fstat(fd))
             == stamp(os.stat(os.path.basename(path), dir_fd=owner_fd, follow_symlinks=False)),
             'fixed evidence bytes or descriptor changed')
        check_chain(chain)
        return {'path': path, 'bytes': size, 'sha256': actual_sha, 'identity': stamp(before)}, json.loads(raw)
    finally:
        if fd is not None:
            os.close(fd)
        close_chain(chain)


def inspect_failed_root():
    chain = open_directory(ROOT28)
    try:
        fd = chain[-1]['fd']
        before = os.fstat(fd)
        need(stat.S_IMODE(before.st_mode) == 0o700, 'original R28 root mode differs')
        rows = []
        for name in ('source', 'target-build', 'qualification-01'):
            try:
                current = os.stat(name, dir_fd=fd, follow_symlinks=False)
            except FileNotFoundError:
                rows.append({'path': ROOT28 + '/' + name, 'exists': False, 'identity': None})
            else:
                rows.append({'path': ROOT28 + '/' + name, 'exists': True, 'identity': stamp(current)})
        need(stamp(before) == stamp(os.fstat(fd)), 'original R28 directory changed while inspecting')
        check_chain(chain)
        return {'path': ROOT28, 'owner': OWNER, 'realpath_matches_literal': True,
                'identity': stamp(before), 'absence': rows,
                'all_three_workload_paths_absent': all(not row['exists'] for row in rows)}
    finally:
        close_chain(chain)


def inventory_tree(path):
    chain = open_directory(path)
    started = time.monotonic_ns()
    try:
        root_fd = chain[-1]['fd']
        root = os.fstat(root_fd)
        totals = {'entries': 0, 'directories_including_root': 0, 'directory_logical_bytes': 0,
                  'directory_allocated_bytes': 0, 'regular_files': 0,
                  'regular_logical_bytes': 0, 'unique_regular_logical_bytes': 0,
                  'unique_regular_allocated_bytes': 0, 'symlinks': 0, 'other_nonregular': 0,
                  'other_device_entries': 0, 'other_owner_entries': 0, 'multiply_linked_regular_files': 0}
        incidents, inodes = [], set()
        accumulator = hashlib.sha256()

        def account(relative, current):
            budget()
            totals['entries'] += 1
            need(totals['entries'] <= MAX_TREE_ENTRIES, 'bounded cache entry count exceeded')
            record = {'relative': relative, 'identity': stamp(current), 'st_blocks': current.st_blocks}
            accumulator.update((json.dumps(record, sort_keys=True, separators=(',', ':')) + '\n').encode())
            foreign_device = current.st_dev != root.st_dev
            foreign_owner = current.st_uid != OWNER
            totals['other_device_entries'] += int(foreign_device)
            totals['other_owner_entries'] += int(foreign_owner)
            mode = current.st_mode
            if stat.S_ISDIR(mode):
                totals['directories_including_root'] += 1
                totals['directory_logical_bytes'] += current.st_size
                totals['directory_allocated_bytes'] += current.st_blocks * 512
            elif stat.S_ISREG(mode):
                totals['regular_files'] += 1
                totals['regular_logical_bytes'] += current.st_size
                totals['multiply_linked_regular_files'] += int(current.st_nlink != 1)
                key = (current.st_dev, current.st_ino)
                if key not in inodes:
                    inodes.add(key)
                    totals['unique_regular_logical_bytes'] += current.st_size
                    totals['unique_regular_allocated_bytes'] += current.st_blocks * 512
            elif stat.S_ISLNK(mode):
                totals['symlinks'] += 1
            else:
                totals['other_nonregular'] += 1
            if foreign_device or foreign_owner or not (stat.S_ISDIR(mode) or stat.S_ISREG(mode)):
                if len(incidents) < 32:
                    incidents.append(record)
            return not foreign_device and not foreign_owner

        def walk(fd, relative, depth):
            budget()
            need(depth <= 64, 'bounded cache directory depth exceeded')
            before = os.fstat(fd)
            account(relative, before)
            names = []
            with os.scandir(fd) as scan:
                for item in scan:
                    need(len(names) < MAX_TREE_ENTRIES, 'bounded directory entry count exceeded')
                    names.append(item.name)
            for name in sorted(names):
                budget()
                current = os.stat(name, dir_fd=fd, follow_symlinks=False)
                child_relative = name if relative == '.' else relative + '/' + name
                if stat.S_ISDIR(current.st_mode) and current.st_dev == root.st_dev and current.st_uid == OWNER:
                    child = os.open(name, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW | os.O_CLOEXEC,
                                    dir_fd=fd)
                    try:
                        need(stamp(current) == stamp(os.fstat(child)), 'cache directory replaced before scan')
                        walk(child, child_relative, depth + 1)
                        need(stamp(os.fstat(child)) == stamp(os.stat(name, dir_fd=fd, follow_symlinks=False)),
                             'cache directory path changed during scan')
                    finally:
                        os.close(child)
                else:
                    account(child_relative, current)
            need(stamp(before) == stamp(os.fstat(fd)), 'cache directory metadata changed during scan')

        walk(root_fd, '.', 0)
        check_chain(chain)
        need(stamp(root) == stamp(os.fstat(root_fd)), 'cache root metadata changed during scan')
        return {'path': path, 'root_identity': stamp(root), 'realpath_matches_literal': True,
                'counts': totals, 'metadata_sha256': accumulator.hexdigest(),
                'anomaly_examples_maximum_32': incidents,
                'foreign_subtrees_and_symlinks_not_followed': True,
                'all_entries_traversed': totals['other_device_entries'] == totals['other_owner_entries'] == 0,
                'started_monotonic_ns': started, 'finished_monotonic_ns': time.monotonic_ns()}
    finally:
        close_chain(chain)


def proc_bytes(fd, name, maximum):
    child = os.open(name, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK | os.O_CLOEXEC, dir_fd=fd)
    try:
        with os.fdopen(os.dup(child), 'rb') as stream:
            raw = stream.read(maximum + 1)
        need(len(raw) <= maximum, 'bounded process metadata exceeded')
        return raw
    finally:
        os.close(child)


def proc_stat(raw, expected_pid):
    closing = raw.rfind(b')')
    need(closing > 0, 'malformed bounded process stat')
    pid = int(raw[:raw.find(b'(')].strip())
    fields = raw[closing + 1:].split()
    need(pid == expected_pid and len(fields) >= 20, 'process stat identity differs')
    state = fields[0].decode('ascii')
    birth = int(fields[19])
    need(len(state) == 1 and birth > 0, 'invalid process state or birth')
    return pid, birth, state


def matches_cache(value, cache, cwd=None):
    # Values remain private to this predicate and are never emitted or hashed.
    value = value.removesuffix(' (deleted)')
    start = 0
    while True:
        pos = value.find(cache, start)
        if pos < 0:
            break
        end = pos + len(cache)
        before_ok = pos == 0 or value[pos - 1] in '=,: \t'
        after_ok = end == len(value) or value[end] == '/'
        if before_ok and after_ok:
            return True
        start = pos + 1
    if cwd and value and not value.startswith('-') and not os.path.isabs(value):
        candidate = os.path.normpath(os.path.join(cwd.removesuffix(' (deleted)'), value))
        return candidate == cache or candidate.startswith(cache + '/')
    return False


def scan_references():
    started = time.monotonic_ns()
    summary = {'scope': ['cwd', 'argv', 'CARGO_TARGET_DIR'], 'started_monotonic_ns': started,
               'processes_enumerated': 0, 'live_processes_examined': 0, 'dead_processes_skipped': 0,
               'vanished_before_live_observation': 0, 'processes_indeterminate': 0,
               'same_owner_processes_indeterminate': 0, 'foreign_owner_processes_indeterminate': 0,
               'unknown_owner_processes_indeterminate': 0,
               'channel_error_counts': {}, 'matched_live_processes': [],
               'unknown_process_examples_maximum_16': [], 'complete': False,
               'raw_argv_or_environment_or_unrelated_cwd_emitted': False}
    proc_fd = os.open('/proc', os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW | os.O_CLOEXEC)
    try:
        pids = []
        with os.scandir(proc_fd) as scan:
            for entry in scan:
                if entry.name.isascii() and entry.name.isdecimal():
                    need(len(pids) < MAX_PROCESSES, 'bounded process inventory exceeded')
                    pids.append(int(entry.name))
        summary['processes_enumerated'] = len(pids)
        for pid in sorted(pids):
            budget()
            fd = None
            uid = None
            first = None
            errors = []
            matches = {name: [] for name, _, _ in CACHES}
            try:
                fd = os.open(str(pid), os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW | os.O_CLOEXEC,
                             dir_fd=proc_fd)
                proc_identity = os.fstat(fd)
                uid = proc_identity.st_uid
                first = proc_stat(proc_bytes(fd, 'stat', 16384), pid)
                if first[2] in DEAD:
                    summary['dead_processes_skipped'] += 1
                    continue
                summary['live_processes_examined'] += 1
                cwd = None
                try:
                    cwd = os.readlink('cwd', dir_fd=fd)
                    for name, cache, _ in CACHES:
                        if matches_cache(cwd, cache):
                            matches[name].append('cwd')
                except OSError as error:
                    errors.append(('cwd', error.errno))
                try:
                    argv = proc_bytes(fd, 'cmdline', MAX_PROC_BYTES).split(b'\0')
                    for value in argv:
                        token = os.fsdecode(value)
                        for name, cache, _ in CACHES:
                            if matches_cache(token, cache, cwd) and 'argv' not in matches[name]:
                                matches[name].append('argv')
                    del argv
                except OSError as error:
                    errors.append(('argv', error.errno))
                try:
                    environment = proc_bytes(fd, 'environ', MAX_PROC_BYTES)
                    for value in environment.split(b'\0'):
                        if value.startswith(b'CARGO_TARGET_DIR='):
                            target = os.fsdecode(value[len(b'CARGO_TARGET_DIR='):])
                            for name, cache, _ in CACHES:
                                if matches_cache(target, cache, cwd):
                                    matches[name].append('CARGO_TARGET_DIR')
                    del environment
                except OSError as error:
                    errors.append(('CARGO_TARGET_DIR', error.errno))
                second = proc_stat(proc_bytes(fd, 'stat', 16384), pid)
                after = os.fstat(fd)
                linked = os.stat(str(pid), dir_fd=proc_fd, follow_symlinks=False)
                need(first[:2] == second[:2]
                     and (proc_identity.st_dev, proc_identity.st_ino, uid)
                     == (after.st_dev, after.st_ino, after.st_uid)
                     == (linked.st_dev, linked.st_ino, linked.st_uid), 'process identity changed during inspection')
                states = [first[2], second[2]]
            except FileNotFoundError:
                if first is None:
                    summary['vanished_before_live_observation'] += 1
                    continue
                errors.append(('identity_after_live_observation', 2))
                states = [first[2]]
            except OSError as error:
                errors.append(('process_metadata', error.errno))
                states = [first[2]] if first else []
            except (RuntimeError, ValueError, UnicodeError):
                errors.append(('process_identity_or_bounds', None))
                states = [first[2]] if first else []
            finally:
                if fd is not None:
                    os.close(fd)
            selected = {name: channels for name, channels in matches.items() if channels}
            if selected:
                summary['matched_live_processes'].append({'pid': pid, 'uid': uid,
                    'birth_ticks': first[1] if first else None, 'observed_states': states,
                    'cache_reference_channels': selected, 'inspection_complete': not errors})
            if errors:
                summary['processes_indeterminate'] += 1
                category = ('unknown_owner_processes_indeterminate' if uid is None else
                            'same_owner_processes_indeterminate' if uid == OWNER else
                            'foreign_owner_processes_indeterminate')
                summary[category] += 1
                for channel, code in errors:
                    key = channel + ':' + str(code)
                    summary['channel_error_counts'][key] = summary['channel_error_counts'].get(key, 0) + 1
                if len(summary['unknown_process_examples_maximum_16']) < 16:
                    summary['unknown_process_examples_maximum_16'].append({'pid': pid, 'uid': uid,
                        'birth_ticks': first[1] if first else None, 'observed_states': states,
                        'unreadable_or_raced_channels': [channel for channel, _ in errors]})
        summary['complete'] = summary['processes_indeterminate'] == 0
        summary['all_same_owner_live_process_channels_inspected'] = (
            summary['same_owner_processes_indeterminate'] == 0
            and summary['unknown_owner_processes_indeterminate'] == 0)
        summary['finished_monotonic_ns'] = time.monotonic_ns()
        summary['single_scan_only_no_continuous_liveness_claim'] = True
        return summary
    finally:
        os.close(proc_fd)


report = {'schema': 'hepta-r28-cache-readonly-inventory/v1', 'passed': False,
          'started_unix_ns': time.time_ns(), 'read_only': True, 'cache_inventory': {},
          'bound_inputs': [], 'process_reference_scans': [], 'files_created_or_deleted': 0,
          'deletion_authorized_by_this_report': False, 'deletion_eligibility_established': False,
          'protected_r26_must_not_be_deleted': True, 'workloads_or_compilers_started': False,
          'raw_other_process_argv_environment_or_cwd_emitted': False,
          'point_in_time_metadata_only_not_a_cleanup_receipt': True}
cpu_start = time.process_time_ns()
try:
    need(sys.platform == 'linux' and os.geteuid() == OWNER, 'fixed native Linux operator required')
    documents = []
    for spec in BOUND:
        identity, value = read_bound(spec)
        report['bound_inputs'].append(identity)
        documents.append(value)
    preparation26, private05, failed28, input28 = documents
    need(preparation26['passed'] is True and preparation26['cache_source'] == CACHES[0][1]
         and preparation26['target'] == CACHES[2][1], 'original R26 cache provenance differs')
    need(private05['passed'] is True and private05['diagnostic_only'] is True
         and private05['production_candidate'] is False
         and private05['diagnostic']['binary']['path'] == ROOT25 + '/mechanism-diagnostic-05/hepta-runtime-diagnostic',
         'original private05 build provenance differs')
    need(failed28['passed'] is False and failed28['candidate_qualified'] is False
         and failed28['error'] == 'AssertionError: (6285365248, 3080991421)'
         and input28['optional_pidfd_selected'] is False, 'original R28 failed admission differs')
    report['actual_root28'] = inspect_failed_root()
    report['actual_root28']['preparation01'] = report['bound_inputs'][2]
    report['actual_root28']['qualification_input01'] = report['bound_inputs'][3]
    report['process_reference_scans'].append(scan_references())
    for name, path, protected in CACHES:
        row = {'path': path, 'protected': protected, 'deletion_allowed': False,
               'metadata_only_no_cache_file_payload_reads': True, 'passes': []}
        report['cache_inventory'][name] = row
        try:
            initial_chain = open_directory(path)
            try:
                row['exists_at_initial_root_check'] = True
                row['initial_root_identity'] = stamp(os.fstat(initial_chain[-1]['fd']))
            finally:
                close_chain(initial_chain)
            for _ in range(2):
                row['passes'].append(inventory_tree(path))
            first, second = row['passes']
            row['exists'] = True
            row['metadata_stable_across_two_passes'] = all(first[key] == second[key] for key in
                ('path', 'root_identity', 'counts', 'metadata_sha256', 'all_entries_traversed'))
            row['complete'] = row['metadata_stable_across_two_passes'] and second['all_entries_traversed']
        except FileNotFoundError:
            row.setdefault('exists_at_initial_root_check', False)
            row.update(complete=False, metadata_stable_across_two_passes=False,
                       error='fixed cache or descendant absent during original inventory; no removal cause inferred')
        except (OSError, RuntimeError) as error:
            row.update(complete=False, metadata_stable_across_two_passes=False,
                       error_type=type(error).__name__, errno=getattr(error, 'errno', None))
    report['process_reference_scans'].append(scan_references())
    for name, _, _ in CACHES:
        row = report['cache_inventory'][name]
        row['active_reference_observed'] = any(name in process['cache_reference_channels']
            for scan in report['process_reference_scans'] for process in scan['matched_live_processes'])
        row['all_process_reference_channels_inspected'] = all(scan['complete'] for scan in report['process_reference_scans'])
        row['all_same_owner_reference_channels_inspected'] = all(
            scan['all_same_owner_live_process_channels_inspected'] for scan in report['process_reference_scans'])
        row['no_reference_observed_in_complete_scans'] = (not row['active_reference_observed']
            and row['all_process_reference_channels_inspected'])
    final_root = inspect_failed_root()
    need(all(final_root[key] == report['actual_root28'][key] for key in final_root), 'original R28 root changed')
    for spec, expected in zip(BOUND, report['bound_inputs'], strict=True):
        need(read_bound(spec)[0] == expected, 'bound original evidence changed after inventory')
    disk = os.statvfs(ROOT28)
    report['disk'] = {'available_bytes': disk.f_bavail * disk.f_frsize,
                    'free_bytes': disk.f_bfree * disk.f_frsize, 'filesystem_block_bytes': disk.f_frsize,
                    'original_failed_available_bytes': 6285365248,
                    'original_copy_cache_bytes': 3080991421,
                    'unchanged_required_headroom_bytes': 3 * 1024**3,
                    'original_shortfall_bytes': 3080991421 + 3 * 1024**3 - 6285365248}
    report['passed'] = (report['actual_root28']['all_three_workload_paths_absent']
                        and all(row['complete'] for row in report['cache_inventory'].values()))
    report['process_reference_scan_incompleteness_is_preserved_not_converted_to_no_reference'] = True
except BaseException as error:
    report['error'] = {'type': type(error).__name__, 'reason': str(error)[:1000]}
finally:
    report['finished_unix_ns'] = time.time_ns()
    report['wall_ns'] = time.monotonic_ns() - START
    report['process_cpu_ns'] = time.process_time_ns() - cpu_start
print(json.dumps(report, sort_keys=True, allow_nan=False), flush=True)
sys.exit(0 if report['passed'] else 1)
