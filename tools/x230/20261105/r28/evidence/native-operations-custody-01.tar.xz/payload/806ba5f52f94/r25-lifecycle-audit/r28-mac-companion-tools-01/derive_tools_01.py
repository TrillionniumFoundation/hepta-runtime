#!/usr/bin/env python3
"""Local-only, create-only derivation of the already reviewed Mac capture tools.

This script only parses/copies local source and original receipt bytes. It never
imports or invokes the collector, consumer, holder, a remote tool, or a workload.
"""
import ast
import difflib
import hashlib
import json
from pathlib import Path
import pprint

HERE = Path(__file__).resolve().parent
WORK = HERE.parents[1]
ORIGINAL = WORK / "r25-integration-audit/r26-mac-companion-tools-01"
OBS = WORK / "benchmark-r28/observation-operations-01"
MAC = "/Users/qianqi/work"
TOOLS = MAC + "/hepta-runtime-r28-mac-companion-tools-01"
INPUTS = MAC + "/hepta-runtime-r28-mac-companion-inputs-01"
OUTPUT = MAC + "/hepta-runtime-r28-mac-companion-evidence-01"
ORIGINAL_PINS = {
    "collect_mac_companion_01.py": (39063, "2af1e0f1bbe5a277ca7c314384a0ea35d33568e9db0d596f67ff8d033846d13c"),
    "verify_mac_companion_01.py": (48337, "cdb69368575dd6e48d8239f8c7509d10a23ce5f295c957e4200615f5018a914e"),
    "contract-01.json": (5382, "ed236222c48f7aa63be9362680f6ac1a7c250ab7ed2b8b50e1acee32720808e8"),
    "output-interface-01.json": (4263, "a1757f9799da19a6db771c5677d91916922deb6a1190261cffc8fe93a88ee102"),
}
OBS_PINS = {
    "actual-receipts-01/mac-report.json": (9075, "288a748ae91e84b409b2bbd903c51bc83d5faca17963f0ddbc638d56a17ea8c9"),
    "holder-status-02.json": (1064, "caf70250b3408215baf89f0b588e56618bbdcbcd18517fd56e5e26a7e1799353"),
    "holder-read-00-01.json": (1646, "abd425abe2e3b1765d221e70ba57cd92a379bcb892931819c86805baa9b4b3bb"),
}
PLANS = {
    "observation01": {
        "directory": MAC + "/hepta-runtime-r28-observation-evidence-01",
        "footer_gate": "observation_gate_passed", "footer_kind": "formal", "group": "formal",
        "known_job_id": "1a1acbbcbec-fc05-56a0",
        "remote_report": "/home/qian/hepta-runtime-optimization-20261105-r28/campaign-01/report.json",
        "script": MAC + "/hepta-runtime-r28-observation-campaign-02.py",
        "script_bytes": 64590,
        "script_sha256": "52c2c2777d44d071896b6a25d5c9f178b66989e501abff63fb4fc2a01ee4b2d9",
        "timeout_seconds": 3600,
    },
    "lifecycle01": {
        "directory": MAC + "/hepta-runtime-r28-lifecycle-evidence-01",
        "footer_gate": "adoption_passed", "footer_kind": "formal", "group": "formal", "known_job_id": None,
        "remote_report": "/home/qian/hepta-runtime-optimization-20261105-r28/lifecycle-campaign-01/report.json",
        "script": MAC + "/hepta-runtime-r28-lifecycle-campaign-02.py",
        "script_bytes": 26760,
        "script_sha256": "5a7f60e4d61ce69ed9962a47956045710908455c90fc3048035287232d4c84ce",
        "timeout_seconds": 3600,
    },
}
KNOWN = {"observation01": {
    "report_sha256": OBS_PINS["actual-receipts-01/mac-report.json"][1],
    "terminal_sha256": OBS_PINS["holder-status-02.json"][1],
    "read_sha256": OBS_PINS["holder-read-00-01.json"][1],
}}


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def identity(path):
    raw = path.read_bytes()
    return {"path": str(path), "bytes": len(raw), "sha256": sha(raw)}


def original(name):
    raw = (ORIGINAL / name).read_bytes()
    assert (len(raw), sha(raw)) == ORIGINAL_PINS[name], name
    return raw


def save(name, raw):
    path = HERE / name
    with path.open("xb") as stream:
        stream.write(raw)
    assert path.read_bytes() == raw
    return identity(path)


def document(name, value):
    return save(name, (json.dumps(value, sort_keys=True, indent=2) + "\n").encode())


def assignments(text, replacements):
    lines = text.splitlines(keepends=True)
    nodes = {}
    for node in ast.parse(text).body:
        if isinstance(node, ast.Assign) and len(node.targets) == 1 and isinstance(node.targets[0], ast.Name):
            if node.targets[0].id in replacements:
                nodes[node.targets[0].id] = node
    assert set(nodes) == set(replacements)
    for name, node in sorted(nodes.items(), key=lambda item: item[1].lineno, reverse=True):
        lines[node.lineno - 1:node.end_lineno] = [name + " = " + replacements[name] + "\n"]
    return "".join(lines)


def function_proof(old, new):
    before = {node.name: node for node in ast.parse(old).body if isinstance(node, (ast.FunctionDef, ast.ClassDef))}
    normalized = new.replace("hepta-r28-mac-companion", "hepta-r26-mac-companion")
    after = {node.name: node for node in ast.parse(normalized).body if isinstance(node, (ast.FunctionDef, ast.ClassDef))}
    assert set(before) == set(after)
    unchanged = []
    for name in before:
        left, right = ast.dump(before[name], include_attributes=False), ast.dump(after[name], include_attributes=False)
        assert left == right, name
        unchanged.append({"name": name, "normalized_ast_sha256": sha(left.encode())})
    return unchanged


def main():
    for name, pin in OBS_PINS.items():
        raw = (OBS / name).read_bytes()
        assert (len(raw), sha(raw)) == pin, name
    parent_base = WORK / "r25-integration-audit/r28-acceptance-tools-02/tools-02"
    for kind, name in (("observation01", "r28_campaign.py"), ("lifecycle01", "r28_lifecycle_campaign.py")):
        raw = (parent_base / name).read_bytes()
        assert (len(raw), sha(raw)) == (PLANS[kind]["script_bytes"], PLANS[kind]["script_sha256"])
    proof = {"schema": "hepta-r28-mac-companion-local-derivation/v1", "local_source_derivation_only": True,
             "collector_consumer_holder_or_workload_executed": False, "host_rpc": False, "git_mutation": False,
             "base_successful_qa": identity(WORK / "r25-integration-audit/r26-mac-companion-actual-capture-01/verified-01/independent-verification-01.json"),
             "source_changes": {}, "actual_original_inputs": {name: identity(OBS / name) for name in OBS_PINS},
             "permitted_change_scope": ["fixed two R28 plans and one formal group", "fresh Mac paths and R28 schema namespace",
                 "actual original observation job/report/terminal/read pins", "top-level descriptive docstrings"],
             "holder_logic_unchanged": True, "privacy_descriptor_native_gzip_and_transport_logic_unchanged": True}
    patches = []
    for name in ("collect_mac_companion_01.py", "verify_mac_companion_01.py"):
        old = original(name).decode()
        common = {"PLANS": pprint.pformat(PLANS, width=110, sort_dicts=False),
                  "KNOWN_ORIGINAL_PINS": pprint.pformat(KNOWN, width=110),
                  "ARCHIVE_NAMES": repr({"formal": "formal-holders-01.tar.gz"})}
        if name.startswith("collect"):
            replacements = {**common, "INPUTS": "WORK / 'hepta-runtime-r28-mac-companion-inputs-01'",
                "TOOLS": "WORK / 'hepta-runtime-r28-mac-companion-tools-01'",
                "OUT": "WORK / 'hepta-runtime-r28-mac-companion-evidence-01'",
                "GROUPS": "('formal',)", "GROUP_KINDS": repr({"formal": ("observation01", "lifecycle01")})}
            text = old.replace("Capture the fixed R26 formal and private diagnostic Mac holders.",
                               "Capture the two fixed R28 formal Mac holder declarations.", 1)
        else:
            replacements = {**common, "REMOTE": repr(OUTPUT), "NATIVE_INPUTS": repr(INPUTS), "TOOLS": repr(TOOLS),
                "GROUPS": repr({"formal": ["observation01", "lifecycle01"]})}
            text = old.replace("Independently verify two Mac companion archives", "Independently verify the R28 Mac companion archive", 1)
        text = assignments(text, replacements).replace("hepta-r26-mac-companion", "hepta-r28-mac-companion")
        assert "hepta-runtime-r26-" not in text
        functions = function_proof(old, text)
        saved = save(name, text.encode())
        proof["source_changes"][name] = {"original": identity(ORIGINAL / name), "derived": saved,
            "all_functions_equal_after_schema_namespace_normalization": True, "functions": functions,
            "replaced_top_level_assignments": sorted(replacements)}
        patches.extend(difflib.unified_diff(old.splitlines(True), text.splitlines(True),
                                           fromfile="reviewed-r26/" + name, tofile="r28/" + name))
    contract = json.loads(original("contract-01.json"))
    contract.update(schema="hepta-r28-mac-companion-code-contract/v1", groups=["formal"], plans=PLANS,
        archive_names={"formal": "formal-holders-01.tar.gz"}, input_schema="hepta-r28-mac-companion-originals/v1",
        tools=TOOLS, inputs=INPUTS, output=OUTPUT,
        native_files="<kind>-terminal.json and <kind>-read.json; exact original saved request/result envelope bytes, no DTO re-encode",
        actual_observation={"job_id": PLANS["observation01"]["known_job_id"], "native_state": "succeeded",
            "native_exit_code": 0, "original_holder_passed": True, "observation_gate_passed": False,
            "report_sha256": KNOWN["observation01"]["report_sha256"]},
        lifecycle={"executed": False, "job_id": None,
            "directory_absence_required_in_actual_collector": True,
            "absence_rechecked_before_and_after_archive": True,
            "actual_absence_observed_by_this_local_preparation": False,
            "prepared_source_may_be_captured_but_is_not_a_transmitted_or_executed_holder" : True},
        compression="Original reviewed deterministic single-member gzip; no new compression helper or archive execution")
    document("contract-01.json", contract)
    interface = json.loads(original("output-interface-01.json").decode().replace("hepta-r26-mac-companion", "hepta-r28-mac-companion"))
    interface.update(campaigns_shape="kind -> complete original native/holder/remote footer proof; consumer independently derives before comparing",
        chunk_paths_relative_to_export_root="formal/chunks/chunk-NNNN.b64",
        manifest_source_inventories="Executed kind -> exact22 original filenames; all stat/version witnesses remain in files; collector rechecks every descriptor and each unexecuted directory absence before and after the archive")
    interface["native_capture_footer"].update(archive_groups=["formal"], receipt=OUTPUT + "/receipt.json")
    document("output-interface-01.json", interface)
    declaration = {"schema": "hepta-r28-mac-companion-originals/v1", "all_originals_terminal_or_unexecuted": True,
        "holders": {"observation01": {"executed": True, "job_id": PLANS["observation01"]["known_job_id"],
            **KNOWN["observation01"], "reason": None}, "lifecycle01": {"executed": False, "job_id": None,
            "report_sha256": None, "terminal_sha256": None, "read_sha256": None,
            "reason": "Not launched after the original R28 observation gate rejected C1 throughput; lifecycle and saturation were not scheduled. Actual evidence-directory absence must still be observed and rechecked by this capture."}}}
    (HERE / "inputs").mkdir(mode=0o700)
    document("inputs/actual-input-01.json", declaration)
    for suffix, source in (("terminal", "holder-status-02.json"), ("read", "holder-read-00-01.json")):
        save("inputs/observation01-" + suffix + ".json", (OBS / source).read_bytes())
    collector, consumer = identity(HERE / "collect_mac_companion_01.py"), identity(HERE / "verify_mac_companion_01.py")
    input_pin = identity(HERE / "inputs/actual-input-01.json")
    request = {"host": "main", "executable": "/usr/bin/python3", "args": ["-I", "-B", TOOLS + "/collect_mac_companion_01.py",
        "--collector-sha256", collector["sha256"], "--consumer-sha256", consumer["sha256"], "--input-sha256", input_pin["sha256"]],
        "idempotency_key": "hepta-r28-mac-holder-evidence-export-20261105-01", "nice": 19, "timeout_seconds": 300}
    document("capture-request-01.json", request)
    staging = []
    for name in ("collect_mac_companion_01.py", "verify_mac_companion_01.py"):
        staging.append({**identity(HERE / name), "remote_path": TOOLS + "/" + name})
    for name in ("actual-input-01.json", "observation01-terminal.json", "observation01-read.json"):
        staging.append({**identity(HERE / "inputs" / name), "remote_path": INPUTS + "/" + name})
    document("staging-plan-01.json", {"schema": "hepta-r28-mac-companion-create-only-staging-plan/v1",
        "remote_operations_performed": False, "exact_files": staging,
        "fresh_private_directories": [TOOLS, INPUTS], "directory_mode": "0700", "file_mode": "0600",
        "create_only": True, "overwrite": False, "execute_payload_during_staging": False,
        "capture_output_must_remain_absent_until_original_capture": OUTPUT,
        "no_lifecycle_native_files": True, "no_holder_configuration_or_key_reads": True})
    save("source-delta-01.patch", "".join(patches).encode())
    document("derivation-proof-01.json", proof)
    print(json.dumps({"prepared": True, "collector": collector, "consumer": consumer,
                      "input": input_pin, "functions_and_workloads_executed": False}, sort_keys=True))


if __name__ == "__main__":
    main()
