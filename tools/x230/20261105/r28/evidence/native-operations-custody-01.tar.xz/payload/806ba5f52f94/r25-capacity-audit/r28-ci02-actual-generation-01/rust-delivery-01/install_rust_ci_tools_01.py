"""Data-only fresh installation of exactly three tools, manifest and launcher."""
import base64
import gzip
import hashlib
import io
import json
import os
from pathlib import Path
import stat
import sys
import tarfile

SPEC = {'actual_pins': {'ISOLATED_AUDIT_SHA': '1212a8fa0b0e3631627fbadc3e5f93e895babfb7b35bf7e0fa740cc01d16e6d6',
                 'ISOLATED_SUMMARY_SHA': 'a6645dbb6a0208fdbca1a3dd6308c55f7d6b876ef4ddf70f02a2b4c58c9db46d',
                 'JOB_ID': '1a1ac5d5a29-fc05-53d9',
                 'NATIVE_TERMINAL_SHA': '3325b116b998ddff0e586a3b983a2715339acb1b48e9215f5b92e9abfdde4946',
                 'PREPARATION_SHA': '4ece02608c423456d0996de39c54129c6c759a1973a0e11f22b04f936b113cc3',
                 'QUALIFICATION_REPORT_SHA': '9e564f3950575313034f55974303e56c236ac030e2c5f121d49791da0c4c09fa',
                 'SOURCE_MAP_SHA': 'da8cbdfef75c1c9fc5861e4fe0bd96aeb98f635e95fc122610021cd725db1d28'},
 'archive': {'bytes': 19495,
             'sha256': 'ed5fbaa7a632b9ed36c80ffcac348441c83b72717fdb235db2b7383c95afacc9'},
 'base64_bytes': 25996,
 'files': {'audit_nextest_0137.py': {'bytes': 8563,
                                     'sha256': '03fc242ae6ba3f5fa2fc948d3401e5f93a7a388ee9edb5b703183d6410aab8d2'},
           'launch_exact_rust_ci_01.py': {'bytes': 6165,
                                          'sha256': 'f913cb34b1962b93d6176912d20fb4e24480fc0057cd30349e59578dcbab5b4e'},
           'materialize_rust_ci_plan_01.py': {'bytes': 36835,
                                              'sha256': '3111c9566ad739694279ea378c2ade0c86caa991dcfa5552cfc42366f60aac57'},
           'package-manifest-01.json': {'bytes': 843,
                                        'sha256': 'd1183f1886da7ddcd82788779cb3feea0e42bf5ef85321e293f00de0d49969f4'},
           'run_rust_ci_01.py': {'bytes': 15182,
                                 'sha256': '6e4a71de3e38bbaa858ce0cdac0fec8fc1288343aec93759bf943370d8bb359b'}}}
ROOT = Path('/home/qian/hepta-runtime-optimization-20261105-r28')
DEST = ROOT / 'rust-ci-tools-01'
RECEIPT = ROOT / 'rust-ci-tools-install-01.json'
NAMES = {'materialize_rust_ci_plan_01.py', 'run_rust_ci_01.py', 'audit_nextest_0137.py',
         'package-manifest-01.json', 'launch_exact_rust_ci_01.py'}


def need(value, reason):
    if not value:
        raise ValueError(reason)


def identity(body):
    return {'bytes': len(body), 'sha256': hashlib.sha256(body).hexdigest()}


need(type(SPEC) is dict, 'actual reviewed installation package is not bound')
need(sys.platform == 'linux' and os.geteuid() != 0, 'native Linux operator required')
encoded = sys.stdin.buffer.read(SPEC['base64_bytes'] + 1)
need(len(encoded) == SPEC['base64_bytes'], 'fixed archive stdin length differs')
packed = base64.b64decode(encoded, validate=True)
need(identity(packed) == SPEC['archive'], 'fixed archive bytes/hash differ')
expanded = gzip.decompress(packed)
need(len(expanded) <= 512 * 1024, 'fixed tool archive exceeds expanded bound')
files = {}
with tarfile.open(fileobj=io.BytesIO(expanded), mode='r:') as archive:
    members = archive.getmembers()
    need(len(members) == 5 and {m.name for m in members} == NAMES, 'exact five-file archive required')
    for member in members:
        need(member.type == tarfile.REGTYPE and not member.linkname and not member.pax_headers
             and not member.issparse() and member.mode == 0o600 and member.name not in files
             and Path(member.name).name == member.name and 0 < member.size <= 65536,
             'unsafe, repeated or unexpected archive member')
        body = archive.extractfile(member).read()
        need(len(body) == member.size and identity(body) == SPEC['files'][member.name],
             'fixed member identity differs: ' + member.name)
        files[member.name] = body
    tail = expanded[archive.offset:]
    need(len(tail) >= 1024 and not any(tail), 'tar ending differs')
manifest = json.loads(files['package-manifest-01.json'])
need(set(SPEC['files']) == NAMES and manifest['schema'] == 'hepta-r28-exact-rust-ci-tools/v1'
     and manifest['files'] == {name: SPEC['files'][name] for name in NAMES if name not in {
         'package-manifest-01.json', 'launch_exact_rust_ci_01.py'}}
     and manifest['actual_qualification_job_id'] == SPEC['actual_pins']['JOB_ID']
     and manifest['executed'] is False and manifest['hosted_actions_passed'] is False,
     'frozen package manifest composition differs')
need(ROOT.resolve(strict=True) == ROOT, 'R28 root path is indirect')
root_info = ROOT.lstat()
need(stat.S_ISDIR(root_info.st_mode) and root_info.st_uid == os.geteuid(), 'R28 root is not an owned directory')
need(not os.path.lexists(DEST) and not os.path.lexists(RECEIPT), 'fresh tool directory and receipt required')
os.umask(0o077)
root_fd = os.open(ROOT, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW | os.O_CLOEXEC)
try:
    need((os.fstat(root_fd).st_dev, os.fstat(root_fd).st_ino) == (root_info.st_dev, root_info.st_ino),
         'root directory changed before install')
    os.mkdir(DEST.name, mode=0o700, dir_fd=root_fd)
    dest_fd = os.open(DEST.name, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW | os.O_CLOEXEC, dir_fd=root_fd)
    try:
        directory = os.fstat(dest_fd)
        for name, body in sorted(files.items()):
            fd = os.open(name, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW | os.O_CLOEXEC, 0o600, dir_fd=dest_fd)
            with os.fdopen(fd, 'wb') as stream:
                stream.write(body)
                stream.flush()
                os.fsync(stream.fileno())
            fd = os.open(name, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK | os.O_CLOEXEC, dir_fd=dest_fd)
            with os.fdopen(fd, 'rb') as stream:
                before = os.fstat(stream.fileno())
                actual = stream.read(65537)
                after = os.fstat(stream.fileno())
            fields = ('st_dev', 'st_ino', 'st_mode', 'st_uid', 'st_nlink', 'st_size', 'st_mtime_ns', 'st_ctime_ns')
            current = os.stat(name, dir_fd=dest_fd, follow_symlinks=False)
            need(stat.S_ISREG(before.st_mode) and before.st_uid == os.geteuid() and before.st_nlink == 1
                 and stat.S_IMODE(before.st_mode) == 0o600 and actual == body
                 and all(getattr(before, k) == getattr(after, k) == getattr(current, k) for k in fields),
                 'installed file readback/identity differs: ' + name)
        os.fsync(dest_fd)
        need(DEST.resolve(strict=True) == DEST and (DEST.lstat().st_dev, DEST.lstat().st_ino)
             == (directory.st_dev, directory.st_ino) and {p.name for p in DEST.iterdir()} == NAMES,
             'installed directory identity or inventory differs')
    finally:
        os.close(dest_fd)
    receipt = {'schema': 'hepta-r28-exact-rust-ci-tools-install/v1', 'passed': True,
               'destination': str(DEST), 'archive': SPEC['archive'], 'files': SPEC['files'],
               'actual_qualification_pins': SPEC['actual_pins'], 'original_file_count': 5,
               'packaged_tools_executed': False, 'cargo_executed': False,
               'source_or_compiler_cache_modified': False}
    receipt_raw = (json.dumps(receipt, sort_keys=True, indent=2) + '\n').encode()
    fd = os.open(RECEIPT.name, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW | os.O_CLOEXEC,
                 0o600, dir_fd=root_fd)
    with os.fdopen(fd, 'wb') as stream:
        stream.write(receipt_raw)
        stream.flush()
        os.fsync(stream.fileno())
    os.fsync(root_fd)
finally:
    os.close(root_fd)
print(json.dumps({'passed': True, 'receipt': {'path': str(RECEIPT), **identity(receipt_raw)},
                  'installed_regular_files': 5, 'packaged_tools_executed': False}, sort_keys=True), flush=True)
