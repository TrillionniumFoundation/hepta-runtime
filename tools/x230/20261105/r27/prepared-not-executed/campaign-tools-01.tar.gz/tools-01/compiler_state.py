"""Read bounded compiler identity metadata; never inspect argv or send signals."""
from pathlib import Path
import time

COMPILER_NAMES = frozenset({'cargo', 'rustc', 'rust-lld', 'ld.lld'})
DEAD_STATES = frozenset({'Z', 'X', 'x'})
MAX_RECORDS = 256


def parse_stat(raw, expected_pid):
    opening, closing = raw.find(' ('), raw.rfind(')')
    if opening < 1 or closing <= opening + 1:
        raise ValueError('invalid proc stat delimiters')
    pid = int(raw[:opening])
    fields = raw[closing + 1:].split()
    if pid != expected_pid or len(fields) < 20 or len(fields[0]) != 1:
        raise ValueError('invalid proc stat identity or fields')
    row = {'pid': pid, 'comm': raw[opening + 2:closing], 'state': fields[0],
           'ppid': int(fields[1]), 'process_group': int(fields[2]),
           'birth_ticks': int(fields[19])}
    if row['birth_ticks'] <= 0 or row['ppid'] < 0 or row['process_group'] < 0:
        raise ValueError('invalid proc stat numeric identity')
    return row


def compiler_snapshot(proc_root=Path('/proc')):
    started = time.monotonic_ns()
    records = []
    for directory in sorted(proc_root.glob('[0-9]*'), key=lambda path: int(path.name)):
        if len(records) >= MAX_RECORDS:
            records.append({'blocks': True, 'reason': 'compiler metadata record bound reached'})
            break
        pid = int(directory.name)
        try:
            comm = (directory / 'comm').read_text().strip()
        except (FileNotFoundError, ProcessLookupError):
            continue
        except (OSError, ValueError) as error:
            records.append({'pid': pid, 'blocks': True, 'reason': 'comm unreadable',
                            'error_type': type(error).__name__})
            continue
        if comm not in COMPILER_NAMES:
            continue
        try:
            first = parse_stat((directory / 'stat').read_text(), pid)
            uid_before = directory.stat().st_uid
            second = parse_stat((directory / 'stat').read_text(), pid)
            uid_after = directory.stat().st_uid
            if (first['birth_ticks'] != second['birth_ticks'] or
                    first['comm'] != comm or second['comm'] != comm or uid_before != uid_after):
                records.append({'pid': pid, 'comm': comm, 'blocks': True,
                                'reason': 'compiler identity changed while reading',
                                'before': {**first, 'uid': uid_before},
                                'after': {**second, 'uid': uid_after}})
            else:
                records.append({**second, 'uid': uid_after,
                                'blocks': second['state'] not in DEAD_STATES})
        except (FileNotFoundError, ProcessLookupError):
            records.append({'pid': pid, 'comm': comm, 'blocks': False,
                            'reason': 'compiler disappeared while reading'})
        except (OSError, ValueError) as error:
            records.append({'pid': pid, 'comm': comm, 'blocks': True,
                            'reason': 'compiler identity metadata unreadable',
                            'error_type': type(error).__name__})
    blocking = [row for row in records if row['blocks']]
    return {'schema': 'hepta-compiler-state-sample/v1',
            'started_monotonic_ns': started, 'finished_monotonic_ns': time.monotonic_ns(),
            'records': records, 'blocking_records': blocking, 'quiescent': not blocking,
            'cmdline_or_environment_read': False, 'signals_sent': 0}
