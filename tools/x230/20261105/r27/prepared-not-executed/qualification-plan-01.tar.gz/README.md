# R27 full qualification input

Status: locally prepared only. No Rust compilation, remote job, upload, qualification success, campaign acceptance or Git publication is asserted by this directory. The exact planned process_start arguments are in planned-native-request.json; its stable key must be reused if a submission result is ambiguous.

## Candidate

Accepted parent: R24 commit baab4def80be7af015b2e7a594cb302f66c4130e, source tree b71cac25e2c2138837f27f3c74f6a2dc5c56b565. The full available qualified snapshot was copied to source/ and the reviewed serializer patch applied. Its 282 regular files become 283, and the qualification compiler-input map grows from 220 to 221. Only src/mcp/runtime/ssh.rs is modified; src/mcp/runtime/ssh_observation_serialization_tests.rs is added. No R25 production change or cancellation reservation is inherited.

The launcher verifies the accepted remote R24 qualification report, source map, publication readback and all 19 original qualification scripts, copies that entire remote source tree, then writes only the two pinned files. Remote support files beyond the locally available snapshot are recorded; new build.rs, Cargo configuration/toolchain files and auto-discovered Rust tests or benches are rejected. Cargo.toml, Cargo.lock, rustfmt.toml, all src/ and examples/ inputs remain exactly pinned. The local snapshot has no README.md despite the package metadata reference; no package operation is requested, and the launcher retains any existing remote README when copying the actual accepted tree.

## Staging and exact execution

| Local file | Remote destination | Bytes | SHA-256 |
| --- | --- | ---: | --- |
| qualification-input-01.json | /home/qian/hepta-runtime-optimization-20261105-r25/tools/b96-r27-qualification-01-input.json | 48634 | 55b9014be05a9f303c2ad2d20a8b4f5d3c858896e11953baffb0b3b79de22186 |
| prepare_and_qualify_r27_01.py | /home/qian/hepta-runtime-optimization-20261105-r25/tools/b96_prepare_and_qualify_r27_01.py | 18639 | d308c4f90c627959c78d5bc6fd8f03974111d49ce1a08094dffad2bd62f0813e |

Create these two new staged files only after checking they are absent, or verifying an existing exact same identity. The launcher creates a fresh /home/qian/hepta-runtime-optimization-20261105-b96-r27. It refuses an existing root and does not delete or reuse it after failure. A changed attempt needs review and a new root/key. Source, target-build, qualification-01 and preparation-01.json live directly under that root. The planned native request provides two CPU equivalents, 5 GiB memory, nice 5 and 11700 seconds; the qualifier itself has a 10800-second aggregate limit.

## Prerequisites and private cache

Coordinate the free slot with the R26 owner and finish any component benchmark first. The launcher checks active cargo, rustc, rust-lld and ld.lld twice before qualification; these snapshots are not an exclusive host lock. Do not overlap another compilation or performance campaign.

The accepted R24 remote source and three pinned evidence files must remain available and unchanged. Rust +1.95.0, cargo/clippy/rustfmt and the existing offline cargo home at /home/qian/hepta-runtime-optimization-20261023/cargo-home-a32-a33-r02 must already exist. The launcher does not install or download dependencies.

The R24 build cache is absent. This launcher copies only third-party debug/release deps, build and .fingerprint files from /home/qian/hepta-runtime-optimization-20261105-r25/target-build-02. It excludes Hepta package fingerprints/build outputs, Hepta libraries/binaries/tests, all incremental output and examples. It creates ordinary private copies, never hardlinks and never deletes or changes the original cache. Cargo remains responsible for fingerprint freshness and recompilation. Required free space is the measured selected dependency bytes plus the complete source bytes plus 3 GiB of build/output reserve; actual measurements are saved in the preparation receipt. About 6.9 GiB was reported earlier, but present free space has not been checked locally.

## Gates and evidence

The unchanged R24 qualifier runs format, fmt-check, 19-script harness tests, offline locked all-target/all-feature clippy with warnings denied, test-build, isolated tests, independent isolated-test audit, and offline locked all-feature release binaries/examples. Rust test cases run once in their own processes with the original 180-second limit. Expected totals are 1652 passed, 0 failed, 34 ignored, 1686 selected and 0 retries; the seven serializer tests must each appear as a passed original attempt. Formatter changes are permitted only in the two candidate files. Qualification records the actual formatted source and three retained release binary hashes; those values must be collected after execution.

The preparation receipt schema is hepta-r27-accepted-r24-serializer-preparation/v1. On genuine completed success it contains passed=true, candidate_qualified=true, candidate_adopted=false, parent_source_qualified=true, parent_candidate_adopted=true, parent_inputs_unchanged=true and r25_source_inherited=false. It also contains bound_parent_inputs, source_before, candidate_compilation_inputs, source_changes, source_tested, source_after, formatter_changed_paths, harness_before/after, tests, test_summary, new_tests, binaries, input, launcher and qualification_report identities. Failure retains passed=false and candidate_qualified=false with an error and original output; it is never retried automatically. Process-group cleanup records an attempt for this qualification group; it is not a proof that every detached test process is absent. In particular, the original qualifier can kill a timed-out stage runner before that runner cleans its separate test group. The parent must separately verify terminal native-job cleanup, the terminal DTO and durable output before using these receipts. Qualification does not decide performance acceptance or Git publication.

Local verification completed: launcher Python syntax; original qualified compiler map; complete two-file source delta; payload byte/SHA identity; unchanged 19-script harness; expected seven test names and baseline test counts. A local Python-only smoke also verified that a failed qualifier leader can exit before a remaining runner, the runner receives TERM grace, and its detached fixture process is reaped. No Rust test result is claimed.
