#!/usr/bin/env python3
# Copyright 2026 TrillionniumFoundation
# SPDX-License-Identifier: Apache-2.0
"""Qualify accepted R24 plus the borrowed serializer in a new private work tree."""
import argparse
import datetime
import hashlib
import json
import os
from pathlib import Path
import shutil
import signal
import stat
import subprocess
import time
import traceback

ROOT = Path('/home/qian/hepta-runtime-optimization-20261105-b96-r27')
PARENT = Path('/home/qian/hepta-runtime-optimization-20261105-r24')
BASE_SOURCE = PARENT / 'source'
CACHE = Path('/home/qian/hepta-runtime-optimization-20261105-r25/target-build-02')
SOURCE = ROOT / 'source'
TARGET = ROOT / 'target-build'
OUTPUT = ROOT / 'qualification-01'
INPUT = Path('/home/qian/hepta-runtime-optimization-20261105-r25/tools/b96-r27-qualification-01-input.json')
CARGO_HOME = Path('/home/qian/hepta-runtime-optimization-20261023/cargo-home-a32-a33-r02')
ACCEPTED_COMMIT = 'baab4def80be7af015b2e7a594cb302f66c4130e'
PARENT_REPORT_SHA = 'bf0c5814d28b163e4a90405026cd4d90e399370d1f910f8ac48cb580af1e4971'
PARENT_MAP_SHA = 'c3415beaf7697b3eb07a763ef24f424138de80af31acfd6c224cf682f3c67cbd'
PUBLICATION_SHA = '38866c01fac54133c8a88e25bee90ea4a551e7273614f493bf44522a8273d3ca'
MODIFIED = ['src/mcp/runtime/ssh.rs']
ADDED = ['src/mcp/runtime/ssh_observation_serialization_tests.rs']
STAGES = ['format', 'fmt-check', 'harness-tests', 'clippy', 'test-build',
          'isolated-tests', 'audit-isolated-tests', 'release']
PROJECT_TARGETS = ('hepta_runtime', 'hepta_runtime_jobctl',
                   'hepta_effect_ownerctl', 'native_process_driver')


def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def encoded(value):
    return (json.dumps(value, sort_keys=True, indent=2, allow_nan=False) + '\n').encode()


def digest(value):
    return hashlib.sha256(value).hexdigest()


def stamp(value):
    return tuple(getattr(value, key) for key in ('st_dev', 'st_ino', 'st_mode',
                 'st_uid', 'st_nlink', 'st_size', 'st_mtime_ns', 'st_ctime_ns'))


def read(path, expected=None):
    path = Path(path)
    assert path.is_absolute() and path.resolve(strict=True) == path, str(path)
    with path.open('rb') as stream:
        before = os.fstat(stream.fileno())
        assert stat.S_ISREG(before.st_mode) and before.st_uid == os.geteuid()
        raw = stream.read()
        assert stamp(before) == stamp(os.fstat(stream.fileno())) == stamp(path.lstat())
    identity = {'path': str(path), 'bytes': len(raw), 'sha256': digest(raw)}
    assert expected is None or identity['sha256'] == expected, str(path)
    return identity, raw


def source_map(root):
    paths = [root / name for name in ('Cargo.toml', 'Cargo.lock', 'rustfmt.toml')]
    for name in ('src', 'examples'):
        paths.extend(path for path in (root / name).rglob('*') if path.is_file())
    return {path.relative_to(root).as_posix(): read(path)[0]['sha256']
            for path in sorted(paths)}


def harness_map(root):
    return {path.name: read(path)[0]['sha256']
            for path in sorted((root / 'tools/x230/20261028').glob('*.py'))}


def full_map(root):
    result = {}
    for path in sorted(root.rglob('*')):
        mode = path.lstat().st_mode
        assert stat.S_ISREG(mode) or stat.S_ISDIR(mode), str(path)
        if stat.S_ISREG(mode):
            item, _ = read(path)
            result[path.relative_to(root).as_posix()] = {
                'bytes': item['bytes'], 'sha256': item['sha256']}
    return result


def reject_unaccounted_cargo_inputs(root):
    # These inputs are absent from the accepted compiler/harness snapshot.
    # Extra documentation is harmless; Cargo auto-discovery/configuration is not.
    for name in ('build.rs', '.cargo/config', '.cargo/config.toml',
                 'rust-toolchain', 'rust-toolchain.toml'):
        assert not os.path.lexists(root / name), 'unaccounted Cargo input: ' + name
    for name in ('tests', 'benches'):
        assert not list((root / name).rglob('*.rs')), 'unaccounted Cargo targets: ' + name


def compiler_state():
    active = []
    for path in Path('/proc').glob('[0-9]*/comm'):
        try:
            name = path.read_text().strip()
            if name in ('cargo', 'rustc', 'rust-lld', 'ld.lld'):
                raw = (path.parent / 'stat').read_text()
                state = raw[raw.rfind(')') + 2:].split()[0]
                if state not in ('Z', 'X', 'x'):
                    active.append({'pid': int(path.parent.name), 'name': name, 'state': state})
        except (FileNotFoundError, ProcessLookupError):
            pass
    return {'utc': utc(), 'active': active}


def dependency_cache_files():
    files, excluded = [], 0
    assert CACHE.is_dir() and CACHE.resolve(strict=True) == CACHE
    for profile in ('debug', 'release'):
        assert (CACHE / profile / 'deps').is_dir(), profile + ' dependency cache missing'
        for subtree in ('deps', 'build', '.fingerprint'):
            for path in sorted((CACHE / profile / subtree).rglob('*')):
                parts = path.relative_to(CACHE).parts
                own = parts[2].startswith('hepta-runtime-') if subtree != 'deps' else False
                if subtree == 'deps':
                    name = path.name.removeprefix('lib')
                    own = any(name == target or name.startswith(target + '-')
                              or name.startswith(target + '.') for target in PROJECT_TARGETS)
                if own:
                    excluded += 1
                    continue
                before = path.lstat()
                assert stat.S_ISREG(before.st_mode) or stat.S_ISDIR(before.st_mode), str(path)
                if stat.S_ISREG(before.st_mode):
                    assert path.resolve(strict=True) == path
                    files.append((path, before))
    assert files, 'empty dependency cache selection'
    return files, excluded


def qualification_process(argv, receipt):
    child = subprocess.Popen(argv, cwd=SOURCE, start_new_session=True)
    receipt['qualification_pid'] = child.pid

    def group_members():
        members = []
        for path in Path('/proc').glob('[0-9]*/stat'):
            try:
                raw = path.read_text()
            except (FileNotFoundError, ProcessLookupError):
                continue
            fields = raw[raw.rfind(')') + 2:].split()
            if int(fields[2]) == child.pid and fields[0] not in ('Z', 'X', 'x'):
                members.append(int(path.parent.name))
        return members

    try:
        return child.wait(timeout=10800)
    finally:
        # The qualifier leader can exit first. Give its remaining group members
        # time to handle TERM; the isolated runner cleans its separate test group.
        if group_members():
            try:
                os.killpg(child.pid, signal.SIGTERM)
            except ProcessLookupError:
                pass
            deadline = time.monotonic() + 30
            while group_members() and time.monotonic() < deadline:
                child.poll()
                time.sleep(0.1)
            if group_members():
                try:
                    os.killpg(child.pid, signal.SIGKILL)
                except ProcessLookupError:
                    pass
        try:
            child.wait(timeout=10)
        except subprocess.TimeoutExpired:
            receipt['qualification_cleanup_incomplete'] = True
        receipt['qualification_returncode'] = child.returncode
        receipt['qualification_group_cleanup_attempted'] = True
        receipt['qualification_group_cleanup_scope'] = 'qualification process group only'


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--input-sha256', required=True)
    parser.add_argument('--launcher-sha256', required=True)
    args = parser.parse_args()
    launcher, _ = read(Path(__file__).resolve(), args.launcher_sha256)
    input_identity, input_raw = read(INPUT, args.input_sha256)
    payload = json.loads(input_raw)
    assert payload['schema'] == 'hepta-r27-serializer-qualification-input/v1'
    assert payload['accepted_commit'] == ACCEPTED_COMMIT
    assert payload['allowed_modified_paths'] == MODIFIED
    assert payload['allowed_added_paths'] == ADDED and not payload['allowed_removed_paths']
    assert not os.path.lexists(ROOT), str(ROOT)
    ROOT.mkdir(mode=0o700)
    receipt = {'schema': 'hepta-r27-accepted-r24-serializer-preparation/v1',
               'started_utc': utc(), 'passed': False, 'candidate_qualified': False,
               'candidate_adopted': False, 'accepted_commit': ACCEPTED_COMMIT,
               'production_selection': payload['production_selection'],
               'source': str(SOURCE), 'target': str(TARGET), 'qualification_output': str(OUTPUT),
               'input': input_identity, 'launcher': launcher,
               'automatic_test_retries': 0, 'production_services_modified': False,
               'shared_hardlinks_created': False, 'cache_source': str(CACHE),
               'cache_policy': payload['cache_policy'], 'r25_source_inherited': False,
               'allowed_modified_paths': MODIFIED, 'allowed_added_paths': ADDED}
    (ROOT / 'qualification-input-01.json').write_bytes(input_raw)

    def save():
        (ROOT / 'preparation-01.next').write_bytes(encoded(receipt))
        os.replace(ROOT / 'preparation-01.next', ROOT / 'preparation-01.json')

    bound = {}

    def bind(path, expected):
        item, raw = read(path, expected)
        bound[str(path)] = item
        return json.loads(raw)

    result_code = 1
    signal.signal(signal.SIGTERM, lambda *_: (_ for _ in ()).throw(KeyboardInterrupt()))
    try:
        parent = bind(PARENT / 'qualification-01/report.json', PARENT_REPORT_SHA)
        parent_map = bind(PARENT / 'qualification-01/source-map.json', PARENT_MAP_SHA)
        publication = bind(PARENT / 'final-publication-readback.json', PUBLICATION_SHA)
        assert parent['qualified'] is True and parent['finished_utc']
        assert parent['source_tested'] == parent['source_after'] == parent_map == source_map(BASE_SOURCE)
        assert len(parent_map) == 220
        assert [row['name'] for row in parent['stages']] == STAGES
        assert all(row['returncode'] == 0 for row in parent['stages'])
        assert parent['automatic_test_retries'] == 0
        assert publication['commit'] == ACCEPTED_COMMIT
        assert publication['verified'] is True and publication['candidate_adopted'] is True
        assert publication['qualification_report_sha256'] == PARENT_REPORT_SHA
        assert digest(encoded(parent_map)) == payload['baseline_source_map_sha256']
        harness = parent['harness_after']
        assert len(harness) == 19 and parent['harness_before'] == harness == harness_map(BASE_SOURCE)
        reject_unaccounted_cargo_inputs(BASE_SOURCE)
        baseline_full = full_map(BASE_SOURCE)
        receipt.update(parent_source_qualified=True, parent_candidate_adopted=True,
                       source_before=parent_map, harness_before=harness,
                       baseline_full_file_map_sha256=digest(encoded(baseline_full)),
                       baseline_support_extra_paths=sorted(set(baseline_full) - set(payload['known_source_paths'])))
        (ROOT / 'baseline-full-file-map.json').write_bytes(encoded(baseline_full))
        first = compiler_state()
        receipt['compiler_checks'] = [first]
        assert not first['active'], 'compiler active; qualification not started'
        cache_files, excluded = dependency_cache_files()
        cache_bytes = sum(info.st_size for _, info in cache_files)
        source_bytes = sum(row['bytes'] for row in baseline_full.values())
        free = shutil.disk_usage(ROOT).free
        required = cache_bytes + source_bytes + 3 * 1024**3
        receipt.update(cache_files=len(cache_files), cache_bytes=cache_bytes,
                       cache_project_entries_excluded=excluded, disk_free_before_bytes=free,
                       disk_required_bytes=required, disk_reserve_bytes=3 * 1024**3)
        save()
        assert free >= required, 'insufficient space for private dependency cache plus 3 GiB reserve'
        shutil.copytree(BASE_SOURCE, SOURCE)
        assert full_map(SOURCE) == baseline_full
        expected = dict(parent_map)
        expected_full = dict(baseline_full)
        assert [row['path'] for row in payload['files']] == MODIFIED + ADDED
        for row in payload['files']:
            path = SOURCE / row['path']
            if row['before_sha256'] is None:
                assert not os.path.lexists(path)
            else:
                read(path, row['before_sha256'])
            raw = row['text'].encode()
            assert len(raw) == row['bytes'] and digest(raw) == row['sha256']
            path.write_bytes(raw)
            expected[row['path']] = row['sha256']
            expected_full[row['path']] = {'bytes': row['bytes'], 'sha256': row['sha256']}
        assert len(expected) == 221 and source_map(SOURCE) == expected
        assert digest(encoded(expected)) == payload['candidate_source_map_sha256']
        assert full_map(SOURCE) == expected_full and harness_map(SOURCE) == harness
        receipt.update(candidate_compilation_inputs=expected,
                       candidate_source_map_sha256=digest(encoded(expected)),
                       source_changes=[{k: row[k] for k in ('path', 'before_sha256', 'sha256', 'bytes')}
                                       for row in payload['files']])
        (ROOT / 'candidate-input-source-map.json').write_bytes(encoded(expected))
        copy_started = time.monotonic()
        TARGET.mkdir(mode=0o700)
        for path, before in cache_files:
            destination = TARGET / path.relative_to(CACHE)
            destination.parent.mkdir(parents=True, exist_ok=True)
            assert stamp(path.stat()) == stamp(before), 'cache changed before copy: ' + str(path)
            shutil.copy2(path, destination)
            assert stamp(path.stat()) == stamp(before), 'cache changed during copy: ' + str(path)
            assert destination.stat().st_nlink == 1 and destination.stat().st_size == before.st_size
        receipt['private_cache_copy_seconds'] = time.monotonic() - copy_started
        second = compiler_state()
        receipt['compiler_checks'].append(second)
        assert not second['active'], 'compiler started during preparation; qualification not started'
        assert source_map(BASE_SOURCE) == parent_map and harness_map(BASE_SOURCE) == harness
        assert full_map(BASE_SOURCE) == baseline_full
        argv = ['/usr/bin/python3', '-B', str(SOURCE / 'tools/x230/20261028/qualify.py'),
                '--source', str(SOURCE), '--output', str(OUTPUT), '--target', str(TARGET),
                '--cargo-home', str(CARGO_HOME), '--jobs', '2', '--stage-timeout', '3600']
        receipt['qualification_argv'] = argv
        save()
        print(json.dumps({'prepared': True, 'compilation_inputs': 221,
                          'cache_bytes': cache_bytes, 'automatic_test_retries': 0}), flush=True)
        result_code = qualification_process(argv, receipt)
        receipt['qualification_returncode'] = result_code
        report_identity, report_raw = read(OUTPUT / 'report.json')
        qualified = json.loads(report_raw)
        receipt['qualification_report'] = report_identity
        assert source_map(BASE_SOURCE) == parent_map and harness_map(BASE_SOURCE) == harness
        assert full_map(BASE_SOURCE) == baseline_full
        for path, identity in bound.items():
            assert read(path)[0] == identity, 'accepted parent evidence changed: ' + path
        read(INPUT, args.input_sha256)
        read(Path(__file__).resolve(), args.launcher_sha256)
        receipt['parent_inputs_unchanged'] = True
        if result_code != 0:
            assert qualified['qualified'] is False
            raise RuntimeError('original qualification failed; no retry')
        assert qualified['qualified'] is True and qualified['finished_utc']
        assert qualified['source_input'] == expected
        assert [row['name'] for row in qualified['stages']] == STAGES
        assert all(row['returncode'] == 0 for row in qualified['stages'])
        assert qualified['automatic_test_retries'] == 0
        actual = source_map(SOURCE)
        assert qualified['source_tested'] == qualified['source_after'] == actual
        assert set(actual) == set(expected)
        formatted = sorted(path for path in expected if expected[path] != actual[path])
        assert set(formatted).issubset(MODIFIED + ADDED), formatted
        assert qualified['harness_before'] == qualified['harness_after'] == harness_map(SOURCE) == harness
        reject_unaccounted_cargo_inputs(SOURCE)
        summary_identity, summary_raw = read(OUTPUT / 'isolated-tests/summary.json')
        summary = json.loads(summary_raw)
        assert summary['success'] is True
        assert {key: summary[key] for key in payload['expected_tests']} == payload['expected_tests']
        new_tests = [json.loads(line) for line in (OUTPUT / 'isolated-tests/tests.jsonl').read_text().splitlines()]
        new_tests = [row for row in new_tests if row['name'] in payload['added_tests']]
        assert len(new_tests) == 7 and {row['name'] for row in new_tests} == set(payload['added_tests'])
        assert all(row['status'] == 'passed' and row['executed'] is True and row['attempt'] == 1
                   for row in new_tests)
        for item in qualified['binaries'].values():
            read(Path(item['path']), item['sha256'])
        receipt.update(passed=True, candidate_qualified=True, tests=summary,
                       test_summary=summary_identity, new_tests=new_tests,
                       source_tested=actual, source_after=actual, formatter_changed_paths=formatted,
                       harness_after=harness, binaries=qualified['binaries'])
        (ROOT / 'candidate-tested-full-file-map.json').write_bytes(encoded(full_map(SOURCE)))
        result_code = 0
    except BaseException as error:
        receipt['error'] = f'{type(error).__name__}: {error}'
        receipt['error_trace'] = traceback.format_exc()
        result_code = 1
    finally:
        receipt['bound_parent_inputs'] = bound
        receipt['finished_utc'] = utc()
        save()
        print(json.dumps({'preparation_and_qualification_passed': receipt['passed'],
                          'candidate_qualified': receipt['candidate_qualified'],
                          'candidate_adopted': False, 'error': receipt.get('error')}), flush=True)
    return result_code


if __name__ == '__main__':
    raise SystemExit(main())
