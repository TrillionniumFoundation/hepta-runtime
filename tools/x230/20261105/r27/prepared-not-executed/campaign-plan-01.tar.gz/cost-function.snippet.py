def full_local_cost_breakdown(raw, analysis):
    """Reuse the R24 capacity audit's raw stat arithmetic; no extra workload."""
    cells = []
    for round_row in raw["rounds"]:
        for cell in round_row["cells"]:
            timing = cell["raw_timing"]
            before, after = timing["controller_before"], timing["controller_after"]
            need((before["pid"], before["birth_ticks"]) == (after["pid"], after["birth_ticks"]),
                 "child CPU counter controller generation differs")
            ticks = before["clock_ticks_per_second"]
            need(type(ticks) is int and ticks > 0 and ticks == after["clock_ticks_per_second"],
                 "child CPU counter frequency differs")
            parsed = []
            for snapshot in (before, after):
                value = snapshot["raw_stat"]
                fields = value[value.rfind(")") + 2:].split()
                need(int(value[:value.index("(")].strip()) == snapshot["pid"]
                     and int(fields[19]) == snapshot["birth_ticks"]
                     and int(fields[11]) == snapshot["utime_ticks"]
                     and int(fields[12]) == snapshot["stime_ticks"],
                     "raw stat differs from retained controller counters")
                parsed.append(fields)
            a, b = parsed
            delta = [int(b[i]) - int(a[i]) for i in (11, 12, 13, 14)]
            need(all(n >= 0 for n in delta), "negative raw controller/child CPU delta")
            controller = (delta[0] + delta[1]) / ticks
            children = (delta[2] + delta[3]) / ticks
            wall = (timing["end_monotonic_ns"] - timing["start_monotonic_ns"]) / 1e9
            need(abs(controller - cell["controller_cpu_seconds"]) < 1e-9
                 and abs(wall - cell["seconds"]) < 1e-9 and wall > 0,
                 "cost counters or wall differ from original native timing")
            cells.append({"round": round_row["index"], "arm": round_row["version"],
                "concurrency": cell["concurrency"], "calls": cell["calls"], "wall_seconds": wall,
                "controller_cpu_seconds": controller, "waited_child_cpu_seconds": children,
                "controller_plus_waited_child_cpu_seconds": controller + children,
                "controller_user_system_ticks": delta[:2], "waited_child_user_system_ticks": delta[2:],
                "clock_ticks_per_second": ticks, "controller_before": before, "controller_after": after,
                "controller_threads_before_after": [int(a[17]), int(b[17])],
                "sampled_cpu_seconds_delta_by_scope_not_added": cell["sampled_cpu_seconds_delta_by_scope"]})
    aggregate = []
    for arm in "AB":
        for concurrency in (1, 8, 16):
            rows = [r for r in cells if r["arm"] == arm and r["concurrency"] == concurrency]
            need(len(rows) == 2 and all(r["calls"] == 192 for r in rows), "full-cost cell set differs")
            total = lambda key: sum(row[key] for row in rows)
            calls, wall = total("calls"), total("wall_seconds")
            aggregate.append({"arm": arm, "concurrency": concurrency, "calls": calls,
                "wall_seconds": wall, "successful_calls_per_second": calls / wall,
                "controller_cpu_ms_per_call": 1000 * total("controller_cpu_seconds") / calls,
                "waited_child_cpu_ms_per_call": 1000 * total("waited_child_cpu_seconds") / calls,
                "controller_plus_waited_child_cpu_ms_per_call": 1000 * total("controller_plus_waited_child_cpu_seconds") / calls,
                "controller_plus_waited_child_cpu_per_wall_second": total("controller_plus_waited_child_cpu_seconds") / wall})
    ratios = []
    for concurrency in (1, 8, 16):
        arms = {row["arm"]: row for row in aggregate if row["concurrency"] == concurrency}
        keys = ("controller_cpu_ms_per_call", "waited_child_cpu_ms_per_call",
                "controller_plus_waited_child_cpu_ms_per_call")
        ratios.append({"concurrency": concurrency,
                       "B_over_A": {key: arms["B"][key] / arms["A"][key] if arms["A"][key] else None for key in keys}})
    resource_keys = ("peaks", "metric_samples", "sampled_cpu_seconds_by_scope", "samples",
                     "sampler_error", "error_counts", "trace", "limitations")
    return {"verified_from_original_counters": True, "new_workload_calls": 0,
            "cells": cells, "aggregate": aggregate, "ratios_diagnostic_only": ratios,
            "all_measurement_and_restart_resources": [
                {"round": r["round"], "arm": r["version"], "phase": r["phase"],
                 **{key: r["observations"].get(key) for key in resource_keys}}
                for r in analysis["resources"]],
            "limitations": [
                "cutime/cstime charge children at reap; endpoint accounting error can have either sign.",
                "Controller plus waited-child CPU excludes live-master, harness, unrelated and remote-helper CPU.",
                "Sampled SSH lifetime CPU overlaps waited-child CPU and is never added to it.",
                "100 ms descendant samples may miss short-lived processes; RSS is a non-atomic sum with shared-page duplication.",
                "Zero without available metric samples is unavailable, not a zero resource cost.",
                "These cost columns add no new performance threshold and cannot establish exact whole-cluster efficiency."]}


