#!/usr/bin/env python3
"""Local-only provenance/derivation checks and historical arithmetic replay."""
import ast
import copy
import hashlib
import importlib.util
import json
from pathlib import Path
import subprocess
import sys
import tarfile

HERE = Path(__file__).resolve().parent
OLD = Path('/workspace/scratch/806ba5f52f94')
REVIEWED = OLD / 'r25-lifecycle-audit/r26-tools-02'
sys.dont_write_bytecode = True


def module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    value = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(value)
    return value


def functions(text):
    return {node.name: node for node in ast.walk(ast.parse(text)) if isinstance(node, ast.FunctionDef)}


def equal_ast(left, right):
    assert ast.dump(left, include_attributes=False) == ast.dump(right, include_attributes=False)


def rejects(callback):
    try:
        callback()
    except (RuntimeError, ValueError):
        return
    raise AssertionError('invalid synthetic input accepted')


def main():
    derive = module('r27_local_derive', HERE/'derive_local_tools.py')
    parent = module('r27_local_parent', HERE/'tools-01/r27_campaign.py')
    preparer = module('r27_local_preparer', HERE/'tools-01/prepare_campaign_inputs.py')
    summary = module('r27_local_summary', HERE/'tools-01/summarize_r27_campaign.py')
    example = json.loads((HERE/'campaign-inputs-01.example.json').read_text())
    for path in (HERE/'tools-01').glob('*.py'):
        ast.parse(path.read_text())
    before = functions(derive.version((REVIEWED/'tools-02/r26_campaign.py').read_text()).replace('observation_gate_passed', 'adoption_passed'))
    after = functions((HERE/'tools-01/r27_campaign.py').read_text())
    preserved = ['checked','create','save','private_directory','source_inputs','machine_snapshot',
                 'compiler_activity','process_identity','group_present','verify_composed_qualification',
                 'qualification_projection','verify_baseline_enablement','bind_compiler_monitor_inputs',
                 'prepare_compiler_monitor','finish_compiler_monitor','verify_completed_compiler_monitor','run_stage']
    for name in preserved:
        equal_ast(before[name], after[name])
    wanted = ast.get_source_segment(derive.version((REVIEWED/'tools-02/r26_campaign.py').read_text()),before['commands'])
    wanted = (wanted.replace('summarize_r25_campaign.py','summarize_r27_campaign.py')
                    .replace('("r27-cancel-recovery-" + attempt)','("b96-r27-cancel-recovery-" + attempt)')
                    .replace('("h26" + prefix + attempt)','("h96r27" + prefix + attempt)')
                    .replace('("observation-summary", py +','("campaign-summary", py +'))
    equal_ast(ast.parse(wanted).body[0],after['commands'])
    main_node = after['main']
    cooling = next(n for n in ast.walk(main_node) if isinstance(n, ast.Assign)
                   and any(isinstance(t, ast.Name) and t.id == 'cooling' for t in n.targets))
    socket_loop = next(n for n in ast.walk(main_node) if isinstance(n, ast.For)
                       and isinstance(n.iter, ast.Call) and isinstance(n.iter.func, ast.Attribute)
                       and isinstance(n.iter.func.value, ast.Name) and n.iter.func.value.id == 'sockets')
    creation = next(n for n in ast.walk(socket_loop) if isinstance(n, ast.Call)
                    and isinstance(n.func, ast.Name) and n.func.id == 'private_directory')
    assert creation.lineno < cooling.lineno and any(k.arg == 'create_new' and isinstance(k.value, ast.Constant)
                                                  and k.value.value is True for k in creation.keywords)
    rechecks = [n for n in ast.walk(main_node) if isinstance(n, ast.Call)
                and isinstance(n.func, ast.Name) and n.func.id == 'private_directory' and n.args
                and isinstance(n.args[0], ast.Subscript) and isinstance(n.args[0].value, ast.Name)
                and n.args[0].value.id == 'workload_sockets']
    assert len(rechecks) == 1 and not rechecks[0].keywords and rechecks[0].lineno > cooling.lineno
    old_summary=module('r24_local_original_summary',OLD/'benchmark-r24/summarize_r24_campaign.py')
    assert summary.GATES == old_summary.GATES == json.loads((HERE/'preregistration.json').read_text())['fixed_performance_gates']
    original_gate = functions((OLD/'benchmark-r24/summarize_r24_campaign.py').read_text())['summarize']
    new_gate = copy.deepcopy(functions((HERE/'tools-01/summarize_r27_campaign.py').read_text())['summarize'])
    class GateMetadata(ast.NodeTransformer):
        def visit_Constant(self, node):
            if node.value == 'hepta-r27-campaign-gates/v1': node.value = 'hepta-r24-campaign-gates/v1'
            return node
        def visit_Dict(self, node):
            self.generic_visit(node)
            pairs = [(key, value) for key, value in zip(node.keys, node.values)
                     if not (isinstance(key, ast.Constant) and key.value == 'full_local_costs')]
            node.keys, node.values = [k for k, v in pairs], [v for k, v in pairs]
            return node
    equal_ast(original_gate, GateMetadata().visit(new_gate))
    for name in ('compiler_monitor.py','compiler_state.py','validate_compiler_monitor.py'):
        assert (HERE/'tools-01'/name).read_bytes() == (REVIEWED/'tools-02'/name).read_bytes()
    policy=json.loads((HERE/'tools-01/compiler-monitor-policy-01.json').read_text())
    assert policy==parent.COMPILER_MONITOR_POLICY
    assert policy['limits']==json.loads((REVIEWED/'tools-02/compiler-monitor-policy-01.json').read_text())['limits']
    preparer.validate_template(example)
    invented=copy.deepcopy(example); invented['candidate_binaries']['hepta-runtime']={'bytes':1,'sha256':'0'*64}
    rejects(lambda:preparer.validate_template(invented))
    previous=json.loads((OLD/'r24-results/qualification-report.json').read_text())
    source_before=previous['source_after']
    contract=parent.R27_QUALIFICATION_CONTRACT
    expected=dict(source_before)
    for change in contract['source_changes']: expected[change['path']]=change['sha256']
    tests=dict(success=True,**contract['expected_tests'])
    fake_job='feed0000001-cafe-beef'
    terminal={'job_id':fake_job,'state':'succeeded','exit_code':0,'automatic_retry':False,'timed_out':False,'cancelled':False,
              'output_complete':True,'output_durable':True,'terminal_publication_confirmed':True,'terminal_publication_protocol':1,
              'log_synced':{'stdout':True,'stderr':True},'log_errors':{'stdout':None,'stderr':None},
              'log_truncated':{'stdout':False,'stderr':False},'log_bytes':{s:{'seen':1,'stored':1} for s in ('stdout','stderr')}}
    qualified=copy.deepcopy(previous)
    qualified.update(source=str(parent.SOURCE),source_input=expected,source_tested=expected,source_after=expected,
                     binaries={name:{'path':str(parent.CANDIDATE_DIR/name),'sha256':'0'*64} for name in parent.BINARY_NAMES})
    prep={'schema':'hepta-r27-accepted-r24-serializer-preparation/v1','accepted_commit':contract['accepted_commit'],
          'production_selection':'accepted R24 plus borrowed observation serializer only','finished_utc':'SYNTHETIC-NOT-EXECUTED',
          'passed':True,'candidate_qualified':True,'parent_source_qualified':True,'parent_candidate_adopted':True,'parent_inputs_unchanged':True,
          'candidate_adopted':False,'production_services_modified':False,'shared_hardlinks_created':False,'r25_source_inherited':False,
          'source':str(parent.SOURCE),'target':str(parent.ROOT/'target-build'),'qualification_output':str(parent.CANDIDATE_DIR),
          'launcher':contract['launcher'],'input':contract['input'],'qualification_returncode':0,'automatic_test_retries':0,
          'source_changes':contract['source_changes'],'allowed_modified_paths':['src/mcp/runtime/ssh.rs'],
          'allowed_added_paths':['src/mcp/runtime/ssh_observation_serialization_tests.rs'],'source_before':source_before,
          'candidate_compilation_inputs':expected,'source_tested':expected,'source_after':expected,'formatter_changed_paths':[],
          'harness_before':previous['harness_after'],'harness_after':previous['harness_after'],'tests':tests,
          'new_tests':[{'name':name,'status':'passed','executed':True,'attempt':1} for name in contract['added_tests']],
          'binaries':qualified['binaries']}
    assert parent.verify_r27_candidate_preparation(prep,terminal,fake_job,qualified,tests)['passed'] is True
    rejects(lambda:parent.verify_r27_candidate_preparation(prep,terminal,None,qualified,tests))
    inherited=copy.deepcopy(prep); inherited['r25_source_inherited']=True
    rejects(lambda:parent.verify_r27_candidate_preparation(inherited,terminal,fake_job,qualified,tests))
    reserve=copy.deepcopy(prep); reserve['candidate_compilation_inputs']['src/mcp/runtime/jobs.rs']='783f162ffd9be6165da63cd40e4ce28844496c53c8c651926fc359c93904e952'
    rejects(lambda:parent.verify_r27_candidate_preparation(reserve,terminal,fake_job,qualified,tests))
    missing=copy.deepcopy(prep); missing['new_tests']=missing['new_tests'][:-1]
    rejects(lambda:parent.verify_r27_candidate_preparation(missing,terminal,fake_job,qualified,tests))
    incomplete=copy.deepcopy(terminal); incomplete['output_durable']=False
    rejects(lambda:parent.verify_r27_candidate_preparation(prep,incomplete,fake_job,qualified,tests))
    with tarfile.open(OLD/'r24-evidence/campaign-01.tar.gz') as archive:
        raw=json.load(archive.extractfile('campaign/native-observation/report.json'))
    analysis=json.loads((OLD/'r24-results/native-analysis.json').read_text())
    costs=summary.full_local_cost_breakdown(raw,analysis)
    historical=json.loads((OLD/'r25-capacity-audit/r24-capacity-evidence.json').read_text())
    for row in costs['aggregate']:
        prior=next(r for r in historical['aggregate'] if r['version']==row['arm'] and r['concurrency']==row['concurrency'])
        assert abs(row['controller_plus_waited_child_cpu_ms_per_call']-prior['controller_plus_waited_children_cpu_ms_per_call'])<1e-12
        assert abs(row['controller_plus_waited_child_cpu_per_wall_second']-prior['controller_plus_waited_children_cpu_per_wall_second'])<1e-12
    help_results=[]
    for name in ('r27_campaign.py','prepare_campaign_inputs.py','summarize_r27_campaign.py'):
        process=subprocess.run([sys.executable,'-B',str(HERE/'tools-01'/name),'--help'],capture_output=True,text=True)
        assert process.returncode==0,(name,process.stderr)
        help_results.append({'file':name,'returncode':process.returncode})
    result={'schema':'hepta-r27-local-campaign-validation/v1','prepared_only':True,'remote_calls':0,'rust_compilations':0,
            'live_process_sampler_or_workload_started':False,'preserved_function_asts_after_version_and_gate_field_normalization':preserved,
            'commands_ast_unchanged_except_paths_and_summary_label':True,'own_socket_parents_created_before_cooling_and_rechecked_before_stages':True,'fixed_gates_equal_original_r24':True,'original_summary_gate_ast_preserved_except_schema_and_cost_column':True,
            'three_compiler_monitor_sources_byte_identical':True,'compiler_limits_unchanged':True,
            'future_pin_refusal_and_five_invalid_synthetic_preparation_checks':True,
            'synthetic_success_is_not_an_actual_qualification':True,
            'historical_cost_fixture':'accepted R24 campaign A=R22/B=R24, not R27 evidence',
            'all_six_cost_aggregates_equal_existing_r24_capacity_audit':True,'historical_cells':len(costs['cells']),
            'historical_resource_generations':len(costs['all_measurement_and_restart_resources']),'help':help_results,
            'tool_hashes':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted((HERE/'tools-01').iterdir()) if p.is_file()}}
    (HERE/'local-validation.json').write_text(json.dumps(result,sort_keys=True,indent=2)+'\n')
    print(json.dumps({'passed':True,'preserved_functions':len(preserved),'historical_cost_aggregates':len(costs['aggregate']),'remote_calls':0}))


if __name__=='__main__':
    main()
