def verify_r27_candidate_preparation(preparation, terminal, job_id, qualified, tests):
    """Bind the actual R24-based serializer qualification; future pins never pass."""
    need(isinstance(job_id, str) and re.fullmatch(r"[0-9a-f]{11,16}-[0-9a-f]{4}-[0-9a-f]{4}", job_id)
         and job_id not in {"1a1aa7fa690-fc05-43af", "1a1aaa6552d-fc05-459f",
                           "1a1ab4cb0fc-fc05-4c3c", "1a1ab216326-fc05-4ac1"},
         "the actual new R27 qualification job is required")
    need(terminal.get("job_id") == job_id and terminal.get("state") == "succeeded"
         and type(terminal.get("exit_code")) is int and terminal["exit_code"] == 0
         and all(terminal.get(key) is False for key in ("automatic_retry", "timed_out", "cancelled"))
         and all(terminal.get(key) is True for key in ("output_complete", "output_durable", "terminal_publication_confirmed"))
         and type(terminal.get("terminal_publication_protocol")) is int and terminal["terminal_publication_protocol"] == 1
         and terminal.get("log_synced") == {"stdout": True, "stderr": True}
         and terminal.get("log_errors") == {"stdout": None, "stderr": None}
         and terminal.get("log_truncated") == {"stdout": False, "stderr": False},
         "original R27 qualification has no complete successful native terminal proof")
    for stream in ("stdout", "stderr"):
        counts = terminal["log_bytes"][stream]
        need(set(counts) == {"seen", "stored"} and all(type(value) is int and value >= 0 for value in counts.values())
             and counts["seen"] == counts["stored"], "qualification native log byte custody differs")
    contract = R27_QUALIFICATION_CONTRACT
    need(preparation["schema"] == "hepta-r27-accepted-r24-serializer-preparation/v1"
         and preparation["accepted_commit"] == contract["accepted_commit"]
         and preparation["production_selection"] == "accepted R24 plus borrowed observation serializer only"
         and preparation.get("finished_utc")
         and all(preparation.get(key) is True for key in ("passed", "candidate_qualified", "parent_source_qualified",
                                                        "parent_candidate_adopted", "parent_inputs_unchanged"))
         and all(preparation.get(key) is False for key in ("candidate_adopted", "production_services_modified",
                                                         "shared_hardlinks_created", "r25_source_inherited")),
         "actual R27 preparation does not preserve accepted R24 ancestry")
    need(preparation["source"] == str(SOURCE) and preparation["target"] == str(ROOT / "target-build")
         and preparation["qualification_output"] == str(CANDIDATE_DIR), "R27 private qualification paths differ")
    for key in ("launcher", "input"):
        expected = contract[key]
        need(isinstance(expected["sha256"], str) and HEX.fullmatch(expected["sha256"])
             and type(expected["bytes"]) is int and expected["bytes"] > 0
             and all(preparation[key][field] == expected[field] for field in ("bytes", "sha256")),
             "R27 qualification tool/input must match the frozen preparation: " + key)
    need(type(preparation["qualification_returncode"]) is int and preparation["qualification_returncode"] == 0
         and type(preparation["automatic_test_retries"]) is int and preparation["automatic_test_retries"] == 0,
         "R27 qualification did not finish once with exit zero")
    need(preparation["source_changes"] == contract["source_changes"]
         and preparation["allowed_modified_paths"] == ["src/mcp/runtime/ssh.rs"]
         and preparation["allowed_added_paths"] == ["src/mcp/runtime/ssh_observation_serialization_tests.rs"],
         "qualified selection is not the serializer-only two-file change")
    before = preparation["source_before"]
    need(len(before) == 220 and hashlib.sha256(canonical(before)).hexdigest() == contract["baseline_source_map_sha256"],
         "R27 parent compilation map is not the accepted R24 map")
    expected = dict(before)
    for change in contract["source_changes"]:
        need(before.get(change["path"]) == change["before_sha256"], "unexpected pre-change source identity")
        expected[change["path"]] = change["sha256"]
    need(len(expected) == 221 and preparation["candidate_compilation_inputs"] == expected
         and hashlib.sha256(canonical(expected)).hexdigest() == contract["candidate_source_map_sha256"],
         "R27 pre-format compilation map differs")
    stages = ["format", "fmt-check", "harness-tests", "clippy", "test-build", "isolated-tests", "audit-isolated-tests", "release"]
    need(qualified["schema"] == "hepta-x230-composed-qualification/v1" and qualified["qualified"] is True
         and qualified.get("finished_utc") and qualified["source"] == str(SOURCE)
         and qualified["jobs"] == 2 and qualified["service_changes"] is False
         and type(qualified["automatic_test_retries"]) is int and qualified["automatic_test_retries"] == 0
         and [row["name"] for row in qualified["stages"]] == stages
         and all(type(row["returncode"]) is int and row["returncode"] == 0 for row in qualified["stages"]),
         "all eight original R27 qualification stages must pass")
    changed = {row["path"] for row in contract["source_changes"]}
    need(qualified["source_input"] == expected
         and qualified["source_tested"] == qualified["source_after"] == preparation["source_tested"] == preparation["source_after"]
         and set(qualified["source_after"]) == set(expected)
         and all(qualified["source_after"][name] == value for name, value in expected.items() if name not in changed),
         "actual formatted R27 source differs from its exact R24-based preparation")
    need(preparation["formatter_changed_paths"] == sorted(name for name in expected if qualified["source_after"][name] != expected[name])
         and set(preparation["formatter_changed_paths"]) <= changed
         and qualified["harness_before"] == qualified["harness_after"] == preparation["harness_before"] == preparation["harness_after"]
         and len(qualified["harness_after"]) == 19, "qualification formatter or original harness binding differs")
    counts = ("passed", "failed", "ignored", "selected", "retries")
    need(tests["success"] is True and all(type(tests[key]) is int for key in counts)
         and {key: tests[key] for key in counts} == contract["expected_tests"]
         and preparation["tests"] == tests, "original full R27 isolated test result is incomplete")
    added = preparation["new_tests"]
    need(len(added) == 7 and {row["name"] for row in added} == set(contract["added_tests"])
         and all(row["status"] == "passed" and row["executed"] is True and type(row["attempt"]) is int and row["attempt"] == 1 for row in added),
         "all seven new serializer equivalence tests must execute and pass once")
    need(preparation["binaries"] == qualified["binaries"], "preparation and qualified binary identities differ")
    return {"passed": True, "original_job_id": job_id, "accepted_commit": contract["accepted_commit"],
            "production_selection": preparation["production_selection"], "r25_source_inherited": False,
            "qualified_source_files": 221, "harness_files": 19, "stages": stages,
            "tests": {key: tests[key] for key in counts}, "new_tests_passed": 7, "candidate_adopted": False}


