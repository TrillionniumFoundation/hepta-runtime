#!/usr/bin/env python3
"""Local-only version adaptation; reads reviewed files and writes this directory."""
import ast
import difflib
import hashlib
import json
from pathlib import Path
import pprint

HERE = Path(__file__).resolve().parent
OLD = Path('/workspace/scratch/806ba5f52f94')
REVIEWED = OLD / 'r25-lifecycle-audit/r26-tools-02'
QUALIFICATION = HERE.parent / 'r27-full-qualification'
REMOTE_ROOT = '/home/qian/hepta-runtime-optimization-20261105-b96-r27'


def identity(path):
    raw = path.read_bytes()
    return {'path': str(path), 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


def replace_once(text, old, new):
    assert text.count(old) == 1, old[:100]
    return text.replace(old, new)


def replace_function(text, name, replacement):
    node = next(n for n in ast.parse(text).body if isinstance(n, ast.FunctionDef) and n.name == name)
    lines = text.splitlines(keepends=True)
    return ''.join(lines[:node.lineno-1]) + replacement.rstrip() + '\n' + ''.join(lines[node.end_lineno:])


def version(text):
    return (text.replace('/home/qian/hepta-runtime-optimization-20261105-r26', REMOTE_ROOT)
                .replace('R26', 'R27').replace('r26', 'r27').replace('tools-02/', 'tools-01/')
                .replace('hepta-r25-campaign-inputs/v1', 'hepta-r27-campaign-inputs/v1'))


def main():
    original = REVIEWED / 'tools-02/r26_campaign.py'
    raw = original.read_text()
    body = version(raw)
    body = body.replace('summarize_r25_campaign.py', 'summarize_r27_campaign.py')
    body = body.replace('hepta-r25-observation-campaign-control/v1', 'hepta-r27-campaign-control/v1')
    body = body.replace('observation_gate_passed', 'adoption_passed')
    body = body.replace('summary["adoption_passed"]', 'summary["adoption_gate_passed"]')
    body = body.replace('("r27-cancel-recovery-" + attempt)', '("b96-r27-cancel-recovery-" + attempt)')
    body = body.replace('("h26" + prefix + attempt)', '("h96r27" + prefix + attempt)')
    body = body.replace('No future R24 binary', 'No future R27 binary')
    body = body.replace('("observation-summary", py +', '("campaign-summary", py +')
    body = replace_once(body,
        '["lifecycle ABBA nonregression", "real saturated cancellation proof", "qualified source", "complete resource evidence"]',
        '["qualified R24-based serializer source", "fixed R24 efficiency gates", "seven-stage correctness evidence", "full local child-cost evidence", "valid compiler monitor"]')
    body = replace_once(body,
        'and gates["controller_cpu_b_over_a_max"] == 1.10',
        'and gates["primary_throughput_b_over_a_min"] == 1.03\n             and gates["primary_controller_cpu_b_over_a_max"] == 0.97')
    body = replace_once(body,
        'need(summary["evidence_verified"] is True and summary["correctness_verified"] is True\n             and summary["thresholds"] == report["thresholds"], "summary identity or protocol differs")',
        'need(summary["schema"] == "hepta-r27-campaign-gates/v1" and summary["evidence_verified"] is True\n             and summary["correctness_verified"] is True and summary["thresholds"] == report["thresholds"]\n             and summary["full_local_costs"]["verified_from_original_counters"] is True,\n             "summary identity, fixed gates or required child-cost evidence differs")')
    body = replace_once(body,
        'need(not os.path.lexists(path) and path.resolve() == path, "private socket directory already exists")',
        'need(not os.path.lexists(path) and path.resolve() == path, "private socket directory already exists")\n            private_directory(path, create_new=True)')
    body = replace_once(body,
        'private_directory(workload_sockets[spec["name"]], create_new=True)',
        'private_directory(workload_sockets[spec["name"]])')
    body = replace_function(body, 'verify_r27_candidate_preparation',
                            (HERE / 'candidate-validator.snippet.py').read_text())
    body = replace_once(body, 'tests = json.loads(raw)\n    source_map_id, raw = bind',
                        'tests = json.loads(raw)\n    need(preparation["test_summary"] == test_id, "preparation names different original test summary bytes")\n    source_map_id, raw = bind')
    payload_path = QUALIFICATION / 'qualification-input-01.json'
    payload = json.loads(payload_path.read_text())
    launcher = identity(QUALIFICATION / 'prepare_and_qualify_r27_01.py')
    launcher['path'] = '/home/qian/hepta-runtime-optimization-20261105-r25/tools/b96_prepare_and_qualify_r27_01.py'
    input_id = identity(payload_path)
    input_id['path'] = '/home/qian/hepta-runtime-optimization-20261105-r25/tools/b96-r27-qualification-01-input.json'
    contract = {key: payload[key] for key in ('accepted_commit', 'baseline_source_map_sha256',
                  'candidate_source_map_sha256', 'expected_tests', 'added_tests')}
    contract.update(launcher=launcher, input=input_id,
        source_changes=[{key: row[key] for key in ('path','before_sha256','sha256','bytes')} for row in payload['files']])
    body = replace_once(body, '\n\ndef need(value, message):',
                        '\n\nR27_QUALIFICATION_CONTRACT = ' + pprint.pformat(contract, width=100, sort_dicts=True) + '\n\ndef need(value, message):')
    ast.parse(body)
    (HERE / 'tools-01/r27_campaign.py').write_text(body)
    preparer = version((REVIEWED / 'tools-02/prepare_campaign_inputs.py').read_text())
    ast.parse(preparer)
    (HERE / 'tools-01/prepare_campaign_inputs.py').write_text(preparer)
    policy = json.loads((REVIEWED / 'tools-02/compiler-monitor-policy-01.json').read_text())
    policy['schema'] = 'hepta-r27-compiler-monitor-policy/v1'
    (HERE / 'tools-01/compiler-monitor-policy-01.json').write_text(json.dumps(policy, sort_keys=True, indent=2)+'\n')
    example = json.loads(version((REVIEWED / 'campaign-inputs-01.example.json').read_text()))
    example['launcher_sha256'] = identity(HERE/'tools-01/r27_campaign.py')['sha256']
    example['summary_sha256'] = identity(HERE/'tools-01/summarize_r27_campaign.py')['sha256']
    for role, old_pin in example['compiler_monitor'].items():
        pin = identity(HERE/'tools-01'/Path(old_pin['path']).name)
        pin['path'] = REMOTE_ROOT + '/tools-01/' + Path(old_pin['path']).name
        example['compiler_monitor'][role] = pin
    (HERE/'campaign-inputs-01.example.json').write_text(json.dumps(example, sort_keys=True, indent=2)+'\n')
    (HERE/'r27-vs-reviewed-r26-parent.patch').write_text(''.join(difflib.unified_diff(raw.splitlines(keepends=True), body.splitlines(keepends=True), fromfile=str(original), tofile='tools-01/r27_campaign.py')))
    old_summary=OLD/'benchmark-r24/summarize_r24_campaign.py'
    (HERE/'r27-vs-original-r24-summary.patch').write_text(''.join(difflib.unified_diff(old_summary.read_text().splitlines(keepends=True), (HERE/'tools-01/summarize_r27_campaign.py').read_text().splitlines(keepends=True), fromfile=str(old_summary), tofile='tools-01/summarize_r27_campaign.py')))
    receipt = {'schema':'hepta-r27-local-tool-derivation/v1','prepared_only':True,'remote_actions':0,
        'qualification_runtime_pins_still_null':True,'qualification_contract':contract,
        'parent_reference':identity(original),'summary_reference':identity(old_summary),
        'materializer_reference':identity(REVIEWED/'tools-02/prepare_campaign_inputs.py'),
        'cost_arithmetic_reference':identity(OLD/'r25-capacity-audit/audit_r24_capacity.py'),
        'compiler_monitor_sources':[identity(REVIEWED/'tools-02'/name) for name in ('compiler_monitor.py','compiler_state.py','validate_compiler_monitor.py')]}
    (HERE/'derivation-inputs.json').write_text(json.dumps(receipt,sort_keys=True,indent=2)+'\n')
    print(json.dumps({'prepared_only':True,'parent':identity(HERE/'tools-01/r27_campaign.py'),
                      'example':identity(HERE/'campaign-inputs-01.example.json'),
                      'qualification_launcher_snapshot':launcher}))


if __name__ == '__main__':
    main()
