#!/usr/bin/env python3
"""R20 fresh-interpreter differential semantics and bounded ABBA component probe.

No SSH, runtime, workload, cancellation, or real systemctl/ps is executed. Every
observation is an owned fresh Python process using exact extracted source. Only
status_completed, read_completed and detached_live are native Linux paths;
systemd_mock and nonlinux_ps_mock are explicitly simulated branch coverage.
"""
import argparse
import ast
from collections import Counter
import datetime
import hashlib
import json
import math
import os
from pathlib import Path
import platform
import re
import resource
import statistics
import subprocess
import sys
import time
import traceback

BASELINE_SHA = 'c9080de8aa9a35f7495aa2822a1495d297903900ae0f0de26d7b0c86d043d3c9'
CANDIDATE_SHA = '2f751c09a9a29bebb0cda0a9bd2bb522d145ee8183740ed1442d77666ee44aa7'
CONSTANTS = ('PRIVATE_DIRECTORY_CODE', 'BOUND_OBSERVATION_CODE', 'START_CODE', 'STATUS_CODE', 'READ_CODE', 'CANCEL_CODE')
SCENES = ('status_completed', 'read_completed', 'detached_live', 'systemd_mock', 'nonlinux_ps_mock')
METADATA = 'R20_PROBE_METADATA '
USAGE_FIELDS = ('ru_utime', 'ru_stime', 'ru_maxrss', 'ru_ixrss', 'ru_idrss', 'ru_isrss', 'ru_minflt',
                'ru_majflt', 'ru_nswap', 'ru_inblock', 'ru_oublock', 'ru_msgsnd', 'ru_msgrcv',
                'ru_nsignals', 'ru_nvcsw', 'ru_nivcsw')


def need(value, reason):
    if not value:
        raise ValueError(reason)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def encode(value):
    return (json.dumps(value, sort_keys=True, indent=2) + '\n').encode()


def write_new(path, raw, mode=0o600):
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_CLOEXEC, mode)
    with os.fdopen(fd, 'wb') as stream:
        stream.write(raw)


def artifact(path):
    raw = path.read_bytes()
    return {'path': str(path), 'bytes': len(raw), 'sha256': sha(raw)}


def extracted(path, expected):
    raw = path.read_bytes()
    need(sha(raw) == expected, 'source SHA256 differs: ' + str(path))
    text = raw.decode('utf-8')
    values = {}
    for name in CONSTANTS:
        match = re.search(r'const ' + name + r': &str = r#"(.*?)"#;', text, re.S)
        need(match is not None, 'missing source constant ' + name)
        ast.parse(match.group(1))
        values[name] = match.group(1)
    return raw, values


def strip_imports(node):
    for field, value in ast.iter_fields(node):
        if isinstance(value, list):
            setattr(node, field, [strip_imports(x) if isinstance(x, ast.AST) else x for x in value
                                  if not isinstance(x, (ast.Import, ast.ImportFrom))])
        elif isinstance(value, ast.AST):
            setattr(node, field, strip_imports(value))
    return node


def snapshot(folder):
    return {p.relative_to(folder).as_posix(): {'bytes': p.stat().st_size,
            'mode': p.stat().st_mode & 0o7777, 'sha256': sha(p.read_bytes())}
            for p in sorted(folder.rglob('*')) if p.is_file()}


def usage():
    value = resource.getrusage(resource.RUSAGE_CHILDREN)
    return {name: getattr(value, name) for name in USAGE_FIELDS}


def fixture(out, name, scene, fault=None):
    job = out / 'fixtures' / name / 'state' / 'jobs' / name
    job.mkdir(mode=0o700, parents=True)
    for p in (job.parent.parent, job.parent, job):
        os.chmod(p, 0o700)
    pid, nonce, digest, invocation = os.getpid(), 'e' * 32, 'd' * 64, 'f' * 32
    nonlinux = scene == 'nonlinux_ps_mock' or fault == 'nonlinux_systemd_uid_error'
    systemd = scene == 'systemd_mock'
    value = 'Wed Nov  4 12:34:56 2026'
    if nonlinux:
        identity = {'kind': 'ps_lstart', 'value': value}
    else:
        ticks = int(Path('/proc/' + str(pid) + '/stat').read_text().rsplit(') ', 1)[1].split()[19])
        boot = Path('/proc/sys/kernel/random/boot_id').read_text().strip()
        identity = {'kind': 'proc_start_ticks', 'value': boot + ':' + str(ticks)}
    q = {'job_id': name, 'job_dir': str(job), 'unit': 'hepta-r20-probe-' + name,
         'request_digest': digest, 'wait_seconds': 0, 'stdout_offset': 0, 'stderr_offset': 0, 'limit': 16384}
    request = {**q, 'launch_nonce': nonce, 'terminal_publication_protocol': 1}
    started = {'job_id': name, 'launch_nonce': nonce, 'supervisor_uid': os.geteuid(),
               'supervisor_pid': pid, 'supervisor_identity': identity, 'invocation_id': invocation}
    documents = {'request.json': request, 'launch.json': {'backend': 'systemd' if systemd else 'detached'},
                 'started.json': started}
    if scene in ('status_completed', 'read_completed'):
        terminal = {'job_id': name, 'launch_nonce': nonce, 'terminal_publication_protocol': 1,
                    'exit_code': 0, 'output_complete': True, 'output_durable': True,
                    'timed_out': False, 'cancelled': False}
        documents['exit.json'] = terminal
        documents['exit.witness.json'] = {'job_id': name, 'launch_nonce': nonce,
            'terminal_publication_protocol': 1, 'exit_sha256': sha(encode(terminal))}
    if fault == 'binding_mismatch':
        q['request_digest'] = 'b' * 64
    if fault == 'bad_witness':
        documents['exit.witness.json']['exit_sha256'] = '0' * 64
    if fault == 'missing_witness':
        del documents['exit.witness.json']
    if fault == 'missing_owner':
        del documents['started.json']
    for filename, document in documents.items():
        data = encode(document)
        if (filename, fault) in (('launch.json', 'corrupt_launch'), ('exit.json', 'corrupt_exit'),
                                 ('started.json', 'malformed_owner')):
            data = b'{'
        write_new(job / filename, data, 0o644 if filename == 'started.json' and fault == 'unsafe_owner' else 0o600)
        if filename == 'started.json' and fault == 'unsafe_owner':
            # The driver's private umask must not erase this deliberate fault.
            os.chmod(job / filename, 0o644)
    write_new(job / 'stdout.log', b'R20 read-only output\n')
    write_new(job / 'stderr.log', b'')
    return {'name': name, 'scene': scene, 'fault': fault, 'job': job, 'query': q,
            'pid': pid, 'identity': identity, 'nonlinux': nonlinux, 'systemd': systemd,
            'invocation': invocation, 'ps_value': value, 'snapshot': snapshot(job)}


def script(constants, case, blocked_import=False, diagnostics=True):
    prefix = 'import sys\n_r20_initial_modules = set(sys.modules)\n_r20_mock_calls = []\n_r20_extra = {}\n' if diagnostics else ''
    if case['systemd'] or case['nonlinux']:
        if not diagnostics:
            prefix = 'import sys\n_r20_mock_calls = []\n'
        settings = {key: case[key] for key in ('pid', 'nonlinux', 'systemd', 'invocation', 'ps_value', 'fault')}
        settings.update(uid=os.geteuid(), unit=case['query']['unit'], job_id=case['name'], nonce='e' * 32)
        prefix += 'import subprocess as _r20_subprocess\n_r20_settings = ' + repr(settings) + '\n'
        prefix += '''def _r20_check_output(argv, **kwargs):
    _r20_mock_calls.append({"method": "check_output", "argv": argv})
    assert argv[:4] == ["ps", "-p", str(_r20_settings["pid"]), "-o"]
    assert kwargs == {"text": True, "timeout": 3}
    if argv[4] == "lstart=": return _r20_settings["ps_value"] + "\\n"
    assert argv[4] == "uid="
    if _r20_settings["fault"] == "nonlinux_systemd_uid_error":
        raise _r20_subprocess.CalledProcessError(1, argv)
    return str(_r20_settings["uid"]) + "\\n"
def _r20_run(argv, **kwargs):
    _r20_mock_calls.append({"method": "run", "argv": argv})
    assert argv == ["systemctl", "--user", "show", _r20_settings["unit"], "--no-pager", "--property=LoadState,ActiveState,SubState,Result,ExecMainPID,ExecMainCode,ExecMainStatus,InvocationID,Description"]
    assert kwargs["stdout"] == kwargs["stderr"] == _r20_subprocess.PIPE and kwargs["text"] is True
    assert kwargs["env"]["XDG_RUNTIME_DIR"] and kwargs["env"]["DBUS_SESSION_BUS_ADDRESS"]
    invocation = "0" * 32 if _r20_settings["fault"] == "systemd_wrong_invocation" else _r20_settings["invocation"]
    props = {"LoadState": "loaded", "ActiveState": "active", "SubState": "running", "Result": "success", "ExecMainPID": str(_r20_settings["pid"]), "ExecMainCode": "0", "ExecMainStatus": "0", "InvocationID": invocation, "Description": "Hepta Runtime job " + _r20_settings["job_id"] + " " + _r20_settings["nonce"]}
    return _r20_subprocess.CompletedProcess(argv, 0, "".join(k + "=" + v + "\\n" for k, v in props.items()), "")
_r20_subprocess.check_output = _r20_check_output
_r20_subprocess.run = _r20_run
if _r20_settings["nonlinux"]: sys.platform = "darwin"
'''
    if blocked_import:
        prefix += '''import builtins as _r20_builtins
_r20_import = _r20_builtins.__import__
def _r20_block(name, *args, **kwargs):
    if name == "subprocess": raise ImportError("R20 deliberate unavailable subprocess")
    return _r20_import(name, *args, **kwargs)
_r20_builtins.__import__ = _r20_block
'''
    body = 'REMOTE_DIRECTORY_SOURCE = ' + json.dumps(constants['PRIVATE_DIRECTORY_CODE'], ensure_ascii=False) + '\nexec(REMOTE_DIRECTORY_SOURCE)\n'
    body += constants['BOUND_OBSERVATION_CODE'] + '\n' + constants['READ_CODE' if case['scene'] == 'read_completed' else 'STATUS_CODE']
    footer = '\n' if diagnostics else ''
    if diagnostics and case['scene'] == 'nonlinux_ps_mock':
        footer += '_r20_extra["process_uid_helper"] = process_uid(' + str(case['pid']) + ')\n'
    if diagnostics:
        footer += 'print(' + repr(METADATA) + ' + json.dumps({"subprocess_loaded": "subprocess" in sys.modules, "initial_subprocess_loaded": "subprocess" in _r20_initial_modules, "new_modules": sorted(set(sys.modules) - _r20_initial_modules), "mock_calls": _r20_mock_calls, "extra": _r20_extra}, sort_keys=True), file=sys.stderr)\n'
    result = prefix + body + footer
    ast.parse(result)
    return result


def expected_outcome(case, row):
    fault = case['fault']
    if fault in ('binding_mismatch', 'corrupt_launch', 'corrupt_exit', 'unsafe_owner'):
        text = {'binding_mismatch': 'remote job request binding missing or mismatched',
                'corrupt_launch': 'corrupt remote job file launch.json',
                'corrupt_exit': 'corrupt remote job file exit.json',
                'unsafe_owner': 'ValueError: unsafe terminal publication file'}[fault]
        return row['returncode'] != 0 and row['response'] is None and row['exception_tail'] == text
    if row['returncode'] != 0 or row['response'] is None:
        return False
    response = row['response']
    if case['scene'] == 'read_completed':
        return (response['job_id'] == case['name'] and response['stdout']['bytes_hex'] == b'R20 read-only output\n'.hex()
                and response['stdout']['eof'] is True and response['stderr']['bytes_hex'] == '')
    state = 'succeeded' if case['scene'] == 'status_completed' else 'running'
    if fault in ('bad_witness', 'missing_witness'):
        state = 'finalizing'
    if fault in ('missing_owner', 'unsafe_owner', 'malformed_owner', 'systemd_wrong_invocation', 'nonlinux_systemd_uid_error'):
        state = 'owner_unknown'
    return response.get('state') == state and response.get('job_id') == case['name']


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--baseline', type=Path, required=True)
    parser.add_argument('--candidate', type=Path, required=True)
    parser.add_argument('--out', type=Path, required=True)
    parser.add_argument('--expected-tool-sha256', required=True)
    parser.add_argument('--python', default=sys.executable)
    parser.add_argument('--calls', type=int, default=16)
    args = parser.parse_args()
    need(sys.platform == 'linux' and 1 <= args.calls <= 64, 'bounded Linux probe requires 1..64 calls per ABBA cell')
    need(sha(Path(__file__).read_bytes()) == args.expected_tool_sha256, 'probe tool identity differs')
    sources = {'A': extracted(args.baseline, BASELINE_SHA), 'B': extracted(args.candidate, CANDIDATE_SHA)}
    checks = {'all_nonstatus_constants_identical': all(sources['A'][1][k] == sources['B'][1][k] for k in CONSTANTS if k != 'STATUS_CODE'),
              'status_nonimport_ast_identical': ast.dump(strip_imports(ast.parse(sources['A'][1]['STATUS_CODE'])), include_attributes=False) == ast.dump(strip_imports(ast.parse(sources['B'][1]['STATUS_CODE'])), include_attributes=False)}
    need(all(checks.values()), 'candidate contains non-import semantic changes')
    out = args.out.absolute()
    need(out.resolve() == out and not os.path.lexists(out), 'output must be fresh and direct')
    os.umask(0o077)
    out.mkdir(mode=0o700, parents=True)
    for name in ('scripts', 'processes'):
        (out / name).mkdir(mode=0o700)
    common = {'baseline_source_sha256': BASELINE_SHA, 'candidate_source_sha256': CANDIDATE_SHA,
              'probe_tool_sha256': args.expected_tool_sha256, 'scenes': list(SCENES), 'source_stable': False,
              'python': args.python, 'driver_python_version': sys.version, 'driver_platform': platform.platform(),
              'workloads_started': False, 'remote_calls': 0, 'automatic_retries': 0}
    semantics = {'schema': 'hepta-r20-coldprocess-semantics/v1', 'passed': False, **common, 'checks': checks, 'cases': []}
    benchmark = {'schema': 'hepta-r20-coldprocess-abba/v1', 'passed': False, **common,
                 'order': 'ABBA', 'calls_per_cell': args.calls, 'cells': [],
                 'measurement_scope': 'One fresh interpreter per raw row. Native benchmark executes the production BOUND+STATUS/READ body without diagnostic prefix/footer. Wall includes Popen+communicate+reap; CPU is RUSAGE_CHILDREN utime+stime delta, never driver or function-only CPU. Systemd/nonlinux keep only required mocks and are diagnostic.',
                 'ru_maxrss_scope': 'Cumulative child high-water observation only; no per-process RSS delta or allocation reduction is inferred.'}
    raw_path = out / 'raw-processes.jsonl'
    raw_stream = raw_path.open('xb')
    sequence = 0
    all_fixtures = []

    def invoke(case, variant, phase, round_index=None, call_index=None, blocked=False):
        nonlocal sequence
        number = sequence; sequence += 1
        key = case['name'] + '-' + variant + ('-blocked' if blocked else '')
        source = script(sources[variant][1], case, blocked, diagnostics=phase != 'benchmark')
        script_file = out / 'scripts' / (key + '-' + phase + '.py')
        if not script_file.exists():
            write_new(script_file, source.encode())
        else:
            need(script_file.read_bytes() == source.encode(), 'fixture script changed')
        before, begin, realtime_begin = usage(), time.monotonic_ns(), time.time_ns()
        child = subprocess.Popen([args.python, '-B', '-c', source], stdin=subprocess.PIPE,
                                 stdout=subprocess.PIPE, stderr=subprocess.PIPE, cwd=out)
        spawned = time.monotonic_ns()
        timed_out = False
        try:
            stdout, stderr = child.communicate(json.dumps(case['query'], sort_keys=True).encode(), timeout=15)
        except subprocess.TimeoutExpired:
            timed_out = True
            child.kill()
            stdout, stderr = child.communicate()
        end, realtime_end, after = time.monotonic_ns(), time.time_ns(), usage()
        paths = {name: out / 'processes' / (str(number).zfill(5) + '.' + name) for name in ('stdout', 'stderr')}
        write_new(paths['stdout'], stdout); write_new(paths['stderr'], stderr)
        app_lines, metadata = [], None
        for line in stderr.decode('utf-8', errors='replace').splitlines():
            if line.startswith(METADATA):
                need(metadata is None, 'duplicate diagnostic metadata')
                metadata = json.loads(line[len(METADATA):])
            else:
                app_lines.append(line)
        try:
            response = json.loads(stdout)
        except (ValueError, UnicodeError):
            response = None
        cpu = after['ru_utime'] + after['ru_stime'] - before['ru_utime'] - before['ru_stime']
        row = {'sequence': number, 'phase': phase, 'case': case['name'], 'scene': case['scene'], 'variant': variant,
               'round': round_index, 'call': call_index, 'pid': child.pid, 'returncode': child.returncode,
               'timed_out': timed_out, 'reaped': child.returncode is not None, 'fresh_interpreter': True,
               'argv_shape': [args.python, '-B', '-c', {'script_file': str(script_file), 'sha256': sha(source.encode())}],
               'input_json': case['query'], 'input_sha256': sha(json.dumps(case['query'], sort_keys=True).encode()),
               'clock': {'start_monotonic_ns': begin, 'spawned_monotonic_ns': spawned, 'end_monotonic_ns': end,
                         'start_realtime_ns': realtime_begin, 'end_realtime_ns': realtime_end},
               'rusage_children_before': before, 'rusage_children_after': after, 'child_cpu_seconds': cpu,
               'wall_seconds': (end - begin) / 1e9, 'stdout': artifact(paths['stdout']), 'stderr': artifact(paths['stderr']),
               'response': response, 'exception_tail': app_lines[-1] if app_lines else None,
               'application_stderr_lines': app_lines, 'metadata': metadata, 'automatic_retry': False}
        raw_stream.write(encode(row).replace(b'\n', b'') + b'\n'); raw_stream.flush()
        need(not timed_out and cpu >= 0, 'fresh interpreter timeout or invalid child CPU counters')
        return row

    try:
        specifications = [(s, s, None) for s in SCENES] + [
            ('binding_mismatch', 'status_completed', 'binding_mismatch'),
            ('corrupt_launch', 'status_completed', 'corrupt_launch'),
            ('corrupt_exit', 'status_completed', 'corrupt_exit'),
            ('bad_witness', 'status_completed', 'bad_witness'),
            ('missing_witness', 'status_completed', 'missing_witness'),
            ('missing_owner', 'detached_live', 'missing_owner'),
            ('unsafe_owner', 'detached_live', 'unsafe_owner'),
            ('malformed_owner', 'detached_live', 'malformed_owner'),
            ('systemd_wrong_invocation', 'systemd_mock', 'systemd_wrong_invocation'),
            ('nonlinux_systemd_uid_error', 'systemd_mock', 'nonlinux_systemd_uid_error')]
        for name, scene, fault in specifications:
            case = fixture(out, name, scene, fault); all_fixtures.append(case)
            runs = {v: invoke(case, v, 'semantics') for v in 'AB'}
            a, b = runs['A'], runs['B']
            same = (a['returncode'], a['response'], a['exception_tail']) == (b['returncode'], b['response'], b['exception_tail'])
            passed = same and all(expected_outcome(case, row) for row in runs.values())
            if fault is None:
                passed = passed and all(row['metadata'] is not None for row in runs.values())
                if scene in ('status_completed', 'detached_live'):
                    passed = passed and a['metadata']['subprocess_loaded'] is True and b['metadata']['subprocess_loaded'] is False
                if scene == 'read_completed':
                    passed = passed and a['metadata']['subprocess_loaded'] is b['metadata']['subprocess_loaded'] is False
                if scene == 'systemd_mock':
                    passed = passed and all(len(row['metadata']['mock_calls']) == 1 for row in runs.values())
                if scene == 'nonlinux_ps_mock':
                    passed = passed and all(len(row['metadata']['mock_calls']) == 2 and row['metadata']['extra']['process_uid_helper'] == os.geteuid() for row in runs.values())
            semantics['cases'].append({'name': name, 'scene': scene, 'fault': fault, 'passed': passed,
                                       'baseline_sequence': a['sequence'], 'candidate_sequence': b['sequence'],
                                       'equivalent_exit_response_error_tail': same})
            need(passed, 'semantic case failed: ' + name)
        checks['all_differential_cases_passed'] = True
        boundary_case = all_fixtures[0]
        boundary_runs = {v: invoke(boundary_case, v, 'environment-boundary', blocked=True) for v in 'AB'}
        boundary_ok = boundary_runs['A']['returncode'] != 0 and boundary_runs['A']['exception_tail'] == 'ImportError: R20 deliberate unavailable subprocess' and expected_outcome(boundary_case, boundary_runs['B'])
        checks['unused_module_environment_boundary_documented'] = boundary_ok
        semantics['environment_boundary'] = {'assumption': 'Supported Python has intact standard-library modules. A missing or deliberately blocked unused subprocess import no longer fails completed status.',
            'intentionally_different': True, 'verified_as_documented': boundary_ok,
            'baseline_sequence': boundary_runs['A']['sequence'], 'candidate_sequence': boundary_runs['B']['sequence']}
        need(boundary_ok, 'documented environment boundary differs')
        for scene in SCENES:
            case = next(x for x in all_fixtures if x['name'] == scene)
            for round_index, variant in enumerate('ABBA'):
                rows = [invoke(case, variant, 'benchmark', round_index, n) for n in range(args.calls)]
                need(all(expected_outcome(case, r) for r in rows), 'benchmark correctness failed')
                benchmark['cells'].append({'scene': scene, 'variant': variant, 'round': round_index,
                    'calls': len(rows), 'sequences': [r['sequence'] for r in rows],
                    'child_cpu_seconds': math.fsum(r['child_cpu_seconds'] for r in rows),
                    'wall_seconds': math.fsum(r['wall_seconds'] for r in rows),
                    'child_cpu_ms_per_call': 1000 * statistics.mean(r['child_cpu_seconds'] for r in rows),
                    'wall_ms_per_call': 1000 * statistics.mean(r['wall_seconds'] for r in rows),
                    'native_linux_path': scene in SCENES[:3], 'mock_diagnostic_only': scene in SCENES[3:]})
                print(json.dumps({'stage': 'cold-abba', 'scene': scene, 'round': round_index,
                                  'variant': variant, 'calls': len(rows)}), flush=True)
        benchmark['summaries'] = {}
        for scene in SCENES:
            cells = [c for c in benchmark['cells'] if c['scene'] == scene]
            arms = {v: {'calls': sum(c['calls'] for c in cells if c['variant'] == v),
                        'child_cpu_seconds': math.fsum(c['child_cpu_seconds'] for c in cells if c['variant'] == v),
                        'wall_seconds': math.fsum(c['wall_seconds'] for c in cells if c['variant'] == v)} for v in 'AB'}
            for arm in arms.values():
                arm['child_cpu_ms_per_call'] = 1000 * arm['child_cpu_seconds'] / arm['calls']
                arm['wall_ms_per_call'] = 1000 * arm['wall_seconds'] / arm['calls']
            benchmark['summaries'][scene] = {'arms': arms, 'aggregate_B_over_A_cpu': arms['B']['child_cpu_ms_per_call'] / arms['A']['child_cpu_ms_per_call'],
                'aggregate_B_over_A_wall': arms['B']['wall_ms_per_call'] / arms['A']['wall_ms_per_call'],
                'pair_B_over_A_cpu': [cells[1]['child_cpu_ms_per_call'] / cells[0]['child_cpu_ms_per_call'], cells[2]['child_cpu_ms_per_call'] / cells[3]['child_cpu_ms_per_call']],
                'mock_diagnostic_only': scene in SCENES[3:]}
        checks['fixtures_unchanged'] = all(snapshot(case['job']) == case['snapshot'] for case in all_fixtures)
        checks['sources_and_tool_unchanged'] = (args.baseline.read_bytes() == sources['A'][0] and args.candidate.read_bytes() == sources['B'][0] and sha(Path(__file__).read_bytes()) == args.expected_tool_sha256)
        need(all(checks.values()), 'final source/fixture checks failed')
        semantics['source_stable'] = benchmark['source_stable'] = True
        semantics['passed'] = benchmark['passed'] = True
    except BaseException as error:
        semantics['error'] = benchmark['error'] = {'type': type(error).__name__, 'message': str(error)}
        write_new(out / 'error.txt', traceback.format_exc().encode())
    finally:
        raw_stream.close()
        failed = sum(not c['passed'] for c in semantics['cases'])
        semantics['semantic_cases'] = {'total': len(semantics['cases']), 'passed': len(semantics['cases']) - failed,
                                       'failed': failed, 'names': [c['name'] for c in semantics['cases']]}
        for report, filename in ((semantics, 'semantics.json'), (benchmark, 'cold-abba.json')):
            report['raw_processes'] = artifact(raw_path)
            report['fresh_process_count'] = sequence
            report['finished_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
            write_new(out / filename, encode(report))
        print(json.dumps({'passed': semantics['passed'] and benchmark['passed'],
                          'semantics': artifact(out / 'semantics.json'), 'benchmark': artifact(out / 'cold-abba.json'),
                          'processes': sequence, 'error': semantics.get('error')}, sort_keys=True), flush=True)
    return 0 if semantics['passed'] and benchmark['passed'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
