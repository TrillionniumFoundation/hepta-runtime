REMOTE_DIRECTORY_SOURCE = "\nimport os, pathlib, stat, sys\n_hepta_directory_pins = []\ndef private_job_directory(raw, create=False):\n    if not isinstance(raw, str) or not raw.startswith(\"/\") or any(p in (\".\", \"..\") for p in raw.split(\"/\")):\n        raise SystemExit(\"unsafe remote job path\")\n    parts = [p for p in raw.split(\"/\") if p]\n    if len(parts) < 3 or parts[-2] != \"jobs\":\n        raise SystemExit(\"remote job path must name a dedicated state/jobs/job directory\")\n    shared_access = getattr(os, \"O_PATH\", os.O_RDONLY) if sys.platform == \"linux\" else os.O_RDONLY\n    path_only_shared = shared_access != os.O_RDONLY\n    directory_flags = os.O_DIRECTORY | os.O_NOFOLLOW | os.O_CLOEXEC\n    fd = os.open(\"/\", shared_access | directory_flags)\n    _hepta_directory_pins.append(fd)\n    for offset, part in enumerate(parts):\n        private = offset >= len(parts) - 3\n        if create and private and not path_only_shared:\n            try:\n                os.mkdir(part, mode=0o700, dir_fd=fd)\n                os.fsync(fd)\n            except FileExistsError:\n                pass\n        access = os.O_RDONLY if private else shared_access\n        try:\n            child = os.open(part, access | directory_flags, dir_fd=fd)\n        except FileNotFoundError:\n            if not (create and private and path_only_shared):\n                raise\n            # O_PATH traverses an existing searchable ancestor without reading it.\n            # A new child still needs its parent's original durability barrier:\n            # acquire a readable handle before mkdir, or refuse without creating.\n            sync_parent = os.open(\".\", os.O_RDONLY | directory_flags, dir_fd=fd)\n            _hepta_directory_pins.append(sync_parent)\n            pinned = os.fstat(fd)\n            readable = os.fstat(sync_parent)\n            if (pinned.st_dev, pinned.st_ino) != (readable.st_dev, readable.st_ino):\n                raise SystemExit(\"remote parent directory identity changed; no directory created\")\n            try:\n                os.mkdir(part, mode=0o700, dir_fd=sync_parent)\n            except FileExistsError:\n                pass\n            else:\n                os.fsync(sync_parent)\n            child = os.open(part, os.O_RDONLY | directory_flags, dir_fd=sync_parent)\n        _hepta_directory_pins.append(child)\n        info = os.fstat(child)\n        if private and (info.st_uid != os.geteuid() or stat.S_IMODE(info.st_mode) != 0o700):\n            raise SystemExit(\"unsafe remote state/jobs/job directory; existing permissions are never repaired\")\n        fd = child\n    os.fchdir(fd)\n    return pathlib.Path(\".\")\n\ndef private_bound_job_directory(raw, expected):\n    job = private_job_directory(raw)\n    info = os.fstat(_hepta_directory_pins[-1])\n    if (info.st_dev, info.st_ino) != (expected[\"device\"], expected[\"inode\"]):\n        raise SystemExit(\"remote job directory identity changed; no workload submitted\")\n    return job\n\ndef private_open_job_file(name):\n    try:\n        fd = os.open(name, os.O_RDONLY | os.O_NOFOLLOW | os.O_CLOEXEC | os.O_NONBLOCK,\n                     dir_fd=_hepta_directory_pins[-1])\n    except FileNotFoundError:\n        return None\n    except OSError as error:\n        raise SystemExit(\"unsafe remote job file \" + name) from error\n    info = os.fstat(fd)\n    if (not stat.S_ISREG(info.st_mode) or info.st_nlink != 1 or\n            info.st_uid != os.geteuid() or stat.S_IMODE(info.st_mode) & 0o022):\n        os.close(fd)\n        raise SystemExit(\"unsafe remote job file \" + name + \": non-regular or linked inode\")\n    return fd\n\ndef private_read_json(name):\n    import json\n    fd = private_open_job_file(name)\n    if fd is None: return None\n    with os.fdopen(fd, \"rb\") as stream:\n        before = os.fstat(stream.fileno())\n        if before.st_size > 4 * 1024 * 1024:\n            raise SystemExit(\"unsafe remote job file \" + name + \": linked or oversized inode\")\n        # Size the common allocation to the fresh snapshot, not the 4 MiB cap.\n        # A regular file may underreport its size; retain the original bounded\n        # read in that case before the unchanged metadata and JSON checks.\n        encoded = stream.read(max(0, before.st_size) + 1)\n        if encoded is not None and len(encoded) > before.st_size:\n            tail = stream.read(4 * 1024 * 1024 + 1 - len(encoded))\n            # BufferedReader preserves an available prefix when a later raw\n            # read would block. Keep that behavior without retrying the read.\n            if tail is not None:\n                encoded += tail\n        after = os.fstat(stream.fileno())\n        current = os.stat(name, dir_fd=_hepta_directory_pins[-1], follow_symlinks=False)\n    def stamp(info):\n        return (info.st_dev, info.st_ino, info.st_mode, info.st_uid, info.st_nlink,\n                info.st_size, info.st_mtime_ns, info.st_ctime_ns)\n    if len(encoded) > 4 * 1024 * 1024 or stamp(before) != stamp(after) or stamp(after) != stamp(current):\n        raise SystemExit(\"unsafe remote job file \" + name + \": changed while reading\")\n    try:\n        value = json.loads(encoded)\n        if not isinstance(value, dict): raise ValueError(\"not an object\")\n        return value\n    except (ValueError, UnicodeError) as error:\n        raise SystemExit(\"corrupt remote job file \" + name) from error\n\n"
exec(REMOTE_DIRECTORY_SOURCE)

import io, json
_original_query = json.load(sys.stdin)
_bound_job = private_job_directory(_original_query["job_dir"])
_bound_request = private_read_json("request.json")
_digest = _original_query.get("request_digest")
if (not isinstance(_bound_request, dict) or not isinstance(_digest, str) or len(_digest) != 64 or
        any(c not in "0123456789abcdef" for c in _digest) or
        _bound_request.get("job_id") != _original_query.get("job_id") or
        _bound_request.get("job_dir") != _original_query.get("job_dir") or
        _bound_request.get("unit") != _original_query.get("unit") or
        _bound_request.get("request_digest", _bound_request.get("request_fingerprint")) != _digest):
    raise SystemExit("remote job request binding missing or mismatched")
# Metadata is validated before a status can claim success or cancellation can
# acknowledge a terminal receipt. The status owner interprets a torn private
# started.json as unknown, and a confirmed terminal receipt takes precedence.
# Cancellation still validates its owner record before sending any signal.
for _name in ("launch.json", "exit.json"):
    private_read_json(_name)
sys.stdin = io.StringIO(json.dumps(_original_query))


import json, os, pathlib, stat, sys, time
q = json.load(sys.stdin)
job = private_job_directory(q["job_dir"])

def read_json(name):
    return private_read_json(name)

def process_identity(pid):
    if sys.platform == "linux":
        try:
            ticks = int(pathlib.Path(f"/proc/{pid}/stat").read_text().rsplit(") ", 1)[1].split()[19])
            boot = pathlib.Path("/proc/sys/kernel/random/boot_id").read_text().strip()
            return {"kind": "proc_start_ticks", "value": boot + ":" + str(ticks)} if boot else None
        except Exception:
            return None
    import subprocess
    try:
        value = subprocess.check_output(["ps", "-p", str(pid), "-o", "lstart="], text=True, timeout=3).strip()
        return {"kind": "ps_lstart", "value": value} if value else None
    except Exception:
        return None

def valid_owner(request, started, systemd=False):
    nonce = request.get("launch_nonce")
    identity = started.get("supervisor_identity")
    return (isinstance(nonce, str) and len(nonce) == 32 and all(c in "0123456789abcdef" for c in nonce) and
        started.get("job_id") == request.get("job_id") and started.get("launch_nonce") == nonce and
        type(started.get("supervisor_uid")) is int and started["supervisor_uid"] == os.geteuid() and
        type(started.get("supervisor_pid")) is int and 1 < started["supervisor_pid"] <= 2147483647 and
        isinstance(identity, dict) and identity.get("kind") == ("proc_start_ticks" if sys.platform == "linux" else "ps_lstart") and
        isinstance(identity.get("value"), str) and bool(identity["value"]) and
        (not systemd or (isinstance(started.get("invocation_id"), str) and len(started["invocation_id"]) == 32 and
            all(c in "0123456789abcdef" for c in started["invocation_id"]))))

def process_uid(pid):
    if sys.platform == "linux": return pathlib.Path(f"/proc/{pid}").stat().st_uid
    import subprocess
    return int(subprocess.check_output(["ps", "-p", str(pid), "-o", "uid="], text=True, timeout=3).strip())

def publication_pending(reason):
    return {"state": "finalizing", "outcome": "unknown", "reason": reason,
            "terminal_publication_confirmed": False,
            "status_authoritative": False, "automatic_retry": False}

def read_terminal_file(name, limit, missing_ok=False):
    # Relative to the already pinned job directory; never follow a receipt
    # symlink or wait on a substituted FIFO. Hash and parse this one snapshot.
    try:
        fd = os.open(name, os.O_RDONLY | os.O_NOFOLLOW | os.O_CLOEXEC | os.O_NONBLOCK,
                     dir_fd=_hepta_directory_pins[-1])
    except FileNotFoundError:
        if missing_ok:
            return None
        raise
    # Keep sole descriptor ownership even if fdopen rejects a substituted file.
    try:
        with os.fdopen(fd, "rb", closefd=False) as stream:
            before = os.fstat(stream.fileno())
            if (not stat.S_ISREG(before.st_mode) or before.st_uid != os.geteuid() or
                    before.st_nlink != 1 or stat.S_IMODE(before.st_mode) != 0o600 or before.st_size > limit):
                raise ValueError("unsafe terminal publication file")
            # The checks below already require exactly this fresh snapshot size.
            encoded = stream.read(max(0, before.st_size) + 1)
            after = os.fstat(stream.fileno())
            current = os.stat(name, dir_fd=_hepta_directory_pins[-1], follow_symlinks=False)
    finally:
        os.close(fd)
    def stamp(info):
        return (info.st_dev, info.st_ino, info.st_mode, info.st_uid, info.st_nlink,
                info.st_size, info.st_mtime_ns, info.st_ctime_ns)
    if (len(encoded) > limit or len(encoded) != before.st_size or
            stamp(before) != stamp(after) or stamp(after) != stamp(current)):
        raise ValueError("terminal publication file changed")
    return encoded

def read_owner_binding():
    # An interrupted O_EXCL owner write is a permanent no-replay tombstone.
    # Only malformed bytes in a verified private regular file become Unknown;
    # unsafe paths, ownership/mode changes and read failures still propagate.
    encoded = read_terminal_file("started.json", 16 * 1024, missing_ok=True)
    if encoded is None:
        return {}
    try:
        value = json.loads(encoded)
    except ValueError:
        return {}
    return value if isinstance(value, dict) else {}

def read_terminal_status(request):
    field = "terminal_publication_protocol"
    if field in request and (type(request[field]) is not int or request[field] != 1):
        return publication_pending("terminal publication protocol is unsupported")
    try:
        encoded = read_terminal_file("exit.json", 1024 * 1024)
    except FileNotFoundError:
        return None
    except (OSError, ValueError):
        return publication_pending("terminal receipt is unavailable or unsafe")
    try:
        exit_data = json.loads(encoded)
        if not isinstance(exit_data, dict):
            raise ValueError("terminal receipt must be an object")
        if field not in request and field not in exit_data:
            return final_status(exit_data)
        if type(exit_data.get(field)) is not int or exit_data[field] != 1:
            return publication_pending("terminal publication protocol is missing or unsupported")
        nonce = request.get("launch_nonce")
        if (not isinstance(nonce, str) or len(nonce) != 32 or
                not all(c in "0123456789abcdef" for c in nonce) or
                exit_data.get("job_id") != request["job_id"] or exit_data.get("launch_nonce") != nonce):
            return publication_pending("terminal receipt identity does not match the original request")
        import hashlib
        witness = json.loads(read_terminal_file("exit.witness.json", 4096))
        if (not isinstance(witness, dict) or type(witness.get(field)) is not int or witness[field] != 1 or
                witness.get("job_id") != request["job_id"] or witness.get("launch_nonce") != nonce or
                witness.get("exit_sha256") != hashlib.sha256(encoded).hexdigest()):
            return publication_pending("terminal publication witness does not match the original receipt")
        result = final_status(exit_data)
        result["terminal_publication_confirmed"] = True
        result["automatic_retry"] = False
        return result
    except (OSError, ValueError, TypeError, KeyError):
        return publication_pending("terminal publication witness or receipt is unavailable or invalid")

def final_status(exit_data):
    if exit_data.get("effect_outcome") == "unknown":
        state = "effect_unknown"
    elif exit_data.get("timed_out"):
        state = "timed_out"
    elif exit_data.get("cancelled"):
        state = "cancelled"
    elif int(exit_data.get("exit_code", -1)) == 0:
        # Legacy receipts without these additive fields remain readable.
        output_failed = any(name in exit_data and exit_data[name] is not True
                            for name in ("output_complete", "output_durable"))
        state = "failed" if output_failed else "succeeded"
    else:
        state = "failed"
    return {**exit_data, "state": state}

def one_status():
    request = read_json("request.json")
    if not request or request.get("job_id") != q["job_id"]:
        return {"state": "unknown", "reason": "remote job metadata missing or mismatched"}
    terminal = read_terminal_status(request)
    if terminal is not None:
        return terminal
    requires_witness = "terminal_publication_protocol" in request
    launch = read_json("launch.json") or {}
    if launch.get("backend") == "systemd":
        uid = os.getuid()
        env = os.environ.copy()
        env.setdefault("XDG_RUNTIME_DIR", f"/run/user/{uid}")
        env.setdefault("DBUS_SESSION_BUS_ADDRESS", f"unix:path=/run/user/{uid}/bus")
        import subprocess
        p = subprocess.run(
            ["systemctl", "--user", "show", q["unit"], "--no-pager",
             "--property=LoadState,ActiveState,SubState,Result,ExecMainPID,ExecMainCode,ExecMainStatus,InvocationID,Description"],
            stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, env=env)
        props = {}
        for line in p.stdout.splitlines():
            if "=" in line:
                k, v = line.split("=", 1); props[k] = v
        # A --collect unit can disappear immediately after the runner exits.
        # Re-read the atomic exit record after querying systemd to close that race.
        terminal = read_terminal_status(request)
        if terminal is not None:
            return terminal
        started = read_owner_binding()
        nonce = request.get("launch_nonce")
        invocation = started.get("invocation_id")
        if not valid_owner(request, started, systemd=True):
            return {"state":"owner_unknown","reason":"frozen supervisor binding unavailable",
                    "status_authoritative":False,"automatic_retry":False}
        if props.get("LoadState") != "not-found" and (props.get("InvocationID") != invocation or
                props.get("Description") != f"Hepta Runtime job {q['job_id']} {nonce}"):
            return {"state":"owner_unknown","reason":"unit incarnation differs from frozen supervisor",
                    "status_authoritative":False,"automatic_retry":False}
        active = props.get("ActiveState")
        sub = props.get("SubState")
        if active in ("active", "activating") and sub not in ("exited", "dead"):
            try: matching = process_identity(started["supervisor_pid"]) == started["supervisor_identity"] and process_uid(started["supervisor_pid"]) == started["supervisor_uid"]
            except (OSError, ValueError, subprocess.SubprocessError): matching = False
            if not matching:
                return {"state":"owner_unknown","reason":"frozen supervisor PID/start/UID unavailable or changed",
                        "status_authoritative":False,"automatic_retry":False}
            state = "running"
        elif active == "failed":
            if requires_witness:
                return publication_pending("supervisor exited without a confirmed terminal receipt")
            state = "failed"
        elif active == "active" and sub == "exited":
            if requires_witness:
                return publication_pending("supervisor exited without a confirmed terminal receipt")
            # RemainAfterExit can become visible a few microseconds before the
            # supervisor's atomic exit.json rename. systemd already has the
            # authoritative process result, so use it rather than returning a
            # false completed_unknown race.
            try:
                exit_code = int(props.get("ExecMainStatus", "-1"))
            except ValueError:
                exit_code = -1
            if props.get("ExecMainCode") == "1":
                state = "succeeded" if exit_code == 0 else "failed"
                return {"state": state, "backend": "systemd", "exit_code": exit_code, "systemd": props}
            state = "completed_unknown"
        elif props.get("LoadState") == "not-found":
            if requires_witness:
                return publication_pending("supervisor disappeared without a confirmed terminal receipt")
            state = "finalizing"
        else:
            if requires_witness:
                return publication_pending("supervisor has no confirmed terminal receipt")
            state = active or "unknown"
        return {"state": state, "backend": "systemd", "systemd": props}
    started = read_owner_binding()
    if not valid_owner(request, started):
        return {"state":"owner_unknown","reason":"frozen supervisor binding unavailable",
                "status_authoritative":False,"automatic_retry":False}
    pid = started["supervisor_pid"]
    expected = started["supervisor_identity"]
    actual = process_identity(pid)
    running = bool(pid and actual is not None and (expected is not None and expected == actual))
    if not running and requires_witness:
        return publication_pending("supervisor disappeared without a confirmed terminal receipt")
    return {"state": "running" if running else "lost", "backend": launch.get("backend", "detached"), "pid": pid, "identity": actual}

deadline = time.monotonic() + min(float(q.get("wait_seconds", 0)), 30.0)
while True:
    status = one_status()
    state = status.get("state")
    transient = state in ("running", "activating", "finalizing", "completed_unknown")
    now = time.monotonic()
    if not transient or now >= deadline:
        if (now >= deadline and state in ("finalizing", "completed_unknown") and
                status.get("terminal_publication_confirmed") is not False):
            status["state"] = "lost"
            status["reason"] = "no exit record appeared before the wait deadline"
        status["job_id"] = q["job_id"]
        print(json.dumps(status, sort_keys=True))
        break
    time.sleep(0.1)
