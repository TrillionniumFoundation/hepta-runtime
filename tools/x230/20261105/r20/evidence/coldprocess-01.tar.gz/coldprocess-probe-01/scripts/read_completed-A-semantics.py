import sys
_r20_initial_modules = set(sys.modules)
_r20_mock_calls = []
_r20_extra = {}
REMOTE_DIRECTORY_SOURCE = "\nimport os, pathlib, stat, sys\n_hepta_directory_pins = []\ndef private_job_directory(raw, create=False):\n    if not isinstance(raw, str) or not raw.startswith(\"/\") or any(p in (\".\", \"..\") for p in raw.split(\"/\")):\n        raise SystemExit(\"unsafe remote job path\")\n    parts = [p for p in raw.split(\"/\") if p]\n    if len(parts) < 3 or parts[-2] != \"jobs\":\n        raise SystemExit(\"remote job path must name a dedicated state/jobs/job directory\")\n    shared_access = getattr(os, \"O_PATH\", os.O_RDONLY) if sys.platform == \"linux\" else os.O_RDONLY\n    path_only_shared = shared_access != os.O_RDONLY\n    directory_flags = os.O_DIRECTORY | os.O_NOFOLLOW | os.O_CLOEXEC\n    fd = os.open(\"/\", shared_access | directory_flags)\n    _hepta_directory_pins.append(fd)\n    for offset, part in enumerate(parts):\n        private = offset >= len(parts) - 3\n        if create and private and not path_only_shared:\n            try:\n                os.mkdir(part, mode=0o700, dir_fd=fd)\n                os.fsync(fd)\n            except FileExistsError:\n                pass\n        access = os.O_RDONLY if private else shared_access\n        try:\n            child = os.open(part, access | directory_flags, dir_fd=fd)\n        except FileNotFoundError:\n            if not (create and private and path_only_shared):\n                raise\n            # O_PATH traverses an existing searchable ancestor without reading it.\n            # A new child still needs its parent's original durability barrier:\n            # acquire a readable handle before mkdir, or refuse without creating.\n            sync_parent = os.open(\".\", os.O_RDONLY | directory_flags, dir_fd=fd)\n            _hepta_directory_pins.append(sync_parent)\n            pinned = os.fstat(fd)\n            readable = os.fstat(sync_parent)\n            if (pinned.st_dev, pinned.st_ino) != (readable.st_dev, readable.st_ino):\n                raise SystemExit(\"remote parent directory identity changed; no directory created\")\n            try:\n                os.mkdir(part, mode=0o700, dir_fd=sync_parent)\n            except FileExistsError:\n                pass\n            else:\n                os.fsync(sync_parent)\n            child = os.open(part, os.O_RDONLY | directory_flags, dir_fd=sync_parent)\n        _hepta_directory_pins.append(child)\n        info = os.fstat(child)\n        if private and (info.st_uid != os.geteuid() or stat.S_IMODE(info.st_mode) != 0o700):\n            raise SystemExit(\"unsafe remote state/jobs/job directory; existing permissions are never repaired\")\n        fd = child\n    os.fchdir(fd)\n    return pathlib.Path(\".\")\n\ndef private_bound_job_directory(raw, expected):\n    job = private_job_directory(raw)\n    info = os.fstat(_hepta_directory_pins[-1])\n    if (info.st_dev, info.st_ino) != (expected[\"device\"], expected[\"inode\"]):\n        raise SystemExit(\"remote job directory identity changed; no workload submitted\")\n    return job\n\ndef private_open_job_file(name):\n    try:\n        fd = os.open(name, os.O_RDONLY | os.O_NOFOLLOW | os.O_CLOEXEC | os.O_NONBLOCK,\n                     dir_fd=_hepta_directory_pins[-1])\n    except FileNotFoundError:\n        return None\n    except OSError as error:\n        raise SystemExit(\"unsafe remote job file \" + name) from error\n    info = os.fstat(fd)\n    if (not stat.S_ISREG(info.st_mode) or info.st_nlink != 1 or\n            info.st_uid != os.geteuid() or stat.S_IMODE(info.st_mode) & 0o022):\n        os.close(fd)\n        raise SystemExit(\"unsafe remote job file \" + name + \": non-regular or linked inode\")\n    return fd\n\ndef private_read_json(name):\n    import json\n    fd = private_open_job_file(name)\n    if fd is None: return None\n    with os.fdopen(fd, \"rb\") as stream:\n        before = os.fstat(stream.fileno())\n        if before.st_size > 4 * 1024 * 1024:\n            raise SystemExit(\"unsafe remote job file \" + name + \": linked or oversized inode\")\n        # Size the common allocation to the fresh snapshot, not the 4 MiB cap.\n        # A regular file may underreport its size; retain the original bounded\n        # read in that case before the unchanged metadata and JSON checks.\n        encoded = stream.read(max(0, before.st_size) + 1)\n        if encoded is not None and len(encoded) > before.st_size:\n            tail = stream.read(4 * 1024 * 1024 + 1 - len(encoded))\n            # BufferedReader preserves an available prefix when a later raw\n            # read would block. Keep that behavior without retrying the read.\n            if tail is not None:\n                encoded += tail\n        after = os.fstat(stream.fileno())\n        current = os.stat(name, dir_fd=_hepta_directory_pins[-1], follow_symlinks=False)\n    def stamp(info):\n        return (info.st_dev, info.st_ino, info.st_mode, info.st_uid, info.st_nlink,\n                info.st_size, info.st_mtime_ns, info.st_ctime_ns)\n    if len(encoded) > 4 * 1024 * 1024 or stamp(before) != stamp(after) or stamp(after) != stamp(current):\n        raise SystemExit(\"unsafe remote job file \" + name + \": changed while reading\")\n    try:\n        value = json.loads(encoded)\n        if not isinstance(value, dict): raise ValueError(\"not an object\")\n        return value\n    except (ValueError, UnicodeError) as error:\n        raise SystemExit(\"corrupt remote job file \" + name) from error\n\n"
exec(REMOTE_DIRECTORY_SOURCE)

import io, json
_original_query = json.load(sys.stdin)
_bound_job = private_job_directory(_original_query["job_dir"])
_bound_request = private_read_json("request.json")
_digest = _original_query.get("request_digest")
if (not isinstance(_bound_request, dict) or not isinstance(_digest, str) or len(_digest) != 64 or
        any(c not in "0123456789abcdef" for c in _digest) or
        _bound_request.get("job_id") != _original_query.get("job_id") or
        _bound_request.get("job_dir") != _original_query.get("job_dir") or
        _bound_request.get("unit") != _original_query.get("unit") or
        _bound_request.get("request_digest", _bound_request.get("request_fingerprint")) != _digest):
    raise SystemExit("remote job request binding missing or mismatched")
# Metadata is validated before a status can claim success or cancellation can
# acknowledge a terminal receipt. The status owner interprets a torn private
# started.json as unknown, and a confirmed terminal receipt takes precedence.
# Cancellation still validates its owner record before sending any signal.
for _name in ("launch.json", "exit.json"):
    private_read_json(_name)
sys.stdin = io.StringIO(json.dumps(_original_query))


import json, pathlib, sys
q = json.load(sys.stdin)
job = private_job_directory(q["job_dir"])
try:
    request = private_read_json("request.json")
except Exception:
    raise SystemExit("remote job metadata missing")
if request.get("job_id") != q["job_id"]:
    raise SystemExit("remote job metadata mismatch")
limit = max(1, min(int(q.get("limit", 16384)), 16384))

def read_part(name, offset):
    fd = private_open_job_file(name)
    offset = max(0, int(offset or 0))
    data = b""
    size = 0
    if fd is not None:
        with os.fdopen(fd, "rb") as stream:
            before = os.fstat(stream.fileno())
            size = before.st_size
            if offset > size: raise SystemExit("cursor exceeds log length; refusing silent rewind")
            stream.seek(offset)
            data = stream.read(min(limit, size - offset))
            current = os.stat(name, dir_fd=_hepta_directory_pins[-1], follow_symlinks=False)
            after = os.fstat(stream.fileno())
            if (current.st_dev, current.st_ino) != (before.st_dev, before.st_ino) or after.st_nlink != 1 or after.st_size < size:
                raise SystemExit("remote log identity changed while reading")
    elif offset:
        raise SystemExit("cursor exceeds log length; refusing silent rewind")
    return {"offset": offset, "next_offset": offset + len(data), "size": size,
            "eof": offset + len(data) >= size, "text": data.decode("utf-8", errors="replace"),
            "bytes_hex": data.hex()}

print(json.dumps({
    "job_id": q["job_id"],
    "stdout": read_part("stdout.log", q.get("stdout_offset", 0)),
    "stderr": read_part("stderr.log", q.get("stderr_offset", 0)),
}, sort_keys=True))

print('R20_PROBE_METADATA ' + json.dumps({"subprocess_loaded": "subprocess" in sys.modules, "initial_subprocess_loaded": "subprocess" in _r20_initial_modules, "new_modules": sorted(set(sys.modules) - _r20_initial_modules), "mock_calls": _r20_mock_calls, "extra": _r20_extra}, sort_keys=True), file=sys.stderr)
