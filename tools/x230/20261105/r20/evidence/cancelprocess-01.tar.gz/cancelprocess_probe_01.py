#!/usr/bin/env python3
"""Closed R20 CANCEL mechanism probe; full X230 run or local mock-only smoke.

Full measurements use exact production scripts. Target creation and reaping are
outside helper timing/CPU samples. Local branch-smoke never creates a target or
executes a real pidfd/signal, and cannot pass the full mechanism screen.
"""
import argparse
import ast
import atexit
import builtins
import contextlib
import datetime
import hashlib
import io
import json
import math
import os
from pathlib import Path
import re
import resource
import secrets
import select
import signal
import stat
import statistics
import subprocess
import sys
import time
import traceback

A_SHA = '2f751c09a9a29bebb0cda0a9bd2bb522d145ee8183740ed1442d77666ee44aa7'
B_SHA = '1f1f086e3bc0fc62184ed51949964e1f82e337b87d330225097ae38722e4ac8c'
CONSTANTS = ('PRIVATE_DIRECTORY_CODE', 'BOUND_OBSERVATION_CODE', 'START_CODE', 'STATUS_CODE', 'READ_CODE', 'CANCEL_CODE')
SCENES = ('cancel_already_exited', 'cancel_linux_owned_pidfd', 'read_control')
SPECS = [
    ('already_exited_native', 'cancel_already_exited', 'native', None),
    ('pidfd_owned_native', 'cancel_linux_owned_pidfd', 'native', None),
    ('read_control_native', 'read_control', 'native', None),
    ('pidfd_mock_success', 'cancel_linux_owned_pidfd', 'mock', None),
    ('pidfd_unavailable', 'cancel_linux_owned_pidfd', 'mock', 'pidfd_unavailable'),
    ('pidfd_open_failure', 'cancel_linux_owned_pidfd', 'mock', 'pidfd_open_failure'),
    ('pidfd_signal_failure', 'cancel_linux_owned_pidfd', 'mock', 'pidfd_signal_failure'),
    ('missing_owner', 'cancel_linux_owned_pidfd', 'mock', 'missing_owner'),
    ('invalid_owner', 'cancel_linux_owned_pidfd', 'mock', 'invalid_owner'),
    ('identity_mismatch', 'cancel_linux_owned_pidfd', 'mock', 'identity_mismatch'),
    ('uid_mismatch', 'cancel_linux_owned_pidfd', 'mock', 'uid_mismatch'),
    ('publication_failure', 'cancel_linux_owned_pidfd', 'mock', 'publication_failure'),
    ('nonlinux_success', 'cancel_linux_owned_pidfd', 'mock', 'nonlinux_success'),
    ('nonlinux_ps_failure', 'cancel_linux_owned_pidfd', 'mock', 'nonlinux_ps_failure'),
    ('nonlinux_revalidate_identity', 'cancel_linux_owned_pidfd', 'mock', 'nonlinux_revalidate_identity'),
    ('nonlinux_revalidate_uid', 'cancel_linux_owned_pidfd', 'mock', 'nonlinux_revalidate_uid'),
    ('binding_mismatch', 'cancel_linux_owned_pidfd', 'mock', 'binding_mismatch')]
SMOKE = ('pidfd_mock_success', 'identity_mismatch', 'nonlinux_success')
MARKER = 'R20_CANCEL_METADATA '
USAGE_FIELDS = ('ru_utime', 'ru_stime', 'ru_maxrss', 'ru_ixrss', 'ru_idrss', 'ru_isrss', 'ru_minflt',
                'ru_majflt', 'ru_nswap', 'ru_inblock', 'ru_oublock', 'ru_msgsnd', 'ru_msgrcv',
                'ru_nsignals', 'ru_nvcsw', 'ru_nivcsw')
FAKE_PID = 424242
FAKE_BOOT = '00000000-0000-4000-8000-000000000020'
FAKE_TICKS = 1234567
PS_START = 'Wed Nov  4 12:34:56 2026'
READ_BYTES = b'R20 cancel read control\n'


def need(ok, why):
    if not ok:
        raise ValueError(why)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def encode(value):
    return (json.dumps(value, indent=2, sort_keys=True) + '\n').encode()


def write_new(path, raw):
    with path.open('xb') as stream:
        stream.write(raw)


def artifact(path):
    raw = path.read_bytes()
    return {'path': str(path), 'bytes': len(raw), 'sha256': sha(raw)}


def usage():
    value = resource.getrusage(resource.RUSAGE_CHILDREN)
    return {key: getattr(value, key) for key in USAGE_FIELDS}


def cpu_delta(before, after):
    return after['ru_utime'] + after['ru_stime'] - before['ru_utime'] - before['ru_stime']


def extracted(path, expected):
    raw = path.read_bytes(); need(sha(raw) == expected, 'source SHA256 differs: ' + str(path))
    constants = {}
    for name in CONSTANTS:
        values = re.findall(r'const ' + name + r': &str = r#"(.*?)"#;', raw.decode(), re.S)
        need(len(values) == 1, 'constant not unique: ' + name)
        ast.parse(values[0]); constants[name] = values[0]
    return raw, constants


class WithoutImports(ast.NodeTransformer):
    def visit_Import(self, node):
        return None

    def visit_ImportFrom(self, node):
        return None


def production(constants, scene):
    body = 'REMOTE_DIRECTORY_SOURCE = ' + json.dumps(constants['PRIVATE_DIRECTORY_CODE'], ensure_ascii=False) + '\nexec(REMOTE_DIRECTORY_SOURCE)\n'
    return body + constants['BOUND_OBSERVATION_CODE'] + '\n' + constants['READ_CODE' if scene == 'read_control' else 'CANCEL_CODE']


DIAGNOSTICS = r'''
import atexit, json, os, pathlib, signal, sys
_r20_initial_subprocess = "subprocess" in sys.modules
_r20_events, _r20_opened, _r20_closed = [], [], []
_r20_original_close, _r20_original_fstat = os.close, os.fstat
_r20_original_open = getattr(os, "pidfd_open", None)
_r20_original_send = getattr(signal, "pidfd_send_signal", None)
_r20_original_read_text, _r20_original_stat = pathlib.Path.read_text, pathlib.Path.stat
_r20_ps_counts = {"lstart=": 0, "uid=": 0}
def _r20_open(pid, flags=0):
    assert pid == _r20_cfg["pid"] and flags == 0
    if _r20_cfg["fault"] == "pidfd_open_failure":
        _r20_events.append({"kind": "pidfd_open_failed", "pid": pid})
        raise PermissionError(1, "R20 deliberate pidfd-open failure")
    fd = _r20_original_open(pid, flags) if _r20_cfg["mode"] == "native" else os.open(os.devnull, os.O_RDONLY | os.O_CLOEXEC)
    _r20_opened.append(fd); _r20_events.append({"kind": "pidfd_open", "pid": pid, "fd": fd})
    return fd
def _r20_send(fd, signum, siginfo=None, flags=0):
    assert fd in _r20_opened and fd not in _r20_closed and signum == signal.SIGTERM and siginfo is None and flags == 0
    event = {"kind": "pidfd_send_signal", "fd": fd, "signal": signum, "returned": False, "mock": _r20_cfg["mode"] == "mock"}
    _r20_events.append(event)
    if _r20_cfg["fault"] == "pidfd_signal_failure": raise PermissionError(1, "R20 deliberate pidfd-signal failure")
    if _r20_cfg["mode"] == "native": _r20_original_send(fd, signum, siginfo, flags)
    event["returned"] = True
def _r20_close(fd):
    if fd in _r20_opened:
        _r20_closed.append(fd); _r20_events.append({"kind": "pidfd_close", "fd": fd})
    return _r20_original_close(fd)
def _r20_kill(pid, signum):
    assert _r20_cfg["mode"] == "mock" and pid == _r20_cfg["pid"] and signum == signal.SIGTERM
    _r20_events.append({"kind": "os_kill", "pid": pid, "signal": signum, "mock": True})
def _r20_read_text(path, *args, **kwargs):
    name = str(path)
    if name == "/proc/" + str(_r20_cfg["pid"]) + "/stat":
        _r20_events.append({"kind": "proc_identity"})
        ticks = _r20_cfg["ticks"] + (1 if _r20_cfg["fault"] == "identity_mismatch" else 0)
        return str(_r20_cfg["pid"]) + " (r20-cancel-mock) " + " ".join(["S"] + ["0"] * 18 + [str(ticks)])
    if name == "/proc/sys/kernel/random/boot_id": return _r20_cfg["boot"] + "\n"
    return _r20_original_read_text(path, *args, **kwargs)
def _r20_stat(path, *args, **kwargs):
    if str(path) == "/proc/" + str(_r20_cfg["pid"]):
        _r20_events.append({"kind": "proc_uid"})
        class _Uid: pass
        result = _Uid(); result.st_uid = _r20_cfg["uid"] + (1 if _r20_cfg["fault"] == "uid_mismatch" else 0)
        return result
    return _r20_original_stat(path, *args, **kwargs)
os.close, os.kill = _r20_close, _r20_kill
os.pidfd_open, signal.pidfd_send_signal = _r20_open, _r20_send
if _r20_cfg["mode"] == "mock":
    pathlib.Path.read_text, pathlib.Path.stat = _r20_read_text, _r20_stat
if _r20_cfg["fault"] == "pidfd_unavailable": del os.pidfd_open
if _r20_cfg["nonlinux"]:
    import subprocess as _r20_subprocess
    def _r20_check_output(argv, **kwargs):
        assert argv[:4] == ["ps", "-p", str(_r20_cfg["pid"]), "-o"] and argv[4] in _r20_ps_counts
        assert kwargs == {"text": True, "timeout": 3}
        key = argv[4]; _r20_ps_counts[key] += 1
        _r20_events.append({"kind": "ps", "argv": argv, "call": _r20_ps_counts[key]})
        if key == "lstart=":
            if _r20_cfg["fault"] == "nonlinux_ps_failure": raise _r20_subprocess.CalledProcessError(1, argv)
            if _r20_cfg["fault"] == "nonlinux_revalidate_identity" and _r20_ps_counts[key] == 2: return "changed identity\n"
            return _r20_cfg["ps_start"] + "\n"
        value = _r20_cfg["uid"] + (1 if _r20_cfg["fault"] == "nonlinux_revalidate_uid" and _r20_ps_counts[key] == 2 else 0)
        return str(value) + "\n"
    _r20_subprocess.check_output = _r20_check_output
    sys.platform = "darwin"
def _r20_emit():
    open_fds = []
    for fd in _r20_opened:
        try: _r20_original_fstat(fd)
        except OSError: pass
        else: open_fds.append(fd)
    print("R20_CANCEL_METADATA " + json.dumps({"mode": _r20_cfg["mode"], "events": _r20_events,
        "opened": _r20_opened, "closed": _r20_closed, "still_open": open_fds, "ps_counts": _r20_ps_counts,
        "subprocess_loaded": "subprocess" in sys.modules, "initial_subprocess_loaded": _r20_initial_subprocess}, sort_keys=True), file=sys.stderr)
if not _r20_cfg["inprocess"]: atexit.register(_r20_emit)
'''

BLOCK_IMPORT = r'''
import builtins as _r20_builtins
_r20_original_import = _r20_builtins.__import__
def _r20_block(name, *args, **kwargs):
    if name == "subprocess": raise ImportError("R20 deliberate unavailable subprocess")
    return _r20_original_import(name, *args, **kwargs)
_r20_builtins.__import__ = _r20_block
'''

TARGET_CODE = r'''
import json, os, pathlib, select, sys
pid = os.getpid()
ticks = int(pathlib.Path("/proc/" + str(pid) + "/stat").read_text().rsplit(") ", 1)[1].split()[19])
boot = pathlib.Path("/proc/sys/kernel/random/boot_id").read_text().strip()
print(json.dumps({"pid": pid, "uid": os.geteuid(), "nonce": sys.argv[1],
                  "identity": {"kind": "proc_start_ticks", "value": boot + ":" + str(ticks)}}, sort_keys=True), flush=True)
ready, _, _ = select.select([sys.stdin.buffer], [], [], 45)
if ready: sys.stdin.buffer.read(1)
else: raise SystemExit(87)
'''


def script(constants, case, phase, inprocess=False, blocked=False):
    body = production(constants, case['scene'])
    if phase == 'benchmark':
        need(not blocked and case['mode'] == 'native', 'benchmark must be a native production body')
        return body
    config = {'mode': case['mode'], 'fault': case['fault'], 'pid': case['owner']['supervisor_pid'],
              'uid': os.geteuid(), 'ticks': FAKE_TICKS, 'boot': FAKE_BOOT, 'ps_start': PS_START,
              'nonlinux': case['nonlinux'], 'inprocess': inprocess}
    result = '_r20_cfg = ' + repr(config) + '\n' + DIAGNOSTICS + (BLOCK_IMPORT if blocked else '') + body
    ast.parse(result)
    return result


def snapshot(folder):
    return {p.name: {'bytes': p.stat().st_size, 'mode': stat.S_IMODE(p.stat().st_mode), 'sha256': sha(p.read_bytes())}
            for p in sorted(folder.iterdir()) if p.is_file()}


def fixture(out, spec, variant, phase, number, real_owner=None):
    name, scene, mode, fault = spec
    job = out / 'fixtures' / phase / (str(number).zfill(5) + '-' + variant) / 'state' / 'jobs' / name
    job.mkdir(parents=True, mode=0o700)
    for path in (job.parent.parent, job.parent, job): os.chmod(path, 0o700)
    nonlinux = bool(fault and fault.startswith('nonlinux'))
    owner = real_owner or {'supervisor_pid': FAKE_PID, 'supervisor_uid': os.geteuid(),
                          'supervisor_identity': {'kind': 'proc_start_ticks', 'value': FAKE_BOOT + ':' + str(FAKE_TICKS)}}
    owner = dict(owner, job_id=name, launch_nonce='e' * 32, invocation_id='f' * 32)
    if nonlinux: owner['supervisor_identity'] = {'kind': 'ps_lstart', 'value': PS_START}
    q = {'job_id': name, 'job_dir': str(job), 'unit': 'hepta-r20-cancel-' + name,
         'request_digest': 'd' * 64, 'grace_seconds': 0, 'stdout_offset': 0, 'stderr_offset': 0, 'limit': 16384}
    request = {**q, 'launch_nonce': 'e' * 32, 'terminal_publication_protocol': 1}
    docs = {'request.json': request, 'launch.json': {'backend': 'detached'}}
    if scene in ('cancel_already_exited', 'read_control'):
        docs['exit.json'] = {'job_id': name, 'launch_nonce': 'e' * 32, 'exit_code': 0, 'output_complete': True,
                             'output_durable': True, 'cancelled': False, 'timed_out': False, 'terminal_publication_protocol': 1}
        # With no owner, a missing terminal file cannot authorize any signal.
    elif fault != 'missing_owner':
        docs['started.json'] = dict(owner, launch_nonce='a' * 32) if fault == 'invalid_owner' else owner
    if fault == 'binding_mismatch': q['request_digest'] = 'b' * 64
    for filename, data in docs.items(): write_new(job / filename, encode(data))
    write_new(job / 'stdout.log', READ_BYTES); write_new(job / 'stderr.log', b'')
    if fault == 'publication_failure': write_new(job / 'cancel-request.json.tmp', b'R20 preexisting owned temporary file\n')
    return {'name': name, 'scene': scene, 'mode': mode, 'fault': fault, 'owner': owner, 'query': q,
            'nonlinux': nonlinux, 'job': job, 'before': snapshot(job)}


def observe_fixture(case):
    after = snapshot(case['job'])
    need(all(after.get(name) == identity for name, identity in case['before'].items()), 'preexisting fixture changed')
    added = set(after) - set(case['before'])
    need(added <= {'cancel-request.json'}, 'unexpected fixture publication')
    publication = None
    if 'cancel-request.json' in after:
        publication = json.loads((case['job'] / 'cancel-request.json').read_bytes())
        need(set(publication) == {'at_unix_ms', 'job_id', 'launch_nonce'} and
             type(publication['at_unix_ms']) is int and publication['at_unix_ms'] > 0 and
             publication['job_id'] == case['name'] and publication['launch_nonce'] == 'e' * 32 and
             after['cancel-request.json']['mode'] == 0o600, 'cancel request publication binding')
    return {'before': case['before'], 'after': after, 'published': publication,
            'path': str(case['job']), 'preexisting_unchanged': True}


def proc_identity(pid):
    info = Path('/proc', str(pid))
    ticks = int((info / 'stat').read_text().rsplit(') ', 1)[1].split()[19])
    boot = Path('/proc/sys/kernel/random/boot_id').read_text().strip()
    need(bool(boot), 'missing Linux boot identity')
    return {'pid': pid, 'uid': info.stat().st_uid, 'identity': {'kind': 'proc_start_ticks', 'value': boot + ':' + str(ticks)}}


def acquire_guard(child, argv):
    need(child.returncode is None, 'direct child already reaped before guard')
    before = proc_identity(child.pid)
    expected = b'\0'.join(arg.encode() for arg in argv) + b'\0'
    command = Path('/proc', str(child.pid), 'cmdline').read_bytes()
    need(before['uid'] == os.geteuid() and command == expected, 'owned child PID/UID/argv cannot be confirmed')
    fd = os.pidfd_open(child.pid, 0)
    try:
        need(proc_identity(child.pid) == before, 'owned child identity changed during pidfd binding')
    except BaseException:
        os.close(fd); raise
    return {'fd': fd, **before, 'cmdline_sha256': sha(command), 'direct_popen_child': True}


def signal_owned(child, guard, signum):
    need(guard is not None and child.returncode is None and guard['pid'] == child.pid
         and proc_identity(child.pid) == {k: guard[k] for k in ('pid', 'uid', 'identity')}, 'cleanup identity mismatch; no signal sent')
    signal.pidfd_send_signal(guard['fd'], signum, None, 0)


class Target:
    def __init__(self, python, out, number):
        self.out, self.number, self.guard = out, number, None
        self.nonce, self.ready_raw = secrets.token_hex(16), b''
        self.argv = [python, '-B', '-u', '-c', TARGET_CODE, self.nonce]
        self.setup_start = time.monotonic_ns()
        self.child = subprocess.Popen(self.argv, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE, bufsize=0)
        try:
            ready, _, _ = select.select([self.child.stdout], [], [], 5)
            need(bool(ready), 'owned target readiness timed out')
            self.ready_raw = self.child.stdout.readline(4097)
            need(0 < len(self.ready_raw) <= 4096 and self.ready_raw.endswith(b'\n'), 'owned target readiness record invalid')
            self.ready = json.loads(self.ready_raw)
            self.guard = acquire_guard(self.child, self.argv)
            need(self.ready == {'pid': self.child.pid, 'uid': os.geteuid(), 'nonce': self.nonce, 'identity': self.guard['identity']},
                 'target self-reported PID/start/UID/nonce does not match its direct Popen identity')
            self.setup_end = time.monotonic_ns()
        except BaseException:
            self.cleanup(None, setup_failure=True)
            raise

    def owner(self):
        return {'supervisor_pid': self.child.pid, 'supervisor_uid': self.guard['uid'], 'supervisor_identity': self.guard['identity']}

    def cleanup(self, helper_after, setup_failure=False):
        before, start = usage(), time.monotonic_ns()
        not_reaped = self.child.returncode is None
        scope_ok = not setup_failure and helper_after == before and not_reaped
        cleanup_signal, cleanup_error, stdout, stderr = None, None, self.ready_raw, b''
        code = self.child.returncode
        try:
            if self.child.stdin is not None:
                try: self.child.stdin.close()
                except BrokenPipeError: pass
                self.child.stdin = None
            try:
                code = self.child.wait(timeout=5)
            except subprocess.TimeoutExpired:
                if self.guard is not None:
                    signal_owned(self.child, self.guard, signal.SIGKILL); cleanup_signal = 'SIGKILL'
                # A target whose identity was not established gets EOF only. Its
                # fixed program also has a 45-second self-exit deadline.
                code = self.child.wait(timeout=45 if self.guard is None else 5)
            stdout, stderr = self.ready_raw + self.child.stdout.read(), self.child.stderr.read()
        except BaseException as problem:
            cleanup_error = type(problem).__name__ + ': ' + str(problem)
        finally:
            if self.guard is not None:
                os.close(self.guard['fd'])
            self.child.stdout.close(); self.child.stderr.close()
        end, after = time.monotonic_ns(), usage()
        paths = {s: self.out / 'targets' / (str(self.number).zfill(5) + '.' + s) for s in ('stdout', 'stderr')}
        write_new(paths['stdout'], stdout); write_new(paths['stderr'], stderr)
        result = {'pid': self.child.pid, 'guard': {k: v for k, v in (self.guard or {}).items() if k != 'fd'},
                  'ready': getattr(self, 'ready', None), 'setup_start_monotonic_ns': self.setup_start,
                  'setup_end_monotonic_ns': getattr(self, 'setup_end', None), 'setup_failure': setup_failure,
                  'not_reaped_before_helper_after_rusage': not_reaped and not setup_failure,
                  'rusage_after_helper_matches_before_reap': scope_ok, 'cleanup_error': cleanup_error,
                  'cleanup_start_monotonic_ns': start, 'cleanup_end_monotonic_ns': end, 'returncode': code,
                  'reaped': self.child.returncode is not None, 'cleanup_signal': cleanup_signal,
                  'rusage_before_reap': before, 'rusage_after_reap': after, 'target_cpu_seconds_excluded_from_helper': cpu_delta(before, after),
                  'stdout': artifact(paths['stdout']), 'stderr': artifact(paths['stderr'])}
        write_new(self.out / 'targets' / (str(self.number).zfill(5) + '.json'), encode(result))
        return result


def parse_streams(stdout, stderr):
    metadata, lines = None, []
    for line in stderr.decode('utf-8', errors='replace').splitlines():
        if line.startswith(MARKER):
            need(metadata is None, 'duplicate diagnostic metadata')
            metadata = json.loads(line[len(MARKER):])
        else:
            lines.append(line)
    try: response = json.loads(stdout)
    except (ValueError, UnicodeError): response = None
    return {'response': response, 'metadata': metadata, 'application_stderr_lines': lines, 'exception_tail': lines[-1] if lines else None}


def run_fresh_helper(python, source, query, out, number):
    before, start, real_start = usage(), time.monotonic_ns(), time.time_ns()
    child = subprocess.Popen([python, '-B', '-c', source], stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE, cwd=out)
    spawned, guard, timed_out, error, query_sent = time.monotonic_ns(), None, False, None, False
    actual_input = json.dumps(query, sort_keys=True).encode()
    stdout, stderr = b'', b''
    try:
        guard = acquire_guard(child, [python, '-B', '-c', source])
        try:
            query_sent = True
            stdout, stderr = child.communicate(actual_input, timeout=15)
        except subprocess.TimeoutExpired:
            timed_out = True
            signal_owned(child, guard, signal.SIGKILL)
            stdout, stderr = child.communicate(timeout=5)
    except BaseException as problem:
        error = type(problem).__name__ + ': ' + str(problem)
        if child.returncode is None:
            # No query is sent after an ownership failure. EOF exits the fixed
            # JSON reader; a held, identity-matched pidfd is the only kill path.
            if child.stdin is not None:
                try: child.stdin.close()
                except BrokenPipeError: pass
                child.stdin = None
            try: stdout, stderr = child.communicate(timeout=5)
            except BaseException as cleanup_problem:
                try:
                    signal_owned(child, guard, signal.SIGKILL)
                    stdout, stderr = child.communicate(timeout=5)
                except BaseException as final_problem:
                    error += '; cleanup: ' + type(cleanup_problem).__name__ + ': ' + str(cleanup_problem)
                    error += '; final cleanup: ' + type(final_problem).__name__ + ': ' + str(final_problem)
    finally:
        end, real_end, after = time.monotonic_ns(), time.time_ns(), usage()
        if guard is not None: os.close(guard['fd'])
    paths = {s: out / 'processes' / (str(number).zfill(5) + '.' + s) for s in ('stdout', 'stderr')}
    write_new(paths['stdout'], stdout); write_new(paths['stderr'], stderr)
    result = {'pid': child.pid, 'returncode': child.returncode, 'timed_out': timed_out, 'reaped': child.returncode is not None,
              'fresh_interpreter': True, 'automatic_retry': False, 'ownership_error': error,
              'query_sent_after_helper_identity_confirmed': query_sent,
              'helper_guard': {k: v for k, v in (guard or {}).items() if k != 'fd'},
              'clock': {'start_monotonic_ns': start, 'spawned_monotonic_ns': spawned, 'end_monotonic_ns': end,
                        'start_realtime_ns': real_start, 'end_realtime_ns': real_end},
              'rusage_children_before': before, 'rusage_children_after': after,
              'child_cpu_seconds': cpu_delta(before, after), 'wall_seconds': (end - start) / 1e9,
              'stdout': artifact(paths['stdout']), 'stderr': artifact(paths['stderr']), **parse_streams(stdout, stderr)}
    return result


def expected(case, row, diagnostic):
    fault, scene = case['fault'], case['scene']
    response, metadata = row['response'], row['metadata']
    error_text = {'missing_owner': 'frozen supervisor binding unavailable; no cancellation submitted',
                  'invalid_owner': 'frozen supervisor binding unavailable; no cancellation submitted',
                  'identity_mismatch': 'frozen supervisor identity or UID changed; no cancellation submitted',
                  'uid_mismatch': 'frozen supervisor identity or UID changed; no cancellation submitted',
                  'nonlinux_ps_failure': 'frozen supervisor identity or UID changed; no cancellation submitted',
                  'nonlinux_revalidate_identity': 'supervisor changed before best-effort signal',
                  'nonlinux_revalidate_uid': 'supervisor changed before best-effort signal',
                  'pidfd_unavailable': 'atomic supervisor signalling unavailable; no cancellation submitted',
                  'binding_mismatch': 'remote job request binding missing or mismatched',
                  'pidfd_open_failure': 'PermissionError: [Errno 1] R20 deliberate pidfd-open failure',
                  'pidfd_signal_failure': 'PermissionError: [Errno 1] R20 deliberate pidfd-signal failure'}
    success = fault is None or fault == 'nonlinux_success'
    if success:
        need(row['returncode'] == 0 and response is not None and not row['application_stderr_lines'], 'successful helper exit/output differs')
        if scene == 'cancel_already_exited':
            need(response == {'job_id': case['name'], 'result': 'already_exited'}, 'already-exited result differs')
        elif scene == 'read_control':
            need(response['job_id'] == case['name'] and response['stdout']['bytes_hex'] == READ_BYTES.hex()
                 and response['stdout']['eof'] is True and response['stderr']['bytes_hex'] == '', 'read control output differs')
        else:
            need(response == {'job_id': case['name'], 'result': 'term_sent', 'atomic_identity': not case['nonlinux'],
                 'supervisor_pid': case['owner']['supervisor_pid'], 'termination_confirmed': False, 'reconcile_via': 'process_status'}, 'cancel result binding differs')
    else:
        need(row['returncode'] != 0 and response is None, 'negative case did not fail closed')
        if fault == 'publication_failure':
            need(row['exception_tail'].startswith('FileExistsError:') and "'cancel-request.json.tmp'" in row['exception_tail'], 'publication failure error differs')
        else:
            need(row['exception_tail'] == error_text[fault], 'expected failure tail differs: ' + str(row['exception_tail']))
    published = (scene == 'cancel_linux_owned_pidfd' and fault in
                 (None, 'nonlinux_success', 'pidfd_signal_failure', 'nonlinux_revalidate_identity', 'nonlinux_revalidate_uid'))
    need((row['fixture']['published'] is not None) == published, 'publication/signal ordering differs')
    if diagnostic:
        need(metadata is not None and metadata['still_open'] == [] and metadata['opened'] == metadata['closed'], 'pidfd open/close ownership differs')
        should_open = (scene == 'cancel_linux_owned_pidfd' and not case['nonlinux'] and fault not in
                       ('missing_owner', 'invalid_owner', 'pidfd_unavailable', 'pidfd_open_failure', 'binding_mismatch'))
        need(len(metadata['opened']) == int(should_open), 'pidfd open count differs')
        sends = [e for e in metadata['events'] if e['kind'] == 'pidfd_send_signal']
        kills = [e for e in metadata['events'] if e['kind'] == 'os_kill']
        need(len(sends) == int(scene == 'cancel_linux_owned_pidfd' and fault in (None, 'pidfd_signal_failure') and not case['nonlinux']), 'pidfd send ordering differs')
        need(len(kills) == int(fault == 'nonlinux_success'), 'nonlinux signal ordering differs')
        if sends: need(sends[0]['returned'] == (fault != 'pidfd_signal_failure'), 'pidfd send outcome differs')
        ps_counts = {'nonlinux_success': {'lstart=': 2, 'uid=': 2}, 'nonlinux_ps_failure': {'lstart=': 1, 'uid=': 0},
                     'nonlinux_revalidate_identity': {'lstart=': 2, 'uid=': 1}, 'nonlinux_revalidate_uid': {'lstart=': 2, 'uid=': 2}}
        need(metadata['ps_counts'] == ps_counts.get(fault, {'lstart=': 0, 'uid=': 0}), 'nonlinux revalidation call counts differ')
    else:
        need(metadata is None, 'benchmark contains diagnostic output')
    if row.get('target') is not None:
        need(row['target']['not_reaped_before_helper_after_rusage'] is True and row['target']['reaped'] is True
             and row['target']['rusage_after_helper_matches_before_reap'] is True and row['target']['cleanup_error'] is None
             and row['target']['cleanup_signal'] is None and row['target']['returncode'] == -signal.SIGTERM,
             'native owned target termination or CPU scope differs')
    return True


def canonical_result(row):
    response = row['response']
    if response is not None and row.get('target') is not None and 'supervisor_pid' in response:
        response = dict(response, supervisor_pid='<verified-owned-child>')
    return row['returncode'], response, row['exception_tail']


def inprocess_mock(source, query):
    """Local smoke only; all signal/identity operations are mocks, then restored."""
    sentinel = object()
    attributes = [(os, 'close'), (os, 'kill'), (os, 'pidfd_open'), (signal, 'pidfd_send_signal'),
                  (Path, 'read_text'), (Path, 'stat'), (subprocess, 'check_output'), (builtins, '__import__')]
    saved = [(obj, name, getattr(obj, name, sentinel)) for obj, name in attributes]
    old_stdin, old_platform = sys.stdin, sys.platform
    cwd = os.open('.', os.O_RDONLY | os.O_DIRECTORY | os.O_CLOEXEC)
    stdout, stderr, namespace = io.StringIO(), io.StringIO(), {'__name__': '__main__'}
    returncode = 0
    try:
        sys.stdin = io.StringIO(json.dumps(query, sort_keys=True))
        with contextlib.redirect_stdout(stdout), contextlib.redirect_stderr(stderr):
            try:
                exec(compile(source, '<R20-local-branch-mock>', 'exec'), namespace)
            except SystemExit as error:
                returncode = error.code if isinstance(error.code, int) else (0 if error.code is None else 1)
                if error.code is not None and not isinstance(error.code, int): print(error.code, file=sys.stderr)
            except BaseException:
                returncode = 1; traceback.print_exc()
            if '_r20_emit' in namespace: namespace['_r20_emit']()
    finally:
        for obj, name, value in saved:
            if value is sentinel:
                if hasattr(obj, name): delattr(obj, name)
            else: setattr(obj, name, value)
        sys.stdin, sys.platform = old_stdin, old_platform
        os.fchdir(cwd); os.close(cwd)
        # Production helpers rely on process exit for directory pins. The smoke
        # is explicitly in-process, so release only the descriptors it created.
        for fd in set(namespace.get('_hepta_directory_pins', []) + namespace.get('_r20_opened', [])):
            try: os.close(fd)
            except OSError: pass
    return returncode, stdout.getvalue().encode(), stderr.getvalue().encode()


def validate_plan(plan):
    need(plan['schema'] == 'hepta-r20-cancel-mechanism-plan/v1' and plan['baseline_jobs_sha256'] == A_SHA
         and plan['candidate_jobs_sha256'] == B_SHA and plan['scenes'] == list(SCENES)
         and plan['order'] == 'ABBA' and plan['calls_per_cell'] == 16
         and plan['adjacent_pairs'] == [{'A_round': 0, 'B_round': 1}, {'A_round': 3, 'B_round': 2}]
         and plan['semantic_cases'] == [s[0] for s in SPECS] and plan['maximum_full_run_helper_processes'] == 228
         and plan['maximum_full_run_owned_targets'] == 66 and plan['grace_seconds'] == 0
         and plan['automatic_retries'] == 0 and plan['local_branch_smoke']['cases'] == list(SMOKE), 'fixed plan differs')
    need(plan['screen'] == {'each_native_cancel_aggregate_B_over_A_cpu_max': 0.95,
         'each_native_cancel_each_adjacent_pair_B_over_A_cpu_max': 1.0,
         'byte_identical_read_control_aggregate_B_over_A_cpu_max': 1.1,
         'all_semantics_and_measurement_correctness_required': True, 'all_owned_child_scope_checks_required': True,
         'complete_fixed_matrix_required': True}, 'fixed screen differs')


def summarize(rows):
    cells, summaries = [], {}
    for scene in SCENES:
        group = []
        for rnd, variant in enumerate('ABBA'):
            selected = [r for r in rows if r['phase'] == 'benchmark' and r['scene'] == scene and r['round'] == rnd]
            need(len(selected) == 16 and all(r['variant'] == variant and r['correct'] for r in selected), 'benchmark cell incomplete')
            cell = {'scene': scene, 'round': rnd, 'variant': variant, 'calls': 16, 'sequences': [r['sequence'] for r in selected],
                    'helper_cpu_seconds': math.fsum(r['child_cpu_seconds'] for r in selected),
                    'helper_wall_seconds': math.fsum(r['wall_seconds'] for r in selected),
                    'helper_cpu_ms_per_call': 1000 * statistics.mean(r['child_cpu_seconds'] for r in selected),
                    'helper_wall_ms_per_call': 1000 * statistics.mean(r['wall_seconds'] for r in selected)}
            cells.append(cell); group.append(cell)
        arms = {}
        for variant in 'AB':
            selected = [c for c in group if c['variant'] == variant]
            arm = {'calls': 32, 'helper_cpu_seconds': math.fsum(c['helper_cpu_seconds'] for c in selected),
                   'helper_wall_seconds': math.fsum(c['helper_wall_seconds'] for c in selected)}
            arm.update(helper_cpu_ms_per_call=1000 * arm['helper_cpu_seconds'] / 32,
                       helper_wall_ms_per_call=1000 * arm['helper_wall_seconds'] / 32)
            arms[variant] = arm
        summaries[scene] = {'arms': arms,
            'aggregate_B_over_A_cpu': arms['B']['helper_cpu_seconds'] / arms['A']['helper_cpu_seconds'],
            'aggregate_B_over_A_wall': arms['B']['helper_wall_seconds'] / arms['A']['helper_wall_seconds'],
            'pair_B_over_A_cpu': [group[b]['helper_cpu_ms_per_call'] / group[a]['helper_cpu_ms_per_call'] for a, b in [(0, 1), (3, 2)]],
            'pair_B_over_A_wall': [group[b]['helper_wall_ms_per_call'] / group[a]['helper_wall_ms_per_call'] for a, b in [(0, 1), (3, 2)]]}
    return cells, summaries


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ('baseline', 'candidate', 'plan', 'out'):
        parser.add_argument('--' + name, type=Path, required=True)
    parser.add_argument('--expected-tool-sha256', required=True)
    parser.add_argument('--expected-plan-sha256', required=True)
    parser.add_argument('--python', default='/usr/bin/python3')
    parser.add_argument('--mode', choices=('full', 'branch-smoke'), required=True)
    args = parser.parse_args()
    tool_raw = Path(__file__).read_bytes(); plan_raw = args.plan.read_bytes()
    need(sha(tool_raw) == args.expected_tool_sha256 and sha(plan_raw) == args.expected_plan_sha256, 'tool/plan identity differs')
    plan = json.loads(plan_raw); validate_plan(plan)
    sources = {'A': extracted(args.baseline, A_SHA), 'B': extracted(args.candidate, B_SHA)}
    need(all(sources['A'][1][name] == sources['B'][1][name] for name in CONSTANTS if name != 'CANCEL_CODE'), 'non-CANCEL source changed')
    need(ast.dump(WithoutImports().visit(ast.parse(sources['A'][1]['CANCEL_CODE']))) ==
         ast.dump(WithoutImports().visit(ast.parse(sources['B'][1]['CANCEL_CODE']))), 'non-import CANCEL AST changed')
    if args.mode == 'full':
        need(sys.platform == 'linux' and hasattr(os, 'pidfd_open') and hasattr(signal, 'pidfd_send_signal'), 'full probe requires native Linux pidfd')
        need(signal.getsignal(signal.SIGCHLD) == signal.SIG_DFL, 'full probe requires normal direct-child wait accounting')
    out = args.out.absolute()
    need(out.resolve() == out and not os.path.lexists(out), 'output must be fresh and direct')
    os.umask(0o077); out.mkdir(mode=0o700, parents=True)
    for folder in ('scripts', 'processes', 'targets'): (out / folder).mkdir(mode=0o700)
    write_new(out / 'plan.frozen.json', plan_raw)
    common = {'baseline_source_sha256': A_SHA, 'candidate_source_sha256': B_SHA,
              'probe_tool_sha256': args.expected_tool_sha256, 'plan_sha256': args.expected_plan_sha256,
              'mode': args.mode, 'python': args.python, 'driver_python_version': sys.version, 'driver_uname': list(os.uname()),
              'source_stable': False, 'remote_calls': 0, 'automatic_retries': 0, 'existing_services_changed': False}
    semantics = {'schema': 'hepta-r20-cancel-mechanism-semantics/v1', **common, 'passed': False,
                 'complete_required_coverage': False, 'cases': [], 'environment_boundary': None}
    benchmark = {'schema': 'hepta-r20-cancel-mechanism-abba/v1', **common, 'completed': False, 'benchmark_performed': False,
                 'order': 'ABBA', 'calls_per_cell': 16, 'cells': [], 'summaries': {}, 'timing_scope': plan['timing_scope']}
    screen = {'schema': 'hepta-r20-cancel-mechanism-screen/v1', **common, 'assessed': False, 'passed': False,
              'adoption_assessed': False, 'checks': {}, 'limits': plan['screen']}
    raw_path = out / 'raw-processes.jsonl'; raw_file = raw_path.open('xb')
    rows, target_records = [], []
    run_error = None

    def progress(stage, **extra):
        value = {'current_stage': stage, 'helper_records': len(rows), 'owned_target_records': len(target_records),
                 'updated_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), **extra}
        temporary = out / 'progress.tmp.json'
        with temporary.open('wb') as stream: stream.write(encode(value))
        os.replace(temporary, out / 'progress.json')
        print(json.dumps(value, sort_keys=True), flush=True)

    def invoke(spec, variant, phase, rnd=None, call=None, blocked=False):
        number = len(rows); target, target_result, row, case = None, None, None, None
        inprocess = args.mode == 'branch-smoke'
        try:
            if spec[1] == 'cancel_linux_owned_pidfd' and spec[2] == 'native':
                target = Target(args.python, out, number)
            case = fixture(out, spec, variant, phase, number, target.owner() if target else None)
            source = script(sources[variant][1], case, phase, inprocess=inprocess, blocked=blocked)
            key = spec[0] + '-' + variant + ('-blocked' if blocked else '') + '-' + phase + '.py'
            script_file = out / 'scripts' / key
            if script_file.exists(): need(script_file.read_bytes() == source.encode(), 'script bytes changed')
            else: write_new(script_file, source.encode())
            if inprocess:
                code, stdout, stderr = inprocess_mock(source, case['query'])
                paths = {s: out / 'processes' / (str(number).zfill(5) + '.' + s) for s in ('stdout', 'stderr')}
                write_new(paths['stdout'], stdout); write_new(paths['stderr'], stderr)
                row = {'returncode': code, 'fresh_interpreter': False, 'reaped': None, 'timed_out': False,
                       'automatic_retry': False, 'real_pidfd_or_signal_executed': False,
                       'native_identity_validation_performed': False, 'production_identity_function_modified': False,
                       'stdout': artifact(paths['stdout']), 'stderr': artifact(paths['stderr']), **parse_streams(stdout, stderr)}
            else:
                row = run_fresh_helper(args.python, source, case['query'], out, number)
        finally:
            if target is not None:
                target_result = target.cleanup(row['rusage_children_after'] if row else usage())
                target_records.append(target_result)
        need(row is not None and case is not None, 'helper did not produce a record')
        row.update(sequence=number, phase=phase, case=spec[0], scene=spec[1], variant=variant, round=rnd, call=call,
                   branch_mock=spec[2] == 'mock', script=artifact(script_file),
                   argv_shape=[args.python, '-B', '-c', {'script_file': str(script_file), 'sha256': sha(source.encode())}] if not inprocess else None,
                   input_json=case['query'], input_sha256=sha(json.dumps(case['query'], sort_keys=True).encode()),
                   fixture=observe_fixture(case), target=target_result, rusage_after_cleanup=usage() if not inprocess else None,
                   correct=False)
        try:
            if not inprocess:
                need(row['reaped'] is True and row['timed_out'] is False and row['ownership_error'] is None
                     and row['child_cpu_seconds'] >= 0, 'helper lifecycle/CPU/ownership failure')
            if phase != 'environment-boundary':
                row['correct'] = expected(case, row, diagnostic=phase != 'benchmark')
            else:
                row['correct'] = (row['returncode'] != 0 and row['exception_tail'] == 'ImportError: R20 deliberate unavailable subprocess') if variant == 'A' else expected(case, row, True)
            if phase == 'benchmark':
                need(source == production(sources[variant][1], spec[1]) and MARKER not in source, 'benchmark diagnostic contamination')
                row['native_exact_production_script'] = True
        except BaseException as problem:
            row['validation_error'] = type(problem).__name__ + ': ' + str(problem)
        rows.append(row); raw_file.write(encode(row).replace(b'\n', b'') + b'\n'); raw_file.flush()
        need(row['correct'] is True and 'validation_error' not in row, 'helper case failed: ' + spec[0] + ': ' + str(row.get('validation_error')))
        return row

    old_term = signal.getsignal(signal.SIGTERM)
    def interrupted(signum, frame):
        raise InterruptedError('owned probe received signal ' + str(signum))
    signal.signal(signal.SIGTERM, interrupted)
    try:
        selected_specs = SPECS if args.mode == 'full' else [s for s in SPECS if s[0] in SMOKE]
        for spec in selected_specs:
            progress('semantics', case=spec[0])
            a = invoke(spec, 'A', 'semantics' if args.mode == 'full' else 'branch-smoke')
            b = invoke(spec, 'B', 'semantics' if args.mode == 'full' else 'branch-smoke')
            need(canonical_result(a) == canonical_result(b), 'A/B semantic result differs: ' + spec[0])
            if args.mode == 'full' and spec[2] == 'native':
                expected_imports = (False, False) if spec[1] == 'read_control' else (True, False)
                need((a['metadata']['subprocess_loaded'], b['metadata']['subprocess_loaded']) == expected_imports
                     and a['metadata']['initial_subprocess_loaded'] is b['metadata']['initial_subprocess_loaded'] is False,
                     'native subprocess import mechanism differs')
            semantics['cases'].append({'name': spec[0], 'scene': spec[1], 'mode': spec[2], 'passed': True,
                                       'baseline_sequence': a['sequence'], 'candidate_sequence': b['sequence'],
                                       'normalization': 'Only the individually verified owned target PID differs between native success runs.'})
        if args.mode == 'full':
            progress('environment-boundary')
            a = invoke(SPECS[0], 'A', 'environment-boundary', blocked=True)
            b = invoke(SPECS[0], 'B', 'environment-boundary', blocked=True)
            semantics['environment_boundary'] = {'documented': True, 'intentionally_different': True,
                'baseline_sequence': a['sequence'], 'candidate_sequence': b['sequence'],
                'meaning': plan['interpretation']['environment_boundary']}
            semantics['complete_required_coverage'] = True
            for scene in SCENES:
                for rnd, variant in enumerate('ABBA'):
                    progress('benchmark', scene=scene, round=rnd, variant=variant)
                    for call in range(16): invoke((scene, scene, 'native', None), variant, 'benchmark', rnd, call)
            need(len(rows) == 228 and len(target_records) == 66, 'fixed full-run denominators differ')
            benchmark['cells'], benchmark['summaries'] = summarize(rows)
            benchmark['benchmark_performed'] = benchmark['completed'] = True
            for scene in SCENES[:2]:
                values = benchmark['summaries'][scene]
                screen['checks'][scene + '_aggregate_cpu_at_most_0_95'] = values['aggregate_B_over_A_cpu'] <= 0.95
                for pair, ratio in enumerate(values['pair_B_over_A_cpu']):
                    screen['checks'][scene + '_pair_' + str(pair + 1) + '_cpu_at_most_1_00'] = ratio <= 1.0
            screen['checks']['unchanged_read_aggregate_cpu_at_most_1_10'] = benchmark['summaries']['read_control']['aggregate_B_over_A_cpu'] <= 1.1
            screen['checks']['all_semantics_and_measurement_correctness'] = all(r['correct'] for r in rows)
            screen['checks']['all_owned_targets_unreaped_until_after_helper_sample'] = all(
                r['not_reaped_before_helper_after_rusage'] and r['rusage_after_helper_matches_before_reap']
                and r['reaped'] and r['cleanup_signal'] is None and r['cleanup_error'] is None for r in target_records)
            screen['checks']['complete_fixed_matrix'] = len(rows) == 228 and len(target_records) == 66
            screen['assessed'] = True
        need(args.baseline.read_bytes() == sources['A'][0] and args.candidate.read_bytes() == sources['B'][0]
             and Path(__file__).read_bytes() == tool_raw and args.plan.read_bytes() == plan_raw, 'source/tool/plan changed')
        semantics['passed'] = True
        for doc in (semantics, benchmark, screen): doc['source_stable'] = True
        if args.mode == 'full': screen['passed'] = all(v is True for v in screen['checks'].values())
        progress('completed', screen_assessed=screen['assessed'], screen_passed=screen['passed'])
    except BaseException as problem:
        run_error = {'type': type(problem).__name__, 'message': str(problem)}
        write_new(out / 'error.txt', traceback.format_exc().encode())
        progress('failed', error=run_error)
    finally:
        signal.signal(signal.SIGTERM, old_term)
        raw_file.close()
        target_metadata_files = sorted((out / 'targets').glob('*.json'))
        for doc, name in ((semantics, 'semantics.json'), (benchmark, 'abba.json'), (screen, 'screen.json')):
            doc.update(raw_processes=artifact(raw_path), actual_helper_records=len(rows), actual_owned_target_records=len(target_records),
                       actual_fresh_helper_processes=len(rows) if args.mode == 'full' else 0,
                       real_targets_created=len(target_metadata_files) if args.mode == 'full' else 0,
                       target_metadata_files=[artifact(p) for p in target_metadata_files],
                       error=run_error, finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
            write_new(out / name, encode(doc))
        print(json.dumps({'mode': args.mode, 'semantics_passed': semantics['passed'], 'benchmark_completed': benchmark['completed'],
                          'screen_assessed': screen['assessed'], 'screen_passed': screen['passed'],
                          'semantics': artifact(out / 'semantics.json'), 'abba': artifact(out / 'abba.json'),
                          'screen': artifact(out / 'screen.json'), 'error': run_error}, sort_keys=True), flush=True)
    if run_error is not None: return 1
    return 0 if args.mode == 'branch-smoke' or screen['passed'] else 2


if __name__ == '__main__':
    sys.exit(main())

