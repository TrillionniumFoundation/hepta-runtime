_r20_cfg = {'mode': 'native', 'fault': None, 'pid': 424242, 'uid': 1000, 'ticks': 1234567, 'boot': '00000000-0000-4000-8000-000000000020', 'ps_start': 'Wed Nov  4 12:34:56 2026', 'nonlinux': False, 'inprocess': False}

import atexit, json, os, pathlib, signal, sys
_r20_initial_subprocess = "subprocess" in sys.modules
_r20_events, _r20_opened, _r20_closed = [], [], []
_r20_original_close, _r20_original_fstat = os.close, os.fstat
_r20_original_open = getattr(os, "pidfd_open", None)
_r20_original_send = getattr(signal, "pidfd_send_signal", None)
_r20_original_read_text, _r20_original_stat = pathlib.Path.read_text, pathlib.Path.stat
_r20_ps_counts = {"lstart=": 0, "uid=": 0}
def _r20_open(pid, flags=0):
    assert pid == _r20_cfg["pid"] and flags == 0
    if _r20_cfg["fault"] == "pidfd_open_failure":
        _r20_events.append({"kind": "pidfd_open_failed", "pid": pid})
        raise PermissionError(1, "R20 deliberate pidfd-open failure")
    fd = _r20_original_open(pid, flags) if _r20_cfg["mode"] == "native" else os.open(os.devnull, os.O_RDONLY | os.O_CLOEXEC)
    _r20_opened.append(fd); _r20_events.append({"kind": "pidfd_open", "pid": pid, "fd": fd})
    return fd
def _r20_send(fd, signum, siginfo=None, flags=0):
    assert fd in _r20_opened and fd not in _r20_closed and signum == signal.SIGTERM and siginfo is None and flags == 0
    event = {"kind": "pidfd_send_signal", "fd": fd, "signal": signum, "returned": False, "mock": _r20_cfg["mode"] == "mock"}
    _r20_events.append(event)
    if _r20_cfg["fault"] == "pidfd_signal_failure": raise PermissionError(1, "R20 deliberate pidfd-signal failure")
    if _r20_cfg["mode"] == "native": _r20_original_send(fd, signum, siginfo, flags)
    event["returned"] = True
def _r20_close(fd):
    if fd in _r20_opened:
        _r20_closed.append(fd); _r20_events.append({"kind": "pidfd_close", "fd": fd})
    return _r20_original_close(fd)
def _r20_kill(pid, signum):
    assert _r20_cfg["mode"] == "mock" and pid == _r20_cfg["pid"] and signum == signal.SIGTERM
    _r20_events.append({"kind": "os_kill", "pid": pid, "signal": signum, "mock": True})
def _r20_read_text(path, *args, **kwargs):
    name = str(path)
    if name == "/proc/" + str(_r20_cfg["pid"]) + "/stat":
        _r20_events.append({"kind": "proc_identity"})
        ticks = _r20_cfg["ticks"] + (1 if _r20_cfg["fault"] == "identity_mismatch" else 0)
        return str(_r20_cfg["pid"]) + " (r20-cancel-mock) " + " ".join(["S"] + ["0"] * 18 + [str(ticks)])
    if name == "/proc/sys/kernel/random/boot_id": return _r20_cfg["boot"] + "\n"
    return _r20_original_read_text(path, *args, **kwargs)
def _r20_stat(path, *args, **kwargs):
    if str(path) == "/proc/" + str(_r20_cfg["pid"]):
        _r20_events.append({"kind": "proc_uid"})
        class _Uid: pass
        result = _Uid(); result.st_uid = _r20_cfg["uid"] + (1 if _r20_cfg["fault"] == "uid_mismatch" else 0)
        return result
    return _r20_original_stat(path, *args, **kwargs)
os.close, os.kill = _r20_close, _r20_kill
os.pidfd_open, signal.pidfd_send_signal = _r20_open, _r20_send
if _r20_cfg["mode"] == "mock":
    pathlib.Path.read_text, pathlib.Path.stat = _r20_read_text, _r20_stat
if _r20_cfg["fault"] == "pidfd_unavailable": del os.pidfd_open
if _r20_cfg["nonlinux"]:
    import subprocess as _r20_subprocess
    def _r20_check_output(argv, **kwargs):
        assert argv[:4] == ["ps", "-p", str(_r20_cfg["pid"]), "-o"] and argv[4] in _r20_ps_counts
        assert kwargs == {"text": True, "timeout": 3}
        key = argv[4]; _r20_ps_counts[key] += 1
        _r20_events.append({"kind": "ps", "argv": argv, "call": _r20_ps_counts[key]})
        if key == "lstart=":
            if _r20_cfg["fault"] == "nonlinux_ps_failure": raise _r20_subprocess.CalledProcessError(1, argv)
            if _r20_cfg["fault"] == "nonlinux_revalidate_identity" and _r20_ps_counts[key] == 2: return "changed identity\n"
            return _r20_cfg["ps_start"] + "\n"
        value = _r20_cfg["uid"] + (1 if _r20_cfg["fault"] == "nonlinux_revalidate_uid" and _r20_ps_counts[key] == 2 else 0)
        return str(value) + "\n"
    _r20_subprocess.check_output = _r20_check_output
    sys.platform = "darwin"
def _r20_emit():
    open_fds = []
    for fd in _r20_opened:
        try: _r20_original_fstat(fd)
        except OSError: pass
        else: open_fds.append(fd)
    print("R20_CANCEL_METADATA " + json.dumps({"mode": _r20_cfg["mode"], "events": _r20_events,
        "opened": _r20_opened, "closed": _r20_closed, "still_open": open_fds, "ps_counts": _r20_ps_counts,
        "subprocess_loaded": "subprocess" in sys.modules, "initial_subprocess_loaded": _r20_initial_subprocess}, sort_keys=True), file=sys.stderr)
if not _r20_cfg["inprocess"]: atexit.register(_r20_emit)

import builtins as _r20_builtins
_r20_original_import = _r20_builtins.__import__
def _r20_block(name, *args, **kwargs):
    if name == "subprocess": raise ImportError("R20 deliberate unavailable subprocess")
    return _r20_original_import(name, *args, **kwargs)
_r20_builtins.__import__ = _r20_block
REMOTE_DIRECTORY_SOURCE = "\nimport os, pathlib, stat, sys\n_hepta_directory_pins = []\ndef private_job_directory(raw, create=False):\n    if not isinstance(raw, str) or not raw.startswith(\"/\") or any(p in (\".\", \"..\") for p in raw.split(\"/\")):\n        raise SystemExit(\"unsafe remote job path\")\n    parts = [p for p in raw.split(\"/\") if p]\n    if len(parts) < 3 or parts[-2] != \"jobs\":\n        raise SystemExit(\"remote job path must name a dedicated state/jobs/job directory\")\n    shared_access = getattr(os, \"O_PATH\", os.O_RDONLY) if sys.platform == \"linux\" else os.O_RDONLY\n    path_only_shared = shared_access != os.O_RDONLY\n    directory_flags = os.O_DIRECTORY | os.O_NOFOLLOW | os.O_CLOEXEC\n    fd = os.open(\"/\", shared_access | directory_flags)\n    _hepta_directory_pins.append(fd)\n    for offset, part in enumerate(parts):\n        private = offset >= len(parts) - 3\n        if create and private and not path_only_shared:\n            try:\n                os.mkdir(part, mode=0o700, dir_fd=fd)\n                os.fsync(fd)\n            except FileExistsError:\n                pass\n        access = os.O_RDONLY if private else shared_access\n        try:\n            child = os.open(part, access | directory_flags, dir_fd=fd)\n        except FileNotFoundError:\n            if not (create and private and path_only_shared):\n                raise\n            # O_PATH traverses an existing searchable ancestor without reading it.\n            # A new child still needs its parent's original durability barrier:\n            # acquire a readable handle before mkdir, or refuse without creating.\n            sync_parent = os.open(\".\", os.O_RDONLY | directory_flags, dir_fd=fd)\n            _hepta_directory_pins.append(sync_parent)\n            pinned = os.fstat(fd)\n            readable = os.fstat(sync_parent)\n            if (pinned.st_dev, pinned.st_ino) != (readable.st_dev, readable.st_ino):\n                raise SystemExit(\"remote parent directory identity changed; no directory created\")\n            try:\n                os.mkdir(part, mode=0o700, dir_fd=sync_parent)\n            except FileExistsError:\n                pass\n            else:\n                os.fsync(sync_parent)\n            child = os.open(part, os.O_RDONLY | directory_flags, dir_fd=sync_parent)\n        _hepta_directory_pins.append(child)\n        info = os.fstat(child)\n        if private and (info.st_uid != os.geteuid() or stat.S_IMODE(info.st_mode) != 0o700):\n            raise SystemExit(\"unsafe remote state/jobs/job directory; existing permissions are never repaired\")\n        fd = child\n    os.fchdir(fd)\n    return pathlib.Path(\".\")\n\ndef private_bound_job_directory(raw, expected):\n    job = private_job_directory(raw)\n    info = os.fstat(_hepta_directory_pins[-1])\n    if (info.st_dev, info.st_ino) != (expected[\"device\"], expected[\"inode\"]):\n        raise SystemExit(\"remote job directory identity changed; no workload submitted\")\n    return job\n\ndef private_open_job_file(name):\n    try:\n        fd = os.open(name, os.O_RDONLY | os.O_NOFOLLOW | os.O_CLOEXEC | os.O_NONBLOCK,\n                     dir_fd=_hepta_directory_pins[-1])\n    except FileNotFoundError:\n        return None\n    except OSError as error:\n        raise SystemExit(\"unsafe remote job file \" + name) from error\n    info = os.fstat(fd)\n    if (not stat.S_ISREG(info.st_mode) or info.st_nlink != 1 or\n            info.st_uid != os.geteuid() or stat.S_IMODE(info.st_mode) & 0o022):\n        os.close(fd)\n        raise SystemExit(\"unsafe remote job file \" + name + \": non-regular or linked inode\")\n    return fd\n\ndef private_read_json(name):\n    import json\n    fd = private_open_job_file(name)\n    if fd is None: return None\n    with os.fdopen(fd, \"rb\") as stream:\n        before = os.fstat(stream.fileno())\n        if before.st_size > 4 * 1024 * 1024:\n            raise SystemExit(\"unsafe remote job file \" + name + \": linked or oversized inode\")\n        # Size the common allocation to the fresh snapshot, not the 4 MiB cap.\n        # A regular file may underreport its size; retain the original bounded\n        # read in that case before the unchanged metadata and JSON checks.\n        encoded = stream.read(max(0, before.st_size) + 1)\n        if encoded is not None and len(encoded) > before.st_size:\n            tail = stream.read(4 * 1024 * 1024 + 1 - len(encoded))\n            # BufferedReader preserves an available prefix when a later raw\n            # read would block. Keep that behavior without retrying the read.\n            if tail is not None:\n                encoded += tail\n        after = os.fstat(stream.fileno())\n        current = os.stat(name, dir_fd=_hepta_directory_pins[-1], follow_symlinks=False)\n    def stamp(info):\n        return (info.st_dev, info.st_ino, info.st_mode, info.st_uid, info.st_nlink,\n                info.st_size, info.st_mtime_ns, info.st_ctime_ns)\n    if len(encoded) > 4 * 1024 * 1024 or stamp(before) != stamp(after) or stamp(after) != stamp(current):\n        raise SystemExit(\"unsafe remote job file \" + name + \": changed while reading\")\n    try:\n        value = json.loads(encoded)\n        if not isinstance(value, dict): raise ValueError(\"not an object\")\n        return value\n    except (ValueError, UnicodeError) as error:\n        raise SystemExit(\"corrupt remote job file \" + name) from error\n\n"
exec(REMOTE_DIRECTORY_SOURCE)

import io, json
_original_query = json.load(sys.stdin)
_bound_job = private_job_directory(_original_query["job_dir"])
_bound_request = private_read_json("request.json")
_digest = _original_query.get("request_digest")
if (not isinstance(_bound_request, dict) or not isinstance(_digest, str) or len(_digest) != 64 or
        any(c not in "0123456789abcdef" for c in _digest) or
        _bound_request.get("job_id") != _original_query.get("job_id") or
        _bound_request.get("job_dir") != _original_query.get("job_dir") or
        _bound_request.get("unit") != _original_query.get("unit") or
        _bound_request.get("request_digest", _bound_request.get("request_fingerprint")) != _digest):
    raise SystemExit("remote job request binding missing or mismatched")
# Metadata is validated before a status can claim success or cancellation can
# acknowledge a terminal receipt. The status owner interprets a torn private
# started.json as unknown, and a confirmed terminal receipt takes precedence.
# Cancellation still validates its owner record before sending any signal.
for _name in ("launch.json", "exit.json"):
    private_read_json(_name)
sys.stdin = io.StringIO(json.dumps(_original_query))


import json, os, pathlib, signal, subprocess, sys, time
q = json.load(sys.stdin)
job = private_job_directory(q["job_dir"])

def read_json(name):
    return private_read_json(name)

def atomic(name, value):
    target = job / name
    tmp = job / (name + ".tmp")
    fd = os.open(tmp, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    with os.fdopen(fd, "w", encoding="utf-8") as stream:
        stream.write(json.dumps(value, sort_keys=True) + "\n")
        stream.flush(); os.fsync(stream.fileno())
    os.replace(tmp, target)
    fd = os.open(job, os.O_RDONLY)
    try: os.fsync(fd)
    finally: os.close(fd)

def process_identity(pid):
    if sys.platform == "linux":
        try:
            ticks = int(pathlib.Path(f"/proc/{pid}/stat").read_text().rsplit(") ", 1)[1].split()[19])
            boot = pathlib.Path("/proc/sys/kernel/random/boot_id").read_text().strip()
            return {"kind": "proc_start_ticks", "value": boot + ":" + str(ticks)} if boot else None
        except Exception:
            return None
    try:
        value = subprocess.check_output(["ps", "-p", str(pid), "-o", "lstart="], text=True, timeout=3).strip()
        return {"kind": "ps_lstart", "value": value} if value else None
    except Exception:
        return None

def valid_owner(request, started, systemd=False):
    nonce = request.get("launch_nonce")
    identity = started.get("supervisor_identity")
    return (isinstance(nonce, str) and len(nonce) == 32 and all(c in "0123456789abcdef" for c in nonce) and
        started.get("job_id") == request.get("job_id") and started.get("launch_nonce") == nonce and
        type(started.get("supervisor_uid")) is int and started["supervisor_uid"] == os.geteuid() and
        type(started.get("supervisor_pid")) is int and 1 < started["supervisor_pid"] <= 2147483647 and
        isinstance(identity, dict) and identity.get("kind") == ("proc_start_ticks" if sys.platform == "linux" else "ps_lstart") and
        isinstance(identity.get("value"), str) and bool(identity["value"]) and
        (not systemd or (isinstance(started.get("invocation_id"), str) and len(started["invocation_id"]) == 32 and
            all(c in "0123456789abcdef" for c in started["invocation_id"]))))

def process_uid(pid):
    if sys.platform == "linux": return pathlib.Path(f"/proc/{pid}").stat().st_uid
    return int(subprocess.check_output(["ps", "-p", str(pid), "-o", "uid="], text=True, timeout=3).strip())

request = read_json("request.json")
if not request or request.get("job_id") != q["job_id"]:
    raise SystemExit("remote job metadata missing or mismatched")
if read_json("exit.json"):
    print(json.dumps({"job_id": q["job_id"], "result": "already_exited"}))
    raise SystemExit(0)
launch = read_json("launch.json") or {}
started = read_json("started.json") or {}
nonce = request.get("launch_nonce")
pid = int(started.get("supervisor_pid") or 0)
expected = started.get("supervisor_identity")
expected_uid = started.get("supervisor_uid")
if not valid_owner(request, started, systemd=launch.get("backend") == "systemd"):
    raise SystemExit("frozen supervisor binding unavailable; no cancellation submitted")
# Never stop by a reusable unit name. This descriptor stays bound to the
# original supervisor even if its PID or systemd unit name is later recycled.
atomic_identity = sys.platform == "linux"
fd = None
try:
    if atomic_identity:
        if not hasattr(os, "pidfd_open") or not hasattr(signal, "pidfd_send_signal"):
            raise SystemExit("atomic supervisor signalling unavailable; no cancellation submitted")
        fd = os.pidfd_open(pid, 0)
    if process_identity(pid) != expected or process_uid(pid) != expected_uid:
        raise SystemExit("frozen supervisor identity or UID changed; no cancellation submitted")
    atomic("cancel-request.json", {"at_unix_ms": int(time.time() * 1000),
           "job_id": q["job_id"], "launch_nonce": nonce})
    if atomic_identity:
        signal.pidfd_send_signal(fd, signal.SIGTERM, None, 0)
    else:
        # macOS has no pidfd. Retain its explicitly non-atomic account scope.
        if process_identity(pid) != expected or process_uid(pid) != expected_uid:
            raise SystemExit("supervisor changed before best-effort signal")
        os.kill(pid, signal.SIGTERM)
    grace = max(0.0, min(float(q.get("grace_seconds", 10)), 30.0))
    deadline = time.monotonic() + grace
    while time.monotonic() < deadline:
        if read_json("exit.json") or process_identity(pid) != expected:
            break
        time.sleep(.1)
    # The original runner owns workload termination, escalation and output
    # drain. Never force-kill a potentially recycled child group from here.
    result = "stop_requested" if launch.get("backend") == "systemd" else "term_sent"
    print(json.dumps({"job_id":q["job_id"],"result":result,
          "atomic_identity":atomic_identity,"supervisor_pid":pid,
          "termination_confirmed":False,"reconcile_via":"process_status"}, sort_keys=True))
finally:
    if fd is not None: os.close(fd)
