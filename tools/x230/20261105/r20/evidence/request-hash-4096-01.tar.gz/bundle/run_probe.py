#!/usr/bin/env python3
"""Freeze/build/check one isolated request-hash probe, then run exactly 96 cells.

Run only after the separate full-qualification workload is stopped. No network,
production edits, retries, parallel workers, or task launches are performed.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import signal
import statistics
import subprocess
import sys
import time
import tomllib

SOURCE_SHA = 'c9080de8aa9a35f7495aa2822a1495d297903900ae0f0de26d7b0c86d043d3c9'
CASES = [('small_176', 100000, 256), ('escaped_small', 50000, 256),
         ('plain_64k', 512, 8), ('escaped_64k', 128, 4),
         ('plain_1mib', 32, 2), ('escaped_1mib', 8, 2)]
BLOCKS = 4


def need(ok, message):
    if not ok:
        raise ValueError(message)


def identity(path):
    data = path.read_bytes()
    return {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}


def save(path, data):
    with path.open('x') as stream:
        json.dump(data, stream, sort_keys=True, indent=2)
        stream.write('\n')


def package_identity(row):
    return tuple(row.get(k) for k in ('name', 'version', 'source', 'checksum'))


def interrupted(signum, _frame):
    raise InterruptedError('received ' + signal.Signals(signum).name)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--baseline-jobs', required=True, type=Path)
    parser.add_argument('--cargo-home', required=True, type=Path)
    parser.add_argument('--output', required=True, type=Path)
    parser.add_argument('--expected-manifest-sha256', required=True)
    args = parser.parse_args()
    bundle = Path(__file__).resolve().parent
    out = args.output.absolute()
    need(not out.exists() and not out.is_relative_to(bundle), 'output must be new and outside the probe source')
    manifest_path = bundle / 'bundle-manifest.json'
    need(identity(manifest_path)['sha256'] == args.expected_manifest_sha256, 'bundle manifest mismatch')
    manifest = json.loads(manifest_path.read_bytes())
    for name, expected in manifest['files'].items():
        need(identity(bundle / name) == expected, 'probe source changed: ' + name)
    need(identity(args.baseline_jobs)['sha256'] == SOURCE_SHA, 'accepted R19 jobs source differs')
    source = args.baseline_jobs.read_text()
    start = source.index('// Keep the alphabetical key order of the original serde_json::Value map.')
    end = source.index('// Retain the old prefix only', start)
    need(source[start:end].encode() == (bundle / 'src/baseline.inc.rs').read_bytes(), 'baseline excerpt differs')
    out.mkdir(parents=True, exist_ok=False)
    project = out / 'project'
    project.mkdir()
    for name in ('Cargo.toml', 'rustfmt.toml'):
        shutil.copyfile(bundle / name, project / name)
    shutil.copytree(bundle / 'src', project / 'src')
    shutil.copyfile(bundle / 'Cargo.lock.seed', project / 'Cargo.lock')
    home = str(Path.home())
    env = {'HOME': home, 'PATH': home + '/.cargo/bin:/usr/local/bin:/usr/bin:/bin',
           'LANG': 'C.UTF-8', 'LC_ALL': 'C.UTF-8', 'CARGO_HOME': str(args.cargo_home.absolute()),
           'RUSTUP_HOME': home + '/.rustup', 'RUSTUP_AUTO_INSTALL': '0',
           'CARGO_NET_OFFLINE': 'true', 'CARGO_INCREMENTAL': '0', 'CARGO_BUILD_JOBS': '2',
           'CARGO_TARGET_DIR': str(out / 'target'), 'PYTHONDONTWRITEBYTECODE': '1',
           'MALLOC_ARENA_MAX': '1'}
    stages = []
    report = {'schema': 'hepta-r20-request-hash-report/v1', 'passed': False,
              'automatic_retries': 0, 'stages': stages, 'cells': 0,
              'baseline_jobs': str(args.baseline_jobs), 'baseline_jobs_sha256': SOURCE_SHA,
              'bundle_manifest_sha256': args.expected_manifest_sha256,
              'scope': 'isolated request hash; not status/read or process-start throughput'}

    def run(label, argv, timeout):
        row = {'name': label, 'argv': argv, 'timeout_seconds': timeout, 'automatic_retries': 0}
        stages.append(row)
        began = time.monotonic()
        stdout, stderr = out / (label + '.stdout'), out / (label + '.stderr')
        child = None
        try:
            with stdout.open('xb') as sout, stderr.open('xb') as serr:
                child = subprocess.Popen(argv, cwd=project, env=env, stdin=subprocess.DEVNULL,
                                         stdout=sout, stderr=serr, start_new_session=True)
                row['pid'] = child.pid
                try:
                    row['returncode'] = child.wait(timeout=timeout)
                except BaseException:
                    row['interrupted_or_timed_out'] = True
                    try:
                        os.killpg(child.pid, signal.SIGTERM)
                    except ProcessLookupError:
                        pass
                    try:
                        child.wait(timeout=10)
                    except subprocess.TimeoutExpired:
                        os.killpg(child.pid, signal.SIGKILL)
                        child.wait(timeout=10)
                    row['returncode'] = child.returncode
                    raise
            need(row['returncode'] == 0, 'stage failed: ' + label)
        finally:
            row['wall_seconds'] = time.monotonic() - began
            row['waited_and_reaped'] = child is not None and child.returncode is not None
            for name, path in (('stdout', stdout), ('stderr', stderr)):
                if path.exists():
                    row[name] = {'path': path.name, **identity(path)}
            save(out / (label + '.stage.json'), row)
        return stdout

    try:
        protocol = {'schema': 'hepta-r20-request-hash-protocol/v1', 'blocks': BLOCKS,
                    'order': ['A', 'B', 'B', 'A'], 'cases': CASES, 'cells': 96,
                    'candidate': 'one fixed 4096-byte stack buffer, same sha2 and serde_json',
                    'environment': env, 'source_files': manifest['files'],
                    'small_regression_screen_percent': 2.0,
                    'plain_large_regression_screen_percent': 2.0,
                    'escaped_large_improvement_screen_percent': 5.0,
                    'escaped_large_all_four_blocks_must_improve': True,
                    'screen_is_not_production_adoption': True,
                    'memory_scope': 'Linux fresh-worker RSS snapshots and lifetime HWM; not per-call allocation'}
        save(out / 'protocol.json', protocol)
        cargo = ['cargo', '+1.95.0']
        run('01-cargo-version', cargo + ['--version'], 30)
        run('02-rustc-version', ['rustc', '+1.95.0', '--version'], 30)
        # Cargo may prune unused entries from the full R19 seed. Resolve offline,
        # require every external package identity to occur in the R19 lock, then
        # freeze the actual minimal lock before --locked compilation.
        run('03-metadata', cargo + ['metadata', '--offline', '--format-version', '1'], 180)
        original = tomllib.loads((bundle / 'r19-Cargo.lock').read_text())['package']
        resolved = tomllib.loads((project / 'Cargo.lock').read_text())['package']
        allowed = {package_identity(row) for row in original}
        for row in resolved:
            if row['name'] == 'hepta-r20-request-hash-probe':
                need(row['version'] == '0.1.0' and 'source' not in row, 'unexpected root package')
            else:
                need(package_identity(row) in allowed, 'dependency differs from R19 lock: ' + row['name'])
        frozen_lock = identity(project / 'Cargo.lock')
        save(out / 'freeze.json', {'schema': 'hepta-r20-request-hash-freeze/v1',
             'manifest': args.expected_manifest_sha256, 'source_sha256': SOURCE_SHA,
             'resolved_cargo_lock': frozen_lock, 'resolved_packages': resolved,
             'metadata_stdout': identity(out / '03-metadata.stdout'),
             'all_external_packages_in_r19_lock': True, 'wrapper_keys_absent': True})
        run('04-build', cargo + ['build', '--release', '--offline', '--locked'], 900)
        run('05-tests', cargo + ['test', '--release', '--offline', '--locked'], 180)
        binary = out / 'target/release/hepta-r20-request-hash-probe'
        binary_id = identity(binary)
        checked = json.loads(run('06-check', [str(binary), 'check'], 60).read_bytes())
        need(checked['passed'] is True and checked['boundary_cases'] == 7, 'semantic check failed')
        fixtures = {row['case']: row for row in checked['fixtures']}
        need(set(fixtures) == {name for name, _, _ in CASES}, 'fixture set differs')
        cells = []
        with (out / 'raw-cells.jsonl').open('x') as stream:
            for block in range(BLOCKS):
                for name, iterations, warmup in CASES:
                    for slot, arm in enumerate(('A', 'B', 'B', 'A')):
                        label = f'cell-{len(cells):03d}-{block}-{name}-{slot}-{arm}'
                        path = run(label, [str(binary), 'worker', arm, name, str(iterations),
                                          str(warmup), fixtures[name]['sha256']], 60)
                        row = json.loads(path.read_bytes())
                        need(row['arm'] == arm and row['case'] == name and row['iterations'] == iterations
                             and row['warmup'] == warmup and row['all_hashes_equal'] is True
                             and row['expected_sha256'] == fixtures[name]['sha256'], 'worker contract differs')
                        row.update(block=block, slot=slot, stdout=identity(path), binary=binary_id)
                        cells.append(row)
                        stream.write(json.dumps(row, sort_keys=True) + '\n')
                        stream.flush()
                        report['cells'] = len(cells)
        summary = []
        for name, _, _ in CASES:
            rows = [row for row in cells if row['case'] == name]
            pairs = []
            for block in range(BLOCKS):
                means = {arm: statistics.mean(row['cpu_ns_per_call'] for row in rows
                         if row['block'] == block and row['arm'] == arm) for arm in ('A', 'B')}
                pairs.append((means['B'] / means['A'] - 1) * 100)
            item = {'case': name, 'cpu_paired_block_change_percent': pairs,
                    'cpu_paired_block_change_median_percent': statistics.median(pairs),
                    'arms': {arm: {'cpu_ns_per_call_median': statistics.median(row['cpu_ns_per_call'] for row in rows if row['arm'] == arm),
                         'wall_ns_per_call_median': statistics.median(row['wall_ns_per_call'] for row in rows if row['arm'] == arm),
                         'rss_before_bytes': [row['before']['rss_bytes'] for row in rows if row['arm'] == arm],
                         'rss_after_bytes': [row['after']['rss_bytes'] for row in rows if row['arm'] == arm],
                         'lifetime_maxrss_bytes': [row['after']['lifetime_maxrss_bytes'] for row in rows if row['arm'] == arm]}
                         for arm in ('A', 'B')}}
            summary.append(item)
        small_plain = all(row['cpu_paired_block_change_median_percent'] <= 2.0
                          for row in summary if row['case'] not in ('escaped_64k', 'escaped_1mib'))
        escaped = all(row['cpu_paired_block_change_median_percent'] <= -5.0
                      and all(v < 0 for v in row['cpu_paired_block_change_percent'])
                      for row in summary if row['case'] in ('escaped_64k', 'escaped_1mib'))
        need(len(cells) == 96 and identity(binary) == binary_id
             and identity(project / 'Cargo.lock') == frozen_lock, 'final identity/count differs')
        for name, expected in manifest['files'].items():
            need(identity(bundle / name) == expected, 'bundle changed: ' + name)
        for name in ('Cargo.toml', 'rustfmt.toml', *[p for p in manifest['files'] if p.startswith('src/')]):
            need(identity(project / name) == manifest['files'][name], 'compiled source changed: ' + name)
        need(identity(args.baseline_jobs)['sha256'] == SOURCE_SHA, 'R19 source changed')
        report.update(passed=True, source_stable=True, binary=binary_id,
                      resolved_cargo_lock=frozen_lock, fixtures=checked, summary=summary,
                      mechanism_screen_passed=small_plain and escaped,
                      raw_cells=identity(out / 'raw-cells.jsonl'))
    except BaseException as error:
        report['error'] = type(error).__name__ + ': ' + str(error)
    finally:
        save(out / 'report.json', report)
    print(json.dumps({'passed': report['passed'], 'cells': report['cells'],
                      'report': str(out / 'report.json'), 'report_sha256': identity(out / 'report.json')['sha256']}))
    return 0 if report['passed'] else 1


if __name__ == '__main__':
    for requested_signal in (signal.SIGTERM, signal.SIGINT, signal.SIGHUP):
        signal.signal(requested_signal, interrupted)
    sys.exit(main())
