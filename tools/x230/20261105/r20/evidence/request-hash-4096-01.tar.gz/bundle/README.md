# R20 isolated request-hash component probe

This bundle prepares one **unmeasured** candidate. It changes no production source,
server configuration, permission check, request binding field, or digest algorithm.
No compilation or performance run was performed when preparing the bundle.

## Exact baseline and one candidate

The baseline is the exact `RequestBinding`, `request_binding`, `RequestHashWriter`
and `request_digest` excerpt from published R19 commit
`acdd07363cbff335e50c2944e02143d44ab03d6b`,
[`src/mcp/runtime/jobs.rs`](https://github.com/TrillionniumFoundation/hepta-runtime/blob/acdd07363cbff335e50c2944e02143d44ab03d6b/src/mcp/runtime/jobs.rs).
The whole source is 186,456 bytes, SHA256
`c9080de8aa9a35f7495aa2822a1495d297903900ae0f0de26d7b0c86d043d3c9`.
`source-extraction.json` records the exact excerpt identity. The input struct keeps
every original field and Serde attribute; only Schemars schema-generation metadata
is removed so this isolated probe does not require Schemars.

A is that original function. B wraps the same original writer in a fixed **4 KiB
stack buffer**, flushes it before the identical finalization/hex conversion, and
forwards already-large writes directly after draining the buffered prefix. The
buffer has no heap allocation. This is not the rejected unconditional switch to
ring: both arms use `sha2 0.11.0`.

The only direct dependencies are the existing R19 versions of `anyhow`, `libc`,
`serde` with derive, `serde_json`, and `sha2`. The original full lock is retained.
The runner resolves its reduced crate **offline** from an R19-seeded lock, rejects
any external package identity absent from the original lock, and freezes the
resolved lock before `--locked` build/test. The complete Cargo metadata is retained,
including selected features. This isolated dependency graph is not claimed to
match every feature or code-generation context of the full runtime.

## Fixed protocol

Six cases run in fixed order, four ABBA blocks each: **96 fresh workers**, serially.

| Case | Timed calls per worker | Warmup calls |
| --- | ---: | ---: |
| `small_176`: exactly 176 canonical JSON bytes | 100,000 | 256 |
| `escaped_small`: quotes, backslashes, control bytes, Unicode, args/env/cwd | 50,000 | 256 |
| `plain_64k`: 65,536 stdin bytes | 512 | 8 |
| `escaped_64k`: 65,536 stdin bytes | 128 | 4 |
| `plain_1mib`: 1,048,576 stdin bytes | 32 | 2 |
| `escaped_1mib`: 1,048,576 stdin bytes | 8 | 2 |

Before workers run, a separate check process compares the original Value/Vec JSON,
borrowed RequestBinding JSON, actual original writer stream, actual buffered stream,
and all 256 digest bits. It also checks buffer boundaries and exclusion of the
idempotency key. Both sibling Rust tests must pass. The independent canonical digest
is passed to each worker; every warmup/timed result must equal it. A worker never
runs the other arm, and does not allocate the large check-process JSON buffers.

Timed CPU is Linux `CLOCK_PROCESS_CPUTIME_ID`; wall time is `Instant`. Timing includes
the same 64-byte digest equality assertion in both arms and excludes startup,
fixtures, warmup and resource snapshots. RSS is sampled before/after the timed loop.
`getrusage` HWM is the **whole worker's lifetime maximum**, including interpreter-free
Rust process startup, fixtures and warmup. Neither is per-call allocation, stack
usage, runtime-controller RSS, or cluster memory. A 4 KiB fixed stack buffer is a
source property, not a measured claim that RSS improves.

Each case reports four `(mean B / mean A − 1)` block CPU changes, their median,
all arm CPU/wall medians, and each worker RSS/HWM. The preliminary mechanism screen
requires median regression ≤2% for both small cases and both plain large cases;
both large escaped cases must improve by ≥5% in the median and improve in all four
blocks. A screen failure remains in the report. A screen pass only nominates a
later separately qualified production candidate; it does not establish actual
start/reuse throughput or any status/read benefit.

## One invocation on X230, after the full qualification has finished

Choose a new output directory outside this bundle. Supply the locally frozen
`bundle-manifest.json` SHA256 explicitly. Use the existing Cargo cache selected by
the parent qualification workflow:

```sh
python3 -B run_probe.py \
  --baseline-jobs /home/qian/hepta-runtime-optimization-20261104-r19/source/src/mcp/runtime/jobs.rs \
  --cargo-home /home/qian/hepta-runtime-optimization-20261023/cargo-home-a32-a33-r02 \
  --output /home/qian/hepta-runtime-optimization-20261105-r20/request-hash-probe-01 \
  --expected-manifest-sha256 FROZEN_BUNDLE_MANIFEST_SHA256
```

The Cargo-home path is a caller selection and must match the actual cache; no
credential, toolchain or network setup is attempted. Rust/Cargo `+1.95.0` and a Linux
host are required. All wrapper variables are **absent**, not empty. The runner uses
two build jobs and `MALLOC_ARENA_MAX=1`; it runs no performance worker concurrently
with compilation. Estimated duration, not a measured promise: 1–3 minutes for a
fresh small-crate compile when dependencies are already cached, then roughly
20–40 seconds for the fixed component campaign. Stage timeouts are retained.

The output retains original command stdout/stderr, stage receipts, protocol,
resolved lock/metadata/freeze, Rust check results, all 96 raw cell rows, binary
identity, summary and failure information. No automatic retries occur. The working
crate and fresh target live beneath the new output directory; the delivered bundle
and original R19 source are rechecked at the end and remain unchanged.
