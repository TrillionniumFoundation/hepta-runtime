// Copyright 2026 Muvon Un Limited
// Copyright 2026 TrillionniumFoundation
// SPDX-License-Identifier: Apache-2.0
//! Isolated canonical-request hash probe. This is not native process-start TPS.
use anyhow::{bail, ensure, Context, Result};
use serde::{Deserialize, Serialize};
use serde_json::{json, Value};
use sha2::{Digest, Sha256};
use std::collections::BTreeMap;
use std::hint::black_box;
use std::io::Write;
use std::time::Instant;

include!("params.inc.rs");
include!("baseline.inc.rs");
mod candidate;

const CASES: [&str; 6] = [
	"small_176", "escaped_small", "plain_64k", "escaped_64k", "plain_1mib", "escaped_1mib",
];

fn fixture(name: &str) -> Result<ProcessStartParams> {
	let mut p = ProcessStartParams {
		host: "x230-host".into(), executable: "/usr/bin/true".into(), args: vec![],
		cwd: None, env: BTreeMap::new(), stdin: None, timeout_seconds: None,
		idempotency_key: Some("probe-not-a-real-launch".into()), nice: None,
		cpu_quota_percent: None, memory_max_bytes: None,
	};
	match name {
		"small_176" => {},
		"escaped_small" => {
			p.args = vec!["quote\"slash\\".into(), "NUL\0\n\t\r".into(), "λ雪🦀".into()];
			p.cwd = Some("/tmp/雪\\\"".into());
			p.env = BTreeMap::from([("A".into(), "雪\n\"".into()), ("Z".into(), "x\\".into())]);
			p.stdin = Some("\"\\\0\nλ雪🦀".repeat(2));
		},
		"plain_64k" => p.stdin = Some("x".repeat(64 * 1024)),
		"escaped_64k" => p.stdin = Some("\"\\\0\n".repeat(64 * 1024 / 4)),
		"plain_1mib" => p.stdin = Some("x".repeat(1024 * 1024)),
		"escaped_1mib" => p.stdin = Some("\"\\\0\n".repeat(1024 * 1024 / 4)),
		_ => bail!("unknown fixture"),
	}
	Ok(p)
}

fn canonical_legacy(p: &ProcessStartParams) -> Result<Vec<u8>> {
	Ok(serde_json::to_vec(&json!({
		"args": p.args, "cpu_quota_percent": p.cpu_quota_percent,
		"cwd": p.cwd, "env": p.env, "executable": p.executable, "host": p.host,
		"memory_max_bytes": p.memory_max_bytes, "nice": p.nice, "stdin": p.stdin,
		"timeout_seconds": p.timeout_seconds,
	}))?)
}

fn hex_digest(bytes: &[u8]) -> String {
	Sha256::digest(bytes).iter().map(|b| format!("{b:02x}")).collect()
}

#[derive(Default)]
struct RecordingWriter { bytes: Vec<u8>, writes: usize, max_write: usize }
impl Write for RecordingWriter {
	fn write(&mut self, bytes: &[u8]) -> std::io::Result<usize> {
		self.writes += 1;
		self.max_write = self.max_write.max(bytes.len());
		self.bytes.extend_from_slice(bytes);
		Ok(bytes.len())
	}
	fn flush(&mut self) -> std::io::Result<()> { Ok(()) }
}

fn fixture_check(name: &str) -> Result<Value> {
	let p = fixture(name)?;
	let expected = canonical_legacy(&p)?;
	let serialized = serde_json::to_vec(&request_binding(&p))?;
	ensure!(serialized == expected, "canonical bytes differ: {name}");
	if name == "small_176" { ensure!(serialized.len() == 176, "small length differs"); }
	let expected_hash = hex_digest(&expected);
	ensure!(request_digest(&p)? == expected_hash, "baseline digest differs: {name}");
	ensure!(candidate::request_digest_buffered(&p)? == expected_hash, "buffered digest differs: {name}");
	let mut original_fragments = RecordingWriter::default();
	serde_json::to_writer(&mut original_fragments, &request_binding(&p))?;
	let mut buffered_fragments = RecordingWriter::default();
	{
		let mut buffered = candidate::StackBuffer::new(&mut buffered_fragments);
		serde_json::to_writer(&mut buffered, &request_binding(&p))?;
		buffered.flush()?;
	}
	ensure!(original_fragments.bytes == expected && buffered_fragments.bytes == expected,
		"buffer changed byte stream: {name}");
	let mut changed_key = p.clone();
	changed_key.idempotency_key = Some("different-excluded-key".into());
	ensure!(request_digest(&changed_key)? == expected_hash
		&& candidate::request_digest_buffered(&changed_key)? == expected_hash,
		"excluded idempotency key changed hash");
	Ok(json!({"case":name, "input_stdin_bytes":p.stdin.as_ref().map_or(0, String::len),
		"serialized_bytes":serialized.len(), "sha256":expected_hash,
		"baseline_writer_calls":original_fragments.writes,
		"buffered_inner_writer_calls":buffered_fragments.writes,
		"baseline_max_write":original_fragments.max_write,
		"buffered_max_write":buffered_fragments.max_write,
		"canonical_bytes_equal":true, "serialized_stream_equal":true, "full_hash_equal":true}))
}

fn boundary_check() -> Result<usize> {
	let mut cases = 0;
	for lengths in [vec![0], vec![4095, 1, 1], vec![4096], vec![4097],
		vec![3, 8192, 2], vec![1; 8193], vec![0, 4095, 0, 4096, 0, 4097, 0]] {
		let mut expected = vec![];
		let mut recorded = RecordingWriter::default();
		{
			let mut buffered = candidate::StackBuffer::new(&mut recorded);
			for (i, n) in lengths.iter().enumerate() {
				let bytes = vec![(i % 251) as u8; *n];
				expected.extend_from_slice(&bytes);
				ensure!(buffered.write(&bytes)? == bytes.len(), "short write");
			}
			buffered.flush()?;
			buffered.flush()?;
		}
		ensure!(recorded.bytes == expected, "fragment boundary changed bytes");
		cases += 1;
	}
	Ok(cases)
}

fn cpu_ns() -> Result<u128> {
	let mut ts: libc::timespec = unsafe { std::mem::zeroed() };
	if unsafe { libc::clock_gettime(libc::CLOCK_PROCESS_CPUTIME_ID, &mut ts) } != 0 {
		return Err(std::io::Error::last_os_error().into());
	}
	Ok(ts.tv_sec as u128 * 1_000_000_000 + ts.tv_nsec as u128)
}

fn resources() -> Result<Value> {
	let mut usage: libc::rusage = unsafe { std::mem::zeroed() };
	if unsafe { libc::getrusage(libc::RUSAGE_SELF, &mut usage) } != 0 {
		return Err(std::io::Error::last_os_error().into());
	}
	let status = std::fs::read_to_string("/proc/self/status")?;
	let rss = status.lines().find_map(|line| line.strip_prefix("VmRSS:"))
		.context("missing VmRSS")?.split_whitespace().next().context("empty VmRSS")?
		.parse::<u64>()? * 1024;
	Ok(json!({"rss_bytes":rss,"lifetime_maxrss_bytes":usage.ru_maxrss as u64 * 1024}))
}

fn worker(arm: &str, name: &str, iterations: usize, warmup: usize, expected: &str) -> Result<Value> {
	ensure!(iterations > 0 && warmup > 0, "empty protocol");
	let p = fixture(name)?;
	// Same fixture/canonical setup in both arms. No big validation buffers are
	// allocated in workers: those belong to the separate check process. Its
	// pinned canonical hash is passed explicitly; a worker runs only its arm.
	ensure!(expected.len() == 64 && expected.bytes().all(|b| b.is_ascii_digit()
		|| (b'a'..=b'f').contains(&b)), "invalid canonical digest");
	let calculate: fn(&ProcessStartParams) -> Result<String> = match arm {
		"A" => request_digest,
		"B" => candidate::request_digest_buffered,
		_ => bail!("unknown arm"),
	};
	for _ in 0..warmup { ensure!(calculate(black_box(&p))? == expected, "warmup mismatch"); }
	let before = resources()?;
	let wall = Instant::now();
	let cpu_before = cpu_ns()?;
	for _ in 0..iterations {
		let hash = calculate(black_box(&p))?;
		ensure!(hash == expected, "timed digest mismatch");
		drop(black_box(hash));
	}
	let cpu_elapsed = cpu_ns()? - cpu_before;
	let wall_elapsed = wall.elapsed().as_nanos();
	let after = resources()?;
	Ok(json!({"schema":"hepta-r20-request-hash-cell/v1", "arm":arm, "case":name,
		"iterations":iterations,"warmup":warmup,"cpu_ns":cpu_elapsed,"wall_ns":wall_elapsed,
		"cpu_ns_per_call":cpu_elapsed as f64 / iterations as f64,
		"wall_ns_per_call":wall_elapsed as f64 / iterations as f64,
		"expected_sha256":expected,"all_hashes_equal":true,"before":before,"after":after,
		"timing_scope":"request_digest including same full-hash equality check; excludes process startup, fixture creation, warmup and resource samples",
		"memory_scope":"Linux process RSS snapshots and lifetime getrusage HWM, not per-call allocation or cluster memory"}))
}

fn main() -> Result<()> {
	ensure!(cfg!(target_os = "linux"), "probe requires Linux resource units");
	let args: Vec<String> = std::env::args().collect();
	let result = match args.get(1).map(String::as_str) {
		Some("check") if args.len() == 2 => {
			let fixtures: Vec<Value> = CASES.iter().map(|name| fixture_check(name)).collect::<Result<_>>()?;
			json!({"schema":"hepta-r20-request-hash-check/v1", "passed":true,
				"buffer_bytes":candidate::BUFFER_BYTES,"fixtures":fixtures,
				"boundary_cases":boundary_check()?,"source":"exact R19 request_digest and RequestBinding excerpt"})
		},
		Some("worker") if args.len() == 7 => worker(&args[2], &args[3], args[4].parse()?, args[5].parse()?, &args[6])?,
		_ => bail!("usage: probe check | worker A|B CASE ITERATIONS WARMUP EXPECTED_SHA256"),
	};
	println!("{}", serde_json::to_string(&result)?);
	Ok(())
}

#[cfg(test)]
#[path = "probe_tests.rs"]
mod probe_tests;
