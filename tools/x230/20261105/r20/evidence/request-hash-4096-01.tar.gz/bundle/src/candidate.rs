// Copyright 2026 Muvon Un Limited
// Copyright 2026 TrillionniumFoundation
// SPDX-License-Identifier: Apache-2.0
//! One candidate: batch JSON fragments in a fixed 4 KiB stack buffer.
use super::*;

pub(super) const BUFFER_BYTES: usize = 4 * 1024;

pub(super) struct StackBuffer<W: Write> {
	inner: W,
	buffer: [u8; BUFFER_BYTES],
	used: usize,
}

impl<W: Write> StackBuffer<W> {
	pub(super) fn new(inner: W) -> Self {
		Self { inner, buffer: [0; BUFFER_BYTES], used: 0 }
	}

	fn drain(&mut self) -> std::io::Result<()> {
		self.inner.write_all(&self.buffer[..self.used])?;
		self.used = 0;
		Ok(())
	}
}

impl<W: Write> Write for StackBuffer<W> {
	fn write(&mut self, bytes: &[u8]) -> std::io::Result<usize> {
		if bytes.len() >= BUFFER_BYTES {
			// Large unescaped strings already arrive as one contiguous slice.
			// Drain the prefix and forward this slice without an extra copy.
			self.drain()?;
			self.inner.write_all(bytes)?;
		} else {
			if bytes.len() > BUFFER_BYTES - self.used {
				self.drain()?;
			}
			self.buffer[self.used..self.used + bytes.len()].copy_from_slice(bytes);
			self.used += bytes.len();
		}
		Ok(bytes.len())
	}

	fn flush(&mut self) -> std::io::Result<()> {
		self.drain()?;
		self.inner.flush()
	}
}

pub(super) fn request_digest_buffered(params: &ProcessStartParams) -> Result<String> {
	let mut writer = RequestHashWriter(Sha256::new());
	{
		let mut buffered = StackBuffer::new(&mut writer);
		serde_json::to_writer(&mut buffered, &request_binding(params))?;
		buffered.flush()?;
	}
	let digest = writer.0.finalize();
	let mut hex = String::with_capacity(64);
	const HEX: &[u8; 16] = b"0123456789abcdef";
	for byte in digest {
		hex.push(HEX[(byte >> 4) as usize] as char);
		hex.push(HEX[(byte & 15) as usize] as char);
	}
	Ok(hex)
}
