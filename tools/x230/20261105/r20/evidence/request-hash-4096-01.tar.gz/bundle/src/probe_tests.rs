// Copyright 2026 Muvon Un Limited
// Copyright 2026 TrillionniumFoundation
// SPDX-License-Identifier: Apache-2.0
//! Canonical bytes, full digests and actual candidate buffering boundaries.
use super::*;

#[test]
fn six_canonical_request_fixtures() {
	for name in CASES { fixture_check(name).unwrap(); }
}

#[test]
fn fixed_buffer_preserves_fragment_boundaries() {
	assert_eq!(boundary_check().unwrap(), 7);
}
