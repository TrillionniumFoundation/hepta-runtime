#!/usr/bin/env python3
# SPDX-License-Identifier: Apache-2.0
"""Invalidate stale-cache attempt 01 and run exactly one fresh-target qualification."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import runpy
import shutil
import subprocess
import sys
import time
import traceback

ROOT=Path('/home/qian/hepta-runtime-optimization-20261104-r18')
SOURCE=ROOT/'source'
TARGET=ROOT/'target-fresh-02'
OUTPUT=ROOT/'qualification-02'
COMPARISON=json.loads("{\"artifacts\":{\"r14\":[{\"bytes\":68006752,\"fresh\":false,\"kind\":[\"bin\"],\"manifest_path\":\"/home/qian/hepta-runtime-optimization-20261103-r14/source/Cargo.toml\",\"path\":\"/home/qian/hepta-runtime-optimization-20261103-r14/qualification-01/test-binaries/hepta_runtime-f56c8d6245f2b457\",\"sha256\":\"7835ce35b1ca728a29808a5cdf32254a0d9108d69a1d48a46bad04e0fda70c5a\",\"src_path\":\"/home/qian/hepta-runtime-optimization-20261103-r14/source/src/main.rs\",\"target\":\"hepta-runtime\"},{\"bytes\":12402968,\"fresh\":false,\"kind\":[\"bin\"],\"manifest_path\":\"/home/qian/hepta-runtime-optimization-20261103-r14/source/Cargo.toml\",\"path\":\"/home/qian/hepta-runtime-optimization-20261103-r14/qualification-01/test-binaries/hepta_effect_ownerctl-e5753ace8394cc20\",\"sha256\":\"c90d7e56069b33d68202583c472decce4fb27c635f3b681ca7d5ec17cfd31923\",\"src_path\":\"/home/qian/hepta-runtime-optimization-20261103-r14/source/src/bin/hepta-effect-ownerctl.rs\",\"target\":\"hepta-effect-ownerctl\"},{\"bytes\":6881672,\"fresh\":false,\"kind\":[\"example\"],\"manifest_path\":\"/home/qian/hepta-runtime-optimization-20261103-r14/source/Cargo.toml\",\"path\":\"/home/qian/hepta-runtime-optimization-20261103-r14/qualification-01/test-binaries/native_process_driver-6b17814984925a1d\",\"sha256\":\"767f644130c5c67606af81ce8fc19203aa51aea943b4f1c05b704499c69c448c\",\"src_path\":\"/home/qian/hepta-runtime-optimization-20261103-r14/source/examples/native_process_driver.rs\",\"target\":\"native_process_driver\"},{\"bytes\":16063528,\"fresh\":false,\"kind\":[\"bin\"],\"manifest_path\":\"/home/qian/hepta-runtime-optimization-20261103-r14/source/Cargo.toml\",\"path\":\"/home/qian/hepta-runtime-optimization-20261103-r14/qualification-01/test-binaries/hepta_runtime_jobctl-38b254305a5e2468\",\"sha256\":\"b6a6fa64b297279d4265554c63c62132b30cd976ade58861434c89f3adbc8ba5\",\"src_path\":\"/home/qian/hepta-runtime-optimization-20261103-r14/source/src/bin/jobctl.rs\",\"target\":\"hepta-runtime-jobctl\"},{\"bytes\":539667664,\"fresh\":false,\"kind\":[\"lib\"],\"manifest_path\":\"/home/qian/hepta-runtime-optimization-20261103-r14/source/Cargo.toml\",\"path\":\"/home/qian/hepta-runtime-optimization-20261103-r14/qualification-01/test-binaries/hepta_runtime-1b8b761b89392e3b\",\"sha256\":\"fe880a56037ace61fa44a33156e3465792a77a2096adc81af1d7704f5aed445f\",\"src_path\":\"/home/qian/hepta-runtime-optimization-20261103-r14/source/src/lib.rs\",\"target\":\"hepta_runtime\"}],\"r17\":[{\"bytes\":12403024,\"fresh\":false,\"kind\":[\"bin\"],\"manifest_path\":\"/home/qian/hepta-runtime-optimization-20261104-r17/source/Cargo.toml\",\"path\":\"/home/qian/hepta-runtime-optimization-20261104-r17/qualification-01/test-binaries/hepta_effect_ownerctl-e5753ace8394cc20\",\"sha256\":\"dfc500b924462bf344111c66500614399ce5fe1ec4e46016d9d0346440e7ecc4\",\"src_path\":\"/home/qian/hepta-runtime-optimization-20261104-r17/source/src/bin/hepta-effect-ownerctl.rs\",\"target\":\"hepta-effect-ownerctl\"},{\"bytes\":68006744,\"fresh\":false,\"kind\":[\"bin\"],\"manifest_path\":\"/home/qian/hepta-runtime-optimization-20261104-r17/source/Cargo.toml\",\"path\":\"/home/qian/hepta-runtime-optimization-20261104-r17/qualification-01/test-binaries/hepta_runtime-f56c8d6245f2b457\",\"sha256\":\"2d23c22764d1836db04a878eb9b850d5487bdcb89e50ba455bbd3c87d7ce4537\",\"src_path\":\"/home/qian/hepta-runtime-optimization-20261104-r17/source/src/main.rs\",\"target\":\"hepta-runtime\"},{\"bytes\":6881680,\"fresh\":false,\"kind\":[\"example\"],\"manifest_path\":\"/home/qian/hepta-runtime-optimization-20261104-r17/source/Cargo.toml\",\"path\":\"/home/qian/hepta-runtime-optimization-20261104-r17/qualification-01/test-binaries/native_process_driver-6b17814984925a1d\",\"sha256\":\"5a27b31ed40adcd00e6778a3ada9e2af03f2497c8905884389bd25e8aa2b5136\",\"src_path\":\"/home/qian/hepta-runtime-optimization-20261104-r17/source/examples/native_process_driver.rs\",\"target\":\"native_process_driver\"},{\"bytes\":16135912,\"fresh\":false,\"kind\":[\"bin\"],\"manifest_path\":\"/home/qian/hepta-runtime-optimization-20261104-r17/source/Cargo.toml\",\"path\":\"/home/qian/hepta-runtime-optimization-20261104-r17/qualification-01/test-binaries/hepta_runtime_jobctl-38b254305a5e2468\",\"sha256\":\"5d5f79a5cc4a0b3f603a14d94d5db6f6631589c074041f3425eb08ffbc68ab26\",\"src_path\":\"/home/qian/hepta-runtime-optimization-20261104-r17/source/src/bin/jobctl.rs\",\"target\":\"hepta-runtime-jobctl\"},{\"bytes\":539606864,\"fresh\":false,\"kind\":[\"lib\"],\"manifest_path\":\"/home/qian/hepta-runtime-optimization-20261104-r17/source/Cargo.toml\",\"path\":\"/home/qian/hepta-runtime-optimization-20261104-r17/qualification-01/test-binaries/hepta_runtime-1b8b761b89392e3b\",\"sha256\":\"5394e8bcf30258e24ea3fa7975c1b9c8f2ec00c613bf58f5299cddd627f0c288\",\"src_path\":\"/home/qian/hepta-runtime-optimization-20261104-r17/source/src/lib.rs\",\"target\":\"hepta_runtime\"}],\"r18\":[{\"bytes\":539606864,\"fresh\":true,\"kind\":[\"lib\"],\"manifest_path\":\"/home/qian/hepta-runtime-optimization-20261104-r18/source/Cargo.toml\",\"path\":\"/home/qian/hepta-runtime-optimization-20261104-r18/qualification-01/test-binaries/hepta_runtime-1b8b761b89392e3b\",\"sha256\":\"5394e8bcf30258e24ea3fa7975c1b9c8f2ec00c613bf58f5299cddd627f0c288\",\"src_path\":\"/home/qian/hepta-runtime-optimization-20261104-r18/source/src/lib.rs\",\"target\":\"hepta_runtime\"},{\"bytes\":12403024,\"fresh\":true,\"kind\":[\"bin\"],\"manifest_path\":\"/home/qian/hepta-runtime-optimization-20261104-r18/source/Cargo.toml\",\"path\":\"/home/qian/hepta-runtime-optimization-20261104-r18/qualification-01/test-binaries/hepta_effect_ownerctl-e5753ace8394cc20\",\"sha256\":\"dfc500b924462bf344111c66500614399ce5fe1ec4e46016d9d0346440e7ecc4\",\"src_path\":\"/home/qian/hepta-runtime-optimization-20261104-r18/source/src/bin/hepta-effect-ownerctl.rs\",\"target\":\"hepta-effect-ownerctl\"},{\"bytes\":6881680,\"fresh\":true,\"kind\":[\"example\"],\"manifest_path\":\"/home/qian/hepta-runtime-optimization-20261104-r18/source/Cargo.toml\",\"path\":\"/home/qian/hepta-runtime-optimization-20261104-r18/qualification-01/test-binaries/native_process_driver-6b17814984925a1d\",\"sha256\":\"5a27b31ed40adcd00e6778a3ada9e2af03f2497c8905884389bd25e8aa2b5136\",\"src_path\":\"/home/qian/hepta-runtime-optimization-20261104-r18/source/examples/native_process_driver.rs\",\"target\":\"native_process_driver\"},{\"bytes\":68006744,\"fresh\":true,\"kind\":[\"bin\"],\"manifest_path\":\"/home/qian/hepta-runtime-optimization-20261104-r18/source/Cargo.toml\",\"path\":\"/home/qian/hepta-runtime-optimization-20261104-r18/qualification-01/test-binaries/hepta_runtime-f56c8d6245f2b457\",\"sha256\":\"2d23c22764d1836db04a878eb9b850d5487bdcb89e50ba455bbd3c87d7ce4537\",\"src_path\":\"/home/qian/hepta-runtime-optimization-20261104-r18/source/src/main.rs\",\"target\":\"hepta-runtime\"},{\"bytes\":16135992,\"fresh\":false,\"kind\":[\"bin\"],\"manifest_path\":\"/home/qian/hepta-runtime-optimization-20261104-r18/source/Cargo.toml\",\"path\":\"/home/qian/hepta-runtime-optimization-20261104-r18/qualification-01/test-binaries/hepta_runtime_jobctl-38b254305a5e2468\",\"sha256\":\"9e784b72b6d6a70659fbba87cf63c4671b27cc20f9150b01dd951be5a8ed96d4\",\"src_path\":\"/home/qian/hepta-runtime-optimization-20261104-r18/source/src/bin/jobctl.rs\",\"target\":\"hepta-runtime-jobctl\"}]},\"comparisons\":[{\"equals_r14\":false,\"equals_r17\":true,\"kind\":[\"lib\"],\"r14_matching_targets\":1,\"r14_sha256\":\"fe880a56037ace61fa44a33156e3465792a77a2096adc81af1d7704f5aed445f\",\"r17_matching_targets\":1,\"r17_sha256\":\"5394e8bcf30258e24ea3fa7975c1b9c8f2ec00c613bf58f5299cddd627f0c288\",\"r18_fresh\":true,\"r18_sha256\":\"5394e8bcf30258e24ea3fa7975c1b9c8f2ec00c613bf58f5299cddd627f0c288\",\"target\":\"hepta_runtime\"},{\"equals_r14\":false,\"equals_r17\":true,\"kind\":[\"bin\"],\"r14_matching_targets\":1,\"r14_sha256\":\"c90d7e56069b33d68202583c472decce4fb27c635f3b681ca7d5ec17cfd31923\",\"r17_matching_targets\":1,\"r17_sha256\":\"dfc500b924462bf344111c66500614399ce5fe1ec4e46016d9d0346440e7ecc4\",\"r18_fresh\":true,\"r18_sha256\":\"dfc500b924462bf344111c66500614399ce5fe1ec4e46016d9d0346440e7ecc4\",\"target\":\"hepta-effect-ownerctl\"},{\"equals_r14\":false,\"equals_r17\":true,\"kind\":[\"example\"],\"r14_matching_targets\":1,\"r14_sha256\":\"767f644130c5c67606af81ce8fc19203aa51aea943b4f1c05b704499c69c448c\",\"r17_matching_targets\":1,\"r17_sha256\":\"5a27b31ed40adcd00e6778a3ada9e2af03f2497c8905884389bd25e8aa2b5136\",\"r18_fresh\":true,\"r18_sha256\":\"5a27b31ed40adcd00e6778a3ada9e2af03f2497c8905884389bd25e8aa2b5136\",\"target\":\"native_process_driver\"},{\"equals_r14\":false,\"equals_r17\":true,\"kind\":[\"bin\"],\"r14_matching_targets\":1,\"r14_sha256\":\"7835ce35b1ca728a29808a5cdf32254a0d9108d69a1d48a46bad04e0fda70c5a\",\"r17_matching_targets\":1,\"r17_sha256\":\"2d23c22764d1836db04a878eb9b850d5487bdcb89e50ba455bbd3c87d7ce4537\",\"r18_fresh\":true,\"r18_sha256\":\"2d23c22764d1836db04a878eb9b850d5487bdcb89e50ba455bbd3c87d7ce4537\",\"target\":\"hepta-runtime\"},{\"equals_r14\":false,\"equals_r17\":false,\"kind\":[\"bin\"],\"r14_matching_targets\":1,\"r14_sha256\":\"b6a6fa64b297279d4265554c63c62132b30cd976ade58861434c89f3adbc8ba5\",\"r17_matching_targets\":1,\"r17_sha256\":\"5d5f79a5cc4a0b3f603a14d94d5db6f6631589c074041f3425eb08ffbc68ab26\",\"r18_fresh\":false,\"r18_sha256\":\"9e784b72b6d6a70659fbba87cf63c4671b27cc20f9150b01dd951be5a8ed96d4\",\"target\":\"hepta-runtime-jobctl\"}],\"jobs_source\":{\"r14\":{\"mtime_ns\":1793738469916629500,\"path\":\"/home/qian/hepta-runtime-optimization-20261103-r14/source/src/mcp/runtime/jobs.rs\",\"sha256\":\"694a4e4dcbc2be499879abd837f0b5e399f9cad95caab34716907de15cbbe82f\"},\"r17\":{\"mtime_ns\":1793780879676619500,\"path\":\"/home/qian/hepta-runtime-optimization-20261104-r17/source/src/mcp/runtime/jobs.rs\",\"sha256\":\"f7c23620d2d79c5a02938b432e90f8dadb6352a897bf5a575547eabc121119f4\"},\"r18\":{\"mtime_ns\":1793738469916629500,\"path\":\"/home/qian/hepta-runtime-optimization-20261104-r18/source/src/mcp/runtime/jobs.rs\",\"sha256\":\"694a4e4dcbc2be499879abd837f0b5e399f9cad95caab34716907de15cbbe82f\"}},\"schema\":\"hepta-r18-retained-test-artifact-cache-comparison/v1\"}")
PREFLIGHT=json.loads("{\"binaries\":{\"hepta-runtime\":{\"actual_sha256\":\"1c1d79911ce039186ca40817524a1f5f6b03dae4dd936ee87c0ab05b69f3cbe1\",\"path\":\"/home/qian/hepta-runtime-optimization-20261104-r18/qualification-01/hepta-runtime\",\"reported_sha256\":\"1c1d79911ce039186ca40817524a1f5f6b03dae4dd936ee87c0ab05b69f3cbe1\"},\"hepta-runtime-jobctl\":{\"actual_sha256\":\"61c90260057a405626a24a36ad43303c632f72d2d97929296acdffd748b79d62\",\"path\":\"/home/qian/hepta-runtime-optimization-20261104-r18/qualification-01/hepta-runtime-jobctl\",\"reported_sha256\":\"61c90260057a405626a24a36ad43303c632f72d2d97929296acdffd748b79d62\"},\"native_process_driver\":{\"actual_sha256\":\"49f2f2717996361acb7e8fe48e46551be5c20167267f6c4b991a5477c111b7e9\",\"path\":\"/home/qian/hepta-runtime-optimization-20261104-r18/qualification-01/native_process_driver\",\"reported_sha256\":\"49f2f2717996361acb7e8fe48e46551be5c20167267f6c4b991a5477c111b7e9\"}},\"disk\":{\"du_exit_code\":0,\"existing_target_allocated_bytes\":2922647552,\"free\":37079740416,\"minimum_free_bytes\":17179869184,\"sufficient\":true,\"total\":234621349888,\"used\":185548943360},\"fresh_target_exists\":false,\"qualification_02_exists\":false,\"qualified_claim\":true,\"qualified_report_sha256\":\"0ce99b6bb81a30489a06fae33a0422fdd22bcb96b9db858093939ed5f8200fd2\"}")
PREP_SCRIPT_SHA='e17374d5f5b7206001c97a91cf5d792fa2d1fc0b366a8c36fcdec539df6f2fb7'
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def need(v,m):
    if not v:raise ValueError(m)
def sha(p):
    h=hashlib.sha256()
    with Path(p).open('rb') as f:
        for b in iter(lambda:f.read(1<<20),b''):h.update(b)
    return h.hexdigest()
def write(name,value):
    p=ROOT/name;p.parent.mkdir(parents=True,exist_ok=True)
    with p.open('xb') as f:f.write((json.dumps(value,sort_keys=True,indent=2)+'\n').encode())
def same_bytes(a,b):
    if Path(a).stat().st_size!=Path(b).stat().st_size:return False
    with Path(a).open('rb') as x,Path(b).open('rb') as y:
        while True:
            first=x.read(1<<20);second=y.read(1<<20)
            if first!=second:return False
            if not first:return True

def main():
    phase='fresh-preflight';started=time.monotonic()
    try:
        need(sha(ROOT/'prepare-and-qualify.py')==PREP_SCRIPT_SHA,'original preparation script changed')
        helpers=runpy.run_path(str(ROOT/'prepare-and-qualify.py'),run_name='r18_readonly_helpers')
        full_map,compile_map=helpers['full_map'],helpers['compile_map']
        original_full=json.loads((ROOT/'source-full-map.json').read_bytes())
        original_inputs=json.loads((ROOT/'source-map.json').read_bytes())
        need(full_map(SOURCE)==original_full and compile_map(original_full)==original_inputs and len(original_inputs)==219,'R18 frozen source bytes changed')
        protected=json.loads((ROOT/'protected-artifacts-before.json').read_bytes())
        need(helpers['protected_snapshot']()==protected,'historical protected sources/reports/binaries changed')
        q1=ROOT/'qualification-01/report.json'
        need(sha(q1)==PREFLIGHT['qualified_report_sha256'],'attempt 01 report changed')
        q1report=json.loads(q1.read_bytes())
        need(q1report['qualified'] is True,'unexpected original attempt 01 claim')
        lib=[r for r in COMPARISON['comparisons'] if r['kind']==['lib'] and r['target']=='hepta_runtime']
        need(len(lib)==1 and lib[0]['equals_r17'] and not lib[0]['equals_r14'] and lib[0]['r18_fresh'],'stale lib artifact evidence missing')
        need(original_inputs['src/mcp/runtime/jobs.rs']=='694a4e4dcbc2be499879abd837f0b5e399f9cad95caab34716907de15cbbe82f','R18 jobs bytes differ from intended R14')
        binary_observation={}
        for name,row in q1report['binaries'].items():
            actual=sha(row['path'])
            need(actual==PREFLIGHT['binaries'][name]['actual_sha256']==row['sha256'],'attempt01 binary changed')
            binary_observation[name]={'path':row['path'],'sha256':actual}
        write('independent-invalidation-01.json',{
          'schema':'hepta-r18-source-artifact-binding-invalidation/v1','created_utc':now(),'attempt':'qualification-01','accepted':False,
          'original_report_qualified_claim':True,'original_report_path':str(q1),'original_report_sha256':sha(q1),
          'reason':'R18 source restored jobs.rs to R14, but the retained library/runtime test artifacts are byte-identical to R17 and Cargo reported them fresh. This attempt does not establish qualification of the intended source.',
          'observed_test_artifacts':COMPARISON,'observed_release_binaries':binary_observation,
          'mtime_causal_boundary':'copy2 preserved the older R14 source mtimes; observed fresh flags and exact R17 artifact reuse establish wrong source/artifact binding. This is consistent with mtime-based reuse; it is not a trace of every Cargo freshness decision.',
          'source_inputs_unchanged':True,'source_map_sha256':sha(ROOT/'source-map.json'),
          'comparison_job_id':'1a1a5f26ab7-fc05-225b','comparison_release_disk_job_id':'1a1a5f53457-fc05-226b',
          'original_attempt_preserved':True,'original_report_modified':False,
          'remediation':'One specifically authorized qualification-02 with a previously nonexistent dedicated target directory; no timestamp touching and no automatic third attempt.'})
        need(not TARGET.exists() and not TARGET.is_symlink(),'fresh target already exists')
        need(not OUTPUT.exists() and not OUTPUT.is_symlink(),'qualification-02 output already exists')
        du=subprocess.run(['/usr/bin/du','-s','-B1','/home/qian/hepta-runtime-optimization-20261104-r16/target'],capture_output=True,text=True,check=False)
        need(du.returncode==0,'cannot establish existing target allocation')
        allocated=int(du.stdout.split()[0]);usage=shutil.disk_usage(ROOT)
        required=max(16*(1<<30),allocated*3//2+3*(1<<30))
        need(usage.free>=required,'insufficient free space for independent fresh target')
        disk={'free_bytes':usage.free,'existing_target_allocated_bytes':allocated,'minimum_free_bytes':required,'sufficient':True,'du_exit_code':du.returncode}
        TARGET.mkdir(mode=0o700,exist_ok=False)
        need(not any(TARGET.iterdir()),'new target is not empty')
        with (ROOT/'qualification-fresh-02.py').open('x') as f:f.write(LAUNCH_SCRIPT)
        argv=['/usr/bin/python3','-B','-u',str(SOURCE/'tools/x230/20261028/qualify.py'),
          '--source',str(SOURCE),'--output',str(OUTPUT),'--target',str(TARGET),
          '--cargo-home','/home/qian/hepta-runtime-optimization-20261023/cargo-home-a32-a33-r02',
          '--jobs','2','--stage-timeout','3600']
        env=dict(os.environ)
        prefixes=('CARGO_','RUST_','MALLOC_','GLIBC_','HEPTA_','SSH_')
        exact={'RUSTFLAGS','RUSTDOCFLAGS','CARGO_ENCODED_RUSTFLAGS','RUSTC_WRAPPER','RUSTC_WORKSPACE_WRAPPER','PYTHONPATH','PYTHONHOME','RUST_LOG'}
        removed=sorted(k for k in env if k.startswith(prefixes) or k in exact)
        for key in removed:env.pop(key,None)
        env.update({'PYTHONDONTWRITEBYTECODE':'1','PATH':'/home/qian/.cargo/bin:/usr/local/bin:/usr/bin:/bin'})
        launch={'schema':'hepta-r18-fresh-qualification-launch/v1','created_utc':now(),'argv':argv,'cwd':str(SOURCE),
          'target_asserted_nonexistent':True,'target_created_empty':True,'disk':disk,
          'source_map_sha256':sha(ROOT/'source-map.json'),'source_freeze_sha256':sha(ROOT/'source-freeze.json'),
          'invalidation_01_sha256':sha(ROOT/'independent-invalidation-01.json'),'original_attempt_01_report_sha256':sha(q1),
          'original_attempt_01_accepted':False,'cleared_environment_key_names':removed,
          'clear_environment_prefixes':list(prefixes),'clear_environment_exact_names':sorted(exact),
          'script_sha256':sha(ROOT/'qualification-fresh-02.py'),'automatic_retries':0,'automatic_third_attempt':False}
        write('qualification-launch-02.json',launch)
        print('R18_FRESH_02_STARTED '+json.dumps({'source_inputs':219,'target':str(TARGET),'target_previously_absent':True,
          'disk':disk,'invalidation_01_sha256':sha(ROOT/'independent-invalidation-01.json'),'launch_sha256':sha(ROOT/'qualification-launch-02.json')}),flush=True)
        phase='qualification-02'
        qstarted=time.monotonic()
        process=subprocess.run(argv,cwd=SOURCE,env=env,check=False)
        write('qualification-exit-02.json',{'schema':'hepta-r18-fresh-qualification-exit/v1','finished_utc':now(),
          'returncode':process.returncode,'elapsed_seconds':time.monotonic()-qstarted,'automatic_retries':0})
        print('R18_FRESH_02_QUALIFICATION_EXIT '+str(process.returncode),flush=True)
        if process.returncode:return process.returncode
        phase='fresh-root-artifact-review'
        artifacts=[]
        for line in (OUTPUT/'cargo-no-run.jsonl').read_text().splitlines():
            event=json.loads(line)
            if event.get('reason')=='compiler-artifact' and event.get('manifest_path')==str(SOURCE/'Cargo.toml'):
                artifacts.append({'target':event['target']['name'],'kind':event['target']['kind'],
                  'src_path':event['target']['src_path'],'profile_test':event['profile']['test'],'fresh':event.get('fresh')})
        all_rebuilt=bool(artifacts) and all(row['fresh'] is False for row in artifacts)
        write('fresh-artifact-review-02.json',{'schema':'hepta-r18-fresh-root-artifacts/v1','success':all_rebuilt,
          'artifacts':artifacts,'source_report_sha256':sha(OUTPUT/'report.json'),'cargo_no_run_sha256':sha(OUTPUT/'cargo-no-run.jsonl')})
        phase='release-identity-review'
        report=json.loads((OUTPUT/'report.json').read_bytes())
        expected=helpers['EXPECTED_BINARIES'];identity={}
        for name,row in report['binaries'].items():
            refroot='r17' if name=='hepta-runtime-jobctl' else 'r14'
            reference=protected[refroot]['binaries'][name]['path']
            actual=sha(row['path']);reference_sha=sha(reference)
            identity[name]={'path':row['path'],'actual_sha256':actual,'reported_sha256':row['sha256'],
              'reference_path':reference,'reference_sha256':reference_sha,'expected_sha256':expected[name],
              'sha256_matches':actual==row['sha256']==reference_sha==expected[name],'byte_for_byte_equal':same_bytes(row['path'],reference)}
        identity_success=len(identity)==3 and all(x['sha256_matches'] and x['byte_for_byte_equal'] for x in identity.values())
        write('binary-identity-review-02.json',{'schema':'hepta-r18-fresh-release-identity/v1','success':identity_success,'binaries':identity})
        preserved=helpers['protected_snapshot']()==protected
        source_stable=full_map(SOURCE)==original_full and report['source_input']==report['source_tested']==report['source_after']==original_inputs
        acceptance={'schema':'hepta-r18-fresh-qualification-identity-review/v1','created_utc':now(),
          'success':all_rebuilt and identity_success and preserved and source_stable and report.get('qualified') is True,
          'qualified_report_sha256':sha(OUTPUT/'report.json'),'all_root_crate_artifacts_rebuilt':all_rebuilt,
          'expected_release_identities_match':identity_success,'historical_artifacts_preserved':preserved,'source_219_unchanged':source_stable,
          'attempt01_accepted':False,'attempt01_original_report_preserved':sha(q1)==PREFLIGHT['qualified_report_sha256'],
          'independent_final_acceptance_pending':True,'automatic_third_attempt':False}
        acceptance['success']=acceptance['success'] and acceptance['attempt01_original_report_preserved']
        write('qualification-identity-review-02.json',acceptance)
        print('R18_FRESH_02_IDENTITY_REVIEW '+json.dumps(acceptance),flush=True)
        return 0 if acceptance['success'] else 2
    except BaseException as error:
        failure={'schema':'hepta-r18-fresh-qualification-failure/v1','phase':phase,'created_utc':now(),
          'error':type(error).__name__+': '+str(error),'elapsed_seconds':time.monotonic()-started,'automatic_retries':0,'automatic_third_attempt':False}
        try:write('qualification-fresh-02-failure.json',failure)
        except Exception:pass
        try:
            with (ROOT/'qualification-fresh-02-failure.stderr').open('x') as f:traceback.print_exc(file=f)
        except Exception:pass
        print('R18_FRESH_02_FAILURE '+json.dumps(failure),file=sys.stderr,flush=True)
        return 1
if __name__=='__main__':raise SystemExit(main())
