#!/usr/bin/env python3
# SPDX-License-Identifier: Apache-2.0
"""Prepare an isolated R18 jobctl-only source, then run the unchanged full qualifier once."""
import datetime
import difflib
import hashlib
import json
import os
from pathlib import Path
import shutil
import stat
import subprocess
import sys
import time
import traceback

ROOT=Path('/home/qian/hepta-runtime-optimization-20261104-r18')
SOURCE=ROOT/'source'
R14=Path('/home/qian/hepta-runtime-optimization-20261103-r14')
R16=Path('/home/qian/hepta-runtime-optimization-20261104-r16')
R17=Path('/home/qian/hepta-runtime-optimization-20261104-r17')
BASELINE_COMMIT='a784b92df7c84e6047343b436222716eb4b532d6'
REPORT_SHA={
 'r14':'d6a46164b30c6677cf49ec7eea156748a8445589c71034795d016a62795610cd',
 'r16':'a284512d70ebe5be84b65d510d196affdba2fe962ee9d5837af3aa9cf489f923',
 'r17':'883d65c6947f6d6617dabc9af04246fb28e75b4fdb473e175a65212d5e14f1a9',
}
JOBCTL_BEFORE='2c8bcbdac8b8fa113526b80a8eda5b40355d20f4cbbb347cc240172c78320983'
JOBCTL_AFTER='c22fdcd5bafad3a2123d5817c27fd73e7b5c26001bf1a8bdd6f8dbacabc8b562'
JOBS_BASELINE='694a4e4dcbc2be499879abd837f0b5e399f9cad95caab34716907de15cbbe82f'
PATCH_SHA='4627f0a9f70efd40affa918bd03234142f28439914099b4e17c39eb3f1ecd31e'
REVIEW_SHA='6a462fcf70100a962227cc3762b6d95b746a7e89f69d954c6f941ccb7e2988da'
EXPECTED_BINARIES={
 'hepta-runtime':'51480b3cf630a95419d3afeb571eec17c90cffa5944101920d05333673de031d',
 'native_process_driver':'551aa5ba0f990908d0143c34f513a0f1937f14198335c5e4a611a112b82f944e',
 'hepta-runtime-jobctl':'61c90260057a405626a24a36ad43303c632f72d2d97929296acdffd748b79d62',
}
def now(): return datetime.datetime.now(datetime.timezone.utc).isoformat()
def need(value,message):
    if not value: raise ValueError(message)
def sha_bytes(raw): return hashlib.sha256(raw).hexdigest()
def sha(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as f:
        for block in iter(lambda:f.read(1<<20),b''):h.update(block)
    return h.hexdigest()
def canonical(value):return sha_bytes(json.dumps(value,sort_keys=True,separators=(',',':')).encode())
def write_json(name,value):
    p=ROOT/name
    p.parent.mkdir(parents=True,exist_ok=True)
    with p.open('xb') as f:f.write((json.dumps(value,sort_keys=True,indent=2)+'\n').encode())
def full_map(root):
    need(root.is_dir() and not root.is_symlink(),'source must be an ordinary directory: '+str(root))
    out={}
    def walk(directory,prefix):
        with os.scandir(directory) as entries:
            for entry in sorted(entries,key=lambda x:x.name):
                relative=prefix+entry.name
                s=entry.stat(follow_symlinks=False)
                if stat.S_ISDIR(s.st_mode):walk(Path(entry.path),relative+'/')
                else:
                    need(stat.S_ISREG(s.st_mode) and s.st_nlink==1,'non-regular or linked source file: '+relative)
                    out[relative]=sha(Path(entry.path))
    walk(root,'')
    return dict(sorted(out.items()))
def compile_map(full):
    return {p:h for p,h in full.items() if p in ('Cargo.toml','Cargo.lock','rustfmt.toml') or p.startswith(('src/','examples/'))}
def protected_snapshot():
    result={}
    for name,base in [('r14',R14),('r16',R16),('r17',R17)]:
        report_path=base/'qualification-01/report.json'
        need(sha(report_path)==REPORT_SHA[name],name+' qualified report hash differs')
        report=json.loads(report_path.read_bytes())
        need(report.get('qualified') is True,name+' report is not qualified')
        full=full_map(base/'source')
        current=compile_map(full)
        need(len(current)==219 and current==report['source_after'],name+' qualified source changed')
        binaries={}
        for binary,row in report['binaries'].items():
            actual=sha(row['path'])
            need(actual==row['sha256'],name+' saved binary changed: '+binary)
            binaries[binary]={'path':row['path'],'sha256':actual}
        result[name]={'root':str(base),'report_path':str(report_path),'report_sha256':sha(report_path),
          'source_inputs':current,'source_full_map':full,'source_full_file_count':len(full),'binaries':binaries}
    return result

def main():
    created=False
    started=time.monotonic()
    phase='create-root'
    try:
        ROOT.mkdir(mode=0o700,parents=False,exist_ok=False)
        created=True
        with (ROOT/'prepare-and-qualify.py').open('x') as f:f.write(LAUNCH_SCRIPT)
        phase='verify-protected-baselines'
        protected=protected_snapshot()
        write_json('protected-artifacts-before.json',protected)
        baseline_full=protected['r14']['source_full_map']
        baseline_inputs=protected['r14']['source_inputs']
        need(len(baseline_full)==281 and len(baseline_inputs)==219,'R14 source inventory count differs')
        need(baseline_inputs['src/bin/jobctl.rs']==JOBCTL_BEFORE,'R14 jobctl hash differs')
        need(baseline_inputs['src/mcp/runtime/jobs.rs']==JOBS_BASELINE,'R14 jobs hash differs')
        jobctl=(R17/'source/src/bin/jobctl.rs').read_bytes()
        need(sha_bytes(jobctl)==JOBCTL_AFTER==protected['r17']['source_inputs']['src/bin/jobctl.rs'],'R17 qualified jobctl identity differs')
        need(protected['r14']['binaries']['hepta-runtime']['sha256']==EXPECTED_BINARIES['hepta-runtime'],'R14 runtime reference differs')
        need(protected['r14']['binaries']['native_process_driver']['sha256']==EXPECTED_BINARIES['native_process_driver'],'R14 driver reference differs')
        need(protected['r17']['binaries']['hepta-runtime-jobctl']['sha256']==EXPECTED_BINARIES['hepta-runtime-jobctl'],'R17 jobctl reference differs')
        phase='copy-isolated-source'
        shutil.copytree(R14/'source',SOURCE,copy_function=shutil.copy2,symlinks=False)
        (SOURCE/'src/bin/jobctl.rs').write_bytes(jobctl)
        candidate_full=full_map(SOURCE)
        candidate_inputs=compile_map(candidate_full)
        delta=[p for p in sorted(set(baseline_full)|set(candidate_full)) if baseline_full.get(p)!=candidate_full.get(p)]
        need(len(candidate_full)==281 and len(candidate_inputs)==219,'R18 source inventory count differs')
        need(set(candidate_full)==set(baseline_full),'source files added or removed')
        need(delta==['src/bin/jobctl.rs'],'R18 has more than one source delta')
        need(candidate_inputs['src/bin/jobctl.rs']==JOBCTL_AFTER,'R18 jobctl hash differs')
        need(candidate_inputs['src/mcp/runtime/jobs.rs']==JOBS_BASELINE,'R18 jobs was not restored to R14')
        need(full_map(R14/'source')==baseline_full,'R14 source changed during copy')
        patch=''.join(difflib.unified_diff((R14/'source/src/bin/jobctl.rs').read_text().splitlines(keepends=True),
          jobctl.decode().splitlines(keepends=True),fromfile='a/src/bin/jobctl.rs',tofile='b/src/bin/jobctl.rs')).encode()
        need(sha_bytes(patch)==PATCH_SHA,'minimal jobctl patch differs')
        (ROOT/'patches').mkdir()
        with (ROOT/'patches/jobctl-buffer.patch').open('xb') as f:f.write(patch)
        write_json('baseline-source-map.json',baseline_inputs)
        write_json('baseline-full-tree-map.json',baseline_full)
        write_json('source-map.json',candidate_inputs)
        write_json('source-full-map.json',candidate_full)
        binding={'schema':'hepta-x230-r18-baseline-binding/v1','created_utc':now(),'baseline_commit':BASELINE_COMMIT,
          'baseline_source':str(R14/'source'),'baseline_qualification_report':str(R14/'qualification-01/report.json'),
          'baseline_qualification_sha256':REPORT_SHA['r14'],'baseline_qualified':True,
          'baseline_full_file_count':281,'baseline_compile_input_count':219,
          'baseline_source_canonical_map_sha256':canonical(baseline_inputs),
          'baseline_full_tree_canonical_map_sha256':canonical(baseline_full),
          'jobctl_source':str(R17/'source/src/bin/jobctl.rs'),'jobctl_qualification_report_sha256':REPORT_SHA['r17'],
          'jobctl_source_sha256':JOBCTL_AFTER}
        write_json('baseline-binding.json',binding)
        decision={'schema':'hepta-x230-r18-selection-decision/v1','created_utc':now(),
          'r17_combined_candidate':'rejected; preserve all R17 candidate source, diffs, and evidence',
          'r17_final_review_reference_sha256':REVIEW_SHA,'review_values_source':'parent-supplied final R17 review identified by this SHA256',
          'r17_c16_paired_percent_changes':{'rate':[-0.942,-1.125],'cpu':[2.571,1.0],'p95':[2.733,3.293],'p99':[15.208,15.221]},
          'r17_mean_memory_change_kib':-20,'reason':'Small memory change does not justify the observed throughput, CPU, and latency regressions.',
          'r18_candidate':'R14 source plus only the qualified bounded BufReader change in jobctl',
          'r18_adoption':'pending full qualification and exact release-binary identity checks',
          'reused_evidence_condition':'Reuse existing operator multi-host and recovery evidence only if actual R18 runtime and driver bytes match preserved R14 binaries; require jobctl bytes to match preserved R17 jobctl.',
          'expected_binary_sha256':EXPECTED_BINARIES,'automatic_retries':0}
        write_json('selection-decision.json',decision)
        review={'schema':'hepta-x230-r18-source-review/v1','created_utc':now(),'changed_file':'src/bin/jobctl.rs',
          'before_sha256':JOBCTL_BEFORE,'after_sha256':JOBCTL_AFTER,'patch_sha256':PATCH_SHA,
          'contract':'Only wrap the exclusively owned bounded file reader in BufReader::with_capacity(8192, f.take(INPUT_MAX + 1)).',
          'preserved':['Take remains inside BufReader','same O_NOFOLLOW/O_NONBLOCK/O_CLOEXEC open flags','same initial regular-file and size checks','same serde_json::from_reader end/error semantics','no cache/retry/shared file descriptor','no new post-read fstat or atomic-snapshot claim'],
          'jobs_rs_restored_to_r14_sha256':JOBS_BASELINE,'profile_candidate_included':False,
          'r17_rejection_review_sha256':REVIEW_SHA,'source_review_basis':'Exact R17-qualified jobctl source and previously mechanism-tested minimal patch; no other R17 production change retained.'}
        write_json('source-review.json',review)
        freeze={'schema':'hepta-x230-r18-source-freeze/v1','created_utc':now(),'source':str(SOURCE),'baseline_commit':BASELINE_COMMIT,
          'source_file_count':281,'compiler_input_count':219,'source_canonical_map_sha256':canonical(candidate_inputs),
          'source_full_tree_canonical_map_sha256':canonical(candidate_full),
          'source_map_sha256':sha(ROOT/'source-map.json'),'source_full_map_sha256':sha(ROOT/'source-full-map.json'),
          'changed_files':[{'path':'src/bin/jobctl.rs','before_sha256':JOBCTL_BEFORE,'after_sha256':JOBCTL_AFTER}],
          'only_one_file_changed':True,'no_added_or_deleted_source_files':True,
          'jobs_rs_sha256':JOBS_BASELINE,'r16_profile_candidate_included':False,'r17_lazy_request_candidate_included':False,
          'baseline_binding_sha256':sha(ROOT/'baseline-binding.json'),'source_review_sha256':sha(ROOT/'source-review.json'),
          'selection_decision_sha256':sha(ROOT/'selection-decision.json'),'protected_artifacts_before_sha256':sha(ROOT/'protected-artifacts-before.json'),
          'qualification_started':False,'production_modified':False}
        write_json('source-freeze.json',freeze)
        ready=dict(freeze,schema='hepta-x230-r18-implementation-ready/v1',ready=True,
          source_freeze_sha256=sha(ROOT/'source-freeze.json'),automatic_retries=0)
        write_json('implementation-ready.json',ready)
        write_json('preparation-exit-01.json',{'created_utc':now(),'phase':'ready','exit_code':0,
          'elapsed_seconds':time.monotonic()-started,'script_sha256':sha(ROOT/'prepare-and-qualify.py'),'automatic_retries':0})
        print('R18_READY '+json.dumps({'source_files':281,'compile_inputs':219,'changed_files':delta,
          'ready_sha256':sha(ROOT/'implementation-ready.json'),'source_map_sha256':sha(ROOT/'source-map.json'),
          'jobs_rs_sha256':candidate_inputs['src/mcp/runtime/jobs.rs'],'jobctl_sha256':JOBCTL_AFTER}),flush=True)
        phase='launch-qualification'
        argv=['/usr/bin/python3','-B','-u',str(SOURCE/'tools/x230/20261028/qualify.py'),
          '--source',str(SOURCE),'--output',str(ROOT/'qualification-01'),'--target',str(R16/'target'),
          '--cargo-home','/home/qian/hepta-runtime-optimization-20261023/cargo-home-a32-a33-r02','--jobs','2','--stage-timeout','3600']
        env=dict(os.environ)
        prefixes=('CARGO_','RUST_','MALLOC_','GLIBC_','HEPTA_','SSH_')
        exact={'RUSTFLAGS','RUSTDOCFLAGS','CARGO_ENCODED_RUSTFLAGS','RUSTC_WRAPPER','RUSTC_WORKSPACE_WRAPPER','PYTHONPATH','PYTHONHOME','RUST_LOG'}
        removed=sorted(k for k in env if k.startswith(prefixes) or k in exact)
        for k in removed:env.pop(k,None)
        env['PYTHONDONTWRITEBYTECODE']='1'
        env['PATH']='/home/qian/.cargo/bin:/usr/local/bin:/usr/bin:/bin'
        launch={'schema':'hepta-x230-r18-qualification-launch/v1','created_utc':now(),'argv':argv,'cwd':str(SOURCE),
          'cleared_environment_key_names':removed,'clear_environment_prefixes':list(prefixes),'clear_environment_exact_names':sorted(exact),
          'explicit_environment':{'PYTHONDONTWRITEBYTECODE':'1','PATH':env['PATH']},
          'implementation_ready_sha256':sha(ROOT/'implementation-ready.json'),'qualifier_sha256':sha(SOURCE/'tools/x230/20261028/qualify.py'),
          'cargo_target_role':'mutable cache only; all R14/R16/R17 qualified release binaries are separately preserved',
          'automatic_stage_retries':0,'all_qualifier_stdout_stderr':'inherited by the durable job; each qualifier stage also preserves its original stdout/stderr in qualification-01'}
        need(launch['qualifier_sha256']=='95717717fd5421f2e31dbce24e2f8821696f57d779ce93e988ed66764159552d','qualifier differs from original qualified tool')
        write_json('qualification-launch-01.json',launch)
        print('R18_QUALIFICATION_STARTED '+json.dumps({'jobs':2,'cache':str(R16/'target'),'automatic_retries':0}),flush=True)
        qstarted=time.monotonic()
        process=subprocess.run(argv,cwd=SOURCE,env=env,check=False)
        exit_record={'schema':'hepta-x230-r18-qualification-exit/v1','finished_utc':now(),'returncode':process.returncode,
          'elapsed_seconds':time.monotonic()-qstarted,'automatic_retries':0}
        write_json('qualification-exit-01.json',exit_record)
        print('R18_QUALIFICATION_EXIT '+str(process.returncode),flush=True)
        return process.returncode
    except BaseException as error:
        failure={'schema':'hepta-x230-r18-preparation-failure/v1','phase':phase,'created_utc':now(),
          'error':type(error).__name__+': '+str(error),'elapsed_seconds':time.monotonic()-started,'automatic_retries':0}
        if created:
            try:write_json('preparation-failure.json',failure)
            except Exception:pass
            try:
                with (ROOT/'preparation-failure.stderr').open('x') as f:traceback.print_exc(file=f)
            except Exception:pass
        print('R18_FAILURE '+json.dumps(failure),file=sys.stderr,flush=True)
        return 1
if __name__=='__main__':
    raise SystemExit(main())
