# R17 isolated candidate source review

R17 starts from the exact qualified R14 source, bound by qualification-01/report.json (source_input == source_tested == source_after, 219 compiler inputs), and the R16 baseline-binding source_inputs. The 281-file export copy is separately verified; it includes repository/document/tool files outside the 219-input compilation set.

Git parent for the planned R17 change is PR87 head a784b92df7c84e6047343b436222716eb4b532d6, supplied by the root agent from its repository review. Parent root tree is f85e12bd92eb03df9e4352c115bd8d29dc13069e; parent src tree is 8e661044ad247eefee20e973a9c27c104da22e31. The R14 historical compiler-tree report independently binds that src tree and the 219 compiler files; its older candidate root tree ffe6d4757c7b274cf5f671d28f8936d2a8adfff3 is deliberately not mislabeled as the PR87 root tree. This exported source has no newly created git commit.

## Changes reviewed

1. src/bin/jobctl.rs: json_file keeps the existing regular-file and metadata size checks, open flags, INPUT_MAX+1 Take, and serde_json from_reader. Only an 8192-byte BufReader is inserted outside Take. This is the exact reviewed/probed patch; helper record/policy/capture-witness paths benefit from fewer small underlying File reads. All downstream job, nonce, boot, invocation, witness and finalization logic is unchanged.

2. src/mcp/runtime/jobs.rs: read_job moves the identical legacy Python request Value expression from before route selection into the direct legacy Python branch that alone consumes it. Pool/native, pool/Python and direct/native retain their original request construction. The original host/config check, request defaults, offset/limit/clamp, request_digest, full observation verification and completion audit order remain unchanged. On the legacy branch the Value can now drop after its awaited call and before audit; no protocol value or custody changes.

No dependencies, manifest/release flags, schemas, permits, cache policy, pin hashing, owner checks, SSH lifecycle, cancellation, replay or durability contracts change. R16's profile preprocessing and buffer reuse candidate is not included: both profile files remain exactly at R14 hashes, and the full export differs from R14 in only the two files above.

## Qualification scope

This preparation applies two reviewed patches and runs cargo fmt --all -- --check with the installed Rust 1.95.0 toolchain. It does not build, test, run clippy, run a benchmark, deploy a service/helper, or touch the mutable R16 Cargo cache or any retained qualification binary. The full qualification remains a separate next step.

No mirror-implementation tests are added for the pure Value move. The jobctl buffer candidate's independent probe has already passed per the root/author report; its bound report and summary hashes are recorded in source-freeze.json. Existing jobctl suites and the whole qualification still have to pass for the actual composed R17 artifact.

The two changes affect different CPU domains. Do not convert component read-count/CPU reduction or removed allocations into an asserted end-to-end throughput gain. Later reporting should distinguish controller/helper and native/Python and status/read paths.

## Local instructions

AGENTS.md was read before modifications. No commit/staging, dependency addition, copyright-header edit, tool-schema change or asynchronous filesystem operation was introduced. Referenced .agents/architecture.md and .agents/tool-authoring.md are absent in this export. The explicit parent instruction authorizes this isolated X230 preparation and defers builds/tests until the controlled qualification window; no remote dev-server work or compilation is launched.

## Evidence

baseline-source-map.json: authoritative 219 baseline hashes.
baseline-full-tree-map.json: exact 281 copied file hashes.
source-map.json: exact 219 frozen candidate hashes.
source-full-map.json: all 281 candidate hashes.
review/source-diff.patch: combined actual source delta.
patches/: byte-for-byte copies of the two reviewed patches.
format-check.json and format-check.log: formatting command and exit.
source-freeze.json and implementation-ready.json: source, patch, parent, probe and preparation identities.
