import collections, hashlib, json
from pathlib import Path

R17=Path('/home/qian/hepta-runtime-optimization-20261104-r17')
R16=Path('/home/qian/hepta-runtime-optimization-20261104-r16')
Q=R17/'qualification-01'
def sha(p):
    h=hashlib.sha256()
    with Path(p).open('rb') as f:
        for b in iter(lambda:f.read(1<<20),b''): h.update(b)
    return h.hexdigest()
def data(p): return json.loads(Path(p).read_text())
def inputs(source):
    files=[source/x for x in ('Cargo.toml','Cargo.lock','rustfmt.toml')]
    for directory in ('src','examples'): files.extend(p for p in (source/directory).rglob('*') if p.is_file())
    return {str(p.relative_to(source)):sha(p) for p in sorted(files) if p.is_file()}
def canonical(value):
    return hashlib.sha256(json.dumps(value,sort_keys=True,separators=(',',':')).encode()).hexdigest()
report=data(Q/'report.json')
freeze=data(R17/'source-freeze.json')
binding=data(R17/'baseline-binding.json')
source=inputs(R17/'source')
baseline=binding['baseline_source_inputs']
delta=[{'path':p,'before_sha256':baseline.get(p),'after_sha256':source.get(p)} for p in sorted(set(baseline)|set(source)) if baseline.get(p)!=source.get(p)]
r14=data(binding['baseline_qualification_report'])
probe_path=R16/'diagnostics/jobctl-buffer-probe-01/attempt-01/report.json'
probe=data(probe_path)
r16_path=R16/'qualification-01/report.json'
r16=data(r16_path)
summary=data(Q/'isolated-tests/summary.json')
audit=data(Q/'isolated-tests.audit.json')
rows=[json.loads(line) for line in (Q/'isolated-tests/tests.jsonl').read_text().splitlines() if line.strip()]
counts=dict(collections.Counter(row.get('status') for row in rows))
def binaries(r):
    result={}
    for name,value in r['binaries'].items():
        actual=sha(value['path'])
        result[name]={'path':value['path'],'expected_sha256':value['sha256'],'actual_sha256':actual,'matches':actual==value['sha256']}
    return result
b17=binaries(report)
b16=binaries(r16)
checks={
 'qualified':report.get('qualified') is True,
 'all_stages_exit_zero':all(s.get('returncode')==0 for s in report.get('stages',[])),
 'stages_complete':[s['name'] for s in report.get('stages',[])]==['format','fmt-check','harness-tests','clippy','test-build','isolated-tests','audit-isolated-tests','release'],
 '219_inputs':len(source)==219,
 'source_freeze_preserved':sha(R17/'source-freeze.json')=='5fc473e65ac9d278f88f844a3b6e25e44c7462c079efa93ecccab4fe8770f4c2',
 'baseline_binding_preserved':sha(R17/'baseline-binding.json')=='9d084886f4978e61ce8f718b210fd4539e8f49afad9ededfa10fc07ae397eaa9',
 'source_unchanged':all(report.get(k)==source for k in ('source_input','source_tested','source_after')),
 'source_map_file_matches':data(R17/'source-map.json')==source and data(Q/'source-map.json')==source,
 'source_freeze_canonical_matches':canonical(source)==freeze['source_canonical_map_sha256'],
 'only_two_expected_changes':[r['path'] for r in delta]==['src/bin/jobctl.rs','src/mcp/runtime/jobs.rs'],
 'delta_matches_freeze':delta==freeze['changed_files'],
 'baseline_report_preserved':sha(binding['baseline_qualification_report'])==binding['baseline_qualification_sha256'],
 'baseline_map_matches_qualified':baseline==r14['source_after'],
 'r16_probe_report_preserved':sha(probe_path)=='77559a9962dd9d6cff28e4f76f1382f77aaa19a62f3f07a05c2ce630381cf0e8',
 'r16_report_preserved':sha(r16_path)==probe['qualified_report_sha256']=='a284512d70ebe5be84b65d510d196affdba2fe962ee9d5837af3aa9cf489f923',
 'r16_release_preserved':len(b16)==3 and all(v['matches'] for v in b16.values()),
 'r17_release_matches':len(b17)==3 and all(v['matches'] for v in b17.values()),
 'test_summary_success':summary.get('success') is True,
 'audit_success':audit.get('success') is True,
 'audit_counts_match_summary':all(audit.get(k)==summary.get(k) for k in ('passed','failed','ignored','selected')),
 'auditor_identity_matches':audit.get('auditor_sha256')==report.get('harness_before',{}).get('audit_isolated_tests.py'),
 'no_test_failures':summary.get('failed')==0 and not summary.get('enumeration_errors') and not summary.get('fatal_error'),
 'test_rows_match_summary':all(counts.get(k,0)==summary.get(k) for k in ('passed','failed','ignored')) and len(rows)==summary.get('selected'),
 'unique_test_rows':len({(r.get('binary'),r.get('name')) for r in rows})==len(rows),
 'no_test_retries':all(r.get('attempt')==(0 if r.get('status')=='ignored' else 1) for r in rows),
 'test_execution_flags':all(r.get('executed')==(r.get('status')!='ignored') for r in rows),
 'harness_unchanged':report.get('harness_before')==report.get('harness_after')=={p.name:sha(p) for p in sorted((R17/'source/tools/x230/20261028').glob('*.py'))},
}
result={'schema':'hepta-r17-qualification-independent-verification/v1','success':all(checks.values()),'checks':checks,
'report_path':str(Q/'report.json'),'report_sha256':sha(Q/'report.json'),
'source_input_count':len(source),'source_canonical_map_sha256':canonical(source),'changes':delta,
'stages':[{k:s.get(k) for k in ('name','returncode','seconds')} for s in report['stages']],
'tests':{k:summary.get(k) for k in ('passed','failed','ignored','selected','success','elapsed_seconds','enumeration_errors','fatal_error')},
'test_rows_counted':counts,'test_binary_count':len(summary.get('binaries',[])),
'isolated_audit':{k:v for k,v in audit.items() if not isinstance(v,(dict,list))},
'isolated_audit_sha256':sha(Q/'isolated-tests.audit.json'),'binaries':b17,'r16_binaries':b16,
'r16_report_sha256':sha(r16_path),'baseline_report_sha256':sha(binding['baseline_qualification_report']),
'artifact_hashes':{str(p.relative_to(Q)):sha(p) for p in [Q/'source-map.json',Q/'cargo-no-run.jsonl',Q/'retained-artifacts.jsonl',Q/'isolated-tests/summary.json',Q/'isolated-tests/tests.jsonl']}}
print(json.dumps(result,sort_keys=True))
raise SystemExit(0 if result['success'] else 1)

