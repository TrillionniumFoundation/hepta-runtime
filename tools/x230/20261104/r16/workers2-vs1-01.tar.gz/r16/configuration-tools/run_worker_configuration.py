#!/usr/bin/env python3
# Copyright 2026 TrillionniumFoundation; SPDX-License-Identifier: Apache-2.0
"""Same-binary, arena1, workers2 versus workers1/4 ABBA using frozen R16 code.

Only two Python extension points are used: a Controller subclass changes its
workers constructor argument and adds a live environment receipt; the original
report writer adds the configuration identity. Every frozen measurement,
preflight, restart, raw capture, cleanup and zero-retry check still executes.
"""
import argparse
import hashlib
import importlib
import json
from pathlib import Path
import re
import sys
import time

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
DEFAULT_HARNESS = HERE.parent / "measurement-tools"
SCHEMA = "hepta-x230-tokio-workers-abba/v1"
LIVE_SCHEMA = "hepta-x230-live-worker-environment/v1"
SOURCE_NAMES = ("run_worker_configuration.py", "verify_worker_configuration.py",
                "test_worker_configuration.py", "harness-freeze.json")


def need(value, reason):
    if not value:
        raise ValueError(reason)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def canonical(value):
    return (json.dumps(value, sort_keys=True, separators=(",", ":")) + "\n").encode()


def source_hashes():
    return {name: sha((HERE / name).read_bytes()) for name in SOURCE_NAMES}


def frozen_hashes(root):
    freeze = json.loads((HERE / "harness-freeze.json").read_bytes())
    need(freeze["schema"] == "hepta-r16-configuration-harness-freeze/v1"
         and len(freeze["files"]) == 12, "frozen harness manifest differs")
    actual = {name: sha((root / name).read_bytes()) for name in freeze["files"]}
    need(actual == freeze["files"], "a frozen measurement script changed")
    return actual


def load_frozen(root):
    root = root.resolve()
    frozen_hashes(root)
    sys.path.insert(0, str(root))
    wrapper = importlib.import_module("run_native_observation")
    bench = importlib.import_module("x230_observation_benchmark")
    for module in (wrapper, bench):
        need(Path(module.__file__).resolve().parent == root, "imported another harness directory")
    return wrapper, bench


def select_environment(raw):
    """Retain exact selected NUL-delimited entries; never retain the whole env."""
    need(raw.endswith(b"\0") and len(raw) <= 1024 * 1024, "child environment framing/bound differs")
    retained, values = [], {}
    for entry in raw.split(b"\0"):
        if not entry:
            continue
        key, separator, value = entry.partition(b"=")
        need(separator == b"=", "invalid child environment entry")
        if key == b"TOKIO_WORKER_THREADS" or key.startswith(b"MALLOC_") or key == b"GLIBC_TUNABLES":
            name = key.decode("ascii")
            need(name not in values, "duplicate selected child environment key")
            values[name] = value.decode("utf-8")
            retained.append(entry + b"\0")
    return b"".join(retained), values


def make_controller(bench, experiment):
    original = bench.Controller

    class ConfiguredController(original):
        def __init__(self, binary, config, profile, directory, workers,
                     path_prefix=None, file_pool=False, allocator_values=None):
            directory = Path(directory)
            match = re.fullmatch(r"round-([0-3])-([AB])", directory.parent.name)
            need(match is not None and directory.parent.parent == experiment["out"]
                 and directory.name in {"first", "restart"}, "controller is outside the declared ABBA layout")
            number, arm = int(match[1]), match[2]
            need(arm == "ABBA"[number] and workers == 2, "frozen driver arm/interface argument differs")
            need(Path(binary).absolute() == experiment["binary"], "configuration comparison changed executable")
            need(allocator_values == {"MALLOC_ARENA_MAX": "1"}, "configuration comparison changed allocator")
            need(path_prefix is None and file_pool is False, "configuration comparison changed transport options")
            requested = experiment["workers_by_arm"][arm]
            # The real frozen constructor writes this value into the child env.
            super().__init__(binary, config, profile, directory, requested,
                             path_prefix=path_prefix, file_pool=file_pool, allocator_values=allocator_values)
            try:
                before = bench.counters(self.child.pid)
                need(before["birth_ticks"] == self.birth, "child generation changed before environment observation")
                read_start = time.monotonic_ns()
                with Path(f"/proc/{self.child.pid}/environ").open("rb") as stream:
                    raw = stream.read(1024 * 1024 + 1)
                read_end = time.monotonic_ns()
                after = bench.counters(self.child.pid)
                need(after["birth_ticks"] == self.birth, "child generation changed during environment observation")
                selected, observed = select_environment(raw)
                expected = {"TOKIO_WORKER_THREADS": str(requested), "MALLOC_ARENA_MAX": "1"}
                need(observed == expected, "actual controller workers/allocator environment differs")
                bench.create_file(directory / "worker-environment.bin", selected)
                snapshot = {
                    "schema": LIVE_SCHEMA, "status": "verified", "pid": self.child.pid,
                    "birth_ticks": self.birth, "round": number, "arm": arm, "phase": directory.name,
                    "source": "same-PID/start-ticks /proc/PID/environ",
                    "observation_phase": "after-native-initialize-before-preflight",
                    "frozen_driver_workers_argument": workers,
                    "constructor_workers_argument": requested, "requested": expected, "observed": observed,
                    "full_environment_retained": False,
                    "selected_raw": {"file": "worker-environment.bin", "bytes": len(selected), "sha256": sha(selected)},
                    "read_start_monotonic_ns": read_start, "read_end_monotonic_ns": read_end,
                    "controller_before": before, "controller_after": after}
                encoded = canonical(snapshot)
                bench.create_file(directory / "worker-environment.json", encoded)
                self.startup["worker_configuration"] = {
                    "file": "worker-environment.json", "bytes": len(encoded), "sha256": sha(encoded),
                    "pid": self.child.pid, "birth_ticks": self.birth, "round": number, "arm": arm,
                    "phase": directory.name, "observed_workers": requested}
            except BaseException:
                self.close()
                raise

    return ConfiguredController


def attach_metadata(report, experiment):
    workers = experiment["workers_by_arm"]
    need(report.get("tokio_workers") in (2, workers), "unrecognized original workers field")
    # A scalar would misdescribe the experiment. The original driver argument
    # remains explicit as an interface placeholder, separate from live evidence.
    report["tokio_workers"] = dict(workers)
    same_sources = source_hashes() == experiment["source_hashes"]
    try:
        same_harness = frozen_hashes(experiment["harness_root"]) == experiment["frozen_hashes"]
    except (ValueError, OSError):
        same_harness = False
    configurations = {}
    for arm, count in workers.items():
        identity = {"binary_sha256": experiment["binary_sha256"],
                    "allocator_environment": {"MALLOC_ARENA_MAX": "1"}, "TOKIO_WORKER_THREADS": str(count)}
        configurations[arm] = {**identity, "configuration_fingerprint": sha(canonical(identity))}
    report["worker_configuration_experiment"] = {
        "schema": SCHEMA, "comparison_identity": "binary_sha256+allocator_environment+TOKIO_WORKER_THREADS",
        "same_binary_sha256": True, "binary_sha256": experiment["binary_sha256"],
        "workers_by_arm": dict(workers), "arena_max": 1, "configurations": configurations,
        "frozen_driver_workers_argument": 2,
        "frozen_driver_argument_role": "interface placeholder; Controller subclass passes the per-arm value",
        "live_environment_required_for_every_controller": True,
        "parent_environment_modified": False, "automatic_rpc_retries": 0,
        "source_sha256": experiment["source_hashes"], "sources_unchanged": same_sources,
        "frozen_harness_sha256": experiment["frozen_hashes"], "frozen_harness_unchanged": same_harness,
        "scope": "same qualified binary; warm completed-job observations; first and normal-restart controllers",
        "runtime_thread_count_claim": "selected startup environment is observed; internal Tokio thread count is not introspected"}
    if not (same_sources and same_harness):
        report["passed"] = False


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--binary", type=Path, required=True)
    parser.add_argument("--workers-b", type=int, choices=(1, 4), required=True)
    parser.add_argument("--profile-template", type=Path, required=True)
    parser.add_argument("--topology", type=Path, required=True)
    parser.add_argument("--frozen-jobs", type=Path, required=True)
    parser.add_argument("--socket-parent", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--calls", type=int, default=96)
    parser.add_argument("--concurrency", type=int, nargs="+", choices=(1, 4, 8, 16), default=(1, 8, 16))
    parser.add_argument("--warmup-calls", type=int, default=24)
    parser.add_argument("--harness-root", type=Path, default=DEFAULT_HARNESS)
    args = parser.parse_args()
    need(args.calls > 0 and args.calls % 12 == 0 and len(set(args.concurrency)) == len(args.concurrency),
         "invalid balanced measurement dimensions")
    need(12 <= args.warmup_calls <= 120 and args.warmup_calls % 12 == 0, "invalid balanced warmup")
    out = args.out.absolute()
    need(out.resolve() == out and out.is_relative_to(HERE.parent) and not out.exists(),
         "output must be a fresh direct path inside this R16 directory")
    harness = args.harness_root.resolve()
    wrapper, bench = load_frozen(harness)
    binary = args.binary.absolute()
    experiment = {"out": out, "binary": binary, "binary_sha256": sha(bench.read_file(binary, 128 * 1024 * 1024)),
                  "workers_by_arm": {"A": 2, "B": args.workers_b}, "harness_root": harness,
                  "frozen_hashes": frozen_hashes(harness), "source_hashes": source_hashes()}
    original_controller, original_cell, original_save = bench.Controller, bench.cell, bench.save_report
    original_wrapper_save, original_argv = wrapper.ORIGINAL_SAVE, sys.argv

    def save(path, report):
        attach_metadata(report, experiment)
        original_wrapper_save(path, report)

    bench.Controller = make_controller(bench, experiment)
    wrapper.ORIGINAL_SAVE = save
    sys.argv = [str(HERE / "run_worker_configuration.py"), "--baseline", str(binary), "--candidate", str(binary),
                "--arena-max", "1", "--profile-template", str(args.profile_template), "--topology", str(args.topology),
                "--frozen-jobs", str(args.frozen_jobs), "--socket-parent", str(args.socket_parent), "--out", str(out),
                "--calls", str(args.calls), "--concurrency", *map(str, args.concurrency),
                "--workers", "2", "--order", "ABBA", "--warmup-calls", str(args.warmup_calls)]
    try:
        return wrapper.main()
    finally:
        bench.Controller, bench.cell, bench.save_report = original_controller, original_cell, original_save
        wrapper.ORIGINAL_SAVE, sys.argv = original_wrapper_save, original_argv


if __name__ == "__main__":
    sys.exit(main())
