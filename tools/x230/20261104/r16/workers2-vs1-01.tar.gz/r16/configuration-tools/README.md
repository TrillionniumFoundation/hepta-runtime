# R16 workers configuration comparison

This directory extends the frozen `../measurement-tools` harness without editing
any of its 12 Python files. It compares one qualified executable with explicit
`MALLOC_ARENA_MAX=1` in both arms. A uses `TOKIO_WORKER_THREADS=2`; B uses 1 or 4.
The first and normal-restart controllers in all four ABBA rounds have their
selected live `/proc/PID/environ` bytes read after initialization, bracketed by
same-generation `/proc/PID/stat` observations. Only worker and allocator entries
are retained. The held SSH agent and full environment are not copied into these
receipts.

## Reproduce after source qualification and the source A/B experiment

Run on X230 inside the parent's held authenticated foreground SSH-agent session.
The output directory must not exist. The socket parent must already be a private,
account-owned, direct directory with mode 0700, as required by the frozen driver.
Replace the qualified binary path below with its exact retained qualification
artifact. The driver hashes the one binary and passes it as both original A/B
binary arguments; there is no binary arm selection in this experiment.

```sh
python3 -B /home/qian/hepta-runtime-optimization-20261104-r16/configuration-tools/run_worker_configuration.py \
  --binary /absolute/path/to/qualified/hepta-runtime \
  --workers-b 1 \
  --profile-template /home/qian/hepta-runtime-optimization-20261023/r11-native-observation-abba-20261103-02/profile/profile.json \
  --topology /home/qian/hepta-runtime-optimization-20261104-r16/benchmark-topology.json \
  --frozen-jobs /home/qian/hepta-runtime-optimization-20261023/a31-frozen-originals-r01 \
  --socket-parent /home/qian/h16w1 \
  --out /home/qian/hepta-runtime-optimization-20261104-r16/workers2-vs1-01 \
  --calls 96 --concurrency 1 8 16 --warmup-calls 24

python3 -B /home/qian/hepta-runtime-optimization-20261104-r16/configuration-tools/verify_worker_configuration.py \
  --report /home/qian/hepta-runtime-optimization-20261104-r16/workers2-vs1-01/report.json \
  --output /home/qian/hepta-runtime-optimization-20261104-r16/workers2-vs1-01/independent-configuration-analysis.json
```

For the separately authorized upper configuration comparison, use `--workers-b
4`, a fresh socket parent and output directory. `--concurrency 8 16` is also
supported. Calls and warmups remain balanced multiples of 12. C32 is deliberately
excluded: the current native observation pool admits 16 logical requests and
uses global8/per-host2 execution capacity; overload/refusal is a separate test.
There are zero automatic RPC retries, and all calls must succeed for acceptance.

## Meaning of the fields and the audit

The frozen driver's `--workers 2` argument is an interface placeholder. The new
Controller subclass actually passes the arm's selected worker count to the
unchanged constructor that creates the child environment. The top-level report
`tokio_workers` is a map `{"A": 2, "B": 1}` or `{"A": 2, "B": 4}`, with the
placeholder's role recorded separately. Configuration fingerprints include the
worker count, binary hash and allocator environment. A scalar report field,
missing/relabelled controller receipt, mismatched raw environment or changed
frozen source is rejected.

The independent verifier does not import the configuration launcher. It reads
the selected raw bytes, recomputes their hashes, validates PID/start-time and
clock bindings for all eight controller generations, then calls the unchanged
native analyzer. The latter still requires exact transport frames, raw monotonic
clocks, synchronous controller CPU deltas, sampled resource traces, allocator
observations, topology, balanced operations, original registries, normal restart,
no retries and full success. Configuration validation never replaces that gate.
The selected startup environment is observed; internal Tokio thread count is
not introspected. Measurements remain finite warm observation throughput on six
historically routed entities, not new-job execution throughput or cluster CPU.

## Lightweight validation only

```sh
python3 -B /home/qian/hepta-runtime-optimization-20261104-r16/configuration-tools/test_worker_configuration.py
```

These tests start only a Python fake MCP peer, initialize it and close it. They
do not connect SSH, run a HeptaRuntime binary or send workload calls. They check
actual worker1/2/4 child environment selection, all first/restart bindings,
parent environment isolation, raw-byte tamper rejection and the mandatory frozen
native audit. Environments that block child `/proc/environ` report an explicit
skip; only an X230 run with zero skips is accepted as preparation validation.
