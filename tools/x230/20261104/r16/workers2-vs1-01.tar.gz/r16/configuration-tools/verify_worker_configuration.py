#!/usr/bin/env python3
# Copyright 2026 TrillionniumFoundation; SPDX-License-Identifier: Apache-2.0
"""Audit configuration evidence independently, then run the frozen raw-data audit.

This verifier does not import the configuration launcher or trust its parsed
environment claims. It rehashes selected raw /proc environment bytes, checks
PID/start-ticks and clock brackets, and binds all eight live observations to the
declared ABBA arm, including every normal restart.
"""
import argparse
import gzip
import hashlib
import importlib
import json
from pathlib import Path
import sys

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
SOURCE_NAMES = {"run_worker_configuration.py", "verify_worker_configuration.py",
                "test_worker_configuration.py", "harness-freeze.json"}


def need(value, reason):
    if not value:
        raise ValueError(reason)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def encoded(value):
    return (json.dumps(value, sort_keys=True, separators=(",", ":")) + "\n").encode()


def freeze(root):
    value = json.loads((HERE / "harness-freeze.json").read_bytes())
    need(value["schema"] == "hepta-r16-configuration-harness-freeze/v1" and len(value["files"]) == 12,
         "frozen harness identity missing")
    observed = {name: sha((root / name).read_bytes()) for name in value["files"]}
    need(observed == value["files"], "frozen harness source hash changed")
    return observed


def selected_raw(directory, entry):
    need(entry["file"] == "worker-environment.bin", "unexpected environment filename")
    raw = (directory / entry["file"]).read_bytes()
    need(len(raw) == entry["bytes"] <= 4096 and sha(raw) == entry["sha256"], "selected environment byte hash differs")
    need(raw.endswith(b"\0"), "selected environment framing differs")
    values = {}
    for item in raw[:-1].split(b"\0"):
        key, separator, value = item.partition(b"=")
        need(separator == b"=" and key in {b"TOKIO_WORKER_THREADS", b"MALLOC_ARENA_MAX"},
             "unexpected selected environment key")
        key = key.decode("ascii")
        need(key not in values, "duplicate selected environment key")
        values[key] = value.decode("ascii")
    need(set(values) == {"TOKIO_WORKER_THREADS", "MALLOC_ARENA_MAX"}, "selected environment key missing")
    return values


def identity(snapshot, pid, birth):
    raw = snapshot["raw_stat"]
    prefix, fields = raw.rsplit(") ", 1)
    fields = fields.split()
    need(int(prefix.split(" (", 1)[0]) == pid and fields[0] not in {"Z", "X"}
         and int(fields[19]) == birth == snapshot["birth_ticks"] and snapshot["pid"] == pid,
         "live /proc stat PID generation differs")
    need(snapshot["read_start_monotonic_ns"] <= snapshot["read_end_monotonic_ns"], "stat clock bracket differs")


def audit_configuration(report, directory, harness_root):
    meta = report["worker_configuration_experiment"]
    need(meta["schema"] == "hepta-x230-tokio-workers-abba/v1"
         and meta["comparison_identity"] == "binary_sha256+allocator_environment+TOKIO_WORKER_THREADS",
         "configuration experiment schema differs")
    workers = meta["workers_by_arm"]
    need(workers in ({"A": 2, "B": 1}, {"A": 2, "B": 4}) and report["tokio_workers"] == workers,
         "per-arm workers identity differs")
    need(report["order"] == "ABBA" and len(report["rounds"]) == 4, "configuration ABBA incomplete")
    need(meta["same_binary_sha256"] is True and set(report["binary_sha256"]) == {"A", "B"}
         and set(report["binary_sha256"].values()) == {meta["binary_sha256"]}, "binary changed across configurations")
    need(meta["arena_max"] == 1 and meta["frozen_driver_workers_argument"] == 2
         and meta["frozen_driver_argument_role"] == "interface placeholder; Controller subclass passes the per-arm value"
         and meta["live_environment_required_for_every_controller"] is True
         and meta["parent_environment_modified"] is False
         and meta["automatic_rpc_retries"] == report["automatic_rpc_retries"] == 0,
         "configuration isolation/retry contract differs")
    expected_sources = {name: sha((HERE / name).read_bytes()) for name in SOURCE_NAMES}
    need(meta["source_sha256"] == expected_sources and meta["sources_unchanged"] is True,
         "configuration source identity changed")
    need(meta["frozen_harness_unchanged"] is True and meta["frozen_harness_sha256"] == freeze(harness_root),
         "frozen harness provenance differs")
    need(set(meta["configurations"]) == {"A", "B"}, "configuration labels differ")
    for arm in "AB":
        expected = {"binary_sha256": meta["binary_sha256"], "allocator_environment": {"MALLOC_ARENA_MAX": "1"},
                    "TOKIO_WORKER_THREADS": str(workers[arm])}
        need(meta["configurations"][arm] == {**expected, "configuration_fingerprint": sha(encoded(expected))},
             "worker-aware configuration fingerprint differs")
        need(report["allocator_configuration"]["variants"][arm]["environment"] == {"MALLOC_ARENA_MAX": "1"},
             "allocator differs between configurations")
    receipts = []
    for number, round_ in enumerate(report["rounds"]):
        arm = "ABBA"[number]
        need(round_["version"] == arm and round_["index"] == number, "configuration round order differs")
        for phase, startup_key, rows_key in (("first", "startup", "initial_complete_outputs"),
                                             ("restart", "restart_startup", "restart_checks")):
            startup = round_[startup_key]
            receipt = startup["worker_configuration"]
            folder = directory / f"round-{number}-{arm}" / phase
            need(receipt["file"] == "worker-environment.json", "unexpected live receipt filename")
            raw = (folder / receipt["file"]).read_bytes()
            need(len(raw) == receipt["bytes"] and sha(raw) == receipt["sha256"], "live environment receipt hash differs")
            value = json.loads(raw)
            pid, birth = startup["pid"], startup["birth_ticks"]
            for record in (receipt, value):
                need(record["pid"] == pid and record["birth_ticks"] == birth and record["round"] == number
                     and record["arm"] == arm and record["phase"] == phase, "environment arm/process binding differs")
            need(value["schema"] == "hepta-x230-live-worker-environment/v1" and value["status"] == "verified"
                 and value["source"] == "same-PID/start-ticks /proc/PID/environ"
                 and value["observation_phase"] == "after-native-initialize-before-preflight"
                 and value["full_environment_retained"] is False, "live environment observation contract differs")
            observed = selected_raw(folder, value["selected_raw"])
            expected = {"TOKIO_WORKER_THREADS": str(workers[arm]), "MALLOC_ARENA_MAX": "1"}
            need(observed == value["observed"] == value["requested"] == expected,
                 "raw child worker environment differs from declared arm")
            need(value["frozen_driver_workers_argument"] == 2
                 and value["constructor_workers_argument"] == receipt["observed_workers"] == workers[arm],
                 "constructor/live workers differ")
            before, after = value["controller_before"], value["controller_after"]
            identity(before, pid, birth)
            identity(after, pid, birth)
            need(startup["ready_monotonic_ns"] <= before["read_start_monotonic_ns"]
                 and before["read_end_monotonic_ns"] <= value["read_start_monotonic_ns"]
                 <= value["read_end_monotonic_ns"] <= after["read_start_monotonic_ns"]
                 and after["read_end_monotonic_ns"] <= min(r["start_monotonic_ns"] for r in round_[rows_key]),
                 "live worker observation is outside initialization/preflight clock brackets")
            receipts.append({"round": number, "arm": arm, "phase": phase, "pid": pid, "birth_ticks": birth,
                             "workers": workers[arm], "receipt_sha256": sha(raw), "selected_raw_sha256": value["selected_raw"]["sha256"]})
    need(len(receipts) == 8 and len({(r["pid"], r["birth_ticks"]) for r in receipts}) == 8,
         "eight distinct first/restart controller generations were not observed")
    return {"verified": True, "controllers_with_live_workers": len(receipts), "workers_by_arm": workers,
            "binary_sha256": meta["binary_sha256"], "allocator_environment": {"MALLOC_ARENA_MAX": "1"},
            "receipts": receipts, "limitations": ["Actual selected startup environment was read for every controller.",
                "Internal Tokio thread count is not introspected; this is a startup-configuration comparison.",
                "Same frozen raw-data/zero-retry audit is required separately and cannot be replaced by this check."]}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--report", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--harness-root", type=Path, default=HERE.parent / "measurement-tools")
    args = parser.parse_args()
    raw = args.report.read_bytes()
    if args.report.suffix == ".gz":
        raw = gzip.decompress(raw)
    root = args.harness_root.resolve()
    report = json.loads(raw)
    configuration = audit_configuration(report, args.report.parent, root)
    sys.path.insert(0, str(root))
    standard = importlib.import_module("analyze_native_observation")
    need(Path(standard.__file__).resolve().parent == root, "imported another native auditor")
    original = standard.analyze(raw, args.report.parent)
    need(original["verified"] is True, "frozen native audit failed")
    result = {"schema": "hepta-x230-workers-independent-analysis/v1", "verified": True,
              "configuration_verification": configuration, "native_analysis": original}
    with args.output.open("x") as stream:
        json.dump(result, stream, indent=2)
        stream.write("\n")
    print(json.dumps({"verified": True, "workers_by_arm": configuration["workers_by_arm"],
                      "controllers_with_live_workers": configuration["controllers_with_live_workers"],
                      "measured_calls": original["measured_calls"], "total_calls": original["total_calls"]}))


if __name__ == "__main__":
    main()
