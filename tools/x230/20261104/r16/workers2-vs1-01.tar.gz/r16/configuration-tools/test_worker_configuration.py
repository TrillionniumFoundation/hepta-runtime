#!/usr/bin/env python3
# Copyright 2026 TrillionniumFoundation; SPDX-License-Identifier: Apache-2.0
"""Pure-Python fake-MCP tests: no SSH and no HeptaRuntime process or workload."""
import argparse
import copy
import json
import os
from pathlib import Path
import sys
import tempfile
import time
import types
import unittest
from unittest import mock

sys.dont_write_bytecode = True
import run_worker_configuration as launcher
import verify_worker_configuration as verifier

HARNESS = launcher.DEFAULT_HARNESS


class ConfigurationTests(unittest.TestCase):
    live_observations_verified = 0

    @classmethod
    def setUpClass(cls):
        cls.wrapper, cls.bench = launcher.load_frozen(HARNESS)
        from test_native_harness import FAKE
        cls.fake = FAKE

    def test_selected_environment_strictness_and_no_secret_retention(self):
        raw = b"UNRELATED_SECRET=do-not-retain\0TOKIO_WORKER_THREADS=1\0MALLOC_ARENA_MAX=1\0SSH_AUTH_SOCK=/private/test\0"
        selected, values = launcher.select_environment(raw)
        self.assertEqual(selected, b"TOKIO_WORKER_THREADS=1\0MALLOC_ARENA_MAX=1\0")
        self.assertEqual(values, {"TOKIO_WORKER_THREADS": "1", "MALLOC_ARENA_MAX": "1"})
        self.assertNotIn(b"SECRET", selected)
        for invalid in (raw[:-1], raw + b"TOKIO_WORKER_THREADS=4\0", b"broken-entry\0"):
            with self.assertRaises(ValueError):
                launcher.select_environment(invalid)

    def setup_experiment(self, root, alternative):
        binary = root / "fake-mcp"
        binary.write_text(self.fake)
        binary.chmod(0o700)
        return {"out": root, "binary": binary, "binary_sha256": launcher.sha(binary.read_bytes()),
                "workers_by_arm": {"A": 2, "B": alternative}, "harness_root": HARNESS,
                "frozen_hashes": launcher.frozen_hashes(HARNESS), "source_hashes": launcher.source_hashes()}

    def test_first_and_restart_live_environments_and_independent_rejection(self):
        for alternative in (1, 4):
            with tempfile.TemporaryDirectory() as temporary, \
                 mock.patch.dict(os.environ, {"SSH_AUTH_SOCK": "/fake-selftest-unused-agent", "TOKIO_WORKER_THREADS": "99",
                                              "MALLOC_ARENA_MAX": "4", "GLIBC_TUNABLES": "unused-parent-value"}):
                before_env = dict(os.environ)
                root = Path(temporary)
                experiment = self.setup_experiment(root, alternative)
                controller_type = launcher.make_controller(self.bench, experiment)
                report = {"order": "ABBA", "tokio_workers": 2, "passed": False, "automatic_rpc_retries": 0,
                          "binary_sha256": {arm: experiment["binary_sha256"] for arm in "AB"},
                          "allocator_configuration": {"variants": {arm: {"environment": {"MALLOC_ARENA_MAX": "1"}} for arm in "AB"}},
                          "rounds": []}
                for number, arm in enumerate("ABBA"):
                    row = {"index": number, "version": arm}
                    report["rounds"].append(row)
                    for phase, key, rows_key in (("first", "startup", "initial_complete_outputs"),
                                                  ("restart", "restart_startup", "restart_checks")):
                        folder = root / f"round-{number}-{arm}" / phase
                        folder.mkdir(parents=True)
                        try:
                            controller = controller_type(experiment["binary"], root / "unused-config", root / "unused-profile",
                                                         folder, 2, allocator_values={"MALLOC_ARENA_MAX": "1"})
                        except PermissionError as error:
                            if error.errno == 13 and str(error.filename).endswith("/environ"):
                                self.skipTest("this executor denies child /proc/environ; run this unchanged test on X230")
                            raise
                        try:
                            row[key] = controller.startup
                            # These are synthetic clock fences for config-only tests,
                            # not workload rows and never passed off as native results.
                            row[rows_key] = [{"start_monotonic_ns": time.monotonic_ns()}]
                        finally:
                            shutdown = controller.close()
                        self.assertEqual(shutdown["exit_code"], 0)
                        self.assertIsNone(shutdown["reader_error"])
                launcher.attach_metadata(report, experiment)
                verified = verifier.audit_configuration(report, root, HARNESS)
                self.assertEqual(verified["controllers_with_live_workers"], 8)
                type(self).live_observations_verified += verified["controllers_with_live_workers"]
                self.assertEqual([r["workers"] for r in verified["receipts"]],
                                 [2, 2, alternative, alternative, alternative, alternative, 2, 2])
                self.assertEqual(dict(os.environ), before_env)
                self.assertEqual(launcher.frozen_hashes(HARNESS), experiment["frozen_hashes"])

                scalar = copy.deepcopy(report)
                scalar["tokio_workers"] = 2
                with self.assertRaisesRegex(ValueError, "per-arm"):
                    verifier.audit_configuration(scalar, root, HARNESS)

                # A valid config audit must still invoke the frozen full raw-data
                # gate. This synthetic config-only report is not a valid campaign.
                report_path, output = root / "report.json", root / "independent.json"
                report_path.write_text(json.dumps(report))
                fake_auditor = types.ModuleType("analyze_native_observation")
                fake_auditor.__file__ = str(HARNESS / "analyze_native_observation.py")
                fake_auditor.analyze = mock.Mock(side_effect=ValueError("sentinel-frozen-raw-gate"))
                with mock.patch.dict(sys.modules, {"analyze_native_observation": fake_auditor}), \
                     mock.patch.object(sys, "argv", ["verify", "--report", str(report_path), "--output", str(output),
                                                    "--harness-root", str(HARNESS)]):
                    with self.assertRaisesRegex(ValueError, "sentinel-frozen-raw-gate"):
                        verifier.main()
                fake_auditor.analyze.assert_called_once()
                self.assertFalse(output.exists())

                folder = root / "round-1-B/restart"
                receipt = report["rounds"][1]["restart_startup"]["worker_configuration"]
                snapshot_path = folder / receipt["file"]
                snapshot = json.loads(snapshot_path.read_bytes())
                env_path = folder / snapshot["selected_raw"]["file"]
                original = env_path.read_bytes()
                wrong = original.replace(f"TOKIO_WORKER_THREADS={alternative}".encode(), b"TOKIO_WORKER_THREADS=2")
                env_path.write_bytes(wrong)
                with self.assertRaisesRegex(ValueError, "byte hash"):
                    verifier.audit_configuration(report, root, HARNESS)
                # Even consistently rehashing altered raw bytes cannot turn the
                # wrong observed value into the declared configuration.
                snapshot["selected_raw"].update(bytes=len(wrong), sha256=launcher.sha(wrong))
                encoded = launcher.canonical(snapshot)
                snapshot_path.write_bytes(encoded)
                receipt.update(bytes=len(encoded), sha256=launcher.sha(encoded))
                with self.assertRaisesRegex(ValueError, "raw child worker environment"):
                    verifier.audit_configuration(report, root, HARNESS)

    def test_controller_extension_rejects_changed_scope_before_launch(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            experiment = self.setup_experiment(root, 1)
            controller_type = launcher.make_controller(self.bench, experiment)
            for folder, workers, allocator in ((root / "elsewhere/first", 2, {"MALLOC_ARENA_MAX": "1"}),
                                               (root / "round-0-A/first", 4, {"MALLOC_ARENA_MAX": "1"}),
                                               (root / "round-0-A/first", 2, {"MALLOC_ARENA_MAX": "4"})):
                with self.assertRaises(ValueError):
                    controller_type(experiment["binary"], root / "unused", root / "unused", folder, workers,
                                    allocator_values=allocator)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(add_help=False)
    parser.add_argument("--harness-root", type=Path, default=HARNESS)
    args, remaining = parser.parse_known_args()
    HARNESS = args.harness_root.resolve()
    program = unittest.main(argv=[sys.argv[0], *remaining], verbosity=2, exit=False)
    result = program.result
    print(json.dumps({"schema": "hepta-x230-workers-harness-selftest/v1", "tests_run": result.testsRun,
                      "failures": len(result.failures), "errors": len(result.errors), "skipped": len(result.skipped),
                      "live_controller_environments_verified": ConfigurationTests.live_observations_verified,
                      "success": result.wasSuccessful(), "accepted_preparation": result.wasSuccessful() and not result.skipped}))
    sys.exit(0 if result.wasSuccessful() else 1)
