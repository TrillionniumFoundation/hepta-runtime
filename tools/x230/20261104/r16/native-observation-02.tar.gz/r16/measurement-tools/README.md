# X230 R16 native observation harness

Derived from the five R15 native observation/allocator scripts. R15 evidence and
scripts remain unchanged. This measures read-only `process_status` and
`process_read` against six frozen alias records, with balanced warmup, ABBA fresh
controllers and normal controller restart. Alias meanings come from a required
frozen `--topology` manifest bound to the exact historical SSH profile. The
current Mac Controller's aliases must not be substituted for historical routes.
It does not measure successful launch/cancel throughput or cluster-wide CPU.

## R16 changes

- `--arena-max` defaults to 1 and is explicitly applied to **both** A and B.
  Parent allocator settings are cleared in children. Each initialized controller
  and restart retains the actual `/proc/PID/environ` allocator observation.
- Every fixture platform and machine group comes from the frozen preflight,
  including whether `main` addresses a Mac or a distinct Linux host.
- Each private controller stores exact stdout bytes in
  `transport-responses.jsonl`, including initialization and notifications, plus
  a contiguous byte-offset/hash index. Canonical JSON hashes are separately
  retained; they are not mislabeled as exact transport hashes.
- Each call stores integer monotonic start/end, send and receive/dequeue
  endpoints. Each cell stores the wall endpoints and raw `/proc/stat` counter
  reads (PID generation, user/system ticks, clock rate and read endpoints).
- `resource-samples.jsonl` separates the controller, observed local SSH
  descendants, other descendants, unknown executable classes and generations
  whose observed class changes. Selected status fields, FD numbers, raw stat
  lines and missing observations are retained. Argv and full environments are
  never retained.
- The analyzer independently rehashes transport/index/resource files, checks
  raw reply identity, status/output semantics and all frame references, and
  reconstructs latency, CPU deltas, sampled resource maxima and lifetime CPU
  classes from the raw traces. Changed bytes or dropped missing observations
  cause analysis to fail.

## Run

Use an authenticated forwarded agent held for the whole foreground command.
Socket existence alone is insufficient. The driver requires a bounded usable
key list and unchanged socket/agent identity. The output directory must not
exist. Precreate a short, account-owned, non-symlink socket directory with mode
0700, e.g. `/home/qian/h16n1`; never reuse an old run's socket directory.

```sh
python3 -B /home/qian/hepta-runtime-optimization-20261104-r16/measurement-tools/run_native_observation.py \
  --baseline /home/qian/hepta-runtime-optimization-20261103-r14/qualification-01/hepta-runtime \
  --candidate /absolute/path/to/qualified-r16/hepta-runtime \
  --arena-max 1 \
  --profile-template /home/qian/hepta-runtime-optimization-20261023/r11-native-observation-abba-20261103-02/profile/profile.json \
  --topology /absolute/path/to/frozen-profile-topology.json \
  --frozen-jobs /home/qian/hepta-runtime-optimization-20261023/a31-frozen-originals-r01 \
  --socket-parent /home/qian/h16n1 \
  --out /home/qian/hepta-runtime-optimization-20261104-r16/native-observation-01 \
  --calls 96 --concurrency 1 4 8 --workers 2 --order ABBA --warmup-calls 24

python3 -B /home/qian/hepta-runtime-optimization-20261104-r16/measurement-tools/analyze_native_observation.py \
  --report /home/qian/hepta-runtime-optimization-20261104-r16/native-observation-01/report.json \
  --output /home/qian/hepta-runtime-optimization-20261104-r16/native-observation-01/independent-summary.json
```

The profile generator rebinds the current held agent and copies verified SSH
configuration/known-hosts inputs. Existing frozen records are copied byte for
byte. No RPC retries, new remote jobs, effectful tools or service changes are
performed. An interrupted/failed campaign remains failed; use a new output
directory only for a separately declared new experiment.

The topology manifest has schema `hepta-x230-benchmark-topology/v1`, the exact
`profile_template_sha256`, and `hosts` containing all six aliases. Each host
declares `platform` (`linux` or `macos`) and a nonempty `machine_group`. Equal
groups mean the aliases address the same machine according to the caller's
fresh frozen preflight. The original manifest bytes are copied into the report
directory and checked unchanged at the end. Recovery independently compares
reported hostname equivalence and `sys.platform` against this manifest.

## Pure Python self-checks

```sh
cd /home/qian/hepta-runtime-optimization-20261104-r16/measurement-tools
python3 -B -m unittest -v test_native_harness.py
python3 -B -c 'import ast,pathlib; [ast.parse(p.read_text(),filename=str(p)) for p in pathlib.Path(".").glob("*.py")]'
```

These checks use a local fake MCP child and a synthetic `/proc` tree. They do
not invoke HeptaRuntime or SSH. They reject allocator mismatch, changed raw
transport bytes, altered timing/ticks/DTO hashes and misattributed process CPU.
The resource test verifies that an unreadable child FD directory does not
suppress its CPU/RSS and that a PID with a changed parent is excluded. The fake
MCP test explicitly skips if its executor disallows child `/proc/environ`; X230
validation should report zero skips.

## Measurement limits

Trace buffers are 64 KiB, with fsync at normal controller shutdown rather than
for every message. Capture and sampling wall overhead affects both arms, so old
R15-harness rates are not directly comparable. Harness CPU is outside controller
CPU. Synchronous controller CPU uses raw tick deltas; descendant CPU is sampled
partial lifetime accumulation and is diagnostic, with possible interval endpoint
error in either direction. A 100 ms sample can miss short-lived or reparented
children. RSS sums are not simultaneous and can double-count shared pages. All
missing metrics remain explicit; zero without observed samples is unavailable.

ABBA provides two fresh processes per arm. This is finite shared-host evidence,
not statistical significance or proof that all workloads have reached an optimum.

## Optional owned cancellation/recovery canary

`run_six_host_cancel_recovery.py` retains the R15 new private fixtures, original
idempotency keys, concurrent cancel, controller SIGKILL, normal restart, terminal
output/exit/witness comparisons and a second cancellation after exit. It does
not clean remote artifacts or retry an uncertain mutation. The only optional
SSH interruption is `--interrupt-host rog`; the existing helper requires a
live original private controller, direct-child ownership, pinned executable,
private control-socket peer and generation rechecks before a pidfd signal.
It cannot signal an arbitrary supplied PID or a shared SSH master.

Use the same profile-bound topology and held agent. The output must be a fresh
direct child of the R16 root. This command performs the declared **new private
jobs and their cancellation**; do not use it as a dry-run command:

```sh
python3 -B /home/qian/hepta-runtime-optimization-20261104-r16/measurement-tools/run_six_host_cancel_recovery.py \
  --candidate /absolute/path/to/qualified-r16/hepta-runtime --candidate-arena-max 1 \
  --profile-template /home/qian/hepta-runtime-optimization-20261023/r11-native-observation-abba-20261103-02/profile/profile.json \
  --topology /absolute/path/to/frozen-profile-topology.json \
  --frozen-jobs /home/qian/hepta-runtime-optimization-20261023/a31-frozen-originals-r01 \
  --socket-parent /home/qian/h16c1 \
  --out /home/qian/hepta-runtime-optimization-20261104-r16/cancel-recovery-01 \
  --workers 2 --interrupt-host rog

python3 -B /home/qian/hepta-runtime-optimization-20261104-r16/measurement-tools/verify_cancel_recovery.py \
  --report /home/qian/hepta-runtime-optimization-20261104-r16/cancel-recovery-01/report.json \
  --output /home/qian/hepta-runtime-optimization-20261104-r16/cancel-recovery-01/independent-summary.json
```

The verifier also rehashes the exact controller transport, canonical native
responses, independent SSH stdout/stderr and resource traces. It binds reported
effect results and final statuses back to their raw native responses. The helper
`x230_six_running_recovery_canary.py` remains the source of the unchanged bounded
child workload, descriptor-pinned fixture operations and private SSH wrapper.
Its platform check now comes from the explicit manifest; no host aliases are
reassigned and no production protocol or service is changed.
