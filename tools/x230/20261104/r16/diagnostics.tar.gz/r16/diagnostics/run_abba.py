#!/usr/bin/env python3
"""ABBA public-file full-content SHA256 diagnostic. No HeptaRuntime traffic."""
from pathlib import Path
import hashlib,json,math,os,platform,statistics,subprocess,time
ROOT=Path(__file__).resolve().parent
BIN=ROOT/'target/release/hepta-pin-buffer-diagnostic'
ITERATIONS=200
ROUNDS=4
PAIRS=[(16384,65536),(65536,262144)]
PUBLIC=('/usr/bin/ssh','/usr/bin/false','/bin/sh')
def signature(path):
    p=Path(path).resolve(strict=True)
    st=p.stat()
    content=p.read_bytes()
    after=p.stat()
    fields=('st_dev','st_ino','st_mode','st_size','st_mtime_ns','st_ctime_ns')
    before={k:getattr(st,k) for k in fields}
    if before!={k:getattr(after,k) for k in fields} or len(content)!=st.st_size:raise RuntimeError('public file changed during reference hash')
    return {'requested_path':path,'resolved_path':str(p),'sha256':hashlib.sha256(content).hexdigest(),'stat':before}
def write_json(path,value):
    path.write_text(json.dumps(value,indent=2)+chr(10))
baseline=[signature(p) for p in PUBLIC]
baseline_by_path={x['resolved_path']:x for x in baseline}
manifest={'schema':'hepta-pin-buffer-diagnostic-v1','scope':'warm page-cache complete public-file hashing microbenchmark; not end-to-end runtime throughput','public_files':baseline,'rounds_per_pair':ROUNDS,'order':'ABBA for each pair each round; pair ordering alternates by round','iterations_per_file_per_process':ITERATIONS,'warmup_per_file':8,'chunks_bytes':[16384,65536,262144],'binary_sha256':hashlib.sha256(BIN.read_bytes()).hexdigest(),'source_sha256':hashlib.sha256((ROOT/'src/main.rs').read_bytes()).hexdigest(),'loadavg_before':os.getloadavg(),'machine':platform.machine(),'cpu_affinity':sorted(os.sched_getaffinity(0)),'read_calls_semantics':'count of Read::read attempts including EOF and Interrupted; complete byte length and SHA256 verified on each iteration','metadata_semantics':'fresh descriptor per hash; fd and path identity stamps checked before and after; resolved public files only; no private profile paths','cpu_semantics':'clock_gettime(CLOCK_PROCESS_CPUTIME_ID), user+system CPU inside each timed block','deadline_semantics':'per-run subprocess deadline 10 sec; benchmark has no HeptaRuntime cancellation/profile checks'}
write_json(ROOT/'manifest.json',manifest)
samples=[]
started=time.monotonic()
raw=ROOT/'samples.jsonl'
with raw.open('x') as output:
    run_index=0
    for round_index in range(ROUNDS):
        pairs=PAIRS if round_index%2==0 else list(reversed(PAIRS))
        for a,b in pairs:
            for slot,chunk in enumerate((a,b,b,a)):
                run_index+=1
                cmd=[str(BIN),str(chunk),str(ITERATIONS)]
                p=subprocess.run(cmd,capture_output=True,text=True,timeout=10)
                if p.returncode:
                    write_json(ROOT/'failed-run.json',{'index':run_index,'argv':cmd,'exit_code':p.returncode,'stdout':p.stdout,'stderr':p.stderr})
                    raise RuntimeError('diagnostic executable failed')
                try: values=[json.loads(line) for line in p.stdout.splitlines() if line]
                except Exception:
                    write_json(ROOT/'failed-run.json',{'index':run_index,'argv':cmd,'exit_code':p.returncode,'stdout':p.stdout,'stderr':p.stderr})
                    raise
                if len(values)!=len(PUBLIC):raise RuntimeError('missing public file output')
                for row in values:
                    expected=baseline_by_path[row['path']]
                    size=expected['stat']['st_size']
                    if row['sha256']!=expected['sha256'] or row['bytes_read']!=ITERATIONS*size or row['full_hash_checks']!=ITERATIONS:
                        raise RuntimeError('full-content identity check failed')
                    expected_calls=ITERATIONS*(math.ceil(size/chunk)+1)
                    if row['read_calls_including_eof']!=expected_calls+row['interrupted_read_calls']:
                        raise RuntimeError('unexpected short read or read-call count')
                    row.update({'round':round_index+1,'pair':[a,b],'slot':slot,'run_index':run_index})
                    samples.append(row)
                    output.write(json.dumps(row)+chr(10))
                output.flush()
    after=[signature(p) for p in PUBLIC]
    if after!=baseline:raise RuntimeError('public binaries changed during ABBA')
write_json(ROOT/'post-manifest.json',{'public_files':after,'loadavg_after':os.getloadavg(),'elapsed_seconds':time.monotonic()-started})
comparisons=[]
for a,b in PAIRS:
    for path in baseline_by_path:
        block=[]
        for round_number in range(1,ROUNDS+1):
            rows=[x for x in samples if x['path']==path and x['pair']==[a,b] and x['round']==round_number]
            result={'round':round_number}
            for metric in ('cpu_ns','elapsed_ns'):
                means={chunk:statistics.mean(x[metric]/x['iterations'] for x in rows if x['chunk_bytes']==chunk) for chunk in (a,b)}
                result[metric+'_ratio_b_over_a']=means[b]/means[a]
                result[metric+'_saved_per_hash']=means[a]-means[b]
            block.append(result)
        comparisons.append({'path':path,'a':a,'b':b,'rounds':block,
            'cpu_ratio_geomean':math.exp(statistics.mean(math.log(x['cpu_ns_ratio_b_over_a']) for x in block)),
            'elapsed_ratio_geomean':math.exp(statistics.mean(math.log(x['elapsed_ns_ratio_b_over_a']) for x in block)),
            'cpu_saved_ns_mean':statistics.mean(x['cpu_ns_saved_per_hash'] for x in block),
            'b_cpu_faster_rounds':sum(x['cpu_ns_ratio_b_over_a']<1 for x in block)})
per_size=[]
for path in baseline_by_path:
    for chunk in (16384,65536,262144):
        rows=[x for x in samples if x['path']==path and x['chunk_bytes']==chunk]
        per_size.append({'path':path,'chunk_bytes':chunk,'samples':len(rows),
            'cpu_ns_per_hash_median':statistics.median(x['cpu_ns']/x['iterations'] for x in rows),
            'elapsed_ns_per_hash_median':statistics.median(x['elapsed_ns']/x['iterations'] for x in rows),
            'read_calls_per_hash':rows[0]['read_calls_including_eof']/ITERATIONS,
            'sha256':rows[0]['sha256']})
summary={'schema':'hepta-pin-buffer-diagnostic-summary-v1','ok':True,
'complete_hash_checks':sum(x['full_hash_checks'] for x in samples),
'bytes_hashed_measured':sum(x['bytes_read'] for x in samples),
'read_calls':sum(x['read_calls_including_eof'] for x in samples),
'interrupted_read_calls':sum(x['interrupted_read_calls'] for x in samples),
'comparisons':comparisons,'per_size':per_size,
'scope':manifest['scope'],'no_production_changes':True}
write_json(ROOT/'summary.json',summary)
print(json.dumps(summary))
