# R16 后续优化候选：只读源码与既有证据审计

本报告区分已观察到的源码成本、历史测量和待验证推断。排序表示值得投入下一轮验证的顺序，不代表已证明的收益大小。本次审计没有改动冻结源码、构建、运行负载、采样 perf、修改 CPU 设置或向既有服务发送信号。

基准源码根目录：/home/qian/hepta-runtime-optimization-20261104-r16/source。R16 正式资格/性能流程由主代理独立负责；本报告不替代该流程，不将后续未应用的 diff 算入 R16 已资格化二进制。

## 一、结论

下一步有三个可单独验收的低风险方向：同一二进制/arena1 下比较主 Tokio workers 1、2、4；给 native jobctl 的普通 File JSON reader 加受限缓冲；把 read_job 中三个路由完全不用的 legacy JSON Value 延迟到实际使用分支构造。

前者只改变主运行时线程配置，不能提高独立 SSH owner 的线程数或固定两个 validation permits。后两者分别作用于远端 helper 和 controller，不能把混合候选的端到端变化全部归因于同一个补丁。当前历史 native CPU 分母只覆盖 controller 进程，因此 helper CPU 下降不能直接当作该指标下降。

更大的潜力需要分相位证据：同步 owner 完整 hash 的 CPU、validation 排队/运行、三次 agent 查询、SSH slave/helper 启动与执行、observation completion audit 的排队/同步时间。源码上确有这些成本，但现有材料不足以断言其中任意一个独占主要瓶颈。

## 二、已有数据的适用范围

R15 /performance-results.md 和 /independent-audit-tools/frontier-decision-after-r15.json 记录同一 qualified R14 binary、主 workers=2、default allocator 与 arena1 的 ABBA。每个 C/arm 为两次新 controller 进程、合计 192 个 measured calls；样本不支持统计显著性或全负载最优结论。

| 并发 | default CPU ms/call | arena1 CPU ms/call | default calls/s | arena1 calls/s |
|---|---:|---:|---:|---:|
| C1 | 129.5312 | 129.0625 | 4.3922 | 4.3244 |
| C4 | 73.0729 | 72.3438 | 17.5215 | 18.2721 |
| C8 | 72.1875 | 72.8125 | 23.1270 | 22.8705 |

C8 arena1 的 pooled rate 为 -1.1091%、controller CPU/call +0.8658%、p95 +2.9182%、p99 +9.1306%；两个 B 的 rate 和 CPU 都落在 A 两个新进程的范围内。这不是稳定吞吐增益，也没有形成足够一致的 allocator contention 证据来要求重做 arena2 全矩阵。arena1 在另一 large wrong-host cancellation refusal 夹具上的大幅 RSS/HWM 下降不能外推为 native 吞吐增益。

该 native CPU 指标没有完整计入 SSH 子进程或远端 helper 的 CPU。树 RSS/FD 为异步部分采样，旧 native FD 还出现 PermissionError，不能解释为零。C1/C8 CPU 差异有多种可能因素；不能从这张表推断 governor、SSH 或 hash 的单一因果。

来源：
- /home/qian/hepta-runtime-optimization-20261103-r15/performance-results.md
- /home/qian/hepta-runtime-optimization-20261103-r15/performance-report-data.json
- /home/qian/hepta-runtime-optimization-20261103-r15/independent-audit-tools/frontier-decision-after-r15.json

## 三、真实并发结构

下列位置均相对于 R16/source。

| 层次 | 实际边界 | workers 配置的含义 |
|---|---|---|
| 主 HTTP/MCP 运行时 | src/main.rs:25 的 #[tokio::main] | TOKIO_WORKER_THREADS 影响该多线程运行时 |
| SSH observation owner | ssh_observation_pool.rs:start，178–183，专用 OS 线程 + new_current_thread | 不随主 workers 改变；原物理 owner 的同步验收仍在这里 |
| Direct SSH owner | ssh_direct.rs:470–475，独立 current-thread runtime | 不随主 workers 改变 |
| Pin validation | ssh_observation_validation.rs:12，WORKERS=2 | 固定两个物理容量许可；不是主 Tokio worker 数 |
| Observation SSH | ssh_observation_pool.rs，global 8、host 2、queue 8、admitted 16、masters 8 | 调高请求 C 不等于调高物理会话容量 |
| 本地 observation record read | jobs.rs:53 / run_observation_record_read2084 / check_ref_async2104，容量 4 | Permit 覆盖 blocking queue 和真实执行至退出 |
| Observation audit | jobs.rs:51 / run_observation_audit2472，容量 8 | append 还受全局 AUDIT_LOCK 串行化 |
| Native status helper | jobctl.rs:Lock::acquire163 / run1449，ROOT/lock 独占 flock | status 在全局锁内；read 路由没有这把锁 |

R14 的 thread/arena 诊断仍观察到 19–20 个峰值线程及 idle 后 10 个线程；限制 glibc arena 不等于限制线程。主 workers=1/2/4 的新实验应使用同一 binary、arena1、同一 workload 与 C，并记录实际 /proc/PID/environ、进程 identity、吞吐、controller CPU、尾延迟和线程/RSS。其合理机制是主调度开销/争用/公平性变化，不能将其包装成 SSH owner 的 4 路 hash。

## 四、候选排序与验证机制

### 1. 主 Tokio workers 1 / 2 / 4：先完成现有证据缺口

代码位置见上一节。历史 R14/R15 的 workers1/2 比较属于 local wrong-host cancel refusal 夹具；native 正式数据均 workers2。已审阅材料没有同等 native workers1/4 资格化对照的确证，不能因此声称从未试过。

采用主代理计划中的相同 qualified binary、相同 arena1、独立 workers2 vs1 / vs4 ABBA，避免混入源码或 allocator 差异。增减 workers 都可能影响尾延迟/内存/主调度公平性；X230 的两个物理核心并不保证 workers4 更快。

### 2. Native jobctl 的 JSON 文件读取加缓冲

src/bin/jobctl.rs:150–159 json_file 打开普通 File、验证 bounded regular file，然后 serde_json::from_reader(f.take(INPUT_MAX + 1))。该 reader 没有 BufReader。Serde JSON 的 reader 输入本身不提供缓冲，小步解析会将底层 Read 调用传递给 File；这是明确的、可测的 syscall/CPU 机制。

调用覆盖包括 load_record439、policy449、observe_terminal581 中的 capture witness；exit receipt 走 json_bytes134 的完整受限 read_to_end，再于591 from_slice，不能重复计算为同一问题。controller 中已查看的 JSON 路径用 from_slice，没有把这个发现推广为“全局换 parser”。

候选应是 BufReader::new(f.take(INPUT_MAX + 1))，将 Take 放在底层，保留原打开 flags、regular-file/长度前置检查、JSON trailing/error 行为、job ID/nonce/boot/invocation/capture witness 绑定。具体错误/增长边界与 ABBA 脚本由 native_hotpath 独立审查；不得先假设等价。

应量化真实 NativeRecord/witness 和边界/损坏输入的底层 read 调用数、helper CPU/elapsed、同样内容验证结果，再测 live/terminal status 与 read。controller CPU 分母不包含远端 helper；端到端收益受网络、SSH、owner hash 和 audit 限制。此候选不是 R14 已否决的 controller 自定义 streaming serializer/parser 实验。

### 3. read_job 延迟创建未使用的 legacy request Value

jobs.rs:4442–4503 的 read_job 在4449–4457无条件创建 legacy Python request Value。只有4486开始的 direct legacy Python 分支使用它；pool/native、pool/Python 与 direct/native 三条路径各自准备请求。把原表达式完整移入唯一使用分支，能在源码层面省去不需要的 map/string 构造。

不得移动 check_ref_async、runtime_config/host 检查、audit，也不更改默认 offset、limit/clamp 或 request_digest。这个补丁不接触任何 pin、owner、取消、重放或许可生命周期。预计属于小收益候选，不能把理论删除分配当作 native 吞吐提升。

独立未应用补丁与审查位置：diagnostics/read-job-request-review/。冻结源码保持不变。后续可与 helper 缓冲一起做完整资格，但性能结论必须分 controller/helper、status/read、native/Python 归因。

### 4. 测量 audit 串行成本，再考虑保持合同的调度改造

status_job4407、wait_job4422、read_job4442 都在返回前 await observation_completion_audit2494。run_observation_audit2472 将物理 permit 移入 spawn_blocking closure，直到真实 append 退出。append_audit_with2339 的全局 AUDIT_LOCK 覆盖 append；append_audit_at_with2408 在每事件 write 后同步文件，2457–2459实际调用 sync_data。warm readiness 只减少已证明可复用的目录同步，文件同步仍强制逐事件进行。

可量化锁等待、file sync、目录/path 验证、closure queue 和真正 CPU。若确认是资源热点，单个专用 bounded writer 可研究线程/等待资源，仍须每事件 sync_data、原时间/身份/目标冻结、返回前持久成功、取消后物理 permit 保留、失败传播与 shutdown drain。它不是现成的“线程数调小”开关，也不是已证明更快。

Group commit、取消 fdatasync、先回成功后审计均不在本轮合同内。不得用旧 wrong-host cancel refusal 夹具（在 append 前失败）声称成功 audit/fsync 已测或是瓶颈。

### 5. Native live 状态探测与 wait：单列协议前沿

jobctl.rs:properties514 每次 live 探测启动 /usr/bin/systemctl show，已限制属性集合；status_at727 先查 completion、检查 boot，再 probe(systemctl + bind_invocation521)，之后再次检查 completion，以覆盖终态在 probe 期间发布的竞争。完成态可以在 probe 前返回，因此 terminal fixture 不能证明替换 systemctl 的收益。

全局 helper flock 跨 status/probe，也会串行化同一主机的不同 job。直接改 shared/per-job lock 会改变现有 start/cancel/bind_invocation 的互斥关系和新旧 helper 的协调，不能仅按“观察是只读”删除锁。直接 D-Bus 可减少子进程启动，但必须保留 exact unit/description/InvocationID/boot、两个 completion 窗口及失败/unknown 语义，并独立测 live workload。

jobs.rs:status_observation3879 对 native wait 重复调用 SystemStatus，若仍 running 则 sleep100ms，再做下一次完整 SSH observation；每轮都有12 pin-set passes和新slave/helper。PythonStatus已经传wait_seconds。当前status/read ABBA不覆盖这条放大路径。

一个闭集 bounded native wait 操作有降低重复启动和通信的潜力，但需要新协议与单独资格：保留原绝对deadline、每次原owner验收、输出绑定、取消/无重放/unknown规则；内部每轮重新验证所需record/receipt/invocation，不能用30秒旧record快照替代。不能在整个wait期间一直持有global helper lock而阻塞cancel/start。不得直接合并现有独立observation调用的安全检查。

### 6. X230 专用 target-cpu 与更深 owner/worker 调度：低优先、先归因

Cargo.toml:30–36 当前已是 opt-level=3、lto=true、codegen-units=1、panic=abort、strip=true、overflow-checks=false；仓库 .cargo/config 与 .cargo/config.toml 均不存在。不能再把这些已启用 release 参数当作新优化。

已审阅 R11–R15 证据没有 qualified target-cpu=native 或 release-profile 对照的确证；对较早目录只做了有限顶层/已知报告检查，未全盘搜索旧 source/cache，历史未测不能被证明。target-cpu=native 是不同 artifact，需绑定编译环境/架构/CPU flags、完整资格和同一 source 的 ABBA，且不得误部署到能力不足的其它主机。已有 ring hash backend 不意味着新的 rustc CPU flag 一定能改善主要成本。

同步 owner hash 可能限制单 owner 的并行服务，但现有资料不能量化其占比。增加主 Tokio workers、validation permits 或改用独立 hash worker 都不能绕过原 owner 的同步完整内容验收。跨 host 分 shard 的 owner 需要新结构：每 shard 的原 owner identity、全局 freeze、master/child custody、总容量、绝对deadline与shutdown保持一致。只在 owner CPU/queue 已被实测证明关键时进入该项目；不要先扩大并发再以更多 CPU/RSS 换短期吞吐。

## 五、不能合并或省略的边界

ssh_observation_pool.rs:verify_files673 / verify_profile_for697 / execute_inner1411 的 warm request 包含 admission、pre-lease、post-response 三次 profile 验证；每次 agent 前后各一次文件校验；每次又有 worker 完整内容校验和 original owner 同步完整复查。六个 pinned files 合计12 pin-set passes、72次完整文件读取/hash。

以下不等价：
- 只比较 inode/mtime/长度，复用前一次“成功”，缓存 fd 或内容 hash；
- 把 agent 前后验证合并、用之前的 agent response 替代三次当前查询；
- 在 worker 算完后就接受，去掉原 owner 全内容复查；
- 取消请求后提前归还仍在 blocking queue/真实执行/未reap child 所拥有的 permit；
- 在 SSH/agent/response 失败后自动重放提交，以“重试”改善成功率；
- 跳过 remote record/nonce/boot/invocation/witness 绑定或终态竞争窗口；
- 省略逐事件 audit 文件同步或提前发布成功。

validation 模块的 Completion/OwnerTicket（WORKERS2，run_retained95）把许可保留至真实工作和ownerfinish完成；drain获取全部许可才能清理。captured路径同样在真正reap之后才能释放child相关预算。新调度必须维持这些物理生命周期。

openat2 快速路径已被真实 execute-only 中间目录反例否决：传统逐组件 O_RDONLY 遍历对0111目录 EACCES，而最终fd openat2(BENEATH|NO_SYMLINKS)可成功。其独立证据保留在 diagnostics/openat2-*；R16 production 未采用该路径。

## 六、已测/已做的项目，避免重复包装

- 固定脚本命令：ssh.rs112/121 已用 OnceLock；runtime_policy_digest 在 config.rs119–146/399 已缓存。
- 16/64/256KiB 完整 ring SHA256 诊断已完成，保留16KiB。16→64仅ssh文件有小幅且不稳定收益，其余文件无一致收益；256KiB无普遍优势。应用Read调用下降不等于端到端吞吐提升。
- R14 design/frontier 中的两遍streaming、one-buffer bounded writer、two-buffer实验已呈CPU回退（各自原实验范围分别+64–205%、+162–344%、+6.32–21.32%）；不能作为未试过的新方案。
- arena1主要是资源占用取舍；R15没有证明native稳定吞吐提升。R14/R15 prep2与publication8各自承担不同物理生命周期，不等于8个可以同时写盘的audit writer。
- Linux observation pool已有ControlMaster复用、bounded masters/hosts/sessions、idle/age维护；不要再建议“开启SSH复用”作为尚未实现项。

## 七、硬件和采样条件

本次少量只读快照：
- Intel Core i5-3230M @2.60GHz，2 physical cores、4 siblings；
- sha_ni=false、avx=true、avx2=false、aes=true、sse4_2=true；
- cpu0 governor=schedutil、driver=intel_cpufreq；一次scaling_cur_freq=2993094kHz，min1200000/max3200000；
- perf_event_paranoid=4，kptr_restrict=1。

这些不是性能采样，也不能说明测试期间频率稳定。没有执行perf、改权限/governor、绑核或调频。若未来需要分相位归因，优先使用隔离诊断版本中的有限计数/原线程CPU和wall时间，以及不暴露credentials的结果；其开销需校准，正式收益最终仍由绑定qualified artifact的无诊断ABBA确认。

## 八、停止条件

本轮静态审计已把低风险、具有具体机制的下一步和需要合同设计的大项目分开。完成workers配置和两个小候选的资格/测量后，应以重复性、资源成本、尾延迟与正确性门槛决定是否保留。尚无证据能宣布全局最优；同样不应为了枚举更多开关而重复已否决实验，或把安全边界当作可删除的性能开销。

## 参考资料

本地历史：
- /home/qian/hepta-runtime-optimization-20261103-r14/implementation-design-and-frontier.md
- /home/qian/hepta-runtime-optimization-20261103-r14/diagnostic-summary.json
- /home/qian/hepta-runtime-optimization-20261103-r15/performance-results.md
- /home/qian/hepta-runtime-optimization-20261103-r15/independent-audit-tools/frontier-decision-after-r15.json
- /home/qian/hepta-runtime-optimization-20261104-r16/diagnostics/README.md
- /home/qian/hepta-runtime-optimization-20261104-r16/diagnostics/review/source-review.md
- /home/qian/hepta-runtime-optimization-20261104-r16/diagnostics/read-job-request-review/review.md (后续未应用候选)

官方API语义核对：
- https://docs.rs/tokio/latest/tokio/runtime/struct.Builder.html
- https://docs.rs/tokio/latest/tokio/runtime/
- https://docs.rs/serde_json/latest/serde_json/struct.Deserializer.html
- https://docs.rs/serde_json/latest/src/serde_json/read.rs.html

上述online docs用于核对reader不buffer与current-thread/worker配置的一般API语义；当前项目版本以Cargo.toml/lock及实际源码为准，不能将latest文档版本冒充当前二进制依赖版本。

