# Independent source review: parsed fixed pin paths and local 16 KiB reuse

Decision: no source-level blocker found for the exact candidate in
candidate-identity.json. This is not a test, release, or performance qualification.

## Reviewed invariants

The new ParsedAbsolutePath owns the unchanged original PathBuf and immutable
CString components. It stores no open descriptor, inode result or successful
authorization decision. The previous absolute-path validation runs during
preparation. Actual access still reopens the root and every component with the
same flags, so execute-only intermediate directories remain rejected.

checked_file retains regular-file, owner, mode, link-count, size and executable
capability restrictions. verify_read retains the complete length, same-descriptor
stamp, and an independent full pathname reopen. Every streamed verification still
reads the complete content into a fresh SHA256 context and checks the final digest.

Buffer reuse is restricted to one synchronous verify_files_checked invocation.
The buffer remains 16 KiB, is exclusively mutable, and only the returned byte count
is hashed. Existing check_current boundaries remain before and after reads/hashes.
The fixed /bin/sh alias resolver is unchanged; dynamic open_absolute still uses
the original parser and traversal.

## Tests inspected

The seven new unit tests cover syntax/component parity, symlink replacement,
execute-only parent denial, descriptor flags/FIFO/type changes, directory
replacement and both read stamps, old chunk boundaries and dirty short/empty
tails, and post-read cancellation. No candidate build or test was executed by
this reviewer. The permission test skips under root; the observed X230 account
is uid1000 with no effective capability bits, so the case can execute there.

The two ignored benchmarks isolate path preparation and same-size buffer reuse.
They are not production performance gates and cannot substitute for measured
multi-host runtime throughput, latency, CPU, RSS, failure and cancellation tests.

## Rejected optimization and resource accounting

The single-final-fd openat2 substitution has a real-kernel permission counterexample
recorded separately, including a uid1000, mode0600, nlink1 private-pin-valid file
under an execute-only 0111 intermediate directory. It was excluded from production.

The separate full-content hash-buffer ABBA diagnostic did not support increasing
the established 16 KiB buffer as a clear stable win. Immutable CString components
also increase retained per-pin storage slightly; adoption must depend on the full
runtime benefit and resource accounting, not the existence of an optimization patch.

## Identity

The complete diff, copied candidate source/tests, original and candidate hashes,
and diff hashes are under this review directory. Current source was rechecked
against the reviewed snapshot before publishing this result.
