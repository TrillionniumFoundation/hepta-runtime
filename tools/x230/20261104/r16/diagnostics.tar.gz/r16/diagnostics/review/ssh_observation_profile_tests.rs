// Copyright 2026 Muvon Un Limited
// Copyright 2026 TrillionniumFoundation; SPDX-License-Identifier: Apache-2.0
//! Profile identity, byte completeness and worker-consumption boundaries.
use super::*;
use sha2::Digest;
use std::os::unix::fs::{symlink, PermissionsExt};

#[test]
fn profile_hashes_keep_standard_sha256_bytes() {
	for (bytes, expected) in [
		(
			b"".as_slice(),
			"e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855",
		),
		(
			b"abc".as_slice(),
			"ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad",
		),
	] {
		assert_eq!(digest(bytes), hex_digest(expected).unwrap());
	}
	for length in [
		1, 55, 56, 63, 64, 65, 4095, 4096, 16383, 16384, 16385, 262151,
	] {
		let bytes: Vec<_> = (0..length).map(|index| (index % 251) as u8).collect();
		let reference: [u8; 32] = sha2::Sha256::digest(&bytes).into();
		assert_eq!(digest(&bytes), reference);
	}
}

#[test]
fn exact_supported_config_has_no_dynamic_or_undeclared_inputs() {
	let known = Path::new("/private/known_hosts");
	let accepted = b"Host hepta-main\n HostName 127.0.0.1\n User test\n Port 22\n HostKeyAlias pinned-main\n UserKnownHostsFile /private/known_hosts\n GlobalKnownHostsFile /dev/null\n BatchMode yes\n ConnectTimeout 8\n ControlMaster no\n ForwardAgent no\n StrictHostKeyChecking yes\n";
	validate_config(accepted, known).unwrap();
	for line in [
		"Include /private/more",
		"Match exec /usr/bin/true",
		"ProxyJump main",
		"ProxyCommand /bin/true",
		"IdentityFile /private/key",
		"LocalCommand /bin/true",
		"UserKnownHostsFile /other/known_hosts",
		"GlobalKnownHostsFile /etc/ssh/ssh_known_hosts",
		"ForwardAgent yes",
		"StrictHostKeyChecking no",
		"Host !main",
		"Host hepta-*",
		"User ${USER}",
		"Hostname `command`",
		"User \"quoted\"",
	] {
		assert!(
			validate_config(
				format!("{}\n{line}\n", std::str::from_utf8(accepted).unwrap()).as_bytes(),
				known
			)
			.is_err(),
			"accepted {line}"
		);
	}
}

#[test]
fn exact_file_pins_reject_inplace_changes_symlinks_hardlinks_and_permissions() {
	let root = tempfile::tempdir().unwrap();
	let path = root.path().join("config");
	std::fs::write(&path, b"one").unwrap();
	std::fs::set_permissions(&path, std::fs::Permissions::from_mode(0o600)).unwrap();
	let (pin, _) = PinnedFile::load(&path, None, 1024, true, false).unwrap();
	pin.verify().unwrap();
	std::fs::write(&path, b"two").unwrap();
	assert!(pin.verify().is_err());
	let link = root.path().join("link");
	symlink(&path, &link).unwrap();
	assert!(PinnedFile::load(&link, None, 1024, true, false).is_err());
	std::fs::remove_file(&link).unwrap();
	std::fs::hard_link(&path, &link).unwrap();
	assert!(PinnedFile::load(&path, None, 1024, true, false).is_err());
	std::fs::remove_file(link).unwrap();
	std::fs::set_permissions(&path, std::fs::Permissions::from_mode(0o644)).unwrap();
	assert!(PinnedFile::load(&path, None, 1024, true, false).is_err());
}

#[test]
fn streamed_pins_check_every_chunk_and_the_partial_tail() {
	let root = tempfile::tempdir().unwrap();
	let path = root.path().join("large-pin");
	let mut bytes: Vec<u8> = (0..VERIFY_BUFFER_BYTES * 13 + 7)
		.map(|index| (index % 251) as u8)
		.collect();
	std::fs::write(&path, &bytes).unwrap();
	std::fs::set_permissions(&path, std::fs::Permissions::from_mode(0o600)).unwrap();
	let (mut pin, _) = PinnedFile::load(&path, None, bytes.len(), true, false).unwrap();
	pin.verify().unwrap();
	for position in [
		0,
		VERIFY_BUFFER_BYTES - 1,
		VERIFY_BUFFER_BYTES * 7,
		bytes.len() - 1,
	] {
		bytes[position] ^= 1;
		std::fs::write(&path, &bytes).unwrap();
		// Isolate byte verification from the independent metadata fence.
		pin.stamp = Stamp::of(&std::fs::metadata(&path).unwrap());
		assert!(pin.verify().is_err(), "missed changed byte {position}");
		bytes[position] ^= 1;
		std::fs::write(&path, &bytes).unwrap();
		pin.stamp = Stamp::of(&std::fs::metadata(&path).unwrap());
		pin.verify().unwrap();
	}
}

#[test]
fn streamed_pins_keep_length_and_path_identity_fences() {
	let root = tempfile::tempdir().unwrap();
	let path = root.path().join("pin");
	let bytes = vec![7; VERIFY_BUFFER_BYTES + 3];
	std::fs::write(&path, &bytes).unwrap();
	std::fs::set_permissions(&path, std::fs::Permissions::from_mode(0o600)).unwrap();
	let (pin, _) = PinnedFile::load(&path, None, bytes.len(), true, false).unwrap();
	for length in [bytes.len() - 1, bytes.len() + 1] {
		std::fs::OpenOptions::new()
			.write(true)
			.open(&path)
			.unwrap()
			.set_len(length as u64)
			.unwrap();
		assert!(pin.verify().is_err());
	}
	std::fs::rename(&path, root.path().join("original")).unwrap();
	std::fs::write(&path, &bytes).unwrap();
	std::fs::set_permissions(&path, std::fs::Permissions::from_mode(0o600)).unwrap();
	assert!(pin.verify().is_err());
	let target = root.path().join("target");
	std::fs::rename(&path, &target).unwrap();
	symlink(&target, &path).unwrap();
	assert!(pin.verify().is_err());
}

fn private_test_pin(path: &Path, bytes: &[u8]) -> PinnedFile {
	std::fs::write(path, bytes).unwrap();
	std::fs::set_permissions(path, std::fs::Permissions::from_mode(0o600)).unwrap();
	PinnedFile::load(path, None, bytes.len(), true, false)
		.unwrap()
		.0
}

#[test]
fn parsed_paths_keep_the_original_syntax_and_component_normalization() {
	let root = tempfile::tempdir().unwrap();
	let path = root.path().join("pin");
	private_test_pin(&path, b"pin");
	for path in [
		PathBuf::from("/"),
		PathBuf::from("///"),
		root.path().to_owned(),
		path.clone(),
		PathBuf::from(format!("{}//pin///", root.path().display())),
	] {
		let parsed = ParsedAbsolutePath::new(&path).unwrap();
		assert_eq!(parsed.as_path().as_os_str(), path.as_os_str());
		for directory in [false, true] {
			match (
				open_absolute_legacy(&path, directory),
				parsed.open(directory),
			) {
				(Ok(before), Ok(after)) => {
					let before = before.metadata().unwrap();
					let after = after.metadata().unwrap();
					assert_eq!((before.dev(), before.ino()), (after.dev(), after.ino()));
				}
				(Err(before), Err(after)) => assert_eq!(
					before
						.downcast_ref::<std::io::Error>()
						.unwrap()
						.raw_os_error(),
					after
						.downcast_ref::<std::io::Error>()
						.unwrap()
						.raw_os_error()
				),
				_ => panic!("parsed path changed acceptance: {path:?}, directory={directory}"),
			}
		}
	}
	let mut invalid: Vec<PathBuf> = [
		"",
		"relative",
		"/private/./pin",
		"/private/../pin",
		"/private/%h",
		"/private/~pin",
		"/private/$pin",
		"/private/`pin`",
		"/private/'pin'",
		"/private/\"pin\"",
		"/private/back\\slash",
		"/private/a b",
		"/private/a\t",
		"/private/a\n",
		"/private/a\0",
	]
	.into_iter()
	.map(PathBuf::from)
	.collect();
	invalid.push(PathBuf::from(format!("/{}", "a".repeat(4096))));
	invalid.push(PathBuf::from(std::ffi::OsString::from_vec(vec![
		b'/', 0xff,
	])));
	for path in invalid {
		assert!(ParsedAbsolutePath::new(&path).is_err(), "{path:?}");
		assert!(open_absolute_legacy(&path, false).is_err(), "{path:?}");
	}
}

#[test]
fn parsed_paths_reject_middle_and_final_symlinks_after_preparation() {
	let root = tempfile::tempdir().unwrap();
	let parent = root.path().join("parent");
	std::fs::create_dir(&parent).unwrap();
	let path = parent.join("pin");
	let pin = private_test_pin(&path, b"original");
	let parsed = ParsedAbsolutePath::new(&path).unwrap();
	let moved = root.path().join("moved");
	std::fs::rename(&parent, &moved).unwrap();
	symlink(&moved, &parent).unwrap();
	assert!(parsed.open(false).is_err());
	assert!(open_absolute_legacy(&path, false).is_err());
	assert!(pin.verify().is_err());
	std::fs::remove_file(&parent).unwrap();
	std::fs::rename(&moved, &parent).unwrap();

	let moved_file = parent.join("moved-pin");
	std::fs::rename(&path, &moved_file).unwrap();
	symlink(&moved_file, &path).unwrap();
	assert!(parsed.open(false).is_err());
	assert!(open_absolute_legacy(&path, false).is_err());
	assert!(pin.verify().is_err());
}

#[test]
fn parsed_paths_keep_read_permission_checks_on_every_intermediate_directory() {
	if unsafe { libc::geteuid() } == 0 {
		eprintln!("permission-denial case requires an unprivileged test account");
		return;
	}
	let root = tempfile::tempdir().unwrap();
	let parent = root.path().join("parent");
	std::fs::create_dir(&parent).unwrap();
	let path = parent.join("pin");
	let pin = private_test_pin(&path, b"readable-through-search-only-parent");
	let parsed = ParsedAbsolutePath::new(&path).unwrap();
	std::fs::set_permissions(&parent, std::fs::Permissions::from_mode(0o111)).unwrap();
	let legacy = open_absolute_legacy(&path, false);
	let prepared = parsed.open(false);
	let pinned = pin.verify();
	// Restore before asserting so temporary-directory cleanup retains access.
	std::fs::set_permissions(&parent, std::fs::Permissions::from_mode(0o700)).unwrap();
	for result in [legacy, prepared] {
		assert_eq!(
			result
				.unwrap_err()
				.downcast_ref::<std::io::Error>()
				.unwrap()
				.raw_os_error(),
			Some(libc::EACCES)
		);
	}
	assert!(pinned.is_err());
}

#[test]
fn parsed_paths_keep_descriptor_flags_and_reject_inode_type_changes() {
	let root = tempfile::tempdir().unwrap();
	let path = root.path().join("pin");
	let pin = private_test_pin(&path, b"regular");
	let parsed = ParsedAbsolutePath::new(&path).unwrap();
	for file in [
		parsed.open(false).unwrap(),
		open_absolute_legacy(&path, false).unwrap(),
	] {
		let status = unsafe { libc::fcntl(file.as_raw_fd(), libc::F_GETFL) };
		assert_ne!(status, -1);
		assert_eq!(status & libc::O_ACCMODE, libc::O_RDONLY);
		assert_ne!(status & libc::O_NONBLOCK, 0);
		let descriptor = unsafe { libc::fcntl(file.as_raw_fd(), libc::F_GETFD) };
		assert_ne!(descriptor, -1);
		assert_ne!(descriptor & libc::FD_CLOEXEC, 0);
	}
	assert!(parsed.open(true).is_err());
	assert!(PinnedFile::load(root.path(), None, 1024, true, false).is_err());
	std::fs::remove_file(&path).unwrap();
	std::fs::create_dir(&path).unwrap();
	assert!(pin.verify().is_err());
	std::fs::remove_dir(&path).unwrap();
	let name = std::ffi::CString::new(path.as_os_str().as_encoded_bytes()).unwrap();
	assert_eq!(unsafe { libc::mkfifo(name.as_ptr(), 0o600) }, 0);
	// O_NONBLOCK must keep a replaced FIFO from parking a validation worker.
	assert!(pin.verify().is_err());
}

#[test]
fn parsed_paths_reopen_replaced_directories_and_keep_both_read_stamps() {
	let root = tempfile::tempdir().unwrap();
	let parent = root.path().join("parent");
	std::fs::create_dir(&parent).unwrap();
	let path = parent.join("pin");
	let pin = private_test_pin(&path, b"original");
	std::fs::rename(&parent, root.path().join("moved-parent")).unwrap();
	std::fs::create_dir(&parent).unwrap();
	private_test_pin(&path, b"original");
	assert!(pin.verify().is_err());
	let reopened = pin.path.open(false).unwrap().metadata().unwrap();
	assert_ne!(
		(reopened.dev(), reopened.ino()),
		(pin.stamp.dev, pin.stamp.ino)
	);

	let parsed = ParsedAbsolutePath::new(&path).unwrap();
	let (mut file, before) = checked_file(&parsed, 1024, true, false).unwrap();
	let mut bytes = Vec::new();
	file.read_to_end(&mut bytes).unwrap();
	std::fs::set_permissions(&path, std::fs::Permissions::from_mode(0o644)).unwrap();
	assert!(verify_read(&parsed, &file, &before, bytes.len(), 1024).is_err());
	std::fs::set_permissions(&path, std::fs::Permissions::from_mode(0o600)).unwrap();
	std::fs::rename(&path, parent.join("moved-pin")).unwrap();
	private_test_pin(&path, &bytes);
	// Rebase only the test's descriptor stamp to isolate the independent
	// pathname reopen from rename-induced metadata changes on the old inode.
	let after_rename = Stamp::of(&file.metadata().unwrap());
	assert!(verify_read(&parsed, &file, &after_rename, bytes.len(), 1024).is_err());
}

#[test]
fn one_pin_set_buffer_handles_old_chunk_boundaries_empty_files_and_short_tails() {
	let root = tempfile::tempdir().unwrap();
	let mut pins = Vec::new();
	// Fixed 16 KiB cases remain explicit even if a later candidate changes
	// VERIFY_BUFFER_BYTES. Long-to-short-to-empty transitions expose stale tails.
	for (index, length) in [32775, 1, 0, 16383, 16384, 16385].into_iter().enumerate() {
		let bytes: Vec<_> = (0..length)
			.map(|offset| ((offset + index) % 251) as u8)
			.collect();
		let path = root.path().join(format!("pin-{index}"));
		pins.push((private_test_pin(&path, &bytes), bytes));
	}
	let mut buffer = [0xa5; VERIFY_BUFFER_BYTES];
	for (pin, bytes) in &mut pins {
		pin.verify_checked_with_buffer(&|| Ok(()), &mut buffer)
			.unwrap();
		if !bytes.is_empty() {
			let mut changed = bytes.clone();
			*changed.last_mut().unwrap() ^= 1;
			std::fs::write(pin.path.as_path(), &changed).unwrap();
			pin.stamp = Stamp::of(&std::fs::metadata(pin.path.as_path()).unwrap());
			assert!(pin
				.verify_checked_with_buffer(&|| Ok(()), &mut buffer)
				.is_err());
			std::fs::write(pin.path.as_path(), bytes).unwrap();
			pin.stamp = Stamp::of(&std::fs::metadata(pin.path.as_path()).unwrap());
			pin.verify_checked_with_buffer(&|| Ok(()), &mut buffer)
				.unwrap();
		}
	}
}

#[test]
fn reused_buffer_keeps_cancellation_checks_after_full_and_partial_reads() {
	let root = tempfile::tempdir().unwrap();
	let path = root.path().join("pin");
	let bytes: Vec<_> = (0..VERIFY_BUFFER_BYTES + 7)
		.map(|index| (index % 251) as u8)
		.collect();
	let pin = private_test_pin(&path, &bytes);
	// Checks 4 and 7 immediately follow the first full read and partial-tail
	// read. Cancellation must be returned before either can grant acceptance.
	for cancel_at in [4, 7] {
		let calls = std::cell::Cell::new(0);
		let mut buffer = [0; VERIFY_BUFFER_BYTES];
		let error = pin
			.verify_checked_with_buffer(
				&|| {
					calls.set(calls.get() + 1);
					if calls.get() == cancel_at {
						bail!("cancelled after a read");
					}
					Ok(())
				},
				&mut buffer,
			)
			.unwrap_err();
		assert_eq!(error.to_string(), "cancelled after a read");
		assert_eq!(calls.get(), cancel_at);
	}
}

fn benchmark_process_cpu_ns() -> u128 {
	let mut value: libc::timespec = unsafe { std::mem::zeroed() };
	assert_eq!(
		unsafe { libc::clock_gettime(libc::CLOCK_PROCESS_CPUTIME_ID, &mut value) },
		0
	);
	value.tv_sec as u128 * 1_000_000_000 + value.tv_nsec as u128
}

#[test]
#[ignore = "manual same-build path-cost benchmark; no production inputs or switches"]
fn profile_path_open_microbenchmark() {
	let root = tempfile::tempdir().unwrap();
	let parent = root.path().join("one/two/three");
	std::fs::create_dir_all(&parent).unwrap();
	let paths: Vec<_> = (0..6)
		.map(|index| {
			let path = parent.join(format!("pin-{index}"));
			private_test_pin(&path, &[index as u8; 64]);
			ParsedAbsolutePath::new(&path).unwrap()
		})
		.collect();
	const PASSES: usize = 2000;
	for round in 0..6 {
		for prepared in if round % 2 == 0 {
			[false, true]
		} else {
			[true, false]
		} {
			let cpu = benchmark_process_cpu_ns();
			let wall = std::time::Instant::now();
			for _ in 0..PASSES {
				for path in &paths {
					let file = if prepared {
						path.open(false)
					} else {
						open_absolute_legacy(path.as_path(), false)
					}
					.unwrap();
					std::hint::black_box(file);
				}
			}
			let wall_ns = wall.elapsed().as_nanos();
			let cpu_ns = benchmark_process_cpu_ns() - cpu;
			eprintln!(
				"{}",
				serde_json::json!({
					"benchmark": "profile_path_open",
					"variant": if prepared { "parsed" } else { "legacy" },
					"round": round,
					"passes": PASSES,
					"pins_per_pass": paths.len(),
					"wall_ns": wall_ns,
					"process_cpu_ns": cpu_ns,
				})
			);
		}
	}
}

#[test]
#[ignore = "manual same-build complete-pin benchmark; preserves every read and hash"]
fn profile_pin_set_buffer_microbenchmark() {
	let root = tempfile::tempdir().unwrap();
	let pins: Vec<_> = [257, 4096, 65539, 1_048_583, 32775, 131079]
		.into_iter()
		.enumerate()
		.map(|(index, length)| {
			let bytes: Vec<_> = (0..length)
				.map(|offset| ((offset + index) % 251) as u8)
				.collect();
			private_test_pin(&root.path().join(format!("pin-{index}")), &bytes)
		})
		.collect();
	const PASSES: usize = 128;
	for round in 0..6 {
		for shared in if round % 2 == 0 {
			[false, true]
		} else {
			[true, false]
		} {
			let cpu = benchmark_process_cpu_ns();
			let wall = std::time::Instant::now();
			for _ in 0..PASSES {
				if shared {
					let mut buffer = [0; VERIFY_BUFFER_BYTES];
					for pin in &pins {
						pin.verify_checked_with_buffer(&|| Ok(()), &mut buffer)
							.unwrap();
					}
				} else {
					for pin in &pins {
						pin.verify_checked(&|| Ok(())).unwrap();
					}
				}
			}
			let wall_ns = wall.elapsed().as_nanos();
			let cpu_ns = benchmark_process_cpu_ns() - cpu;
			eprintln!(
				"{}",
				serde_json::json!({
					"benchmark": "profile_pin_set_buffer",
					"variant": if shared { "one_buffer_per_set" } else { "one_buffer_per_pin" },
					"round": round,
					"passes": PASSES,
					"pins_per_pass": pins.len(),
					"buffer_bytes": VERIFY_BUFFER_BYTES,
					"bytes_per_pass": pins.iter().map(|pin| pin.stamp.len).sum::<u64>(),
					"wall_ns": wall_ns,
					"process_cpu_ns": cpu_ns,
				})
			);
		}
	}
}

#[test]
fn directory_identity_survives_owned_membership_but_detects_replacement() {
	let root = tempfile::tempdir().unwrap();
	std::fs::set_permissions(root.path(), std::fs::Permissions::from_mode(0o700)).unwrap();
	let before = private_directory(root.path()).unwrap();
	std::fs::write(root.path().join("owned"), b"bounded").unwrap();
	let after = private_directory(root.path()).unwrap();
	assert!(before.same_directory(&after));
	let other = tempfile::tempdir().unwrap();
	std::fs::set_permissions(other.path(), std::fs::Permissions::from_mode(0o700)).unwrap();
	assert!(!before.same_directory(&private_directory(other.path()).unwrap()));
}

#[test]
fn only_the_fixed_system_shell_alias_has_a_pinned_symlink_exception() {
	let (target, components) = fixed_shell_resolution().unwrap();
	assert_eq!(target, std::fs::canonicalize("/bin/sh").unwrap());
	assert!(components.iter().all(|node| node.stamp.uid == 0));
	let hash = digest(&std::fs::read(&target).unwrap())
		.iter()
		.map(|v| format!("{v:02x}"))
		.collect::<String>();
	let shell = PinnedShell::load(&hash).unwrap();
	shell.verify().unwrap();
	assert!(PinnedShell::load(&"0".repeat(64)).is_err());
	assert!(
		open_absolute(Path::new("/bin/sh"), false).is_err()
			|| std::fs::symlink_metadata("/bin/sh").unwrap().is_file()
	);
}

fn identities(key: &[u8]) -> Vec<u8> {
	let mut bytes = vec![12, 0, 0, 0, 1];
	bytes.extend_from_slice(&(key.len() as u32).to_be_bytes());
	bytes.extend_from_slice(key);
	bytes.extend_from_slice(&0u32.to_be_bytes());
	bytes
}

#[test]
fn agent_frames_are_bounded_exact_and_key_changes_are_not_socket_identity() {
	let first = identities(b"public-test-key-one");
	let second = identities(b"public-test-key-two");
	assert_ne!(
		agent_identities(&first).unwrap(),
		agent_identities(&second).unwrap()
	);
	for bad in [
		vec![],
		vec![5],
		vec![12, 0, 0, 0, 0],
		vec![12, 0, 0, 0, 65],
		first[..first.len() - 1].to_vec(),
	] {
		assert!(agent_identities(&bad).is_err());
	}
	let mut extra = first;
	extra.push(0);
	assert!(agent_identities(&extra).is_err());
	for path in [
		"relative",
		"/private/../socket",
		"/private/./socket",
		"/private/%h",
		"/private/a b",
		"/private/${UNDECLARED}/socket",
		"/private/`command`",
		"/private/\"quoted\"",
		"/private/back\\slash",
	] {
		assert!(absolute(Path::new(path)).is_err());
	}
}

#[tokio::test]
async fn direct_agent_identity_includes_response_bytes_and_rejects_replaced_socket() {
	let root = tempfile::tempdir().unwrap();
	std::fs::set_permissions(root.path(), std::fs::Permissions::from_mode(0o700)).unwrap();
	let path = root.path().join("agent");
	let listener = tokio::net::UnixListener::bind(&path).unwrap();
	std::fs::set_permissions(&path, std::fs::Permissions::from_mode(0o775)).unwrap();
	let server = tokio::spawn(async move {
		for key in [b"key-one".as_slice(), b"key-two".as_slice()] {
			let (mut stream, _) = listener.accept().await.unwrap();
			let mut request = [0; 5];
			stream.read_exact(&mut request).await.unwrap();
			assert_eq!(request, [0, 0, 0, 1, 11]);
			let response = identities(key);
			stream
				.write_all(&(response.len() as u32).to_be_bytes())
				.await
				.unwrap();
			stream.write_all(&response).await.unwrap();
		}
	});
	let first = agent_snapshot(&path, Instant::now() + std::time::Duration::from_secs(2))
		.await
		.unwrap();
	let second = agent_snapshot(&path, Instant::now() + std::time::Duration::from_secs(2))
		.await
		.unwrap();
	assert_eq!(first.stamp, second.stamp);
	assert_ne!(first, second);
	server.await.unwrap();
	std::fs::remove_file(&path).unwrap();
	std::fs::write(&path, b"not a socket").unwrap();
	assert!(
		agent_snapshot(&path, Instant::now() + std::time::Duration::from_secs(1))
			.await
			.is_err()
	);
}

#[tokio::test(flavor = "current_thread")]
async fn owner_rechecks_changed_file_boundaries_after_complete_worker_validation() {
	use super::super::validation::Workers;
	use std::sync::Arc;
	use std::time::Duration;
	for mutation in ["bytes", "replacement", "permissions", "hardlink"] {
		let root = tempfile::tempdir().unwrap();
		let path = root.path().join("worker-pin");
		std::fs::write(&path, b"original").unwrap();
		std::fs::set_permissions(&path, std::fs::Permissions::from_mode(0o600)).unwrap();
		let (pin, _) = PinnedFile::load(&path, None, 1024, true, false).unwrap();
		let pin = Arc::new(pin);
		let checked = pin.clone();
		let stop = tokio_util::sync::CancellationToken::new();
		let workers = Workers::new();
		let ticket = workers
			.run_retained(
				&stop,
				Instant::now() + Duration::from_secs(2),
				move |ticket| checked.verify_checked(&|| ticket.check_current()),
			)
			.await
			.unwrap();
		pin.verify_identity().unwrap();
		match mutation {
			"bytes" => std::fs::write(&path, b"modified").unwrap(),
			"replacement" => {
				std::fs::rename(&path, root.path().join("old")).unwrap();
				std::fs::write(&path, b"original").unwrap();
				std::fs::set_permissions(&path, std::fs::Permissions::from_mode(0o600)).unwrap();
			}
			"permissions" => {
				std::fs::set_permissions(&path, std::fs::Permissions::from_mode(0o644)).unwrap()
			}
			"hardlink" => std::fs::hard_link(&path, root.path().join("alias")).unwrap(),
			_ => unreachable!(),
		}
		assert!(
			ticket
				.finish(|ticket| pin.verify_checked(&|| ticket.check_current()))
				.is_err(),
			"missed {mutation} after worker completion"
		);
		assert!(stop.is_cancelled());
		workers.drain().await.unwrap();
	}
}

#[tokio::test(flavor = "current_thread")]
async fn owner_full_hash_rejects_existing_shared_mapping_tail_change() {
	use super::super::validation::Workers;
	use std::time::Duration;

	struct Mapping {
		address: *mut u8,
		length: usize,
	}
	impl Drop for Mapping {
		fn drop(&mut self) {
			unsafe { libc::munmap(self.address.cast(), self.length) };
		}
	}

	let root = tempfile::tempdir().unwrap();
	let path = root.path().join("owner-mapped-pin");
	let bytes = vec![31; VERIFY_BUFFER_BYTES * 3 + 7];
	std::fs::write(&path, &bytes).unwrap();
	std::fs::set_permissions(&path, std::fs::Permissions::from_mode(0o600)).unwrap();
	let (mut pin, _) = PinnedFile::load(&path, None, bytes.len(), true, false).unwrap();
	let file = std::fs::OpenOptions::new()
		.read(true)
		.write(true)
		.open(&path)
		.unwrap();
	let address = unsafe {
		libc::mmap(
			std::ptr::null_mut(),
			bytes.len(),
			libc::PROT_READ | libc::PROT_WRITE,
			libc::MAP_SHARED,
			file.as_raw_fd(),
			0,
		)
	};
	assert_ne!(address, libc::MAP_FAILED);
	let mapping = Mapping {
		address: address.cast(),
		length: bytes.len(),
	};
	let checked = pin.clone();
	let stop = tokio_util::sync::CancellationToken::new();
	let workers = Workers::new();
	let ticket = workers
		.run_retained(
			&stop,
			Instant::now() + Duration::from_secs(8),
			move |ticket| checked.verify_checked(&|| ticket.check_current()),
		)
		.await
		.unwrap();
	// The writable MAP_SHARED mapping predates the worker. It changes the
	// partial tail after completion without a write/open event as authority.
	unsafe { mapping.address.add(bytes.len() - 1).write_volatile(30) };
	assert_eq!(
		unsafe { libc::msync(address, bytes.len(), libc::MS_SYNC) },
		0
	);
	// Test-only metadata rebasing isolates the content check from timestamp
	// precision. Production never rebases the pin or its expected digest.
	pin.stamp = Stamp::of(&std::fs::metadata(&path).unwrap());
	pin.verify_identity().unwrap();
	let error = ticket
		.finish(|ticket| pin.verify_checked(&|| ticket.check_current()))
		.unwrap_err();
	assert_eq!(error.to_string(), "observation profile changed");
	assert!(stop.is_cancelled());
	workers.drain().await.unwrap();
}

#[tokio::test(flavor = "current_thread")]
async fn worker_full_hash_is_not_replaced_by_owner_metadata_check() {
	use super::super::validation::Workers;
	use std::time::Duration;
	let root = tempfile::tempdir().unwrap();
	let path = root.path().join("complete-worker-pin");
	let mut bytes = vec![23; VERIFY_BUFFER_BYTES * 3 + 7];
	std::fs::write(&path, &bytes).unwrap();
	std::fs::set_permissions(&path, std::fs::Permissions::from_mode(0o600)).unwrap();
	let (mut pin, _) = PinnedFile::load(&path, None, bytes.len(), true, false).unwrap();
	pin.verify().unwrap();
	*bytes.last_mut().unwrap() ^= 1;
	std::fs::write(&path, &bytes).unwrap();
	// Isolate complete-byte verification from the independent metadata fence,
	// as the existing streamed-pin tests do. Production never rebases a pin.
	pin.stamp = Stamp::of(&std::fs::metadata(&path).unwrap());
	pin.verify_identity().unwrap();
	let stop = tokio_util::sync::CancellationToken::new();
	let workers = Workers::new();
	assert!(workers
		.run(&stop, Instant::now() + Duration::from_secs(2), move || pin
			.verify())
		.await
		.is_err());
	assert!(stop.is_cancelled());
	workers.drain().await.unwrap();
}
