#!/usr/bin/env python3
# Copyright 2026 TrillionniumFoundation; SPDX-License-Identifier: Apache-2.0
"""Run one retained attempt of the isolated jobctl mechanism experiment."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time

ROOT = Path("/home/qian/hepta-runtime-optimization-20261104-r16")
PROBE = ROOT / "diagnostics/jobctl-buffer-probe-01"
REVIEW = ROOT / "diagnostics/jobctl-buffer-review"
SOURCE = ROOT / "source"
PROJECT = PROBE / "project"
TARGET = PROBE / "target"
ATTEMPT = PROBE / "attempt-01"
CARGO_HOME_PATH = Path("/home/qian/hepta-runtime-optimization-20261023/cargo-home-a32-a33-r02")
EXPECTED_JOBCTL = "2c8bcbdac8b8fa113526b80a8eda5b40355d20f4cbbb347cc240172c78320983"
EXPECTED_BUNDLE = {
    "candidate.patch": "4627f0a9f70efd40affa918bd03234142f28439914099b4e17c39eb3f1ecd31e",
    "prepare_microbench.py": "228d1e4ff443977b454acbcf61a8d46bb942ac279b60975818449d486681c1be",
    "probe_main.rs.in": "4baf5c30e2d4a54cb3d70ad9cb2a46cf9b1f189a485440772e174d7bebaf8358",
    "probe_wrapper.rs.in": "eb10dafa8d0b65959ec4d61f7d64605db0b032116204537f9b026df9036c545d",
    "review.md": "074c6f217d1c59d061c8a39ba2d085ba156d2b6d8394c25dd73df624fdb55178",
    "summarize_microbench.py": "ae79e111fb5b9ceeac3880e4932a3fd60d13a39969d02159bb6841977849b648",
}

def sha(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()

def source_map():
    qualification = json.loads((ROOT / "qualification-01/report.json").read_text())
    assert qualification.get("qualified") is True
    assert qualification["source_tested"] == qualification["source_after"]
    expected = qualification["source_after"]
    observed = {name: sha(SOURCE / name) for name in expected}
    assert observed == expected, "frozen qualified compiler inputs changed"
    assert observed["src/bin/jobctl.rs"] == EXPECTED_JOBCTL
    return observed

ATTEMPT.mkdir(mode=0o700, exist_ok=False)
report = {
    "schema": "hepta-jobctl-buffer-mechanism-attempt/v1",
    "attempt": 1, "started_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
    "classification": "source-copy local mechanism/components; not operator Python MCP throughput",
    "automatic_retries": 0, "production_changed": False, "service_changes": False,
    "actual_jobctl_control_entry_called": False, "jobs": 1, "stages": [],
    "complete": False,
}

def save():
    temporary = ATTEMPT / "report.next"
    temporary.write_text(json.dumps(report, indent=2) + "\n")
    os.replace(temporary, ATTEMPT / "report.json")

env = dict(os.environ)
removed = []
for key in list(env):
    if key.startswith(("HEPTA_", "SSH_", "RUST_TEST_", "CARGO_PROFILE_", "CARGO_TARGET_", "CARGO_BUILD_")) or key in {
        "RUSTFLAGS", "CARGO_ENCODED_RUSTFLAGS", "RUSTDOCFLAGS", "RUSTC_WRAPPER",
        "RUSTC_WORKSPACE_WRAPPER", "PYTHONPATH", "PYTHONHOME", "RUST_LOG",
        "LD_PRELOAD", "MALLOC_ARENA_MAX",
    }:
        removed.append(key)
        env.pop(key)
env.update({
    "PATH": "/home/qian/.cargo/bin:/usr/local/bin:/usr/bin:/bin",
    "CARGO_HOME": str(CARGO_HOME_PATH), "CARGO_TARGET_DIR": str(TARGET),
    "CARGO_BUILD_JOBS": "1", "CARGO_INCREMENTAL": "0",
    "RUST_TEST_THREADS": "1", "TOKIO_WORKER_THREADS": "1",
    "LC_ALL": "C.UTF-8", "PYTHONDONTWRITEBYTECODE": "1", "PYTHONNOUSERSITE": "1",
})
report["removed_environment_names"] = sorted(removed)
report["environment"] = {key: env[key] for key in [
    "PATH", "CARGO_HOME", "CARGO_TARGET_DIR", "CARGO_BUILD_JOBS", "CARGO_INCREMENTAL",
    "RUST_TEST_THREADS", "TOKIO_WORKER_THREADS", "LC_ALL", "PYTHONDONTWRITEBYTECODE", "PYTHONNOUSERSITE",
]}
report["malloc_arena_max"] = env.get("MALLOC_ARENA_MAX")
cargo = ["/home/qian/.cargo/bin/cargo", "+1.95.0"]

def stage(name, argv, cwd=PROBE, timeout=1800, stdout_name=None):
    stdout_path = ATTEMPT / (stdout_name or name + ".stdout")
    stderr_path = ATTEMPT / (name + ".stderr")
    row = {"name": name, "command": list(map(str, argv)), "cwd": str(cwd),
           "returncode": None, "stdout": str(stdout_path), "stderr": str(stderr_path)}
    report["stages"].append(row)
    report["current_stage"] = name
    save()
    print(json.dumps({"stage": name, "state": "started"}), flush=True)
    started = time.monotonic()
    try:
        with stdout_path.open("xb") as stdout, stderr_path.open("xb") as stderr:
            try:
                result = subprocess.run(row["command"], cwd=cwd, env=env, stdout=stdout, stderr=stderr, timeout=timeout)
                row["returncode"] = result.returncode
            except subprocess.TimeoutExpired:
                row["timed_out"] = True
                raise
    finally:
        row["seconds"] = time.monotonic() - started
        row["stdout_sha256"] = sha(stdout_path)
        row["stderr_sha256"] = sha(stderr_path)
        save()
    print(json.dumps({"stage": name, "exit": row["returncode"], "seconds": row["seconds"]}), flush=True)
    if row["returncode"] != 0:
        raise RuntimeError(name + " failed; no retry and all original logs retained")
    return stdout_path

exit_code = 1
try:
    report["source_before"] = source_map()
    report["runner_sha256"] = sha(__file__)
    report["review_bundle"] = {name: sha(REVIEW / name) for name in EXPECTED_BUNDLE}
    assert report["review_bundle"] == EXPECTED_BUNDLE, "review bundle changed"
    report["qualified_report_sha256"] = sha(ROOT / "qualification-01/report.json")
    save()
    stage("rustc-version", ["/home/qian/.cargo/bin/rustc", "+1.95.0", "-Vv"], timeout=30)
    stage("cargo-version", cargo + ["-V"], timeout=30)
    stage("prepare", ["/usr/bin/python3", "-B", REVIEW / "prepare_microbench.py",
                      "--source", SOURCE, "--output", PROJECT], timeout=60)
    report["prepared_bindings_sha256"] = sha(PROJECT / "bindings.json")
    stage("lockfile", cargo + ["generate-lockfile", "--offline", "--manifest-path", PROJECT / "Cargo.toml"], cwd=PROJECT, timeout=120)
    report["probe_cargo_lock_sha256"] = sha(PROJECT / "Cargo.lock")
    metadata_path = stage("metadata", cargo + ["metadata", "--offline", "--locked", "--format-version=1",
                                               "--manifest-path", PROJECT / "Cargo.toml"], cwd=PROJECT, timeout=120,
                          stdout_name="cargo-metadata.json")
    metadata = json.loads(metadata_path.read_text())
    nodes = {node["id"]: node["features"] for node in metadata["resolve"]["nodes"]}
    report["dependencies"] = [{"name": package["name"], "version": package["version"],
                               "source": package.get("source"), "features": nodes.get(package["id"], [])}
                              for package in metadata["packages"]]
    build_path = stage("build", cargo + ["build", "--offline", "--locked", "--release", "--jobs", "1",
                                         "--message-format=json", "--manifest-path", PROJECT / "Cargo.toml"],
                       cwd=PROJECT, timeout=1800, stdout_name="cargo-build.jsonl")
    events = [json.loads(line) for line in build_path.read_text().splitlines() if line.strip()]
    assert sum(event.get("reason") == "build-finished" and event.get("success") is True for event in events) == 1
    selected = [event for event in events if event.get("reason") == "compiler-artifact"
                and event.get("target", {}).get("name") == "jobctl-buffer-probe" and event.get("executable")]
    assert len(selected) == 1
    artifact = selected[0]
    assert artifact["profile"]["test"] is False
    assert artifact["profile"]["opt_level"] == "3"
    assert artifact["profile"]["debug_assertions"] is False
    retained = PROBE / "artifacts"
    retained.mkdir(mode=0o700)
    binary = retained / "jobctl-buffer-probe"
    shutil.copy2(artifact["executable"], binary)
    assert sha(binary) == sha(artifact["executable"])
    report["binary"] = {"path": str(binary), "sha256": sha(binary), "cargo_profile": artifact["profile"]}
    report["compiled_inputs"] = {str(path.relative_to(PROJECT)): sha(path)
                                 for path in [PROJECT / "Cargo.toml", PROJECT / "Cargo.lock", *sorted((PROJECT / "src").glob("*.rs"))]}
    save()
    fixture_root = PROJECT / "fixtures"
    stage("verify", [binary, "verify", fixture_root], cwd=PROJECT, timeout=180, stdout_name="verify.jsonl")
    stage("oracle", [binary, "oracle", fixture_root], cwd=PROJECT, timeout=180, stdout_name="oracle.jsonl")
    timing_path = stage("timing", [binary, "timing", fixture_root], cwd=PROJECT, timeout=300, stdout_name="timing.jsonl")
    summary_path = PROBE / "summary.json"
    stage("summary", ["/usr/bin/python3", "-B", REVIEW / "summarize_microbench.py",
                     timing_path, summary_path], cwd=PROBE, timeout=30)
    report["summary_sha256"] = sha(summary_path)
    report["binary_after_sha256"] = sha(binary)
    assert report["binary_after_sha256"] == report["binary"]["sha256"]
    report["compiled_inputs_after"] = {name: sha(PROJECT / name) for name in report["compiled_inputs"]}
    assert report["compiled_inputs_after"] == report["compiled_inputs"]
    report["source_after"] = source_map()
    assert report["source_before"] == report["source_after"]
    report["review_bundle_after"] = {name: sha(REVIEW / name) for name in EXPECTED_BUNDLE}
    assert report["review_bundle_after"] == report["review_bundle"]
    report["complete"] = True
    exit_code = 0
except Exception as error:
    report["error"] = f"{type(error).__name__}: {error}"
finally:
    report["finished_utc"] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    save()
    print(json.dumps({"complete": report["complete"], "report": str(ATTEMPT / "report.json"),
                      "error": report.get("error")}), flush=True)
sys.exit(exit_code)
