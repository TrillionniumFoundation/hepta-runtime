// Copyright 2026 TrillionniumFoundation; SPDX-License-Identifier: Apache-2.0
//! Synthetic local mechanism probe; never invokes the privileged control entry point.
use anyhow::{bail, Context, Result};
use serde_json::{json, Value};
use std::cell::Cell;
use std::fs::{self, OpenOptions};
use std::io::{self, BufReader, Cursor, Read};
use std::os::unix::fs::OpenOptionsExt;
use std::path::{Path, PathBuf};
use std::rc::Rc;
use std::time::Instant;

mod baseline;
mod buffered;

const INPUT_MAX: u64 = 1_048_576;
const BUFFER_BYTES: usize = 8192;
const CASES: &[(&str, &str, usize)] = &[
	("json_record", "record.json", 1000),
	("json_witness", "completed/exit.witness", 1000),
	("json_policy", "policy.json", 1000),
	("json_spec", "spec.json", 1000),
	("json_spec_64k", "spec-large.json", 8),
	("status_running", "running", 500),
	("status_completed", "completed", 500),
	("read_completed", "completed", 500),
];

fn process_cpu_ns() -> Result<u128> {
	let mut value: libc::timespec = unsafe { std::mem::zeroed() };
	if unsafe { libc::clock_gettime(libc::CLOCK_PROCESS_CPUTIME_ID, &mut value) } != 0 {
		return Err(io::Error::last_os_error().into());
	}
	Ok(value.tv_sec as u128 * 1_000_000_000 + value.tv_nsec as u128)
}

fn outcome(value: Result<Value>) -> Value {
	match value {
		Ok(value) => json!({"ok": true, "value": value}),
		Err(error) => {
			if let Some(parser) = error.downcast_ref::<serde_json::Error>() {
				json!({
					"ok": false, "kind": "serde",
					"class": format!("{:?}", parser.classify()),
					"line": parser.line(), "column": parser.column(),
					"message": parser.to_string(),
				})
			} else if let Some(io) = error.downcast_ref::<io::Error>() {
				json!({
					"ok": false, "kind": "io",
					"raw_os_error": io.raw_os_error(),
					"error_kind": format!("{:?}", io.kind()),
				})
			} else {
				json!({"ok": false, "kind": "other", "message": format!("{error:#}")})
			}
		}
	}
}

fn equal(case: &str, path: &Path) -> Result<bool> {
	let old = outcome(baseline::diagnostic_value(case, path));
	let new = outcome(buffered::diagnostic_value(case, path));
	if old != new {
		bail!("different diagnostic outcome for {case} at {}", path.display());
	}
	Ok(old["ok"] == true)
}

#[derive(Default)]
struct Counters {
	calls: Cell<u64>,
	bytes: Cell<u64>,
	maximum_request: Cell<usize>,
}

struct Counted<R> {
	reader: R,
	counters: Rc<Counters>,
}

impl<R: Read> Read for Counted<R> {
	fn read(&mut self, destination: &mut [u8]) -> io::Result<usize> {
		self.counters.calls.set(self.counters.calls.get() + 1);
		self.counters.maximum_request.set(
			self.counters.maximum_request.get().max(destination.len()),
		);
		let count = self.reader.read(destination)?;
		self.counters.bytes.set(self.counters.bytes.get() + count as u64);
		Ok(count)
	}
}

fn counted<R: Read>(reader: R, buffered: bool) -> Result<(Value, Rc<Counters>)> {
	let counters = Rc::new(Counters::default());
	let bounded = Counted { reader, counters: counters.clone() }.take(INPUT_MAX + 1);
	let value = if buffered {
		serde_json::from_reader(BufReader::with_capacity(BUFFER_BYTES, bounded))?
	} else {
		serde_json::from_reader(bounded)?
	};
	Ok((value, counters))
}

fn verify(root: &Path) -> Result<()> {
	for &(case, relative, _) in CASES {
		if !equal(case, &root.join(relative))? {
			bail!("valid fixture was rejected: {case}");
		}
		println!("{}", json!({"event":"verified", "case":case, "accepted":true}));
	}
	let mut paths: Vec<_> = fs::read_dir(root.join("boundaries"))?
		.map(|entry| entry.map(|entry| entry.path()))
		.collect::<io::Result<_>>()?;
	paths.sort();
	for path in paths {
		let accepted = equal("json_value", &path)?;
		println!("{}", json!({
			"event":"boundary_equal", "fixture":path.file_name().and_then(|name| name.to_str()),
			"accepted":accepted,
		}));
	}
	// Model bytes appended after the initial metadata point. Both old and
	// proposed adapters expose the same cap; neither adds a growth fence.
	let mut growing = b"{}".to_vec();
	growing.resize((INPUT_MAX + 1) as usize, b' ');
	growing.extend_from_slice(b"foreign trailing bytes outside the reader cap");
	for buffered in [false, true] {
		let (value, count) = counted(Cursor::new(&growing), buffered)?;
		if value != json!({}) || count.bytes.get() != INPUT_MAX + 1 {
			bail!("bounded reader consumed an unexpected prefix");
		}
		println!("{}", json!({
			"event":"take_cap_model", "buffered":buffered,
			"bytes_read":count.bytes.get(), "read_calls":count.calls.get(),
			"accepted_existing_prefix_behavior":true,
		}));
	}
	Ok(())
}

fn oracle(root: &Path) -> Result<()> {
	for &(case, relative, _) in CASES.iter().filter(|(name, _, _)| name.starts_with("json_")) {
		let path = root.join(relative);
		for buffered in [false, true] {
			let file = OpenOptions::new().read(true)
				.custom_flags(libc::O_NOFOLLOW | libc::O_NONBLOCK | libc::O_CLOEXEC)
				.open(&path)?;
			let metadata = file.metadata()?;
			if !metadata.is_file() || metadata.len() > INPUT_MAX {
				bail!("not a bounded regular JSON file");
			}
			let (value, count) = counted(file, buffered)?;
			drop(std::hint::black_box(value));
			println!("{}", json!({
				"event":"untimed_read_oracle", "case":case,
				"variant":if buffered {"buffered_8192"} else {"unbuffered"},
				"file_bytes":metadata.len(),
				"read_calls":count.calls.get(), "bytes_read":count.bytes.get(),
				"maximum_read_request":count.maximum_request.get(),
				"instrumented_not_a_timing_result":true,
			}));
		}
	}
	Ok(())
}

fn timing(root: &Path, selected: Option<&str>, iterations: Option<usize>) -> Result<()> {
	if cfg!(debug_assertions) {
		bail!("build this diagnostic with the recorded release profile");
	}
	let mut matched = false;
	for &(case, relative, default_iterations) in CASES {
		if selected.is_some_and(|selected| selected != case) {
			continue;
		}
		matched = true;
		let path = root.join(relative);
		if !equal(case, &path)? {
			bail!("valid benchmark fixture rejected");
		}
		println!("{}", json!({"event":"equal_before_timing","case":case}));
		baseline::diagnostic_step(case, &path)?;
		buffered::diagnostic_step(case, &path)?;
		let iterations = iterations.unwrap_or(default_iterations);
		if iterations == 0 || iterations > 10_000 {
			bail!("iterations must be in 1..=10000");
		}
		for block in 0..4 {
			for (position, buffered) in [false, true, true, false].into_iter().enumerate() {
				let cpu_start = process_cpu_ns()?;
				let wall_start = Instant::now();
				for _ in 0..iterations {
					if buffered {
						buffered::diagnostic_step(case, &path)?;
					} else {
						baseline::diagnostic_step(case, &path)?;
					}
				}
				let wall_ns = wall_start.elapsed().as_nanos();
				let process_cpu_ns = process_cpu_ns()? - cpu_start;
				println!("{}", json!({
					"event":"timing", "case":case, "block":block, "position":position,
					"variant":if buffered {"buffered_8192"} else {"unbuffered"},
					"iterations":iterations, "wall_ns":wall_ns,
					"process_cpu_ns":process_cpu_ns,
					"debug_assertions":cfg!(debug_assertions),
				}));
			}
		}
	}
	if !matched { bail!("unknown selected case"); }
	Ok(())
}

fn run_probe() -> Result<()> {
	let args: Vec<_> = std::env::args().collect();
	if !(3..=5).contains(&args.len()) {
		bail!("usage: jobctl-buffer-probe MODE FIXTURE_ROOT [CASE] [ITERATIONS]");
	}
	let root = PathBuf::from(&args[2]);
	let iterations = args.get(4).map(|value| value.parse::<usize>()).transpose()?;
	match args[1].as_str() {
		"verify" if args.len() == 3 => verify(&root),
		"oracle" if args.len() == 3 => oracle(&root),
		"timing" => timing(&root, args.get(3).map(String::as_str), iterations),
		_ => bail!("unknown mode or extra mode arguments"),
	}
}

fn main() {
	if let Err(error) = run_probe().context("jobctl-buffer diagnostic") {
		eprintln!("{error:#}");
		std::process::exit(1);
	}
}
