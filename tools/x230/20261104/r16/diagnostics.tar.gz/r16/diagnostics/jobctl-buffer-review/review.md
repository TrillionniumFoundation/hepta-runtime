# jobctl bounded JSON buffering candidate

Status: prepared only. No candidate edit, build, benchmark, service operation, or deployment has been performed for this review. X230 access stopped when the parent began formal R16 measurements. These files are staged locally for later delivery to the R16 diagnostics/jobctl-buffer-review directory.

## Exact source and scope

Baseline: /home/qian/hepta-runtime-optimization-20261104-r16/source/src/bin/jobctl.rs

SHA-256: 2c8bcbdac8b8fa113526b80a8eda5b40355d20f4cbbb347cc240172c78320983

Cargo.lock SHA-256: 15b9fb468eb34a210238657d132cbf19e961552d1313de488e1f14936bfa4e5f

The only production occurrence of from_reader under R16/source/src is jobctl.rs:159. Its json_file helper opens a File, checks its initial metadata, and passes File.take(INPUT_MAX + 1) directly to serde_json::from_reader. The pinned serde_json 1.0.151 source constructs IoRead with LineColIterator<io::Bytes<R>> at read.rs:149–153 and reader.bytes() at 200–202. The upstream documentation explicitly states that it does not buffer File reads.

Sources:

- https://docs.rs/serde_json/1.0.151/serde_json/fn.from_reader.html
- https://doc.rust-lang.org/std/io/struct.BufReader.html
- /home/qian/hepta-runtime-optimization-20261023/cargo-home-a32-a33-r02/registry/src/index.crates.io-1949cf8c6b5b557f/serde_json-1.0.151/src/read.rs

This candidate belongs to the system jobctl backend. jobs.rs:4369–4370 sets system_jobctl only for Linux + ExecutionMode::Isolated. Operator jobs use the Python backend. It cannot improve the current operator/Python six-alias observation benchmark. Report jobctl measurements separately.

## Reachable paths

| Input | Call site | Relevant operations |
| --- | --- | --- |
| record.json | load_record, 439–447 | status, read, cancel, start/reconciliation paths |
| administrator policy | policy, 449–465 | start / pty setup |
| exit.witness | observe_terminal, 609–618 | versioned completed status/read, including pending publication |
| credential spec | supervise, 1356–1364 | supervisor startup, both captured and PTY modes |

exit.json already uses json_bytes, read_to_end, and from_slice at 134–148 and 586–595. It is outside this optimization. Log pages use bounded read_to_end at 788–837 and are also outside it. Controller replies use from_slice. Do not conflate the native helper's file input with the runtime's controller record parser or SSH reply decoder.

## Minimum change and retained contract

candidate.patch only wraps the bounded reader with an explicit 8 KiB BufReader. The capacity is fixed, independent of LOG_BUFFER, so changing log capture tuning cannot silently alter JSON buffering.

All existing checks remain in their original order:

1. Fresh OpenOptions read-only open with O_NOFOLLOW | O_NONBLOCK | O_CLOEXEC.
2. fstat of that same descriptor.
3. Refuse a non-regular inode or an initial length above INPUT_MAX = 1,048,576.
4. Limit reads from the underlying descriptor with Take(INPUT_MAX + 1).
5. Deserialize the same T with serde_json::from_reader, retaining its trailing-input / EOF validation.
6. Propagate the same anyhow/serde/io failure path to the existing caller.

Take must be INSIDE BufReader. BufReader<File>.take(limit) may prefetch bytes past the underlying byte budget. BufReader<Take<File>> preserves the physical read cap, including lookahead for EOF or trailing data.

The File is owned by this invocation and discarded at return. No caller reuses its cursor, buffered tail, or descriptor. There is no shared buffer, retained file handle, parse-result cache, cross-call policy cache, extra retry, or change to status/read publication ordering.

### Limits of the existing contract

- json_file has no post-read fstat, inode/mtime fence, or explicit growth-length rejection. Its sibling json_bytes does have a post-read byte-length rejection. Do not replace json_file with json_bytes/from_slice as part of this narrow candidate: that changes behavior for growth after initial metadata.
- A concurrent append or in-place rewrite is not an atomic snapshot in either implementation. Larger read batches alter possible read timing; do not claim identical interleavings. The input publication protocol normally uses fresh descriptors and atomic replacement, which the candidate retains.
- Buffering can physically read more bytes before reporting an early syntax error. Those bytes are still limited by the inner Take. Error acceptance/rejection for stable bytes and the caller's error mapping must remain unchanged.
- O_NOFOLLOW here applies to the final path component. This helper does not implement the observation profile's per-component no-symlink traversal.
- The helper does not itself reject hardlinks or check owner/mode. policy performs its own root-owner/non-writable check. Do not attribute additional checks to json_file.
- Policy and Request deny unknown fields; Record, Spec, and TerminalWitness retain their current serde behavior. Buffering must not alter schema choices.

### Caller error behavior to preserve

load_record keeps the “unknown owned job” context and its separate job/unit identity check. policy keeps the existing administrator ownership, canonical workspace, and resource-limit checks. supervise keeps non-root and credential job/boot identity checks.

For a versioned receipt, a missing, malformed, oversized, symlinked, or otherwise unreadable witness still becomes terminal_witness_unavailable. A well-formed foreign witness still becomes terminal_witness_mismatch. No failure may promote a finalizing/publication_pending result to an authoritative exit.

status_at must continue to inspect terminal publication before a boot/probe decision and again after the systemctl observation (727–777). The global status lock, syscall probe, fsync barriers, witness digest, log length checks, and cancel/start behavior are untouched.

## Existing test coverage that must run on the eventual candidate

All tests are in source/src/jobctl_tests.rs and are part of the hepta-runtime-jobctl test binary. Run the complete binary once; these names identify the specific contracts:

| Contract | Existing tests |
| --- | --- |
| nonblocking non-regular JSON refusal | json_fifo_rejected_without_waiting_for_a_writer |
| no invented terminal outcome | versioned_status_without_terminal_receipt_never_invents_a_terminal_outcome; versioned_reboot_without_a_receipt_is_unknown_and_never_replayed |
| pre/post systemctl publication race | status_rereads_terminal_publication_after_systemd_collection_or_probe_error; status_rereads_unwitnessed_publication_before_interpreting_unit_failure |
| boot race and retained probe error | terminal_publication_during_boot_probe_remains_valid_after_reboot; probe_failure_without_a_terminal_receipt_stays_an_error |
| witness identity / exact exit bytes | witness_binds_exact_exit_bytes_identity_protocol_and_new_record_marker |
| conservative witness publication | actual_witness_publication_failure_cannot_promote_visible_exit; visible_witness_proves_prior_exit_barrier_not_its_own_directory_sync |
| foreign/inconsistent captures | read_and_status_refuse_foreign_or_inconsistent_terminal_capture_evidence |
| read cursor/bytes/capture durability | cap_plus_one_retains_the_bound_and_reports_lost_output_in_status_and_reads; confirmed_capture_reads_reject_deleted_truncated_or_appended_logs; confirmed_capture_pages_preserve_all_bytes_and_standard_digest_wire_format |
| preserved cancellation result | cancellation_ack_cannot_overwrite_a_witnessed_original_exit |

Necessary narrow additions for a future source change:

- Stable-byte baseline vs buffered parsing for every actual type: valid files, empty input, invalid UTF-8, truncated JSON, trailing whitespace, trailing second value, wrong field types, missing fields, and current unknown-field behavior.
- Lengths around 8 KiB and the 1 MiB initial metadata limit; exact maximum valid JSON accepted, maximum + 1 initially refused.
- Instrumented underlying reader verifies physical reads never exceed INPUT_MAX + 1 with the limiter inside the buffer, including a modeled append after the metadata point.
- Short reads, Interrupted, and a deterministic I/O failure after a known prefix preserve refusal and EOF/error handling. Compare parse categories/positions for stable byte errors; do not promise syscall-failure timing equality under arbitrary concurrent mutation.
- Final-component symlink, directory, FIFO, and unreadable file refusal, without changing the original hardlink or intermediate-path policy.
- Invalid/missing/oversized witness produces the same conservative status AND read result.

## Prepared mechanism experiment

prepare_microbench.py is NOT executed. It creates an isolated miniature Cargo project containing two diagnostic copies of the frozen jobctl source, with identical wrappers. The buffered copy changes only the reader expression shown in candidate.patch. The original control entry point is never called. The production source is only read and hashed.

The probe has three modes:

- verify: compare typed parsing and actual copied status_at/read_output_at results, plus malformed/boundary/non-regular fixtures.
- oracle: count underlying Read calls and consumed bytes in an UNTIMED adapter. This proves the mechanism; its instrumentation must not enter timing results.
- timing: same-process ABBA, four blocks per scenario, fresh File open for every operation, unchanged input bytes, process CPU and wall time, no counted reader and no strace.

Component scenarios use the real copied jobctl status_at/read_output_at bodies with private synthetic files. The status probe closure is injected; they do NOT include sudo, systemctl, SSH, the global control lock, or actual service dispatch. Name them “jobctl component” measurements, never multi-machine MCP throughput.

Future commands, only after the parent reopens the measurement window:

    python3 prepare_microbench.py --source /home/qian/hepta-runtime-optimization-20261104-r16/source --output ./project
    cd project
    CARGO_HOME=/home/qian/hepta-runtime-optimization-20261023/cargo-home-a32-a33-r02 CARGO_BUILD_JOBS=2 CARGO_INCREMENTAL=0 /home/qian/.cargo/bin/cargo +1.95.0 generate-lockfile --offline
    CARGO_HOME=/home/qian/hepta-runtime-optimization-20261023/cargo-home-a32-a33-r02 CARGO_BUILD_JOBS=2 CARGO_INCREMENTAL=0 /home/qian/.cargo/bin/cargo +1.95.0 build --release --offline --locked
    ./target/release/jobctl-buffer-probe verify ./fixtures > verify.jsonl 2> verify.stderr
    ./target/release/jobctl-buffer-probe oracle ./fixtures > oracle.jsonl 2> oracle.stderr
    ./target/release/jobctl-buffer-probe timing ./fixtures > timing.jsonl 2> timing.stderr
    python3 ../summarize_microbench.py timing.jsonl summary.json

Use the same sanitized build environment as qualification, with profile/target/build override variables removed before applying the shown values. Save the mini-project's Cargo.lock, source bindings, toolchain version, build logs, command/exit codes, and resulting binary SHA-256. The miniature crate pins direct dependencies to the frozen Cargo.lock and uses release opt-level 3, LTO, one codegen unit and panic=abort. Its overall dependency features / whole-program context are not the production crate's qualification. Treat it as mechanism evidence only.

Optional syscall corroboration may use a separate one-iteration trace. Never time under strace or include the counted reader in the ABBA timings.

## Actual helper / backend acceptance

After a separately qualified source candidate exists, run the complete jobctl unit suite and the actual runtime's SystemStatus/SystemRead integration/recovery coverage. For a live backend measurement, use an explicitly jobctl-backed Linux isolated target and a dedicated owned fixture; retain job ID, initial binary hashes, record/receipt/witness identity, cursor behavior, and before/after status/read outputs.

The exact configured sudo capability points at /usr/local/libexec/hepta-runtime-jobctl. A diagnostic copy elsewhere is not a deployed backend. Do not bypass that capability with an arbitrary sudo shell or silently install the candidate. A live helper change, if later selected by the parent, needs the normal controlled deployment/rollback process and separate baseline/candidate measurements.

Measure running jobs, completed witnessed jobs, pending publication, and 0/64/16,384-byte log pages separately. Completed status/read usually parse one Record and one Witness. Running status adds a systemctl probe and holds the existing global status lock, so parser speedup is only one component. Report both helper CPU and end-to-end latency; no improvement is asserted before measurements.
