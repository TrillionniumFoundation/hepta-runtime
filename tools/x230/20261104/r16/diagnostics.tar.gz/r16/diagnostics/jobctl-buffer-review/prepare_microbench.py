#!/usr/bin/env python3
# Copyright 2026 TrillionniumFoundation
# SPDX-License-Identifier: Apache-2.0
"""Prepare an isolated jobctl mechanism probe; never build or execute it."""
import argparse
import copy
import hashlib
import json
import os
from pathlib import Path
import tomllib

SOURCE_SHA256 = "2c8bcbdac8b8fa113526b80a8eda5b40355d20f4cbbb347cc240172c78320983"
LOCK_SHA256 = "15b9fb468eb34a210238657d132cbf19e961552d1313de488e1f14936bfa4e5f"
INPUT_MAX = 1_048_576
OLD = "\tOk(serde_json::from_reader(f.take(INPUT_MAX + 1))?)"
NEW = """\tOk(serde_json::from_reader(std::io::BufReader::with_capacity(
\t\t8192,
\t\tf.take(INPUT_MAX + 1),
\t))?)"""
FOOTER = '\n#[cfg(test)]\n#[path = "../jobctl_tests.rs"]\nmod tests;\n'


def digest(data):
    return hashlib.sha256(data).hexdigest()


def write(path, data):
    path.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
    with path.open("xb") as stream:
        stream.write(data)
    path.chmod(0o600)


def write_json(path, value):
    data = json.dumps(value, ensure_ascii=False, separators=(",", ":")).encode() + b"\n"
    write(path, data)
    return data


def dependency_versions(lock):
    packages = lock["package"]
    owners = [package for package in packages
              if package["name"] == "hepta-runtime" and "source" not in package]
    assert len(owners) == 1
    owner = owners[0]
    result = {}
    for name in ["anyhow", "serde", "serde_json", "sha2", "libc"]:
        selectors = [entry.split() for entry in owner["dependencies"]
                     if entry.split()[0] == name]
        assert len(selectors) == 1, name
        requested = selectors[0][1] if len(selectors[0]) > 1 else None
        matches = [package for package in packages
                   if package["name"] == name
                   and (requested is None or package["version"] == requested)]
        assert len(matches) == 1, (name, requested)
        result[name] = matches[0]["version"]
    assert result["serde_json"] == "1.0.151"
    return result


def fixtures(root):
    job = "buffer-review"
    record = {
        "job_id": job, "unit": f"hepta-job-{job}.service",
        "request_digest": "a" * 64, "boot_id": "fixture-boot",
        "nonce": "private-synthetic-nonce", "invocation_id": "original-invocation",
        "launch_state": "launched", "created_unix_ms": 1,
        "terminal_protocol": "captured_v1",
    }
    write_json(root / "record.json", record)
    write_json(root / "running/record.json", record)
    write_json(root / "completed/record.json", record)
    policy = {
        "workspace": "/var/lib/hepta-runtime/workspaces/fixture",
        "allow_network": False, "max_timeout_seconds": 3600,
        "max_cpu_percent": 100, "max_memory_bytes": 1_073_741_824,
    }
    write_json(root / "policy.json", policy)
    request = {
        "op": "start", "job_id": job, "executable": "/usr/bin/true",
        "args": [], "cwd": policy["workspace"], "env": {}, "stdin": None,
        "timeout_seconds": 60, "nice": 0, "cpu_quota_percent": 100,
        "memory_max_bytes": 67_108_864, "stdout_offset": 0,
        "stderr_offset": 0, "limit": 16384,
    }
    spec = {
        "request": request, "nonce": record["nonce"], "boot_id": record["boot_id"],
        "workspace": policy["workspace"], "terminal_protocol": "captured_v1",
    }
    write_json(root / "spec.json", spec)
    large_spec = copy.deepcopy(spec)
    large_spec["request"]["stdin"] = "z" * 65536
    write_json(root / "spec-large.json", large_spec)
    capture = {}
    for stream, data in [("stdout", b"buffer review stdout\n"),
                         ("stderr", b"buffer review stderr\n")]:
        write(root / "completed" / f"{stream}.log", data)
        capture[stream] = {
            "seen": len(data), "saved": len(data), "eof": True,
            "truncated": False, "drain_timeout": False,
            "read_error": None, "write_error": None, "sync_error": None,
            "synced": True,
        }
    receipt = {
        "job_id": job, "nonce": record["nonce"], "exit_code": 0,
        "timed_out": False, "cancelled": False, "at_unix_ms": 2,
        "terminal_protocol": "captured_v1", "output_complete": True,
        "output_durable": True, "capture": capture,
    }
    receipt_bytes = write_json(root / "completed/exit.json", receipt)
    write_json(root / "completed/exit.witness", {
        "job_id": job, "nonce": record["nonce"],
        "terminal_protocol": "captured_v1", "exit_sha256": digest(receipt_bytes),
    })
    boundaries = root / "boundaries"
    boundaries.mkdir(mode=0o700)
    cases = {
        "empty.json": b"",
        "whitespace.json": b" \r\n\t",
        "valid.json": b'{"value":1}\n',
        "truncated.json": b'{"value":',
        "trailing_value.json": b'{"value":1}{"second":2}',
        "trailing_invalid.json": b'{"value":1}x',
        "invalid_utf8.json": b'{"value":"\xff"}',
        "nested_too_deep.json": b"[" * 129 + b"0" + b"]" * 129,
    }
    prefix, suffix = b'{"padding":"', b'"}'
    for length in [8191, 8192, 8193, INPUT_MAX, INPUT_MAX + 1]:
        cases[f"length_{length}.json"] = prefix + b"a" * (length - len(prefix) - len(suffix)) + suffix
    for name, data in cases.items():
        write(boundaries / name, data)
    os.symlink("valid.json", boundaries / "final_symlink.json")
    os.link(boundaries / "valid.json", boundaries / "hardlink.json")
    (boundaries / "directory.json").mkdir(mode=0o700)
    os.mkfifo(boundaries / "fifo.json", 0o600)
    write(boundaries / "permission_denied.json", b"{}")
    (boundaries / "permission_denied.json").chmod(0)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    args = parser.parse_args()
    package = Path(__file__).resolve().parent
    source_path = args.source / "src/bin/jobctl.rs"
    original_bytes = source_path.read_bytes()
    assert digest(original_bytes) == SOURCE_SHA256, "frozen jobctl source changed"
    lock_bytes = (args.source / "Cargo.lock").read_bytes()
    assert digest(lock_bytes) == LOCK_SHA256, "frozen Cargo.lock changed"
    versions = dependency_versions(tomllib.loads(lock_bytes.decode()))
    original = original_bytes.decode()
    assert original.count(OLD) == 1
    assert original.count(FOOTER) == 1
    candidate = original.replace(OLD, NEW)
    output = args.output.resolve()
    output.mkdir(mode=0o700, parents=False, exist_ok=False)
    wrapper = (package / "probe_wrapper.rs.in").read_text()
    # These common changes affect only diagnostic copies: remove the test
    # module (the mini-project builds a normal executable), allow unused
    # original helper functions, and append identical local entry wrappers.
    for name, content in [("baseline", original), ("buffered", candidate)]:
        module = "#![allow(dead_code)]\n" + content.replace(FOOTER, "\n") + "\n" + wrapper
        write(output / "src" / f"{name}.rs", module.encode())
    write(output / "src/main.rs", (package / "probe_main.rs.in").read_bytes())
    dependencies = "\n".join(
        f'{name} = {{ version = "={version}", features = ["derive"] }}'
        if name == "serde" else f'{name} = "={version}"'
        for name, version in versions.items()
    )
    manifest = (
        '[package]\nname = "jobctl-buffer-probe"\nversion = "0.0.0"\nedition = "2021"\n'
        'publish = false\n\n[dependencies]\n' + dependencies +
        '\n\n[profile.release]\nopt-level = 3\nlto = true\ncodegen-units = 1\n'
        'panic = "abort"\nstrip = true\noverflow-checks = false\n'
    )
    write(output / "Cargo.toml", manifest.encode())
    fixtures(output / "fixtures")
    bindings = {
        "schema": "jobctl-buffer-mechanism-inputs/v1",
        "state": "prepared_not_built_or_executed",
        "frozen_source": str(source_path), "source_sha256": SOURCE_SHA256,
        "candidate_source_sha256": digest(candidate.encode()),
        "source_cargo_lock_sha256": LOCK_SHA256,
        "direct_dependencies": versions,
        "only_candidate_change": "BufReader::with_capacity(8192, File.take(INPUT_MAX + 1))",
        "scope": "synthetic local parser and copied jobctl components; no sudo/systemctl/SSH",
        "files": {},
    }
    for path in sorted(output.rglob("*")):
        # Never open fixture FIFOs or dereference symlinks. The mode-000 case
        # is recorded separately; preparation still works as an unprivileged account.
        if path.is_symlink() or not path.is_file():
            continue
        if path.name == "permission_denied.json":
            bindings["files"][str(path.relative_to(output))] = {
                "bytes": 2, "sha256": digest(b"{}"), "mode": "000",
            }
        else:
            data = path.read_bytes()
            bindings["files"][str(path.relative_to(output))] = {
                "bytes": len(data), "sha256": digest(data),
            }
    write(output / "bindings.json", (json.dumps(bindings, indent=2) + "\n").encode())
    print(json.dumps({"prepared": str(output), "compiled": False, "executed": False}))


if __name__ == "__main__":
    main()
