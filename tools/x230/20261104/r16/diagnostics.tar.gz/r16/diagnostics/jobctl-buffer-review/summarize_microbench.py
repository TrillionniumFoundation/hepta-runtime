#!/usr/bin/env python3
# Copyright 2026 TrillionniumFoundation
# SPDX-License-Identifier: Apache-2.0
"""Independently summarize complete ABBA blocks from the prepared diagnostic."""
import argparse
import hashlib
import json
import statistics
from pathlib import Path


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("input", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    rows = []
    for number, line in enumerate(args.input.read_text().splitlines(), 1):
        if not line.strip():
            continue
        event = json.loads(line)
        if event.get("event") == "timing":
            assert event["debug_assertions"] is False, "refusing debug timing label"
            assert event["iterations"] > 0
            rows.append(event)
        elif event.get("event") != "equal_before_timing":
            raise ValueError(f"unexpected record at line {number}")
    assert rows, "no timing records"
    cases = sorted({row["case"] for row in rows})
    result = {
        "schema": "jobctl-buffer-microbenchmark-summary/v1",
        "classification": "synthetic local jobctl mechanism/component; not MCP throughput",
        "input_sha256": hashlib.sha256(args.input.read_bytes()).hexdigest(),
        "all_blocks_retained": True,
        "cases": {},
    }
    for case in cases:
        selected = [row for row in rows if row["case"] == case]
        assert len(selected) == 16, (case, len(selected))
        expected = {(block, position) for block in range(4) for position in range(4)}
        assert {(row["block"], row["position"]) for row in selected} == expected
        assert len({(row["block"], row["position"]) for row in selected}) == len(selected)
        costs = {"unbuffered": {"cpu": [], "wall": []},
                 "buffered_8192": {"cpu": [], "wall": []}}
        paired = {"cpu": [], "wall": []}
        for block in range(4):
            group = sorted((row for row in selected if row["block"] == block),
                           key=lambda row: row["position"])
            assert [row["variant"] for row in group] == [
                "unbuffered", "buffered_8192", "buffered_8192", "unbuffered"
            ]
            assert len({row["iterations"] for row in group}) == 1
            for metric, field in [("cpu", "process_cpu_ns"), ("wall", "wall_ns")]:
                by_variant = {}
                for variant in costs:
                    values = [row[field] / row["iterations"] / 1000
                              for row in group if row["variant"] == variant]
                    assert all(value > 0 for value in values)
                    by_variant[variant] = statistics.mean(values)
                    costs[variant][metric].extend(values)
                paired[metric].append(
                    100 * (1 - by_variant["buffered_8192"] / by_variant["unbuffered"])
                )
        result["cases"][case] = {
            "unit": "microseconds per local diagnostic operation",
            "variant_costs": {
                variant: {
                    metric: {"median": statistics.median(values),
                             "min": min(values), "max": max(values)}
                    for metric, values in metrics.items()
                } for variant, metrics in costs.items()
            },
            "paired_block_improvement_pct": {
                metric: {"all": values, "median": statistics.median(values),
                         "min": min(values), "max": max(values)}
                for metric, values in paired.items()
            },
        }
    with args.output.open("x") as stream:
        json.dump(result, stream, indent=2)
        stream.write("\n")


if __name__ == "__main__":
    main()
