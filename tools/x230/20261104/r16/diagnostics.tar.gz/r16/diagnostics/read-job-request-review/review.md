# read_job: delay the legacy Python request Value until it is used

## Decision and scope

This is an unapplied follow-up candidate for the frozen R16 source. It only moves construction of one serde_json::Value into the sole branch that uses it. No runtime source was edited, built, tested, benchmarked, or deployed by this review.

Baseline: /home/qian/hepta-runtime-optimization-20261104-r16/source/src/mcp/runtime/jobs.rs. The exact SHA-256 is recorded in identity.json. The patch is intentionally independent of the profile preprocessing / hash-buffer candidate and the jobctl BufReader candidate.

## Source evidence

read_job (baseline lines 4442–4503) creates the legacy Python request at 4449–4457 before choosing a transport/backend. It includes job_id, job_dir, request_digest, unit, stdout_offset, stderr_offset, and limit. Only the direct legacy Python branch at 4486–4492 uses this Value.

The pool/native branch constructs JobObservation::SystemRead from borrowed job_id and scalar arguments; the pool/Python branch constructs JobObservation::PythonRead; the direct/native branch independently constructs its closed jobctl JSON request. In those three branches, the earlier legacy Value is unused.

## Proposed change

Move the identical request expression immediately inside the direct legacy Python else branch, before run_python_json. Preserve the runtime_config/host lookup and its error behavior at the original position. Preserve every default, offset, request_digest field, and MAX_LOG_READ_BYTES clamp exactly.

This removes an unnecessary Value/map/string construction on native reads and pool/Python reads at source level. No measured CPU, latency, throughput, or RSS improvement is claimed. Optimizer behavior and the share of these allocations in a real request must be measured; the observed native ~72 ms controller CPU/call cannot be attributed to this expression.

## Routing and contract review

| Route | Request after patch | Behavioral boundary |
|---|---|---|
| Pool + native jobctl | Existing SystemRead | Same job ID, offsets, limit, typed preparation and full pool validation |
| Pool + Python | Existing PythonRead | Same job directory, unit, request digest, bounds and fixed script |
| Direct + native jobctl | Existing jobctl JSON | Same request and sudo/helper path |
| Direct + legacy Python | Identical moved legacy Value | Same fields, defaults, clamp, bound_remote_code and timeout |

check_ref_async, check_binding, runtime_config/host lookup, pool admission, fixed pin verification, original owner acceptance, cancellation/reaping, and observation_completion_audit remain in the same order. The patch does not cache values, retain descriptors, skip content reads, weaken durability, alter schemas, or change a resource limit.

The moved expression contains only serialization of immutable record fields, Options, and integer parameters. Its useful result is not observable on the other branches. Allocation failure timing is the ordinary implementation-level consequence of removing unused allocations; no successful/error protocol result is intentionally changed.

## Validation and acceptance

Only deterministic source transformation checks were run: the original block and insertion anchor each occur once; the unified diff contains that move only; the frozen source SHA-256 remains unchanged after writing diagnostics. No Rust test or benchmark was run here.

If adopted into a later candidate, apply only to the bound source identity (or manually review any mismatch), inspect the resulting diff, and include the ordinary full qualification. Existing route coverage should continue to exercise all four paths, especially null/non-null request_digest and limit default/clamp behavior in the legacy route. Performance reporting must separate native/Python, status/read, and controller/helper CPU. A combined qualification with jobctl buffering does not establish separate performance attribution.

Files: request-value-lazy.patch, proposed-read_job.rs.txt, identity.json.
