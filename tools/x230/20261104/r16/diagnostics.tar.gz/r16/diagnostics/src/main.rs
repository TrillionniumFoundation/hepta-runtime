// Copyright 2026 TrillionniumFoundation
// Standalone diagnostic: complete public-file SHA256 on every iteration.
// No runtime configuration, credential, private key, or production state is read.
use ring::digest::{Context, SHA256};
use std::fs::{self, File, Metadata};
use std::io::{self, Read};
use std::os::raw::{c_int, c_long};
use std::os::unix::fs::MetadataExt;
use std::path::{Path, PathBuf};
use std::time::Instant;

#[repr(C)]
struct Timespec { tv_sec: c_long, tv_nsec: c_long }
unsafe extern "C" { fn clock_gettime(clock_id: c_int, ts: *mut Timespec) -> c_int; }
fn cpu_ns() -> io::Result<u128> {
    let mut ts = Timespec { tv_sec: 0, tv_nsec: 0 };
    // Linux CLOCK_PROCESS_CPUTIME_ID includes user and system CPU for this process.
    if unsafe { clock_gettime(2, &mut ts) } != 0 { return Err(io::Error::last_os_error()); }
    Ok(ts.tv_sec as u128 * 1_000_000_000 + ts.tv_nsec as u128)
}
#[derive(PartialEq, Eq, Clone)]
struct Stamp { dev: u64, ino: u64, len: u64, mode: u32, nlink: u64, mtime: i64, mtime_ns: i64, ctime: i64, ctime_ns: i64 }
impl From<Metadata> for Stamp {
    fn from(m: Metadata) -> Self {
        Self { dev: m.dev(), ino: m.ino(), len: m.len(), mode: m.mode(), nlink: m.nlink(), mtime: m.mtime(), mtime_ns: m.mtime_nsec(), ctime: m.ctime(), ctime_ns: m.ctime_nsec() }
    }
}
struct FileCase { path: PathBuf, stamp: Stamp, expected: [u8; 32] }
struct HashResult { digest: [u8; 32], bytes: u64, calls: u64, interrupted: u64 }
fn fail(message: &str) -> io::Error { io::Error::other(message) }
fn hash_file<const N: usize>(case: &FileCase) -> io::Result<HashResult> {
    // Open a new descriptor each time; metadata on both sides fences the full read.
    let mut file = File::open(&case.path)?;
    if Stamp::from(file.metadata()?) != case.stamp || Stamp::from(fs::symlink_metadata(&case.path)?) != case.stamp {
        return Err(fail("public file identity changed before hashing"));
    }
    let mut hash = Context::new(&SHA256);
    let mut buffer = [0u8; N];
    let mut bytes = 0u64;
    let mut calls = 0u64;
    let mut interrupted = 0u64;
    {
        let mut reader = Read::by_ref(&mut file).take(16 * 1024 * 1024 + 1);
        loop {
            calls += 1;
            let count = match reader.read(&mut buffer) {
                Err(error) if error.kind() == io::ErrorKind::Interrupted => { interrupted += 1; continue; },
                result => result?,
            };
            if count == 0 { break; }
            hash.update(&buffer[..count]);
            bytes += count as u64;
        }
    }
    if bytes != case.stamp.len || Stamp::from(file.metadata()?) != case.stamp || Stamp::from(fs::symlink_metadata(&case.path)?) != case.stamp {
        return Err(fail("public file identity changed during hashing"));
    }
    let mut digest = [0u8; 32];
    digest.copy_from_slice(hash.finish().as_ref());
    if digest != case.expected { return Err(fail("full-content SHA256 mismatch")); }
    Ok(HashResult { digest, bytes, calls, interrupted })
}
fn run<const N: usize>(cases: &[FileCase], iterations: usize) -> io::Result<()> {
    for case in cases {
        // Warmup is explicit and unmeasured. Every later iteration rereads every byte.
        for _ in 0..8 { let _ = hash_file::<N>(case)?; }
        let cpu_start = cpu_ns()?;
        let start = Instant::now();
        let mut total_bytes = 0u64;
        let mut total_calls = 0u64;
        let mut interrupted = 0u64;
        let mut last = [0u8; 32];
        for _ in 0..iterations {
            let output = hash_file::<N>(case)?;
            total_bytes += output.bytes;
            total_calls += output.calls;
            interrupted += output.interrupted;
            last = output.digest;
        }
        let elapsed_ns = start.elapsed().as_nanos();
        let cpu_used_ns = cpu_ns()? - cpu_start;
        let hex = last.iter().map(|b| format!("{b:02x}")).collect::<String>();
        println!("{{\"path\":\"{}\",\"chunk_bytes\":{},\"iterations\":{},\"full_hash_checks\":{},\"bytes_read\":{},\"read_calls_including_eof\":{},\"interrupted_read_calls\":{},\"sha256\":\"{}\",\"elapsed_ns\":{},\"cpu_ns\":{}}}",
            case.path.display(), N, iterations, iterations, total_bytes, total_calls, interrupted, hex, elapsed_ns, cpu_used_ns);
    }
    Ok(())
}
fn main() -> Result<(), Box<dyn std::error::Error>> {
    let args: Vec<String> = std::env::args().collect();
    let size: usize = args.get(1).ok_or("missing chunk bytes")?.parse()?;
    let iterations: usize = args.get(2).ok_or("missing iterations")?.parse()?;
    if !(1..=10_000).contains(&iterations) { return Err("iterations outside bounded range".into()); }
    let mut cases = Vec::new();
    for path in ["/usr/bin/ssh", "/usr/bin/false", "/bin/sh"] {
        let resolved = fs::canonicalize(Path::new(path))?;
        let before = Stamp::from(fs::symlink_metadata(&resolved)?);
        if before.len > 16 * 1024 * 1024 { return Err("public binary too large".into()); }
        let bytes = fs::read(&resolved)?;
        let after = Stamp::from(fs::symlink_metadata(&resolved)?);
        if before != after || bytes.len() as u64 != before.len { return Err("public file changed while binding baseline".into()); }
        let mut expected = [0u8; 32];
        expected.copy_from_slice(ring::digest::digest(&SHA256, &bytes).as_ref());
        cases.push(FileCase { path: resolved, stamp: before, expected });
    }
    match size { 16384 => run::<16384>(&cases, iterations)?, 65536 => run::<65536>(&cases, iterations)?, 262144 => run::<262144>(&cases, iterations)?, _ => return Err("unsupported chunk size".into()) }
    Ok(())
}
