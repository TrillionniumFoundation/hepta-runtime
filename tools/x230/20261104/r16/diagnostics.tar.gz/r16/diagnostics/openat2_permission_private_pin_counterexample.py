#!/usr/bin/env python3
"""Real-kernel permission parity counterexample for a rejected openat2 fast path."""
from pathlib import Path
import ctypes,errno,hashlib,json,os,platform,re,shutil,tempfile
ROOT=Path(__file__).resolve().parent
if platform.machine()!='x86_64':raise RuntimeError('diagnostic only binds observed X230 x86_64 ABI')
header=Path('/usr/include/x86_64-linux-gnu/asm/unistd_64.h')
match=re.search(r'^#define\s+__NR_openat2\s+(\d+)\s*$',header.read_text(),re.M)
if not match:raise RuntimeError('openat2 syscall number unavailable in native header')
NUMBER=int(match.group(1))
class OpenHow(ctypes.Structure):
    _fields_=[('flags',ctypes.c_uint64),('mode',ctypes.c_uint64),('resolve',ctypes.c_uint64)]
libc=ctypes.CDLL(None,use_errno=True)
libc.syscall.restype=ctypes.c_long
FLAGS=os.O_RDONLY|os.O_NOFOLLOW|os.O_NONBLOCK|os.O_CLOEXEC
def old_walk(path):
    parts=path.parts
    if parts[0]!='/':raise RuntimeError('absolute path required')
    fd=os.open('/',FLAGS|os.O_DIRECTORY)
    try:
        for index,part in enumerate(parts[1:]):
            nextfd=os.open(part,FLAGS|(os.O_DIRECTORY if index<len(parts)-2 else 0),dir_fd=fd)
            os.close(fd)
            fd=nextfd
        result=fd
        fd=None
        return result
    finally:
        if fd is not None:os.close(fd)
def fast_open(path):
    rootfd=os.open('/',FLAGS|os.O_DIRECTORY)
    try:
        how=OpenHow(FLAGS,0,0x08|0x04)
        ctypes.set_errno(0)
        fd=libc.syscall(ctypes.c_long(NUMBER),ctypes.c_int(rootfd),ctypes.c_char_p(os.fsencode(str(path)[1:])),ctypes.byref(how),ctypes.c_size_t(ctypes.sizeof(how)))
        if fd<0:
            error=ctypes.get_errno()
            raise OSError(error,os.strerror(error))
        return fd
    finally:
        os.close(rootfd)
def observe(method,path,expected):
    try:
        fd=method(path)
        try:
            data=os.read(fd,1024)
            return {'ok':True,'errno':None,'errno_name':None,'bytes_read':len(data),'sha256':hashlib.sha256(data).hexdigest(),'full_fixture_match':data==expected}
        finally:os.close(fd)
    except OSError as error:
        return {'ok':False,'errno':error.errno,'errno_name':errno.errorcode.get(error.errno)}
folder=Path(tempfile.mkdtemp(prefix='openat2-permission-',dir=ROOT))
middle=folder/'execute-only'
target=middle/'public-fixture'
fixture=b'HeptaRuntime openat2 permission diagnostic fixture\n'
rows=[]
try:
    middle.mkdir(mode=0o700)
    target.write_bytes(fixture)
    target.chmod(0o600)
    st=target.stat()
    private_pin_preconditions={'uid':st.st_uid,'euid':os.geteuid(),'mode':oct(st.st_mode&0o7777),'nlink':st.st_nlink,'length':st.st_size,'regular_file':target.is_file(),'maximum':256*1024}
    if not (st.st_uid==os.geteuid() and st.st_mode&0o7777==0o600 and st.st_nlink==1 and st.st_size<=256*1024 and target.is_file()):
        raise RuntimeError('private non-executable pin inode guard not met')
    for mode in (0o755,0o111,0o444):
        middle.chmod(mode)
        row={'middle_mode':oct(mode),'declared_file_mode':'0o600'}
        row['old_component_read_open']=observe(old_walk,target,fixture)
        row['openat2_final_fd']=observe(fast_open,target,fixture)
        rows.append(row)
finally:
    # Restore permissions only on this diagnostic's own fixture before cleanup.
    middle.chmod(0o700)
    target.chmod(0o600)
    shutil.rmtree(folder)
capability_line=next((x for x in Path('/proc/self/status').read_text().splitlines() if x.startswith('CapEff:')),None)
record={'schema':'hepta-openat2-permission-counterexample-v1','private_pin_inode_preconditions':private_pin_preconditions,'kernel':platform.release(),'euid':os.geteuid(),'capability_line':capability_line,'syscall_number':NUMBER,'syscall_header':str(header),'flags':FLAGS,'resolve':12,'resolve_names':['RESOLVE_BENEATH','RESOLVE_NO_SYMLINKS'],'fixture_sha256':hashlib.sha256(fixture).hexdigest(),'rows':rows,'temporary_fixture_removed':not folder.exists(),'production_changed':False}
control,execute_only,no_search=rows
record['counterexample_confirmed']=(control['old_component_read_open']['ok'] and control['openat2_final_fd']['ok'] and execute_only['old_component_read_open']=={'ok':False,'errno':errno.EACCES,'errno_name':'EACCES'} and execute_only['openat2_final_fd'].get('full_fixture_match') is True and no_search['old_component_read_open'].get('errno')==errno.EACCES and no_search['openat2_final_fd'].get('errno')==errno.EACCES)
(ROOT/'openat2-private-pin-permission-result.json').write_text(json.dumps(record,indent=2)+chr(10))
print(json.dumps(record))
if not record['counterexample_confirmed']:raise SystemExit(1)
