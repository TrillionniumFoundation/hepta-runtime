# Independent rejection of single-open openat2 substitution

## Finding

The production substitution is not behaviorally equivalent to the existing
component-by-component O_RDONLY traversal. The existing loop requires each
intermediate directory to be readable; a single final-fd openat2 walk only needs
search/execute access on intermediate directories. RESOLVE_BENEATH and
RESOLVE_NO_SYMLINKS restrict resolution, but do not restore those read checks.

## X230 real-kernel evidence

The standalone Python ctypes program invoked the actual native openat2 syscall
(number 437 from the installed native ABI header), with a zero-initialized
open_how, O_RDONLY|O_NOFOLLOW|O_NONBLOCK|O_CLOEXEC, and
RESOLVE_BENEATH|RESOLVE_NO_SYMLINKS. The baseline used the same flags and
O_DIRECTORY for each nonfinal openat component.

Environment: kernel 6.8.0-142-generic, euid 1000, effective capability mask zero.

| Intermediate directory | Final file | Component-read baseline | Final-fd openat2 |
| --- | --- | --- | --- |
| 0755 | 0444 | Success; exact fixture bytes | Success; exact fixture bytes |
| 0111 | 0444 | EACCES (13) | Success; exact fixture bytes |
| 0444 | 0444 | EACCES (13) | EACCES (13) |

All successful reads returned the same complete 51-byte synthetic fixture and
SHA256 562edbcae8ec604144cab6453c3864ad08016d851a0b271c8570c1a9cadba1b2.
The fixture existed only under this diagnostics directory; its permissions were
restored before removal, and temporary_fixture_removed is true. No production
files, configuration, services, mounts or privileges were changed.

This decisive counterexample is sufficient to reject the production fast path.
O_PATH intermediate handles would likewise remove the existing read requirement.
Checking only UNIX mode bits would not reproduce the actual kernel read-open
permission decision under ACLs, capabilities, or LSM policy.

## Other review boundaries

- Final O_PATH|O_NOFOLLOW plus NO_SYMLINKS can return a symlink handle; it is not
  equivalent to this baseline's final O_RDONLY|O_NOFOLLOW.
- NO_SYMLINKS does not prohibit mount or bind-mount traversal. Adding NO_XDEV would
  introduce a distinct and stricter contract; retain the established mount policy.
- BENEATH may introduce errors under path-resolution races. ENOSYS-only fallback
  avoids treating policy or permission errors as unsupported-system signals, but
  cannot restore equivalence for successful paths such as the one above.
- The rejected change must not be represented as a production performance win.

Primary documentation:
https://man7.org/linux/man-pages/man2/open.2.html
https://man7.org/linux/man-pages/man2/openat2.2.html
https://man7.org/linux/man-pages/man7/path_resolution.7.html
https://www.kernel.org/doc/html/v6.2/filesystems/path-lookup.html

## Reproduction

    python3 openat2_permission_counterexample.py

The program makes and removes only its own temporary fixture and writes
openat2-permission-result.json. It is explicitly restricted to the observed
X230 x86_64 ABI and reads the syscall number from the installed native header.
A first diagnostic attempt failed while trying to stat the target inside the
intentionally non-searchable 0444 directory; the corrected program records the
declared file mode before attempting access. The first script and error record
are preserved, and that setup error is not counted as kernel parity evidence.
