# X230 public-file pin hashing buffer diagnostic

## Decision

Keep 16 KiB as the established baseline. The 64 KiB candidate has a small, variable
benefit for the 846,888-byte SSH executable, with no consistent benefit for the two
smaller files. The 256 KiB candidate has no reliable additional advantage and costs
more stack space and zeroing. These measurements do not establish an end-to-end
HeptaRuntime throughput improvement.

This diagnostic changes no runtime source, production configuration, running service,
credential, or benchmark target belonging to another task.

## Method

- Rust 1.95.0, offline release build, ring 0.17.14 only as a direct dependency.
- One compilation job; isolated diagnostics/target.
- Resolved public binaries: /usr/bin/ssh, /usr/bin/false, /bin/sh -> /usr/bin/dash.
- Pair 16/64 KiB and pair 64/256 KiB each ran four ABBA rounds.
  Pair ordering alternates between rounds.
- Each run hashes all three files, 200 complete hashes per file, after eight warmups.
- Every hash opens a fresh descriptor, streams every byte through ring SHA256,
  checks both path and descriptor identity before and after, validates byte length,
  and compares the resulting digest.
- Python hashlib SHA256 independently binds the public files before and after the
  entire run; every timed sample must match those hashes.
- This measures a warm page-cache microbenchmark. It does not call SSH, execute the
  public binaries, read private profiles, or benchmark full profile authorization,
  cancellation, key validation, durable work, or MCP.
- cpu_ns uses Linux CLOCK_PROCESS_CPUTIME_ID (user + system CPU).
- read_calls_including_eof counts application Read::read attempts including EOF
  and interrupted calls. It is not a system-wide syscall counter.
- Main measurement loop omits the production check_current closure; those
  cancellation/deadline checks must remain in any production candidate.

## Outcomes

All 19,200 measured complete hashes passed. They read
6,423,091,200 bytes through 179,200 counted Read::read
calls, with 0 interrupted reads.

Measured block CPU summed to 21.844 seconds; full runner wall time was
23.093 seconds. The runner does not impose CPU affinity or alter
system performance settings. The raw before/after host load is in the manifests.

| File | Read calls/hash 16 KiB | 64 KiB | 256 KiB |
| --- | ---: | ---: | ---: |
| ssh | 53 | 14 | 5 |
| false | 3 | 2 | 2 |
| dash | 9 | 3 | 2 |

16 -> 64 KiB paired CPU ratio (B/A), geometric mean across four ABBA blocks:
ssh 0.96718 (3/4 blocks faster, block range 0.91499-1.00120);
false 1.00411 (1/4 faster);
dash 0.99964 (2/4 faster).
SSH mean CPU saving was 97.18 microseconds per complete hash, influenced by a
faster second block. Across all size-specific samples, SSH medians were 2.840 ms
at 16 KiB and 2.816 ms at 64 KiB. The 64 KiB median also includes its second-pair
samples, so use the paired block ratios in summary.json for controlled comparison.

64 -> 256 KiB paired CPU ratio:
ssh 0.99677 (1/4 blocks faster);
false 1.03526 (1/4 faster);
dash 1.02066 (0/4 faster).

The baseline stack buffer grows by 48 KiB for the 64 KiB candidate and by
240 KiB for the 256 KiB candidate. Retain existing safety checks and evaluate any
candidate through the real runtime before adopting it.

## Reproduction

Cargo.toml, Cargo.lock, src/main.rs and run_abba.py are the complete
standalone source. Successful compiler identity, arguments and hashes are in
build-result-b.json. The initial PATH-related compiler startup failure is retained
in build.log / build-result.json; it was repaired by supplying the toolchain's
absolute rustc path. There was no missing dependency or online fetch.

Run from a fresh copy of this diagnostic directory, preserving existing evidence.
Set CARGO_HOME to the already configured private cache, set CARGO_TARGET_DIR to the
fresh copy's target, select Rust 1.95.0, and run:

    cargo +1.95.0 build --offline --locked --release -j 1
    python3 run_abba.py

The runner intentionally refuses to overwrite an existing samples.jsonl.
If rustc is absent from PATH, set RUSTC to the output of
rustup which --toolchain 1.95.0 rustc. No production environment needs changing.

## Evidence files

- manifest.json: file identities, binary/source hashes, methodology.
- samples.jsonl: all 96 measured file-block samples.
- post-manifest.json: post-run file identities and wall/load accounting.
- summary.json: all paired round ratios and size-specific summaries.
- build-result-b.json, build-b.log: successful offline single-job build.
