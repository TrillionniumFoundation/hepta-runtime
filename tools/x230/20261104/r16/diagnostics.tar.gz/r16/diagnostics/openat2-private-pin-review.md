# Private-pin-valid openat2 counterexample

This supplements the open_absolute 0444-file result with an inode satisfying the
existing private non-executable pin guard: regular file, uid=euid1000, mode0600,
one hard link, length51 <= 262144 bytes. The actual syscall still accepts the
0111 intermediate directory where component-by-component O_RDONLY fails EACCES.
Every successful read matches the complete fixture content and expected SHA256.

The 0755 control succeeds through both methods; the 0444 no-search parent fails
through both. No production source/configuration/service or privilege was changed.
The temporary fixture was chmod-restored and removed.

Reproduce:
    python3 openat2_permission_private_pin_counterexample.py

Evidence: openat2-private-pin-permission-result.json.
This directly closes the limitation that the original 0444 fixture did not itself
meet a private-pin mode0600 policy or public-pin uid0 policy.
