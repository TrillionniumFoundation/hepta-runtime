#!/usr/bin/env python3
# Copyright 2026 TrillionniumFoundation
# SPDX-License-Identifier: Apache-2.0
"""ABBA component probe executing Python functions extracted from real jobs.rs.

This measures only the selected Python file-reading/status components in fresh
local Python processes. It does not measure SSH, controller pin validation,
systemctl, cancellation, fsync, cluster resources, or full MCP throughput.
"""

from __future__ import annotations

import argparse
import ast
import contextlib
import datetime as dt
import gc
import hashlib
import json
import os
from pathlib import Path
import platform
import resource
import statistics
import subprocess
import sys
import tempfile
import time
import tracemalloc
from typing import Any


PRIVATE_LIMIT = 4 * 1024 * 1024
TERMINAL_LIMIT = 1024 * 1024
BASELINE_SHA256 = "694a4e4dcbc2be499879abd837f0b5e399f9cad95caab34716907de15cbbe82f"
CONSTANTS = ("PRIVATE_DIRECTORY_CODE", "STATUS_CODE", "BOUND_OBSERVATION_CODE")
SCENARIOS = (
    "private_small",
    "private_64k",
    "terminal_small",
    "terminal_64k",
    "terminal_status",
    "live_detached",
)
SCOPE = (
    "Actual extracted Python functions; synthetic private regular files on the "
    "local filesystem; fresh interpreter per ABBA cell. CPU includes per-call "
    "result equality checks. tracemalloc is a separate untimed component sample, "
    "not resident memory. ru_maxrss is whole-worker lifetime HWM, not steady RSS. "
    "No SSH/systemctl/controller/global-lock/cancel/durability or cluster claim."
)


def sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def extract_constant(source: str, name: str) -> str:
    marker = f'const {name}: &str = r#"'
    if source.count(marker) != 1:
        raise ValueError(f"expected exactly one real source constant {name}")
    start = source.index(marker) + len(marker)
    end = source.index('\n"#;', start)
    return source[start:end]


def encode_json(value: Any) -> bytes:
    return (json.dumps(value, sort_keys=True, ensure_ascii=False) + "\n").encode("utf-8")


def value_identity(value: Any) -> dict[str, Any]:
    if isinstance(value, bytes):
        return {"kind": "bytes", "length": len(value), "sha256": sha256(value)}
    encoded = encode_json(value)
    return {"kind": "json", "length": len(encoded), "sha256": sha256(encoded)}


class SourceFunctions:
    """Compile original imports/function ASTs without rewriting their bodies.

    The remote stdin/bootstrap and wait loop are intentionally excluded. Tests
    separately execute the complete original bound helper for integration.
    """

    def __init__(self, path: Path):
        self.path = Path(path).resolve()
        data = self.path.read_bytes()
        self.source_sha256 = sha256(data)
        source = data.decode("utf-8")
        self.constants = {name: extract_constant(source, name) for name in CONSTANTS}
        self.namespace: dict[str, Any] = {"__name__": "hepta_extracted_read_probe"}
        self.function_sha256: dict[str, str] = {}
        for name in CONSTANTS[:2]:
            code = self.constants[name]
            tree = ast.parse(code, filename=f"{self.path}#{name}")
            retained = [
                node
                for node in tree.body
                if isinstance(node, (ast.Import, ast.ImportFrom, ast.FunctionDef))
            ]
            for node in retained:
                if isinstance(node, ast.FunctionDef):
                    segment = ast.get_source_segment(code, node)
                    if segment is None:
                        raise ValueError("original function source segment unavailable")
                    self.function_sha256[node.name] = sha256(segment.encode("utf-8"))
            module = ast.Module(body=retained, type_ignores=[])
            exec(compile(module, f"{self.path}#{name}", "exec"), self.namespace)
        self.namespace["_hepta_directory_pins"] = []
        self.namespace["q"] = {"job_id": "synthetic-probe-job", "unit": "not-a-real-unit"}

    @contextlib.contextmanager
    def directory(self, path: Path):
        fd = os.open(path, os.O_RDONLY | os.O_DIRECTORY | os.O_CLOEXEC)
        if self.namespace["_hepta_directory_pins"]:
            os.close(fd)
            raise RuntimeError("probe already has a pinned directory")
        self.namespace["_hepta_directory_pins"] = [fd]
        try:
            yield self.namespace
        finally:
            for held in self.namespace["_hepta_directory_pins"]:
                os.close(held)
            self.namespace["_hepta_directory_pins"] = []

    def complete_status_script(self) -> str:
        private = self.constants["PRIVATE_DIRECTORY_CODE"]
        return (
            "REMOTE_DIRECTORY_SOURCE = " + repr(private) + "\n"
            "exec(REMOTE_DIRECTORY_SOURCE)\n"
            + self.constants["BOUND_OBSERVATION_CODE"]
            + "\n"
            + self.constants["STATUS_CODE"]
        )

    def identity(self) -> dict[str, Any]:
        return {
            "path": str(self.path),
            "source_sha256": self.source_sha256,
            "constant_sha256": {
                name: sha256(code.encode("utf-8")) for name, code in self.constants.items()
            },
            "function_sha256": self.function_sha256,
            "extraction": "original imports and function ASTs; no function-body rewrite",
        }


def private_write(path: Path, data: bytes) -> None:
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    with os.fdopen(fd, "wb") as output:
        output.write(data)


def supervisor_identity() -> dict[str, str]:
    if sys.platform == "linux":
        raw = Path(f"/proc/{os.getpid()}/stat").read_text()
        ticks = int(raw.rsplit(") ", 1)[1].split()[19])
        boot = Path("/proc/sys/kernel/random/boot_id").read_text().strip()
        if not boot:
            raise RuntimeError("local fixture boot identity unavailable")
        return {"kind": "proc_start_ticks", "value": f"{boot}:{ticks}"}
    value = subprocess.check_output(
        ["ps", "-p", str(os.getpid()), "-o", "lstart="], text=True, timeout=3
    ).strip()
    if not value:
        raise RuntimeError("local fixture process identity unavailable")
    return {"kind": "ps_lstart", "value": value}


def scenario_functions(
    functions: SourceFunctions, directory: Path, scenario: str
) -> tuple[Any, Any, dict[str, Any]]:
    ns = functions.namespace
    if scenario.startswith("private_"):
        expected = {"job_id": "synthetic-probe-job", "state": "running", "data": "small"}
        data = encode_json(expected)
        if scenario == "private_64k":
            data += b" " * (65536 - len(data))
        private_write(directory / "request.json", data)
        return (
            lambda: ns["private_read_json"]("request.json"),
            expected,
            {"file_bytes": len(data), "file_sha256": sha256(data), "limit": PRIVATE_LIMIT},
        )
    if scenario.startswith("terminal_") and scenario != "terminal_status":
        data = encode_json({"job_id": "synthetic-probe-job", "exit_code": 0, "data": "small"})
        if scenario == "terminal_64k":
            data += b" " * (65536 - len(data))
        private_write(directory / "exit.json", data)
        return (
            lambda: ns["read_terminal_file"]("exit.json", TERMINAL_LIMIT),
            data,
            {"file_bytes": len(data), "file_sha256": sha256(data), "limit": TERMINAL_LIMIT},
        )
    request = {
        "job_id": "synthetic-probe-job",
        "launch_nonce": "a" * 32,
        "terminal_publication_protocol": 1,
    }
    request_bytes = encode_json(request)
    private_write(directory / "request.json", request_bytes)
    private_write(directory / "launch.json", encode_json({"backend": "detached"}))
    if scenario == "terminal_status":
        terminal = {**request, "exit_code": 0, "output_complete": True, "output_durable": True}
        data = encode_json(terminal)
        private_write(directory / "exit.json", data)
        witness = {
            **request,
            "exit_sha256": sha256(data),
        }
        private_write(directory / "exit.witness.json", encode_json(witness))
        expected = {
            **terminal,
            "state": "succeeded",
            "terminal_publication_confirmed": True,
            "automatic_retry": False,
        }
        return (
            ns["one_status"],
            expected,
            {"request_bytes": len(request_bytes), "exit_bytes": len(data), "exit_sha256": sha256(data)},
        )
    if scenario == "live_detached":
        identity = supervisor_identity()
        started = {
            "job_id": request["job_id"],
            "launch_nonce": request["launch_nonce"],
            "supervisor_pid": os.getpid(),
            "supervisor_uid": os.geteuid(),
            "supervisor_identity": identity,
        }
        private_write(directory / "started.json", encode_json(started))
        expected = {"state": "running", "backend": "detached", "pid": os.getpid(), "identity": identity}
        return (
            ns["one_status"],
            expected,
            {
                "request_bytes": len(request_bytes),
                "fixture_owner": "this probe worker only; no application process launched",
                "supervisor_identity_kind": identity["kind"],
            },
        )
    raise ValueError(f"unsupported scenario {scenario}")


def rss_bytes() -> int:
    value = int(resource.getrusage(resource.RUSAGE_SELF).ru_maxrss)
    return value if sys.platform == "darwin" else value * 1024


def run_worker(source: Path, scenario: str, iterations: int, warmup: int) -> dict[str, Any]:
    functions = SourceFunctions(source)
    with tempfile.TemporaryDirectory(prefix="hepta-read-probe-") as temporary:
        directory = Path(temporary)
        call, expected, fixture = scenario_functions(functions, directory, scenario)
        with functions.directory(directory):
            for _ in range(warmup):
                if call() != expected:
                    raise AssertionError("actual extracted warmup returned unexpected content")
            rss_before = rss_bytes()
            cpu_start = time.process_time_ns()
            wall_start = time.perf_counter_ns()
            for _ in range(iterations):
                if call() != expected:
                    raise AssertionError("actual extracted measured call returned unexpected content")
            wall_end = time.perf_counter_ns()
            cpu_end = time.process_time_ns()
            rss_after = rss_bytes()
            traced = []
            for _ in range(3):
                gc.collect()
                tracemalloc.start()
                actual = call()
                current, peak = tracemalloc.get_traced_memory()
                tracemalloc.stop()
                if actual != expected:
                    raise AssertionError("actual extracted allocation sample returned unexpected content")
                traced.append({"current_bytes": current, "peak_bytes": peak})
            return {
                "schema": "hepta-python-read-component-cell-v1",
                "scope": SCOPE,
                "source": functions.identity(),
                "scenario": scenario,
                "fixture": fixture,
                "iterations": iterations,
                "warmup": warmup,
                "cpu_start_ns": cpu_start,
                "cpu_end_ns": cpu_end,
                "cpu_ns": cpu_end - cpu_start,
                "wall_start_ns": wall_start,
                "wall_end_ns": wall_end,
                "wall_ns": wall_end - wall_start,
                "cpu_ns_per_call": (cpu_end - cpu_start) / iterations,
                "wall_ns_per_call": (wall_end - wall_start) / iterations,
                "ru_maxrss_before_bytes": rss_before,
                "ru_maxrss_after_bytes": rss_after,
                "ru_maxrss_after_allocation_samples_bytes": rss_bytes(),
                "untimed_tracemalloc_samples": traced,
                "expected_result": value_identity(expected),
                "all_actual_results_equal_expected": True,
                "python": sys.version,
                "platform": platform.platform(),
                "clock_process_time": vars(time.get_clock_info("process_time")),
                "clock_perf_counter": vars(time.get_clock_info("perf_counter")),
                "selected_allocator_environment": {
                    name: os.environ.get(name) for name in ("PYTHONMALLOC", "MALLOC_ARENA_MAX")
                },
            }


def summary(rows: list[dict[str, Any]], rounds: int, scenarios: list[str]) -> dict[str, Any]:
    result: dict[str, Any] = {"schema": "hepta-python-read-component-abba-summary-v1", "scope": SCOPE}
    tables = {}
    for scenario in scenarios:
        selected = [row for row in rows if row["scenario"] == scenario]
        if len(selected) != 4 * rounds:
            raise ValueError("missing ABBA cells")
        pairs = []
        for block in range(rounds):
            block_rows = [row for row in selected if row["block"] == block]
            if [row["variant"] for row in block_rows] != ["A", "B", "B", "A"]:
                raise ValueError("ABBA order differs from protocol")
            means = {
                variant: statistics.mean(
                    row["cell"]["cpu_ns_per_call"] for row in block_rows if row["variant"] == variant
                )
                for variant in ("A", "B")
            }
            pairs.append({"block": block, "a_cpu_ns_per_call": means["A"], "b_cpu_ns_per_call": means["B"], "b_over_a_cpu": means["B"] / means["A"]})
        variants = {}
        for variant in ("A", "B"):
            cells = [row["cell"] for row in selected if row["variant"] == variant]
            variants[variant] = {
                "cpu_ns_per_call_median": statistics.median(cell["cpu_ns_per_call"] for cell in cells),
                "wall_ns_per_call_median": statistics.median(cell["wall_ns_per_call"] for cell in cells),
                "traced_peak_bytes_median": statistics.median(
                    sample["peak_bytes"] for cell in cells for sample in cell["untimed_tracemalloc_samples"]
                ),
                "worker_lifetime_hwm_bytes_median": statistics.median(
                    cell["ru_maxrss_after_allocation_samples_bytes"] for cell in cells
                ),
            }
        tables[scenario] = {
            "variants": variants,
            "paired_blocks": pairs,
            "paired_cpu_change_percent_median": (statistics.median(pair["b_over_a_cpu"] for pair in pairs) - 1) * 100,
            "b_faster_blocks": sum(pair["b_over_a_cpu"] < 1 for pair in pairs),
        }
    result["scenarios"] = tables
    result["cells"] = len(rows)
    result["rounds"] = rounds
    result["all_cells_passed"] = all(row["cell"]["all_actual_results_equal_expected"] for row in rows)
    return result


def run_abba(args: argparse.Namespace) -> None:
    output = args.output_dir.resolve()
    output.mkdir(parents=True, exist_ok=False)
    sources = {"A": args.baseline.resolve(), "B": args.candidate.resolve()}
    bindings = {label: SourceFunctions(path).identity() for label, path in sources.items()}
    if bindings["A"]["source_sha256"] != BASELINE_SHA256:
        raise ValueError("baseline is not the frozen R18/R14 jobs.rs")
    metadata = {
        "schema": "hepta-python-read-component-protocol-v1",
        "scope": SCOPE,
        "started_utc": dt.datetime.now(dt.timezone.utc).isoformat(),
        "sources": bindings,
        "rounds": args.rounds,
        "iterations": args.iterations,
        "warmup": args.warmup,
        "scenarios": args.scenarios,
        "order_per_scenario_block": ["A", "B", "B", "A"],
        "python": sys.version,
        "script_sha256": sha256(Path(__file__).read_bytes()),
        "automatic_retries": 0,
    }
    (output / "protocol.json").write_text(json.dumps(metadata, indent=2) + "\n")
    rows = []
    with (output / "raw-cells.jsonl").open("x") as log:
        for block in range(args.rounds):
            for scenario in args.scenarios:
                for position, variant in enumerate(("A", "B", "B", "A")):
                    command = [sys.executable, "-I", "-S", str(Path(__file__).resolve()), "_worker", "--source", str(sources[variant]), "--scenario", scenario, "--iterations", str(args.iterations), "--warmup", str(args.warmup)]
                    start = time.perf_counter_ns()
                    process = subprocess.run(command, capture_output=True, text=True, timeout=180)
                    row: dict[str, Any] = {"block": block, "scenario": scenario, "position": position, "variant": variant, "command": command, "returncode": process.returncode, "driver_wall_ns": time.perf_counter_ns() - start, "stderr": process.stderr}
                    if process.returncode == 0:
                        row["cell"] = json.loads(process.stdout)
                        if row["cell"]["source"]["source_sha256"] != bindings[variant]["source_sha256"]:
                            raise ValueError("source changed while running component probe")
                    else:
                        row["stdout"] = process.stdout
                    log.write(json.dumps(row, sort_keys=True) + "\n")
                    log.flush()
                    if process.returncode:
                        raise RuntimeError(f"component cell failed without retry: {scenario}/{block}/{position}")
                    rows.append(row)
    result = summary(rows, args.rounds, args.scenarios)
    result["raw_cells_sha256"] = sha256((output / "raw-cells.jsonl").read_bytes())
    result["protocol_sha256"] = sha256((output / "protocol.json").read_bytes())
    result["finished_utc"] = dt.datetime.now(dt.timezone.utc).isoformat()
    for label, path in sources.items():
        if sha256(path.read_bytes()) != bindings[label]["source_sha256"]:
            raise ValueError("source changed after component probe")
    with (output / "summary.json").open("x") as stream:
        json.dump(result, stream, indent=2)
        stream.write("\n")
    print(json.dumps({"output": str(output), "cells": len(rows), "all_cells_passed": result["all_cells_passed"], "summary_sha256": sha256((output / "summary.json").read_bytes())}))


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="mode", required=True)
    worker = sub.add_parser("_worker")
    worker.add_argument("--source", type=Path, required=True)
    worker.add_argument("--scenario", choices=SCENARIOS, required=True)
    worker.add_argument("--iterations", type=int, required=True)
    worker.add_argument("--warmup", type=int, required=True)
    abba = sub.add_parser("abba")
    abba.add_argument("--baseline", type=Path, required=True)
    abba.add_argument("--candidate", type=Path, required=True)
    abba.add_argument("--output-dir", type=Path, required=True)
    abba.add_argument("--rounds", type=int, default=4)
    abba.add_argument("--iterations", type=int, default=256)
    abba.add_argument("--warmup", type=int, default=16)
    abba.add_argument("--scenarios", nargs="+", choices=SCENARIOS, default=list(SCENARIOS))
    args = parser.parse_args()
    if not 1 <= args.iterations <= 100000 or not 0 <= args.warmup <= 1000:
        parser.error("iterations must be 1..100000 and warmup 0..1000")
    if args.mode == "_worker":
        print(json.dumps(run_worker(args.source, args.scenario, args.iterations, args.warmup), sort_keys=True))
    else:
        if not 1 <= args.rounds <= 8:
            parser.error("rounds must be 1..8")
        run_abba(args)


if __name__ == "__main__":
    main()
