#!/usr/bin/env python3
"""Tiny local identity and rejection fixtures for the transport envelope only."""
import argparse
import gzip
import hashlib
import importlib.util
import json
from pathlib import Path
import sys
import tarfile
import tempfile
import traceback
from types import SimpleNamespace


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    script = Path(__file__).absolute().parents[1] / 'publication/pack_transfer_01.py'
    sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
    spec = importlib.util.spec_from_file_location('envelope_tested', script)
    m = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(m)
    p, t = m.helpers()
    files = [script, script.with_name('package_x230_evidence.py'), script.with_name('publication_transfer.py')]
    before = {str(path): sha(path) for path in files}
    report = {'schema': 'hepta-r19-transfer-envelope-selftest/v1', 'passed': False,
              'tools_before': before, 'remote_operations': 0, 'builds_started': False,
              'checks': {}, 'negative_cases': []}
    try:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            stage, extras = root / 'closed-stage', root / 'closed-batch'
            stage.mkdir()
            extras.mkdir()
            originals = {
                'tools/x230/20261104/r19/inner.tar.gz': bytes(range(256)) * 4,
                'tools/x230/20261104/r19/inner.manifest.json': b'{  "preserve": true, "rows": [] }\n\n',
            }
            index_rows = []
            for name, raw in originals.items():
                path = stage / name
                path.parent.mkdir(parents=True, exist_ok=True)
                path.write_bytes(raw)
                index_rows.append({'repo_path': name, 'absolute_remote_path': str(path), **t.hashes(path)})
            for name, raw in [('report.json', b'{"closed":true}'), ('pack.stderr', b'')]:
                path = extras / name
                path.write_bytes(raw)
                repo = 'tools/x230/20261104/r19/publication-attempts/' + name
                originals[repo] = raw
                index_rows.append({'repo_path': repo, 'absolute_remote_path': str(path), **t.hashes(path)})
            index = root / 'original-index.json'
            index.write_bytes(m.encode({'schema': m.INDEX_SCHEMA, 'files': index_rows}))
            index_sha = sha(index)

            def pack_args(out):
                return SimpleNamespace(stage_root=stage, index=index, output_root=out, extra_root=[extras],
                                       evidence_window_closed=True, expected_index_sha256=index_sha)

            one = m.pack(pack_args(root / 'envelope-01'), p, t)
            assert one['passed'], one.get('error')
            two = m.pack(pack_args(root / 'envelope-02'), p, t)
            assert two['passed'], two.get('error')
            archive = Path(one['archive_path'])
            report['checks']['deterministic_outer_bytes'] = one['archive'] == two['archive']
            report['checks']['source_files_unchanged_after_pack'] = all(Path(row['absolute_remote_path']).read_bytes() == originals[row['repo_path']] for row in index_rows)
            destination = root / 'restored-stage'
            restore_args = SimpleNamespace(archive=archive, expected_archive_sha256=one['archive']['sha256'],
                expected_index_sha256=index_sha, output_stage=destination,
                receipt=root / 'restore-report.json', index_output=root / 'restored-index.json')
            restored = m.restore(restore_args, p, t)
            report['checks']['byte_exact_roundtrip_including_binary_and_empty'] = restored['passed'] and all((destination / name).read_bytes() == raw for name, raw in originals.items())
            report['checks']['original_index_bytes_preserved'] = restore_args.index_output.read_bytes() == index.read_bytes()

            def reject(label, operation, expected_text=None):
                try:
                    value = operation()
                    rejected = isinstance(value, dict) and value.get('passed') is False
                    message = str(value.get('error')) if isinstance(value, dict) else repr(value)
                except Exception as error:
                    rejected, message = True, type(error).__name__ + ': ' + str(error)
                ok = rejected and (expected_text is None or expected_text in message)
                report['checks'][label] = ok
                report['negative_cases'].append({'case': label, 'rejected': rejected, 'message': message, 'passed': ok})

            old_receipt = restore_args.receipt.read_bytes()
            reject('restore_refuses_overwrite', lambda: m.restore(restore_args, p, t), 'already exists')
            report['checks']['old_restore_receipt_unchanged'] = restore_args.receipt.read_bytes() == old_receipt
            old_pack_report = (root / 'envelope-01/report.json').read_bytes()
            reject('pack_refuses_overwrite', lambda: m.pack(pack_args(root / 'envelope-01'), p, t))
            report['checks']['old_pack_receipt_unchanged'] = (root / 'envelope-01/report.json').read_bytes() == old_pack_report
            binary = stage / index_rows[0]['repo_path']
            binary.write_bytes(b'changed source')
            reject('changed_source_fails_and_is_preserved', lambda: m.pack(pack_args(root / 'envelope-changed'), p, t))
            report['checks']['changed_source_failure_receipt_exists'] = (root / 'envelope-changed/report.json').exists() and not (root / 'envelope-changed/r19-transfer-envelope-01.tar.gz').exists()
            binary.write_bytes(originals[index_rows[0]['repo_path']])
            unlisted = stage / 'unlisted.json'
            unlisted.write_bytes(b'{}')
            reject('unindexed_stage_file_rejected', lambda: m.pack(pack_args(root / 'envelope-unindexed'), p, t), 'exact closed stage')
            unlisted.unlink()
            reject('remote_output_inside_sources_rejected', lambda: m.pack(pack_args(stage / 'forbidden-envelope'), p, t), 'overlaps indexed sources')
            report['checks']['unsafe_pack_output_not_created'] = not (stage / 'forbidden-envelope').exists()
            unsafe = SimpleNamespace(**vars(restore_args))
            unsafe.output_stage, unsafe.receipt, unsafe.index_output = stage / 'forbidden-restore', root / 'unsafe-restore.json', root / 'unsafe-index.json'
            reject('local_destination_inside_sources_rejected', lambda: m.restore(unsafe, p, t), 'overlaps indexed sources')
            unsafe.output_stage, unsafe.receipt = root / 'safe-stage-unused', stage / 'forbidden-receipt.json'
            reject('local_receipt_inside_sources_rejected', lambda: m.restore(unsafe, p, t), 'overlaps indexed sources')
            report['checks']['unsafe_restore_outputs_not_created'] = not (stage / 'forbidden-restore').exists() and not (stage / 'forbidden-receipt.json').exists()

            metadata = one['verification']['metadata']
            for case in ['malformed-index', 'extra', 'duplicate', 'symlink', 'hardlink', 'traversal', 'absolute', 'missing', 'wrong-bytes']:
                bad = root / (case + '.tar.gz')
                raw_index = b'{malformed' if case == 'malformed-index' else index.read_bytes()
                with bad.open('xb') as raw:
                    with gzip.GzipFile(filename='', fileobj=raw, mode='wb', mtime=0) as gz:
                        with tarfile.open(fileobj=gz, mode='w|', format=tarfile.PAX_FORMAT) as tar:
                            m.write_member(tar, m.INDEX_MEMBER, raw_index)
                            meta = dict(metadata, original_index_sha256=m.digest(raw_index))
                            m.write_member(tar, m.META_MEMBER, m.encode(meta))
                            selected = sorted(originals)
                            for i, name in enumerate(selected):
                                if case == 'missing' and i == len(selected) - 1:
                                    continue
                                if case in ('symlink', 'hardlink') and i == 0:
                                    link = tarfile.TarInfo(name)
                                    link.type = tarfile.SYMTYPE if case == 'symlink' else tarfile.LNKTYPE
                                    link.linkname, link.mode, link.mtime = '../outside', 0o644, 0
                                    tar.addfile(link)
                                else:
                                    data = originals[name]
                                    if case == 'wrong-bytes' and i == 0:
                                        data = bytes([data[0] ^ 1]) + data[1:]
                                    m.write_member(tar, name, data)
                            if case == 'extra':
                                m.write_member(tar, 'tools/extra.json', b'{}')
                            elif case == 'duplicate':
                                m.write_member(tar, selected[0], originals[selected[0]])
                            elif case == 'traversal':
                                m.write_member(tar, '../escaped.txt', b'escape')
                            elif case == 'absolute':
                                m.write_member(tar, str(root / 'escaped.txt'), b'escape')
                def inspect_bad(path=bad, frozen=m.digest(raw_index)):
                    return m.inspect_envelope(path, sha(path), frozen, p, t)
                reject('reject_' + case, inspect_bad)
            report['checks']['no_path_escape_created'] = not (root / 'escaped.txt').exists()
            report['checks']['single_envelope_index_supported_by_original_chunks'] = False
            single = Path(one['transfer_index'])
            chunk_result = t.chunks(str(single), str(root / 'pieces'), str(root / 'pieces-manifest.json'))
            assembled = t.assemble(str(root / 'pieces-manifest.json'), str(root / 'pieces'), str(root / 'download'), str(root / 'assemble.json'))
            report['checks']['single_envelope_index_supported_by_original_chunks'] = sha(root / 'download/transport/r19-transfer-envelope-01.tar.gz') == one['archive']['sha256']
            report['transport_fixture'] = {'split': chunk_result, 'assemble': assembled}
        report['tools_after'] = {str(path): sha(path) for path in files}
        report['checks']['all_frozen_helpers_and_tool_unchanged'] = report['tools_after'] == before
        report['passed'] = all(report['checks'].values())
    except BaseException as error:
        report['error'] = {'type': type(error).__name__, 'message': str(error), 'traceback': traceback.format_exc()}
    with args.output.open('x') as stream:
        stream.write(json.dumps(report, sort_keys=True, indent=2) + '\n')
    print(json.dumps({'passed': report['passed'], 'checks': len(report['checks']),
                      'failed_checks': [key for key, value in report['checks'].items() if not value],
                      'error': report.get('error'), 'receipt': str(args.output), 'sha256': sha(args.output)}, sort_keys=True))
    return 0 if report['passed'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
