#!/usr/bin/env python3
# Copyright 2026 TrillionniumFoundation
# SPDX-License-Identifier: Apache-2.0
"""Read one already closed archive; stdout contains only its original gzip bytes.

Invoked through the unchanged held_agent_campaign.py stdin-script interface.
The launcher SHA argument is the holder's source-byte identity label; the holder
hashes those source bytes before forwarding them. This reader separately checks
the fixed archive before emitting any byte and again after streaming it.
"""
import hashlib
import json
import os
import stat
import sys

PATH = '/home/qian/hepta-runtime-optimization-20261104-r19/transfer-envelope-01/r19-transfer-envelope-01.tar.gz'
SIZE = 7712102
SHA256 = '6e329b2b9adffc23c06496c68efeeea07605ce1ee28079a92cc3e2d508accd93'
CHUNK = 64 * 1024


def need(value, message):
    if not value:
        raise ValueError(message)


def stamp(value):
    return (value.st_dev, value.st_ino, value.st_mode, value.st_nlink,
            value.st_size, value.st_mtime_ns, value.st_ctime_ns)


def open_source():
    """Walk every fixed path component without following symbolic links."""
    directory = os.open('/', os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW | os.O_CLOEXEC)
    descriptor = None
    try:
        names = PATH.split('/')[1:]
        for name in names[:-1]:
            child = os.open(name, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW | os.O_CLOEXEC,
                            dir_fd=directory)
            os.close(directory)
            directory = child
        descriptor = os.open(names[-1], os.O_RDONLY | os.O_NOFOLLOW | os.O_CLOEXEC | os.O_NONBLOCK,
                             dir_fd=directory)
        actual = os.fstat(descriptor)
        named = os.stat(names[-1], dir_fd=directory, follow_symlinks=False)
        need(stat.S_ISREG(actual.st_mode) and actual.st_nlink == 1 and actual.st_size == SIZE,
             'source is not the fixed-size independent regular archive')
        need(stamp(named) == stamp(actual), 'named source identity differs')
        owned, descriptor = descriptor, None
        return owned, stamp(actual)
    finally:
        if descriptor is not None:
            os.close(descriptor)
        os.close(directory)


def current_name_matches(expected):
    descriptor, actual = open_source()
    try:
        need(actual == expected, 'absolute source identity changed')
    finally:
        os.close(descriptor)


def pass_bytes(descriptor, emit, result):
    digest, count = hashlib.sha256(), 0
    while True:
        block = os.read(descriptor, CHUNK)
        if not block:
            break
        count += len(block)
        need(count <= SIZE, 'source grew during read')
        digest.update(block)
        if emit:
            view = memoryview(block)
            while view:
                written = os.write(1, view)
                need(written > 0, 'stdout write made no progress')
                result['output_bytes'] += written
                view = view[written:]
    need(count == SIZE and digest.hexdigest() == SHA256, 'archive byte count or SHA256 differs')


def main():
    result = {'schema': 'hepta-r19-frozen-envelope-stream/v1', 'passed': False,
              'read_only': True, 'source_bytes': SIZE, 'source_sha256': SHA256,
              'output_bytes': 0, 'chunk_bytes': CHUNK, 'whole_file_buffered': False}
    descriptor = None
    try:
        need(len(sys.argv) == 3 and sys.argv[1] == '--launcher-sha256'
             and len(sys.argv[2]) == 64 and all(c in '0123456789abcdef' for c in sys.argv[2]),
             'exact holder launcher-SHA argument required')
        result['holder_launcher_sha256'] = sys.argv[2]
        descriptor, before = open_source()
        pass_bytes(descriptor, False, result)
        need(stamp(os.fstat(descriptor)) == before, 'source changed during preverification')
        current_name_matches(before)
        os.lseek(descriptor, 0, os.SEEK_SET)
        pass_bytes(descriptor, True, result)
        need(stamp(os.fstat(descriptor)) == before, 'source changed during streaming')
        current_name_matches(before)
        need(result['output_bytes'] == SIZE, 'stdout byte count differs')
        result['passed'] = True
    except BaseException as error:
        result['error'] = {'type': type(error).__name__, 'message': str(error)}
    finally:
        if descriptor is not None:
            os.close(descriptor)
        sys.stderr.write(json.dumps(result, sort_keys=True) + '\n')
        sys.stderr.flush()
    return 0 if result['passed'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
