#!/usr/bin/env python3
"""Read-only, independent recomputation of the frozen X230 component campaign.

Does not import the probe, execute a measured helper, or run performance work.
Only new audit result files are written under the explicitly selected output.
"""

import argparse
import ast
from collections import defaultdict
from datetime import datetime
import hashlib
import json
from pathlib import Path
import tarfile


BASELINE = "694a4e4dcbc2be499879abd837f0b5e399f9cad95caab34716907de15cbbe82f"
CANDIDATE = "c9080de8aa9a35f7495aa2822a1495d297903900ae0f0de26d7b0c86d043d3c9"
PROBE = "c6bd04ea22d4b368a3eed1cf17642b9418f6e2c0ebc2fc8fde26db92a42df0a8"
TESTS = "b2fcba8bf78e895f79cef2b6326b69a76c68f8f8b873b72833023cde8e1d5db1"
ARCHIVE = "4d9787b50d914d3407ce5f15465060ff5e35828b5f489528fb39cc4dbc6a8dd5"
SCENARIOS = ["private_small", "private_64k", "terminal_small", "terminal_64k", "terminal_status", "live_detached"]


def digest(data):
    return hashlib.sha256(data).hexdigest()


def read_json(path):
    return json.loads(path.read_bytes())


def median(items):
    values = sorted(items)
    n = len(values)
    if not n:
        raise ValueError("empty median")
    return values[n // 2] if n % 2 else (values[n // 2 - 1] + values[n // 2]) / 2


def serialized(value):
    return (json.dumps(value, sort_keys=True, ensure_ascii=False) + "\n").encode()


def identity(value, raw=False):
    data = value if raw else serialized(value)
    return {"kind": "bytes" if raw else "json", "length": len(data), "sha256": digest(data)}


def original_sources(path):
    data = path.read_bytes()
    text = data.decode()
    constants, functions = {}, {}
    for name in ("PRIVATE_DIRECTORY_CODE", "STATUS_CODE", "BOUND_OBSERVATION_CODE"):
        prefix = 'const ' + name + ': &str = r#"'
        assert text.count(prefix) == 1
        code = text.split(prefix, 1)[1].split('\n"#;', 1)[0]
        constants[name] = digest(code.encode())
        if name != "BOUND_OBSERVATION_CODE":
            for node in ast.parse(code).body:
                if isinstance(node, ast.FunctionDef):
                    functions[node.name] = digest(ast.get_source_segment(code, node).encode())
    return {"source_sha256": digest(data), "constant_sha256": constants, "function_sha256": functions}


def rebuild_static_fixtures():
    private = {"job_id": "synthetic-probe-job", "state": "running", "data": "small"}
    private_bytes = serialized(private)
    terminal = {"job_id": "synthetic-probe-job", "exit_code": 0, "data": "small"}
    terminal_bytes = serialized(terminal)
    request = {"job_id": "synthetic-probe-job", "launch_nonce": "a" * 32, "terminal_publication_protocol": 1}
    exit_record = {**request, "exit_code": 0, "output_complete": True, "output_durable": True}
    exit_bytes = serialized(exit_record)
    cases = {}
    for name in ("private_small", "private_64k"):
        data = private_bytes if name.endswith("small") else private_bytes + b" " * (65536 - len(private_bytes))
        cases[name] = ({"file_bytes": len(data), "file_sha256": digest(data), "limit": 4 * 1024 * 1024}, identity(private))
    for name in ("terminal_small", "terminal_64k"):
        data = terminal_bytes if name.endswith("small") else terminal_bytes + b" " * (65536 - len(terminal_bytes))
        cases[name] = ({"file_bytes": len(data), "file_sha256": digest(data), "limit": 1024 * 1024}, identity(data, raw=True))
    cases["terminal_status"] = (
        {"request_bytes": len(serialized(request)), "exit_bytes": len(exit_bytes), "exit_sha256": digest(exit_bytes)},
        identity({**exit_record, "state": "succeeded", "terminal_publication_confirmed": True, "automatic_retry": False}),
    )
    return cases


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--evidence-root", type=Path, required=True)
    p.add_argument("--baseline", type=Path, required=True)
    p.add_argument("--candidate", type=Path, required=True)
    p.add_argument("--probe", type=Path, required=True)
    p.add_argument("--tests", type=Path, required=True)
    p.add_argument("--output-dir", type=Path, required=True)
    args = p.parse_args()
    out = args.output_dir.resolve()
    out.mkdir(parents=True, exist_ok=False)
    root = args.evidence_root.resolve()
    checks = []

    def check(name, success, detail=None):
        checks.append({"check": name, "passed": bool(success), "detail": detail})
        if not success:
            with (out / "failed-checks.json").open("x") as stream:
                json.dump(checks, stream, indent=2)
            raise AssertionError(name)

    manifest = read_json(root / "component-export-manifest.json")
    check("exact X230 archive identity", digest((root / "component-evidence.tar.gz").read_bytes()) == ARCHIVE)
    check("all nine extracted members match length and SHA256", len(manifest) == 9 and all((root / name).stat().st_size == meta["size"] and digest((root / name).read_bytes()) == meta["sha256"] for name, meta in manifest.items()))
    with tarfile.open(root / "component-evidence.tar.gz", "r:gz") as archive:
        regular = [member for member in archive.getmembers() if member.isfile()]
        check("archive contains nine manifested evidence members plus manifest", len(regular) == 10 and {member.name for member in regular} == set(manifest) | {"component-export-manifest.json"})
        check("archive bytes and extracted bytes coincide", all(archive.extractfile(member).read() == (root / member.name).read_bytes() for member in regular))
    protocol_path = root / "component-probe-01/protocol.json"
    raw_path = root / "component-probe-01/raw-cells.jsonl"
    original_path = root / "component-probe-01/summary.json"
    protocol = read_json(protocol_path)
    plan = read_json(root / "measurement-plan-01.json")
    installed = read_json(root / "candidate-installed-03.json")
    original = read_json(original_path)
    rows = [json.loads(line) for line in raw_path.read_text().splitlines()]
    local = {"A": original_sources(args.baseline), "B": original_sources(args.candidate)}
    check("frozen R18 and revision3 source bytes", local["A"]["source_sha256"] == BASELINE and local["B"]["source_sha256"] == CANDIDATE)
    check("frozen probe and semantic-test tool bytes", digest(args.probe.read_bytes()) == PROBE and digest(args.tests.read_bytes()) == TESTS)
    check("exact embedded Python and function bindings", all(all(protocol["sources"][label][key] == value for key, value in local[label].items()) for label in ("A", "B")))
    check("plan and installation precede campaign", max(datetime.fromisoformat(plan["created_utc"]), datetime.fromisoformat(installed["created_utc"])) <= datetime.fromisoformat(protocol["started_utc"]) < datetime.fromisoformat(original["finished_utc"]))
    check("installation binds plan, patch and selected code/tools", installed["revision"] == 3 and installed["jobs_sha256"] == CANDIDATE and installed["measurement_plan_sha256"] == digest((root / "measurement-plan-01.json").read_bytes()) and installed["patch_sha256"] == digest((root / "candidate-revision3.patch").read_bytes()) and installed["tools"]["python_read_probe.py"] == PROBE and installed["tools"]["test_python_read_bounds.py"] == TESTS)
    check("fixed component protocol honored", protocol["rounds"] == 4 and protocol["iterations"] == 256 and protocol["warmup"] == 16 and protocol["scenarios"] == SCENARIOS and protocol["order_per_scenario_block"] == ["A", "B", "B", "A"] and protocol["automatic_retries"] == 0 and protocol["script_sha256"] == PROBE and all(plan["component"][key] == protocol[key] for key in ("rounds", "iterations", "warmup", "scenarios")))
    sequence = [(block, scene, position, variant) for block in range(4) for scene in SCENARIOS for position, variant in enumerate("ABBA")]
    check("all 96 cells retained in exact order", len(rows) == 96 and [(row["block"], row["scenario"], row["position"], row["variant"]) for row in rows] == sequence)
    check("every worker exited successfully without stderr", all(row["returncode"] == 0 and row["stderr"] == "" for row in rows))
    check("every cell uses exact source, counts and asserted result check", all(row["cell"]["source"] == protocol["sources"][row["variant"]] and row["cell"]["iterations"] == 256 and row["cell"]["warmup"] == 16 and row["cell"]["scenario"] == row["scenario"] and row["cell"]["all_actual_results_equal_expected"] is True for row in rows))
    commands = []
    for row in rows:
        command = row["command"]
        expected = [command[0], "-I", "-S", command[3], "_worker", "--source", protocol["sources"][row["variant"]]["path"], "--scenario", row["scenario"], "--iterations", "256", "--warmup", "16"]
        if row["scenario"] == "live_detached":
            expected += ["--fixture-supervisor-pid", str(protocol["live_fixture_supervisor_pid"])]
        commands.append(command == expected)
    check("explicit worker argv preserves all planned inputs", all(commands) and len({(row["command"][0], row["command"][3]) for row in rows}) == 1)
    check("monotonic endpoints reproduce every CPU and wall statistic", all((c := row["cell"])["cpu_end_ns"] > c["cpu_start_ns"] and c["wall_end_ns"] > c["wall_start_ns"] and c["cpu_end_ns"] - c["cpu_start_ns"] == c["cpu_ns"] and c["wall_end_ns"] - c["wall_start_ns"] == c["wall_ns"] and c["cpu_ns_per_call"] == c["cpu_ns"] / 256 and c["wall_ns_per_call"] == c["wall_ns"] / 256 and row["driver_wall_ns"] > c["wall_ns"] for row in rows))
    check("same Python, Linux platform, allocator and clock contracts", all(row["cell"]["python"] == protocol["python"] and row["cell"]["platform"].startswith("Linux-") and row["cell"]["selected_allocator_environment"] == {"PYTHONMALLOC": None, "MALLOC_ARENA_MAX": None} and all(row["cell"][key]["monotonic"] is True and row["cell"][key]["adjustable"] is False for key in ("clock_process_time", "clock_perf_counter")) for row in rows))
    check("HWM is nondecreasing across actual sample phases", all((c := row["cell"])["ru_maxrss_before_bytes"] <= c["ru_maxrss_after_bytes"] <= c["ru_maxrss_after_allocation_samples_bytes"] for row in rows))
    check("three untimed allocation samples per worker retained", all(len(row["cell"]["untimed_tracemalloc_samples"]) == 3 and all(0 <= sample["current_bytes"] <= sample["peak_bytes"] for sample in row["cell"]["untimed_tracemalloc_samples"]) for row in rows))
    expected = rebuild_static_fixtures()
    check("five static fixtures and expected result digests independently reconstructed", all(row["cell"]["fixture"] == expected[row["scenario"]][0] and row["cell"]["expected_result"] == expected[row["scenario"]][1] for row in rows if row["scenario"] in expected))
    live = [row["cell"] for row in rows if row["scenario"] == "live_detached"]
    check("live fixture binds one held parent with identical result identity", len(live) == 16 and all(c["fixture"]["fixture_supervisor_pid"] == protocol["live_fixture_supervisor_pid"] and c["fixture"]["supervisor_identity_kind"] == "proc_start_ticks" and c["fixture"]["request_bytes"] == 122 for c in live) and len({json.dumps(c["expected_result"], sort_keys=True) for c in live}) == 1)

    tables, extra = {}, {}
    for scene in SCENARIOS:
        selected = [row for row in rows if row["scenario"] == scene]
        paired = []
        for block in range(4):
            arms = {label: [row["cell"]["cpu_ns"] / row["cell"]["iterations"] for row in selected if row["block"] == block and row["variant"] == label] for label in "AB"}
            a, b = sum(arms["A"]) / 2, sum(arms["B"]) / 2
            paired.append({"block": block, "a_cpu_ns_per_call": a, "b_cpu_ns_per_call": b, "b_over_a_cpu": b / a})
        variants, phases = {}, {}
        for label in "AB":
            cells = [row["cell"] for row in selected if row["variant"] == label]
            variants[label] = {
                "cpu_ns_per_call_median": median(c["cpu_ns"] / 256 for c in cells),
                "wall_ns_per_call_median": median(c["wall_ns"] / 256 for c in cells),
                "traced_peak_bytes_median": median(sample["peak_bytes"] for c in cells for sample in c["untimed_tracemalloc_samples"]),
                "worker_lifetime_hwm_bytes_median": median(c["ru_maxrss_after_allocation_samples_bytes"] for c in cells),
            }
            phases[label] = {field: {"minimum": min(c[field] for c in cells), "median": median(c[field] for c in cells), "maximum": max(c[field] for c in cells)} for field in ("ru_maxrss_before_bytes", "ru_maxrss_after_bytes", "ru_maxrss_after_allocation_samples_bytes")}
        tables[scene] = {"variants": variants, "paired_blocks": paired, "paired_cpu_change_percent_median": (median(pair["b_over_a_cpu"] for pair in paired) - 1) * 100, "b_faster_blocks": sum(pair["b_over_a_cpu"] < 1 for pair in paired)}
        extra[scene] = {
            "hwm_phase_ranges": phases,
            "paired_cpu_change_percent_range": [100 * (min(pair["b_over_a_cpu"] for pair in paired) - 1), 100 * (max(pair["b_over_a_cpu"] for pair in paired) - 1)],
            "traced_peak_change_percent": 100 * (variants["B"]["traced_peak_bytes_median"] / variants["A"]["traced_peak_bytes_median"] - 1),
        }
    recomputed = {"schema": "hepta-python-read-component-abba-summary-v1", "scope": protocol["scope"], "scenarios": tables, "cells": len(rows), "rounds": 4, "all_cells_passed": True, "raw_cells_sha256": digest(raw_path.read_bytes()), "protocol_sha256": digest(protocol_path.read_bytes()), "finished_utc": original["finished_utc"]}
    check("every summary value independently reproduced", recomputed == original, "Only the finished_utc label is passed through; all statistics, counts, identities and raw hashes are rederived.")
    rebuilt = (json.dumps(recomputed, indent=2) + "\n").encode()
    check("regenerated summary bytes equal original", rebuilt == original_path.read_bytes())
    check("predeclared component allocation gate passes", all(extra[scene]["traced_peak_change_percent"] <= -90 for scene in ("private_small", "terminal_small")))
    semantic = read_json(root / "semantic-tests-x230-01.json")
    check("X230 semantic suite binds exact final source and tools", semantic["tests_run"] == 14 and semantic["successful"] and semantic["failed"] == semantic["errors"] == semantic["skipped"] == 0 and semantic["test_script_sha256"] == TESTS and semantic["probe_script_sha256"] == PROBE and all(semantic["source_bindings"][label]["source_sha256"] == local[label]["source_sha256"] for label in "AB"))
    grouped = defaultdict(dict)
    for observation in semantic["observations"]:
        key = (observation["kind"], observation["case"])
        assert observation["variant"] not in grouped[key]
        grouped[key][observation["variant"]] = observation
    check("all 119 semantic outcome pairs agree", len(semantic["observations"]) == 238 and len(grouped) == 119 and all(set(pair) == {"A", "B"} and pair["A"]["ok"] == pair["B"]["ok"] and pair["A"]["result"] == pair["B"]["result"] for pair in grouped.values()))
    leaks = {}
    for case in ("unsafe-terminal-directory", "terminal-fdopen-failure"):
        pair = grouped[("terminal", case)]
        leaks[case] = {label: {key: pair[label][key] for key in ("file_fds_open_at_return", "explicit_close_counts", "result")} for label in "AB"}
    check("FD leak difference is exactly baseline one and candidate zero", all(pair["A"]["file_fds_open_at_return"] == 1 and pair["B"]["file_fds_open_at_return"] == 0 and pair["B"]["explicit_close_counts"] == [1] for pair in leaks.values()))
    check("all candidate terminal opened descriptors explicitly closed once", all(o["file_fds_open_at_return"] == 0 and all(n == 1 for n in o["explicit_close_counts"]) for o in semantic["observations"] if o["variant"] == "B" and o["kind"] == "terminal"))
    eagain_cases = [pair for pair in grouped.values() if any(event.get("returned", "absent") is None and "raw_read" in event for event in pair["A"].get("trace", []))]
    no_retry = True
    for pair in eagain_cases:
        for observation in pair.values():
            trace = observation["trace"]
            blocked = [i for i, event in enumerate(trace) if "raw_read" in event and event.get("returned", "absent") is None]
            no_retry &= len(blocked) == 1 and not any("raw_read" in event for event in trace[blocked[0] + 1 :])
    check("all nine EAGAIN pairs retain no-retry behavior", len(eagain_cases) == 9 and no_retry)
    check("local code and tools unchanged during audit", digest(args.baseline.read_bytes()) == BASELINE and digest(args.candidate.read_bytes()) == CANDIDATE and digest(args.probe.read_bytes()) == PROBE and digest(args.tests.read_bytes()) == TESTS)
    report = {
        "schema": "hepta-r19-x230-component-independent-recomputation-v1",
        "input_root": str(root),
        "archive_sha256": ARCHIVE,
        "recompute_script_sha256": digest(Path(__file__).read_bytes()),
        "checks": checks,
        "all_checks_passed": all(c["passed"] for c in checks),
        "recomputed_summary_sha256": digest(rebuilt),
        "counts": {"cells": 96, "scenarios": 6, "blocks_per_scenario": 4, "measured_calls": 96 * 256, "warmup_calls": 96 * 16, "untimed_allocation_calls": 96 * 3, "semantic_pairs": 119},
        "total_measured_worker_cpu_ns": sum(row["cell"]["cpu_ns"] for row in rows),
        "total_measured_worker_wall_ns": sum(row["cell"]["wall_ns"] for row in rows),
        "extra_statistics": extra,
        "fd_leak_differential": leaks,
        "limits": [
            "Only component allocation acceptance is decided here; fresh Rust qualification, native regression screen and recovery are separate pending gates.",
            "CPU brackets the timed loop plus the enclosing CPU/perf-counter clock reads and includes every equality comparison; it excludes warmup, AST extraction, fixture creation, tracemalloc and helper subprocess CPU.",
            "The measurements use freshly created synthetic private files and warmup, not cold storage or real workload completion throughput. Both 64KiB fixtures are small JSON plus trailing spaces.",
            "All HWM samples are whole-worker historical maxima; they do not measure current or per-call RSS. Initialization/fork history may dominate, but the evidence does not identify that cause.",
            "tracemalloc peaks are separate untimed calls. They establish Python traced allocation changes, not RSS or cluster memory changes.",
            "The raw cells retain expected-result digests and the frozen worker's equality assertion flags, not each actual return payload. Five static expectations were independently reconstructed; the live identity lacks saved boot/start bytes, so only its invariant digest and held parent binding can be checked offline.",
            "A new Python interpreter is invoked for each remote observation through python3 -c; SSH master reuse is not persistent Python. OS process exit reclaims residual descriptors. A process_wait helper loops internally and may repeat a caught terminal-read fault during its own lifetime, but no accumulated real-helper leak count was measured.",
            "Four ABBA blocks are a fixed finite component experiment; no confidence interval or global performance optimum is inferred.",
        ],
    }
    (out / "recomputed-summary.json").write_bytes(rebuilt)
    with (out / "independent-audit.json").open("x") as stream:
        json.dump(report, stream, indent=2)
        stream.write("\n")
    print(json.dumps({"all_checks_passed": report["all_checks_passed"], "checks": len(checks), "cells": len(rows), "summary_sha256": digest(rebuilt), "audit_sha256": digest((out / "independent-audit.json").read_bytes()), "output": str(out)}))


if __name__ == "__main__":
    main()
