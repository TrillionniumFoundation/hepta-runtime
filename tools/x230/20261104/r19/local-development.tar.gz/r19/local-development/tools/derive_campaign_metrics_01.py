#!/usr/bin/env python3
# Copyright 2026 TrillionniumFoundation
# SPDX-License-Identifier: Apache-2.0
"""Describe the already verified R19 raw replay; never run a workload or test."""
from collections import Counter
import datetime
import hashlib
import json
import math
from pathlib import Path
import statistics

ROOT = Path(__file__).resolve().parent.parent
EVIDENCE = ROOT / 'publication/replay-01/extracted/r19'
AUDIT = ROOT / 'review/offline-raw-audit-01'
OUTPUT = ROOT / 'review/derived-campaign-metrics-01.json'


def main():
    inputs = {}

    def load(path):
        raw = path.read_bytes()
        inputs[str(path)] = {'path': str(path), 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}
        return json.loads(raw)

    replay = load(AUDIT / 'report.json')
    proof = load(ROOT / 'review/qualified-source-binding-01.json')
    assert replay['passed'] is True and proof['verified'] is True
    assert all(x['returncode'] == 0 and x['equals_original_analysis'] is True for x in replay['audits'])
    native = load(AUDIT / 'native-independent.json')
    boundary = load(AUDIT / 'boundary-independent.json')
    recovery = load(AUDIT / 'recovery-independent.json')
    raw_native = load(EVIDENCE / 'native-observation-01/report.json')
    component = load(EVIDENCE / 'component-probe-01/summary.json')
    assert native['verified'] and boundary['evidence_verified'] and boundary['diagnostic_passed'] and recovery['verified']
    assert component['all_cells_passed'] is True
    nearest = lambda values, q: sorted(values)[max(0, math.ceil(len(values) * q) - 1)]
    cases = []
    for item in native['cases']:
        concurrency = item['concurrency']
        cells = [next(c for c in r['cells'] if c['concurrency'] == concurrency) for r in raw_native['rounds']]
        pairs = []
        for a, b in ((0, 1), (3, 2)):
            av, bv = cells[a], cells[b]
            ratio = (bv['calls'] / bv['seconds']) / (av['calls'] / av['seconds'])
            p95 = {v: nearest([r['elapsed_ms'] for r in cell['rows']], .95)
                   for v, cell in (('A', av), ('B', bv))}
            pairs.append({'A_round': a, 'B_round': b, 'B_over_A_successful_rate': ratio,
                          'successful_rate_change_percent': 100 * (ratio - 1),
                          'A_p95_ms': p95['A'], 'B_p95_ms': p95['B'], 'B_over_A_p95': p95['B'] / p95['A'],
                          'B_over_A_controller_cpu_per_call':
                              (bv['controller_cpu_seconds'] / bv['calls']) / (av['controller_cpu_seconds'] / av['calls'])})
        a, b = item['arms']['A'], item['arms']['B']
        ratios = {name: b[name] / a[name] for name in
                  ('calls_per_second', 'controller_cpu_ms_per_call', 'p50_ms', 'p95_ms', 'p99_ms', 'max_ms')}
        cases.append({'concurrency': concurrency, 'aggregate': item, 'aggregate_B_over_A': ratios,
                      'pre_registered_screen': {'rate_at_least_0_95': ratios['calls_per_second'] >= .95,
                                                'p95_at_most_1_10': ratios['p95_ms'] <= 1.10},
                      'descriptive_ABBA_pairs': pairs})
    observations = []
    for row in native['resources']:
        value = row['observations']
        observations.append({'round': row['round'], 'version': row['version'], 'phase': row['phase'],
                             'peaks': value['peaks'], 'metric_samples': value['metric_samples'],
                             'error_counts': value['error_counts']})
    resource_summary = {}
    for phase in ('shutdown', 'restart_shutdown'):
        per_metric = {}
        for metric in ('controller_hwm_kib', 'controller_rss_kib', 'tree_rss_kib', 'controller_fd', 'tree_fd', 'descendants'):
            arms = {}
            for arm in ('A', 'B'):
                rows = [r for r in observations if r['phase'] == phase and r['version'] == arm]
                values = [r['peaks'][metric] for r in rows]
                samples = [r['metric_samples'].get(metric) for r in rows]
                if metric != 'descendants':
                    assert all(value is not None and value > 0 for value in samples)
                arms[arm] = {'round_values': values, 'mean_of_round_peaks': statistics.mean(values),
                             'minimum_round_peak': min(values), 'maximum_round_peak': max(values),
                             'metric_sample_counts': samples}
            a, b = arms['A']['mean_of_round_peaks'], arms['B']['mean_of_round_peaks']
            per_metric[metric] = {'arms': arms, 'mean_peak_B_minus_A': b - a,
                                  'mean_peak_change_percent': 100 * (b / a - 1) if a else None}
        resource_summary[phase] = per_metric
    missing = Counter()
    for row in observations:
        missing.update(row['error_counts'])
    native_frames = sum(r['transport']['frames_rehashed'] for r in native['raw_evidence'])
    native_notifications = sum(r['transport']['notifications_retained'] for r in native['raw_evidence'])
    component_projection = {}
    for name in ('private_small', 'terminal_small'):
        scene = component['scenarios'][name]
        a, b = scene['variants']['A'], scene['variants']['B']
        reduction = 1 - b['traced_peak_bytes_median'] / a['traced_peak_bytes_median']
        component_projection[name] = {'A': a, 'B': b, 'traced_peak_reduction_percent': 100 * reduction,
                                      'pre_registered_at_least_90_percent': reduction >= .90,
                                      'paired_cpu_change_percent_median': scene['paired_cpu_change_percent_median'],
                                      'worker_lifetime_hwm_bytes_change': b['worker_lifetime_hwm_bytes_median'] - a['worker_lifetime_hwm_bytes_median']}
    refused = boundary['counts']['capacity_rejection']
    calls = native['total_calls'] + boundary['total_tool_calls'] + recovery['native_calls']
    frames = native_frames + boundary['raw_transport']['frames_rehashed'] + recovery['raw_evidence']['transport']['frames_rehashed']
    screened = all(all(c['pre_registered_screen'].values()) for c in cases)
    peak_screened = all(c['pre_registered_at_least_90_percent'] for c in component_projection.values())
    result = {
        'schema': 'hepta-r19-offline-derived-metrics/v1', 'derived_from_verified_raw_replay': True,
        'created_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'workloads_run': False,
        'source_proof_verified': True, 'inputs': inputs,
        'tool': {'path': str(Path(__file__).resolve()), 'sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest()},
        'native': {'cases': cases, 'measured_calls': native['measured_calls'], 'warmup_calls': native['warmup_calls'],
                   'preflight_restart_calls': native['preflight_restart_calls'], 'total_tool_calls': native['total_calls'],
                   'raw_frames': native_frames, 'notifications': native_notifications,
                   'frame_counts_by_round': [r['transport'] for r in native['raw_evidence']],
                   'resource_trace_records': sum(t['trace_records_recomputed'] for r in native['raw_evidence'] for t in r['resource_traces']),
                   'resource_observations': observations, 'resource_summary_by_phase': resource_summary,
                   'missing_observations': dict(missing)},
        'boundary': {'counts': boundary['counts'], 'bursts': boundary['bursts'],
                     'successful_burst_calls_per_second_aggregate': boundary['counts']['success'] / math.fsum(b['seconds'] for b in boundary['bursts']),
                     'total_tool_calls': boundary['total_tool_calls'], 'raw_frames': boundary['raw_transport']['frames_rehashed'],
                     'post_drain_calls': boundary['post_drain_calls'], 'drain_and_recovery_passed': boundary['drain_and_recovery_passed']},
        'recovery': {'native_calls': recovery['native_calls'], 'independent_ssh_calls': recovery['independent_ssh_calls'],
                     'new_starts': recovery['new_starts'], 'same_key_lookups': recovery['same_key_lookups'],
                     'cancellations': recovery['cancellations'], 'hosts': recovery['hosts'],
                     'raw_frames': recovery['raw_evidence']['transport']['frames_rehashed'],
                     'ssh_streams_rehashed': recovery['raw_evidence']['ssh_streams_rehashed'], 'elapsed_seconds': recovery['elapsed_seconds']},
        'totals': {'tool_calls': calls, 'successful_tool_calls': calls - refused - boundary['counts']['other_error'],
                   'capacity_refusals': refused, 'other_errors': boundary['counts']['other_error'], 'raw_frames': frames,
                   'independent_ssh_checks_excluded_from_native_tool_count': recovery['independent_ssh_calls']},
        'component_summary_projection': component_projection,
        'fixed_screens': {'native_all_C1_C8_C16_pass': screened, 'component_small_traced_peaks_pass': peak_screened,
                          'all_three_correctness_replays_pass': True, 'all_pass': screened and peak_screened},
        'binary_locations_and_hashes': proof['binaries'],
        'interpretation': [
            'Aggregate B/A rate is sum(successful calls)/sum(cell seconds) for each arm; pooled nearest-rank tails use 384 measured calls per arm per concurrency.',
            'Pair ratios B1/A0 and B2/A3 describe the two ABBA pairs; they are not the pre-registered aggregate screen and do not establish significance.',
            'C32 success and capacity refusal rates remain separate. Total attempted completions are not successful throughput; pool_identity_peak is unobserved.',
            'Controller HWM/RSS values are sampled lifetime/phase peaks covering preflight, warmup and all concurrency cells, not per-cell deltas.',
            'Tree RSS is a non-atomic process sum with shared-page double counting and incomplete descendant sampling; missing observations are retained.',
            'A zero peak with zero metric samples means unavailable rather than measured zero. No memory reduction is inferred from unsampled scopes.',
            'The component values here project the preserved component summary, already independently recomputed elsewhere; this script does not rerun or reanalyse its 96 cells.',
            'Python traced allocation is not whole-process or six-host RSS. The small-scene worker lifetime HWM medians are unchanged.',
            'Finite shared-host evidence with two rounds per version establishes these observations and fixed screens, not a universal performance ceiling.'
        ]}
    with OUTPUT.open('xb') as stream:
        stream.write((json.dumps(result, indent=2, sort_keys=True) + '\n').encode())
    print(json.dumps({'path': str(OUTPUT), 'sha256': hashlib.sha256(OUTPUT.read_bytes()).hexdigest(),
                      'bytes': OUTPUT.stat().st_size, 'totals': result['totals'], 'screens': result['fixed_screens'],
                      'pairs': [{'concurrency': c['concurrency'], 'rate_changes_percent': [p['successful_rate_change_percent'] for p in c['descriptive_ABBA_pairs']]} for c in cases],
                      'first_phase_hwm_mean_change_kib': resource_summary['shutdown']['controller_hwm_kib']['mean_peak_B_minus_A']}, sort_keys=True))


if __name__ == '__main__':
    main()
