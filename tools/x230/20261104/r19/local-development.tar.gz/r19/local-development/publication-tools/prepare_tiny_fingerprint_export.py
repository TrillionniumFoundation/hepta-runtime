#!/usr/bin/env python3
# Copyright 2026 TrillionniumFoundation
# SPDX-License-Identifier: Apache-2.0
"""Copy only the six frozen tiny-probe fingerprint JSON files outside targets.

No target traversal, compiled binary reads, commands, network or credential reads.
Run once after the evidence window closes, before the unchanged archive driver.
"""
import argparse
import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import stat
import sys
import tempfile

ROOT = Path('/home/qian/hepta-runtime-optimization-20261104-r19')
PROBE = ROOT / 'cargo-empty-wrapper-probe-01'
REPORT_SHA = 'cae75b491c52271b72439018c68059657da72080999894ec15a57b313e71d824'
OUTPUT = ROOT / 'publication/tiny-fingerprints-01'
CASES = ['A-unset', 'B-empty', 'A2-unset']
FILENAMES = {'bin-wrapper-metadata-probe.json', 'lib-wrapper_metadata_probe.json'}


def need(value, message):
    if not value:
        raise ValueError(message)


def read_exact(path, expected, maximum=65536):
    path = Path(path)
    need(path.absolute() == path.resolve(), 'indirect evidence path')
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK | os.O_CLOEXEC)
    try:
        before = os.fstat(fd)
        need(stat.S_ISREG(before.st_mode) and before.st_nlink == 1 and before.st_size <= maximum,
             'fingerprint is not an independent bounded regular file')
        parts, length = [], 0
        while length <= maximum:
            part = os.read(fd, min(65536, maximum + 1 - length))
            if not part:
                break
            parts.append(part)
            length += len(part)
        raw = b''.join(parts)
        fields = ('st_dev', 'st_ino', 'st_mode', 'st_nlink', 'st_size', 'st_mtime_ns', 'st_ctime_ns')
        identity = tuple(getattr(before, f) for f in fields)
        need(length == before.st_size and all(tuple(getattr(s, f) for f in fields) == identity
             for s in (os.fstat(fd), path.lstat())), 'fingerprint changed while read')
        need(hashlib.sha256(raw).hexdigest() == expected, 'frozen fingerprint SHA256 differs')
        return raw
    finally:
        os.close(fd)


def write_new(path, raw):
    with path.open('xb') as stream:
        stream.write(raw)


def self_test():
    with tempfile.TemporaryDirectory() as temporary:
        root = Path(temporary)
        original = root / 'original.json'
        raw = b'{  "test": true }\n\n'
        write_new(original, raw)
        expected = hashlib.sha256(raw).hexdigest()
        copied = root / 'copied.json'
        write_new(copied, read_exact(original, expected))
        need(copied.read_bytes() == raw, 'raw bytes were normalized')
        original.write_bytes(b'{"changed":true}\n')
        try:
            read_exact(original, expected)
        except ValueError:
            pass
        else:
            raise AssertionError('mutation accepted')
        link = root / 'link.json'
        link.symlink_to(copied)
        try:
            read_exact(link, expected)
        except ValueError:
            pass
        else:
            raise AssertionError('symlink accepted')
        try:
            write_new(copied, b'overwrite')
        except FileExistsError:
            pass
        else:
            raise AssertionError('existing copy overwritten')
    print(json.dumps({'self_test': True, 'checks': 4, 'target_accessed': False, 'builds_started': False}))
    return 0


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--evidence-window-closed', action='store_true')
    parser.add_argument('--self-test', action='store_true')
    args = parser.parse_args()
    if args.self_test:
        return self_test()
    need(args.evidence_window_closed, 'explicit closed-evidence-window assertion required')
    report_path = PROBE / 'report.json'
    raw_report = read_exact(report_path, REPORT_SHA, 1024 * 1024)
    report = json.loads(raw_report)
    need(report['schema'] == 'hepta-r19-cargo-empty-wrapper-probe/v1' and report['passed'] is True
         and report['automatic_retries'] == 0 and all(v is True for v in report['checks'].values())
         and [c['label'] for c in report['cases']] == CASES, 'unexpected frozen tiny-probe report')
    need(OUTPUT.parent.is_dir() and OUTPUT.parent.resolve() == OUTPUT.parent, 'invalid publication directory')
    OUTPUT.mkdir(mode=0o700)  # Never overwrite an export attempt.
    receipt = {'schema': 'hepta-r19-tiny-fingerprint-export/v1', 'passed': False,
               'started_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
               'report': {'path': str(report_path), 'sha256': REPORT_SHA}, 'files': [],
               'scope': 'Six explicitly named JSON metadata files only; no target tree or compiled artifact is exported.',
               'source_bytes_modified': False, 'automatic_retries': 0, 'builds_started': False,
               'tool_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
    try:
        for case in report['cases']:
            target = PROBE / ('target-' + case['label'])
            need(case['target'] == str(target) and len(case['unit_fingerprints']) == 2
                 and {r['file'] for r in case['unit_fingerprints']} == FILENAMES, 'unexpected fingerprint set')
            for row in case['unit_fingerprints']:
                need(re.fullmatch('wrapper-metadata-probe-[0-9a-f]{16}', row['unit']) is not None
                     and re.fullmatch('[0-9a-f]{64}', row['sha256']) is not None, 'unsafe fingerprint selector')
                source = target / 'release/.fingerprint' / row['unit'] / row['file']
                raw = read_exact(source, row['sha256'])
                need(json.loads(raw) == row['value'], 'fingerprint JSON differs from the frozen report')
                relative = Path(case['label']) / row['unit'] / row['file']
                destination = OUTPUT / relative
                destination.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
                write_new(destination, raw)
                need(read_exact(destination, row['sha256']) == raw, 'fingerprint export differs')
                receipt['files'].append({'source': str(source), 'relative': relative.as_posix(),
                                         'size': len(raw), 'sha256': row['sha256']})
        need(len(receipt['files']) == 6 and read_exact(report_path, REPORT_SHA, 1024 * 1024) == raw_report,
             'report changed during export')
        for row in receipt['files']:
            read_exact(Path(row['source']), row['sha256'])
            read_exact(OUTPUT / row['relative'], row['sha256'])
        receipt['passed'] = True
    except BaseException as error:
        receipt['error'] = {'type': type(error).__name__, 'message': str(error)}
    finally:
        receipt['finished_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
        manifest = OUTPUT / 'manifest.json'
        raw = (json.dumps(receipt, sort_keys=True, indent=2) + '\n').encode()
        write_new(manifest, raw)
        print(json.dumps({'passed': receipt['passed'], 'manifest': str(manifest),
                          'manifest_sha256': hashlib.sha256(raw).hexdigest(), 'files': len(receipt['files']),
                          'error': receipt.get('error')}), flush=True)
    return 0 if receipt['passed'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
