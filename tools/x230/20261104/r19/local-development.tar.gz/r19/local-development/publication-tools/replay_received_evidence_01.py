#!/usr/bin/env python3
# Copyright 2026 TrillionniumFoundation
# SPDX-License-Identifier: Apache-2.0
"""Verify a closed 83-file transfer, extract nine packages, replay three audits.

Local evidence only. This never imports a workload runner or executes a runtime.
Existing source evidence, archives and original independent summaries are read
only; extraction and audit output both require fresh, separate directories.
"""
import argparse
import datetime
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import stat
import subprocess
import sys
import tarfile
import time
import traceback

HERE = Path(__file__).resolve().parent
PLAN = HERE / 'r19-plan-final-02.json'
PLAN_SHA = '0d89dda957690e18372fdfe282d9d46b79e3c6bf779219b8a8b92c3db7b7c0e5'
PACKAGER_SHA = '226edda9684f742178398c09266a171df38df5e505c0020372e72265ff684c43'
REPO = 'tools/x230/20261104/r19'
STEMS = ['qualification-01', 'prequalification-component-01', 'qualification-02',
         'qualification-resolution-02', 'qualification-diagnostics-01', 'campaign-control-01',
         'native-observation-01', 'native-boundary-01', 'cancel-recovery-01']


def need(value, reason):
    if not value:
        raise ValueError(reason)


def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def encode(value):
    return (json.dumps(value, sort_keys=True, indent=2) + '\n').encode()


def save(path, value):
    with path.open('xb') as stream:
        stream.write(encode(value))


def direct(path):
    path = Path(path).absolute()
    need(path.resolve() == path, 'indirect path: ' + str(path))
    return path


def fingerprint(path):
    path = direct(path)
    before = path.stat()
    need(stat.S_ISREG(before.st_mode), 'not a regular file: ' + str(path))
    sha = hashlib.sha256()
    git = hashlib.sha1(('blob ' + str(before.st_size) + '\0').encode(), usedforsecurity=False)
    size = 0
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            size += len(block)
            sha.update(block)
            git.update(block)
        after = os.fstat(stream.fileno())
    stamp = lambda s: (s.st_dev, s.st_ino, s.st_size, s.st_mtime_ns, s.st_ctime_ns)
    need(size == before.st_size and stamp(before) == stamp(after) == stamp(path.stat()), 'file changed')
    return {'path': str(path), 'bytes': size, 'sha256': sha.hexdigest(), 'git_blob_sha1': git.hexdigest()}


def load(path):
    return json.loads(path.read_bytes())


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--stage-root', type=Path, required=True)
    parser.add_argument('--index', type=Path, required=True)
    parser.add_argument('--expected-index-sha256', required=True)
    parser.add_argument('--extract-root', type=Path, required=True)
    parser.add_argument('--output-root', type=Path, required=True)
    args = parser.parse_args()
    stage, index_path, extracted, out = map(direct, (args.stage_root, args.index, args.extract_root, args.output_root))
    need(stage.is_dir(), 'received stage is not present')
    need(not os.path.lexists(extracted) and not os.path.lexists(out), 'extraction/output must be fresh')
    need(not any(a.is_relative_to(b) or b.is_relative_to(a) for a, b in
                 ((stage, extracted), (stage, out), (extracted, out))), 'input/output directories overlap')
    need(not index_path.is_relative_to(extracted) and not index_path.is_relative_to(out), 'index lies in output')
    out.mkdir(mode=0o700, parents=True)
    result = {'schema': 'hepta-r19-offline-raw-replay/v1', 'passed': False, 'started_utc': now(),
              'workloads_run': False, 'builds_run': False, 'network_requests': 0, 'automatic_retries': 0,
              'stage_root': str(stage), 'extract_root': str(extracted), 'archives': [], 'audits': []}
    try:
        result['tool'] = fingerprint(Path(__file__))
        result['plan'] = fingerprint(PLAN)
        need(result['plan']['sha256'] == PLAN_SHA, 'frozen publication plan differs')
        packager = HERE / 'package_x230_evidence.py'
        result['packager'] = fingerprint(packager)
        need(result['packager']['sha256'] == PACKAGER_SHA, 'original packager differs')
        spec = importlib.util.spec_from_file_location('r19_frozen_packager', packager)
        original = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(original)
        result['index'] = fingerprint(index_path)
        need(result['index']['sha256'] == args.expected_index_sha256, 'original index SHA differs')
        index = load(index_path)
        need(index['schema'] == 'hepta-x230-publication-transfer/v1' and len(index['files']) == 83,
             'transfer is not the complete expected 83-file index')
        indexed = {}
        for row in index['files']:
            name = row['repo_path']
            original.parts(name)
            need(name not in indexed, 'duplicate indexed path')
            actual = fingerprint(stage / name)
            need(all(actual[key] == row[key] for key in ('bytes', 'sha256', 'git_blob_sha1')), 'received indexed bytes differ')
            indexed[name] = actual
        actual_paths = set()
        for path in stage.rglob('*'):
            need(not path.is_symlink(), 'received stage contains a symlink')
            if path.is_file():
                actual_paths.add(path.relative_to(stage).as_posix())
        need(actual_paths == set(indexed), 'received stage contains extra or missing files')
        result['transfer_files_verified'] = len(indexed)
        plan = load(PLAN)
        packages = {p['id']: p for p in plan['packages']}
        need(plan['publication_groups']['remote']['packages'] == ['r19-' + s for s in STEMS], 'package set differs')
        manifests, expected = {}, {}
        for stem in STEMS:
            base = stage / REPO
            archive, manifest, receipt_path = (base / (stem + suffix) for suffix in ('.tar.gz', '.manifest.json', '.archive.json'))
            receipt = load(receipt_path)
            need(receipt.get('verified') is True and receipt.get('original_bytes_changed') is False
                 and receipt.get('plan_sha256') == PLAN_SHA, 'archive receipt was not verified')
            verified = original.verify(archive, manifest)
            need(all(verified[key] == receipt[key] for key in
                     ('archive_bytes', 'archive_sha256', 'manifest_sha256')), 'archive receipt identity differs')
            body = load(manifest)
            manifests[stem] = body
            result['archives'].append({'stem': stem, 'receipt': fingerprint(receipt_path), **verified})
            for row in body['files']:
                name = row['archive_path']
                original.parts(name)
                need(name.startswith('r19/'), 'member outside the R19 bundle')
                comparison = {'bytes': row['bytes'], 'sha256': row['sha256']}
                need(name not in expected or expected[name] == comparison, 'conflicting cross-package duplicate')
                expected[name] = comparison
        save(out / 'archive-verification.json', result['archives'])
        extracted.mkdir(mode=0o700, parents=True)
        duplicate_count = 0
        for stem in STEMS:
            with tarfile.open(stage / REPO / (stem + '.tar.gz'), mode='r|gz') as tar:
                for member in tar:
                    if member.name == '_publication/r19-' + stem + '/manifest.json':
                        continue
                    need(member.name in expected and member.isreg() and not member.issym() and not member.islnk(),
                         'unexpected extraction member')
                    original.parts(member.name)
                    raw = tar.extractfile(member).read()
                    need(len(raw) == expected[member.name]['bytes']
                         and hashlib.sha256(raw).hexdigest() == expected[member.name]['sha256'], 'extraction bytes differ')
                    path = extracted / member.name
                    if path.exists():
                        need(path.read_bytes() == raw, 'duplicate extraction bytes differ')
                        duplicate_count += 1
                    else:
                        path.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
                        with path.open('xb') as stream:
                            stream.write(raw)
        need({p.relative_to(extracted).as_posix() for p in extracted.rglob('*') if p.is_file()} == set(expected),
             'extracted file set differs')
        result['extraction'] = {'unique_files': len(expected), 'identical_duplicate_members': duplicate_count,
                                'all_selected_file_bytes_verified': True, 'embedded_manifests_preserved_in_archives': True}
        pins = {}
        for stem in STEMS:
            package = packages['r19-' + stem]
            if 'expected_report_sha256' in package:
                key = package.get('campaign', package.get('qualification'))['bundle'] + '/report.json'
                pins[key] = package['expected_report_sha256']
            for selector in package.get('selectors', []):
                for relative, sha in selector.get('expected_sha256', {}).items():
                    key = selector['bundle'].rstrip('/') + '/' + relative
                    need(key not in pins or pins[key] == sha, 'conflicting plan pin')
                    pins[key] = sha
        need(all(fingerprint(extracted / path)['sha256'] == sha for path, sha in pins.items()), 'extracted plan-bound source differs')
        result['explicit_plan_pins_verified'] = len(pins)
        evidence = extracted / 'r19'
        harness = evidence / 'measurement-tools'
        calls = [
            ('native', harness / 'analyze_native_observation.py', evidence / 'native-observation-01', []),
            ('boundary', evidence / 'boundary-tools/audit_native_boundary.py', evidence / 'native-boundary-01',
             ['--harness-root', str(harness)]),
            ('recovery', harness / 'verify_cancel_recovery.py', evidence / 'cancel-recovery-01', []),
        ]
        for name, tool, directory, additional in calls:
            output = out / (name + '-independent.json')
            argv = [sys.executable, '-B', str(tool), '--report', str(directory / 'report.json'),
                    '--output', str(output), *additional]
            row = {'name': name, 'argv': argv, 'started_utc': now(), 'tool': fingerprint(tool),
                   'original_analysis': fingerprint(directory / 'independent-summary.json')}
            result['audits'].append(row)
            started = time.monotonic()
            stdout, stderr = (out / (name + '.' + stream) for stream in ('stdout', 'stderr'))
            with stdout.open('xb') as sout, stderr.open('xb') as serr:
                child = subprocess.run(argv, stdin=subprocess.DEVNULL, stdout=sout, stderr=serr, timeout=180,
                                       env={k: v for k, v in os.environ.items() if k not in ('PYTHONPATH', 'PYTHONHOME')})
            row.update(returncode=child.returncode, finished_utc=now(), seconds=time.monotonic() - started,
                       stdout=fingerprint(stdout), stderr=fingerprint(stderr))
            need(child.returncode == 0, name + ' frozen audit failed')
            analysis = load(output)
            need(analysis.get('verified') is True or (analysis.get('evidence_verified') is True
                 and analysis.get('diagnostic_passed') is True), name + ' audit did not accept')
            row.update(output=fingerprint(output), equals_original_analysis=analysis == load(directory / 'independent-summary.json'))
            need(row['equals_original_analysis'], name + ' original and replayed analyses differ')
        need(fingerprint(index_path) == result['index'] and fingerprint(PLAN) == result['plan']
             and fingerprint(packager) == result['packager'], 'replay input changed')
        result['passed'] = True
    except BaseException as error:
        result['error'] = {'type': type(error).__name__, 'message': str(error)}
        with (out / 'error.txt').open('xb') as stream:
            stream.write(traceback.format_exc().encode())
    finally:
        result['finished_utc'] = now()
        save(out / 'report.json', result)
        print(json.dumps({'passed': result['passed'], 'report': fingerprint(out / 'report.json'),
                          'archives': len(result['archives']), 'audits': len(result['audits']), 'error': result.get('error')}, sort_keys=True))
    return 0 if result['passed'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
