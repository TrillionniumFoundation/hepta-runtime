#!/usr/bin/env python3
# Copyright 2026 TrillionniumFoundation
# SPDX-License-Identifier: Apache-2.0
"""A deterministic transport envelope for an already closed publication index.

Inner archives, manifests and batch evidence stay byte-identical. The envelope
is a transport artifact, not an additional experiment or Git evidence package.
Pack only after closure. Restore into a fresh stage and retain its original index.
"""
import argparse
import gzip
import hashlib
import importlib.util
import io
import json
import os
from pathlib import Path
import re
import stat
import sys
import tarfile

PACKAGER_SHA = '226edda9684f742178398c09266a171df38df5e505c0020372e72265ff684c43'
TRANSFER_SHA = '280eee7cf06236f1ebd4444e723f16e7d08bf65090574630e118d7101a7663cc'
SCHEMA = 'hepta-r19-transfer-envelope/v1'
INDEX_SCHEMA = 'hepta-x230-publication-transfer/v1'
INDEX_MEMBER = '_transfer/original-index.json'
META_MEMBER = '_transfer/envelope.json'
MAX_INDEX = 32 * 1024 ** 2
MAX_FILE = 1024 ** 3
MAX_TOTAL = 4 * 1024 ** 3


def need(value, message):
    if not value:
        raise ValueError(message)


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def encode(value):
    return (json.dumps(value, sort_keys=True, indent=2) + '\n').encode()


def direct(path):
    path = Path(path).absolute()
    need(path.resolve() == path, 'indirect path: ' + str(path))
    return path


def safe_relative(name):
    need(isinstance(name, str) and name and not name.startswith('/') and '\\' not in name
         and all(ord(c) >= 32 and ord(c) != 127 for c in name), 'unsafe member path')
    need(all(x not in ('', '.', '..') for x in name.split('/')), 'non-canonical member path')
    need(name.split('/')[0] != '_transfer', 'reserved member prefix')
    return name


def helpers():
    """Verify the exact old helpers before importing them; no historical edit."""
    modules = []
    for name, expected in [('package_x230_evidence', PACKAGER_SHA), ('publication_transfer', TRANSFER_SHA)]:
        path = direct(Path(__file__).parent / (name + '.py'))
        need(digest(path.read_bytes()) == expected, 'frozen helper differs: ' + name)
        spec = importlib.util.spec_from_file_location(name, path)
        module = importlib.util.module_from_spec(spec)
        sys.modules[name] = module
        spec.loader.exec_module(module)
        modules.append(module)
    return modules


def parse_index(raw, expected):
    need(len(raw) <= MAX_INDEX and digest(raw) == expected, 'original index identity differs')
    index = json.loads(raw)
    need(index.get('schema') == INDEX_SCHEMA and isinstance(index.get('files'), list) and index['files'], 'invalid transfer index')
    rows = {}
    for entry in index['files']:
        name = safe_relative(entry['repo_path'])
        need(name not in rows and type(entry['bytes']) is int and 0 <= entry['bytes'] <= MAX_FILE,
             'duplicate member or invalid indexed length')
        need(re.fullmatch('[0-9a-f]{64}', entry['sha256']) and re.fullmatch('[0-9a-f]{40}', entry['git_blob_sha1']),
             'invalid indexed hashes')
        need(isinstance(entry['absolute_remote_path'], str) and Path(entry['absolute_remote_path']).is_absolute(),
             'original source path is not absolute')
        rows[name] = entry
    need(sum(e['bytes'] for e in rows.values()) <= MAX_TOTAL, 'envelope exceeds the total source-byte bound')
    return rows


def stamp(path, p):
    path = direct(path)
    value = path.lstat()
    need(stat.S_ISREG(value.st_mode) and value.st_nlink == 1, 'source is not an independent regular file')
    return p.identity(value)


def stage_files(root):
    files = set()
    for path in root.rglob('*'):
        value = path.lstat()
        need(stat.S_ISDIR(value.st_mode) or (stat.S_ISREG(value.st_mode) and value.st_nlink == 1), 'unsafe stage entry')
        if stat.S_ISREG(value.st_mode):
            files.add(path.relative_to(root).as_posix())
    return files


class Reader:
    def __init__(self, stream, size):
        self.stream, self.count = stream, 0
        self.sha = hashlib.sha256()
        self.git = hashlib.sha1(('blob ' + str(size) + '\0').encode(), usedforsecurity=False)

    def read(self, size=-1):
        raw = self.stream.read(size)
        self.count += len(raw)
        self.sha.update(raw)
        self.git.update(raw)
        return raw

    def matches(self, entry):
        return self.count == entry['bytes'] and self.sha.hexdigest() == entry['sha256'] and self.git.hexdigest() == entry['git_blob_sha1']


def canonical(member, expected_name=None):
    need(member is not None and member.isreg() and not member.issym() and not member.islnk(), 'non-regular or missing tar member')
    need(expected_name is None or member.name == expected_name, 'unexpected envelope header')
    need(set(member.pax_headers) <= {'path'} and member.uid == member.gid == 0
         and member.uname == member.gname == '' and member.mode == 0o644 and member.mtime == 0,
         'non-canonical member metadata')


def write_member(tar, name, raw):
    member = tarfile.TarInfo(name)
    member.size, member.mode, member.mtime = len(raw), 0o644, 0
    tar.addfile(member, io.BytesIO(raw))


def inspect_envelope(archive, expected_archive, expected_index, p, t, destination=None, index_output=None, provenance=()):
    archive = direct(archive)
    need(stamp(archive, p)['size'] <= MAX_FILE, 'outer archive exceeds the byte bound')
    actual_archive = t.hashes(archive)
    need(actual_archive['bytes'] <= MAX_FILE and actual_archive['sha256'] == expected_archive, 'outer archive identity differs')
    with p.source_file(str(archive.parent), archive.name) as (raw, before):
        with gzip.GzipFile(fileobj=raw, mode='rb') as gz:
            with tarfile.open(fileobj=gz, mode='r|') as tar:
                iterator = iter(tar)
                first = next(iterator, None)
                canonical(first, INDEX_MEMBER)
                need(first.size <= MAX_INDEX, 'original index member is oversized')
                index_raw = tar.extractfile(first).read(first.size + 1)
                rows = parse_index(index_raw, expected_index)
                second = next(iterator, None)
                canonical(second, META_MEMBER)
                need(second.size <= 65536, 'envelope metadata is oversized')
                metadata = json.loads(tar.extractfile(second).read(second.size + 1))
                need(metadata['schema'] == SCHEMA and metadata['original_index_sha256'] == expected_index
                     and metadata['member_files'] == len(rows), 'envelope metadata differs')
                source_roots = [Path(metadata['stage_root']), *map(Path, metadata['extra_roots'])]
                need(all(path.is_absolute() and path != Path('/') and '..' not in path.parts for path in source_roots), 'invalid original source roots')
                for entry in rows.values():
                    need(any(Path(entry['absolute_remote_path']).is_relative_to(root) for root in source_roots), 'indexed source outside declared roots')
                if destination is not None:
                    destination = direct(destination)
                    need(not any(path.is_relative_to(root) or root.is_relative_to(path)
                         for path in [destination, *map(direct, provenance)] for root in source_roots),
                         'local destination or provenance overlaps indexed sources')
                    need(not archive.is_relative_to(destination), 'downloaded envelope lies within destination')
                    destination.mkdir(mode=0o700)  # Fresh stage; never merge/overwrite a prior attempt.
                    t.write_new(index_output, index_raw)
                observed, restored = set(), []
                for member in iterator:
                    canonical(member)
                    name = safe_relative(member.name)
                    need(name in rows and name not in observed, 'extra or duplicate member')
                    entry = rows[name]
                    need(member.size == entry['bytes'], 'member length differs from original index')
                    reader = Reader(tar.extractfile(member), member.size)
                    if destination is None:
                        while reader.read(1024 * 1024):
                            pass
                    else:
                        target = destination / name
                        with p.directory_fd(str(target.parent), create=True):
                            pass
                        with target.open('xb') as output:
                            while block := reader.read(1024 * 1024):
                                output.write(block)
                            output.flush()
                            os.fsync(output.fileno())
                    need(reader.matches(entry), 'member SHA256/Git blob identity differs')
                    observed.add(name)
                    restored.append({'repo_path': name, 'bytes': reader.count, 'sha256': reader.sha.hexdigest(),
                                     'git_blob_sha1': reader.git.hexdigest()})
                need(observed == set(rows), 'missing indexed member')
                tail = tar.fileobj.read(1024 * 1024 + 1)
                need(512 <= len(tail) <= 1024 * 1024 and not tail.strip(b'\0'), 'invalid tar termination or trailing data')
            need(gz.read(1) == b'', 'unconsumed compressed payload')
        need(before == p.identity(os.fstat(raw.fileno())) == stamp(archive, p), 'envelope changed while reading')
    return {'verified': True, 'archive': actual_archive, 'original_index_sha256': expected_index,
            'original_index_bytes': len(index_raw), 'member_files': len(rows), 'files': restored,
            'metadata': metadata, 'original_bytes_changed': False}


def pack(args, p, t):
    stage, index_path, output = direct(args.stage_root), direct(args.index), direct(args.output_root)
    extra = sorted({direct(path) for path in args.extra_root}, key=str)
    need(args.evidence_window_closed, 'explicit closed-evidence-window assertion required')
    need(stage.is_dir() and all(path.is_dir() and path != Path('/') for path in extra), 'invalid closed source root')
    need(not any(output.is_relative_to(root) or root.is_relative_to(output) for root in [stage, *extra]), 'remote archive output overlaps indexed sources')
    need(not index_path.is_relative_to(output), 'input index lies within envelope output')
    output.mkdir(mode=0o700)
    report = {'schema': SCHEMA, 'passed': False, 'operation': 'pack', 'automatic_retries': 0,
              'builds_started': False, 'network_requests': 0, 'source_bytes_modified': False}
    try:
        with p.source_file(str(index_path.parent), index_path.name) as (stream, before):
            index_raw = stream.read(MAX_INDEX + 1)
            need(before == p.identity(os.fstat(stream.fileno())) == stamp(index_path, p), 'original index changed while read')
        rows = parse_index(index_raw, args.expected_index_sha256)
        original_stamps, indexed_stage = {}, set()
        for name, entry in rows.items():
            source = direct(entry['absolute_remote_path'])
            if source.is_relative_to(stage):
                need(source == stage / name, 'stage source does not match its original repository path')
                indexed_stage.add(name)
            else:
                need(any(source.is_relative_to(root) for root in extra), 'extra file lacks an explicit source root')
            original_stamps[name] = stamp(source, p)
        need(stage_files(stage) == indexed_stage, 'original index does not cover the exact closed stage')
        metadata = {'schema': SCHEMA, 'original_index_sha256': args.expected_index_sha256,
                    'stage_root': str(stage), 'extra_roots': [str(root) for root in extra], 'member_files': len(rows),
                    'packager_sha256': PACKAGER_SHA, 'transfer_sha256': TRANSFER_SHA,
                    'envelope_tool_sha256': digest(Path(__file__).read_bytes())}
        partial, archive = output / 'envelope.partial.tar.gz', output / 'r19-transfer-envelope-01.tar.gz'
        with partial.open('xb') as raw:
            with gzip.GzipFile(filename='', fileobj=raw, mode='wb', compresslevel=6, mtime=0) as gz:
                with tarfile.open(fileobj=gz, mode='w|', format=tarfile.PAX_FORMAT) as tar:
                    write_member(tar, INDEX_MEMBER, index_raw)
                    write_member(tar, META_MEMBER, encode(metadata))
                    for name in sorted(rows):
                        entry, source = rows[name], Path(rows[name]['absolute_remote_path'])
                        with p.source_file(str(source.parent), source.name) as (stream, before):
                            need(before == original_stamps[name], 'indexed source metadata changed before read')
                            member = tarfile.TarInfo(name)
                            member.size, member.mode, member.mtime = entry['bytes'], 0o644, 0
                            reader = Reader(stream, entry['bytes'])
                            tar.addfile(member, reader)
                            need(reader.matches(entry) and stream.read(1) == b'', 'indexed source bytes changed')
                            need(before == p.identity(os.fstat(stream.fileno())) == stamp(source, p), 'indexed source changed during read')
            raw.flush()
            os.fsync(raw.fileno())
        outer = t.hashes(partial)
        checked = inspect_envelope(partial, outer['sha256'], args.expected_index_sha256, p, t)
        need(index_path.read_bytes() == index_raw and stage_files(stage) == indexed_stage
             and all(stamp(rows[name]['absolute_remote_path'], p) == original_stamps[name] for name in rows),
             'closed stage/index changed during envelope creation')
        os.link(partial, archive, follow_symlinks=False)
        partial.unlink()
        single_index = {'schema': INDEX_SCHEMA, 'files': [{'repo_path': 'transport/' + archive.name,
                        'absolute_remote_path': str(archive), **outer}], 'local_files_verified': False, 'network_requests': 0}
        single_raw = encode(single_index)
        t.write_new(output / 'envelope-transfer-index-01.json', single_raw)
        report.update(passed=True, archive_path=str(archive), archive=outer,
                      original_index_sha256=args.expected_index_sha256, original_index_bytes=len(index_raw),
                      member_files=len(rows), total_original_file_bytes=sum(row['bytes'] for row in rows.values()),
                      verification=checked, transfer_index_sha256=digest(single_raw),
                      transfer_index=str(output / 'envelope-transfer-index-01.json'))
    except BaseException as error:
        report['error'] = {'type': type(error).__name__, 'message': str(error)}
    finally:
        t.write_new(output / 'report.json', encode(report))
    return report


def restore(args, p, t):
    stage, receipt, index_output = direct(args.output_stage), direct(args.receipt), direct(args.index_output)
    need(not any(os.path.lexists(path) for path in (stage, receipt, index_output)), 'restore destination or receipt already exists')
    need(not receipt.is_relative_to(stage) and not index_output.is_relative_to(stage) and receipt != index_output,
         'restore provenance must be outside the restored stage')
    # Validate the entire envelope and its declared original roots before even
    # a failure receipt may be written. An unsafe requested receipt path must
    # never turn a rejection into a write inside the original indexed sources.
    preflight = inspect_envelope(args.archive, args.expected_archive_sha256, args.expected_index_sha256, p, t)
    source_roots = [Path(preflight['metadata']['stage_root']), *map(Path, preflight['metadata']['extra_roots'])]
    need(not any(path.is_relative_to(root) or root.is_relative_to(path)
                 for path in (stage, receipt, index_output) for root in source_roots),
         'restore destination or provenance overlaps indexed sources')
    need(not direct(args.archive).is_relative_to(stage), 'downloaded envelope lies within destination')
    report = {'schema': SCHEMA, 'passed': False, 'operation': 'restore', 'automatic_retries': 0,
              'network_requests': 0, 'builds_started': False, 'original_bytes_changed': False}
    try:
        result = inspect_envelope(args.archive, args.expected_archive_sha256, args.expected_index_sha256,
                                  p, t, stage, index_output, (receipt, index_output))
        need(stage_files(stage) == {row['repo_path'] for row in result['files']}, 'restored stage has unexpected members')
        need(all(t.hashes(stage / row['repo_path']) == {k: row[k] for k in ('bytes', 'sha256', 'git_blob_sha1')}
                 for row in result['files']), 'restored bytes changed before completion')
        report.update(passed=True, stage_root=str(stage), original_index_path=str(index_output), **result)
    except BaseException as error:
        report['error'] = {'type': type(error).__name__, 'message': str(error)}
    finally:
        t.write_new(receipt, encode(report))
    return report


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest='operation', required=True)
    make = sub.add_parser('pack')
    make.add_argument('--index', required=True)
    make.add_argument('--expected-index-sha256', required=True)
    make.add_argument('--stage-root', required=True)
    make.add_argument('--extra-root', action='append', default=[])
    make.add_argument('--output-root', required=True)
    make.add_argument('--evidence-window-closed', action='store_true')
    take = sub.add_parser('restore')
    take.add_argument('--archive', required=True)
    take.add_argument('--expected-archive-sha256', required=True)
    take.add_argument('--expected-index-sha256', required=True)
    take.add_argument('--output-stage', required=True)
    take.add_argument('--index-output', required=True)
    take.add_argument('--receipt', required=True)
    args = parser.parse_args()
    try:
        p, t = helpers()
        result = pack(args, p, t) if args.operation == 'pack' else restore(args, p, t)
        print(json.dumps({k: v for k, v in result.items() if k not in ('verification', 'files')}, sort_keys=True), flush=True)
        return 0 if result['passed'] else 1
    except BaseException as error:
        print(json.dumps({'passed': False, 'operation': args.operation, 'error': type(error).__name__ + ': ' + str(error)}), file=sys.stderr, flush=True)
        return 1


if __name__ == '__main__':
    raise SystemExit(main())
