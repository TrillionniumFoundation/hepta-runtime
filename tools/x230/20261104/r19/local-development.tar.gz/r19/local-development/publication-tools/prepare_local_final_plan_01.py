#!/usr/bin/env python3
# Copyright 2026 TrillionniumFoundation
# SPDX-License-Identifier: Apache-2.0
"""Freeze local inputs only after raw replay, source proof and observations close.

No network, workload, compiler, archive extraction or publication is performed.
The document copied here is an immutable pre-publication snapshot. Final docs
and README are staged separately after archive identities are available.
"""
import argparse
import base64
import copy
import fnmatch
import gzip
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import stat
import sys

sys.dont_write_bytecode = True
ROOT = Path(__file__).absolute().parent.parent
PUB, REVIEW = ROOT / 'publication', ROOT / 'review'
PLAN = PUB / 'r19-plan-final-02.json'
PLAN_SHA = '0d89dda957690e18372fdfe282d9d46b79e3c6bf779219b8a8b92c3db7b7c0e5'
OUT = PUB / 'r19-plan-local-final.json'
SNAPSHOT = ROOT / 'report-snapshot-before-publication-01.md'
RECEIPT = REVIEW / 'local-plan-closure-01.json'
REPLAY = REVIEW / 'offline-raw-audit-01/report.json'
PROOF = REVIEW / 'qualified-source-binding-01.json'
OBSERVATIONS = REVIEW / 'orchestration-observations-01.json'
COLLECTION = REVIEW / 'collection-evidence-01'
EXPORT = COLLECTION / 'collection-control-export-01.json.gz.b64'
EXPORT_SHA = '18e19417e0b5992546da21bc8e6c0efe7ca760940451b0be97130918770a8b29'
REMOTE = Path('/home/qian/hepta-runtime-optimization-20261104-r19')
CONTROL = 'publication/collection-control-01'
INDEX_SHA = '9d6386109be866f9b7f8104d82d461bed9a13f178560866b9e4fcfb0721880cd'
OUTER_SHA = '6e329b2b9adffc23c06496c68efeeea07605ce1ee28079a92cc3e2d508accd93'
TOOLS = {
    'publication/package_r19_evidence.py': 'ce00ce6012819f19d11cb90a46867be7e0968f40c4ae2b516578e0a14dab2e48',
    'publication/run_remote_publication_01.py': 'bb15123e263836094f6c746cbc07ffe66a3bdeff5547c58c28c6b9b360780436',
    'publication/replay_received_evidence_01.py': '769ee5c93cea373f7f40f41c382091df0600fb88ba83555e42eabb38796db389',
    'tools/summarize_closed_campaign_01.py': '058afff96a8c952114124692adb26a02fe9b970864ac856a3d56de6e85734048',
    'tools/read_frozen_envelope_01.py': '41355dd4bcd29c3149b52af27bc326063629090e2c1e586f26d2b92a4a6c4fbc',
}


def need(value, message):
    if not value:
        raise ValueError(message)


def encoded(value):
    return (json.dumps(value, indent=2, sort_keys=True, ensure_ascii=False) + '\n').encode()


def read(path, expected=None):
    path = Path(path).absolute()
    need(path.resolve() == path and path.is_relative_to(ROOT), 'indirect or out-of-root input')
    before = path.stat()
    need(stat.S_ISREG(before.st_mode) and before.st_nlink == 1 and before.st_size <= 32 * 1024 ** 2,
         'input is not a bounded independent regular file')
    raw = path.read_bytes()
    stamp = lambda s: (s.st_dev, s.st_ino, s.st_size, s.st_mtime_ns, s.st_ctime_ns)
    need(stamp(before) == stamp(path.stat()) and len(raw) == before.st_size, 'input changed')
    sha = hashlib.sha256(raw).hexdigest()
    need(expected is None or sha == expected, 'input SHA differs: ' + str(path))
    return raw, {'path': str(path), 'bytes': len(raw), 'sha256': sha}


def write_new(path, raw):
    with path.open('xb') as stream:
        stream.write(raw)
        stream.flush()
        os.fsync(stream.fileno())


def require(selector, name, sha):
    if name not in selector['files']:
        selector['files'].append(name)
    selector.setdefault('expected_sha256', {})[name] = sha


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ('launcher', 'report', 'replay', 'source-proof', 'orchestration'):
        parser.add_argument('--expected-' + name + '-sha256', required=True)
    parser.add_argument('--local-evidence-closed', action='store_true')
    args = parser.parse_args()
    need(args.local_evidence_closed, 'local closure must be explicitly asserted')
    need(all(re.fullmatch('[0-9a-f]{64}', value) for key, value in vars(args).items()
             if key.startswith('expected_')), 'invalid expected SHA256')
    need(not any(os.path.lexists(p) for p in (OUT, SNAPSHOT, RECEIPT)), 'closure output already exists')
    inputs = {}

    def bound(path, expected=None, document=False):
        raw, row = read(path, expected)
        inputs[str(path)] = row
        return json.loads(raw) if document else raw

    bound(Path(__file__).absolute(), args.expected_launcher_sha256)
    original = bound(PLAN, PLAN_SHA, True)
    plan = copy.deepcopy(original)
    need(plan['roots']['local'] == str(ROOT), 'plan local root differs')
    local = next(p for p in plan['packages'] if p['id'] == 'r19-local-development')
    need(local['state'] == 'pending' and not plan['publication_groups']['local-development']['evidence_closed'],
         'input plan is not the pending local group')
    replay = bound(REPLAY, args.expected_replay_sha256, True)
    need(replay['schema'] == 'hepta-r19-offline-raw-replay/v1' and replay['passed'] is True
         and replay['transfer_files_verified'] == 83 and len(replay['archives']) == 9
         and all(x['verified'] is True for x in replay['archives'])
         and replay['plan']['sha256'] == PLAN_SHA and replay['index']['sha256'] == INDEX_SHA
         and replay['tool']['sha256'] == TOOLS['publication/replay_received_evidence_01.py'],
         'full raw replay is not the accepted fixed input')
    need([x['name'] for x in replay['audits']] == ['native', 'boundary', 'recovery']
         and all(x['returncode'] == 0 and x['equals_original_analysis'] is True for x in replay['audits']),
         'three original analyses were not independently reproduced')
    audit_files = {'report.json': args.expected_replay_sha256}
    for row in replay['audits']:
        for key in ('output', 'stdout', 'stderr'):
            item = row[key]
            path = Path(item['path'])
            need(path.parent == REPLAY.parent, 'audit output is outside its fixed directory')
            bound(path, item['sha256'])
            audit_files[path.name] = item['sha256']
    audit_files['archive-verification.json'] = read(REPLAY.parent / 'archive-verification.json')[1]['sha256']
    proof = bound(PROOF, args.expected_source_proof_sha256, True)
    need(proof['schema'] == 'hepta-r19-qualified-source-binding/v1' and proof['verified'] is True
         and proof['source_input_count'] == 219 and isinstance(proof['checks'], dict)
         and proof['checks'] and all(value is True for value in proof['checks'].values()),
         'qualified source proof is missing or not verified')
    observations = bound(OBSERVATIONS, args.expected_orchestration_sha256, True)
    need(isinstance(observations, dict) and observations, 'final orchestration observations are empty')
    report_raw = bound(ROOT / 'report_template.md', args.expected_report_sha256)
    for relative, expected in TOOLS.items():
        bound(ROOT / relative, expected)

    export_raw = bound(EXPORT, EXPORT_SHA)
    exported = json.loads(gzip.decompress(base64.b64decode(export_raw, validate=True)))
    need(exported['schema'] == 'hepta-r19-closed-collection-export/v1'
         and len(exported['files']) == 33, 'closed collection export differs')
    collection_files = {}
    for row in exported['files']:
        relative = row['relative_path']
        need(isinstance(relative, str) and not relative.startswith('/') and '\\' not in relative
             and all(p not in ('', '.', '..') for p in relative.split('/'))
             and relative not in collection_files, 'unsafe or duplicate export path')
        raw = row['content_utf8'].encode('utf-8')
        need(len(raw) == row['bytes'] and hashlib.sha256(raw).hexdigest() == row['sha256'], 'export member differs')
        need(bound(COLLECTION / relative, row['sha256']) == raw, 'received collection bytes differ')
        collection_files[relative] = row['sha256']
    control = json.loads(bound(COLLECTION / CONTROL / 'report.json',
                         'c113197c6fc4eca69cf891f003a9d2ce8398709130e4628cb1f347a41f5403a1'))
    need(control['passed'] is True and len(control['stages']) == 7
         and all(x['returncode'] == 0 and not x['timed_out'] for x in control['stages'])
         and all(not x['direct_child'] or x['reaped'] is True for x in control['stages'])
         and control['original_index']['sha256'] == INDEX_SHA and control['envelope']['sha256'] == OUTER_SHA,
         'collection did not close successfully')
    need(len(control['control_files']) == 28, 'successful collection control file count differs')
    for row in control['control_files']:
        path = Path(row['path'])
        need(path.parent == REMOTE / CONTROL, 'control evidence path differs')
        need(collection_files[CONTROL + '/' + path.name] == row['sha256'], 'named control file is missing or changed')
    need(collection_files['publication-final-installed-01.json'] ==
         '6074fad7af8e470be6709ec85617a2dd3a34f78e5ecc0305afb01479b3abc003', 'final installation receipt differs')

    selectors = local['selectors']
    root_selector = next(s for s in selectors if s['base'] == '')
    old_report_sha = root_selector['expected_sha256'].pop('report_template.md')
    root_selector['files'].remove('report_template.md')
    require(root_selector, SNAPSHOT.name, args.expected_report_sha256)
    reviews = next(s for s in selectors if s['base'] == 'review')
    require(reviews, OBSERVATIONS.name, args.expected_orchestration_sha256)
    require(reviews, PROOF.name, args.expected_source_proof_sha256)
    for name, expected in audit_files.items():
        require(reviews, 'offline-raw-audit-01/' + name, expected)
    selectors.append({'root': 'local', 'base': 'review/collection-evidence-01',
                      'bundle': 'r19/local-development/review/collection-evidence-01',
                      'files': sorted(collection_files), 'optional_files': [], 'expected_sha256': collection_files})
    publications = next(s for s in selectors if s['base'] == 'publication')
    require(publications, 'README.template.md', 'b97a1fadbbebcfbfc6b0c504189f92f480540e2234f53644b6a7dc874044216f')
    require(publications, Path(__file__).name, args.expected_launcher_sha256)
    for relative, expected in TOOLS.items():
        folder, name = relative.split('/', 1)
        require(next(s for s in selectors if s['base'] == folder), name, expected)
    mac = next(s for s in selectors if s['base'] == 'mac-agent-evidence/campaign-02')
    mac_report = bound(ROOT / mac['base'] / 'report.json',
                       'c7144000d9c02b766c444fc6ed906486be776723750341e8397ff895bc581b40', True)
    need(mac_report['passed'] is True and mac_report['owned_agent_reaped'] is True, 'Mac holder did not close')
    require(mac, 'report.json', 'c7144000d9c02b766c444fc6ed906486be776723750341e8397ff895bc581b40')
    for row in mac_report['log_files']:
        name = row['file']
        need(name == Path(name).name and name not in ('', '.', '..'), 'unsafe Mac log basename')
        bound(ROOT / mac['base'] / name, row['sha256'])
        require(mac, name, row['sha256'])
    mac_meta = next(s for s in selectors if s['base'] == 'mac-agent-evidence')
    require(mac_meta, 'export-manifest-02.json', 'abde56c0350a60995221fc9e36473b28b483ba3523a2bea65a88f06db4138cae')
    # Freeze the actual late receipts only when the caller declares all writers
    # closed. This includes future transfer-download-03/*.json success/failure
    # records; never replace an already pinned historical file's expected SHA.
    dynamic_review_files = []
    for path in sorted(REVIEW.rglob('*')):
        relative = path.relative_to(REVIEW).as_posix()
        if (len(Path(relative).parts) - 1 <= reviews['depth'] and path.is_file()
                and any(fnmatch.fnmatchcase(relative, pattern) for pattern in reviews['patterns'])):
            bound(path, reviews.get('expected_sha256', {}).get(relative))
            require(reviews, relative, inputs[str(path)]['sha256'])
            dynamic_review_files.append(relative)
    for selector in selectors:
        for name in selector['files']:
            if selector is root_selector and name == SNAPSHOT.name:
                continue
            bound(ROOT / selector['base'] / name, selector.get('expected_sha256', {}).get(name))

    # The exact review set is now closed. The one receipt generated below is
    # explicitly required, but cannot be SHA-pinned inside its own plan because
    # it contains that plan's SHA. Inventory will bind its complete raw bytes.
    reviews['patterns'] = []
    need(RECEIPT.name not in reviews['files'], 'closure receipt unexpectedly predates closure')
    reviews['files'].append(RECEIPT.name)

    plan['revision'] = 'local-final-01'
    plan['previous_plan'], plan['previous_plan_sha256'] = PLAN.name, PLAN_SHA
    plan['publication_groups']['local-development'].update(evidence_closed=True, measurement_window_closed=True)
    local['state'] = 'complete'
    plan['standalone_local_artifacts'].append({
        'source': str(EXPORT), 'bytes': len(export_raw), 'sha256': EXPORT_SHA,
        'repo_path': 'tools/x230/20261104/r19/publication-history/' + EXPORT.name,
        'reason': 'Original compressed collection export is retained byte-for-byte as a standalone staged file; .b64 is not an ordinary packager role.'})
    plan['local_finalization'] = {
        'source_plan_sha256': PLAN_SHA, 'raw_replay': inputs[str(REPLAY)], 'qualified_source_proof': inputs[str(PROOF)],
        'orchestration': inputs[str(OBSERVATIONS)], 'collection_files': 33,
        'review_files_frozen_at_execution': dynamic_review_files,
        'post_plan_receipt': 'review/local-plan-closure-01.json is the sole explicitly required review file generated after this plan; its bytes are bound by inventory. Further publication evidence is staged separately.',
        'snapshot': {'path': str(SNAPSHOT), 'sha256': args.expected_report_sha256,
                     'original_template_draft_sha256': old_report_sha,
                     'role': 'Immutable result-text snapshot before publication identities are filled; final docs and README are standalone stage files.'},
        'final_commit_identity_required_here': False,
        'commit_scope': 'Bind the actually created src tree and qualified 219-input map; no self-referential final root-tree/commit SHA is required.',
        'late_evidence': 'After this local package closes, keep pack/transfer/Git receipts and final docs as separately indexed stage extras. Do not rewrite this archive.'}
    driver = PUB / 'package_r19_evidence.py'
    spec = importlib.util.spec_from_file_location('r19_frozen_publication_driver', driver)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    _, readiness = module.plan_check(plan, 'local-development', None)
    need(readiness['ready'] is True and not readiness['unfilled_sha256_fields'], 'local plan is not ready')
    need(plan['publication_groups']['remote'] == original['publication_groups']['remote'], 'remote group changed')
    for path, row in inputs.items():
        need(read(path, row['sha256'])[1] == row, 'closed input changed before output')
    write_new(SNAPSHOT, report_raw)
    plan_raw = encoded(plan)
    write_new(OUT, plan_raw)
    receipt = {'schema': 'hepta-r19-local-plan-closure/v1', 'passed': True,
               'plan': {'path': str(OUT), 'bytes': len(plan_raw), 'sha256': hashlib.sha256(plan_raw).hexdigest()},
               'snapshot': read(SNAPSHOT)[1], 'readiness': readiness, 'inputs': list(inputs.values()),
               'remote_operations': 0, 'workloads_started': 0, 'archives_written': 0,
               'next_action': 'Run the frozen package_r19_evidence local-development group into a fresh local-export run; retain its closed batch logs separately.'}
    write_new(RECEIPT, encoded(receipt))
    print(json.dumps({'passed': True, 'plan': receipt['plan'], 'receipt': read(RECEIPT)[1]}, sort_keys=True))


if __name__ == '__main__':
    try:
        main()
    except BaseException as error:
        print(json.dumps({'passed': False, 'error': type(error).__name__ + ': ' + str(error),
                          'automatic_retries': 0}), file=sys.stderr)
        raise
