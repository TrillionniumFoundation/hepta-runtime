#!/usr/bin/env python3
# Copyright 2026 TrillionniumFoundation
# SPDX-License-Identifier: Apache-2.0
"""One-shot closed-evidence collection; no workload, build, network or publication.

The collection-control report and streams remain outside the transport envelope.
Export those closed files separately after this launcher exits. Never retry into
these output paths: failed stages and partial files are intentionally retained.
"""
import argparse
import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import signal
import stat
import subprocess
import sys
import time
import traceback

ROOT = Path('/home/qian/hepta-runtime-optimization-20261104-r19')
PUB = ROOT / 'publication'
PLAN = PUB / 'r19-plan-final-02.json'
CONTROL, RUN, STAGE = (PUB / name for name in ('collection-control-01', 'export-run-01', 'stage'))
TINY = PUB / 'tiny-fingerprints-01'
EXTRAS, INDEX = (PUB / name for name in ('remote-extras-01.json', 'remote-index-01.json'))
ENVELOPE = ROOT / 'transfer-envelope-01'
CHUNKS = ENVELOPE / 'chunk-manifest-01.json'
REPO = 'tools/x230/20261104/r19'
LOCAL_STAGE = '/workspace/scratch/846f8b2ab644/r19/publication/received-stage-01'
IDS = ['r19-' + name for name in (
    'qualification-01', 'prequalification-component-01', 'qualification-02',
    'qualification-resolution-02', 'qualification-diagnostics-01', 'campaign-control-01',
    'native-observation-01', 'native-boundary-01', 'cancel-recovery-01')]
TOOLS = {
    'prepare_tiny_fingerprint_export.py': '06bfe67e6d2eaa3d15871295e64f19bea828216a696578716c0198eca3582840',
    'package_r19_evidence.py': 'ce00ce6012819f19d11cb90a46867be7e0968f40c4ae2b516578e0a14dab2e48',
    'package_x230_evidence.py': '226edda9684f742178398c09266a171df38df5e505c0020372e72265ff684c43',
    'publication_transfer.py': '280eee7cf06236f1ebd4444e723f16e7d08bf65090574630e118d7101a7663cc',
    'pack_transfer_01.py': '789a61812674b7597832cfc47f7d50086c44bea8674f5c6f2477d7bf38cf4399',
}


def need(value, message):
    if not value:
        raise ValueError(message)


def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def encoded(value):
    return (json.dumps(value, indent=2, sort_keys=True) + '\n').encode()


def write_new(path, value):
    with Path(path).open('xb') as stream:
        stream.write(encoded(value))


def identity(path):
    path = Path(path)
    need(path.is_absolute() and path.resolve() == path, 'indirect file path: ' + str(path))
    before = path.stat()
    need(stat.S_ISREG(before.st_mode) and before.st_nlink == 1, 'not an independent regular file: ' + str(path))
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(block)
        after = os.fstat(stream.fileno())
    stamp = lambda s: (s.st_dev, s.st_ino, s.st_size, s.st_mtime_ns, s.st_ctime_ns)
    need(stamp(before) == stamp(after) == stamp(path.stat()), 'file changed: ' + str(path))
    return {'path': str(path), 'bytes': before.st_size, 'sha256': h.hexdigest()}


def load(path):
    return json.loads(Path(path).read_bytes())


def build_extras(plan_sha):
    batch = load(RUN / 'report.json')
    need(batch.get('schema') == 'hepta-r19-publication-batch/v1' and batch.get('passed') is True
         and batch.get('group') == 'remote' and batch.get('package_ids') == IDS
         and batch.get('plan_sha256') == plan_sha and batch.get('automatic_retries') == 0,
         'batch did not complete the fixed nine packages')
    need(identity(RUN / 'plan.frozen.json')['sha256'] == plan_sha, 'batch frozen plan differs')
    need([p['id'] for p in batch['packages']] == IDS
         and all(p.get('passed') is True for p in batch['packages']), 'incomplete package status')
    need([p['package'] for p in batch['archives']] == IDS, 'incomplete archive receipt set')
    receipts = []
    for identifier, row in zip(IDS, batch['archives']):
        path = STAGE / REPO / (identifier.removeprefix('r19-') + '.archive.json')
        receipt = load(path)
        need(row['receipt'] == str(path) and receipt.get('verified') is True
             and receipt.get('original_bytes_changed') is False
             and receipt.get('plan_sha256') == plan_sha and receipt['repo_dir'] == REPO,
             'archive receipt is not verified or has another identity')
        receipts.append(str(path))
    selected = [RUN / name for name in ('report.json', 'plan.frozen.json')]
    selected += [RUN / identifier / name for identifier in IDS for name in
                 ('inventory.json', 'status.json', 'inventory.stdout', 'inventory.stderr', 'pack.stdout', 'pack.stderr')]
    need(len(selected) == 56 and len(set(selected)) == 56, 'batch extras count differs')
    if (RUN / 'error.txt').exists():
        selected.append(RUN / 'error.txt')
    files = []
    for path in selected:
        record = identity(path)
        files.append({'repo_path': REPO + '/export-run-01/' + path.relative_to(RUN).as_posix(),
                      'absolute_remote_path': str(path), 'sha256': record['sha256']})
    write_new(EXTRAS, {'files': files})
    need(len(files) == 56 and 'error' not in batch, 'successful batch unexpectedly retained an error')
    return {'extras': identity(EXTRAS), 'files': len(files), 'receipts': receipts}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--expected-plan-sha256', required=True)
    parser.add_argument('--expected-launcher-sha256', required=True)
    parser.add_argument('--evidence-window-closed', action='store_true')
    args = parser.parse_args()
    need(args.evidence_window_closed, 'explicit closed-evidence-window assertion required')
    need(all(re.fullmatch('[0-9a-f]{64}', h) for h in
             (args.expected_plan_sha256, args.expected_launcher_sha256)), 'invalid expected SHA256')
    launcher = Path(__file__).absolute()
    need(launcher == PUB / 'run_remote_publication_01.py', 'launcher is not at its fixed remote path')
    need(ROOT.is_dir() and PUB.is_dir() and ROOT.resolve() == ROOT and PUB.resolve() == PUB,
         'fixed publication root is missing or indirect')
    outputs = (CONTROL, TINY, RUN, STAGE, EXTRAS, INDEX, ENVELOPE)
    need(all(path.resolve() == path and not os.path.lexists(path) for path in outputs),
         'an output already exists or traverses an indirect path; no automatic retry')
    CONTROL.mkdir(mode=0o700)
    report = {'schema': 'hepta-r19-remote-publication-collection/v1', 'passed': False,
              'started_utc': now(), 'launcher_pid': os.getpid(), 'automatic_retries': 0,
              'runtime_workloads_started': False, 'builds_started': False, 'network_requests': 0,
              'evidence_window_closed': True, 'package_ids': IDS, 'stages': [],
              'expected_plan_sha256': args.expected_plan_sha256,
              'expected_launcher_sha256': args.expected_launcher_sha256,
              'control_evidence_in_envelope': False,
              'control_export_instruction': 'After this launcher exits, separately export this report and all its named stage records/streams as local extras; these still-open control files are excluded from the envelope.'}
    pins = {PUB / name: sha for name, sha in TOOLS.items()}
    pins.update({PLAN: args.expected_plan_sha256, launcher: args.expected_launcher_sha256})

    def frozen():
        records = [identity(path) for path in pins]
        need(all(row['sha256'] == pins[Path(row['path'])] for row in records), 'frozen tool, plan or launcher changed')
        return records

    def stage(name, argv=None, action=None, timeout=300):
        row = {'name': name, 'argv': argv or ['internal:explicit-batch-extras'], 'started_utc': now(),
               'pid': None, 'direct_child': argv is not None, 'reaped': False if argv else None,
               'returncode': None, 'timed_out': False, 'timeout_seconds': timeout if argv else None}
        report['stages'].append(row)
        paths = {stream: CONTROL / (name + '.' + stream) for stream in ('stdout', 'stderr')}
        started, child = time.monotonic(), None
        try:
            frozen()
            with paths['stdout'].open('xb') as stdout, paths['stderr'].open('xb') as stderr:
                if argv:
                    env = os.environ.copy()
                    for key in ('PYTHONPATH', 'PYTHONHOME', 'PYTHONSTARTUP'):
                        env.pop(key, None)
                    child = subprocess.Popen(argv, cwd=PUB, stdin=subprocess.DEVNULL, stdout=stdout,
                                             stderr=stderr, env=env, start_new_session=True)
                    try:
                        row['pid'] = child.pid
                        write_new(CONTROL / (name + '.started.json'), row)
                        row['returncode'] = child.wait(timeout=timeout)
                    except BaseException as error:
                        row['timed_out'] = isinstance(error, subprocess.TimeoutExpired)
                        # This session contains only this launcher's frozen tool
                        # and its packager children. Never scan or signal runtime.
                        try:
                            os.killpg(child.pid, signal.SIGKILL)
                        except ProcessLookupError:
                            pass
                        row['returncode'] = child.wait(timeout=15)
                        raise
                    finally:
                        row['reaped'] = child.returncode is not None
                else:
                    row['pid'] = os.getpid()
                    write_new(CONTROL / (name + '.started.json'), row)
                    stdout.write(encoded(action()))
                    row['returncode'] = 0
            need(row['returncode'] == 0, name + ' failed; no automatic retry')
            frozen()
        except BaseException as error:
            row['error'] = {'type': type(error).__name__, 'message': str(error)}
            raise
        finally:
            row.update(finished_utc=now(), seconds=time.monotonic() - started)
            for stream, path in paths.items():
                if path.exists():
                    row[stream] = identity(path)
            write_new(CONTROL / (name + '.finished.json'), row)
        return load(paths['stdout'])

    def command(tool, *arguments):
        # publication_transfer imports its sibling helper, so do not use -I.
        return [sys.executable, '-B', str(PUB / tool), *map(str, arguments)]

    def interrupted(signum, _frame):
        raise InterruptedError('launcher received signal ' + str(signum))

    old_handlers = {sig: signal.signal(sig, interrupted) for sig in (signal.SIGTERM, signal.SIGINT)}
    try:
        report['inputs_before'] = frozen()
        plan = load(PLAN)
        group = plan['publication_groups']['remote']
        need(group.get('evidence_closed') is True and group.get('measurement_window_closed') is True
             and group.get('packages') == IDS, 'plan remote group differs or is still open')
        packages = {row['id']: row for row in plan['packages']}
        need(all(packages[name]['repo_dir'] == REPO
                 and packages[name]['archive_stem'] == name.removeprefix('r19-') for name in IDS),
             'plan output identities differ')
        prepared = stage('01-tiny-fingerprints', command('prepare_tiny_fingerprint_export.py',
                         '--evidence-window-closed'), timeout=60)
        need(prepared.get('passed') is True and prepared.get('files') == 6, 'tiny export did not close')
        checked = stage('02-check-plan', command('package_r19_evidence.py', '--plan', PLAN,
                        '--group', 'remote', '--check-plan'), timeout=60)
        need(checked.get('ready') is True and checked.get('package_ids') == IDS, 'plan check is not ready')
        stage('03-package', command('package_r19_evidence.py', '--plan', PLAN, '--group', 'remote',
              '--packages', *IDS, '--run-root', RUN, '--stage-root', STAGE, '--stage-timeout', '1800'), timeout=1800)
        extras = stage('04-batch-extras', action=lambda: build_extras(args.expected_plan_sha256))
        indexed = stage('05-remote-index', command('publication_transfer.py', 'remote-index', '--receipts',
                        *extras['receipts'], '--extras', EXTRAS, '--local-stage', LOCAL_STAGE, '--output', INDEX))
        original_index = identity(INDEX)
        need(indexed.get('sha256') == original_index['sha256'] and indexed.get('files') == 83,
             'original transfer index does not contain nine triples plus 56 extras')
        envelope = stage('06-envelope', command('pack_transfer_01.py', 'pack', '--index', INDEX,
                         '--expected-index-sha256', original_index['sha256'], '--stage-root', STAGE,
                         '--extra-root', RUN, '--output-root', ENVELOPE, '--evidence-window-closed'), timeout=600)
        need(envelope.get('passed') is True and envelope.get('member_files') == 83
             and envelope.get('original_index_sha256') == original_index['sha256'], 'envelope did not verify')
        single = ENVELOPE / 'envelope-transfer-index-01.json'
        need(identity(single)['sha256'] == envelope['transfer_index_sha256']
             and len(load(single)['files']) == 1, 'single-envelope transfer index differs')
        split = stage('07-chunks', command('publication_transfer.py', 'chunks', '--index', single,
                      '--pieces-dir', ENVELOPE / 'pieces', '--output', CHUNKS))
        need(split.get('files') == 1 and split.get('sha256') == identity(CHUNKS)['sha256']
             and load(CHUNKS)['source_index_sha256'] == envelope['transfer_index_sha256'], 'chunk manifest differs')
        need(identity(INDEX) == original_index, 'original index changed')
        report.update(original_index=original_index, envelope=identity(envelope['archive_path']),
                      envelope_report=identity(ENVELOPE / 'report.json'), chunk_manifest=identity(CHUNKS),
                      envelope_transfer_index=identity(single), batch_report=identity(RUN / 'report.json'),
                      extras=identity(EXTRAS), pieces=split['pieces'], inputs_after=frozen(), passed=True)
    except BaseException as error:
        report['error'] = {'type': type(error).__name__, 'message': str(error)}
        with (CONTROL / 'error.txt').open('xb') as stream:
            stream.write(traceback.format_exc().encode())
        if (RUN / 'error.txt').is_file():
            report['batch_error'] = identity(RUN / 'error.txt')
    finally:
        report['finished_utc'] = now()
        report['control_files'] = [identity(path) for path in sorted(CONTROL.iterdir()) if path.is_file()]
        write_new(CONTROL / 'report.json', report)
        for sig, handler in old_handlers.items():
            signal.signal(sig, handler)
        print(json.dumps({'passed': report['passed'], 'control_report': identity(CONTROL / 'report.json'),
                          'chunk_manifest': report.get('chunk_manifest'), 'envelope': report.get('envelope'),
                          'original_index': report.get('original_index'), 'error': report.get('error'),
                          'control_evidence_in_envelope': False}, sort_keys=True), flush=True)
    return 0 if report['passed'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
