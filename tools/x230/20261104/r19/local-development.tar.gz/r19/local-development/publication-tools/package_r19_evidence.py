#!/usr/bin/env python3
# Copyright 2026 TrillionniumFoundation
# SPDX-License-Identifier: Apache-2.0
"""Sequential, no-workload R19 inventory/pack driver using the frozen packager.

--check-plan reads only this plan and tool files; it never visits evidence roots.
Execution requires a closed group, complete packages, and all declared SHA256
bindings filled. A new run directory retains every attempted stage, including
empty streams, nonzero exits and timeouts. No archive or prior attempt is replaced.
"""
import argparse
import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import time
import traceback

PACKAGER_SHA256 = '226edda9684f742178398c09266a171df38df5e505c0020372e72265ff684c43'
PLAN_SCHEMA = 'hepta-x230-evidence-publication/v1'


def need(value, message):
    if not value:
        raise ValueError(message)


def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def write_new(path, raw):
    with Path(path).open('xb') as stream:
        stream.write(raw)


def encode(value):
    return (json.dumps(value, indent=2, sort_keys=True) + '\n').encode()


def save(path, value):
    temporary = path.with_name(path.name + '.next')
    write_new(temporary, encode(value))
    os.replace(temporary, path)


def plan_check(plan, group_name, requested):
    need(plan.get('schema') == PLAN_SCHEMA, 'unexpected plan schema')
    groups = plan['publication_groups']
    need(group_name in groups, 'unknown publication group')
    group = groups[group_name]
    all_packages = plan['packages']
    by_id = {p['id']: p for p in all_packages}
    need(len(by_id) == len(all_packages), 'duplicate package ID')
    members = group['packages']
    need(len(members) == len(set(members)) and set(members) <= set(by_id), 'invalid group membership')
    chosen = requested or members
    need(chosen and len(chosen) == len(set(chosen)) and set(chosen) <= set(members), 'package not in selected group')
    selected = [by_id[name] for name in members if name in chosen]
    incomplete = []
    pending = []
    def bound(value, key):
        if not isinstance(value, str) or not re.fullmatch('[0-9a-f]{64}', value):
            incomplete.append(key)
    for package in selected:
        identifier = package['id']
        need(re.fullmatch('[A-Za-z0-9_.-]+', identifier), 'unsafe package ID')
        need(package['kind'] in {'selectors', 'qualification', 'native', 'config', 'boundary', 'recovery'}, 'unsupported package kind')
        if package['state'] != 'complete':
            pending.append(identifier)
        if package['kind'] != 'selectors':
            bound(package.get('expected_report_sha256'), identifier + '.expected_report_sha256')
        for index, selector in enumerate(package.get('selectors', [])):
            need(selector['root'] in plan['roots'], 'unknown selector root')
            for name, value in selector.get('expected_sha256', {}).items():
                need(name in selector.get('files', []), 'required binding must name a required selected file')
                bound(value, identifier + '.selectors[' + str(index) + '].expected_sha256[' + name + ']')
        repo = Path(package['repo_dir'])
        need(not repo.is_absolute() and '..' not in repo.parts and str(repo) == package['repo_dir'], 'unsafe repository directory')
        need(re.fullmatch('[A-Za-z0-9_.-]+', package['archive_stem']), 'unsafe archive stem')
    tools = plan['publication_tools']
    need(tools['packager_sha256'] == PACKAGER_SHA256, 'plan selects another packager revision')
    need(tools['driver_sha256'] == sha(Path(__file__)), 'driver differs from frozen plan')
    ready = group.get('evidence_closed') is True and group.get('measurement_window_closed') is True and not pending and not incomplete
    return selected, {'ready': ready, 'group': group_name, 'package_ids': [p['id'] for p in selected],
                      'evidence_closed': group.get('evidence_closed') is True,
                      'measurement_window_closed': group.get('measurement_window_closed') is True,
                      'pending_packages': pending, 'unfilled_sha256_fields': incomplete,
                      'evidence_roots_accessed': False}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--plan', type=Path, required=True)
    parser.add_argument('--group', choices=('remote', 'local-development'), default='remote')
    parser.add_argument('--packages', nargs='+')
    parser.add_argument('--packager', type=Path, default=Path(__file__).with_name('package_x230_evidence.py'))
    parser.add_argument('--run-root', type=Path)
    parser.add_argument('--stage-root', type=Path)
    parser.add_argument('--stage-timeout', type=float, default=1800)
    parser.add_argument('--check-plan', action='store_true')
    args = parser.parse_args()
    plan_raw = args.plan.read_bytes()
    plan = json.loads(plan_raw)
    selected, readiness = plan_check(plan, args.group, args.packages)
    packager = args.packager.absolute()
    need(packager.resolve() == packager and sha(packager) == PACKAGER_SHA256, 'packager bytes/path differ')
    if args.check_plan or not readiness['ready']:
        print(json.dumps(readiness, sort_keys=True))
        return 0 if readiness['ready'] else 2
    if args.run_root is None or args.stage_root is None:
        parser.error('--run-root and --stage-root are required for execution')
    need(0 < args.stage_timeout <= 7200, 'invalid stage timeout')
    root, stage = args.run_root.absolute(), args.stage_root.absolute()
    need(root.resolve() == root and stage.resolve() == stage, 'output root traverses a symlink or noncanonical path')
    for package in selected:
        base = stage / package['repo_dir'] / package['archive_stem']
        for suffix in ('.tar.gz', '.manifest.json', '.archive.json'):
            need(not os.path.lexists(str(base) + suffix), 'selected archive output already exists')
    root.mkdir(mode=0o700, parents=True, exist_ok=False)
    frozen_plan = root / 'plan.frozen.json'
    write_new(frozen_plan, plan_raw)
    report = {'schema': 'hepta-r19-publication-batch/v1', 'passed': False, 'started_utc': now(),
              'plan_sha256': hashlib.sha256(plan_raw).hexdigest(), 'driver_sha256': sha(Path(__file__)),
              'packager_sha256': PACKAGER_SHA256, 'group': args.group, 'package_ids': readiness['package_ids'],
              'runtime_workloads_started': False, 'builds_started': False, 'network_requests': 0,
              'automatic_retries': 0, 'packages': [], 'archives': []}
    current = root / 'report.json'
    try:
        # This only lowers the current driver/packager priority. It never touches
        # the priorities, signals or process state of any measurement workload.
        if hasattr(os, 'nice'):
            os.nice(19)
        for package in selected:
            identifier = package['id']
            directory = root / identifier
            directory.mkdir(mode=0o700)
            entry = {'id': identifier, 'passed': False, 'stages': []}
            report['packages'].append(entry)
            inventory = directory / 'inventory.json'
            output = stage / package['repo_dir']
            invocations = [('inventory', ['inventory', '--plan', str(frozen_plan), '--package', identifier, '--output', str(inventory)]),
                           ('pack', ['pack', '--inventory', str(inventory), '--output-dir', str(output)])]
            for name, arguments in invocations:
                need(sha(packager) == PACKAGER_SHA256 and sha(frozen_plan) == report['plan_sha256'], 'frozen tool/plan changed')
                command = [sys.executable, '-I', '-B', str(packager)] + arguments
                row = {'name': name, 'argv': command, 'started_utc': now(), 'returncode': None, 'timed_out': False}
                entry['stages'].append(row)
                save(current, report)
                started = time.monotonic()
                paths = {stream: directory / (name + '.' + stream) for stream in ('stdout', 'stderr')}
                try:
                    with paths['stdout'].open('xb') as stdout, paths['stderr'].open('xb') as stderr:
                        process = subprocess.run(command, cwd=packager.parent, stdin=subprocess.DEVNULL,
                                                 stdout=stdout, stderr=stderr, timeout=args.stage_timeout)
                    row['returncode'] = process.returncode
                except subprocess.TimeoutExpired as error:
                    # The pinned packager has no subprocess/network/workload API:
                    # subprocess.run kills and reaps the sole packager process.
                    row['timed_out'] = True
                    row['error'] = {'type': type(error).__name__, 'message': str(error)}
                except Exception as error:
                    row['error'] = {'type': type(error).__name__, 'message': str(error)}
                finally:
                    row.update(seconds=time.monotonic() - started, finished_utc=now())
                    for stream, path in paths.items():
                        if path.is_file():
                            row[stream] = {'path': str(path), 'bytes': path.stat().st_size, 'sha256': sha(path)}
                    save(directory / 'status.json', entry)
                    save(current, report)
                need(row['returncode'] == 0 and not row['timed_out'], identifier + '/' + name + ' failed; no automatic retry')
            receipt_path = output / (package['archive_stem'] + '.archive.json')
            receipt = json.loads(receipt_path.read_bytes())
            need(receipt.get('verified') is True and receipt.get('original_bytes_changed') is False
                 and receipt['plan_sha256'] == report['plan_sha256'], 'packager receipt differs')
            entry['passed'] = True
            entry['archive_receipt'] = {'path': str(receipt_path), 'sha256': sha(receipt_path)}
            report['archives'].append({'package': identifier, 'receipt': str(receipt_path),
                                       'archive': str(output / receipt['archive']), 'archive_sha256': receipt['archive_sha256'],
                                       'manifest': str(output / receipt['manifest']), 'manifest_sha256': receipt['manifest_sha256'],
                                       'archive_bytes': receipt['archive_bytes'], 'over_50_mib': receipt['over_50_mib']})
            save(directory / 'status.json', entry)
            save(current, report)
        need(sha(packager) == PACKAGER_SHA256 and sha(frozen_plan) == report['plan_sha256'], 'frozen tool/plan changed at completion')
        report['passed'] = True
    except BaseException as error:
        report['error'] = {'type': type(error).__name__, 'message': str(error)}
        write_new(root / 'error.txt', traceback.format_exc().encode())
    finally:
        report['finished_utc'] = now()
        save(current, report)
        print(json.dumps({'passed': report['passed'], 'report': str(current), 'report_sha256': sha(current),
                          'archives': report['archives'], 'error': report.get('error')}, sort_keys=True), flush=True)
    return 0 if report['passed'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
