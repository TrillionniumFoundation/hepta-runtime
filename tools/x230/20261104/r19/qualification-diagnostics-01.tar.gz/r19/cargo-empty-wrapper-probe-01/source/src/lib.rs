pub struct Marker;
pub fn value() -> u64 { 42 }
