use std::any::TypeId;
struct Local;
fn main() { println!("{:?} {:?} {}", TypeId::of::<Local>(), TypeId::of::<wrapper_metadata_probe::Marker>(), wrapper_metadata_probe::value()); }
