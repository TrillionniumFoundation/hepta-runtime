import ast,datetime,hashlib,json,os,re,stat,subprocess,sys,traceback
from pathlib import Path
import tomllib
R18=Path('/home/qian/hepta-runtime-optimization-20261104-r18')
R19=Path('/home/qian/hepta-runtime-optimization-20261104-r19')
CH=Path('/home/qian/hepta-runtime-optimization-20261023/cargo-home-a32-a33-r02')
OUT=R19/'review-qualification-environment-01.json'
TARGETS={'r18':R18/'target-fresh-02','r19':R19/'target-fresh-01'}
KEYS=('rustc','features','declared_features','target','profile','path','deps','rustflags','config','compile_kind')
ENV_KEYS={'HOME','PATH','LANG','LC_ALL','LC_CTYPE','TZ','SOURCE_DATE_EPOCH','RUSTC','RUSTDOC','RUSTC_BOOTSTRAP','RUSTC_FORCE_RUSTC_VERSION','RUSTFLAGS','RUSTDOCFLAGS','CARGO_ENCODED_RUSTFLAGS','CARGO_ENCODED_RUSTDOCFLAGS','RUSTC_WRAPPER','RUSTC_WORKSPACE_WRAPPER','RUSTUP_HOME','RUSTUP_TOOLCHAIN','__CARGO_DEFAULT_LIB_METADATA','CARGO_HOME','CARGO_TARGET_DIR','CARGO_BUILD_RUSTC','CARGO_BUILD_RUSTC_WRAPPER','CARGO_BUILD_RUSTC_WORKSPACE_WRAPPER','CARGO_BUILD_RUSTFLAGS','CARGO_BUILD_TARGET','CARGO_BUILD_INCREMENTAL','CARGO_INCREMENTAL','CARGO_PROFILE_RELEASE_OPT_LEVEL','CARGO_PROFILE_RELEASE_DEBUG','CARGO_PROFILE_RELEASE_LTO','CARGO_PROFILE_RELEASE_CODEGEN_UNITS','CARGO_PROFILE_RELEASE_PANIC','CARGO_PROFILE_RELEASE_STRIP','CARGO_PROFILE_RELEASE_DEBUG_ASSERTIONS','CARGO_PROFILE_RELEASE_OVERFLOW_CHECKS','CC','CXX','AR','LD','RANLIB','CFLAGS','CPPFLAGS','CXXFLAGS','LDFLAGS','ARFLAGS','HOST_CC','HOST_CFLAGS','TARGET_CC','TARGET_CFLAGS','RUST_TARGET_PATH','CARGO_TARGET_X86_64_UNKNOWN_LINUX_GNU_LINKER','CARGO_TARGET_X86_64_UNKNOWN_LINUX_GNU_RUSTFLAGS','CC_x86_64_unknown_linux_gnu','CFLAGS_x86_64_unknown_linux_gnu'}
SENSITIVE=re.compile(r'(?i)(-----BEGIN .*PRIVATE KEY|bearer\s+\S+|(?:token|secret|password|api[_-]?key)\s*[=:]|[a-z]+://[^/\s]+:[^/@\s]+@)')
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def sha(raw):return hashlib.sha256(raw).hexdigest()
def read(path,maxbytes=4*1024*1024,allow_links=False):
 p=Path(path);before=p.stat() if allow_links else p.lstat()
 if not stat.S_ISREG(before.st_mode):raise ValueError('not regular: '+str(p))
 if before.st_size>maxbytes:raise ValueError('oversized: '+str(p))
 with p.open('rb') as f:
  fd0=os.fstat(f.fileno());raw=f.read(maxbytes+1);fd1=os.fstat(f.fileno())
 after=p.stat() if allow_links else p.lstat()
 fields=('st_dev','st_ino','st_mode','st_size','st_mtime_ns','st_ctime_ns')
 stamp=lambda x:tuple(getattr(x,k) for k in fields)
 if len(raw)!=before.st_size or not (stamp(before)==stamp(fd0)==stamp(fd1)==stamp(after)):raise ValueError('changed: '+str(p))
 return raw,{'path':str(p),'bytes':len(raw),'sha256':sha(raw),'mtime_ns':before.st_mtime_ns,'nlink':before.st_nlink}
def digest_file(p):
 p=Path(p);real=p.resolve();h=hashlib.sha256();n=0
 with real.open('rb') as f:
  before=os.fstat(f.fileno())
  if not stat.S_ISREG(before.st_mode):raise ValueError('nonregular tool')
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b);n+=len(b)
  after=os.fstat(f.fileno())
 if (before.st_dev,before.st_ino,before.st_size,before.st_mtime_ns)!=(after.st_dev,after.st_ino,after.st_size,after.st_mtime_ns) or n!=before.st_size:raise ValueError('tool changed')
 return {'path':str(p),'resolved_path':str(real),'bytes':n,'sha256':h.hexdigest(),'mtime_ns':before.st_mtime_ns,'nlink':before.st_nlink}
def safe(v):
 raw=json.dumps(v,sort_keys=True,ensure_ascii=True).encode()
 if len(raw)>16384 or SENSITIVE.search(raw.decode()):return {'value_omitted':True,'sha256':sha(raw),'bytes':len(raw)}
 return v
def doc(p):
 raw,ident=read(p);return json.loads(raw),ident
def original_json(p):
 raw,ident=read(p);d=json.loads(raw)
 return {'identity':ident,'object':safe(d),'original_utf8':raw.decode() if not SENSITIVE.search(raw.decode()) else None},d
report={'schema':'hepta-r19-qualification-environment-diagnostic/v1','started_utc':now(),'diagnostic_key':'r19-env-diagnostic-01','read_only':True,'compilations_started':0,'original_files_modified':False,'full_environment_retained':False,'credential_files_read':False,'notes':['Current diagnostic environment is not evidence of the historical R18 parent environment.','R18 retained environment variables outside its clear prefixes were not comprehensively archived.','The failed independent acceptance is preserved unchanged.'],'errors':[]}
if OUT.exists():raise SystemExit('diagnostic output already exists; no replacement')
def attempt(name,fn):
 try:return fn()
 except BaseException as e:
  report['errors'].append({'area':name,'type':type(e).__name__,'message':str(e)[:500]});return None
jobctls={}
for label,target in TARGETS.items():
 entries=[]
 for p in sorted((target/'release/.fingerprint').glob('hepta-runtime-*/bin-hepta-runtime-jobctl.json')):
  item,d=original_json(p);item['fields']={k:safe(d.get(k)) for k in KEYS};item['unit_directory']=p.parent.name;entries.append(item)
 jobctls[label]=entries
report['jobctl_fingerprints']=jobctls
comparison={'r18_count':len(jobctls['r18']),'r19_count':len(jobctls['r19'])}
if len(jobctls['r18'])==len(jobctls['r19'])==1:
 a,b=jobctls['r18'][0],jobctls['r19'][0]
 comparison['unit_directories']={'r18':a['unit_directory'],'r19':b['unit_directory']}
 comparison['fields']={k:{'equal':a['fields'][k]==b['fields'][k],'r18':a['fields'][k],'r19':b['fields'][k]} for k in KEYS}
report['jobctl_comparison']=comparison
print('R19_JOBCTL_FINGERPRINT_COMPARISON '+json.dumps(comparison,sort_keys=True),flush=True)
protected={}
report['qualifications']={}
for label,root,qnum in [('r18',R18,'02'),('r19',R19,'01')]:
 q=root/('qualification-'+qnum)
 qr,ident=doc(q/'report.json');protected[str(q/'report.json')]=ident['sha256']
 stages=[{'name':x['name'],'command':x['command'],'returncode':x.get('returncode'),'seconds':x.get('seconds'),'stdout_sha256':x.get('stdout_sha256'),'stderr_sha256':x.get('stderr_sha256')} for x in qr['stages']]
 source_input=qr.get('source_tested',qr.get('source_input',{}))
 binaries={name:{'reported':row,'actual':digest_file(Path(row['path']))} for name,row in qr.get('binaries',{}).items()}
 qualifier=root/'source/tools/x230/20261028/qualify.py'
 qb,qi=read(qualifier);protected[str(qualifier)]=qi['sha256']
 events=[json.loads(line) for line in (q/'cargo-no-run.jsonl').read_bytes().splitlines() if line.strip()]
 tests=[{'target':e['target']['name'],'kind':e['target']['kind'],'executable':e['executable'],'basename':Path(e['executable']).name,'profile':e['profile'],'fresh':e.get('fresh'),'manifest_path':e.get('manifest_path'),'package_id':e.get('package_id')} for e in events if e.get('reason')=='compiler-artifact' and e.get('profile',{}).get('test') and e.get('executable')]
 launch_path=root/('qualification-launch-'+qnum+'.json');launch,li=doc(launch_path);protected[str(launch_path)]=li['sha256']
 keep=('schema','argv','cwd','toolchain','environment_policy','explicit_environment','clear_environment_prefixes','clear_environment_exact_names','cleared_environment_key_names','launcher_sha256','script_sha256','qualifier_sha256')
 report['qualifications'][label]={'report_identity':ident,'qualified':qr.get('qualified'),'started_utc':qr.get('started_utc'),'finished_utc':qr.get('finished_utc'),'stages':stages,'launch_identity':li,'launch':{k:safe(launch[k]) for k in keep if k in launch},'qualifier':qi,'compile_input_count':len(source_input),'compile_inputs':source_input,'binaries':binaries,'test_artifacts':tests}
 for special in ['independent-acceptance-01.json','prequalification-01/report.json'] if label=='r19' else []:
  data,di=doc(root/special);protected[str(root/special)]=di['sha256']
  report['qualifications'][label][special]={'identity':di,'accepted':data.get('accepted'),'passed':data.get('passed'),'checks':data.get('checks'),'error':data.get('error')}
report['qualifier_equal']=report['qualifications']['r18']['qualifier']['sha256']==report['qualifications']['r19']['qualifier']['sha256']
a=report['qualifications']['r18']['compile_inputs'];b=report['qualifications']['r19']['compile_inputs']
report['compile_input_differences']=[p for p in sorted(set(a)|set(b)) if a.get(p)!=b.get(p)]
report['current_diagnostic_selected_environment']={k:safe(os.environ[k]) for k in sorted(ENV_KEYS) if k in os.environ}
report['historical_environment_limit']='The selected diagnostic values above are current only. Original launch scripts/receipts and Cargo caches below bound the historical evidence; unrecorded inherited values remain unknown.'
report['launcher_sources']={}
for label,p in [('r18',R18/'qualification-fresh-02.py'),('r19',R19/'tools/qualify_candidate.py')]:
 raw,ident=read(p,2*1024*1024);protected[str(p)]=ident['sha256']
 tree=ast.parse(raw)
 extracts=[]
 for node in ast.walk(tree):
  if isinstance(node,ast.FunctionDef) and node.name=='clean_environment':extracts.append(ast.get_source_segment(raw.decode(),node))
  if isinstance(node,ast.Assign) and any(isinstance(t,ast.Name) and t.id in ('env','prefixes','exact','removed') for t in node.targets):
   segment=ast.get_source_segment(raw.decode(),node)
   if len(segment or '')<4096:extracts.append(segment)
 report['launcher_sources'][label]={'identity':ident,'environment_code':safe(extracts)}
configs=[]
for label,root in [('r18',R18),('r19',R19)]:
 source=root/'source'
 locations=[source,*source.parents,CH]
 for directory in locations:
  for name in ('config','config.toml'):
   path=(directory/name) if directory==CH else directory/'.cargo'/name
   if str(path) not in [x['path'] for x in configs]:
    row={'path':str(path),'contexts':[label],'exists':os.path.lexists(path)}
    if row['exists']:
     if path.is_symlink():row.update(symlink=True,resolved_path=str(path.resolve()),contents_not_read=True)
     else:
      raw,ident=read(path,1024*1024);row['identity']=ident;protected[str(path)]=ident['sha256']
      try:
       config=tomllib.loads(raw.decode())
       selected={k:safe(config[k]) for k in ('build','profile','unstable') if k in config}
       if 'target' in config:selected['target']={k:{key:safe(value) for key,value in v.items() if key in ('linker','rustflags','runner','ar')} for k,v in config['target'].items() if isinstance(v,dict)}
       if 'env' in config:
        selected['env']={k:safe(v) for k,v in config['env'].items() if k in ENV_KEYS}
        selected['other_env_key_count']=len(set(config['env'])-ENV_KEYS)
       row['compiler_projection']=selected
       row['other_top_level_sections']=[k for k in config if k not in ('build','profile','unstable','target','env')]
      except BaseException as e:row['parse_error_type']=type(e).__name__
    configs.append(row)
   else:
    row=next(x for x in configs if x['path']==str(path))
    if label not in row['contexts']:row['contexts'].append(label)
report['cargo_config_candidates']=configs
report['source_cargo_profiles']={}
for label,root in [('r18',R18),('r19',R19)]:
 p=root/'source/Cargo.toml';raw,ident=read(p);toml=tomllib.loads(raw.decode())
 report['source_cargo_profiles'][label]={'identity':ident,'profile':safe(toml.get('profile',{})),'jobctl_target':[safe(x) for x in toml.get('bin',[]) if x.get('name')=='hepta-runtime-jobctl'],'package':{k:toml.get('package',{}).get(k) for k in ('name','version','edition','rust-version')}}
report['cargo_rustc_cache']={}
for label,target in TARGETS.items():
 p=target/'.rustc_info.json'
 if p.is_file():
  entry,d=original_json(p);report['cargo_rustc_cache'][label]=entry
 else:report['cargo_rustc_cache'][label]={'path':str(p),'exists':False}
clean={'HOME':'/home/qian','PATH':'/home/qian/.cargo/bin:/usr/local/bin:/usr/bin:/bin','LANG':'C.UTF-8','LC_ALL':'C.UTF-8','RUSTUP_HOME':'/home/qian/.rustup','RUSTUP_AUTO_INSTALL':'0','CARGO_HOME':str(CH),'CARGO_NET_OFFLINE':'true'}
report['current_toolchain_commands']=[]
for program,argv in [('rustc',['/home/qian/.cargo/bin/rustc','+1.95.0','-vV']),('cargo',['/home/qian/.cargo/bin/cargo','+1.95.0','-Vv']),('rustc_path',['/home/qian/.cargo/bin/rustup','which','--toolchain','1.95.0','rustc']),('cargo_path',['/home/qian/.cargo/bin/rustup','which','--toolchain','1.95.0','cargo'])]:
 def version():
  p=subprocess.run(argv,cwd=R19,env=clean,stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=20)
  row={'label':program,'argv':argv,'returncode':p.returncode,'stdout':safe(p.stdout.decode(errors='replace')),'stderr':safe(p.stderr.decode(errors='replace'))}
  if program.endswith('_path') and p.returncode==0:
   actual=Path(p.stdout.decode().strip())
   if str(actual).startswith('/home/qian/.rustup/toolchains/') and actual.is_file():row['executable_identity']=digest_file(actual)
  report['current_toolchain_commands'].append(row)
 attempt('version:'+program,version)
report['release_fingerprint_catalogs']={}
for label,target in TARGETS.items():
 catalog=[]
 for p in sorted((target/'release/.fingerprint').glob('*/*.json')):
  if not (p.name.startswith(('lib-','bin-','build-script-','run-build-script-'))):continue
  try:
   raw,ident=read(p,1024*1024);data=json.loads(raw)
   # Cargo fingerprint records are build metadata, not registry credential files.
   row={'identity':ident,'unit_directory':p.parent.name,'file':p.name,'fields':{k:safe(data.get(k)) for k in KEYS}}
   locals=[]
   for local in data.get('local',[]):
    if 'RerunIfEnvChanged' in local:
     val=local['RerunIfEnvChanged'];key=val.get('var')
     locals.append({'RerunIfEnvChanged':{key:safe(val.get('val'))}} if key in ENV_KEYS else {'RerunIfEnvChanged':{'var':key,'value_omitted':True}})
    else:locals.append(safe(local))
   row['local']=locals
   if p.name.startswith('lib-') and p.name[4:-5] in {'anyhow','serde','serde_core','serde_json','sha2','libc','digest','generic_array','typenum','crypto_common','block_buffer','cpufeatures','memchr','itoa','ryu','serde_derive','proc_macro2','quote','syn','unicode_ident'}:
    row['original_utf8']=raw.decode() if not SENSITIVE.search(raw.decode()) else None
   catalog.append(row)
  except BaseException as e:report['errors'].append({'area':str(p),'type':type(e).__name__})
 report['release_fingerprint_catalogs'][label]=catalog
report['build_script_outputs']={}
for label,target in TARGETS.items():
 result=[]
 for p in sorted((target/'release/build').glob('*/output')):
  raw,ident=read(p,2*1024*1024);lines=raw.decode(errors='replace').splitlines()
  relevant=[]
  for line in lines:
   if line.startswith(('cargo:rustc-','cargo::rustc-','cargo:rerun-if-env-changed=','cargo::rerun-if-env-changed=')):
    relevant.append(safe(line))
  result.append({'identity':ident,'directory':p.parent.name,'compiler_lines':relevant,'other_line_count':len(lines)-len(relevant)})
 report['build_script_outputs'][label]=result
report['protected_inputs_unchanged']=all(read(Path(p),4*1024*1024)[1]['sha256']==expected for p,expected in protected.items())
report['finished_utc']=now()
raw=(json.dumps(report,indent=2,sort_keys=True)+'\n').encode()
with OUT.open('xb') as f:f.write(raw);f.flush();os.fsync(f.fileno())
summary={'diagnostic_complete':True,'path':str(OUT),'bytes':len(raw),'sha256':sha(raw),'qualifier_equal':report['qualifier_equal'],'source_differences':report['compile_input_differences'],'config_files':[x for x in configs if x['exists']],'toolchain':report['current_toolchain_commands'],'errors':report['errors'],'protected_inputs_unchanged':report['protected_inputs_unchanged'],'historical_environment_not_reconstructed':True}
print('R19_ENV_DIAGNOSTIC_RESULT '+json.dumps(summary,sort_keys=True),flush=True)
