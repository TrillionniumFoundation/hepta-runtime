#!/usr/bin/env python3
# Copyright 2026 TrillionniumFoundation
# SPDX-License-Identifier: Apache-2.0
"""Freeze R19, then invoke the unchanged qualifier once in a new Cargo target.

Run as qian on X230. No compilation occurs with --self-test. This launcher never
reuses an attempt or cleans an old directory. Independent acceptance is produced
separately by verify_qualification.py.
"""
import argparse
import datetime
import hashlib
import json
import os
from pathlib import Path
import pwd
import re
import shutil
import socket
import stat
import subprocess
import sys
import tempfile
import time

DEFAULT_ROOT = Path('/home/qian/hepta-runtime-optimization-20261104-r19')
BASELINE = Path('/home/qian/hepta-runtime-optimization-20261104-r18/source')
CARGO_HOME = Path('/home/qian/hepta-runtime-optimization-20261023/cargo-home-a32-a33-r02')
QUALIFIER_SHA256 = '95717717fd5421f2e31dbce24e2f8821696f57d779ce93e988ed66764159552d'
BASELINE_JOBS_SHA256 = '694a4e4dcbc2be499879abd837f0b5e399f9cad95caab34716907de15cbbe82f'
JOBCTL_SOURCE_SHA256 = 'c22fdcd5bafad3a2123d5817c27fd73e7b5c26001bf1a8bdd6f8dbacabc8b562'
JOBCTL_BINARY_SHA256 = '61c90260057a405626a24a36ad43303c632f72d2d97929296acdffd748b79d62'
JOBS_PATH = 'src/mcp/runtime/jobs.rs'
MINIMUM_FREE_BYTES = 16 * 1024 ** 3


def need(value, message):
    if not value:
        raise ValueError(message)


def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def stamp(s):
    return (s.st_dev, s.st_ino, s.st_mode, s.st_nlink, s.st_size, s.st_mtime_ns, s.st_ctime_ns)


def identity(path):
    """Hash a stable, ordinary, unshared file without following its final symlink."""
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK | os.O_CLOEXEC)
    try:
        before = os.fstat(fd)
        need(stat.S_ISREG(before.st_mode) and before.st_nlink == 1, 'non-regular or hardlinked file: ' + str(path))
        h, count = hashlib.sha256(), 0
        while True:
            block = os.read(fd, 1 << 20)
            if not block:
                break
            h.update(block)
            count += len(block)
        need(count == before.st_size and stamp(before) == stamp(os.fstat(fd)) == stamp(os.lstat(path)),
             'file changed while hashing: ' + str(path))
        return {'size': count, 'sha256': h.hexdigest()}
    finally:
        os.close(fd)


def sha(path):
    return identity(path)['sha256']


def full_map(root):
    need(root.is_dir() and root.resolve() == root.absolute(), 'source path is missing or traverses a symlink')
    result = {}
    for base, directories, files in os.walk(root, followlinks=False):
        for name in directories:
            need(stat.S_ISDIR(os.lstat(Path(base) / name).st_mode), 'non-directory tree entry')
        for name in files:
            path = Path(base) / name
            result[path.relative_to(root).as_posix()] = identity(path)
    return dict(sorted(result.items()))


def compile_map(files):
    return {p: row['sha256'] for p, row in files.items()
            if p in ('Cargo.toml', 'Cargo.lock', 'rustfmt.toml') or p.startswith(('src/', 'examples/'))}


def preparation_map(preparation):
    result = {}
    for row in preparation['files']:
        path = row['path']
        need(isinstance(path, str) and path == Path(path).as_posix() and not Path(path).is_absolute()
             and '..' not in Path(path).parts and path not in ('', '.') and path not in result,
             'invalid or duplicate preparation path')
        need(type(row['size']) is int and row['size'] >= 0 and re.fullmatch('[0-9a-f]{64}', row['sha256']),
             'invalid preparation identity')
        result[path] = {'size': row['size'], 'sha256': row['sha256']}
    return dict(sorted(result.items()))


def validate_sources(baseline, candidate, expected):
    need(len(baseline) == len(candidate) == 281 and set(baseline) == set(candidate), 'full source inventory differs')
    need(len(compile_map(candidate)) == 219, 'compile input count differs from 219')
    need([p for p in baseline if baseline[p] != candidate[p]] == [JOBS_PATH], 'changes extend beyond jobs.rs')
    need(baseline[JOBS_PATH]['sha256'] == BASELINE_JOBS_SHA256, 'R18 jobs.rs identity differs')
    need(candidate[JOBS_PATH]['sha256'] == expected, 'candidate jobs.rs identity differs')
    need(candidate['src/bin/jobctl.rs']['sha256'] == JOBCTL_SOURCE_SHA256, 'jobctl source identity differs')


def save(path, value, replace=False):
    raw = (json.dumps(value, sort_keys=True, indent=2) + '\n').encode()
    if replace:
        temporary = path.with_name(path.name + '.next')
        with temporary.open('xb') as stream:
            stream.write(raw)
        os.replace(temporary, path)
    else:
        with path.open('xb') as stream:
            stream.write(raw)


def clean_environment():
    # Explicit allowlist excludes inherited Rust/Cargo wrappers, loader injection,
    # Python paths, allocator tuning, SSH state and application credentials.
    return {'HOME': '/home/qian', 'USER': 'qian', 'LOGNAME': 'qian',
            'PATH': '/home/qian/.cargo/bin:/usr/local/bin:/usr/bin:/bin',
            'LANG': 'C.UTF-8', 'LC_ALL': 'C.UTF-8',
            'RUSTUP_HOME': '/home/qian/.rustup', 'RUSTUP_AUTO_INSTALL': '0',
            'CARGO_HOME': str(CARGO_HOME), 'CARGO_NET_OFFLINE': 'true',
            'CARGO_INCREMENTAL': '0', 'CARGO_BUILD_JOBS': '2',
            'CARGO_BUILD_RUSTC_WRAPPER': '', 'CARGO_BUILD_RUSTC_WORKSPACE_WRAPPER': '',
            'PYTHONDONTWRITEBYTECODE': '1', 'PYTHONNOUSERSITE': '1',
            'TOKIO_WORKER_THREADS': '2'}


def self_test():
    with tempfile.TemporaryDirectory() as directory:
        root = Path(directory)
        (root / 'src').mkdir()
        (root / 'src' / 'one.rs').write_text('one\n')
        before = full_map(root)
        need(len(compile_map(before)) == 1, 'compile selector self-test failed')
        (root / 'src' / 'one.rs').write_text('two\n')
        need(full_map(root) != before, 'mutation self-test failed')
        os.link(root / 'src' / 'one.rs', root / 'hardlink')
        try:
            full_map(root)
        except ValueError:
            pass
        else:
            raise AssertionError('hardlink accepted')
        (root / 'hardlink').unlink()
        (root / 'symlink').symlink_to(root / 'src')
        try:
            full_map(root)
        except ValueError:
            pass
        else:
            raise AssertionError('symlink accepted')
    need('LD_PRELOAD' not in clean_environment() and 'PYTHONPATH' not in clean_environment(), 'environment is not isolated')
    print(json.dumps({'self_test': True, 'compilation_started': False}))
    return 0


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, default=DEFAULT_ROOT)
    parser.add_argument('--expected-jobs-sha256')
    parser.add_argument('--stage-timeout', type=int, default=3600)
    parser.add_argument('--self-test', action='store_true')
    args = parser.parse_args()
    if args.self_test:
        return self_test()
    if not re.fullmatch('[0-9a-f]{64}', args.expected_jobs_sha256 or ''):
        parser.error('--expected-jobs-sha256 must be lowercase SHA256')
    root = args.root.absolute()
    started = time.monotonic()
    launch = root / 'qualification-launch-01.json'
    progress = root / 'progress.json'
    target, out, source = root / 'target-fresh-01', root / 'qualification-01', root / 'source'
    qualifier = source / 'tools/x230/20261028/qualify.py'
    state = 'preflight'
    child = None
    try:
        need(pwd.getpwuid(os.getuid()).pw_name == 'qian', 'must run as qian on X230')
        need(root.is_dir() and root.resolve() == root and root != BASELINE.parent, 'invalid candidate root')
        need(60 <= args.stage_timeout <= 14400, 'invalid per-stage timeout')
        for path in (target, out, launch, root / 'source-freeze-01.json', root / 'qualification-exit-01.json', progress):
            need(not os.path.lexists(path), 'attempt path already exists: ' + str(path))
        # Atomic reservation prevents two launchers admitting the same attempt.
        (root / 'qualification-01.reserved').mkdir(mode=0o700)
        preparation = json.loads((root / 'preparation.json').read_bytes())
        need(preparation['source'] == str(BASELINE) and preparation['candidate_root'] == str(root), 'preparation targets differ')
        original = preparation_map(preparation)
        need(full_map(BASELINE) == original, 'R18 source differs from preparation')
        frozen = full_map(source)
        validate_sources(original, frozen, args.expected_jobs_sha256)
        need(sha(qualifier) == QUALIFIER_SHA256, 'original qualifier identity differs')
        reference = BASELINE.parent / 'qualification-02/hepta-runtime-jobctl'
        need(sha(reference) == JOBCTL_BINARY_SHA256, 'R18 jobctl binary identity differs')
        free = shutil.disk_usage(root).free
        need(free >= MINIMUM_FREE_BYTES, 'less than 16 GiB free')
        env = clean_environment()
        versions = {}
        for program in ('cargo', 'rustc'):
            process = subprocess.run(['/home/qian/.cargo/bin/' + program, '+1.95.0', '--version'],
                                     cwd=source, env=env, capture_output=True, text=True, timeout=30, check=True)
            versions[program] = process.stdout.strip()
            need(versions[program].startswith(program + ' 1.95.0 '), 'unexpected Rust toolchain version')
        freeze = {'schema': 'hepta-r19-source-freeze/v1', 'created_utc': now(),
                  'source': str(source), 'baseline_source': str(BASELINE),
                  'preparation_sha256': sha(root / 'preparation.json'),
                  'source_full_before': frozen, 'source_inputs_before': compile_map(frozen),
                  'expected_jobs_sha256': args.expected_jobs_sha256,
                  'qualifier_sha256': QUALIFIER_SHA256,
                  'baseline_jobctl_binary': {'path': str(reference), 'sha256': JOBCTL_BINARY_SHA256}}
        save(root / 'source-freeze-01.json', freeze)
        target.mkdir(mode=0o700)
        need(not any(target.iterdir()), 'target was not created empty')
        argv = ['/usr/bin/python3', '-B', '-u', str(qualifier), '--source', str(source), '--output', str(out),
                '--target', str(target), '--cargo-home', str(CARGO_HOME), '--jobs', '2', '--stage-timeout', str(args.stage_timeout)]
        save(launch, {'schema': 'hepta-r19-qualification-launch/v1', 'started_utc': now(),
                      'host': socket.gethostname(), 'user': 'qian', 'argv': argv, 'toolchain': versions,
                      'target_asserted_nonexistent': True, 'target_created_empty': True,
                      'output_asserted_nonexistent': True, 'free_bytes_before': free,
                      'minimum_free_bytes': MINIMUM_FREE_BYTES, 'automatic_retries': 0,
                      'environment_policy': 'explicit-allowlist/v1', 'source_freeze_sha256': sha(root / 'source-freeze-01.json'),
                      'launcher_sha256': sha(Path(__file__).absolute()), 'qualifier_sha256': sha(qualifier)})
        state = 'running'
        stdout_path, stderr_path = root / 'qualification-01.launcher.stdout', root / 'qualification-01.launcher.stderr'
        with stdout_path.open('xb') as stdout, stderr_path.open('xb') as stderr:
            child = subprocess.Popen(argv, cwd=source, env=env, stdout=stdout, stderr=stderr)
            while child.poll() is None:
                current = {}
                try:
                    current = json.loads((out / 'report.json').read_bytes())
                except (FileNotFoundError, json.JSONDecodeError):
                    pass
                save(progress, {'schema': 'hepta-r19-progress/v1', 'state': state, 'updated_utc': now(),
                                'elapsed_seconds': round(time.monotonic() - started, 1),
                                'current_stage': current.get('current_stage'),
                                'completed_stages': sum(s.get('returncode') == 0 for s in current.get('stages', [])),
                                'qualifier_pid': child.pid}, replace=True)
                time.sleep(2)
        report = json.loads((out / 'report.json').read_bytes())
        unchanged = full_map(source) == frozen and full_map(BASELINE) == original
        input_maps_match = all(report.get(k) == freeze['source_inputs_before'] for k in ('source_input', 'source_tested', 'source_after'))
        passed = child.returncode == 0 and report.get('qualified') is True and unchanged and input_maps_match
        receipt = {'schema': 'hepta-r19-qualification-exit/v1', 'finished_utc': now(), 'returncode': child.returncode,
                   'success': passed, 'source_full_before_after_equal': unchanged, 'source_inputs_before_after_equal': input_maps_match,
                   'report_sha256': sha(out / 'report.json'), 'launcher_stdout_sha256': sha(stdout_path),
                   'launcher_stderr_sha256': sha(stderr_path), 'automatic_retries': 0}
        save(root / 'qualification-exit-01.json', receipt)
        save(progress, {'schema': 'hepta-r19-progress/v1', 'state': 'qualified-pending-independent-verification' if passed else 'failed',
                        'updated_utc': now(), 'returncode': child.returncode, 'success': passed,
                        'elapsed_seconds': round(time.monotonic() - started, 1)}, replace=True)
        print(json.dumps({'success': passed, 'returncode': child.returncode, 'report': str(out / 'report.json'),
                          'independent_acceptance_pending': True}), flush=True)
        return 0 if passed else 1
    except Exception as error:
        failure = {'schema': 'hepta-r19-launch-failure/v1', 'state': state, 'updated_utc': now(),
                   'error': type(error).__name__ + ': ' + str(error), 'automatic_retries': 0,
                   'qualifier_pid': child.pid if child else None,
                   'qualifier_may_still_be_running': child is not None and child.poll() is None}
        try:
            save(root / 'qualification-failure-01.json', failure)
        except OSError:
            pass
        print(json.dumps(failure), file=sys.stderr, flush=True)
        return 1


if __name__ == '__main__':
    sys.exit(main())
