#!/usr/bin/env python3
# Copyright 2026 TrillionniumFoundation; SPDX-License-Identifier: Apache-2.0
"""Run the preregistered R19 native, recovery and capacity campaigns once.

The Mac holder supplies these exact source bytes over one held-agent connection.
All inputs are rehashed before and after every stage. A performance rejection is
a valid completed experiment, not a reason to retry or omit recovery evidence.
This launcher never builds, installs, changes policy, or signals shared services.
"""
import argparse
import collections
import datetime
import errno
import hashlib
import json
import math
import os
from pathlib import Path
import re
import signal
import stat
import statistics
import subprocess
import sys
import time
import traceback

sys.dont_write_bytecode = True
R16 = Path('/home/qian/hepta-runtime-optimization-20261104-r16')
R18 = Path('/home/qian/hepta-runtime-optimization-20261104-r18')
R19 = Path('/home/qian/hepta-runtime-optimization-20261104-r19')
SOURCE = R19 / 'source'
TARGET = R19 / 'target-fresh-02'
PRIOR_TARGET = R19 / 'target-fresh-01'
TOOLS = R16 / 'measurement-tools'
BOUNDARY_TOOLS = R16 / 'boundary-tools'
CONTROL = R19 / 'campaign-control-01'
NATIVE_OUT = R19 / 'native-observation-01'
RECOVERY_OUT = R16 / 'r19-cancel-recovery-01'
BOUNDARY_OUT = R16 / 'r19-native-boundary-01'
NATIVE_SOCKET = Path('/home/qian/h19n1')
RECOVERY_SOCKET = Path('/home/qian/h19c1')
BOUNDARY_SOCKET = Path('/home/qian/h19b1')
PROFILE = Path('/home/qian/hepta-runtime-optimization-20261023/r11-native-observation-abba-20261103-02/profile/profile.json')
TOPOLOGY = R16 / 'benchmark-topology.json'
FROZEN_JOBS = Path('/home/qian/hepta-runtime-optimization-20261023/a31-frozen-originals-r01')
BASELINE = R18 / 'qualification-02/hepta-runtime'
CANDIDATE = R19 / 'qualification-02/hepta-runtime'
RESOLUTION = R19 / 'qualification-resolution-02.json'
QUALIFICATION_MANIFEST = R19 / 'tools/qualification-manifest-02.json'
PLAN = R19 / 'measurement-plan-01.json'
CAPACITY_PLAN = R19 / 'capacity-plan-01.json'
MONITOR = R19 / 'qualification-monitor-01.json'
PLAN_SHA = 'a4a32ca0996950e9130444d5a17d58202a779572ffb467fcdb4fce02ccc373cb'
CAPACITY_PLAN_SHA = '4c9dca0dc8de71b856aa02882533280f4fcbfea62dd612dbb915a6b52fce1faa'
MONITOR_SHA = '11a3b91300751c43d8f3ce9ef89613bd347a3e0f7d780834f82cdf3b6736b204'
QUALIFIER_PID = 2774555
QUALIFICATION_MANIFEST_SHA = 'b5193baae4169243b92c6ae1f26460a19f0098429fb331f4a48b1450536b726b'
QUALIFICATION_FILES = {
    'qualify_candidate_02.py': '1e69e4e39156ea878e14c2dd6237ff450f49def76873814ab5cb14bdba5e125f',
    'verify_qualification_02.py': 'c21607f53082021311a3639d888f7a51c0113df8d4d4014d1c95d69969aed00f',
    'run_qualification_02.py': '91625e1f5dcff0869f1d96b6162ce167a33b7d25022500b7ae6d10dd0a5ee4fe',
}
HISTORICAL_FILES = {
    'prequalification-01/report.json', 'independent-acceptance-01.json', 'tools/manifest.json',
    'qualification-01/report.json', 'source-freeze-01.json', 'qualification-launch-01.json', 'qualification-exit-01.json',
    *{'prequalification-01/' + name + '.' + stream
      for name in ('semantic-tests', 'component-abba', 'fresh-qualification', 'independent-qualification')
      for stream in ('stdout', 'stderr')},
}
REUSED_PINS = {
    'semantic-tests-x230-01.json': '61ec1b0307d6c9b5124e16bd94beeeedaa42d30ed1b5a5cea2a68b6f4ea2c853',
    'component-probe-01/protocol.json': '4e95302b4b1ec5e21b4bb5385976893b2b076799a4d8733d74e42801308e8af2',
    'component-probe-01/raw-cells.jsonl': '47a513ba2fe6a73ca8b5452171bde07c6d986088dfb004c91e4622f627ac1f31',
    'component-probe-01/summary.json': 'e144a0e80d6a68dbe73e835e7b007a149adf533f98b3ca31ebb5da85b64002d4',
    'cargo-empty-wrapper-probe-01/report.json': 'cae75b491c52271b72439018c68059657da72080999894ec15a57b313e71d824',
    'tools/cargo_empty_wrapper_probe.py': '36b257990e6c2b1a80047721d8f0de25af88d55982934b3c5772dfec44702422',
}
REUSED_FILES = set(REUSED_PINS)
ATTEMPT02_FILES = {
    'source-freeze-02.json', 'qualification-launch-02.json', 'qualification-exit-02.json',
    'qualification-02/report.json', 'qualification-02/source-map.json', 'independent-acceptance-02.json',
    'qualification-02.launcher.stdout', 'qualification-02.launcher.stderr', 'progress-02.json',
    *{'qualification-control-02/' + name + '.' + stream
      for name in ('fresh-qualification', 'independent-qualification') for stream in ('stdout', 'stderr')},
}
RESOLUTION_CHECKS = {
    'new_tools_exact_and_bound', 'attempt01_rejection_preserved', 'attempt01_stage_results_and_logs_bound',
    'same_reviewed_source_219_281', 'successful_semantic_evidence_reused', 'successful_component_evidence_reused',
    'empty_wrapper_causality_probe_passed', 'attempt02_paths_previously_absent',
    'attempt02_independent_qualification_passed', 'actual_release_binaries_and_strict_r18_jobctl_bound',
    'direct_qualifier_reaped_and_absent', 'protected_tools_evidence_and_sources_unchanged',
}
BINARY_DIAGNOSTIC_SHA = '40bd320eabddcb73f4fb4f450d3f6f388fa5f65894bff12b736087aa113083e2'
JOBS_SHA = 'c9080de8aa9a35f7495aa2822a1495d297903900ae0f0de26d7b0c86d043d3c9'
BASELINE_JOBS_SHA = '694a4e4dcbc2be499879abd837f0b5e399f9cad95caab34716907de15cbbe82f'
BASELINE_SHA = '51480b3cf630a95419d3afeb571eec17c90cffa5944101920d05333673de031d'
BASELINE_REPORT_SHA = 'e2d346eb47fce0812913cc6c830fcb945796f308c9340245b0b368b3fcc41367'
JOBCTL_SHA = '61c90260057a405626a24a36ad43303c632f72d2d97929296acdffd748b79d62'
JOBCTL_SOURCE_SHA = 'c22fdcd5bafad3a2123d5817c27fd73e7b5c26001bf1a8bdd6f8dbacabc8b562'
TOPOLOGY_SHA = '8c0767d3318131a7d470d9cde8e327a59ce18adf022c8bc1b1d5a0fa9a865287'
PROFILE_SHA = 'fe1e9551b5b8812ad6ed3da018c282b7261f7caeb2f49e4dcfefba7ff784ab08'
HOSTS = {'ai395', 'mac', 'main', 'pocket4', 'rog', 'x230'}
SCENARIOS = ['private_small', 'private_64k', 'terminal_small', 'terminal_64k', 'terminal_status', 'live_detached']
HEX = re.compile(r'[0-9a-f]{64}\Z')
QUIESCENCE_SECONDS = 90
PREQUAL_MANIFEST_SHA = '83ff759b13d380aa8a5e3e786b4ed68887fcce47b51d7f9e80583408e6b08a8a'
PREQUAL_FILES = {
    'python_read_probe.py': 'c6bd04ea22d4b368a3eed1cf17642b9418f6e2c0ebc2fc8fde26db92a42df0a8',
    'qualify_candidate.py': '5ac522870dd347fd12dcb723857957918666bddcf59e440f3a1cbe330e6704ba',
    'run_prequalification.py': '99057103d5b4b3149431ebf79c294088c531b24f17dd24baee5a85598b260fd6',
    'test_python_read_bounds.py': 'b2fcba8bf78e895f79cef2b6326b69a76c68f8f8b873b72833023cde8e1d5db1',
    'verify_qualification.py': '212b23cbdfdd24c952f6519db4b13d3036b642b8d6115f38db00306303dbb95f',
}
# This exact map was recovered from the accepted R18 recovery-control report,
# SHA256 9d9b35fe1b1f938f4675d0fdb423181e4edbc4beaaf3caaefb51136871fadcb7.
HARNESS_FILES = {
    'allocator_environment.py': 'f5c8e879c540b3f7cb1b7d3a7a0f5002c2f40c1a87963174b0b00470fa3a4525',
    'allocator_environment_audit.py': '4b082ce343ae3943e3098baa58af2f5def7198881b9c087d63d88360e9763727',
    'analyze_native_observation.py': 'cc7f6884d581cd1ced430437350e808de51931c50d12441797205501b20cae66',
    'audit_native_evidence.py': 'b69f6902d2de81eab41b21506f024c002d2f8264d60e86df6b1086623a77fd28',
    'observation_resources.py': 'f3402d51cb37b2fe20f4351b3a81ec5990a9fdaff93a846d21c07ccd557cb894',
    'owned_ssh_interruption.py': '1989c57f0b944afae1ed759d6529b8f1cc26197e269e2c34c4fd49e43a32aa7b',
    'run_native_observation.py': '7606648c99b2ff2bbf0bba58384e8cab609ac3899f838c0b80ba54d6288d20bb',
    'run_six_host_cancel_recovery.py': '698eb7801cde3f2bd5ff202412c0833fc218fd7e912c3c949d2b37fde7a56a12',
    'test_native_harness.py': '2b450175b9e6122248ac1bcb51860aa8a6d3eff55f6ac8c877c0a905e3dd7d00',
    'verify_cancel_recovery.py': '0116652a0b489dc462f005e01d7c943feda9ba784563d7317c92bb5beb9a701c',
    'x230_observation_benchmark.py': '4d96f0bf2da2562e788f48be7c37589ab3a513be5f9d8b2d741afe5c08ea9eed',
    'x230_six_running_recovery_canary.py': '6219bc556b0ac6d142bd4c731466b959e8a410f0b4b55f3d8b303f8fdbfbaaf4',
}
BOUNDARY_FILES = {
    'run_native_boundary.py': '2af83ebba8b7ea5550e7549da795556eb8328622bcfbf563019654e202a53329',
    'audit_native_boundary.py': '8ad8f6d97a5bd2e4850b02cd66fa5d2ac7d237ea0eef043daf9c88d3c9c152ee',
    'test_native_boundary.py': 'cda0bbef1704c374b49cc3cf5ea7b9a873687e547eed5c927bed801cf15156bd',
    'harness-freeze.json': '77ea90d5d2f45ed4d724f087353a3c8e603abcd0a8bd1d4bceb31179bef174b1',
    'capacity-policy.json': '206d1a99abc328948d8df893daa77a862b25de878a8b97379090da7ce84393d3',
}


def need(value, message):
    if not value:
        raise RuntimeError(message)


def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def stable_file(path, maximum=128 * 1024 * 1024, retain=False):
    """Full current-byte hash, bounded read, direct path and fd/path stamps."""
    path = Path(path)
    need(path.is_absolute() and path.resolve() == path, 'indirect evidence path: ' + str(path))
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK | os.O_CLOEXEC)
    chunks, count, hasher = [], 0, hashlib.sha256()
    try:
        before = os.fstat(fd)
        need(stat.S_ISREG(before.st_mode) and before.st_nlink == 1 and 0 <= before.st_size <= maximum,
             'unsafe or oversized evidence file: ' + str(path))
        while count <= maximum:
            raw = os.read(fd, min(1024 * 1024, maximum + 1 - count))
            if not raw:
                break
            count += len(raw)
            hasher.update(raw)
            if retain:
                chunks.append(raw)
        fields = ('st_dev', 'st_ino', 'st_uid', 'st_mode', 'st_nlink', 'st_size', 'st_mtime_ns', 'st_ctime_ns')
        stamp = lambda info: tuple(getattr(info, name) for name in fields)
        need(count == before.st_size and stamp(before) == stamp(os.fstat(fd)) == stamp(path.lstat()),
             'evidence changed while reading: ' + str(path))
    finally:
        os.close(fd)
    entry = {'path': str(path), 'bytes': count, 'sha256': hasher.hexdigest()}
    return entry, b''.join(chunks) if retain else None


def fingerprint(path, expected=None):
    entry, _ = stable_file(path)
    if expected is not None:
        need(entry['sha256'] == expected, 'evidence SHA256 differs: ' + str(path))
    return entry


def document(path, expected=None, maximum=64 * 1024 * 1024):
    entry, raw = stable_file(path, maximum=maximum, retain=True)
    if expected is not None:
        need(entry['sha256'] == expected, 'document SHA256 differs: ' + str(path))
    return json.loads(raw), entry


def safe_relative(name):
    path = Path(name)
    need(isinstance(name, str) and name not in ('', '.') and not path.is_absolute()
         and '..' not in path.parts and path.as_posix() == name, 'unsafe relative binding')
    return path


def current_inputs():
    paths = {SOURCE / name for name in ('Cargo.toml', 'Cargo.lock', 'rustfmt.toml')}
    for directory in ('src', 'examples'):
        for path in (SOURCE / directory).rglob('*'):
            mode = path.lstat().st_mode
            need(stat.S_ISREG(mode) or stat.S_ISDIR(mode), 'non-regular source entry: ' + str(path))
            if stat.S_ISREG(mode):
                paths.add(path)
    return {path.relative_to(SOURCE).as_posix(): fingerprint(path)['sha256'] for path in sorted(paths)}


def component_evidence():
    """Recompute only the preregistered traced-allocation decision from all cells."""
    directory = R19 / 'component-probe-01'
    protocol, protocol_binding = document(directory / 'protocol.json')
    summary, summary_binding = document(directory / 'summary.json')
    raw_binding, raw = stable_file(directory / 'raw-cells.jsonl', maximum=32 * 1024 * 1024, retain=True)
    rows = [json.loads(line) for line in raw.splitlines() if line.strip()]
    probe_binding = fingerprint(R19 / 'tools/python_read_probe.py')
    need(protocol['schema'] == 'hepta-python-read-component-protocol-v1'
         and protocol['script_sha256'] == probe_binding['sha256']
         and protocol['rounds'] == 4 and protocol['iterations'] == 256 and protocol['warmup'] == 16
         and protocol['scenarios'] == SCENARIOS and protocol['automatic_retries'] == 0,
         'component protocol differs from the registered plan')
    source_bindings = {'A': (R18 / 'source/src/mcp/runtime/jobs.rs', BASELINE_JOBS_SHA),
                       'B': (SOURCE / 'src/mcp/runtime/jobs.rs', JOBS_SHA)}
    for arm, (path, expected) in source_bindings.items():
        need(protocol['sources'][arm]['path'] == str(path)
             and protocol['sources'][arm]['source_sha256'] == expected, 'component source identity differs')
    expected_order = [(block, scene, position, arm) for block in range(4)
                      for scene in SCENARIOS for position, arm in enumerate('ABBA')]
    need([(row['block'], row['scenario'], row['position'], row['variant']) for row in rows] == expected_order,
         'component cell order or completeness differs')
    samples = collections.defaultdict(list)
    for row in rows:
        cell = row['cell']
        need(row['returncode'] == 0 and cell['all_actual_results_equal_expected'] is True
             and cell['source']['source_sha256'] == source_bindings[row['variant']][1]
             and cell['iterations'] == 256 and cell['warmup'] == 16 and cell['scenario'] == row['scenario'],
             'component cell failed or used another source')
        traced = cell['untimed_tracemalloc_samples']
        need(len(traced) == 3 and all(type(item['peak_bytes']) is int and item['peak_bytes'] > 0
             and 0 <= item['current_bytes'] <= item['peak_bytes'] for item in traced), 'invalid traced allocation samples')
        samples[(row['scenario'], row['variant'])].extend(item['peak_bytes'] for item in traced)
    need(summary['schema'] == 'hepta-python-read-component-abba-summary-v1'
         and summary['all_cells_passed'] is True and summary['cells'] == 96 and summary['rounds'] == 4
         and summary['protocol_sha256'] == protocol_binding['sha256']
         and summary['raw_cells_sha256'] == raw_binding['sha256'], 'component summary binding differs')
    checks = {}
    for scene in SCENARIOS:
        medians = {arm: statistics.median(samples[(scene, arm)]) for arm in 'AB'}
        need(all(len(samples[(scene, arm)]) == 24 and medians[arm]
             == summary['scenarios'][scene]['variants'][arm]['traced_peak_bytes_median'] for arm in 'AB'),
             'component allocation median differs from raw cells')
        if scene in ('private_small', 'terminal_small'):
            ratio = medians['B'] / medians['A']
            checks[scene] = {'a_traced_peak_median_bytes': medians['A'], 'b_traced_peak_median_bytes': medians['B'],
                             'b_over_a': ratio, 'required_reduction_fraction': 0.90, 'passed': ratio <= 0.10}
    return {'protocol': protocol_binding, 'summary': summary_binding, 'raw_cells': raw_binding, 'probe': probe_binding,
            'allocation_checks': checks, 'allocation_passed': all(item['passed'] for item in checks.values()),
            'scope': 'tracemalloc component allocation only; not RSS or multi-host throughput'}


def resolution_evidence(rows, required, label):
    need(bool(required) and isinstance(rows, dict) and set(rows) == required,
         'qualification resolution evidence set differs: ' + label)
    result = {}
    for relative, row in sorted(rows.items()):
        path = R19 / safe_relative(relative)
        need(row['path'] == str(path) and type(row['size']) is int and row['size'] >= 0
             and HEX.fullmatch(row['sha256']), 'invalid qualification resolution binding: ' + relative)
        binding = fingerprint(path, row['sha256'])
        need(binding['bytes'] == row['size'], 'qualification resolution evidence size differs: ' + relative)
        result[relative] = binding
    return result


def gate():
    plan, plan_binding = document(PLAN, PLAN_SHA)
    need(plan['schema'] == 'hepta-r19-measurement-plan/v1' and plan['candidate_jobs_sha256'] == JOBS_SHA
         and plan['baseline_runtime_sha256'] == BASELINE_SHA
         and plan['native'] == {'calls_per_cell': 192, 'concurrency': [1, 8, 16], 'malloc_arena_max': 1,
                               'order': 'ABBA', 'primary_concurrency': 8, 'warmup_calls_per_cell': 24, 'workers': 2},
         'registered native plan differs')
    capacity, capacity_binding = document(CAPACITY_PLAN, CAPACITY_PLAN_SHA)
    need(capacity['schema'] == 'hepta-r19-capacity-plan/v1' and capacity['parent_measurement_plan_sha256'] == PLAN_SHA
         and capacity['candidate_jobs_sha256'] == JOBS_SHA and capacity['tools'] == BOUNDARY_FILES
         and capacity['output'] == str(BOUNDARY_OUT) and capacity['socket_parent'] == str(BOUNDARY_SOCKET)
         and capacity['bursts'] == 2 and capacity['attempts_per_burst'] == 32 and capacity['workers'] == 2
         and capacity['malloc_arena_max'] == 1 and capacity['automatic_retries'] == 0
         and capacity['additional_worker_sweep'] is False, 'registered capacity plan differs')
    monitor, monitor_binding = document(MONITOR, MONITOR_SHA)
    need(monitor['qualifier_pid'] == QUALIFIER_PID and digest(monitor['snapshot_text'].encode()) == monitor['snapshot_sha256']
         and json.loads(monitor['snapshot_text'])['qualifier_pid'] == QUALIFIER_PID, 'qualification PID monitor binding differs')
    pre, pre_binding = document(R19 / 'prequalification-01/report.json',
                                '3d458a3809f8f1fc3e6b5f28c009d81bf6890a3022cf645eb20b96eb325ecef9')
    need(pre['schema'] == 'hepta-r19-prequalification/v1' and pre['passed'] is False
         and pre['candidate_jobs_sha256'] == JOBS_SHA and pre['baseline_jobs_sha256'] == BASELINE_JOBS_SHA
         and pre['automatic_retries'] == 0, 'original rejected prequalification identity differs')
    expected_stages = ['semantic-tests', 'component-abba', 'fresh-qualification', 'independent-qualification']
    need([row['name'] for row in pre['stages']] == expected_stages
         and [row['returncode'] for row in pre['stages']] == [0, 0, 0, 1]
         and all(type(row['returncode']) is int for row in pre['stages']),
         'original prequalification rejection differs')
    for row in pre['stages']:
        for stream in ('stdout', 'stderr'):
            path = R19 / 'prequalification-01' / (row['name'] + '.' + stream)
            need(row[stream]['path'] == str(path), 'prequalification log path differs')
            fingerprint(path, row[stream]['sha256'])
    tool_manifest, tool_binding = document(R19 / 'tools/manifest.json', PREQUAL_MANIFEST_SHA)
    need(tool_manifest == pre['tools'] == PREQUAL_FILES and len(tool_manifest) == 5, 'prequalification tools changed')
    for name, expected in tool_manifest.items():
        need(Path(name).name == name and HEX.fullmatch(expected), 'invalid prequalification tool binding')
        fingerprint(R19 / 'tools' / name, expected)
    rejected, rejected_binding = document(R19 / 'independent-acceptance-01.json',
                                          '591f7cf4e301887d15c0d34dc6f10f31786d3b4f6c6e51d44622edc11c62f3ed')
    need(rejected['schema'] == 'hepta-r19-independent-acceptance/v1' and rejected['accepted'] is False
         and rejected['checks'].get('jobctl_release_identical_to_r18') is False
         and rejected['error'] == 'ValueError: jobctl_release_identical_to_r18',
         'original independent rejection is no longer preserved')
    resolution, resolution_binding = document(RESOLUTION)
    need(resolution['schema'] == 'hepta-r19-qualification-resolution/v1' and resolution['passed'] is True
         and resolution['root'] == str(R19) and resolution['attempt'] == 2
         and resolution['baseline_jobs_sha256'] == BASELINE_JOBS_SHA
         and resolution['automatic_retries'] == 0 and resolution['candidate_jobs_sha256'] == JOBS_SHA
         and bool(RESOLUTION_CHECKS) and RESOLUTION_CHECKS <= set(resolution['checks'])
         and all(value is True for value in resolution['checks'].values()),
         'attempt02 qualification resolution did not pass completely')
    new_tools, new_tools_binding = document(QUALIFICATION_MANIFEST, QUALIFICATION_MANIFEST_SHA)
    need(new_tools == resolution['tools'] == QUALIFICATION_FILES and len(new_tools) == 3
         and resolution['tools_manifest'] == {'path': str(QUALIFICATION_MANIFEST),
                                             'size': new_tools_binding['bytes'], 'sha256': new_tools_binding['sha256']},
         'attempt02 qualification tool manifest differs')
    for name, expected in new_tools.items():
        need(Path(name).name == name and HEX.fullmatch(expected), 'invalid attempt02 qualification tool binding')
        fingerprint(R19 / 'tools' / name, expected)
    historical = resolution_evidence(resolution['historical_evidence'], HISTORICAL_FILES, 'historical attempt01')
    reused = resolution_evidence(resolution['reused_evidence'], REUSED_FILES, 'reused semantic/component')
    attempt02 = resolution_evidence(resolution['attempt02_evidence'], ATTEMPT02_FILES, 'attempt02')
    need(historical['prequalification-01/report.json'] == pre_binding
         and historical['independent-acceptance-01.json'] == rejected_binding,
         'resolution does not bind the original rejection')
    need(all(reused[relative]['sha256'] == expected for relative, expected in REUSED_PINS.items()),
         'reused semantic/component/causality evidence identity differs')
    binary_diagnostic = fingerprint(R19 / 'review-jobctl-binary-01.json', BINARY_DIAGNOSTIC_SHA)
    need([row['name'] for row in resolution['stages']] == ['fresh-qualification', 'independent-qualification']
         and all(type(row['returncode']) is int and row['returncode'] == 0 for row in resolution['stages']),
         'attempt02 qualification stages incomplete')
    for row in resolution['stages']:
        for stream in ('stdout', 'stderr'):
            recorded = row[stream]
            path = Path(recorded['path'])
            need(path.is_relative_to(R19) and path.relative_to(R19).as_posix() in attempt02,
                 'attempt02 qualification log is not frozen')
            actual = fingerprint(path, recorded['sha256'])
            need(actual == attempt02[path.relative_to(R19).as_posix()] and actual['bytes'] == recorded['bytes'],
                 'attempt02 qualification log differs')
    verification, verification_binding = document(R19 / 'independent-acceptance-02.json')
    required_checks = {'all_219_source_bindings_match', 'only_expected_jobs_rs_changed',
                       'all_root_artifacts_and_five_tests_fresh_false', 'all_raw_logs_inventories_and_exact_test_verdicts_match',
                       'jobctl_release_identical_to_r18', 'all_sources_and_evidence_stable_during_verification',
                       'attempt02_environment_and_qualifier_reaped'}
    need(verification['schema'] == 'hepta-r19-independent-acceptance/v1' and verification['root'] == str(R19)
         and verification['accepted'] is True and verification['attempt'] == 2
         and required_checks <= set(verification['checks']) and all(value is True for value in verification['checks'].values())
         and verification['source_input_count'] == 219 and verification['source_full_count'] == 281
         and verification['changed_paths'] == ['src/mcp/runtime/jobs.rs'], 'independent acceptance did not pass completely')
    qualification, qualification_binding = document(R19 / 'qualification-02/report.json', verification['qualified_report_sha256'])
    freeze, freeze_binding = document(R19 / 'source-freeze-02.json', verification['source_freeze_sha256'])
    launch, launch_binding = document(R19 / 'qualification-launch-02.json')
    outcome, outcome_binding = document(R19 / 'qualification-exit-02.json')
    need(qualification['qualified'] is True and qualification['source'] == str(SOURCE)
         and qualification['automatic_test_retries'] == 0 and qualification['service_changes'] is False
         and freeze['schema'] == 'hepta-r19-source-freeze/v1' and freeze['source'] == str(SOURCE)
         and freeze['baseline_source'] == str(R18 / 'source') and freeze['expected_jobs_sha256'] == JOBS_SHA
         and freeze['attempt'] == launch['attempt'] == outcome['attempt'] == 2
         and launch['source_freeze_sha256'] == freeze_binding['sha256']
         and launch['environment_policy'] == 'explicit-allowlist/v2-no-wrapper-keys'
         and not any('WRAPPER' in key for key in launch['environment'])
         and launch['launcher_sha256'] == QUALIFICATION_FILES['qualify_candidate_02.py']
         and outcome['success'] is True and outcome['returncode'] == 0 and outcome['automatic_retries'] == 0
         and outcome['report_sha256'] == qualification_binding['sha256'], 'qualification/freeze/exit identities differ')
    qualifier_process = resolution['qualifier_process']
    need(type(qualifier_process['pid']) is int and qualifier_process['pid'] > 1
         and type(qualifier_process['start_ticks']) is int and qualifier_process['start_ticks'] > 0
         and qualifier_process['pid'] == launch['qualifier_pid'] == outcome['qualifier_pid']
         and qualifier_process['start_ticks'] == launch['qualifier_start_ticks'] == outcome['qualifier_start_ticks']
         and qualifier_process['reaped'] is outcome['qualifier_reaped'] is True
         and qualifier_process['returncode'] == outcome['qualifier_returncode'] == 0
         and qualifier_process['proc_absent'] is outcome['qualifier_proc_absent'] is True,
         'attempt02 qualifier process identity or reap receipt differs')
    inputs = freeze['source_inputs_before']
    source_map, source_map_binding = document(R19 / 'qualification-02/source-map.json')
    need(isinstance(inputs, dict) and len(inputs) == 219
         and all(HEX.fullmatch(value) for value in inputs.values())
         and inputs == source_map == qualification['source_input'] == qualification['source_tested'] == qualification['source_after']
         and inputs == resolution['source_inputs']
         and resolution['source_input_count'] == 219 and resolution['source_full_count'] == 281,
         'qualified compiler input maps differ')
    for name in inputs:
        safe_relative(name)
    need(current_inputs() == inputs and inputs['src/mcp/runtime/jobs.rs'] == JOBS_SHA
         and inputs['src/bin/jobctl.rs'] == JOBCTL_SOURCE_SHA, 'current 219 compiler inputs changed')
    baseline_report, baseline_report_binding = document(R18 / 'qualification-02/report.json', BASELINE_REPORT_SHA)
    old = baseline_report['source_tested']
    need(baseline_report['qualified'] is True and old == baseline_report['source_after']
         and set(old) == set(inputs) and old['src/mcp/runtime/jobs.rs'] == BASELINE_JOBS_SHA
         and {name for name in inputs if inputs[name] != old[name]} == {'src/mcp/runtime/jobs.rs'},
         'candidate is no longer the one-file R18 change')
    binaries = {}
    names = {'hepta-runtime', 'hepta-runtime-jobctl', 'native_process_driver'}
    need(set(qualification['binaries']) == set(verification['binaries']) == names, 'candidate release set differs')
    for name in sorted(names):
        path = R19 / 'qualification-02' / name
        selected, independent = qualification['binaries'][name], verification['binaries'][name]
        need(selected['path'] == independent['path'] == str(path) and selected['sha256'] == independent['sha256'],
             'candidate binary receipt differs: ' + name)
        actual = fingerprint(path, selected['sha256'])
        need(actual['bytes'] == independent['size'], 'candidate binary size differs: ' + name)
        binaries[name] = actual
    need(binaries['hepta-runtime-jobctl']['sha256'] == JOBCTL_SHA
         and resolution['binaries'] == verification['binaries'], 'R18 jobctl binary or resolution release set changed')
    baseline_binding = fingerprint(BASELINE, BASELINE_SHA)
    topology_binding, profile_binding = fingerprint(TOPOLOGY, TOPOLOGY_SHA), fingerprint(PROFILE, PROFILE_SHA)
    validation, validation_binding = document(TOOLS / 'harness-validation-02.json')
    need(validation['success'] is True and validation['files'] == HARNESS_FILES, 'historical 12-file harness manifest changed')
    for name, expected in HARNESS_FILES.items():
        fingerprint(TOOLS / name, expected)
    for name, expected in BOUNDARY_FILES.items():
        fingerprint(BOUNDARY_TOOLS / name, expected)
    boundary_freeze, _ = document(BOUNDARY_TOOLS / 'harness-freeze.json')
    need(boundary_freeze['files'] == HARNESS_FILES, 'boundary tool binds another measurement harness')
    frozen_jobs, members = {}, set()
    for path in sorted(FROZEN_JOBS.glob('*.json')):
        original, binding = document(path, maximum=65536)
        need(path.name == original['id'] + '.json' and original['host'] in HOSTS
             and original['launch_state'] == 'launched' and original['execution_mode'] == 'operator'
             and original['system_jobctl'] is False, 'historical frozen job identity differs')
        members.add(original['host'])
        frozen_jobs[path.name] = binding
    need(len(frozen_jobs) == 6 and members == HOSTS, 'historical six-job set differs')
    return {'measurement_plan': plan_binding, 'capacity_plan': capacity_binding, 'historical_qualification_monitor': monitor_binding,
            'qualification_attempt': 2, 'qualification_resolution': resolution_binding,
            'historical_prequalification': pre_binding, 'historical_independent_rejection': rejected_binding,
            'prequalification_tool_manifest': tool_binding, 'qualification_tool_manifest': new_tools_binding,
            'historical_evidence': historical, 'reused_evidence': reused, 'attempt02_evidence': attempt02,
            'binary_difference_diagnostic': binary_diagnostic,
            'qualifier_process': qualifier_process,
            'independent_acceptance': verification_binding, 'qualification': qualification_binding,
            'source_freeze': freeze_binding, 'qualification_launch': launch_binding, 'qualification_exit': outcome_binding,
            'source_map': source_map_binding, 'source_inputs': inputs, 'binaries': binaries,
            'baseline': baseline_binding, 'baseline_qualification': baseline_report_binding,
            'topology': topology_binding, 'profile': profile_binding, 'harness_validation': validation_binding,
            'measurement_scripts': HARNESS_FILES, 'boundary_files': BOUNDARY_FILES, 'frozen_jobs': frozen_jobs,
            'component': component_evidence(), 'workers': 2, 'arena_max': 1}


def snapshot():
    paths = [Path('/proc/loadavg'), Path('/proc/meminfo'), Path('/proc/stat')]
    for pattern in ('cpu[0-9]*/cpufreq/scaling_governor', 'cpu[0-9]*/cpufreq/scaling_cur_freq',
                    'cpu[0-9]*/cpufreq/scaling_min_freq', 'cpu[0-9]*/cpufreq/scaling_max_freq'):
        paths.extend(sorted(Path('/sys/devices/system/cpu').glob(pattern)))
    paths.extend(sorted(Path('/sys/class/thermal').glob('thermal_zone*/temp')))
    paths.extend(sorted(Path('/sys/class/hwmon').glob('hwmon*/temp*_input')))
    values = {}
    for path in paths:
        try:
            values[str(path)] = path.read_text()
        except OSError as error:
            values[str(path)] = {'error': type(error).__name__, 'errno': error.errno}
    return {'utc': utc(), 'monotonic_ns': time.monotonic_ns(), 'values': values,
            'scope': 'read-only diagnostics; no governor or machine settings changed'}


def proc_bytes(path, maximum=4 * 1024 * 1024):
    with path.open('rb') as stream:
        raw = stream.read(maximum + 1)
    need(len(raw) <= maximum, 'process metadata exceeds diagnostic bound')
    return raw


def compilation_idle(qualifier_pid):
    """Read only: both qualification PIDs and either R19 target's compilers."""
    recorded = []
    for pid in (qualifier_pid, QUALIFIER_PID):
        qualifier = Path('/proc') / str(pid)
        try:
            raw = proc_bytes(qualifier / 'stat', 65536).decode()
            tail = raw.rsplit(') ', 1)[1].split()
            recorded.append({'pid': pid, 'present': True, 'state': tail[0], 'start_ticks': int(tail[19])})
        except FileNotFoundError:
            recorded.append({'pid': pid, 'present': False})
    matches, errors, checked = [], [], 0
    qualifier_path = str(SOURCE / 'tools/x230/20261028/qualify.py').encode()
    for directory in Path('/proc').iterdir():
        if not directory.name.isdecimal():
            continue
        try:
            if directory.stat().st_uid != os.geteuid():
                continue
            comm = (directory / 'comm').read_text().strip()
            if comm not in ('cargo', 'rustc') and not comm.startswith('python'):
                continue
            argv = proc_bytes(directory / 'cmdline').split(b'\0')
            checked += 1
            if qualifier_path in argv:
                matches.append({'pid': int(directory.name), 'comm': comm, 'kind': 'exact_qualifier_argv'})
            if comm in ('cargo', 'rustc'):
                cwd = os.readlink(directory / 'cwd')
                targets = (os.fsencode(TARGET), os.fsencode(PRIOR_TARGET))
                target_match = cwd == str(SOURCE) or any(item == target or target + b'/' in item
                                                       for item in argv for target in targets)
                if target_match:
                    matches.append({'pid': int(directory.name), 'comm': comm, 'kind': 'r19_target_compiler',
                                    'cwd': cwd, 'argv_sha256': digest(b'\0'.join(argv))})
        except OSError as error:
            if error.errno not in (errno.ENOENT, errno.ESRCH):
                errors.append({'pid': int(directory.name), 'type': type(error).__name__, 'errno': error.errno})
    return {'recorded_qualifiers': recorded, 'matching_processes': matches, 'scan_errors': errors,
            'owned_python_or_compiler_processes_checked': checked,
            'idle': all(not row['present'] for row in recorded) and not matches and not errors,
            'signals_sent': 0, 'environment_read': False, 'full_environment_or_argv_retained': False}


def write_new(path, raw):
    with path.open('xb') as stream:
        stream.write(raw)
        stream.flush()
        os.fsync(stream.fileno())


def atomic_json(path, value):
    temporary = path.with_suffix('.next')
    write_new(temporary, (json.dumps(value, indent=2) + '\n').encode())
    os.replace(temporary, path)


def finite_positive(value):
    return type(value) in (int, float) and math.isfinite(value) and value > 0


def native_decision(analysis):
    need([item['concurrency'] for item in analysis['cases']] == [1, 8, 16], 'native analysis concurrency differs')
    cases = []
    for item in analysis['cases']:
        left, right = item['arms']['A'], item['arms']['B']
        need(all(finite_positive(arm[key]) for arm in (left, right) for key in ('calls_per_second', 'p95_ms')),
             'invalid aggregate native statistic')
        rate, tail = right['calls_per_second'] / left['calls_per_second'], right['p95_ms'] / left['p95_ms']
        cases.append({'concurrency': item['concurrency'], 'throughput_b_over_a': rate, 'p95_b_over_a': tail,
                      'required_throughput_ratio_min': 0.95, 'required_p95_ratio_max': 1.10,
                      'throughput_passed': rate >= 0.95, 'p95_passed': tail <= 1.10,
                      'passed': rate >= 0.95 and tail <= 1.10})
    return {'cases': cases, 'passed': all(item['passed'] for item in cases),
            'scope': 'preregistered finite-run aggregate regression screen; not a confidence interval'}


def stop_owned_stage(child, row):
    if child is None or child.poll() is not None:
        return
    row['owned_stage_interrupt'] = {'pid': child.pid, 'first_signal': 'SIGINT', 'process_groups_signalled': False}
    child.send_signal(signal.SIGINT)  # Allows the frozen harness's own finally cleanup.
    try:
        child.wait(timeout=30)
    except subprocess.TimeoutExpired:
        row['owned_stage_interrupt']['forced_direct_child_kill'] = True
        child.kill()  # Exact Popen child only; no process search or shared-service signal.
        child.wait(timeout=10)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--launcher-sha256', required=True)
    args = parser.parse_args()
    need(HEX.fullmatch(args.launcher_sha256), 'Mac source-byte receipt required')
    need(sys.platform == 'linux' and os.geteuid() == 1000, 'wrong execution host/account')
    need(CONTROL.resolve() == CONTROL and not os.path.lexists(CONTROL), 'fresh direct control output required')
    CONTROL.mkdir(mode=0o700)
    report = {'schema': 'hepta-x230-r19-six-host-campaign/v1', 'qualification_attempt': 2,
              'started_utc': utc(), 'passed': False,
              'current_stage': 'initial-gate', 'remote_launcher_sha256_reported_by_mac': args.launcher_sha256,
              'launcher_identity_scope': 'Mac holder receipt for stdin source, not an independent remote source hash',
              'automatic_campaign_retries': 0, 'automatic_stage_retries': 0, 'automatic_rpc_retries': 0,
              'production_service_changes': False, 'builds_started': 0, 'governor_changes': False,
              'stages': [], 'adoption_screen_passed': None}
    initial = None

    def save():
        atomic_json(CONTROL / 'report.json', report)
        atomic_json(CONTROL / 'progress.json', {'schema': 'hepta-r19-campaign-progress/v1', 'updated_utc': utc(),
                    'current_stage': report['current_stage'], 'passed': report['passed'],
                    'stage_count': len(report['stages']), 'stage_pid': report.get('stage_pid'),
                    'quiescence_elapsed_seconds': report.get('quiescence', {}).get('elapsed_seconds'),
                    'adoption_screen_passed': report['adoption_screen_passed'], 'error': report.get('error')})

    def unchanged():
        current = gate()
        need(current == initial, 'accepted inputs changed during campaign')

    def stage(name, command, timeout, artifacts):
        report['current_stage'] = name + ':pre-gate'
        save()
        unchanged()
        row = {'name': name, 'argv': command, 'cwd': str(Path(command[2]).parent),
               'script_sha256': fingerprint(command[2])['sha256'], 'timeout_seconds': timeout,
               'start_monotonic_ns': time.monotonic_ns(), 'before': snapshot(),
               'pre_gate_passed': True, 'post_gate_passed': False, 'returncode': None, 'automatic_retry': False}
        report['stages'].append(row)
        report['current_stage'] = name
        save()
        print(json.dumps({'stage': name, 'state': 'started'}), flush=True)
        child, failure = None, None
        try:
            with (CONTROL / (name + '.stdout')).open('xb') as stdout, (CONTROL / (name + '.stderr')).open('xb') as stderr:
                child = subprocess.Popen(command, cwd=Path(command[2]).parent, stdin=subprocess.DEVNULL, stdout=stdout, stderr=stderr)
                row['pid'] = child.pid
                report['stage_pid'] = child.pid
                save()
                row['returncode'] = child.wait(timeout=timeout)
            need(row['returncode'] == 0, name + ' failed; no stage retry')
            need(all(path.is_file() for path in artifacts), name + ' did not leave all required artifacts')
        except BaseException as error:
            failure = error
            row['error'] = {'type': type(error).__name__, 'reason': str(error)}
            row['timed_out'] = isinstance(error, subprocess.TimeoutExpired)
            try:
                stop_owned_stage(child, row)
            except BaseException as cleanup_error:
                row['owned_stage_cleanup_error'] = {'type': type(cleanup_error).__name__, 'reason': str(cleanup_error)}
            if child is not None:
                row['returncode'] = child.poll()
            write_new(CONTROL / (name + '.error.txt'), traceback.format_exc().encode())
        finally:
            row['end_monotonic_ns'] = time.monotonic_ns()
            row['seconds'] = (row['end_monotonic_ns'] - row['start_monotonic_ns']) / 1e9
            row['after'] = snapshot()
            row['logs'], row['artifacts'] = [], []
            retained = [('logs', CONTROL / (name + '.' + suffix)) for suffix in ('stdout', 'stderr', 'error.txt')]
            retained.extend(('artifacts', path) for path in artifacts)
            for group, path in retained:
                if not path.is_file():
                    continue
                try:
                    row[group].append(fingerprint(path))
                except BaseException as error:
                    row[group].append({'path': str(path), 'error': {'type': type(error).__name__, 'reason': str(error)}})
                    failure = failure or error
            report['current_stage'] = name + ':post-gate'
            try:
                unchanged()
                row['post_gate_passed'] = True
            except BaseException as error:
                row['post_gate_error'] = {'type': type(error).__name__, 'reason': str(error)}
                failure = failure or error
            report['stage_pid'] = None
            save()
        print(json.dumps({'stage': name, 'returncode': row['returncode'], 'post_gate_passed': row['post_gate_passed'],
                          'seconds': row['seconds']}), flush=True)
        if failure is not None:
            raise failure

    try:
        save()
        for path in (NATIVE_OUT, RECOVERY_OUT, BOUNDARY_OUT, NATIVE_SOCKET, RECOVERY_SOCKET, BOUNDARY_SOCKET):
            need(path.resolve() == path and not os.path.lexists(path), 'fresh output/socket path required: ' + str(path))
        initial = gate()
        report['gate'] = initial
        for path in (PLAN, CAPACITY_PLAN, MONITOR, RESOLUTION, QUALIFICATION_MANIFEST):
            _, raw = stable_file(path, maximum=1024 * 1024, retain=True)
            write_new(CONTROL / path.name, raw)
        report['current_stage'] = 'pre-measurement-quiescence'
        qualifier_pid = initial['qualifier_process']['pid']
        cooling = {'seconds_required': QUIESCENCE_SECONDS, 'before': snapshot(), 'idle_before': compilation_idle(qualifier_pid),
                   'start_monotonic_ns': time.monotonic_ns(), 'elapsed_seconds': 0.0,
                   'settings_changed': False, 'signals_sent': 0}
        report['quiescence'] = cooling
        save()
        need(cooling['idle_before']['idle'], 'R19 qualifier/target compiler still active or process scan incomplete')
        deadline = time.monotonic() + QUIESCENCE_SECONDS
        last_notice = -1
        while True:
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                break
            time.sleep(min(1.0, remaining))
            cooling['elapsed_seconds'] = (time.monotonic_ns() - cooling['start_monotonic_ns']) / 1e9
            interval = int(cooling['elapsed_seconds']) // 15
            if interval != last_notice:
                last_notice = interval
                save()
                print(json.dumps({'stage': 'pre-measurement-quiescence', 'elapsed_seconds': cooling['elapsed_seconds']}), flush=True)
        cooling['end_monotonic_ns'] = time.monotonic_ns()
        cooling['elapsed_seconds'] = (cooling['end_monotonic_ns'] - cooling['start_monotonic_ns']) / 1e9
        cooling['after'], cooling['idle_after'] = snapshot(), compilation_idle(qualifier_pid)
        need(cooling['elapsed_seconds'] >= QUIESCENCE_SECONDS and cooling['idle_after']['idle'],
             'quiescence incomplete or R19 target compiler became active')
        cooling['passed'] = True
        save()
        unchanged()
        shared = ['--profile-template', str(PROFILE), '--topology', str(TOPOLOGY), '--frozen-jobs', str(FROZEN_JOBS)]
        NATIVE_SOCKET.mkdir(mode=0o700)
        stage('native-observation', ['/usr/bin/python3', '-B', str(TOOLS / 'run_native_observation.py'),
              '--baseline', str(BASELINE), '--candidate', str(CANDIDATE), '--arena-max', '1', *shared,
              '--socket-parent', str(NATIVE_SOCKET), '--out', str(NATIVE_OUT), '--calls', '192',
              '--concurrency', '1', '8', '16', '--workers', '2', '--order', 'ABBA', '--warmup-calls', '24'],
              1800, [NATIVE_OUT / 'report.json'])
        stage('native-independent-audit', ['/usr/bin/python3', '-B', str(TOOLS / 'analyze_native_observation.py'),
              '--report', str(NATIVE_OUT / 'report.json'), '--output', str(NATIVE_OUT / 'independent-summary.json')],
              180, [NATIVE_OUT / 'independent-summary.json'])
        native, native_binding = document(NATIVE_OUT / 'report.json')
        analysis, analysis_binding = document(NATIVE_OUT / 'independent-summary.json')
        runtime_sha = initial['binaries']['hepta-runtime']['sha256']
        need(native['passed'] is True and native['binary_sha256'] == {'A': BASELINE_SHA, 'B': runtime_sha}
             and native['tokio_workers'] == 2 and native['calls_per_cell'] == 192
             and native['concurrency'] == [1, 8, 16] and native['order'] == 'ABBA'
             and native['r16_measurement']['balanced_warmup_calls_per_cell'] == 24
             and analysis['verified'] is True and analysis['original_sha256'] == native_binding['sha256']
             and analysis['binary_sha256'] == native['binary_sha256'] and analysis['failed_calls'] == 0
             and analysis['measured_calls'] == 2304 and analysis['warmup_calls'] == 288
             and analysis['preflight_restart_calls'] == 72 and analysis['total_calls'] == 2664,
             'native report or independent analysis differs from the fixed plan')
        report['native_regression_screen'] = native_decision(analysis)
        report['native_evidence'] = {'report': native_binding, 'independent_analysis': analysis_binding}
        save()  # Keep running the planned correctness stages even if this screen rejects performance.
        RECOVERY_SOCKET.mkdir(mode=0o700)
        stage('cancel-recovery', ['/usr/bin/python3', '-B', str(TOOLS / 'run_six_host_cancel_recovery.py'),
              '--candidate', str(CANDIDATE), '--candidate-arena-max', '1', *shared,
              '--socket-parent', str(RECOVERY_SOCKET), '--out', str(RECOVERY_OUT), '--workers', '2', '--interrupt-host', 'rog'],
              600, [RECOVERY_OUT / 'report.json'])
        stage('recovery-independent-audit', ['/usr/bin/python3', '-B', str(TOOLS / 'verify_cancel_recovery.py'),
              '--report', str(RECOVERY_OUT / 'report.json'), '--output', str(RECOVERY_OUT / 'independent-summary.json')],
              180, [RECOVERY_OUT / 'independent-summary.json'])
        recovery, recovery_binding = document(RECOVERY_OUT / 'independent-summary.json')
        recovery_raw = fingerprint(RECOVERY_OUT / 'report.json')
        need(recovery['verified'] is True and recovery['candidate_sha256'] == runtime_sha
             and recovery['source_sha256'] == recovery_raw['sha256'], 'recovery independent verdict or identity differs')
        report['recovery_evidence'] = {'report': recovery_raw, 'independent_analysis': recovery_binding}
        BOUNDARY_SOCKET.mkdir(mode=0o700)
        stage('native-boundary', ['/usr/bin/python3', '-B', str(BOUNDARY_TOOLS / 'run_native_boundary.py'),
              '--binary', str(CANDIDATE), *shared, '--socket-parent', str(BOUNDARY_SOCKET),
              '--out', str(BOUNDARY_OUT), '--bursts', '2'], 600, [BOUNDARY_OUT / 'report.json'])
        stage('boundary-independent-audit', ['/usr/bin/python3', '-B', str(BOUNDARY_TOOLS / 'audit_native_boundary.py'),
              '--report', str(BOUNDARY_OUT / 'report.json'), '--output', str(BOUNDARY_OUT / 'independent-summary.json')],
              180, [BOUNDARY_OUT / 'independent-summary.json'])
        boundary, boundary_binding = document(BOUNDARY_OUT / 'independent-summary.json')
        boundary_raw, boundary_raw_binding = document(BOUNDARY_OUT / 'report.json')
        need(boundary['evidence_verified'] is True and boundary['diagnostic_passed'] is True
             and boundary['candidate_sha256'] == runtime_sha and boundary['report_sha256'] == boundary_raw_binding['sha256']
             and boundary['drain_and_recovery_passed'] is True and len(boundary['bursts']) == 2
             and boundary_raw['attempts_per_burst'] == 32 and boundary_raw['tokio_workers'] == 2 and boundary_raw['arena_max'] == 1
             and set(boundary['counts']) <= {'success', 'capacity_rejection', 'other_error'}
             and boundary['counts'].get('other_error', 0) == 0
             and sum(boundary['counts'].values()) == 64
             and boundary['classification_policy_sha256'] == BOUNDARY_FILES['capacity-policy.json'],
             'capacity classification, drain, restart or independent identity differs')
        report['capacity_evidence'] = {'report': boundary_raw_binding, 'independent_analysis': boundary_binding,
                                      'counts': boundary['counts'], 'fixed_rejection_count_required': False,
                                      'capacity_rejections_count_as_successful_throughput': False}
        unchanged()
        report['adoption_checks'] = {'component_allocation_passed': initial['component']['allocation_passed'],
                                    'native_regression_screen_passed': report['native_regression_screen']['passed'],
                                    'all_correctness_gates_passed': True}
        report['adoption_screen_passed'] = all(report['adoption_checks'].values())
        report['passed'] = True
        report['current_stage'] = 'completed'
    except BaseException as error:
        report['error'] = {'type': type(error).__name__, 'reason': str(error)}
        write_new(CONTROL / 'campaign.error.txt', traceback.format_exc().encode())
        report['current_stage'] = 'failed'
    finally:
        report['finished_utc'] = utc()
        save()
        print(json.dumps({'passed': report['passed'], 'adoption_screen_passed': report['adoption_screen_passed'],
                          'error': report.get('error'), 'report': str(CONTROL / 'report.json'),
                          'progress': str(CONTROL / 'progress.json')}), flush=True)
    # A measured performance rejection is not an execution failure or a retry trigger.
    return 0 if report['passed'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
