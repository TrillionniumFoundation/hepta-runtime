import collections, datetime, hashlib, json, os, re, shutil, stat, struct, subprocess, time
from pathlib import Path

ROOT = Path('/home/qian/hepta-runtime-optimization-20261104-r19')
OUT = ROOT / 'review-jobctl-binary-01.json'
PATHS = {
    'R18': Path('/home/qian/hepta-runtime-optimization-20261104-r18/qualification-02/hepta-runtime-jobctl'),
    'R19': ROOT / 'qualification-01/hepta-runtime-jobctl',
}
EXPECTED = {
    'R18': '61c90260057a405626a24a36ad43303c632f72d2d97929296acdffd748b79d62',
    'R19': '43a40254d5812a81d9824e30ad75c0eca6cf9ddab04e03a1afb48de102797510',
}
def sha(raw):
    return hashlib.sha256(raw).hexdigest()
def need(ok, message):
    if not ok:
        raise RuntimeError(message)
def stamp(info):
    return tuple(getattr(info, key) for key in ('st_dev','st_ino','st_uid','st_mode','st_nlink','st_size','st_mtime_ns','st_ctime_ns'))
def stable_bytes(path):
    need(path.resolve() == path, 'binary path is indirect')
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_CLOEXEC | os.O_NONBLOCK)
    try:
        before = os.fstat(fd)
        need(stat.S_ISREG(before.st_mode) and 0 < before.st_size <= 16 * 1024 * 1024, 'unexpected binary inode/size')
        chunks, count = [], 0
        while count <= 16 * 1024 * 1024:
            chunk = os.read(fd, min(1024 * 1024, 16 * 1024 * 1024 + 1 - count))
            if not chunk:
                break
            chunks.append(chunk); count += len(chunk)
        data = b''.join(chunks)
        need(len(data) == before.st_size and stamp(before) == stamp(os.fstat(fd)) == stamp(path.lstat()), 'binary changed while reading')
        return data, {'path':str(path),'bytes':len(data),'sha256':sha(data),'mode':oct(stat.S_IMODE(before.st_mode)),
                      'uid':before.st_uid,'nlink':before.st_nlink,'mtime_ns':before.st_mtime_ns,'ctime_ns':before.st_ctime_ns}
    finally:
        os.close(fd)
def run_tool(argv):
    executable = shutil.which(argv[0])
    if executable is None:
        return {'available':False,'argv':argv}, b''
    started=time.monotonic()
    result=subprocess.run([executable,*argv[1:]],stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.PIPE,
                          timeout=30,env={'PATH':'/usr/bin:/bin','LANG':'C','LC_ALL':'C'})
    need(len(result.stdout) <= 16*1024*1024 and len(result.stderr) <= 1024*1024,'diagnostic output exceeded bound')
    return {'available':True,'argv':[executable,*argv[1:]],'returncode':result.returncode,
            'seconds':time.monotonic()-started,'stdout_bytes':len(result.stdout),'stdout_sha256':sha(result.stdout),
            'stderr_bytes':len(result.stderr),'stderr_sha256':sha(result.stderr)}, result.stdout
def cstring(data, offset):
    end=data.find(b'\0',offset)
    need(0<=offset<len(data) and end>=offset,'invalid ELF string')
    return data[offset:end].decode('ascii','backslashreplace')
def elf(data):
    need(data[:4]==b'\x7fELF' and data[4]==2 and data[5]==1,'expected ELF64 little endian')
    head=struct.unpack_from('<16sHHIQQQIHHHHHH',data)
    _,typ,machine,version,entry,phoff,shoff,flags,ehsize,phentsize,phnum,shentsize,shnum,shstrndx=head
    need(machine==62 and phentsize>=56 and shentsize>=64 and 0<shnum<1000 and shstrndx<shnum,'unexpected ELF layout')
    need(shoff+shnum*shentsize<=len(data) and phoff+phnum*phentsize<=len(data),'truncated ELF tables')
    sections=[]
    for i in range(shnum):
        name,stype,sflags,addr,offset,size,link,info,align,entsize=struct.unpack_from('<IIQQQQIIQQ',data,shoff+i*shentsize)
        sections.append({'index':i,'name_offset':name,'type':stype,'flags':sflags,'address':addr,'offset':offset,
                         'size':size,'link':link,'info':info,'alignment':align,'entry_size':entsize})
    strings=sections[shstrndx]
    names=data[strings['offset']:strings['offset']+strings['size']]
    for section in sections:
        section['name']=cstring(names,section.pop('name_offset'))
        need(section['type']==8 or section['offset']+section['size']<=len(data),'section outside binary')
        section['sha256']=None if section['type']==8 else sha(data[section['offset']:section['offset']+section['size']])
    segments=[]
    for i in range(phnum):
        ptype,pflags,offset,vaddr,paddr,filesz,memsz,align=struct.unpack_from('<IIQQQQQQ',data,phoff+i*phentsize)
        need(offset+filesz<=len(data),'segment outside binary')
        segments.append({'index':i,'type':ptype,'flags':pflags,'offset':offset,'virtual_address':vaddr,
                         'physical_address':paddr,'file_size':filesz,'memory_size':memsz,'alignment':align,
                         'sha256':sha(data[offset:offset+filesz])})
    buildids=[]
    for section in sections:
        if section['type']!=7:
            continue
        raw=data[section['offset']:section['offset']+section['size']]
        at=0
        while at+12<=len(raw):
            namesz,descsz,ntype=struct.unpack_from('<III',raw,at); at+=12
            n=raw[at:at+namesz]; at=(at+namesz+3)&~3
            d=raw[at:at+descsz]; at=(at+descsz+3)&~3
            if n.rstrip(b'\0')==b'GNU' and ntype==3:
                buildids.append({'section':section['name'],'gnu_build_id':d.hex()})
    comments=[]
    for section in sections:
        if section['name']=='.comment':
            for value in data[section['offset']:section['offset']+section['size']].split(b'\0'):
                if not value:
                    continue
                record={'bytes':len(value),'sha256':sha(value)}
                # Only compiler-version metadata may be written as raw text.
                if len(value)<=256 and re.fullmatch(rb'(?:rustc version|GCC:|clang version|Linker:)[ -~]+',value) and not re.search(rb'(?i)password|credential|secret|api[_-]?key|access[_-]?token',value):
                    record['compiler_version_text']=value.decode('ascii')
                comments.append(record)
    symbol_tables=[]
    for section in sections:
        if section['type'] in (2,11):
            symbol_tables.append({'section':section['name'],'entries':section['size']//max(1,section['entry_size']),
                                  'sha256':section['sha256']})
    return {'header':{'elf_type':typ,'machine':machine,'version':version,'entry_point':entry,'program_header_offset':phoff,
                      'section_header_offset':shoff,'flags':flags,'elf_header_size':ehsize,'program_header_entry_size':phentsize,
                      'program_headers':phnum,'section_header_entry_size':shentsize,'sections':shnum,'section_name_index':shstrndx},
            'sections':sections,'segments':segments,'gnu_build_ids':buildids,'compiler_comments':comments,'symbol_tables':symbol_tables}
def diff_bytes(a,b,examples=64):
    n=min(len(a),len(b))
    changed=[i for i in range(n) if a[i]!=b[i]]
    runs=[]
    for position in changed:
        if runs and runs[-1][1]==position:
            runs[-1][1]+=1
        else:
            runs.append([position,position+1])
    prefix=0
    while prefix<n and a[prefix]==b[prefix]:
        prefix+=1
    suffix=0
    while suffix<n-prefix and a[len(a)-1-suffix]==b[len(b)-1-suffix]:
        suffix+=1
    pages=collections.Counter(i//4096 for i in changed)
    return {'left_bytes':len(a),'right_bytes':len(b),'same_bytes':a==b,'aligned_changed_bytes':len(changed),
            'unpaired_tail_bytes':abs(len(a)-len(b)),'common_prefix_bytes':prefix,'common_suffix_bytes':suffix,
            'changed_run_count':len(runs),'changed_run_length_histogram':dict(sorted(collections.Counter(end-start for start,end in runs).items())),
            'first_changed_runs':[{'offset':start,'end_exclusive':end,'bytes':end-start,
                                   'left_sha256':sha(a[start:end]),'right_sha256':sha(b[start:end])} for start,end in runs[:examples]],
            'changed_4k_pages':[{'page':page,'offset':page*4096,'aligned_changed_bytes':count} for page,count in sorted(pages.items())]}
def string_record(value):
    result={'bytes':len(value),'sha256':sha(value)}
    if b'/src/' in value or b'/rustc/' in value or b'/registry/' in value:
        result['category']='source_path_containing_string_redacted'
    elif b'hepta' in value.lower() or b'jobctl' in value.lower():
        result['category']='project_named_string_redacted'
    elif b'anyhow' in value or b'TypeId' in value:
        result['category']='type_or_anyhow_named_string_redacted'
    elif re.fullmatch(rb'(?:rustc version|GCC:|clang version|Linker:)[ -~]{1,240}',value) and not re.search(rb'(?i)password|credential|secret|api[_-]?key|access[_-]?token',value):
        result['category']='compiler_version'
        result['compiler_version_text']=value.decode('ascii')
    else:
        result['category']='other_printable_string_redacted'
    return result

report={'schema':'hepta-r19-jobctl-binary-diagnostic/v1','started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'read_only_inputs':True,'binaries_modified_or_copied':False,'builds_started':0,'production_service_changes':False,
        'arbitrary_binary_strings_retained':False,'disassembly_performed':False,'passed':False}
try:
    need(not os.path.lexists(OUT),'diagnostic output already exists; no overwrite')
    binaries={}
    report['binaries']={}
    tools={}
    for name,path in PATHS.items():
        data,binding=stable_bytes(path)
        need(binding['sha256']==EXPECTED[name],'input identity differs: '+name)
        binaries[name]=data
        parsed=elf(data)
        report['binaries'][name]={'identity':binding,**parsed}
        tools[name]={}
        for label,argv in [('file',['file','--brief',str(path)]),('readelf_header',['readelf','-h','-W',str(path)]),
                           ('readelf_sections',['readelf','-S','-W',str(path)]),('readelf_segments',['readelf','-l','-W',str(path)]),
                           ('readelf_notes',['readelf','-n','-W',str(path)])]:
            meta,stdout=run_tool(argv)
            if meta.get('returncode')==0:
                # These ELF header/section/segment/note displays contain metadata,
                # not arbitrary .rodata/.data strings.
                meta['metadata_text']=stdout.decode('utf-8','backslashreplace')
            tools[name][label]=meta
    report['tools']=tools
    report['cmp_s'],_=run_tool(['cmp','--silent',str(PATHS['R18']),str(PATHS['R19'])])
    report['whole_file_diff']=diff_bytes(binaries['R18'],binaries['R19'])
    indexed={variant:{section['name']:section for section in report['binaries'][variant]['sections']} for variant in PATHS}
    differences=[]
    for name in sorted(set(indexed['R18'])|set(indexed['R19'])):
        a,b=indexed['R18'].get(name),indexed['R19'].get(name)
        row={'section':name,'left':a,'right':b}
        if a is not None and b is not None:
            row['same_file_bytes']=a['type']==b['type'] and a['size']==b['size'] and a['sha256']==b['sha256']
            if a['type']!=8 and b['type']!=8 and not row['same_file_bytes']:
                row['content_diff']=diff_bytes(binaries['R18'][a['offset']:a['offset']+a['size']],
                                               binaries['R19'][b['offset']:b['offset']+b['size']],examples=24)
        else:
            row['same_file_bytes']=False
        differences.append(row)
    report['section_comparison']=differences
    string_sets={}
    report['string_tools']={}
    for variant,path in PATHS.items():
        meta,stdout=run_tool(['strings','-a','-n','4',str(path)])
        if meta.get('returncode')==0:
            values=stdout.splitlines()
        else:
            values=re.findall(rb'[ -~]{4,}',binaries[variant])
        string_sets[variant]=collections.Counter(values)
        report['string_tools'][variant]=meta
    left,right=string_sets['R18'],string_sets['R19']
    only_left=list((left-right).elements())
    only_right=list((right-left).elements())
    report['strings_comparison']={'left_count':sum(left.values()),'right_count':sum(right.values()),
          'left_unique_count':len(left),'right_unique_count':len(right),'common_occurrences':sum((left&right).values()),
          'only_left_count':len(only_left),'only_right_count':len(only_right),
          'only_left_category_counts':dict(collections.Counter(string_record(x)['category'] for x in only_left)),
          'only_right_category_counts':dict(collections.Counter(string_record(x)['category'] for x in only_right)),
          'only_left_samples':[string_record(x) for x in only_left[:256]],'only_right_samples':[string_record(x) for x in only_right[:256]],
          'sample_limit_per_side':256,'raw_values_except_compiler_version_metadata_retained':False}
    report['inputs_after']={}
    for name,path in PATHS.items():
        _,binding=stable_bytes(path)
        report['inputs_after'][name]=binding
        need(binding==report['binaries'][name]['identity'],'binary changed during diagnostic: '+name)
    report['passed']=True
except BaseException as error:
    report['error']={'type':type(error).__name__,'message':str(error)}
finally:
    report['finished_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat()
    raw=(json.dumps(report,indent=2,sort_keys=True)+'\n').encode()
    fd=os.open(OUT,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_CLOEXEC,0o600)
    with os.fdopen(fd,'wb') as stream:
        stream.write(raw);stream.flush();os.fsync(stream.fileno())
    summary={'passed':report['passed'],'report':str(OUT),'report_sha256':sha(raw),'report_bytes':len(raw),
             'error':report.get('error'),
             'binaries':{key:value['identity'] for key,value in report.get('binaries',{}).items()},
             'sections_with_different_file_bytes':[row['section'] for row in report.get('section_comparison',[]) if not row['same_file_bytes']],
             'compiler_comments':{key:value['compiler_comments'] for key,value in report.get('binaries',{}).items()},
             'build_ids':{key:value['gnu_build_ids'] for key,value in report.get('binaries',{}).items()},
             'strings_only_left':report.get('strings_comparison',{}).get('only_left_count'),
             'strings_only_right':report.get('strings_comparison',{}).get('only_right_count')}
    print(json.dumps(summary,sort_keys=True))
raise SystemExit(0 if report['passed'] else 1)
