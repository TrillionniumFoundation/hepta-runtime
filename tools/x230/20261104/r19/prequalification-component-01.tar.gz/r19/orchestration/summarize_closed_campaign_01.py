#!/usr/bin/env python3
# Copyright 2026 TrillionniumFoundation
# SPDX-License-Identifier: Apache-2.0
"""Read closed R19 evidence and retain a bounded presentation projection.

This does not rerun a workload or auditor. All complete source files remain
unchanged and are independently archived for the subsequent offline replay.
"""
import hashlib
import json
import os
from pathlib import Path
import stat

ROOT = Path('/home/qian/hepta-runtime-optimization-20261104-r19')
R16 = Path('/home/qian/hepta-runtime-optimization-20261104-r16')
EXPECTED = {
    'control': (ROOT / 'campaign-control-01/report.json', 'c002e4742a3cec90b6d515af9fcdd8b31e6fc571f341a49b807a8f5b3c98468a'),
    'native': (ROOT / 'native-observation-01/independent-summary.json', '3b2bea3c5352dfbdc798b2ac7da44ad60e3cb06704728aeecfada429b6863355'),
    'boundary': (R16 / 'r19-native-boundary-01/independent-summary.json', '0685551e81adfce9bbb0fc7b2e0a71d3390d25b8a40b61cae10dd0eaab589de1'),
    'recovery': (R16 / 'r19-cancel-recovery-01/independent-summary.json', '9945639e0ca109de0b00ec88fae4282a048163cf67a648b5197ec36f75a81364'),
}


def read(path, expected=None):
    assert path.resolve() == path
    before = path.lstat()
    assert stat.S_ISREG(before.st_mode) and before.st_nlink == 1
    raw = path.read_bytes()
    after = path.lstat()
    assert (before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns, before.st_ctime_ns) == (after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns, after.st_ctime_ns)
    actual = hashlib.sha256(raw).hexdigest()
    assert len(raw) == before.st_size and (expected is None or actual == expected)
    return raw, {'path': str(path), 'size': len(raw), 'sha256': actual}


def main():
    documents, bindings = {}, {}
    for label, (path, expected) in EXPECTED.items():
        raw, bindings[label] = read(path, expected)
        documents[label] = json.loads(raw)
    control, native, boundary, recovery = (documents[x] for x in ('control', 'native', 'boundary', 'recovery'))
    assert control['current_stage'] == 'completed' and control['passed'] is True
    assert control['adoption_screen_passed'] is True and len(control['stages']) == 6
    assert all(row['returncode'] == 0 and row['post_gate_passed'] is True for row in control['stages'])
    assert native['verified'] is True and boundary['diagnostic_passed'] is True and recovery['verified'] is True
    small_native = {k: native[k] for k in ('verified', 'original_bytes', 'original_sha256', 'binary_sha256', 'measured_calls', 'warmup_calls', 'preflight_restart_calls', 'total_calls', 'failed_calls', 'cases')}
    small_native['resources'] = [dict(round=x['round'], version=x['version'], phase=x['phase'],
        peaks=x['observations'].get('peaks'), metric_samples=x['observations'].get('metric_samples'),
        error_counts=x['observations'].get('error_counts')) for x in native['resources']]
    small_control = {k: control[k] for k in ('started_utc', 'finished_utc', 'passed', 'adoption_screen_passed', 'adoption_checks', 'native_regression_screen', 'native_evidence', 'recovery_evidence', 'capacity_evidence')}
    small_control['stages'] = [{k: row[k] for k in ('name', 'seconds', 'returncode', 'pre_gate_passed', 'post_gate_passed')} for row in control['stages']]
    small_control['quiescence'] = {k: control['quiescence'][k] for k in ('elapsed_seconds', 'passed', 'settings_changed', 'signals_sent')}
    closed = {}
    for relative in ('preparation.json', 'qualification-01/report.json', 'source-freeze-01.json', 'qualification-launch-01.json', 'qualification-exit-01.json', 'qualification-02/report.json', 'source-freeze-02.json', 'qualification-launch-02.json', 'qualification-exit-02.json', 'independent-acceptance-02.json', 'qualification-resolution-02.json', 'qualification-control-02/report.json', 'qualification-tools-installed-02.json', 'publication-tools-installed-01.json'):
        _, closed[relative] = read(ROOT / relative)
    for label, (path, expected) in EXPECTED.items():
        assert read(path, expected)[1] == bindings[label]
    result = {'schema': 'hepta-r19-closed-results-projection/v1', 'source_files_unchanged': True,
              'workloads_started': 0, 'auditors_rerun': 0, 'source_bindings': bindings, 'closed_file_bindings': closed,
              'control': small_control, 'native': small_native, 'boundary': boundary, 'recovery': recovery}
    raw = (json.dumps(result, sort_keys=True, indent=2) + '\n').encode()
    assert len(raw) <= 60000
    output = ROOT / 'closed-campaign-summary-01.json'
    with output.open('xb') as stream:
        stream.write(raw)
    os.chmod(output, 0o600)
    print(json.dumps({'path': str(output), 'size': len(raw), 'sha256': hashlib.sha256(raw).hexdigest(), 'passed': True}))


if __name__ == '__main__':
    main()
