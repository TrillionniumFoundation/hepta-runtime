#!/usr/bin/env python3
# Copyright 2026 TrillionniumFoundation
# SPDX-License-Identifier: Apache-2.0
"""One X230 component experiment followed by a fresh, independently audited build."""
import argparse
import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time
import traceback

ROOT = Path('/home/qian/hepta-runtime-optimization-20261104-r19')
BASELINE = Path('/home/qian/hepta-runtime-optimization-20261104-r18/source/src/mcp/runtime/jobs.rs')
BASELINE_SHA = '694a4e4dcbc2be499879abd837f0b5e399f9cad95caab34716907de15cbbe82f'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--expected-jobs-sha256', required=True)
    args = parser.parse_args()
    candidate = ROOT / 'source/src/mcp/runtime/jobs.rs'
    tools = ROOT / 'tools'
    output = ROOT / 'prequalification-01'
    if sys.platform != 'linux' or os.geteuid() != 1000:
        raise RuntimeError('run as the X230 operator')
    if sha(BASELINE) != BASELINE_SHA or sha(candidate) != args.expected_jobs_sha256:
        raise RuntimeError('source identity differs')
    output.mkdir(mode=0o700)
    manifest = json.loads((tools / 'manifest.json').read_bytes())
    for name, expected in manifest.items():
        if Path(name).name != name or sha(tools / name) != expected:
            raise RuntimeError('measurement/qualification tool identity differs')
    report = {'schema': 'hepta-r19-prequalification/v1', 'started_utc': utc(),
              'candidate_jobs_sha256': args.expected_jobs_sha256, 'baseline_jobs_sha256': BASELINE_SHA,
              'tools': manifest, 'automatic_retries': 0, 'passed': False, 'stages': []}

    def save():
        temporary = output / 'report.next'
        with temporary.open('x') as stream:
            json.dump(report, stream, indent=2)
            stream.write('\n')
        os.replace(temporary, output / 'report.json')

    def stage(name, command, timeout):
        row = {'name': name, 'argv': command, 'started_utc': utc(), 'returncode': None}
        report['stages'].append(row)
        save()
        start = time.monotonic()
        with (output / (name + '.stdout')).open('xb') as stdout, (output / (name + '.stderr')).open('xb') as stderr:
            child = subprocess.run(command, cwd=tools, stdin=subprocess.DEVNULL,
                                   stdout=stdout, stderr=stderr, timeout=timeout)
        row.update(returncode=child.returncode, seconds=time.monotonic() - start, finished_utc=utc())
        for stream in ('stdout', 'stderr'):
            path = output / (name + '.' + stream)
            row[stream] = {'path': str(path), 'bytes': path.stat().st_size, 'sha256': sha(path)}
        save()
        if child.returncode:
            raise RuntimeError(name + ' failed; no automatic retry')
        if sha(BASELINE) != BASELINE_SHA or sha(candidate) != args.expected_jobs_sha256:
            raise RuntimeError('source changed during ' + name)

    python = ['/usr/bin/python3', '-B']
    try:
        save()
        stage('semantic-tests', python + [str(tools / 'test_python_read_bounds.py'),
              '--baseline', str(BASELINE), '--candidate', str(candidate),
              '--json', str(ROOT / 'semantic-tests-x230-01.json')], 300)
        stage('component-abba', python + [str(tools / 'python_read_probe.py'), 'abba',
              '--baseline', str(BASELINE), '--candidate', str(candidate),
              '--output-dir', str(ROOT / 'component-probe-01'), '--rounds', '4',
              '--iterations', '256', '--warmup', '16'], 1200)
        stage('fresh-qualification', python + [str(tools / 'qualify_candidate.py'),
              '--root', str(ROOT), '--expected-jobs-sha256', args.expected_jobs_sha256,
              '--stage-timeout', '3600'], 7200)
        stage('independent-qualification', python + [str(tools / 'verify_qualification.py'),
              '--root', str(ROOT), '--expected-jobs-sha256', args.expected_jobs_sha256], 300)
        report['passed'] = True
    except BaseException as error:
        report['error'] = {'type': type(error).__name__, 'message': str(error)}
        (output / 'error.txt').write_text(traceback.format_exc())
    finally:
        report['finished_utc'] = utc()
        save()
        print(json.dumps({'passed': report['passed'], 'report': str(output / 'report.json'),
                          'error': report.get('error')}), flush=True)
    return 0 if report['passed'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
