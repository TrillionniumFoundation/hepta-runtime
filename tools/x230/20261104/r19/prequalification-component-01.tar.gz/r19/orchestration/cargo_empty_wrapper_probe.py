#!/usr/bin/env python3
# Copyright 2026 TrillionniumFoundation; SPDX-License-Identifier: Apache-2.0
"""Three tiny std-only builds isolate empty versus absent Cargo wrapper settings.

This never writes the actual runtime source, qualification outputs or targets.
The repeated absent-wrapper control checks that target directory names alone do
not explain the observed compiler namespace difference. It is not a benchmark.
"""
import datetime
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import time
import traceback

ROOT = Path('/home/qian/hepta-runtime-optimization-20261104-r19')
OUT = ROOT / 'cargo-empty-wrapper-probe-01'
KEYS = ('CARGO_BUILD_RUSTC_WRAPPER', 'CARGO_BUILD_RUSTC_WORKSPACE_WRAPPER')
CARGO = ['/home/qian/.cargo/bin/cargo', '+1.95.0']


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    if sys.platform != 'linux' or os.geteuid() != 1000:
        raise RuntimeError('X230 operator required')
    OUT.mkdir(mode=0o700)
    source = OUT / 'source'
    (source / 'src').mkdir(parents=True, mode=0o700)
    manifest = '''[package]
name = "wrapper-metadata-probe"
version = "0.0.0"
edition = "2021"

[workspace]

[profile.release]
opt-level = 3
lto = true
codegen-units = 1
strip = true
panic = "abort"
'''
    (source / 'Cargo.toml').write_text(manifest)
    (source / 'src/lib.rs').write_text('pub struct Marker;\npub fn value() -> u64 { 42 }\n')
    (source / 'src/main.rs').write_text('use std::any::TypeId;\nstruct Local;\nfn main() { println!("{:?} {:?} {}", TypeId::of::<Local>(), TypeId::of::<wrapper_metadata_probe::Marker>(), wrapper_metadata_probe::value()); }\n')
    spec = importlib.util.spec_from_file_location('frozen_qualifier_environment', ROOT / 'tools/qualify_candidate.py')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    original = module.clean_environment()
    if not all(original.get(key) == '' for key in KEYS):
        raise RuntimeError('original R19 environment no longer has the two empty wrapper settings')
    protected = [ROOT / 'source/src/mcp/runtime/jobs.rs', ROOT / 'qualification-01/hepta-runtime-jobctl',
                 ROOT / 'independent-acceptance-01.json', ROOT / 'prequalification-01/report.json',
                 Path('/home/qian/hepta-runtime-optimization-20261104-r18/qualification-02/hepta-runtime-jobctl')]
    bindings = {str(path): sha(path) for path in protected}
    report = {'schema': 'hepta-r19-cargo-empty-wrapper-probe/v1', 'passed': False,
              'started_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
              'scope': 'std-only Cargo identity diagnostic; not runtime qualification or performance',
              'wrapper_keys': list(KEYS), 'protected_inputs_before': bindings, 'automatic_retries': 0,
              'runtime_source_or_targets_modified': False, 'cases': []}

    def save():
        temporary = OUT / 'report.next'
        with temporary.open('x') as stream:
            json.dump(report, stream, indent=2, sort_keys=True)
            stream.write('\n')
        os.replace(temporary, OUT / 'report.json')

    def command(label, argv, environment):
        start = time.monotonic()
        with (OUT / (label + '.stdout')).open('xb') as stdout, (OUT / (label + '.stderr')).open('xb') as stderr:
            result = subprocess.run(argv, cwd=source, env=environment, stdin=subprocess.DEVNULL,
                                    stdout=stdout, stderr=stderr, timeout=180)
        row = {'argv': argv, 'returncode': result.returncode, 'seconds': time.monotonic() - start,
               'stdout_sha256': sha(OUT / (label + '.stdout')), 'stderr_sha256': sha(OUT / (label + '.stderr'))}
        if result.returncode:
            report['failed_command'] = row
            save()
            raise RuntimeError(label + ' failed without retry')
        return row

    try:
        absent = {key: value for key, value in original.items() if key not in KEYS}
        report['lock_generation'] = command('lock', CARGO + ['generate-lockfile', '--offline'], absent)
        sources = {str(path.relative_to(source)): sha(path) for path in source.rglob('*') if path.is_file()}
        report['source_sha256'] = sources
        for label, empty in [('A-unset', False), ('B-empty', True), ('A2-unset', False)]:
            target = OUT / ('target-' + label)
            if target.exists():
                raise RuntimeError('probe target already exists')
            environment = dict(original if empty else absent, CARGO_TARGET_DIR=str(target))
            row = {'label': label, 'wrapper_settings': {key: environment.get(key) for key in KEYS},
                   'target_previously_absent': True, 'target': str(target)}
            report['cases'].append(row)
            save()
            row['build'] = command(label + '-build', CARGO + ['build', '--offline', '--locked', '--release', '-vv'], environment)
            text = (OUT / (label + '-build.stderr')).read_text()
            rustc = [line.strip() for line in text.splitlines() if 'Running `' in line and '--crate-name wrapper_metadata_probe ' in line]
            if len(rustc) != 2:
                raise RuntimeError('expected exactly the owned lib and bin rustc commands')
            row['rustc_commands'] = rustc
            row['compiler_metadata'] = [re.search(r'-C metadata=([^\s`]+)', line).group(1) for line in rustc]
            binary = target / 'release/wrapper-metadata-probe'
            row['binary_sha256'], row['binary_bytes'] = sha(binary), binary.stat().st_size
            row['run'] = command(label + '-run', [str(binary)], environment)
            row['type_identity_output'] = (OUT / (label + '-run.stdout')).read_text().strip()
            row['unit_fingerprints'] = [{'unit': path.parent.name, 'file': path.name,
                 'sha256': sha(path), 'value': json.loads(path.read_bytes())}
                 for path in sorted((target / 'release/.fingerprint').glob('wrapper-metadata-probe-*/*.json'))]
            save()
        left, right, repeated = report['cases']
        report['checks'] = {
            'same_source_bytes': sources == {str(path.relative_to(source)): sha(path) for path in source.rglob('*') if path.is_file()},
            'absent_controls_same_metadata': left['compiler_metadata'] == repeated['compiler_metadata'],
            'absent_controls_same_binary': left['binary_sha256'] == repeated['binary_sha256'],
            'absent_controls_same_type_identity': left['type_identity_output'] == repeated['type_identity_output'],
            'empty_setting_changes_metadata': left['compiler_metadata'] != right['compiler_metadata'],
            'empty_setting_changes_binary': left['binary_sha256'] != right['binary_sha256'],
            'empty_setting_changes_type_identity': left['type_identity_output'] != right['type_identity_output'],
            'actual_runtime_inputs_unchanged': bindings == {str(path): sha(path) for path in protected},
        }
        report['passed'] = all(report['checks'].values())
    except BaseException as error:
        report['error'] = {'type': type(error).__name__, 'message': str(error)}
        (OUT / 'error.txt').write_text(traceback.format_exc())
    finally:
        report['finished_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
        save()
        print(json.dumps({'passed': report['passed'], 'checks': report.get('checks'), 'error': report.get('error'),
                          'report_sha256': sha(OUT / 'report.json'), 'report': str(OUT / 'report.json')}), flush=True)
    return 0 if report['passed'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
