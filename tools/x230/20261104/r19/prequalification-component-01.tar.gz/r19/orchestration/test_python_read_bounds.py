#!/usr/bin/env python3
# Copyright 2026 TrillionniumFoundation
# SPDX-License-Identifier: Apache-2.0
"""Differential tests of the actual R18 and R19 embedded Python read functions.

Ordinary and raced reads use real temporary files. Explicit stat/short-read/EIO
oracles exercise unusual metadata and I/O behavior without changing production
function bodies. No SSH, systemd unit, production registry, or workload is used.
"""

from __future__ import annotations

import argparse
import ast
import errno
import io
import json
import os
from pathlib import Path
import stat
import subprocess
import sys
import tempfile
import types
import unittest

from python_read_probe import (
    BASELINE_SHA256,
    PRIVATE_LIMIT,
    TERMINAL_LIMIT,
    SourceFunctions,
    encode_json,
    extract_constant,
    private_write,
    sha256,
    value_identity,
)


class BoundedRaw(io.RawIOBase):
    """A real file descriptor with controlled raw short reads / injected EIO."""

    def __init__(self, fd, trace, maximum_chunk=None, fail_after=None, closefd=True, block_once_at=None):
        super().__init__()
        self.fd = fd
        self.trace = trace
        self.maximum_chunk = maximum_chunk
        self.fail_after = fail_after
        self.closefd = closefd
        self.block_once_at = block_once_at
        self.blocked_once = False
        self.offset = 0

    def readable(self):
        return True

    def fileno(self):
        return self.fd

    def readinto(self, buffer):
        count = len(buffer)
        if self.block_once_at is not None and not self.blocked_once and self.offset >= self.block_once_at:
            self.blocked_once = True
            self.trace.append({"raw_read": count, "returned": None, "offset": self.offset})
            return None
        if self.fail_after is not None and self.offset >= self.fail_after:
            self.trace.append({"raw_read": count, "error": "EIO", "offset": self.offset})
            raise OSError(errno.EIO, "injected raw file read failure")
        if self.maximum_chunk is not None:
            count = min(count, self.maximum_chunk)
        if self.fail_after is not None:
            count = min(count, self.fail_after - self.offset)
        if self.block_once_at is not None and not self.blocked_once:
            count = min(count, self.block_once_at - self.offset)
        data = os.read(self.fd, count)
        buffer[: len(data)] = data
        self.trace.append({"raw_read": len(buffer), "returned": len(data), "offset": self.offset})
        self.offset += len(data)
        return len(data)

    def close(self):
        if not self.closed and self.closefd:
            os.close(self.fd)
        super().close()


class TracedStream:
    def __init__(self, stream, owner):
        self.stream = stream
        self.owner = owner

    def __enter__(self):
        self.stream.__enter__()
        return self

    def __exit__(self, *args):
        return self.stream.__exit__(*args)

    def fileno(self):
        return self.stream.fileno()

    def read(self, size):
        self.owner.before_read()
        event = {"read_argument": size}
        self.owner.events.append(event)
        try:
            value = self.stream.read(size)
        except BaseException as error:
            event["error_type"] = type(error).__name__
            raise
        event["returned"] = len(value) if value is not None else None
        self.owner.after_read()
        return value


class OsOracle:
    """Forward OS calls; only declared fields or explicit read phases differ."""

    def __init__(
        self,
        target: Path,
        *,
        stat_fields=None,
        mutation=None,
        mutation_phase="after",
        maximum_chunk=None,
        fail_after=None,
        failure=None,
        block_once_at=None,
    ):
        self.target = target
        self.stat_fields = stat_fields or {}
        self.mutation = mutation
        self.mutation_phase = mutation_phase
        self.maximum_chunk = maximum_chunk
        self.fail_after = fail_after
        self.failure = failure
        self.block_once_at = block_once_at
        self.fstat_count = 0
        self.mutated = False
        self.events = []
        self.stream_fds = []
        self.explicit_closes = {}

    def __getattr__(self, name):
        return getattr(os, name)

    def adjusted(self, info):
        if not stat.S_ISREG(info.st_mode) or not self.stat_fields:
            return info
        fields = {name: getattr(info, name) for name in dir(info) if name.startswith("st_")}
        fields.update(self.stat_fields)
        return types.SimpleNamespace(**fields)

    def fstat(self, fd):
        self.fstat_count += 1
        if (self.failure == "before_fstat" and self.fstat_count == 1) or (self.failure == "after_fstat" and self.fstat_count == 2):
            raise OSError(errno.EIO, "injected descriptor stat failure")
        info = self.adjusted(os.fstat(fd))
        self.events.append({"fstat_size": info.st_size})
        return info

    def stat(self, name, **kwargs):
        if self.failure == "named_stat":
            raise OSError(errno.EIO, "injected named stat failure")
        info = self.adjusted(os.stat(name, **kwargs))
        self.events.append({"stat_size": info.st_size})
        return info

    def fdopen(self, fd, mode, *, closefd=True):
        self.stream_fds.append(fd)
        if self.failure == "fdopen":
            raise OSError(errno.EIO, "injected fdopen constructor failure")
        if self.maximum_chunk is not None or self.fail_after is not None or self.block_once_at is not None:
            raw = BoundedRaw(fd, self.events, self.maximum_chunk, self.fail_after, closefd, self.block_once_at)
            stream = io.BufferedReader(raw)
        else:
            stream = os.fdopen(fd, mode, closefd=closefd)
        return TracedStream(stream, self)

    def close(self, fd):
        self.explicit_closes[fd] = self.explicit_closes.get(fd, 0) + 1
        return os.close(fd)

    def mutate(self, phase):
        if self.mutation is not None and not self.mutated and self.mutation_phase == phase:
            self.mutated = True
            self.mutation(self.target)
            self.events.append({"mutation_phase": phase})

    def before_read(self):
        self.mutate("before")

    def after_read(self):
        self.mutate("after")

    def still_open(self):
        held = []
        for fd in self.stream_fds:
            try:
                os.fstat(fd)
            except OSError as error:
                if error.errno == errno.EBADF:
                    continue
                raise
            held.append(fd)
        return held


def encoded_object(size):
    prefix, suffix = b'{"data":"', b'"}'
    if size < len(prefix) + len(suffix):
        raise ValueError("size is too small for the object fixture")
    return prefix + b"x" * (size - len(prefix) - len(suffix)) + suffix


def exception_identity(error):
    return {
        "type": type(error).__name__,
        "message": str(error),
        "errno": getattr(error, "errno", None),
    }


class ReadBoundsTests(unittest.TestCase):
    baseline = None
    candidate = None
    observations = []

    def evaluate(self, variant, kind, data, *, oracle=None, setup=None, missing_ok=False):
        functions = SourceFunctions(self.baseline if variant == "A" else self.candidate)
        with tempfile.TemporaryDirectory(prefix="hepta-read-bound-test-") as temporary:
            directory = Path(temporary)
            target = directory / "fixture.json"
            if data is not None:
                private_write(target, data)
            if setup is not None:
                setup(target)
            view = OsOracle(target, **(oracle or {}))
            functions.namespace["os"] = view
            with functions.directory(directory) as ns:
                try:
                    if kind == "private":
                        value = ns["private_read_json"]("fixture.json")
                    else:
                        value = ns["read_terminal_file"]("fixture.json", TERMINAL_LIMIT, missing_ok)
                    result = {"ok": True, "value": value}
                except BaseException as error:
                    result = {"ok": False, "error": exception_identity(error)}
                # fdopen(directory_fd, 'rb') rejects before taking ownership.
                # Record that existing failure behavior, compare both sources,
                # and close only this test's known descriptors afterwards.
                held = view.still_open()
                result["file_fds_open_at_return"] = len(held)
                result["explicit_close_counts"] = [view.explicit_closes.get(fd, 0) for fd in view.stream_fds]
                for fd in held:
                    os.close(fd)
            result["trace"] = view.events
            result["mutated"] = view.mutated
            return result

    def pair(self, name, kind, data, *, expected_ok, oracle=None, setup=None, missing_ok=False):
        results = {
            variant: self.evaluate(variant, kind, data, oracle=oracle, setup=setup, missing_ok=missing_ok)
            for variant in ("A", "B")
        }
        for variant, result in results.items():
            self.assertEqual(result["ok"], expected_ok, (name, variant, result))
            self.observations.append(
                {
                    "case": name,
                    "variant": variant,
                    "kind": kind,
                    "ok": result["ok"],
                    "result": value_identity(result["value"]) if result["ok"] else result["error"],
                    "trace": result["trace"],
                    "mutated": result["mutated"],
                    "file_fds_open_at_return": result["file_fds_open_at_return"],
                    "explicit_close_counts": result["explicit_close_counts"],
                }
            )
        if expected_ok:
            self.assertEqual(results["A"]["value"], results["B"]["value"], name)
        else:
            self.assertEqual(results["A"]["error"], results["B"]["error"], name)
        self.assertEqual(results["B"]["file_fds_open_at_return"], 0, name)
        if name in ("unsafe-terminal-directory", "terminal-fdopen-failure"):
            self.assertEqual(results["A"]["file_fds_open_at_return"], 1, name)
        else:
            self.assertEqual(results["A"]["file_fds_open_at_return"], 0, name)
        if kind == "terminal":
            self.assertTrue(all(count == 1 for count in results["B"]["explicit_close_counts"]), name)
        for result in results.values():
            read_events = [event for event in result["trace"] if "read_argument" in event]
            cap = PRIVATE_LIMIT + 1 if kind == "private" else TERMINAL_LIMIT + 1
            self.assertTrue(all(event["read_argument"] >= 0 for event in read_events), name)
            self.assertLessEqual(sum(event.get("returned", 0) or 0 for event in read_events), cap, name)
        return results

    def test_only_two_original_function_bodies_change(self):
        before = self.baseline.read_text()
        after = self.candidate.read_text()
        self.assertEqual(sha256(before.encode()), BASELINE_SHA256)
        allowed = {
            "PRIVATE_DIRECTORY_CODE": {"private_read_json"},
            "STATUS_CODE": {"read_terminal_file"},
        }
        for name, changed in allowed.items():
            left = extract_constant(before, name)
            right = extract_constant(after, name)
            left_tree, right_tree = ast.parse(left), ast.parse(right)
            left_items = {node.name: ast.dump(node) for node in left_tree.body if isinstance(node, ast.FunctionDef)}
            right_items = {node.name: ast.dump(node) for node in right_tree.body if isinstance(node, ast.FunctionDef)}
            self.assertEqual(left_items.keys(), right_items.keys())
            self.assertEqual({key for key in left_items if left_items[key] != right_items[key]}, changed)
            for tree in (left_tree, right_tree):
                tree.body = [node for node in tree.body if not (isinstance(node, ast.FunctionDef) and node.name in changed)]
            self.assertEqual(ast.dump(left_tree), ast.dump(right_tree))
            before = before.replace(left, f"<unchanged-contract-{name}>")
            after = after.replace(right, f"<unchanged-contract-{name}>")
        self.assertEqual(before, after, "unrelated Rust or embedded code changed")

    def test_private_stable_json_and_original_limit(self):
        fixtures = {
            "empty_object": b"{}",
            "tiny": b'{"a":1}\n',
            "unicode": encode_json({"text": "汉字 / café / 🚀"}),
            "utf16_with_bom": json.dumps({"text": "汉字"}).encode("utf-16"),
            "valid_nonfinite": b'{"a":NaN,"b":Infinity}',
            "64k": encoded_object(65536),
            "exact_4mib": encoded_object(PRIVATE_LIMIT),
        }
        for name, data in fixtures.items():
            with self.subTest(name=name):
                results = self.pair(name, "private", data, expected_ok=True)
                reads = [event for event in results["B"]["trace"] if "read_argument" in event]
                self.assertEqual([event["read_argument"] for event in reads], [len(data) + 1])
        self.pair("private_before_stat_oversize", "private", encoded_object(PRIVATE_LIMIT + 1), expected_ok=False)

    def test_invalid_json_utf8_nonobject_and_trailing_data(self):
        fixtures = [b"", b"{", b"\xff", b'{"x":"\xff"}', b"[]", b"null", b"1", b"{} trailing", b"{}\n{}", b"{\"x\":1}\x00"]
        for index, data in enumerate(fixtures):
            with self.subTest(index=index):
                self.pair(f"invalid-json-{index}", "private", data, expected_ok=False)

    def test_private_underreported_overreported_and_negative_size_preserve_old_behavior(self):
        valid = encode_json({"message": "complete payload after underreported size"})
        for reported in (-11, -2, -1, 0, 1, len(valid) - 1, len(valid), len(valid) + 100):
            with self.subTest(reported=reported):
                result = self.pair(
                    f"private-size-{reported}", "private", valid, expected_ok=True,
                    oracle={"stat_fields": {"st_size": reported}},
                )
                reads = [event for event in result["B"]["trace"] if "read_argument" in event]
                if reported < len(valid):
                    self.assertEqual(len(reads), 2)
                    self.assertEqual(sum(event["read_argument"] for event in reads), PRIVATE_LIMIT + 1)
                else:
                    self.assertEqual(len(reads), 1)
        for suffix in (b" " * 256 + b"garbage", b" " * 8192 + b"{}", b"\xff"):
            self.pair("underreported-trailing-" + sha256(suffix)[:8], "private", b"{}" + suffix, expected_ok=False, oracle={"stat_fields": {"st_size": 0}})
        self.pair("underreported-valid-at-cap", "private", encoded_object(PRIVATE_LIMIT), expected_ok=True, oracle={"stat_fields": {"st_size": 0}})
        results = self.pair("underreported-cap-plus-one", "private", encoded_object(PRIVATE_LIMIT + 1), expected_ok=False, oracle={"stat_fields": {"st_size": 0}})
        for result in results.values():
            self.assertEqual(sum(event.get("returned", 0) or 0 for event in result["trace"] if "read_argument" in event), PRIVATE_LIMIT + 1)
        result = self.pair("reported-at-cap-fallback-read-zero", "private", encoded_object(PRIVATE_LIMIT + 1), expected_ok=False, oracle={"stat_fields": {"st_size": PRIVATE_LIMIT}})
        reads = [event for event in result["B"]["trace"] if "read_argument" in event]
        self.assertEqual([event["read_argument"] for event in reads], [PRIVATE_LIMIT + 1, 0])

    def test_actual_buffered_reader_coalesces_raw_short_reads(self):
        data = encode_json({"x": "short raw reads with a complete UTF8 boundary: 汉字"})
        for kind in ("private", "terminal"):
            for chunk in (1, 7, 16):
                with self.subTest(kind=kind, chunk=chunk):
                    self.pair(f"raw-short-{kind}-{chunk}", kind, data, expected_ok=True, oracle={"maximum_chunk": chunk})
        self.pair("underreported-raw-short", "private", data, expected_ok=True, oracle={"stat_fields": {"st_size": 0}, "maximum_chunk": 1})
        self.pair("underreported-raw-short-garbage", "private", b"{}" + b" " * 31 + b"garbage", expected_ok=False, oracle={"stat_fields": {"st_size": 1}, "maximum_chunk": 1})

    def test_eio_before_data_and_during_fallback_propagates_and_closes(self):
        data = encode_json({"x": "long enough to reach the injected fault"})
        for kind in ("private", "terminal"):
            for offset in (0, 8):
                with self.subTest(kind=kind, offset=offset):
                    result = self.pair(f"eio-{kind}-{offset}", kind, data, expected_ok=False, oracle={"fail_after": offset})
                    self.assertEqual(result["A"]["error"]["errno"], errno.EIO)
        result = self.pair("fallback-second-read-eio", "private", data, expected_ok=False, oracle={"stat_fields": {"st_size": 0}, "fail_after": 8})
        reads = [event for event in result["B"]["trace"] if "read_argument" in event]
        self.assertEqual(len(reads), 2)
        self.assertEqual(reads[0]["returned"], 1)
        self.assertEqual(reads[1]["error_type"], "OSError")
        self.assertFalse(any("stat_size" in event for event in result["B"]["trace"]))

    def test_nonblocking_raw_eagain_preserves_prefix_without_retry(self):
        cases = [
            ("fallback-none-after-complete-json", "private", b"{}", 1, 2, True),
            ("fallback-buffered-prefix-before-none", "private", b"{}", 0, 2, True),
            ("fallback-none-after-invalid-prefix", "private", b'{"x":1}', 0, 1, False),
            ("no-retry-beyond-eagain", "private", b"{} future garbage", 1, 2, True),
            ("private-first-none", "private", b"{}", 2, 0, False),
            ("terminal-eagain-at-logical-eof", "terminal", b"{}", 2, 2, True),
            ("terminal-short-eagain", "terminal", b"{}", 2, 1, False),
            ("terminal-first-none", "terminal", b"{}", 2, 0, False),
        ]
        for name, kind, data, reported, block_at, expected_ok in cases:
            with self.subTest(case=name):
                results = self.pair(name, kind, data, expected_ok=expected_ok, oracle={"stat_fields": {"st_size": reported}, "block_once_at": block_at})
                for result in results.values():
                    events = result["trace"]
                    blocked = [index for index, event in enumerate(events) if "raw_read" in event and event.get("returned", "absent") is None]
                    self.assertEqual(len(blocked), 1)
                    self.assertFalse(any("raw_read" in event for event in events[blocked[0] + 1 :]), name)
                if name.endswith("first-none"):
                    self.assertEqual(results["B"]["error"]["type"], "TypeError")
                    self.assertTrue(any("stat_size" in event for event in results["B"]["trace"]))
        # An initial None historically reaches metadata checks before len(None).
        # Do not move that failure ahead of a real named-stat error.
        results = self.pair("private-first-none-named-stat-failure", "private", b"{}", expected_ok=False, oracle={"block_once_at": 0, "failure": "named_stat"})
        self.assertEqual(results["B"]["error"]["errno"], errno.EIO)

    def test_terminal_stable_bytes_missing_and_original_bound(self):
        for data in (b"", b"{}\n", b"\xff", encoded_object(65536), encoded_object(TERMINAL_LIMIT)):
            with self.subTest(size=len(data)):
                result = self.pair(f"terminal-bytes-{len(data)}", "terminal", data, expected_ok=True)
                self.assertEqual(result["B"]["value"], data)
        self.pair("terminal-before-stat-oversize", "terminal", encoded_object(TERMINAL_LIMIT + 1), expected_ok=False)
        self.pair("terminal-missing", "terminal", None, expected_ok=False)
        self.pair("terminal-missing-optional", "terminal", None, expected_ok=True, missing_ok=True)
        self.pair("private-missing", "private", None, expected_ok=True)

    def test_terminal_owned_fd_closes_on_constructor_and_metadata_failures(self):
        data = encode_json({"x": "close exactly the originally opened descriptor"})
        for failure in ("fdopen", "before_fstat", "after_fstat", "named_stat"):
            with self.subTest(failure=failure):
                result = self.pair(f"terminal-{failure}-failure", "terminal", data, expected_ok=False, oracle={"failure": failure})
                self.assertEqual(result["B"]["explicit_close_counts"], [1])
                self.assertEqual(result["B"]["error"]["errno"], errno.EIO)

    def test_terminal_size_mismatch_still_refused(self):
        data = encode_json({"x": "strict terminal length"})
        for reported in (-3, -1, 0, 1, len(data) - 1, len(data) + 1):
            with self.subTest(reported=reported):
                self.pair(f"terminal-size-{reported}", "terminal", data, expected_ok=False, oracle={"stat_fields": {"st_size": reported}})

    def test_growth_truncation_replacement_and_metadata_changes_refuse(self):
        data = encode_json({"original": "an immutable snapshot"})

        def grow(path):
            with path.open("ab") as stream:
                stream.write(b" " * 100)

        def grow_over_cap(path):
            with path.open("ab") as stream:
                stream.write(b" " * (PRIVATE_LIMIT + 32))

        def truncate(path):
            with path.open("r+b") as stream:
                stream.truncate(2)

        def replace(path):
            other = path.with_name("replacement.json")
            private_write(other, data)
            os.replace(other, path)

        def timestamp(path):
            info = path.stat()
            os.utime(path, ns=(info.st_atime_ns, info.st_mtime_ns + 1_000_000))

        def permissions(path):
            path.chmod(0o640)

        mutations = {"grow": grow, "grow-over-cap": grow_over_cap, "truncate": truncate, "replace": replace, "mtime": timestamp, "mode": permissions}
        for kind in ("private", "terminal"):
            for phase in ("before", "after"):
                for name, mutation in mutations.items():
                    with self.subTest(kind=kind, phase=phase, mutation=name):
                        result = self.pair(f"race-{kind}-{phase}-{name}", kind, data, expected_ok=False, oracle={"mutation": mutation, "mutation_phase": phase})
                        self.assertTrue(all(value["mutated"] for value in result.values()))

    def test_nonregular_symlink_hardlink_and_unsafe_metadata_refuse(self):
        data = b'{"safe":true}'

        def symlink(path):
            held = path.with_name("held.json")
            path.rename(held)
            path.symlink_to(held.name)

        def hardlink(path):
            os.link(path, path.with_name("other-link.json"))

        def directory(path):
            path.unlink()
            path.mkdir(mode=0o700)

        def fifo(path):
            path.unlink()
            os.mkfifo(path, 0o600)

        for kind in ("private", "terminal"):
            for name, setup in (("symlink", symlink), ("hardlink", hardlink), ("directory", directory), ("fifo", fifo)):
                with self.subTest(kind=kind, fixture=name):
                    self.pair(f"unsafe-{kind}-{name}", kind, data, expected_ok=False, setup=setup)
            for field, value in (("st_uid", os.geteuid() + 1), ("st_mode", stat.S_IFREG | 0o666), ("st_nlink", 2)):
                self.pair(f"unsafe-{kind}-{field}", kind, data, expected_ok=False, oracle={"stat_fields": {field: value}})

    def test_terminal_json_and_witness_still_use_original_interpretation(self):
        request = {"job_id": "terminal-fixture", "launch_nonce": "a" * 32, "terminal_publication_protocol": 1}
        normal = {**request, "exit_code": 0, "output_complete": True, "output_durable": True}
        scenarios = {
            "confirmed": (encode_json(normal), None, "succeeded"),
            "invalid-utf8": (b"\xff", None, "finalizing"),
            "invalid-json": (b"{", None, "finalizing"),
            "not-object": (b"[]", None, "finalizing"),
            "wrong-job": (encode_json({**normal, "job_id": "wrong"}), None, "finalizing"),
            "bad-witness": (encode_json(normal), "bad", "finalizing"),
            "missing-witness": (encode_json(normal), "missing", "finalizing"),
        }
        for name, (data, witness_mode, expected_state) in scenarios.items():
            results = []
            for variant, source in (("A", self.baseline), ("B", self.candidate)):
                functions = SourceFunctions(source)
                with tempfile.TemporaryDirectory(prefix="hepta-terminal-status-") as temporary:
                    directory = Path(temporary)
                    private_write(directory / "exit.json", data)
                    if witness_mode != "missing":
                        witness = {**request, "exit_sha256": sha256(data) if witness_mode is None else "0" * 64}
                        private_write(directory / "exit.witness.json", encode_json(witness))
                    with functions.directory(directory) as ns:
                        value = ns["read_terminal_status"](request)
                    self.assertEqual(value["state"], expected_state)
                    self.assertFalse(value["automatic_retry"])
                    self.observations.append({"case": name, "variant": variant, "kind": "terminal-status", "ok": True, "result": value_identity(value)})
                    results.append(value)
            self.assertEqual(results[0], results[1])

    def test_complete_bound_helper_still_returns_confirmed_status(self):
        results = []
        with tempfile.TemporaryDirectory(prefix="hepta-bound-full-helper-") as temporary:
            directory = Path(temporary) / "state" / "jobs" / "full-helper"
            directory.mkdir(parents=True, mode=0o700)
            directory.parent.chmod(0o700)
            directory.parent.parent.chmod(0o700)
            request = {
                "job_id": "full-helper",
                "job_dir": str(directory),
                "unit": "not-a-real-unit",
                "request_digest": "b" * 64,
                "launch_nonce": "a" * 32,
                "terminal_publication_protocol": 1,
            }
            exit_data = {"job_id": request["job_id"], "launch_nonce": request["launch_nonce"], "terminal_publication_protocol": 1, "exit_code": 0}
            encoded_exit = encode_json(exit_data)
            witness = {"job_id": request["job_id"], "launch_nonce": request["launch_nonce"], "terminal_publication_protocol": 1, "exit_sha256": sha256(encoded_exit)}
            for filename, data in (("request.json", encode_json(request)), ("launch.json", encode_json({"backend": "detached"})), ("exit.json", encoded_exit), ("exit.witness.json", encode_json(witness))):
                private_write(directory / filename, data)
            for variant, source in (("A", self.baseline), ("B", self.candidate)):
                functions = SourceFunctions(source)
                command = [sys.executable, "-I", "-S", "-c", functions.complete_status_script()]
                completed = subprocess.run(command, input=json.dumps({**request, "wait_seconds": 0}), text=True, capture_output=True, timeout=10)
                self.assertEqual(completed.returncode, 0, completed.stderr)
                self.assertEqual(completed.stderr, "")
                parsed = json.loads(completed.stdout)
                self.assertEqual(parsed["state"], "succeeded")
                self.assertTrue(parsed["terminal_publication_confirmed"])
                self.assertFalse(parsed["automatic_retry"])
                self.observations.append({"case": "complete-bound-helper", "variant": variant, "kind": "integration", "ok": True, "result": value_identity(parsed)})
                results.append(parsed)
        self.assertEqual(results[0], results[1])


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--baseline", type=Path, required=True)
    parser.add_argument("--candidate", type=Path, required=True)
    parser.add_argument("--json", type=Path)
    args = parser.parse_args()
    if args.json is not None and args.json.exists():
        parser.error("refusing to replace existing test evidence")
    ReadBoundsTests.baseline = args.baseline.resolve()
    ReadBoundsTests.candidate = args.candidate.resolve()
    bindings = {
        "A": SourceFunctions(ReadBoundsTests.baseline).identity(),
        "B": SourceFunctions(ReadBoundsTests.candidate).identity(),
    }
    result = unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(ReadBoundsTests))
    report = {
        "schema": "hepta-python-read-bounds-tests-v1",
        "source_bindings": bindings,
        "python": sys.version,
        "test_script_sha256": sha256(Path(__file__).read_bytes()),
        "probe_script_sha256": sha256(Path(__file__).with_name("python_read_probe.py").read_bytes()),
        "tests_run": result.testsRun,
        "failed": len(result.failures),
        "errors": len(result.errors),
        "skipped": len(result.skipped),
        "successful": result.wasSuccessful(),
        "failures": [{"test": str(test), "traceback": trace} for test, trace in result.failures],
        "error_details": [{"test": str(test), "traceback": trace} for test, trace in result.errors],
        "observations": ReadBoundsTests.observations,
        "scope": "Actual extracted function bodies; real regular files and declared controlled stat/short-read/EIO oracles; complete helper integration; no remote production load",
    }
    for variant, path in (("A", ReadBoundsTests.baseline), ("B", ReadBoundsTests.candidate)):
        if sha256(path.read_bytes()) != bindings[variant]["source_sha256"]:
            raise RuntimeError("source changed during semantic qualification")
    if args.json is not None:
        args.json.parent.mkdir(parents=True, exist_ok=True)
        with args.json.open("x") as stream:
            json.dump(report, stream, indent=2)
            stream.write("\n")
    print(json.dumps({"tests_run": result.testsRun, "observations": len(report["observations"]), "successful": result.wasSuccessful(), "failed": len(result.failures), "errors": len(result.errors), "skipped": len(result.skipped)}))
    raise SystemExit(0 if result.wasSuccessful() else 1)


if __name__ == "__main__":
    main()
