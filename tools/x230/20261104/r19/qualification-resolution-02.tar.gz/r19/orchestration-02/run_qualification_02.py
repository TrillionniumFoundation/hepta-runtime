#!/usr/bin/env python3
# Copyright 2026 TrillionniumFoundation
# SPDX-License-Identifier: Apache-2.0
"""Run fresh qualification attempt 02 and resolve the preserved attempt 01 failure.

Only the two new qualification tools execute. Previously successful semantic and
component evidence is re-read and bound, never rerun. No retry or overwrite.
"""
import argparse
import datetime
import hashlib
import json
import os
from pathlib import Path
import pwd
import re
import signal
import stat
import subprocess
import sys
import tempfile
import time
import traceback

ROOT = Path('/home/qian/hepta-runtime-optimization-20261104-r19')
BASELINE = Path('/home/qian/hepta-runtime-optimization-20261104-r18/source')
JOBS_SHA = 'c9080de8aa9a35f7495aa2822a1495d297903900ae0f0de26d7b0c86d043d3c9'
BASELINE_JOBS_SHA = '694a4e4dcbc2be499879abd837f0b5e399f9cad95caab34716907de15cbbe82f'
JOBCTL_SHA = '61c90260057a405626a24a36ad43303c632f72d2d97929296acdffd748b79d62'
OLD_MANIFEST_SHA = '83ff759b13d380aa8a5e3e786b4ed68887fcce47b51d7f9e80583408e6b08a8a'
OLD_TOOLS = {
    'python_read_probe.py': 'c6bd04ea22d4b368a3eed1cf17642b9418f6e2c0ebc2fc8fde26db92a42df0a8',
    'qualify_candidate.py': '5ac522870dd347fd12dcb723857957918666bddcf59e440f3a1cbe330e6704ba',
    'run_prequalification.py': '99057103d5b4b3149431ebf79c294088c531b24f17dd24baee5a85598b260fd6',
    'test_python_read_bounds.py': 'b2fcba8bf78e895f79cef2b6326b69a76c68f8f8b873b72833023cde8e1d5db1',
    'verify_qualification.py': '212b23cbdfdd24c952f6519db4b13d3036b642b8d6115f38db00306303dbb95f',
}
HISTORICAL_PINS = {
    'prequalification-01/report.json': '3d458a3809f8f1fc3e6b5f28c009d81bf6890a3022cf645eb20b96eb325ecef9',
    'independent-acceptance-01.json': '591f7cf4e301887d15c0d34dc6f10f31786d3b4f6c6e51d44622edc11c62f3ed',
    'tools/manifest.json': OLD_MANIFEST_SHA,
}
REUSED_PINS = {
    'semantic-tests-x230-01.json': '61ec1b0307d6c9b5124e16bd94beeeedaa42d30ed1b5a5cea2a68b6f4ea2c853',
    'component-probe-01/protocol.json': '4e95302b4b1ec5e21b4bb5385976893b2b076799a4d8733d74e42801308e8af2',
    'component-probe-01/raw-cells.jsonl': '47a513ba2fe6a73ca8b5452171bde07c6d986088dfb004c91e4622f627ac1f31',
    'component-probe-01/summary.json': 'e144a0e80d6a68dbe73e835e7b007a149adf533f98b3ca31ebb5da85b64002d4',
    'cargo-empty-wrapper-probe-01/report.json': 'cae75b491c52271b72439018c68059657da72080999894ec15a57b313e71d824',
    'tools/cargo_empty_wrapper_probe.py': '36b257990e6c2b1a80047721d8f0de25af88d55982934b3c5772dfec44702422',
}
NEW_TOOLS = {'qualify_candidate_02.py', 'verify_qualification_02.py', 'run_qualification_02.py'}
SCENARIOS = ['private_small', 'private_64k', 'terminal_small', 'terminal_64k', 'terminal_status', 'live_detached']
ATTEMPT_FILES = ['source-freeze-02.json', 'qualification-launch-02.json', 'qualification-exit-02.json',
                 'qualification-02/report.json', 'qualification-02/source-map.json', 'independent-acceptance-02.json',
                 'qualification-02.launcher.stdout', 'qualification-02.launcher.stderr', 'progress-02.json']


def need(value, message):
    if not value:
        raise ValueError(message)


def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def binding(path):
    path = Path(path)
    need(path.absolute() == path.resolve(), 'symlink in protected path: ' + str(path))
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK | os.O_CLOEXEC)
    try:
        initial = os.fstat(fd)
        need(stat.S_ISREG(initial.st_mode), 'not a regular file: ' + str(path))
        digest, size = hashlib.sha256(), 0
        while True:
            block = os.read(fd, 1024 * 1024)
            if not block:
                break
            digest.update(block)
            size += len(block)
        fields = ('st_dev', 'st_ino', 'st_mode', 'st_nlink', 'st_size', 'st_mtime_ns', 'st_ctime_ns')
        before = tuple(getattr(initial, field) for field in fields)
        need(size == initial.st_size and all(tuple(getattr(s, field) for field in fields) == before
             for s in (os.fstat(fd), path.lstat())), 'protected file changed while read: ' + str(path))
        return {'path': str(path), 'size': size, 'sha256': digest.hexdigest()}
    finally:
        os.close(fd)


def tree(root):
    need(root.is_dir() and root.absolute() == root.resolve(), 'invalid source root')
    files = {}
    for path in sorted(root.rglob('*')):
        mode = path.lstat().st_mode
        need(stat.S_ISDIR(mode) or stat.S_ISREG(mode), 'unsupported source entry')
        if stat.S_ISREG(mode):
            need(path.lstat().st_nlink == 1, 'hardlinked source entry')
            row = binding(path)
            files[path.relative_to(root).as_posix()] = {'size': row['size'], 'sha256': row['sha256']}
    return files


def inputs(files):
    return {p: row['sha256'] for p, row in files.items()
            if p in ('Cargo.toml', 'Cargo.lock', 'rustfmt.toml') or p.startswith(('src/', 'examples/'))}


def save(path, value, replace=False):
    destination = path.with_name(path.name + '.next') if replace else path
    with destination.open('x') as stream:
        json.dump(value, stream, sort_keys=True, indent=2)
        stream.write('\n')
    if replace:
        os.replace(destination, path)


def run_stage(output, row, command, timeout, save_report):
    row.update(argv=command, started_utc=utc(), returncode=None, automatic_retries=0, timed_out=False)
    save_report()
    started, child = time.monotonic(), None
    try:
        with (output / (row['name'] + '.stdout')).open('xb') as stdout, (output / (row['name'] + '.stderr')).open('xb') as stderr:
            # A dedicated group contains only this owned qualification subtree.
            child = subprocess.Popen(command, cwd=output.parent / 'tools', stdin=subprocess.DEVNULL,
                                     stdout=stdout, stderr=stderr, start_new_session=True)
            row['pid'] = child.pid
            save_report()
            try:
                row['returncode'] = child.wait(timeout=timeout)
            except subprocess.TimeoutExpired:
                row['timed_out'] = True
                raise
    except BaseException as error:
        row['error'] = {'type': type(error).__name__, 'message': str(error)}
        if child is not None and child.poll() is None:
            # Never signal an external PID or search-and-kill unrelated jobs.
            try:
                os.killpg(child.pid, signal.SIGTERM)
                row['owned_group_sigterm_sent'] = True
            except ProcessLookupError:
                pass
            try:
                child.wait(timeout=10)
            except subprocess.TimeoutExpired:
                os.killpg(child.pid, signal.SIGKILL)
                row['owned_group_sigkill_sent'] = True
                child.wait(timeout=10)
            row['returncode'] = child.returncode
        raise
    finally:
        row.update(seconds=time.monotonic() - started, finished_utc=utc(),
                   direct_child_reaped=child is not None and child.returncode is not None)
        for stream in ('stdout', 'stderr'):
            path = output / (row['name'] + '.' + stream)
            if path.exists():
                item = binding(path)
                row[stream] = {'path': item['path'], 'bytes': item['size'], 'sha256': item['sha256']}
        save_report()
    need(row['returncode'] == 0, row['name'] + ' failed; no automatic retry')


def self_test():
    with tempfile.TemporaryDirectory() as temporary:
        root = Path(temporary)
        (root / 'tools').mkdir()
        out = root / 'run'
        out.mkdir()
        row = {'name': 'success'}
        run_stage(out, row, [sys.executable, '-B', '-c', 'print("owned stage")'], 5, lambda: None)
        need(row['returncode'] == 0 and row['direct_child_reaped'] and row['stdout']['bytes'] > 0, 'stage success not bound')
        row = {'name': 'failure'}
        try:
            run_stage(out, row, [sys.executable, '-B', '-c', 'raise SystemExit(7)'], 5, lambda: None)
        except ValueError:
            need(row['returncode'] == 7 and 'stderr' in row, 'stage failure not retained')
        else:
            raise AssertionError('nonzero stage accepted')
        row = {'name': 'timeout'}
        try:
            run_stage(out, row, [sys.executable, '-B', '-c', 'import time; time.sleep(5)'], 0.05, lambda: None)
        except subprocess.TimeoutExpired:
            need(row['timed_out'] and row['direct_child_reaped'] and 'stderr' in row, 'timeout not retained')
        else:
            raise AssertionError('timeout accepted')
    print(json.dumps({'self_test': True, 'compilation_started': False, 'checks': 3}))
    return 0


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, default=ROOT)
    parser.add_argument('--expected-jobs-sha256', default=JOBS_SHA)
    parser.add_argument('--expected-manifest-sha256')
    parser.add_argument('--stage-timeout', type=int, default=3600)
    parser.add_argument('--overall-timeout', type=int, default=7200)
    parser.add_argument('--self-test', action='store_true')
    args = parser.parse_args()
    if args.self_test:
        return self_test()
    if not re.fullmatch('[0-9a-f]{64}', args.expected_manifest_sha256 or ''):
        parser.error('--expected-manifest-sha256 must pin the exact new three-tool manifest')
    need(args.expected_jobs_sha256 == JOBS_SHA, 'this resolution is specific to the reviewed revision 3 source')
    need(60 <= args.stage_timeout <= 14400 and 600 <= args.overall_timeout <= 30000, 'invalid timeout')
    need(sys.platform == 'linux' and pwd.getpwuid(os.getuid()).pw_name == 'qian', 'run as qian on X230')
    root = args.root.absolute()
    need(root == ROOT and root.resolve() == root, 'resolution root is fixed to the reviewed R19 experiment')
    output, resolution = root / 'qualification-control-02', root / 'qualification-resolution-02.json'
    need(not os.path.lexists(resolution), 'attempt 02 resolution already exists')
    output.mkdir(mode=0o700)  # Atomic reservation; a second invocation is never admitted.
    report = {'schema': 'hepta-r19-qualification-resolution/v1', 'attempt': 2, 'root': str(root),
              'passed': False, 'started_utc': utc(), 'automatic_retries': 0,
              'candidate_jobs_sha256': JOBS_SHA, 'baseline_jobs_sha256': BASELINE_JOBS_SHA,
              'reason': 'Remove empty Cargo wrapper settings; preserve the rejected first attempt and every original acceptance gate.',
              'checks': {}, 'stages': [], 'historical_evidence': {}, 'reused_evidence': {}, 'attempt02_evidence': {}}
    protected = {}

    def checkpoint():
        save(output / 'report.json', report, replace=True)

    def record(relative, category, expected=None):
        path = root / relative
        row = binding(path)
        need(expected is None or row['sha256'] == expected, 'protected identity differs: ' + relative)
        need(protected.setdefault(str(path), row) == row, 'protected identity changed: ' + relative)
        if category:
            report[category][relative] = row
        return row

    def document(relative, category=None, expected=None):
        record(relative, category, expected)
        return json.loads((root / relative).read_bytes())

    def check(name, condition):
        report['checks'][name] = bool(condition)
        need(condition, name)

    def stable():
        need(all(binding(Path(path)) == identity for path, identity in protected.items()), 'protected evidence or tool changed')

    try:
        checkpoint()
        manifest_path = 'tools/qualification-manifest-02.json'
        manifest = document(manifest_path, expected=args.expected_manifest_sha256)
        check('new_tools_exact_and_bound', set(manifest) == NEW_TOOLS
              and all(re.fullmatch('[0-9a-f]{64}', value) for value in manifest.values()))
        report['tools'], report['tools_manifest'] = manifest, protected[str(root / manifest_path)]
        report['protected_tool_hashes'] = {}
        for name, expected in {**OLD_TOOLS, **manifest}.items():
            record('tools/' + name, None, expected)
            report['protected_tool_hashes']['tools/' + name] = expected
        for relative, expected in HISTORICAL_PINS.items():
            record(relative, 'historical_evidence', expected)
        for relative, expected in REUSED_PINS.items():
            record(relative, 'reused_evidence', expected)
        pre = document('prequalification-01/report.json')
        rejected = document('independent-acceptance-01.json')
        old_manifest = document('tools/manifest.json')
        check('attempt01_rejection_preserved', pre['schema'] == 'hepta-r19-prequalification/v1'
              and pre['passed'] is False and pre['candidate_jobs_sha256'] == JOBS_SHA
              and pre['baseline_jobs_sha256'] == BASELINE_JOBS_SHA and pre['automatic_retries'] == 0
              and rejected['schema'] == 'hepta-r19-independent-acceptance/v1' and rejected['accepted'] is False
              and rejected['checks']['jobctl_release_identical_to_r18'] is False
              and {k for k, v in rejected['checks'].items() if v is False}
                  <= {'jobctl_release_identical_to_r18', 'verification_completed'}
              and old_manifest == pre['tools'] == OLD_TOOLS)
        names = ['semantic-tests', 'component-abba', 'fresh-qualification', 'independent-qualification']
        check('attempt01_stage_results_and_logs_bound', [s['name'] for s in pre['stages']] == names
              and [s['returncode'] for s in pre['stages']] == [0, 0, 0, 1])
        for stage in pre['stages']:
            for stream in ('stdout', 'stderr'):
                relative = 'prequalification-01/' + stage['name'] + '.' + stream
                row = record(relative, 'historical_evidence', stage[stream]['sha256'])
                need(row['path'] == stage[stream]['path'] and row['size'] == stage[stream]['bytes'], 'old stage log binding differs')
        for relative in ('qualification-01/report.json', 'source-freeze-01.json', 'qualification-launch-01.json', 'qualification-exit-01.json'):
            record(relative, 'historical_evidence')
        old_freeze = document('source-freeze-01.json')
        old_qual = document('qualification-01/report.json')
        old_launch = document('qualification-launch-01.json')
        old_exit = document('qualification-exit-01.json')
        actual, baseline = tree(root / 'source'), tree(BASELINE)
        source_inputs = inputs(actual)
        prep = document('preparation.json')
        preparation_tree = {r['path']: {'size': r['size'], 'sha256': r['sha256']} for r in prep['files']}
        check('same_reviewed_source_219_281', len(actual) == len(baseline) == 281 and len(source_inputs) == 219
              and baseline == preparation_tree and actual == old_freeze['source_full_before']
              and source_inputs == old_freeze['source_inputs_before'] == old_qual['source_input'] == old_qual['source_tested'] == old_qual['source_after']
              and old_qual['qualified'] is True and old_exit['success'] is True and old_exit['returncode'] == 0
              and old_exit['report_sha256'] == protected[str(root / 'qualification-01/report.json')]['sha256']
              and old_launch['source_freeze_sha256'] == protected[str(root / 'source-freeze-01.json')]['sha256']
              and {p for p in set(actual) | set(baseline) if actual.get(p) != baseline.get(p)} == {'src/mcp/runtime/jobs.rs'}
              and actual['src/mcp/runtime/jobs.rs']['sha256'] == JOBS_SHA
              and baseline['src/mcp/runtime/jobs.rs']['sha256'] == BASELINE_JOBS_SHA)
        report.update(source_inputs=source_inputs, source_input_count=219, source_full_count=281)
        semantic = document('semantic-tests-x230-01.json')
        protocol = document('component-probe-01/protocol.json')
        component = document('component-probe-01/summary.json')
        rows = [json.loads(line) for line in (root / 'component-probe-01/raw-cells.jsonl').read_text().splitlines() if line.strip()]
        check('successful_semantic_evidence_reused', semantic['successful'] is True and semantic['tests_run'] == 14
              and semantic['failed'] == semantic['errors'] == semantic['skipped'] == 0
              and semantic['source_bindings']['A']['source_sha256'] == BASELINE_JOBS_SHA
              and semantic['source_bindings']['B']['source_sha256'] == JOBS_SHA
              and semantic['test_script_sha256'] == OLD_TOOLS['test_python_read_bounds.py']
              and semantic['probe_script_sha256'] == OLD_TOOLS['python_read_probe.py'])
        check('successful_component_evidence_reused', protocol['schema'] == 'hepta-python-read-component-protocol-v1'
              and protocol['sources']['A']['source_sha256'] == BASELINE_JOBS_SHA and protocol['sources']['B']['source_sha256'] == JOBS_SHA
              and protocol['script_sha256'] == OLD_TOOLS['python_read_probe.py'] and protocol['automatic_retries'] == 0
              and protocol['rounds'] == 4 and protocol['iterations'] == 256 and protocol['warmup'] == 16 and protocol['scenarios'] == SCENARIOS
              and component['all_cells_passed'] is True and component['cells'] == len(rows) == 96
              and component['protocol_sha256'] == REUSED_PINS['component-probe-01/protocol.json']
              and component['raw_cells_sha256'] == REUSED_PINS['component-probe-01/raw-cells.jsonl']
              and [(r['block'], r['scenario'], r['position'], r['variant']) for r in rows]
                  == [(b, s, i, a) for b in range(4) for s in SCENARIOS for i, a in enumerate('ABBA')]
              and all(r['returncode'] == 0 and r['cell']['all_actual_results_equal_expected'] is True
                      and r['cell']['source']['source_sha256'] == (BASELINE_JOBS_SHA if r['variant'] == 'A' else JOBS_SHA) for r in rows))
        diagnostic = document('cargo-empty-wrapper-probe-01/report.json')
        check('empty_wrapper_causality_probe_passed', diagnostic['schema'] == 'hepta-r19-cargo-empty-wrapper-probe/v1'
              and diagnostic['passed'] is True and len(diagnostic['checks']) == 8 and all(v is True for v in diagnostic['checks'].values())
              and diagnostic['automatic_retries'] == 0 and diagnostic['runtime_source_or_targets_modified'] is False
              and [c['label'] for c in diagnostic['cases']] == ['A-unset', 'B-empty', 'A2-unset'])
        for relative in ATTEMPT_FILES + ['target-fresh-02', 'qualification-02', 'qualification-02.reserved', 'qualification-failure-02.json']:
            need(not os.path.lexists(root / relative), 'attempt 02 path already exists: ' + relative)
        check('attempt02_paths_previously_absent', True)
        stable()
        python = ['/usr/bin/python3', '-B']
        commands = [('fresh-qualification', python + [str(root / 'tools/qualify_candidate_02.py'), '--root', str(root),
                    '--expected-jobs-sha256', JOBS_SHA, '--stage-timeout', str(args.stage_timeout)], args.overall_timeout),
                    ('independent-qualification', python + [str(root / 'tools/verify_qualification_02.py'), '--root', str(root),
                    '--expected-jobs-sha256', JOBS_SHA], 600)]
        for name, command, timeout in commands:
            stable()
            row = {'name': name}
            report['stages'].append(row)
            run_stage(output, row, command, timeout, checkpoint)
            stable()
            need(tree(root / 'source') == actual and tree(BASELINE) == baseline, 'source changed during qualification stage')
        for relative in ATTEMPT_FILES:
            record(relative, 'attempt02_evidence')
        for stage in report['stages']:
            for stream in ('stdout', 'stderr'):
                record('qualification-control-02/' + stage['name'] + '.' + stream, 'attempt02_evidence', stage[stream]['sha256'])
        acceptance = document('independent-acceptance-02.json')
        qualification = document('qualification-02/report.json')
        freeze = document('source-freeze-02.json')
        launch = document('qualification-launch-02.json')
        outcome = document('qualification-exit-02.json')
        required = {'all_219_source_bindings_match', 'only_expected_jobs_rs_changed', 'jobctl_release_identical_to_r18',
                    'all_root_artifacts_and_five_tests_fresh_false', 'all_raw_logs_inventories_and_exact_test_verdicts_match',
                    'all_sources_and_evidence_stable_during_verification', 'attempt02_environment_and_qualifier_reaped'}
        check('attempt02_independent_qualification_passed', acceptance['schema'] == 'hepta-r19-independent-acceptance/v1'
              and acceptance['accepted'] is True and acceptance['root'] == str(root) and acceptance['attempt'] == 2
              and required <= set(acceptance['checks']) and all(v is True for v in acceptance['checks'].values())
              and acceptance['source_input_count'] == 219 and acceptance['source_full_count'] == 281
              and acceptance['changed_paths'] == ['src/mcp/runtime/jobs.rs']
              and acceptance['test_counts'] == {'passed': 1637, 'failed': 0, 'ignored': 33, 'selected': 1670}
              and acceptance['qualified_report_sha256'] == protected[str(root / 'qualification-02/report.json')]['sha256']
              and acceptance['source_freeze_sha256'] == protected[str(root / 'source-freeze-02.json')]['sha256']
              and freeze['source_full_before'] == actual and freeze['source_inputs_before'] == source_inputs
              and qualification['source_input'] == qualification['source_tested'] == qualification['source_after'] == source_inputs
              and qualification['qualified'] is True and outcome['success'] is True and outcome['automatic_retries'] == 0)
        report['binaries'] = acceptance['binaries']
        check('actual_release_binaries_and_strict_r18_jobctl_bound', set(acceptance['binaries']) == {'hepta-runtime', 'hepta-runtime-jobctl', 'native_process_driver'}
              and all(binding(Path(row['path'])) == row for row in acceptance['binaries'].values())
              and acceptance['binaries']['hepta-runtime-jobctl']['sha256'] == JOBCTL_SHA
              and launch['launcher_sha256'] == manifest['qualify_candidate_02.py'])
        process = {'pid': launch['qualifier_pid'], 'start_ticks': launch['qualifier_start_ticks'],
                   'reaped': outcome['qualifier_reaped'], 'returncode': outcome['qualifier_returncode'],
                   'proc_absent': not Path('/proc', str(launch['qualifier_pid'])).exists()}
        report['qualifier_process'] = process
        check('direct_qualifier_reaped_and_absent', process['reaped'] is True and process['returncode'] == 0 and process['proc_absent']
              and outcome['qualifier_pid'] == process['pid'] and outcome['qualifier_start_ticks'] == process['start_ticks'])
        stable()
        check('protected_tools_evidence_and_sources_unchanged', tree(root / 'source') == actual and tree(BASELINE) == baseline)
        report['passed'] = all(report['checks'].values()) and len(report['stages']) == 2 and all(s['returncode'] == 0 for s in report['stages'])
    except BaseException as error:
        report['passed'] = False
        report['error'] = {'type': type(error).__name__, 'message': str(error)}
        with (output / 'error.txt').open('x') as stream:
            stream.write(traceback.format_exc())
    finally:
        # Preserve identities of completed and partial attempt 02 outputs even
        # when a nonzero child prevented the normal success path above.
        final_paths = ATTEMPT_FILES + ['qualification-failure-02.json']
        final_paths += ['qualification-control-02/' + stage['name'] + '.' + stream
                        for stage in report['stages'] for stream in ('stdout', 'stderr')]
        for relative in final_paths:
            if (root / relative).exists():
                try:
                    record(relative, 'attempt02_evidence')
                except Exception as error:
                    report['passed'] = False
                    report.setdefault('final_binding_errors', []).append({'path': relative, 'error': str(error)})
        report['finished_utc'] = utc()
        checkpoint()
        save(resolution, report)
        print(json.dumps({'passed': report['passed'], 'resolution': str(resolution),
                          'resolution_sha256': binding(resolution)['sha256'], 'error': report.get('error')}), flush=True)
    return 0 if report['passed'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
