# R32 open_absolute allocation component

This is a small, single-thread Linux component. It calls the exact R24 and R32
`absolute` / `open_absolute` functions on real files and records allocator counts.
It does not run the runtime, SSH, a benchmark user job, or an archived program.
It makes no whole-runtime latency, throughput, concurrency, CPU or RSS claim.

## What is frozen

- `inputs/r24-profile.rs` and `inputs/r32-profile.rs` are complete, hash-pinned
  production files copied from the accepted R24 and frozen R32 candidate.
- `generate.py` slices the original function bytes using unique markers in those
  already pinned files. It does not implement or translate their algorithms.
- `extracted/*.rs` retain the exact function bytes. `src/extracted.rs` places the
  same bytes inside A and B modules with identical imports. Both `absolute`
  functions must be byte-identical. Only the real `open_absolute` bodies differ.
- The copied R24 `Cargo.lock` pins `anyhow 1.0.104` and `libc 0.2.189`; neither has
  a dependency entry. Their exact source/version/checksum entries are copied into
  the component's minimal version-4 lock, together with this new root package.
  Cargo.toml uses exact versions. No runtime Cargo file is changed.
- `input-manifest.json` records the source/function hashes, dependency pins and
  fixed sample protocol. `package-manifest.json` additionally binds every source,
  build script and document in this package.

Read-only reproduction check, which does not compile or run the component:

```sh
python3 -B /absolute/component/path/generate.py --check
```

## Offline x230 build, separately from execution

The original accepted qualifier uses `/home/qian/.cargo/bin/cargo +1.95.0`. Both
dependency versions are already inputs of that qualified runtime. The following
uses its existing registry cache and a new component-only target directory:

```sh
/usr/bin/python3 -B /home/qian/hepta-runtime-r32-allocation-component-20261106/component/build_offline.py \
  --cargo-home /home/qian/hepta-runtime-optimization-20261023/cargo-home-a32-a33-r02 \
  --output /home/qian/hepta-runtime-r32-allocation-component-20261106/build-01
```

The parent directory must exist; `build-01` must not exist. The helper verifies
the frozen bytes, records `cargo` and `rustc` versions, runs exactly one
`cargo +1.95.0 build --offline --locked --release --jobs 1`, and records the
original compiler logs and resulting binary SHA256. It sets CARGO_NET_OFFLINE,
uses a separate target directory, and never executes the component. Missing
cache/toolchain or an invalid lock fails with the original logs; there is no
network fallback or automatic build retry.

The component has **not yet been Rust-compiled or run** in the preparation
session. The lock arrangement is based on the actual accepted lock entries;
successful offline resolution still needs the above build receipt.

## Explicit execution after the parent releases measurement quiet time

```sh
/home/qian/hepta-runtime-r32-allocation-component-20261106/build-01/target/release/hepta-r32-open-absolute-component \
  /home/qian/hepta-runtime-r32-allocation-component-20261106/run-01.jsonl
```

The JSONL output is create-only and synced on normal completion. A failed run
retains its partial raw records. No retry or additional samples are automatic.
The component creates a nonce-named mode-0700 tree below the canonical temporary
directory. Its files are mode 0600. It also opens `/` as the zero-component control
and reads only its own `/proc/self/fd` / `/proc/self/task` and host/kernel metadata.
The temporary pathname must satisfy the production function's existing path
syntax rules. This is Linux coverage; the Mac runtime does not compile this module.

## Counting and functional checks

Both arms use the same harness and `GlobalAlloc` delegating to `System`. The count
switch surrounds only the original function call and destruction of its returned
owned descriptor. The returned `File` becomes an `OwnedFd` and is dropped every
time. Its actual dev/inode/type is checked, `fcntl(F_GETFD)` must then report EBADF,
and the full own-process FD inventory must be unchanged after each block.
The process checks that it has one actual Linux thread.

Fixture creation, `fstat`, FD enumeration, error handling, formatting and output
are outside the count switch. Allocator callbacks do no logging, locking or
allocation. Counters separately record alloc, alloc_zeroed, realloc, dealloc and
their requested byte totals. `realloc_requested_bytes` sums each new requested
size, not the incremental growth or retained/live memory. Successful blocks
require alloc + alloc_zeroed == dealloc; realloc does not add a live allocation.

Controls run outside the measured counters: real shallow/deep files and
directories, root with both directory flags, repeated separators/trailing slash,
empty/relative/dot/dotdot/non-UTF8 syntax, file-as-directory, leaf and parent
symlinks. A and B must agree on the error text and OS errno where present. Every
success is checked against the known fixture inode; FD recovery is independent
of function return values.

For each fixed shape (`root`, `shallow_file`, `deep_file`, `directory`), warmup is
one ABBA cycle of 16 calls per block. Measurement is 16 ABBA rounds of 64 calls per
block: 256 raw sample rows, 16,384 measured calls total. Each raw row records case,
round, position, arm, original function SHA, Normal-component count, completed
calls, all allocator counters and functional/FD outcome. Raw rows are flushed
before any case summary is written.

The final `passed` means functional checks, own-FD recovery and fixture cleanup
completed. Allocation benefit is reported separately by each case's
`B_fewer_allocation_and_reallocation_calls`; root is expected to show no Vec
saving. A reduction is evidence only about these instrumented real function
calls. No duration is measured, and counter instrumentation is not used to claim
a latency or whole-runtime improvement.
