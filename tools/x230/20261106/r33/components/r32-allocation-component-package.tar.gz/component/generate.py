#!/usr/bin/env python3
# Copyright 2026 TrillionniumFoundation; SPDX-License-Identifier: Apache-2.0
"""Extract pinned real functions and two existing dependency pins; never build/run."""
import argparse
import hashlib
import json
from pathlib import Path
import tomllib

ROOT = Path(__file__).resolve().parent
PACKAGE = 'hepta-r32-open-absolute-component'
PINS = {
    'r24-profile.rs': 'a62169343c2a08c38d69925f33fdc7551cf4be7b4b7f50cf89683f652a8f853a',
    'r32-profile.rs': '525d5b71600c53f1bedfcad89f9c1cfb590b80e38d5fb88bf0a00bf9b7b20d77',
    'R24.Cargo.lock': '15b9fb468eb34a210238657d132cbf19e961552d1313de488e1f14936bfa4e5f',
    'r32-candidate-manifest.json': 'e1969d047545c70a857c733f3318b0c33140a3a8b6b0b85c2505f8457282985a',
}
PROTOCOL = {'rounds': 16, 'calls_per_block': 64, 'warmup_calls_per_block': 16,
            'order': ['A', 'B', 'B', 'A'],
            'shapes': ['root', 'shallow_file', 'deep_file', 'directory'],
            'timing_is_performance_evidence': False}


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def extract(source, name, next_marker):
    marker = ('pub(super) fn ' + name + '(').encode()
    assert source.count(marker) == source.count(next_marker) == 1
    start = source.index(marker)
    end = source.index(next_marker, start)
    result = source[start:end]
    assert result.endswith(b'}\n')
    return result


def expected_files():
    sources = {name: (ROOT / 'inputs' / name).read_bytes() for name in PINS}
    assert all(sha(sources[name]) == expected for name, expected in PINS.items())
    output, arms, modules = {}, [], []
    for arm, source_name in [('A', 'r24-profile.rs'), ('B', 'r32-profile.rs')]:
        source = sources[source_name]
        absolute = extract(source, 'absolute', b'\n/// Every component is resolved')
        opened = extract(source, 'open_absolute', b'\npub(super) fn private_directory(')
        output[f'extracted/{arm}_absolute.rs'] = absolute
        output[f'extracted/{arm}_open_absolute.rs'] = opened
        arms.append({'arm': arm, 'source_sha256': sha(source),
                     'absolute_sha256': sha(absolute), 'open_absolute_sha256': sha(opened)})
        imports = ('use anyhow::{bail, Context, Result};\nuse std::fs::File;\n'
                   'use std::os::fd::{AsRawFd, FromRawFd};\nuse std::path::{Component, Path};\n')
        modules.append(f'mod {arm.lower()} {{\n'.encode() + imports.encode()
                       + absolute + b'\n' + opened + b'}\n')
    assert output['extracted/A_absolute.rs'] == output['extracted/B_absolute.rs']
    declarations = ['const ARMS: [Arm; 2] = [']
    for row in arms:
        declarations.append('    Arm { name: "' + row['arm'] + '", source_sha: "' + row['source_sha256']
                            + '", absolute_sha: "' + row['absolute_sha256'] + '", open_sha: "'
                            + row['open_absolute_sha256'] + '", open: ' + row['arm'].lower() + '::open_absolute },')
    declarations.extend(['];', 'const ROUNDS: usize = 16;', 'const CALLS: usize = 64;',
                         'const WARMUP_CALLS: usize = 16;', 'const ORDER: [usize; 4] = [0, 1, 1, 0];'])
    header = b'// Copyright 2026 Muvon Un Limited\n// Copyright 2026 TrillionniumFoundation; SPDX-License-Identifier: Apache-2.0\n// Generated from pinned real source; function bytes are unchanged.\n'
    output['src/extracted.rs'] = header + b'\n'.join(modules) + ('\n'.join(declarations) + '\n').encode()
    lock = tomllib.loads(sources['R24.Cargo.lock'].decode())
    dependencies = []
    for name in ['anyhow', 'libc']:
        found = [row for row in lock['package'] if row['name'] == name]
        assert len(found) == 1 and set(found[0]) == {'name', 'version', 'source', 'checksum'}
        dependencies.append(found[0])
    manifest = ('[package]\nname = "' + PACKAGE + '"\nversion = "0.1.0"\nedition = "2021"\n'
                'rust-version = "1.95"\nlicense = "Apache-2.0"\npublish = false\n\n[workspace]\n\n[dependencies]\n')
    manifest += ''.join(row['name'] + ' = "=' + row['version'] + '"\n' for row in dependencies)
    manifest += '\n[profile.release]\nopt-level = 3\nlto = true\ncodegen-units = 1\npanic = "abort"\nstrip = true\n'
    output['Cargo.toml'] = manifest.encode()
    packages = dependencies + [{'name': PACKAGE, 'version': '0.1.0', 'dependencies': ['anyhow', 'libc']}]
    minimal = '# Dependency entries copied exactly from the accepted R24 lock.\nversion = 4\n'
    for row in sorted(packages, key=lambda item: item['name']):
        minimal += '\n[[package]]\n'
        for key in ['name', 'version', 'source', 'checksum']:
            if key in row:
                minimal += key + ' = ' + json.dumps(row[key]) + '\n'
        if 'dependencies' in row:
            minimal += 'dependencies = [\n "anyhow",\n "libc",\n]\n'
    output['Cargo.lock'] = minimal.encode()
    receipt = {'schema': 'hepta-r32-allocation-component-input/v1', 'input_sha256': PINS,
               'arms': arms, 'dependency_pins': dependencies, 'protocol': PROTOCOL,
               'generated_sha256': {name: sha(raw) for name, raw in sorted(output.items())}}
    output['input-manifest.json'] = (json.dumps(receipt, indent=2, sort_keys=True) + '\n').encode()
    return output


def check():
    expected = expected_files()
    assert all((ROOT / name).read_bytes() == raw for name, raw in expected.items()), 'generated bytes differ'
    return expected


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    mode = parser.add_mutually_exclusive_group(required=True)
    mode.add_argument('--write', action='store_true')
    mode.add_argument('--check', action='store_true')
    args = parser.parse_args()
    if args.write:
        for name, raw in expected_files().items():
            path = ROOT / name
            path.parent.mkdir(parents=True, exist_ok=True)
            with path.open('xb') as stream:
                stream.write(raw)
    else:
        check()
    print(json.dumps({'generated_bytes_match': True, 'build_executed': False, 'component_executed': False}))
