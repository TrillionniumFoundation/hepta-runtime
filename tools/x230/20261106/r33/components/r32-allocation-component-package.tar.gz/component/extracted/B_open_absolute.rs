pub(super) fn open_absolute(path: &Path, directory: bool) -> Result<File> {
	absolute(path)?;
	let mut current = File::open("/")?;
	let mut parts = path
		.components()
		.filter_map(|v| match v {
			Component::Normal(v) => Some(v),
			_ => None,
		})
		.peekable();
	while let Some(part) = parts.next() {
		let name = std::ffi::CString::new(part.as_encoded_bytes())?;
		let flags = libc::O_RDONLY
			| libc::O_NOFOLLOW
			| libc::O_NONBLOCK
			| libc::O_CLOEXEC
			| if parts.peek().is_some() || directory {
				libc::O_DIRECTORY
			} else {
				0
			};
		let fd = unsafe { libc::openat(current.as_raw_fd(), name.as_ptr(), flags) };
		if fd < 0 {
			return Err(std::io::Error::last_os_error().into());
		}
		current = unsafe { File::from_raw_fd(fd) };
	}
	Ok(current)
}
