// Copyright 2026 Muvon Un Limited
// Copyright 2026 TrillionniumFoundation; SPDX-License-Identifier: Apache-2.0
// Generated from pinned real source; function bytes are unchanged.
mod a {
use anyhow::{bail, Context, Result};
use std::fs::File;
use std::os::fd::{AsRawFd, FromRawFd};
use std::path::{Component, Path};
pub(super) fn absolute(path: &Path) -> Result<()> {
	let text = path
		.to_str()
		.context("observation profile path is not UTF-8")?;
	if !path.is_absolute()
		|| text.len() > 4096
		|| text.chars().any(|v| {
			v.is_control()
				|| v.is_whitespace()
				|| matches!(v, '%' | '~' | '$' | '`' | '\'' | '"' | '\\')
		}) || text.split('/').any(|v| matches!(v, "." | ".."))
	{
		bail!("unsupported observation profile path");
	}
	Ok(())
}

pub(super) fn open_absolute(path: &Path, directory: bool) -> Result<File> {
	absolute(path)?;
	let mut current = File::open("/")?;
	let parts: Vec<_> = path
		.components()
		.filter_map(|v| match v {
			Component::Normal(v) => Some(v),
			_ => None,
		})
		.collect();
	for (index, part) in parts.iter().enumerate() {
		let name = std::ffi::CString::new(part.as_encoded_bytes())?;
		let flags = libc::O_RDONLY
			| libc::O_NOFOLLOW
			| libc::O_NONBLOCK
			| libc::O_CLOEXEC
			| if index + 1 < parts.len() || directory {
				libc::O_DIRECTORY
			} else {
				0
			};
		let fd = unsafe { libc::openat(current.as_raw_fd(), name.as_ptr(), flags) };
		if fd < 0 {
			return Err(std::io::Error::last_os_error().into());
		}
		current = unsafe { File::from_raw_fd(fd) };
	}
	Ok(current)
}
}

mod b {
use anyhow::{bail, Context, Result};
use std::fs::File;
use std::os::fd::{AsRawFd, FromRawFd};
use std::path::{Component, Path};
pub(super) fn absolute(path: &Path) -> Result<()> {
	let text = path
		.to_str()
		.context("observation profile path is not UTF-8")?;
	if !path.is_absolute()
		|| text.len() > 4096
		|| text.chars().any(|v| {
			v.is_control()
				|| v.is_whitespace()
				|| matches!(v, '%' | '~' | '$' | '`' | '\'' | '"' | '\\')
		}) || text.split('/').any(|v| matches!(v, "." | ".."))
	{
		bail!("unsupported observation profile path");
	}
	Ok(())
}

pub(super) fn open_absolute(path: &Path, directory: bool) -> Result<File> {
	absolute(path)?;
	let mut current = File::open("/")?;
	let mut parts = path
		.components()
		.filter_map(|v| match v {
			Component::Normal(v) => Some(v),
			_ => None,
		})
		.peekable();
	while let Some(part) = parts.next() {
		let name = std::ffi::CString::new(part.as_encoded_bytes())?;
		let flags = libc::O_RDONLY
			| libc::O_NOFOLLOW
			| libc::O_NONBLOCK
			| libc::O_CLOEXEC
			| if parts.peek().is_some() || directory {
				libc::O_DIRECTORY
			} else {
				0
			};
		let fd = unsafe { libc::openat(current.as_raw_fd(), name.as_ptr(), flags) };
		if fd < 0 {
			return Err(std::io::Error::last_os_error().into());
		}
		current = unsafe { File::from_raw_fd(fd) };
	}
	Ok(current)
}
}
const ARMS: [Arm; 2] = [
    Arm { name: "A", source_sha: "a62169343c2a08c38d69925f33fdc7551cf4be7b4b7f50cf89683f652a8f853a", absolute_sha: "abcbace6885c69e01809cce9f7521ed9c4c274dcea82ebad706ddd9b33a22251", open_sha: "ff5b6f0c618543d79095c47bc98127919b7ea8c84593743d8afd1b7055498111", open: a::open_absolute },
    Arm { name: "B", source_sha: "525d5b71600c53f1bedfcad89f9c1cfb590b80e38d5fb88bf0a00bf9b7b20d77", absolute_sha: "abcbace6885c69e01809cce9f7521ed9c4c274dcea82ebad706ddd9b33a22251", open_sha: "d5c5c7187989df822a86fe01392b242f2530492967aa1ba3f7a64259be308e52", open: b::open_absolute },
];
const ROUNDS: usize = 16;
const CALLS: usize = 64;
const WARMUP_CALLS: usize = 16;
const ORDER: [usize; 4] = [0, 1, 1, 0];
