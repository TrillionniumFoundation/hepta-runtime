// Copyright 2026 TrillionniumFoundation; SPDX-License-Identifier: Apache-2.0
//! Real R24/R32 open_absolute calls: allocation counters, private fixtures, raw ABBA.
#[cfg(not(target_os = "linux"))]
compile_error!("This component requires Linux and /proc/self; it is not a Mac test.");

use anyhow::{ensure, Context, Result};
use std::alloc::{GlobalAlloc, Layout, System};
use std::fs::{self, DirBuilder, File, OpenOptions};
use std::hint::black_box;
use std::io::{BufWriter, Read, Write};
use std::os::fd::{AsRawFd, OwnedFd};
use std::os::unix::ffi::OsStrExt;
use std::os::unix::fs::{symlink, DirBuilderExt, MetadataExt, OpenOptionsExt};
use std::path::{Component, Path, PathBuf};
use std::sync::atomic::{AtomicBool, AtomicU64, Ordering::Relaxed};

static ENABLED: AtomicBool = AtomicBool::new(false);
static COUNTERS: [AtomicU64; 8] = [const { AtomicU64::new(0) }; 8];
struct CountingSystem;

// No formatting, locks, allocation, or I/O occurs in the callbacks. The measured
// process is single-threaded; snapshots and all reporting occur with counting off.
unsafe impl GlobalAlloc for CountingSystem {
	unsafe fn alloc(&self, layout: Layout) -> *mut u8 {
		if ENABLED.load(Relaxed) {
			COUNTERS[0].fetch_add(1, Relaxed);
			COUNTERS[4].fetch_add(layout.size() as u64, Relaxed);
		}
		unsafe { System.alloc(layout) }
	}
	unsafe fn alloc_zeroed(&self, layout: Layout) -> *mut u8 {
		if ENABLED.load(Relaxed) {
			COUNTERS[1].fetch_add(1, Relaxed);
			COUNTERS[5].fetch_add(layout.size() as u64, Relaxed);
		}
		unsafe { System.alloc_zeroed(layout) }
	}
	unsafe fn realloc(&self, pointer: *mut u8, layout: Layout, size: usize) -> *mut u8 {
		if ENABLED.load(Relaxed) {
			COUNTERS[2].fetch_add(1, Relaxed);
			COUNTERS[6].fetch_add(size as u64, Relaxed);
		}
		unsafe { System.realloc(pointer, layout, size) }
	}
	unsafe fn dealloc(&self, pointer: *mut u8, layout: Layout) {
		if ENABLED.load(Relaxed) {
			COUNTERS[3].fetch_add(1, Relaxed);
			COUNTERS[7].fetch_add(layout.size() as u64, Relaxed);
		}
		unsafe { System.dealloc(pointer, layout) }
	}
}

#[global_allocator]
static ALLOCATOR: CountingSystem = CountingSystem;

#[derive(Clone, Copy)]
struct Arm {
	name: &'static str,
	source_sha: &'static str,
	absolute_sha: &'static str,
	open_sha: &'static str,
	open: fn(&Path, bool) -> Result<File>,
}
include!("extracted.rs");

type Counts = [u64; 8];
fn reset() {
	for counter in &COUNTERS {
		counter.store(0, Relaxed);
	}
}
fn counts() -> Counts {
	std::array::from_fn(|index| COUNTERS[index].load(Relaxed))
}
fn counts_json(value: Counts) -> String {
	format!(
		r#"{{"alloc":{},"alloc_zeroed":{},"realloc":{},"dealloc":{},"alloc_bytes":{},"alloc_zeroed_bytes":{},"realloc_requested_bytes":{},"dealloc_bytes":{}}}"#,
		value[0], value[1], value[2], value[3], value[4], value[5], value[6], value[7]
	)
}
fn quoted(value: &str) -> String {
	let mut out = String::from("\"");
	for character in value.chars() {
		match character {
			'"' => out.push_str("\\\""),
			'\\' => out.push_str("\\\\"),
			value if value < ' ' => out.push_str(&format!("\\u{:04x}", value as u32)),
			value => out.push(value),
		}
	}
	out.push('"');
	out
}
fn emit(output: &mut BufWriter<File>, line: String) -> Result<()> {
	ensure!(!ENABLED.load(Relaxed), "reporting inside the allocation scope");
	writeln!(output, "{line}")?;
	output.flush()?;
	Ok(())
}

fn fd_snapshot() -> Result<Vec<i32>> {
	let mut entries = Vec::new();
	for entry in fs::read_dir("/proc/self/fd")? {
		entries.push(entry?.file_name().to_string_lossy().parse::<i32>()?);
	}
	// read_dir's own descriptor is now closed; do not count its stale entry.
	entries.retain(|fd| (unsafe { libc::fcntl(*fd, libc::F_GETFD) }) >= 0);
	entries.sort_unstable();
	Ok(entries)
}
fn single_thread() -> Result<()> {
	let mut count = 0;
	for entry in fs::read_dir("/proc/self/task")? {
		entry?;
		count += 1;
	}
	ensure!(count == 1, "allocation scope requires one actual Linux thread");
	Ok(())
}
fn closed(fd: i32) -> Result<()> {
	let result = unsafe { libc::fcntl(fd, libc::F_GETFD) };
	ensure!(
		result == -1 && std::io::Error::last_os_error().raw_os_error() == Some(libc::EBADF),
		"owned descriptor was not closed"
	);
	Ok(())
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
struct Identity(u64, u64, u32);
fn identity(metadata: &fs::Metadata) -> Identity {
	Identity(metadata.dev(), metadata.ino(), metadata.mode() & libc::S_IFMT)
}
struct Fixture {
	root: PathBuf,
	identity: Identity,
	removed: bool,
}
impl Fixture {
	fn new() -> Result<Self> {
		let mut nonce = [0u8; 16];
		File::open("/dev/urandom")?.read_exact(&mut nonce)?;
		let suffix: String = nonce.iter().map(|byte| format!("{byte:02x}")).collect();
		let root = fs::canonicalize(std::env::temp_dir())?.join(format!("hepta-r32-alloc-{suffix}"));
		DirBuilder::new().mode(0o700).create(&root)?;
		let stamp = identity(&fs::symlink_metadata(&root)?);
		Ok(Self { root, identity: stamp, removed: false })
	}
	fn cleanup(&mut self) -> Result<()> {
		if !self.removed {
			let now = fs::symlink_metadata(&self.root)?;
			ensure!(identity(&now) == self.identity && now.uid() == unsafe { libc::geteuid() },
				"fixture root changed; refusing to remove a replacement");
			fs::remove_dir_all(&self.root)?;
			self.removed = true;
		}
		Ok(())
	}
}
impl Drop for Fixture {
	fn drop(&mut self) {
		let _ = self.cleanup();
	}
}

struct Case {
	name: &'static str,
	path: PathBuf,
	directory: bool,
	expected: Identity,
}
fn cases(fixture: &Fixture) -> Result<Vec<Case>> {
	let shallow = fixture.root.join("leaf");
	OpenOptions::new().create_new(true).write(true).mode(0o600).open(&shallow)?
		.write_all(b"component-owned-file")?;
	let mut deep = fixture.root.clone();
	for name in ["d1", "d2", "d3", "d4", "d5", "d6"] {
		deep.push(name);
		DirBuilder::new().mode(0o700).create(&deep)?;
	}
	let directory = deep.clone();
	deep.push("leaf");
	OpenOptions::new().create_new(true).write(true).mode(0o600).open(&deep)?
		.write_all(b"component-owned-deep-file")?;
	[("root", PathBuf::from("/"), true), ("shallow_file", shallow, false),
	 ("deep_file", deep, false), ("directory", directory, true)]
		.into_iter().map(|(name, path, directory)| {
			let expected = identity(&fs::metadata(&path)?);
			Ok(Case { name, path, directory, expected })
		}).collect()
}

// Only the original call and destruction of its returned owned FD are counted.
// fstat, the EBADF check, FD inventory, error formatting and output are outside.
fn checked_call(arm: Arm, case: &Case, count: bool) -> Result<()> {
	ENABLED.store(count, Relaxed);
	let result = black_box(arm.open)(black_box(case.path.as_path()), black_box(case.directory));
	ENABLED.store(false, Relaxed);
	let file = result.with_context(|| format!("arm {} case {} open failed", arm.name, case.name))?;
	let observed = file.metadata();
	let owned: OwnedFd = file.into();
	let fd = owned.as_raw_fd();
	ENABLED.store(count, Relaxed);
	drop(owned);
	ENABLED.store(false, Relaxed);
	closed(fd)?;
	ensure!(identity(&observed?) == case.expected, "opened descriptor identity differs");
	Ok(())
}

fn controls(output: &mut BufWriter<File>, fixture: &Fixture, cases: &[Case]) -> Result<()> {
	for case in cases {
		for arm in ARMS {
			checked_call(arm, case, false)?;
		}
	}
	let repeated = Case { name: "repeated_separators_and_tail", path: PathBuf::from(
		format!("/{}///leaf/", fixture.root.display())), directory: false, expected: cases[1].expected };
	let root_file = Case { name: "root_without_directory_flag", path: PathBuf::from("/"),
		directory: false, expected: cases[0].expected };
	for case in [repeated, root_file] {
		for arm in ARMS {
			checked_call(arm, &case, false)?;
		}
		emit(output, format!(r#"{{"kind":"control","name":{},"both_arms_matched":true}}"#, quoted(case.name)))?;
	}
	let leaf_alias = fixture.root.join("leaf_alias");
	let parent_alias = fixture.root.join("parent_alias");
	symlink(&cases[1].path, &leaf_alias)?;
	symlink(&cases[3].path, &parent_alias)?;
	let invalid = [
		("empty", PathBuf::from(""), false), ("relative", PathBuf::from("relative"), false),
		("dot", fixture.root.join("./leaf"), false), ("dotdot", fixture.root.join("d1/../leaf"), false),
		("non_utf8", PathBuf::from(std::ffi::OsStr::from_bytes(b"/invalid/\xff")), false),
		("file_as_directory", cases[1].path.clone(), true),
		("leaf_symlink", leaf_alias, false), ("parent_symlink", parent_alias.join("leaf"), false),
	];
	for (name, path, directory) in invalid {
		let mut outcomes = Vec::new();
		let fds = fd_snapshot()?;
		for arm in ARMS {
			let error = (arm.open)(&path, directory).err()
				.with_context(|| format!("arm {} accepted invalid control {name}", arm.name))?;
			let errno = error.downcast_ref::<std::io::Error>().and_then(|error| error.raw_os_error());
			outcomes.push((errno, error.to_string()));
			ensure!(fd_snapshot()? == fds, "arm {} control {name} leaked descriptors", arm.name);
		}
		ensure!(outcomes[0] == outcomes[1], "error outcome differs for {name}");
		let errno = outcomes[0].0.map_or_else(|| "null".into(), |value| value.to_string());
		emit(output, format!(r#"{{"kind":"control","name":{},"both_arms_matched":true,"errno":{},"error":{}}}"#,
			quoted(name), errno, quoted(&outcomes[0].1)))?;
	}
	Ok(())
}

fn block(output: &mut BufWriter<File>, case: &Case, arm: Arm, round: usize, position: usize,
	fds: &[i32]) -> Result<Counts> {
	reset();
	let mut completed = 0;
	let result = (|| -> Result<()> {
		for _ in 0..CALLS {
			checked_call(arm, case, true)?;
			completed += 1;
		}
		ensure!(fd_snapshot()?.as_slice() == fds, "descriptor inventory changed within measured block");
		let value = counts();
		ensure!(value[0] + value[1] == value[3], "successful calls left scoped allocations unbalanced");
		Ok(())
	})();
	let value = counts();
	let error = result.as_ref().err().map_or_else(|| "null".into(), |error| quoted(&error.to_string()));
	emit(output, format!(r#"{{"kind":"sample","case":{},"round":{},"position":{},"arm":{},"open_absolute_sha256":{},"normal_components":{},"completed_calls":{},"counts":{},"functional_and_fd_ok":{},"error":{}}}"#,
		quoted(case.name), round, position, quoted(arm.name), quoted(arm.open_sha),
		case.path.components().filter(|part| matches!(part, Component::Normal(_))).count(),
		completed, counts_json(value), result.is_ok(), error))?;
	result?;
	Ok(value)
}

fn exercise(output: &mut BufWriter<File>, fixture: &Fixture, fds: &[i32]) -> Result<()> {
	single_thread()?;
	let cases = cases(fixture)?;
	controls(output, fixture, &cases)?;
	ensure!(fd_snapshot()?.as_slice() == fds, "functional controls leaked descriptors");
	for case in &cases {
		for index in ORDER {
			for _ in 0..WARMUP_CALLS {
				checked_call(ARMS[index], case, false)?;
			}
		}
		let mut totals = [[0u64; 8]; 2];
		for round in 0..ROUNDS {
			for (position, index) in ORDER.into_iter().enumerate() {
				let value = block(output, case, ARMS[index], round, position, fds)?;
				for (total, count) in totals[index].iter_mut().zip(value) {
					*total += count;
				}
			}
		}
		let allocation_calls = |value: Counts| value[0] + value[1] + value[2];
		emit(output, format!(r#"{{"kind":"case_summary","case":{},"calls_per_arm":{},"A":{},"B":{},"B_fewer_allocation_and_reallocation_calls":{},"whole_runtime_claim":false}}"#,
			quoted(case.name), ROUNDS * 2 * CALLS, counts_json(totals[0]), counts_json(totals[1]),
			allocation_calls(totals[1]) < allocation_calls(totals[0])))?;
	}
	single_thread()?;
	Ok(())
}

fn run() -> Result<()> {
	let mut arguments = std::env::args_os().skip(1);
	let output_path = PathBuf::from(arguments.next().context("usage: hepta-r32-open-absolute-component NEW_RAW_JSONL")?);
	ensure!(arguments.next().is_none(), "one create-only output path is required");
	let file = OpenOptions::new().create_new(true).write(true).mode(0o600)
		.custom_flags(libc::O_NOFOLLOW | libc::O_CLOEXEC).open(&output_path)?;
	let mut output = BufWriter::new(file);
	let mut fixture = Fixture::new()?;
	let hostname = fs::read_to_string("/proc/sys/kernel/hostname")?;
	let kernel = fs::read_to_string("/proc/sys/kernel/osrelease")?;
	emit(&mut output, format!(r#"{{"kind":"header","schema":"hepta-r32-open-absolute-allocation/v1","hostname":{},"kernel":{},"arch":{},"pid":{},"fixture_root":{},"rounds":{},"calls_per_block":{},"warmup_calls_per_block":{},"order":["A","B","B","A"],"timing_is_performance_evidence":false,"scope":"instrumented real Rust functions; no whole-runtime claim"}}"#,
		quoted(hostname.trim()), quoted(kernel.trim()), quoted(std::env::consts::ARCH), std::process::id(),
		quoted(&fixture.root.to_string_lossy()), ROUNDS, CALLS, WARMUP_CALLS))?;
	for arm in ARMS {
		emit(&mut output, format!(r#"{{"kind":"source","arm":{},"source_sha256":{},"absolute_sha256":{},"open_absolute_sha256":{}}}"#,
			quoted(arm.name), quoted(arm.source_sha), quoted(arm.absolute_sha), quoted(arm.open_sha)))?;
	}
	let fds = fd_snapshot()?;
	let result = exercise(&mut output, &fixture, &fds);
	let cleanup = fixture.cleanup();
	let final_fds = fd_snapshot();
	let fd_match = final_fds.as_ref().is_ok_and(|value| value == &fds);
	let passed = result.is_ok() && cleanup.is_ok() && fd_match;
	let errors = [result.as_ref().err(), cleanup.as_ref().err(), final_fds.as_ref().err()]
		.into_iter().flatten().map(|error| quoted(&error.to_string())).collect::<Vec<_>>().join(",");
	emit(&mut output, format!(r#"{{"kind":"summary","functional_passed":{},"fixture_removed":{},"fd_inventory_unchanged":{},"passed":{},"expected_sample_rows":{},"automatic_rerun":false,"whole_runtime_claim":false,"errors":[{}]}}"#,
		result.is_ok(), fixture.removed, fd_match, passed, 4 * ROUNDS * ORDER.len(), errors))?;
	output.get_ref().sync_all()?;
	ensure!(passed, "component did not close successfully; original raw output is retained");
	println!("component completed; raw evidence: {}", output_path.display());
	Ok(())
}

fn main() {
	if let Err(error) = run() {
		eprintln!("{error:#}");
		std::process::exit(1);
	}
}
