// Copyright 2026 Muvon Un Limited
// Copyright 2026 TrillionniumFoundation; SPDX-License-Identifier: Apache-2.0
// Original function/method/expression bytes are unchanged; adapters are component-only.
mod a {
use anyhow::{bail, Context, Result};
use std::fs::File;
use std::os::fd::{AsRawFd, FromRawFd};
use std::path::{Component, Path};
pub(super) fn absolute(path: &Path) -> Result<()> {
	let text = path
		.to_str()
		.context("observation profile path is not UTF-8")?;
	if !path.is_absolute()
		|| text.len() > 4096
		|| text.chars().any(|v| {
			v.is_control()
				|| v.is_whitespace()
				|| matches!(v, '%' | '~' | '$' | '`' | '\'' | '"' | '\\')
		}) || text.split('/').any(|v| matches!(v, "." | ".."))
	{
		bail!("unsupported observation profile path");
	}
	Ok(())
}

pub(super) fn open_absolute(path: &Path, directory: bool) -> Result<File> {
	absolute(path)?;
	let mut current = File::open("/")?;
	let parts: Vec<_> = path
		.components()
		.filter_map(|v| match v {
			Component::Normal(v) => Some(v),
			_ => None,
		})
		.collect();
	for (index, part) in parts.iter().enumerate() {
		let name = std::ffi::CString::new(part.as_encoded_bytes())?;
		let flags = libc::O_RDONLY
			| libc::O_NOFOLLOW
			| libc::O_NONBLOCK
			| libc::O_CLOEXEC
			| if index + 1 < parts.len() || directory {
				libc::O_DIRECTORY
			} else {
				0
			};
		let fd = unsafe { libc::openat(current.as_raw_fd(), name.as_ptr(), flags) };
		if fd < 0 {
			return Err(std::io::Error::last_os_error().into());
		}
		current = unsafe { File::from_raw_fd(fd) };
	}
	Ok(current)
}
}

mod b {
use anyhow::{bail, Context, Result};
use std::fs::File;
use std::os::fd::{AsRawFd, FromRawFd};
use std::path::{Component, Path};
use std::sync::Arc;
pub(super) fn absolute(path: &Path) -> Result<()> {
	let text = path
		.to_str()
		.context("observation profile path is not UTF-8")?;
	if !path.is_absolute()
		|| text.len() > 4096
		|| text.chars().any(|v| {
			v.is_control()
				|| v.is_whitespace()
				|| matches!(v, '%' | '~' | '$' | '`' | '\'' | '"' | '\\')
		}) || text.split('/').any(|v| matches!(v, "." | ".."))
	{
		bail!("unsupported observation profile path");
	}
	Ok(())
}

pub(super) struct PinnedFile {
	path_components: Arc<[std::ffi::CString]>,
}
impl PinnedFile {
	pub(super) fn from_validated_path(path: &Path) -> Result<Self> {
		let path_components = path
			.components()
			.filter_map(|part| match part {
				Component::Normal(part) => Some(part),
				_ => None,
			})
			.map(|part| std::ffi::CString::new(part.as_encoded_bytes()))
			.collect::<std::result::Result<Vec<_>, _>>()?
			.into();
		Ok(Self { path_components })
	}
	fn open_path(&self) -> Result<File> {
		// Start at a fresh root descriptor on every check. Cached names never
		// stand in for resolving the current directories and final inode.
		let mut current = File::open("/")?;
		for (index, name) in self.path_components.iter().enumerate() {
			let flags = libc::O_RDONLY
				| libc::O_NOFOLLOW
				| libc::O_NONBLOCK
				| libc::O_CLOEXEC
				| if index + 1 < self.path_components.len() {
					libc::O_DIRECTORY
				} else {
					0
				};
			let fd = unsafe { libc::openat(current.as_raw_fd(), name.as_ptr(), flags) };
			if fd < 0 {
				return Err(std::io::Error::last_os_error().into());
			}
			current = unsafe { File::from_raw_fd(fd) };
		}
		Ok(current)
	}
	pub(super) fn component_open(&self) -> Result<File> { self.open_path() }
	pub(super) fn cache_shape(&self) -> (usize, usize, usize) {
		(self.path_components.len(),
		 self.path_components.iter().map(|name| name.as_bytes_with_nul().len()).sum(),
		 self.path_components.len() * std::mem::size_of::<std::ffi::CString>())
	}
}
}
fn open_a(path: &Path, _: &b::PinnedFile) -> Result<File> { a::open_absolute(path, false) }
fn open_b(_: &Path, cache: &b::PinnedFile) -> Result<File> { cache.component_open() }
const ARMS: [Arm; 2] = [
    Arm { name: "A", source_sha: "a62169343c2a08c38d69925f33fdc7551cf4be7b4b7f50cf89683f652a8f853a", absolute_sha: "abcbace6885c69e01809cce9f7521ed9c4c274dcea82ebad706ddd9b33a22251", open_sha: "ff5b6f0c618543d79095c47bc98127919b7ea8c84593743d8afd1b7055498111", open_name: "R24_and_R31_open_absolute_false", open: open_a },
    Arm { name: "B", source_sha: "8a8721585d9c5e06e8962a6d3a3f4d1976e694ce641d41254f5e693ae81e3007", absolute_sha: "abcbace6885c69e01809cce9f7521ed9c4c274dcea82ebad706ddd9b33a22251", open_sha: "4418fc032f1b0d5e33cc71300253444ad65dd10488d5164aed5d9517310b0c59", open_name: "R33_PinnedFile_open_path", open: open_b },
];
const ROUNDS: usize = 16;
const CALLS: usize = 64;
const WARMUP_CALLS: usize = 16;
const ORDER: [usize; 4] = [0, 1, 1, 0];
const CACHE_EXPRESSION_SHA: &str = "7dfd74ec368212d2b08bdf9ca4a0e82fcb2d7612062f819b06d5a056404a8e90";
