// Copyright 2026 TrillionniumFoundation; SPDX-License-Identifier: Apache-2.0
//! Real R24/R31 open_absolute versus R33 open_path, with separate cache costs.
#[cfg(not(target_os = "linux"))]
compile_error!("This component requires Linux and /proc/self; it is not a Mac test.");

use anyhow::{ensure, Context, Result};
use std::alloc::{GlobalAlloc, Layout, System};
use std::fs::{self, DirBuilder, File, OpenOptions};
use std::hint::black_box;
use std::io::{BufWriter, Read, Write};
use std::os::fd::{AsRawFd, OwnedFd};
use std::os::unix::ffi::OsStrExt;
use std::os::unix::fs::{symlink, DirBuilderExt, MetadataExt, OpenOptionsExt};
use std::path::{Component, Path, PathBuf};
use std::sync::atomic::{AtomicBool, AtomicU64, Ordering::Relaxed};

static ENABLED: AtomicBool = AtomicBool::new(false);
static COUNTERS: [AtomicU64; 9] = [const { AtomicU64::new(0) }; 9];
struct CountingSystem;

// No formatting, locks, allocation, or I/O occurs in the callbacks. The measured
// process is single-threaded; snapshots and all reporting occur with counting off.
unsafe impl GlobalAlloc for CountingSystem {
	unsafe fn alloc(&self, layout: Layout) -> *mut u8 {
		if ENABLED.load(Relaxed) {
			COUNTERS[0].fetch_add(1, Relaxed);
			COUNTERS[4].fetch_add(layout.size() as u64, Relaxed);
		}
		unsafe { System.alloc(layout) }
	}
	unsafe fn alloc_zeroed(&self, layout: Layout) -> *mut u8 {
		if ENABLED.load(Relaxed) {
			COUNTERS[1].fetch_add(1, Relaxed);
			COUNTERS[5].fetch_add(layout.size() as u64, Relaxed);
		}
		unsafe { System.alloc_zeroed(layout) }
	}
	unsafe fn realloc(&self, pointer: *mut u8, layout: Layout, size: usize) -> *mut u8 {
		if ENABLED.load(Relaxed) {
			COUNTERS[2].fetch_add(1, Relaxed);
			COUNTERS[6].fetch_add(size as u64, Relaxed);
			COUNTERS[8].fetch_add(layout.size() as u64, Relaxed);
		}
		unsafe { System.realloc(pointer, layout, size) }
	}
	unsafe fn dealloc(&self, pointer: *mut u8, layout: Layout) {
		if ENABLED.load(Relaxed) {
			COUNTERS[3].fetch_add(1, Relaxed);
			COUNTERS[7].fetch_add(layout.size() as u64, Relaxed);
		}
		unsafe { System.dealloc(pointer, layout) }
	}
}

#[global_allocator]
static ALLOCATOR: CountingSystem = CountingSystem;

#[derive(Clone, Copy)]
struct Arm {
	name: &'static str,
	source_sha: &'static str,
	absolute_sha: &'static str,
	open_sha: &'static str,
	open_name: &'static str,
	open: fn(&Path, &b::PinnedFile) -> Result<File>,
}
include!("extracted.rs");

type Counts = [u64; 9];
fn reset() {
	for counter in &COUNTERS {
		counter.store(0, Relaxed);
	}
}
fn counts() -> Counts {
	std::array::from_fn(|index| COUNTERS[index].load(Relaxed))
}
fn counts_json(value: Counts) -> String {
	format!(
		r#"{{"alloc":{},"alloc_zeroed":{},"realloc":{},"dealloc":{},"alloc_bytes":{},"alloc_zeroed_bytes":{},"realloc_requested_bytes":{},"dealloc_bytes":{},"realloc_previous_bytes":{}}}"#,
		value[0], value[1], value[2], value[3], value[4], value[5], value[6], value[7], value[8]
	)
}
fn net(value: Counts) -> (i128, i128) {
	(value[0] as i128 + value[1] as i128 - value[3] as i128,
	 value[4] as i128 + value[5] as i128 + value[6] as i128
		 - value[8] as i128 - value[7] as i128)
}
fn quoted(value: &str) -> String {
	let mut out = String::from("\"");
	for character in value.chars() {
		match character {
			'"' => out.push_str("\\\""),
			'\\' => out.push_str("\\\\"),
			value if value < ' ' => out.push_str(&format!("\\u{:04x}", value as u32)),
			value => out.push(value),
		}
	}
	out.push('"');
	out
}
fn emit(output: &mut BufWriter<File>, line: String) -> Result<()> {
	ensure!(!ENABLED.load(Relaxed), "reporting inside the allocation scope");
	writeln!(output, "{line}")?;
	output.flush()?;
	Ok(())
}

fn fd_snapshot() -> Result<Vec<i32>> {
	let mut entries = Vec::new();
	for entry in fs::read_dir("/proc/self/fd")? {
		entries.push(entry?.file_name().to_string_lossy().parse::<i32>()?);
	}
	// read_dir's own descriptor is now closed; do not count its stale entry.
	entries.retain(|fd| (unsafe { libc::fcntl(*fd, libc::F_GETFD) }) >= 0);
	entries.sort_unstable();
	Ok(entries)
}
fn single_thread() -> Result<()> {
	let mut count = 0;
	for entry in fs::read_dir("/proc/self/task")? {
		entry?;
		count += 1;
	}
	ensure!(count == 1, "allocation scope requires one actual Linux thread");
	Ok(())
}
fn closed(fd: i32) -> Result<()> {
	let result = unsafe { libc::fcntl(fd, libc::F_GETFD) };
	ensure!(
		result == -1 && std::io::Error::last_os_error().raw_os_error() == Some(libc::EBADF),
		"owned descriptor was not closed"
	);
	Ok(())
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
struct Identity(u64, u64, u32);
fn identity(metadata: &fs::Metadata) -> Identity {
	Identity(metadata.dev(), metadata.ino(), metadata.mode() & libc::S_IFMT)
}
struct Fixture {
	root: PathBuf,
	identity: Identity,
	removed: bool,
}
impl Fixture {
	fn new() -> Result<Self> {
		let mut nonce = [0u8; 16];
		File::open("/dev/urandom")?.read_exact(&mut nonce)?;
		let suffix: String = nonce.iter().map(|byte| format!("{byte:02x}")).collect();
		let root = fs::canonicalize(std::env::temp_dir())?.join(format!("hepta-r33-alloc-{suffix}"));
		DirBuilder::new().mode(0o700).create(&root)?;
		let stamp = identity(&fs::symlink_metadata(&root)?);
		Ok(Self { root, identity: stamp, removed: false })
	}
	fn cleanup(&mut self) -> Result<()> {
		if !self.removed {
			let now = fs::symlink_metadata(&self.root)?;
			ensure!(identity(&now) == self.identity && now.uid() == unsafe { libc::geteuid() },
				"fixture root changed; refusing to remove a replacement");
			fs::remove_dir_all(&self.root)?;
			self.removed = true;
		}
		Ok(())
	}
}
impl Drop for Fixture {
	fn drop(&mut self) {
		let _ = self.cleanup();
	}
}

struct Case {
	name: &'static str,
	path: PathBuf,
	expected: Identity,
	cache: Option<b::PinnedFile>,
	construction: Counts,
}
fn cases(fixture: &Fixture) -> Result<Vec<Case>> {
	let shallow = fixture.root.join("leaf");
	OpenOptions::new().create_new(true).write(true).mode(0o600).open(&shallow)?
		.write_all(b"component-owned-file")?;
	let mut deep = fixture.root.clone();
	for name in ["d1", "d2", "d3", "d4", "d5", "d6"] {
		deep.push(name);
		DirBuilder::new().mode(0o700).create(&deep)?;
	}
	let directory = deep.clone();
	deep.push("leaf");
	OpenOptions::new().create_new(true).write(true).mode(0o600).open(&deep)?
		.write_all(b"component-owned-deep-file")?;
	[("root", PathBuf::from("/")), ("shallow_file", shallow),
	 ("deep_file", deep), ("directory", directory)]
		.into_iter().map(|(name, path)| {
			let expected = identity(&fs::metadata(&path)?);
			Ok(Case { name, path, expected, cache: None, construction: [0; 9] })
		}).collect()
}

fn construct_cache(output: &mut BufWriter<File>, case: &mut Case, fds: &[i32]) -> Result<()> {
	ensure!(!ENABLED.load(Relaxed) && case.cache.is_none(), "cache must be constructed once");
	// This is only the original syntax precondition, not the complete cold load.
	b::absolute(&case.path)?;
	reset();
	ENABLED.store(true, Relaxed);
	let result = black_box(b::PinnedFile::from_validated_path)(black_box(case.path.as_path()));
	ENABLED.store(false, Relaxed);
	let value = counts();
	let live = net(value);
	let fd_ok = fd_snapshot()?.as_slice() == fds;
	let error = result.as_ref().err().map_or_else(|| "null".into(), |error| quoted(&error.to_string()));
	let shape = result.as_ref().ok().map_or((0, 0, 0), |cache| cache.cache_shape());
	emit(output, format!(r#"{{"kind":"cache_construct","case":{},"arm":"B","expression_sha256":{},"scope":"cache_expression_and_holder_only","full_load_exercised":false,"counts":{},"live_allocation_requests":{},"live_requested_bytes":{},"normal_components":{},"cstring_payload_with_nuls_bytes":{},"cstring_descriptor_bytes":{},"holder_bytes":{},"fd_inventory_unchanged":{},"constructed":{},"error":{}}}"#,
		quoted(case.name), quoted(CACHE_EXPRESSION_SHA), counts_json(value), live.0, live.1,
		shape.0, shape.1, shape.2, std::mem::size_of::<b::PinnedFile>(), fd_ok, result.is_ok(), error))?;
	let cache = result?;
	ensure!(fd_ok && live.0 >= 0 && live.1 >= 0, "cache construction accounting or FD mismatch");
	case.construction = value;
	case.cache = Some(cache);
	Ok(())
}

fn release_cache(output: &mut BufWriter<File>, case: &mut Case, fds: &[i32]) -> Result<()> {
	ensure!(!ENABLED.load(Relaxed), "cache release started inside another allocation scope");
	let cache = case.cache.take().context("cache already released")?;
	reset();
	ENABLED.store(true, Relaxed);
	drop(cache);
	ENABLED.store(false, Relaxed);
	let value = counts();
	let combined = std::array::from_fn(|index| case.construction[index] + value[index]);
	let remainder = net(combined);
	let fd_ok = fd_snapshot()?.as_slice() == fds;
	let balanced = remainder == (0, 0);
	emit(output, format!(r#"{{"kind":"cache_release","case":{},"arm":"B","counts":{},"construction_plus_release_counts":{},"remaining_allocation_requests":{},"remaining_requested_bytes":{},"balanced":{},"fd_inventory_unchanged":{},"rss_claim":false}}"#,
		quoted(case.name), counts_json(value), counts_json(combined), remainder.0, remainder.1, balanced, fd_ok))?;
	ensure!(balanced && fd_ok, "cache lifetime accounting or FD mismatch");
	Ok(())
}

// Only the original call and destruction of its returned owned FD are counted.
// fstat, the EBADF check, FD inventory, error formatting and output are outside.
fn checked_call(arm: Arm, case: &Case, count: bool) -> Result<()> {
	let cache = case.cache.as_ref().context("missing prepared path cache")?;
	ENABLED.store(count, Relaxed);
	let result = black_box(arm.open)(black_box(case.path.as_path()), black_box(cache));
	ENABLED.store(false, Relaxed);
	let file = result.with_context(|| format!("arm {} case {} open failed", arm.name, case.name))?;
	let observed = file.metadata();
	let owned: OwnedFd = file.into();
	let fd = owned.as_raw_fd();
	ENABLED.store(count, Relaxed);
	drop(owned);
	ENABLED.store(false, Relaxed);
	closed(fd)?;
	ensure!(identity(&observed?) == case.expected, "opened descriptor identity differs");
	Ok(())
}

fn control_case(name: &'static str, path: PathBuf, expected: Identity) -> Result<Case> {
	ensure!(!ENABLED.load(Relaxed), "control cache constructed during measurement");
	b::absolute(&path)?;
	let cache = b::PinnedFile::from_validated_path(&path)?;
	Ok(Case { name, path, expected, cache: Some(cache), construction: [0; 9] })
}

fn rejected_path(output: &mut BufWriter<File>, case: &Case) -> Result<()> {
	let cache = case.cache.as_ref().context("control cache missing")?;
	let mut outcomes = Vec::new();
	let fds = fd_snapshot()?;
	for arm in ARMS {
		let error = (arm.open)(&case.path, cache).err()
			.with_context(|| format!("arm {} accepted rejected path {}", arm.name, case.name))?;
		let errno = error.downcast_ref::<std::io::Error>().and_then(|error| error.raw_os_error());
		outcomes.push((errno, error.to_string()));
		ensure!(fd_snapshot()? == fds, "arm {} rejected path leaked descriptors", arm.name);
	}
	ensure!(outcomes[0] == outcomes[1], "error outcome differs for {}", case.name);
	let errno = outcomes[0].0.map_or_else(|| "null".into(), |value| value.to_string());
	emit(output, format!(r#"{{"kind":"control","phase":"open_method","name":{},"both_arms_matched":true,"errno":{},"error":{}}}"#,
		quoted(case.name), errno, quoted(&outcomes[0].1)))?;
	Ok(())
}

fn controls(output: &mut BufWriter<File>, fixture: &Fixture, cases: &[Case]) -> Result<()> {
	for case in cases {
		for arm in ARMS {
			checked_call(arm, case, false)?;
		}
	}
	let repeated = control_case("repeated_separators_and_tail",
		PathBuf::from(format!("/{}///leaf/", fixture.root.display())), cases[1].expected)?;
	for arm in ARMS {
		checked_call(arm, &repeated, false)?;
	}
	emit(output, format!(r#"{{"kind":"control","phase":"open_method","name":{},"both_arms_matched":true}}"#,
		quoted(repeated.name)))?;
	// Invalid syntax cannot enter a real loaded PinnedFile. Test its unchanged
	// cold precondition explicitly; never pass these paths to the cached method.
	for (name, path) in [
		("empty", PathBuf::from("")), ("relative", PathBuf::from("relative")),
		("dot", fixture.root.join("./leaf")), ("dotdot", fixture.root.join("d1/../leaf")),
		("nul", PathBuf::from("/invalid/\0")),
		("non_utf8", PathBuf::from(std::ffi::OsStr::from_bytes(b"/invalid/\xff"))),
	] {
		let fds = fd_snapshot()?;
		let a = a::open_absolute(&path, false).err()
			.with_context(|| format!("A accepted invalid syntax {name}"))?;
		let b = b::absolute(&path).err()
			.with_context(|| format!("B cold precondition accepted invalid syntax {name}"))?;
		ensure!(a.to_string() == b.to_string(), "syntax error differs for {name}");
		ensure!(fd_snapshot()? == fds, "syntax control leaked descriptors");
		emit(output, format!(r#"{{"kind":"control","phase":"cold_syntax_precondition","name":{},"both_arms_matched":true,"B_open_path_called":false,"error":{}}}"#,
			quoted(name), quoted(&b.to_string())))?;
	}
	let leaf_alias = fixture.root.join("leaf_alias");
	let parent_alias = fixture.root.join("parent_alias");
	symlink(&cases[1].path, &leaf_alias)?;
	symlink(&cases[3].path, &parent_alias)?;
	for (name, path) in [
		("leaf_symlink", leaf_alias), ("parent_symlink", parent_alias.join("leaf")),
		("missing_leaf", fixture.root.join("missing")),
	] {
		let case = control_case(name, path, cases[1].expected)?;
		rejected_path(output, &case)?;
	}
	let directory = fixture.root.join("live_ancestor");
	DirBuilder::new().mode(0o700).create(&directory)?;
	let leaf = directory.join("leaf");
	OpenOptions::new().create_new(true).write(true).mode(0o600).open(&leaf)?
		.write_all(b"cached spelling must resolve current ancestors")?;
	let expected = identity(&fs::metadata(&leaf)?);
	let live = control_case("ancestor_replaced_after_cache", leaf, expected)?;
	for arm in ARMS {
		checked_call(arm, &live, false)?;
	}
	let retired = fixture.root.join("retired_ancestor");
	fs::rename(&directory, &retired)?;
	symlink(&retired, &directory)?;
	rejected_path(output, &live)?;
	Ok(())
}

fn block(output: &mut BufWriter<File>, case: &Case, arm: Arm, round: usize, position: usize,
	fds: &[i32]) -> Result<Counts> {
	reset();
	let mut completed = 0;
	let result = (|| -> Result<()> {
		for _ in 0..CALLS {
			checked_call(arm, case, true)?;
			completed += 1;
		}
		ensure!(fd_snapshot()?.as_slice() == fds, "descriptor inventory changed within measured block");
		let value = counts();
		ensure!(net(value) == (0, 0), "successful hot calls left scoped allocation requests unbalanced");
		Ok(())
	})();
	let value = counts();
	let error = result.as_ref().err().map_or_else(|| "null".into(), |error| quoted(&error.to_string()));
	emit(output, format!(r#"{{"kind":"sample","case":{},"round":{},"position":{},"arm":{},"open_sha256":{},"normal_components":{},"completed_calls":{},"counts":{},"hot_calls_only":true,"functional_and_fd_ok":{},"error":{}}}"#,
		quoted(case.name), round, position, quoted(arm.name), quoted(arm.open_sha),
		case.path.components().filter(|part| matches!(part, Component::Normal(_))).count(),
		completed, counts_json(value), result.is_ok(), error))?;
	result?;
	Ok(value)
}

fn exercise(output: &mut BufWriter<File>, fixture: &Fixture, fds: &[i32]) -> Result<()> {
	single_thread()?;
	let mut cases = cases(fixture)?;
	for case in &mut cases {
		construct_cache(output, case, fds)?;
	}
	controls(output, fixture, &cases)?;
	ensure!(fd_snapshot()?.as_slice() == fds, "functional controls leaked descriptors");
	for case in &mut cases {
		for index in ORDER {
			for _ in 0..WARMUP_CALLS {
				checked_call(ARMS[index], case, false)?;
			}
		}
		let mut totals = [[0u64; 9]; 2];
		for round in 0..ROUNDS {
			for (position, index) in ORDER.into_iter().enumerate() {
				let value = block(output, case, ARMS[index], round, position, fds)?;
				for (total, count) in totals[index].iter_mut().zip(value) {
					*total += count;
				}
			}
		}
		let allocation_calls = |value: Counts| value[0] + value[1] + value[2];
		emit(output, format!(r#"{{"kind":"case_summary","case":{},"calls_per_arm":{},"A_hot":{},"B_hot":{},"B_fewer_hot_allocation_and_reallocation_calls":{},"cold_costs_recorded_separately":true,"rss_claim":false,"whole_runtime_claim":false}}"#,
			quoted(case.name), ROUNDS * 2 * CALLS, counts_json(totals[0]), counts_json(totals[1]),
			allocation_calls(totals[1]) < allocation_calls(totals[0])))?;
		release_cache(output, case, fds)?;
	}
	single_thread()?;
	Ok(())
}

fn run() -> Result<()> {
	let mut arguments = std::env::args_os().skip(1);
	let output_path = PathBuf::from(arguments.next().context("usage: hepta-r33-pinned-path-component NEW_RAW_JSONL")?);
	ensure!(arguments.next().is_none(), "one create-only output path is required");
	let file = OpenOptions::new().create_new(true).write(true).mode(0o600)
		.custom_flags(libc::O_NOFOLLOW | libc::O_CLOEXEC).open(&output_path)?;
	let mut output = BufWriter::new(file);
	let mut fixture = Fixture::new()?;
	let hostname = fs::read_to_string("/proc/sys/kernel/hostname")?;
	let kernel = fs::read_to_string("/proc/sys/kernel/osrelease")?;
	emit(&mut output, format!(r#"{{"kind":"header","schema":"hepta-r33-pinned-path-allocation/v1","hostname":{},"kernel":{},"arch":{},"pid":{},"fixture_root":{},"rounds":{},"calls_per_block":{},"warmup_calls_per_block":{},"order":["A","B","B","A"],"A_directory_argument":false,"root_and_directory_are_method_edge_shapes":true,"full_load_or_verify_exercised":false,"R24_R31_profile_bytes_identical":true,"timing_measured":false,"rss_measured":false,"scope":"instrumented original open function and method; separate cache construction and release; no whole-runtime claim"}}"#,
		quoted(hostname.trim()), quoted(kernel.trim()), quoted(std::env::consts::ARCH), std::process::id(),
		quoted(&fixture.root.to_string_lossy()), ROUNDS, CALLS, WARMUP_CALLS))?;
	for arm in ARMS {
		emit(&mut output, format!(r#"{{"kind":"source","arm":{},"source_sha256":{},"absolute_sha256":{},"open_sha256":{},"open_name":{}}}"#,
			quoted(arm.name), quoted(arm.source_sha), quoted(arm.absolute_sha), quoted(arm.open_sha), quoted(arm.open_name)))?;
	}
	let fds = fd_snapshot()?;
	let result = exercise(&mut output, &fixture, &fds);
	let cleanup = fixture.cleanup();
	let final_fds = fd_snapshot();
	let fd_match = final_fds.as_ref().is_ok_and(|value| value == &fds);
	let passed = result.is_ok() && cleanup.is_ok() && fd_match;
	let errors = [result.as_ref().err(), cleanup.as_ref().err(), final_fds.as_ref().err()]
		.into_iter().flatten().map(|error| quoted(&error.to_string())).collect::<Vec<_>>().join(",");
	emit(&mut output, format!(r#"{{"kind":"summary","functional_passed":{},"fixture_removed":{},"fd_inventory_unchanged":{},"passed":{},"expected_sample_rows":{},"expected_cache_construct_rows":4,"expected_cache_release_rows":4,"automatic_rerun":false,"rss_claim":false,"whole_runtime_claim":false,"errors":[{}]}}"#,
		result.is_ok(), fixture.removed, fd_match, passed, 4 * ROUNDS * ORDER.len(), errors))?;
	output.get_ref().sync_all()?;
	ensure!(passed, "component did not close successfully; original raw output is retained");
	println!("component completed; raw evidence: {}", output_path.display());
	Ok(())
}

fn main() {
	if let Err(error) = run() {
		eprintln!("{error:#}");
		std::process::exit(1);
	}
}
