#!/usr/bin/env python3
# Copyright 2026 TrillionniumFoundation; SPDX-License-Identifier: Apache-2.0
"""Extract pinned real function/method/expression bytes; never compile or run them."""
import argparse
import hashlib
import json
from pathlib import Path
import tomllib

ROOT = Path(__file__).resolve().parent
PACKAGE = 'hepta-r33-pinned-path-component'
PINS = {
    'r24-profile.rs': 'a62169343c2a08c38d69925f33fdc7551cf4be7b4b7f50cf89683f652a8f853a',
    'r31-profile.rs': 'a62169343c2a08c38d69925f33fdc7551cf4be7b4b7f50cf89683f652a8f853a',
    'r33-profile.rs': '8a8721585d9c5e06e8962a6d3a3f4d1976e694ce641d41254f5e693ae81e3007',
    'r33-candidate-manifest.json': '4da10500f9108f484c4415ec726776685f61bfc73eccf7a12b23fed3f7ab53d5',
    'R24.Cargo.lock': '15b9fb468eb34a210238657d132cbf19e961552d1313de488e1f14936bfa4e5f',
}
PROTOCOL = {
    'rounds': 16, 'calls_per_block': 64, 'warmup_calls_per_block': 16,
    'order': ['A', 'B', 'B', 'A'],
    'shapes': ['root', 'shallow_file', 'deep_file', 'directory'],
    'A_directory_argument': False,
    'root_and_directory_are_method_only_edge_shapes': True,
    'cold_cache_construction_and_destruction_recorded_separately': True,
    'full_PinnedFile_load_or_verify_exercised': False,
    'timing_measured': False,
    'rss_measured': False,
}


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def extract(source, marker, next_marker):
    assert source.count(marker) == source.count(next_marker) == 1
    start = source.index(marker)
    end = source.index(next_marker, start)
    return source[start:end]


def expected_files():
    sources = {name: (ROOT / 'inputs' / name).read_bytes() for name in PINS}
    assert all(sha(sources[name]) == expected for name, expected in PINS.items())
    assert sources['r24-profile.rs'] == sources['r31-profile.rs']
    a_absolute = extract(sources['r24-profile.rs'], b'pub(super) fn absolute(',
                         b'\n/// Every component is resolved')
    a_open = extract(sources['r24-profile.rs'], b'pub(super) fn open_absolute(',
                     b'\npub(super) fn private_directory(')
    b_absolute = extract(sources['r33-profile.rs'], b'pub(super) fn absolute(',
                         b'\n/// Every component is resolved')
    b_open = extract(sources['r33-profile.rs'], b'\tfn open_path(&self) -> Result<File> {',
                     b'\tfn verify_identity(&self)')
    cache = extract(sources['r33-profile.rs'], b'\t\tlet path_components = path\n',
                    b'\t\tOk((\n')
    assert a_absolute == b_absolute
    assert all(raw.endswith(b'}\n') for raw in [a_absolute, a_open, b_absolute, b_open])
    assert cache.endswith(b'\t\t\t.into();\n')
    output = {
        'extracted/A_absolute.rs': a_absolute,
        'extracted/A_open_absolute.rs': a_open,
        'extracted/B_absolute.rs': b_absolute,
        'extracted/B_open_path.rs': b_open,
        'extracted/B_cache_expression.rs': cache,
    }
    imports = (b'use anyhow::{bail, Context, Result};\nuse std::fs::File;\n'
               b'use std::os::fd::{AsRawFd, FromRawFd};\nuse std::path::{Component, Path};\n')
    module_a = b'mod a {\n' + imports + a_absolute + b'\n' + a_open + b'}\n'
    # The holder has exactly the field referenced by the unchanged real method.
    # This constructor is an adapter for the exact expression, not PinnedFile::load.
    module_b = (b'mod b {\n' + imports + b'use std::sync::Arc;\n' + b_absolute
                + b'\npub(super) struct PinnedFile {\n\tpath_components: Arc<[std::ffi::CString]>,\n}\n'
                + b'impl PinnedFile {\n'
                + b'\tpub(super) fn from_validated_path(path: &Path) -> Result<Self> {\n'
                + cache + b'\t\tOk(Self { path_components })\n\t}\n'
                + b_open
                + b'\tpub(super) fn component_open(&self) -> Result<File> { self.open_path() }\n'
                + b'\tpub(super) fn cache_shape(&self) -> (usize, usize, usize) {\n'
                + b'\t\t(self.path_components.len(),\n'
                + b'\t\t self.path_components.iter().map(|name| name.as_bytes_with_nul().len()).sum(),\n'
                + b'\t\t self.path_components.len() * std::mem::size_of::<std::ffi::CString>())\n'
                + b'\t}\n}\n}\n')
    arms = [
        {'arm': 'A', 'source_sha256': sha(sources['r24-profile.rs']),
         'absolute_sha256': sha(a_absolute), 'open_sha256': sha(a_open),
         'open_name': 'R24_and_R31_open_absolute_false', 'adapter': 'open_a'},
        {'arm': 'B', 'source_sha256': sha(sources['r33-profile.rs']),
         'absolute_sha256': sha(b_absolute), 'open_sha256': sha(b_open),
         'open_name': 'R33_PinnedFile_open_path', 'adapter': 'open_b'},
    ]
    declarations = [
        'fn open_a(path: &Path, _: &b::PinnedFile) -> Result<File> { a::open_absolute(path, false) }',
        'fn open_b(_: &Path, cache: &b::PinnedFile) -> Result<File> { cache.component_open() }',
        'const ARMS: [Arm; 2] = [',
    ]
    for row in arms:
        declarations.append('    Arm { name: "' + row['arm'] + '", source_sha: "'
                            + row['source_sha256'] + '", absolute_sha: "' + row['absolute_sha256']
                            + '", open_sha: "' + row['open_sha256'] + '", open_name: "'
                            + row['open_name'] + '", open: ' + row['adapter'] + ' },')
    declarations.extend([
        '];', 'const ROUNDS: usize = 16;', 'const CALLS: usize = 64;',
        'const WARMUP_CALLS: usize = 16;', 'const ORDER: [usize; 4] = [0, 1, 1, 0];',
        'const CACHE_EXPRESSION_SHA: &str = "' + sha(cache) + '";',
    ])
    header = (b'// Copyright 2026 Muvon Un Limited\n'
              b'// Copyright 2026 TrillionniumFoundation; SPDX-License-Identifier: Apache-2.0\n'
              b'// Original function/method/expression bytes are unchanged; adapters are component-only.\n')
    output['src/extracted.rs'] = header + module_a + b'\n' + module_b + ('\n'.join(declarations) + '\n').encode()
    lock = tomllib.loads(sources['R24.Cargo.lock'].decode())
    dependencies = []
    for name in ['anyhow', 'libc']:
        found = [row for row in lock['package'] if row['name'] == name]
        assert len(found) == 1 and set(found[0]) == {'name', 'version', 'source', 'checksum'}
        dependencies.append(found[0])
    manifest = ('[package]\nname = "' + PACKAGE + '"\nversion = "0.1.0"\nedition = "2021"\n'
                'rust-version = "1.95"\nlicense = "Apache-2.0"\npublish = false\n\n[workspace]\n\n[dependencies]\n')
    manifest += ''.join(row['name'] + ' = "=' + row['version'] + '"\n' for row in dependencies)
    manifest += '\n[profile.release]\nopt-level = 3\nlto = true\ncodegen-units = 1\npanic = "abort"\nstrip = true\n'
    output['Cargo.toml'] = manifest.encode()
    packages = dependencies + [{'name': PACKAGE, 'version': '0.1.0', 'dependencies': ['anyhow', 'libc']}]
    minimal = '# Dependency entries copied exactly from the accepted R24 lock.\nversion = 4\n'
    for row in sorted(packages, key=lambda item: item['name']):
        minimal += '\n[[package]]\n'
        for key in ['name', 'version', 'source', 'checksum']:
            if key in row:
                minimal += key + ' = ' + json.dumps(row[key]) + '\n'
        if 'dependencies' in row:
            minimal += 'dependencies = [\n "anyhow",\n "libc",\n]\n'
    output['Cargo.lock'] = minimal.encode()
    receipt = {
        'schema': 'hepta-r33-allocation-component-input/v1', 'input_sha256': PINS,
        'arms': arms, 'cache_expression_sha256': sha(cache),
        'R24_R31_profile_bytes_identical': True,
        'R33_path_direction_composition': ['R24', 'R32', 'R33'],
        'R32_separate_full_runtime_qualification_required_before_R33_evaluation': False,
        'final_runtime_baseline_selection': 'parent decides after R31 formal results; no adoption implied',
        'dependency_pins': dependencies, 'protocol': PROTOCOL,
        'generated_sha256': {name: sha(raw) for name, raw in sorted(output.items())},
    }
    output['input-manifest.json'] = (json.dumps(receipt, indent=2, sort_keys=True) + '\n').encode()
    return output


def check():
    expected = expected_files()
    assert all((ROOT / name).read_bytes() == raw for name, raw in expected.items()), 'generated bytes differ'
    return expected


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    mode = parser.add_mutually_exclusive_group(required=True)
    mode.add_argument('--write', action='store_true')
    mode.add_argument('--check', action='store_true')
    args = parser.parse_args()
    if args.write:
        for name, raw in expected_files().items():
            path = ROOT / name
            path.parent.mkdir(parents=True, exist_ok=True)
            with path.open('xb') as stream:
                stream.write(raw)
    else:
        check()
    print(json.dumps({'generated_bytes_match': True, 'build_executed': False, 'component_executed': False}))
