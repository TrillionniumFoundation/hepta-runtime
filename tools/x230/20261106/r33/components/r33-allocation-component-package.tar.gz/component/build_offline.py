#!/usr/bin/env python3
# Copyright 2026 TrillionniumFoundation; SPDX-License-Identifier: Apache-2.0
"""Build this small component with the installed x230 toolchain/cache; never run it."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

import generate

ROOT = Path(__file__).resolve().parent


def identity(path):
    raw = path.read_bytes()
    return {'path': str(path), 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


def checked_package():
    generate.check()
    package = json.loads((ROOT / 'package-manifest.json').read_bytes())
    assert package['schema'] == 'hepta-r33-allocation-component-package/v1'
    for name, expected in package['files'].items():
        actual = identity(ROOT / name)
        assert {'bytes': actual['bytes'], 'sha256': actual['sha256']} == expected, name
    return identity(ROOT / 'package-manifest.json')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--cargo-home', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--cargo', type=Path, default=Path('/home/qian/.cargo/bin/cargo'))
    args = parser.parse_args()
    package = checked_package()
    cargo_home = args.cargo_home.resolve(strict=True)
    cargo = args.cargo.absolute()
    assert cargo.is_file() and cargo_home.is_dir()
    output = args.output.absolute()
    output.mkdir(exist_ok=False)
    environment = os.environ.copy()
    # Native process jobs may omit cargo/bin even when absolute version probes
    # work. Cargo itself resolves rustc through PATH after RUSTC is removed below.
    toolchain_path = os.pathsep.join([str(cargo.parent), '/usr/local/bin', '/usr/bin', '/bin'])
    environment.update(CARGO_HOME=str(cargo_home), CARGO_TARGET_DIR=str(output / 'target'),
                       CARGO_NET_OFFLINE='true', CARGO_INCREMENTAL='0', PATH=toolchain_path)
    for name in ('RUSTC', 'RUSTC_WRAPPER', 'RUSTC_WORKSPACE_WRAPPER', 'RUSTFLAGS', 'CARGO_ENCODED_RUSTFLAGS'):
        environment.pop(name, None)
    command = [str(cargo), '+1.95.0', 'build', '--offline', '--locked', '--release', '--jobs', '1',
               '--manifest-path', str(ROOT / 'Cargo.toml')]
    report = {'schema': 'hepta-r33-allocation-component-build/v1', 'passed': False,
              'started_unix_ns': time.time_ns(), 'package_manifest': package, 'command': command,
              'cargo_home': str(cargo_home), 'network_download_allowed': False,
              'process_path': toolchain_path,
              'rustc_resolution': 'requested cargo parent followed by fixed system paths',
              'component_executed': False, 'automatic_retries': 0}
    try:
        for name, executable in [('cargo', cargo), ('rustc', cargo.with_name('rustc'))]:
            result = subprocess.run([str(executable), '+1.95.0', '-Vv'], env=environment,
                                    stdout=subprocess.PIPE, stderr=subprocess.STDOUT, check=True)
            with (output / (name + '-version.txt')).open('xb') as stream:
                stream.write(result.stdout)
            report[name + '_version'] = identity(output / (name + '-version.txt'))
        with (output / 'build.stdout').open('xb') as stdout, (output / 'build.stderr').open('xb') as stderr:
            result = subprocess.run(command, cwd=ROOT, env=environment, stdout=stdout, stderr=stderr)
        report['returncode'] = result.returncode
        assert result.returncode == 0, 'offline locked build failed; retained original logs; no fallback'
        assert checked_package() == package, 'component source changed during build'
        report['binary'] = identity(output / 'target/release' / generate.PACKAGE)
        report['passed'] = True
    except Exception as error:
        report['error'] = type(error).__name__ + ': ' + str(error)
        raise
    finally:
        report['finished_unix_ns'] = time.time_ns()
        for name in ('build.stdout', 'build.stderr'):
            if (output / name).is_file():
                report[name] = identity(output / name)
        with (output / 'build-report.json').open('x') as stream:
            json.dump(report, stream, sort_keys=True, indent=2)
            stream.write('\n')
        print(json.dumps({'passed': report['passed'], 'report': str(output / 'build-report.json'),
                          'component_executed': False}, sort_keys=True))


if __name__ == '__main__':
    main()
