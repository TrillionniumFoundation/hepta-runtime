# R33 fixed-path allocation component

This is a single-thread Linux **method-level component**, prepared without a Rust
build or component execution. It compares real, byte-extracted R24/R31
`open_absolute(path, false)` with the real R33 `PinnedFile::open_path`. It opens
real private fixtures and records Rust allocator requests. It does not execute
the runtime, SSH, user jobs, or full `PinnedFile::load` / `verify`.

## Exact sources and the comparison boundary

The complete hash-pinned profile files are in `inputs/`. Accepted R24 and frozen
R31 profile files are byte-identical; R31's separate cancellation change does not
alter this component's A input. B comes from the frozen R33 profile file.
`generate.py` slices original bytes using unique markers in those fixed files:

- A: original `absolute` and `open_absolute` functions.
- B: original `absolute`, original `open_path` method, and the exact
  `let path_components = ... .into();` expression from `PinnedFile::load`.

The extracted files retain every original byte, including indentation. Generated
wrappers preserve those bytes and add only imports, a minimal holder with the
single `Arc<[CString]> path_components` field, and visibility/call adapters. The
holder is not the full production `PinnedFile`. Its constructor executes the
original cache expression but does not read, hash, validate an expected pin, or
retain the existing production PathBuf/stamp/reference fields.

For **all four shapes**, A passes `directory=false`, matching B's actual method
interface. Root and directory are useful zero-component/directory method edge
shapes; they cannot be successfully loaded as regular-file PinnedFiles. This
component makes no claim that they can. The old R32 `file_as_directory` comparison
is not applicable and is not carried over.

B's real `absolute` runs before cache construction with counting disabled.
Invalid syntax is reported as a separate cold-precondition control; no invalid
relative, dot, NUL or non-UTF8 path is fed directly to the cached opener. This
syntax precondition still does not substitute for the full production cold load.

`input-manifest.json` binds source/function/expression hashes, dependency pins and
the fixed protocol. `package-manifest.json` binds the complete package. A static
reproduction check, which neither compiles nor executes Rust, is available as:

```sh
python3 -B /absolute/component/path/generate.py --check
```

## Hot counting, cold costs and ownership

Each shape constructs one B cache before warmup or hot measurements. The cold
counter switch surrounds only the exact cache expression and holder return.
`cache_construct` records all raw counters, component and payload sizes, and the
net live allocation requests. This is **cache construction cost only**, not the
total cost of production `PinnedFile::load`.

Hot A and B calls use the same harness. The switch surrounds only the original
opener through its no-allocation adapter and destruction of the returned owned
descriptor. The returned File is inspected while counting is off, transferred to
OwnedFd, then dropped with counting on. B only borrows its prebuilt holder: it
does not build, clone or release the cache in the hot interval.

After a shape's complete ABBA series, the final cache owner is taken and dropped
in a separate counted interval. `cache_release` records its raw counters and the
combined construction-plus-release balance. Both net allocation requests and net
requested bytes must return to zero. This also exposes the persistent cache
cost that is deliberately absent from hot-call samples.

The System-delegating GlobalAlloc callbacks do no logging, I/O, locking or
allocation. Nine counters record alloc, alloc_zeroed, realloc, dealloc; their
requested byte totals; and the prior size for every realloc. Signed net values
are calculated as:

```text
live allocation requests = alloc + alloc_zeroed - dealloc
live requested bytes = alloc_bytes + alloc_zeroed_bytes
                     + realloc_requested_bytes - realloc_previous_bytes
                     - dealloc_bytes
```

The standalone release interval has negative net values. Its raw counters are
retained and combined with construction; construction alone is not incorrectly
required to be balanced. Successful hot blocks do require zero net requests and
bytes, since they return no heap-owned object beyond the FD that is then closed.

These are **Rust allocation requests**, not allocator arena size, malloc usable
size, arbitrary C-library allocations, or process RSS. Cold construction has
additional persistent cost. A decrease in hot requests therefore cannot be
reported as total RSS decreasing. No duration, throughput, CPU or RSS is measured.

## Functional checks and raw records

The process checks that it has one actual Linux thread. It creates a random
mode-0700 tree below the canonical temporary directory, with mode-0600 files.
Every successful open must return the expected dev/inode/type. Every dropped
returned descriptor must subsequently produce EBADF. Own-process FD inventories
must agree after controls, cache construction/release, every hot block and final
cleanup. Cleanup checks the private fixture root's identity and owner first.

The four shapes remain `root`, `shallow_file`, `deep_file` and `directory`.
Warmup is one ABBA cycle of 16 calls per block. Measurement is **16 ABBA rounds
of 64 calls per block per shape**: 256 hot sample rows and 16,384 hot calls.
There are also four measured cache-construction records and four corresponding
release records; cold cache creation is not a timing distribution.

Controls, outside hot counters, check repeated separators/trailing slash; empty,
relative, dot, dotdot, NUL and non-UTF8 syntax at the cold precondition; leaf and
parent symlinks; a missing leaf; and replacement of an already-cached live
ancestor with a symlink. The last control first proves both arms open the live
fixture, then mutates only the owned ancestor and checks that both new opens
reject it. No production file, running user job, or live controller is changed.

The JSONL output is create-only. Every raw row is flushed, normal completion
syncs the file, and failures retain partial raw evidence without automatic retry.
Each sample includes arm, case, round, ABBA position, exact opener SHA, component
count, completed calls, all raw counters and functional/FD outcome. A case summary
separately reports `B_fewer_hot_allocation_and_reallocation_calls`; the overall
`passed` means functional/FD/cache-lifetime/fixture checks closed, not that an
allocation saving or runtime improvement was demonstrated.

## Offline build, separately from execution

Only exact `anyhow 1.0.104` and `libc 0.2.189` dependency entries are copied from
the accepted R24 Cargo.lock. Neither has additional dependency entries. The
small version-4 lock adds this new root package; Cargo.toml pins exact versions
and has its own workspace. Existing runtime or frozen component files are not
changed. Build with the existing x230 toolchain and registry cache:

```sh
/usr/bin/python3 -B /home/qian/hepta-runtime-r33-allocation-component-20261106/component/build_offline.py \
  --cargo-home /home/qian/hepta-runtime-optimization-20261023/cargo-home-a32-a33-r02 \
  --output /home/qian/hepta-runtime-r33-allocation-component-20261106/build-01
```

The parent directory must exist and `build-01` must not exist. The helper verifies
all frozen bytes, records absolute cargo/rustc version probes, invokes exactly
one `cargo +1.95.0 build --offline --locked --release --jobs 1`, and retains the
original logs and binary SHA. CARGO_NET_OFFLINE is set and the target directory
is private to this build. Missing cache/toolchain fails without network fallback.

The helper explicitly records and sets PATH to the selected cargo parent plus
`/usr/local/bin:/usr/bin:/bin`. This allows cargo's internal `rustc` subprocess to
resolve in native process jobs whose original PATH omitted cargo/bin. It removes
RUSTC and compiler-wrapper overrides as before. This is build-environment setup,
not a source or measurement change. `build_offline.py` never runs the component.

Only after the parent chooses a suitable execution period and the actual build
succeeds would the binary be invoked separately:

```sh
/home/qian/hepta-runtime-r33-allocation-component-20261106/build-01/target/release/hepta-r33-pinned-path-component \
  /home/qian/hepta-runtime-r33-allocation-component-20261106/run-01.jsonl
```

No such build or execution occurred while preparing this package. This is Linux
coverage; the existing Mac cfg does not compile the production observation module.

## Relationship to eventual runtime qualification

The frozen R33 path direction is the **R24 → R32 → R33 composition**: temporary
component Vec removal, then fixed-path CString caching. The method comparison
therefore measures their combined endpoint difference against the original
opener; it does not separate each change's contribution.

R33 can be evaluated and qualified as that complete path candidate. There is no
need to run a separate full R32 runtime qualification before evaluating R33.
The parent will select the final runtime baseline after the formal R31 results.
The profile equality recorded here supports reuse of this exact method-level A
input with either profile, but does not adopt R31 or silently rebase the complete
R33 candidate. Any different final runtime composition needs a new complete
source/input freeze and its own qualification and measurements.
