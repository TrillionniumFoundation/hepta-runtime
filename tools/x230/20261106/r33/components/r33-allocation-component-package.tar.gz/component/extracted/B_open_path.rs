	fn open_path(&self) -> Result<File> {
		// Start at a fresh root descriptor on every check. Cached names never
		// stand in for resolving the current directories and final inode.
		let mut current = File::open("/")?;
		for (index, name) in self.path_components.iter().enumerate() {
			let flags = libc::O_RDONLY
				| libc::O_NOFOLLOW
				| libc::O_NONBLOCK
				| libc::O_CLOEXEC
				| if index + 1 < self.path_components.len() {
					libc::O_DIRECTORY
				} else {
					0
				};
			let fd = unsafe { libc::openat(current.as_raw_fd(), name.as_ptr(), flags) };
			if fd < 0 {
				return Err(std::io::Error::last_os_error().into());
			}
			current = unsafe { File::from_raw_fd(fd) };
		}
		Ok(current)
	}
