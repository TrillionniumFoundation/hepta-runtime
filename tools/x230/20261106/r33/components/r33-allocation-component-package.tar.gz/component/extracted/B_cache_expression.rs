		let path_components = path
			.components()
			.filter_map(|part| match part {
				Component::Normal(part) => Some(part),
				_ => None,
			})
			.map(|part| std::ffi::CString::new(part.as_encoded_bytes()))
			.collect::<std::result::Result<Vec<_>, _>>()?
			.into();
