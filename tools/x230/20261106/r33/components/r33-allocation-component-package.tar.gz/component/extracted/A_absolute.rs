pub(super) fn absolute(path: &Path) -> Result<()> {
	let text = path
		.to_str()
		.context("observation profile path is not UTF-8")?;
	if !path.is_absolute()
		|| text.len() > 4096
		|| text.chars().any(|v| {
			v.is_control()
				|| v.is_whitespace()
				|| matches!(v, '%' | '~' | '$' | '`' | '\'' | '"' | '\\')
		}) || text.split('/').any(|v| matches!(v, "." | ".."))
	{
		bail!("unsupported observation profile path");
	}
	Ok(())
}
