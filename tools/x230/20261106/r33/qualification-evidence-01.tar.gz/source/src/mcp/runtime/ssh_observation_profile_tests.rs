// Copyright 2026 Muvon Un Limited
// Copyright 2026 TrillionniumFoundation; SPDX-License-Identifier: Apache-2.0
//! Profile identity, byte completeness and worker-consumption boundaries.
use super::*;
use sha2::Digest;
use std::os::unix::fs::{symlink, PermissionsExt};

#[test]
fn profile_hashes_keep_standard_sha256_bytes() {
	for (bytes, expected) in [
		(
			b"".as_slice(),
			"e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855",
		),
		(
			b"abc".as_slice(),
			"ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad",
		),
	] {
		assert_eq!(digest(bytes), hex_digest(expected).unwrap());
	}
	for length in [
		1, 55, 56, 63, 64, 65, 4095, 4096, 16383, 16384, 16385, 262151,
	] {
		let bytes: Vec<_> = (0..length).map(|index| (index % 251) as u8).collect();
		let reference: [u8; 32] = sha2::Sha256::digest(&bytes).into();
		assert_eq!(digest(&bytes), reference);
	}
}

#[test]
fn exact_supported_config_has_no_dynamic_or_undeclared_inputs() {
	let known = Path::new("/private/known_hosts");
	let accepted = b"Host hepta-main\n HostName 127.0.0.1\n User test\n Port 22\n HostKeyAlias pinned-main\n UserKnownHostsFile /private/known_hosts\n GlobalKnownHostsFile /dev/null\n BatchMode yes\n ConnectTimeout 8\n ControlMaster no\n ForwardAgent no\n StrictHostKeyChecking yes\n";
	validate_config(accepted, known).unwrap();
	for line in [
		"Include /private/more",
		"Match exec /usr/bin/true",
		"ProxyJump main",
		"ProxyCommand /bin/true",
		"IdentityFile /private/key",
		"LocalCommand /bin/true",
		"UserKnownHostsFile /other/known_hosts",
		"GlobalKnownHostsFile /etc/ssh/ssh_known_hosts",
		"ForwardAgent yes",
		"StrictHostKeyChecking no",
		"Host !main",
		"Host hepta-*",
		"User ${USER}",
		"Hostname `command`",
		"User \"quoted\"",
	] {
		assert!(
			validate_config(
				format!("{}\n{line}\n", std::str::from_utf8(accepted).unwrap()).as_bytes(),
				known
			)
			.is_err(),
			"accepted {line}"
		);
	}
}

#[test]
fn absolute_walk_keeps_directory_and_component_boundaries() {
	use std::os::unix::ffi::OsStrExt;

	let root = tempfile::tempdir().unwrap();
	let directory = root.path().join("nested");
	std::fs::create_dir(&directory).unwrap();
	let file = directory.join("file");
	std::fs::write(&file, b"owned path fixture").unwrap();
	let expected = Stamp::of(&std::fs::metadata(&file).unwrap());
	let separators = PathBuf::from(format!("/{}/nested///file/", root.path().display()));
	for path in [&file, &separators] {
		let opened = open_absolute(path, false).unwrap();
		assert_eq!(Stamp::of(&opened.metadata().unwrap()), expected);
		assert!(open_absolute(path, true).is_err());
	}
	for path in [Path::new("/"), directory.as_path()] {
		for require_directory in [false, true] {
			assert!(open_absolute(path, require_directory)
				.unwrap()
				.metadata()
				.unwrap()
				.is_dir());
		}
	}
	for path in ["", "relative", "/invalid/../file", "/invalid/./file"] {
		assert_eq!(
			open_absolute(Path::new(path), false)
				.unwrap_err()
				.to_string(),
			"unsupported observation profile path"
		);
	}
	let non_utf8 = Path::new(std::ffi::OsStr::from_bytes(b"/invalid/\xff"));
	assert_eq!(
		open_absolute(non_utf8, false).unwrap_err().to_string(),
		"observation profile path is not UTF-8"
	);
	let alias = root.path().join("alias");
	symlink(&directory, &alias).unwrap();
	assert!(open_absolute(&alias, true).is_err());
	assert!(open_absolute(&alias.join("file"), false).is_err());
}

#[test]
fn cached_pins_reopen_live_ancestors_without_following_aliases() {
	let root = tempfile::tempdir().unwrap();
	let directory = root.path().join("层级");
	std::fs::create_dir(&directory).unwrap();
	let path = directory.join("pin");
	let bytes = b"fresh ancestor resolution";
	std::fs::write(&path, bytes).unwrap();
	std::fs::set_permissions(&path, std::fs::Permissions::from_mode(0o600)).unwrap();
	let spelling = PathBuf::from(format!("/{}/层级///pin/", root.path().display()));
	let (pin, _) = PinnedFile::load(&spelling, None, bytes.len(), true, false).unwrap();
	let cloned = pin.clone();
	assert!(Arc::ptr_eq(&pin.path_components, &cloned.path_components));
	for pin in [&pin, &cloned] {
		pin.verify_identity().unwrap();
		pin.verify().unwrap();
	}
	let retired = root.path().join("retired");
	std::fs::rename(&directory, &retired).unwrap();
	symlink(&retired, &directory).unwrap();
	for pin in [&pin, &cloned] {
		assert!(pin.verify_identity().is_err());
		assert!(pin.verify().is_err());
	}
	std::fs::remove_file(&directory).unwrap();
	std::fs::create_dir(&directory).unwrap();
	std::fs::write(&path, bytes).unwrap();
	std::fs::set_permissions(&path, std::fs::Permissions::from_mode(0o600)).unwrap();
	// The old leaf still exists, but the current path reaches a different inode.
	for pin in [&pin, &cloned] {
		assert!(pin.verify_identity().is_err());
		assert!(pin.verify().is_err());
	}
}

#[test]
fn cached_pins_keep_final_reopen_and_read_error_precedence() {
	use std::cell::Cell;

	let root = tempfile::tempdir().unwrap();
	let directory = root.path().join("current");
	std::fs::create_dir(&directory).unwrap();
	let path = directory.join("pin");
	let bytes = b"unchanged leaf stamp";
	std::fs::write(&path, bytes).unwrap();
	std::fs::set_permissions(&path, std::fs::Permissions::from_mode(0o600)).unwrap();
	let (pin, _) = PinnedFile::load(&path, None, bytes.len(), true, false).unwrap();
	let mut file = pin.open_path().unwrap();
	let stamp = Stamp::of(&file.metadata().unwrap());
	let mut read = Vec::new();
	file.read_to_end(&mut read).unwrap();
	assert_eq!(read.as_slice(), bytes.as_slice());
	let checks = Cell::new(0);
	pin.verify_checked(&|| {
		checks.set(checks.get() + 1);
		Ok(())
	})
	.unwrap();
	// Use the existing check boundary after the complete read, before verify_read.
	let before_reopen = checks.get() - 2;
	checks.set(0);
	let error = pin
		.verify_checked(&|| {
			checks.set(checks.get() + 1);
			if checks.get() == before_reopen {
				let retired = root.path().join("retired");
				std::fs::rename(&directory, &retired).unwrap();
				symlink(&retired, &directory).unwrap();
			}
			Ok(())
		})
		.unwrap_err();
	assert_eq!(checks.get(), before_reopen);
	// Renaming an ancestor does not change the open leaf: only a fresh path walk
	// can find the alias, including on the final post-read verification.
	assert_eq!(stamp, Stamp::of(&file.metadata().unwrap()));
	assert!(matches!(
		error
			.downcast_ref::<std::io::Error>()
			.unwrap()
			.raw_os_error(),
		Some(libc::ENOTDIR) | Some(libc::ELOOP)
	));
	for (length, maximum) in [(read.len() - 1, read.len()), (read.len(), read.len() - 1)] {
		let error = verify_read(|| pin.open_path(), &file, &stamp, length, maximum).unwrap_err();
		assert_eq!(error.to_string(), "observation profile input changed");
	}
	file.set_permissions(std::fs::Permissions::from_mode(0o644))
		.unwrap();
	let error = verify_read(|| pin.open_path(), &file, &stamp, read.len(), read.len()).unwrap_err();
	assert_eq!(error.to_string(), "observation profile input changed");
}

#[test]
fn pin_loading_keeps_path_io_and_inode_errors_before_expected_digest() {
	for path in [Path::new("relative"), Path::new("/invalid/\0")] {
		let error = PinnedFile::load(path, Some("invalid"), 1024, true, false)
			.err()
			.unwrap();
		assert_eq!(error.to_string(), "unsupported observation profile path");
	}
	let root = tempfile::tempdir().unwrap();
	let path = root.path().join("pin");
	let error = PinnedFile::load(&path, Some("invalid"), 1024, true, false)
		.err()
		.unwrap();
	assert_eq!(
		error
			.downcast_ref::<std::io::Error>()
			.unwrap()
			.raw_os_error(),
		Some(libc::ENOENT)
	);
	std::fs::write(&path, b"cold pin validation").unwrap();
	std::fs::set_permissions(&path, std::fs::Permissions::from_mode(0o644)).unwrap();
	let error = PinnedFile::load(&path, Some("invalid"), 1024, true, false)
		.err()
		.unwrap();
	assert_eq!(
		error.to_string(),
		"unsupported observation profile inode or byte bound"
	);
	std::fs::set_permissions(&path, std::fs::Permissions::from_mode(0o600)).unwrap();
	let error = PinnedFile::load(&path, Some("invalid"), 1024, true, false)
		.err()
		.unwrap();
	assert_eq!(error.to_string(), "observation profile byte pin mismatch");
}

#[test]
fn exact_file_pins_reject_inplace_changes_symlinks_hardlinks_and_permissions() {
	let root = tempfile::tempdir().unwrap();
	let path = root.path().join("config");
	std::fs::write(&path, b"one").unwrap();
	std::fs::set_permissions(&path, std::fs::Permissions::from_mode(0o600)).unwrap();
	let (pin, _) = PinnedFile::load(&path, None, 1024, true, false).unwrap();
	pin.verify().unwrap();
	std::fs::write(&path, b"two").unwrap();
	assert!(pin.verify().is_err());
	let link = root.path().join("link");
	symlink(&path, &link).unwrap();
	assert!(PinnedFile::load(&link, None, 1024, true, false).is_err());
	std::fs::remove_file(&link).unwrap();
	std::fs::hard_link(&path, &link).unwrap();
	assert!(PinnedFile::load(&path, None, 1024, true, false).is_err());
	std::fs::remove_file(link).unwrap();
	std::fs::set_permissions(&path, std::fs::Permissions::from_mode(0o644)).unwrap();
	assert!(PinnedFile::load(&path, None, 1024, true, false).is_err());
}

#[test]
fn streamed_pins_check_every_chunk_and_the_partial_tail() {
	let root = tempfile::tempdir().unwrap();
	let path = root.path().join("large-pin");
	let mut bytes: Vec<u8> = (0..VERIFY_BUFFER_BYTES * 13 + 7)
		.map(|index| (index % 251) as u8)
		.collect();
	std::fs::write(&path, &bytes).unwrap();
	std::fs::set_permissions(&path, std::fs::Permissions::from_mode(0o600)).unwrap();
	let (mut pin, _) = PinnedFile::load(&path, None, bytes.len(), true, false).unwrap();
	pin.verify().unwrap();
	for position in [
		0,
		VERIFY_BUFFER_BYTES - 1,
		VERIFY_BUFFER_BYTES * 7,
		bytes.len() - 1,
	] {
		bytes[position] ^= 1;
		std::fs::write(&path, &bytes).unwrap();
		// Isolate byte verification from the independent metadata fence.
		pin.stamp = Stamp::of(&std::fs::metadata(&path).unwrap());
		assert!(pin.verify().is_err(), "missed changed byte {position}");
		bytes[position] ^= 1;
		std::fs::write(&path, &bytes).unwrap();
		pin.stamp = Stamp::of(&std::fs::metadata(&path).unwrap());
		pin.verify().unwrap();
	}
}

#[test]
fn streamed_pins_keep_length_and_path_identity_fences() {
	let root = tempfile::tempdir().unwrap();
	let path = root.path().join("pin");
	let bytes = vec![7; VERIFY_BUFFER_BYTES + 3];
	std::fs::write(&path, &bytes).unwrap();
	std::fs::set_permissions(&path, std::fs::Permissions::from_mode(0o600)).unwrap();
	let (pin, _) = PinnedFile::load(&path, None, bytes.len(), true, false).unwrap();
	for length in [bytes.len() - 1, bytes.len() + 1] {
		std::fs::OpenOptions::new()
			.write(true)
			.open(&path)
			.unwrap()
			.set_len(length as u64)
			.unwrap();
		assert!(pin.verify().is_err());
	}
	std::fs::rename(&path, root.path().join("original")).unwrap();
	std::fs::write(&path, &bytes).unwrap();
	std::fs::set_permissions(&path, std::fs::Permissions::from_mode(0o600)).unwrap();
	assert!(pin.verify().is_err());
	let target = root.path().join("target");
	std::fs::rename(&path, &target).unwrap();
	symlink(&target, &path).unwrap();
	assert!(pin.verify().is_err());
}

#[test]
fn directory_identity_survives_owned_membership_but_detects_replacement() {
	let root = tempfile::tempdir().unwrap();
	std::fs::set_permissions(root.path(), std::fs::Permissions::from_mode(0o700)).unwrap();
	let before = private_directory(root.path()).unwrap();
	std::fs::write(root.path().join("owned"), b"bounded").unwrap();
	let after = private_directory(root.path()).unwrap();
	assert!(before.same_directory(&after));
	let other = tempfile::tempdir().unwrap();
	std::fs::set_permissions(other.path(), std::fs::Permissions::from_mode(0o700)).unwrap();
	assert!(!before.same_directory(&private_directory(other.path()).unwrap()));
}

#[test]
fn only_the_fixed_system_shell_alias_has_a_pinned_symlink_exception() {
	let (target, components) = fixed_shell_resolution().unwrap();
	assert_eq!(target, std::fs::canonicalize("/bin/sh").unwrap());
	assert!(components.iter().all(|node| node.stamp.uid == 0));
	let hash = digest(&std::fs::read(&target).unwrap())
		.iter()
		.map(|v| format!("{v:02x}"))
		.collect::<String>();
	let mut reference_budget = MAX_EXECUTABLE_REFERENCE_BYTES;
	let shell = PinnedShell::load(&hash, &mut reference_budget).unwrap();
	shell.verify().unwrap();
	assert!(PinnedShell::load(&"0".repeat(64), &mut reference_budget).is_err());
	assert!(
		open_absolute(Path::new("/bin/sh"), false).is_err()
			|| std::fs::symlink_metadata("/bin/sh").unwrap().is_file()
	);
}

fn identities(key: &[u8]) -> Vec<u8> {
	let mut bytes = vec![12, 0, 0, 0, 1];
	bytes.extend_from_slice(&(key.len() as u32).to_be_bytes());
	bytes.extend_from_slice(key);
	bytes.extend_from_slice(&0u32.to_be_bytes());
	bytes
}

#[test]
fn agent_frames_are_bounded_exact_and_key_changes_are_not_socket_identity() {
	let first = identities(b"public-test-key-one");
	let second = identities(b"public-test-key-two");
	assert_ne!(
		agent_identities(&first).unwrap(),
		agent_identities(&second).unwrap()
	);
	for bad in [
		vec![],
		vec![5],
		vec![12, 0, 0, 0, 0],
		vec![12, 0, 0, 0, 65],
		first[..first.len() - 1].to_vec(),
	] {
		assert!(agent_identities(&bad).is_err());
	}
	let mut extra = first;
	extra.push(0);
	assert!(agent_identities(&extra).is_err());
	for path in [
		"relative",
		"/private/../socket",
		"/private/./socket",
		"/private/%h",
		"/private/a b",
		"/private/${UNDECLARED}/socket",
		"/private/`command`",
		"/private/\"quoted\"",
		"/private/back\\slash",
	] {
		assert!(absolute(Path::new(path)).is_err());
	}
}

#[tokio::test]
async fn direct_agent_identity_includes_response_bytes_and_rejects_replaced_socket() {
	let root = tempfile::tempdir().unwrap();
	std::fs::set_permissions(root.path(), std::fs::Permissions::from_mode(0o700)).unwrap();
	let path = root.path().join("agent");
	let listener = tokio::net::UnixListener::bind(&path).unwrap();
	std::fs::set_permissions(&path, std::fs::Permissions::from_mode(0o775)).unwrap();
	let server = tokio::spawn(async move {
		for key in [b"key-one".as_slice(), b"key-two".as_slice()] {
			let (mut stream, _) = listener.accept().await.unwrap();
			let mut request = [0; 5];
			stream.read_exact(&mut request).await.unwrap();
			assert_eq!(request, [0, 0, 0, 1, 11]);
			let response = identities(key);
			stream
				.write_all(&(response.len() as u32).to_be_bytes())
				.await
				.unwrap();
			stream.write_all(&response).await.unwrap();
		}
	});
	let first = agent_snapshot(&path, Instant::now() + std::time::Duration::from_secs(2))
		.await
		.unwrap();
	let second = agent_snapshot(&path, Instant::now() + std::time::Duration::from_secs(2))
		.await
		.unwrap();
	assert_eq!(first.stamp, second.stamp);
	assert_ne!(first, second);
	server.await.unwrap();
	std::fs::remove_file(&path).unwrap();
	std::fs::write(&path, b"not a socket").unwrap();
	assert!(
		agent_snapshot(&path, Instant::now() + std::time::Duration::from_secs(1))
			.await
			.is_err()
	);
}

#[tokio::test(flavor = "current_thread")]
async fn owner_rechecks_changed_file_boundaries_after_complete_worker_validation() {
	use super::super::validation::Workers;
	use std::sync::Arc;
	use std::time::Duration;
	for mutation in ["bytes", "replacement", "permissions", "hardlink"] {
		let root = tempfile::tempdir().unwrap();
		let path = root.path().join("worker-pin");
		std::fs::write(&path, b"original").unwrap();
		std::fs::set_permissions(&path, std::fs::Permissions::from_mode(0o600)).unwrap();
		let (pin, _) = PinnedFile::load(&path, None, 1024, true, false).unwrap();
		let pin = Arc::new(pin);
		let checked = pin.clone();
		let stop = tokio_util::sync::CancellationToken::new();
		let workers = Workers::new();
		let ticket = workers
			.run_retained(
				&stop,
				Instant::now() + Duration::from_secs(2),
				move |ticket| checked.verify_checked(&|| ticket.check_current()),
			)
			.await
			.unwrap();
		pin.verify_identity().unwrap();
		match mutation {
			"bytes" => std::fs::write(&path, b"modified").unwrap(),
			"replacement" => {
				std::fs::rename(&path, root.path().join("old")).unwrap();
				std::fs::write(&path, b"original").unwrap();
				std::fs::set_permissions(&path, std::fs::Permissions::from_mode(0o600)).unwrap();
			}
			"permissions" => {
				std::fs::set_permissions(&path, std::fs::Permissions::from_mode(0o644)).unwrap()
			}
			"hardlink" => std::fs::hard_link(&path, root.path().join("alias")).unwrap(),
			_ => unreachable!(),
		}
		assert!(
			ticket
				.finish(|ticket| pin.verify_checked(&|| ticket.check_current()))
				.is_err(),
			"missed {mutation} after worker completion"
		);
		assert!(stop.is_cancelled());
		workers.drain().await.unwrap();
	}
}

#[tokio::test(flavor = "current_thread")]
async fn owner_full_hash_rejects_existing_shared_mapping_tail_change() {
	use super::super::validation::Workers;
	use std::time::Duration;

	struct Mapping {
		address: *mut u8,
		length: usize,
	}
	impl Drop for Mapping {
		fn drop(&mut self) {
			unsafe { libc::munmap(self.address.cast(), self.length) };
		}
	}

	let root = tempfile::tempdir().unwrap();
	let path = root.path().join("owner-mapped-pin");
	let bytes = vec![31; VERIFY_BUFFER_BYTES * 3 + 7];
	std::fs::write(&path, &bytes).unwrap();
	std::fs::set_permissions(&path, std::fs::Permissions::from_mode(0o600)).unwrap();
	let (mut pin, _) = PinnedFile::load(&path, None, bytes.len(), true, false).unwrap();
	let file = std::fs::OpenOptions::new()
		.read(true)
		.write(true)
		.open(&path)
		.unwrap();
	let address = unsafe {
		libc::mmap(
			std::ptr::null_mut(),
			bytes.len(),
			libc::PROT_READ | libc::PROT_WRITE,
			libc::MAP_SHARED,
			file.as_raw_fd(),
			0,
		)
	};
	assert_ne!(address, libc::MAP_FAILED);
	let mapping = Mapping {
		address: address.cast(),
		length: bytes.len(),
	};
	let checked = pin.clone();
	let stop = tokio_util::sync::CancellationToken::new();
	let workers = Workers::new();
	let ticket = workers
		.run_retained(
			&stop,
			Instant::now() + Duration::from_secs(8),
			move |ticket| checked.verify_checked(&|| ticket.check_current()),
		)
		.await
		.unwrap();
	// The writable MAP_SHARED mapping predates the worker. It changes the
	// partial tail after completion without a write/open event as authority.
	unsafe { mapping.address.add(bytes.len() - 1).write_volatile(30) };
	assert_eq!(
		unsafe { libc::msync(address, bytes.len(), libc::MS_SYNC) },
		0
	);
	// Test-only metadata rebasing isolates the content check from timestamp
	// precision. Production never rebases the pin or its expected digest.
	pin.stamp = Stamp::of(&std::fs::metadata(&path).unwrap());
	pin.verify_identity().unwrap();
	let error = ticket
		.finish(|ticket| pin.verify_checked(&|| ticket.check_current()))
		.unwrap_err();
	assert_eq!(error.to_string(), "observation profile changed");
	assert!(stop.is_cancelled());
	workers.drain().await.unwrap();
}

#[tokio::test(flavor = "current_thread")]
async fn worker_full_hash_is_not_replaced_by_owner_metadata_check() {
	use super::super::validation::Workers;
	use std::time::Duration;
	let root = tempfile::tempdir().unwrap();
	let path = root.path().join("complete-worker-pin");
	let mut bytes = vec![23; VERIFY_BUFFER_BYTES * 3 + 7];
	std::fs::write(&path, &bytes).unwrap();
	std::fs::set_permissions(&path, std::fs::Permissions::from_mode(0o600)).unwrap();
	let (mut pin, _) = PinnedFile::load(&path, None, bytes.len(), true, false).unwrap();
	pin.verify().unwrap();
	*bytes.last_mut().unwrap() ^= 1;
	std::fs::write(&path, &bytes).unwrap();
	// Isolate complete-byte verification from the independent metadata fence,
	// as the existing streamed-pin tests do. Production never rebases a pin.
	pin.stamp = Stamp::of(&std::fs::metadata(&path).unwrap());
	pin.verify_identity().unwrap();
	let stop = tokio_util::sync::CancellationToken::new();
	let workers = Workers::new();
	assert!(workers
		.run(&stop, Instant::now() + Duration::from_secs(2), move || pin
			.verify())
		.await
		.is_err());
	assert!(stop.is_cancelled());
	workers.drain().await.unwrap();
}
