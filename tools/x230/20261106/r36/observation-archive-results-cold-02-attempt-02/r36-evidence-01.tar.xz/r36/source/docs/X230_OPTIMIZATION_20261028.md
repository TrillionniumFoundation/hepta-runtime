# X230 concurrency, resource and recovery integration — 2026-10-28

## Provenance and review boundary

This branch composes A55 (`463963580c2f34ef46032f7d80c79b4d4c59edb3`), the native-library and audit qualification work from PR 75 (`d7d039458c8745bea1bafd24f03635e75a66a2f4`), and the previously unpublished A56–A62 source retained on the X230. The preserved A62 source archive contains 175 files and has SHA-256 `3aab0e642709af973df3fe2932bfc9acd36d34d2bfd5ea57b91116da281e647c`.

Historical results qualify their original source and ELF only. The composed source needs a new qualification. The current validation status and exact source maps are recorded under `tests/evidence/20261028-x230/` when the run is complete. No production runtime service is changed by these experiments.

## Changes in this integration

### Bounded lookup work without blocking the async executor

Job binding lookup moves its synchronous filesystem scan into a blocking worker with four global admission permits. A permit follows the actual worker even if its caller is cancelled. Cancelling while waiting for admission does not submit work. The existing per-key launch lane and execution fence remain with the caller; a read worker cannot launch or replay a job.

Exact-key lookup validates every existing JSON receipt, including unrelated corrupt history and duplicate bindings. The positive reuse cache is capped at 4,096 entries. Linux content watches invalidate positive hits on in-place writes and permission changes as well as directory changes. A missing watch never authorizes a positive hit. Each event drain is limited to 64 read attempts and 16,384 events, including interrupted attempts; exhaustion retires its tokens and returns an error rather than monopolizing a shared lock.

Without a reliable watch, lookup uses two complete streaming scans with decoded-record fingerprints. It does not collect or sort all pathnames. The same root identity is pinned, sustained mutation is limited to three attempts, and malformed or duplicate history fails immediately. Memory scales with the selected record and one current input, subject to the existing four-MiB record limit, rather than the number of receipts. The four-worker cap bounds concurrent work, not the duration of a stalled filesystem operation.

A previously strict original is re-read within the final validation fence, preventing a permission downgrade between the first read and a compatibility scan. Strict cached reads use `O_NONBLOCK` as well as `O_NOFOLLOW`, so a regular-file-to-FIFO race cannot occupy a worker indefinitely. Only an actually strict-validated record can acquire strict cache status; compatible legacy records continue through full validation.

### Archive concurrency and allocation work retained from A56–A62

Two FIFO shared readers may validate eligible snapshots concurrently. Queued writers cannot be bypassed, and reservations cover actual I/O completion rather than only the lifetime of the waiting future. The batching collection window is two milliseconds; existing three-second operation deadlines remain unchanged.

Snapshot reuse requires a reliable content watch, a stable owned root, matching generations, no pending write, and final database/watch identity checks. Borrowed JSON field validation, reused binary identifiers, stack filename buffers and shared namespace metadata reduce repeated allocations and syscalls. Removed diagnostics are not counted as performance improvements.

### Durable execution and conservative recovery

Startup intent and owner namespaces retain their required directory-sync barriers. Captured output tracks EOF, byte caps, errors, truncation and fsync; file EOF alone does not prove complete output. A versioned terminal result is confirmed only by the witness bound to the exact original receipt bytes.

`jobctl status` re-reads terminal evidence after querying systemd. A collected or failed unit without a confirmed terminal result is reported as non-authoritative with unknown outcome and automatic retry disabled. Reboot without terminal evidence also preserves unknown outcome. A late cancellation acknowledgment cannot overwrite an already witnessed original success or failure. Legacy receipt behavior remains explicit and compatible.

Native lost-ack observation and safe persisted record reads from PR 75 are retained. Shutdown now freezes direct SSH transport alongside queued requests, operations and pooled observations. Linux direct SSH children retain the parent-death ownership guard from A62.

## Validation method

The qualification runner formats the frozen source, runs strict all-target/all-feature Clippy, builds all test executables, and executes every non-ignored exact case in a fresh process. Each original command, inventory, output and executable hash is retained. An independent auditor rejects exit-zero-with-no-test and running-zero-tests false positives, checks exact coverage and ignored identities, and verifies original compressed logs and executable hashes. Tests are not automatically retried.

Release binaries and source maps are bound to the completed gates. Native validation uses a current forwarded SSH agent and the existing pinned host-key profile, with fresh private fixtures on the six configured hosts. Its stages include inherited-pipe cases, six original running jobs surviving controller SIGKILL, file observation ABBA at C1/C4/C8, and a separately labelled 120-second C8 soak. No credentials or host-key checks are bypassed. A sampled compiler or heptabao workload invalidates the affected performance stage rather than being stopped.

The registry microbenchmark compares retained A62 and candidate test executables in fixed ABBA order. It measures synchronous exact-key lookup, not end-to-end job launch throughput. The six-host file benchmark measures tiny immutable files, not bulk transfer bandwidth. Every measured sample and failure remains part of its report.

## Persistence trust boundary

The private registry and its cooperating owner are part of the trust boundary. These scans are not filesystem transactions: two scans cannot prove a single atomic snapshot against an unrelated same-UID writer that repeatedly changes bindings between reads. Inotify also does not report memory-mapped writes; see the Linux [inotify(7) limitations](https://man7.org/linux/man-pages/man7/inotify.7.html). Consequently, positive caching is not an integrity boundary against an uncooperative process with the same filesystem authority. Such a threat model requires a shared write protocol or a separate protected storage service. Normal receipt publication, detectable mutation, watcher loss and bounded validation failures remain conservative.

## Practical stopping criteria and remaining limits

A candidate is accepted only after the exact source passes the required gates and each performance claim has an appropriate measured scope. A failed gate is retained with its explanation. Repeating measurements merely to obtain a favorable run is not an optimization.

These experiments do not prove behavior during physical power loss, target reboot, WAN partition or production ownership transfer. They do not establish globally optimal throughput. Further work that changes the persistence contract, relaxes validation, depends on new hardware, or requires a distinct workload needs a separate design and experiment; those changes are not implied by a faster microbenchmark.
