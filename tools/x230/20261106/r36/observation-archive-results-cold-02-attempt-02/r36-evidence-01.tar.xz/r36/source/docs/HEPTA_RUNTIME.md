# Hepta Runtime architecture and operating contract

Hepta Runtime is an Apache-2.0 fork of Octofs pinned to upstream commit
`37b5d3d02be511bae86d91fa980996a5fe257d7b`. It keeps Octofs file tools and
adds an explicit multi-host operations plane.

## Design goals

- Every remote operation names a configured host. Tool calls never accept raw
  SSH destinations, private keys, or ports.
- Process execution accepts an executable and argv, not a shell command string.
- Long jobs keep durable metadata and logs and continue when the MCP transport
  or Hepta Runtime controller restarts.
- Interactive PTYs are a separate, intentionally ephemeral facility.
- Ordinary execution uses a dedicated unprivileged SSH identity.
- Root operations are exact named actions configured by an administrator; the
  model cannot supply an arbitrary privileged executable.
- Hardware, service and network inspection is read-only and typed.
- Remote file writes are host-registered, explicitly enabled, and constrained
  to absolute allowlisted roots.

## Architecture

```text
ChatGPT / Codex / Responses API
              |
      OpenAI Secure MCP Tunnel
              | outbound HTTPS only
              v
 tunnel-client (dedicated account)
              |
   127.0.0.1:8787/mcp only
              v
       hepta-runtime
              |
        OpenSSH client
       /      |       \
     rog   pocket4    mac
      |        |        |
 dedicated unprivileged target accounts
```

The controller does not expose a public listener. The Streamable HTTP endpoint
is bound to loopback and the official tunnel client reaches it locally. Runtime
HTTP mode requires a high-entropy token file; every `/mcp` request must carry
`X-Hepta-Runtime-Token`. Health and readiness probes contain no host data.

## Tool contract

### Durable process tools

- `process_start`: explicit host, executable, argv, cwd, environment, optional
  stdin, timeout and resource limits. A nonblank **required** `idempotency_key`
  (at most 256 bytes) binds to one exact request. Retrying with the same host,
  key and request reconciles the original job rather than starting a duplicate;
  changing the payload under the same key fails closed.
- `process_status`: authoritative remote state.
- `process_read`: independent stdout/stderr byte offsets, bounded pagination.
- `process_wait`: bounded wait, never a new process.
- `process_cancel`: only stored jobs; no arbitrary PID input.
- `process_list`: durable controller-side identities.

On Linux, the dedicated SSH identity can invoke only the no-argument root-owned
`hepta-runtime-jobctl` binary through a narrow sudoers entry. That binary accepts
bounded, typed JSON for start/status/read/cancel/PTY, validates a root-owned host
policy, and creates a transient **system** systemd unit. Workloads run under a
separate DynamicUser, not root and not the controller SSH identity. The unit
hides controller state/credentials and user homes, uses a private network by
default, and grants write access only to the workspace and its own result data.
The independent aggregate job slice limits CPU, memory and task counts.

Controller startup acquires a nonblocking OS-level exclusive lock on
both `controller.lock` and `controller.owner.lock` inside its canonical,
non-world-writable state directory. Holding the legacy lock also fences an
older controller that only recognizes that filename.
A second controller using that state refuses startup, including after tunnel
reconnects; the lock lasts for the owning process and is released on exit.
State directories on network filesystems need separately qualified locking
semantics and are not assumed safe merely because the file exists.

A controller restart does not terminate durable jobs. A remote host reboot is
not claimed as process recovery in v0.1: logs and metadata remain, but an
in-flight transient unit is reported lost unless the application itself has a
separate restart policy.

Root-owned records bind the job ID, full SHA-256 request digest, boot ID, random
nonce, unit name and systemd invocation identity. New idempotent requests bind
all 256 bits; legacy controller records remain readable but cannot silently
relaunch through a missing full-digest binding. Completed exit records are
preserved across target boots; interrupted in-flight jobs are reported lost and
are never automatically repeated. Invalid completion identities fail closed.

The macOS backend remains a Python detached supervisor under the dedicated
unprivileged account. It verifies stored process identity for cancellation but
does **not** provide Linux namespace/DynamicUser isolation; administrators must
explicitly enable its fallback/network policy.

A controller-side `launch_failed` record means the launch acknowledgement failed,
not proof that no target process exists. Pending and failed acknowledgements
remain indeterminate and never authorize another launch. Reconcile the exact
original job ID and full request digest; status errors are reported explicitly.
Never retry an uncertain effect under a new key.

Duplicate entries in the durable controller store with the same host and
idempotency key are treated as conflicting owners even when their request
payloads appear identical. Recovery refuses automatic reuse and requires
manual reconciliation of each possible effect; selecting the oldest receipt
would silently discard evidence of a second launch.

The controller state-directory owner lock already serializes processes that
share one canonical local state directory. In-process start lock sharding does
not create distributed single-writer authority: controllers with separate
state directories pointing to one SSH host remain a distinct deployment
blocker and must not be promoted as a multi-controller configuration.

A duplicate `process_start` is observation-only after a stored `launched`
acknowledgement. Persisted `pending` and `launch_failed` rows remain
**indeterminate** and cannot dispatch a second remote launch, even if a prior
remote directory was erased or the target was rebooted. The operator must
reconcile exact original effect evidence; the runtime never treats remote
metadata absence as proof that a command did not execute.

Durable job observations remain bound to the SSH target and remote job root
recorded at original admission. If an administrator remaps a configured host
alias to another target or remote state directory, existing job launch retries,
status/wait, log reads and cancellations fail closed; manually reconcile the
original remote operation rather than following the changed alias. This guard
does not attest changes to DNS or OpenSSH alias resolution on its own: retain
strict host-key verification and independently qualify host identity.
Remote status/wait, stdout/stderr reads and cancellations additionally require the
remote request.json to match the locally persisted job ID, unit, job directory
and full 64-character SHA-256 request digest. A legacy job record lacking this
binding remains listable for manual reconciliation, but cannot drive a remote
observer or cancellation. A matching digest is not independent remote-host
attestation; separate host identity and terminal-effect acceptance remain required.

### PTY tools

`pty_start/read/write/close/list` provide interactive terminal sessions over
SSH. Output is held in a bounded offset-addressable ring buffer. PTYs survive
individual MCP calls and tunnel reconnects while the controller process remains
alive. They are deliberately terminated when the controller stops and are not
advertised as restart-persistent.

### Read-only inspection

- `hardware_snapshot`: DMI, CPU and memory, hwmon, GPU use and clocks, power
  supplies, supported platform power limits, NPU device nodes, and USB4 /
  Thunderbolt peers.
- `service_status`: exact systemd units or launchd labels; no mutation.
- `network_inspect`: links, addresses, routes, listeners and USB4 peers.

### Privileged actions

`privileged_action` selects an exact symbolic action from the host policy. The
policy fixes the absolute root-owned executable, fixed arguments, whether extra
arguments are accepted, and a timeout. The runtime invokes it through
`sudo -n`. Do not configure `/bin/sh`, `/usr/bin/env`, interpreters, package
managers, general-purpose file tools, or a wrapper accepting arbitrary shell
text as a privileged action.

Each \`privileged_action\` request must also include a nonblank caller-stable
\`idempotency_key\` (at most 256 bytes). The controller durably enters the
policy-resolved executable, arguments and timeout before any remote SSH effect.
An observed result is cached for same-key retries; a lost acknowledgement remains
\`indeterminate\` and MUST be reconciled, never automatically re-executed.
Changing the action or payload under the same key is rejected. The V2 intent
also binds the configured SSH target string: if a host alias is administratively
remapped, an old successful result cannot be reused as evidence for the new target.
V1 intent records are not automatically upgraded, replayed, or counted as V2 success;
they require independent operator reconciliation. This string binding does **not**
attest the physical host or protect against underlying DNS/SSH configuration changes
without separately checked server host keys and target identity.
This bounded
no-blind-replay mechanism does not make arbitrary sudo operations transactional,
does not prevent distinct authorized keys from invoking the same named action,
and is **not** an independently signed Hepta Final-use grant. Production activation
still requires issuer/revocation/generation binding and target-host fault tests.

## Policy boundary

The first and strongest boundary is the target operating-system identity. Use a
separate `hepta-runtime` account on every host. Give it only its runtime state
and workspace. Do not give it the target user's SSH keys, trading files,
browser profiles, provider credentials, or runner credentials.

The runtime adds defense in depth:

- default denial of sudo, shells, nested SSH, process signalling, service and
  package managers, mounts, containers, firewall tools and detached-session
  launchers;
- optional absolute cwd allowlists;
- write-root allowlists and protected path prefixes;
- protected argument substrings for known workloads;
- exact host binding for every job and PTY;
- process cancellation by stored unit/supervisor ownership, not caller PID;
- local JSONL audit records.

The policy is not a substitute for UNIX permissions. A deliberately allowed
interpreter can perform anything available to its target account. Keep the
account unprivileged and use exact privileged actions for the small set of root
operations that are truly needed.

## Local shell and file rules

When `--runtime-config` is active, the inherited unrestricted Octofs `shell`
tool is neither advertised nor callable. Durable `process_start` and ephemeral
`pty_start` are the only general execution paths; both require a configured
host, explicit executable/argv, and host policy approval.

Inherited local file tools are confined to canonicalized
`controller_workspace_roots`. Absolute paths, client-provided session workdirs,
nonexistent write targets, and symlink ancestors are checked against those
roots. Controller state, audit logs, SSH keys and `/etc/hepta-runtime` are not
file-tool-visible.

## Remote file rules

When `--runtime-config` is active, reads and writes to unregistered SSH hosts are denied.
Remote URLs may not override the registered user or port, may not use login-home
relative forms, and must fall under `allowed_read_path_prefixes` or
`allowed_write_path_prefixes`. Writes additionally require `allow_write=true`.
A registered host must set `allow_write=true`, provide at least one absolute
`allowed_write_path_prefixes` entry, and the target must not intersect a
protected prefix. Login-home-relative forms such as `ssh://host/~/file` are rejected in runtime
mode; use an absolute remote path.

Without `--runtime-config`, upstream Octofs compatibility is retained and these
fork-specific host policies are not active.

## Secure MCP Tunnel

Preferred deployment keeps the runtime on loopback and uses the official
OpenAI tunnel client as a separate service. Create a tunnel ID and a runtime API
key in OpenAI Platform. Keep that key in `/etc/hepta-runtime/tunnel-api-key` or a
secret manager; never put it in this repository. The same environment file sets
`MCP_SERVER_URL` to the loopback MCP endpoint, sends
`X-Hepta-Runtime-Token: file:/etc/hepta-runtime/mcp-token` for discovery and
normal MCP requests, and binds tunnel health to loopback.

The installed runtime-flavor binary exposes `run`, not the full development
CLI. After credentials are provisioned, enable the tunnel service and require
both its systemd state and `http://127.0.0.1:8788/health?details=true` to report
healthy before connecting ChatGPT.

## Deployment sequence

1. Build and test the exact locked source.
2. Install the controller and official tunnel client from checksum-verified
   artifacts.
3. Create the dedicated controller and target accounts.
4. Install an SSH key owned only by the controller account; pre-populate
   `known_hosts` and use `StrictHostKeyChecking=yes`.
5. Create `/var/lib/hepta-runtime/{state,workspaces,jobs}` on Linux targets.
6. Install a reviewed runtime policy at `/etc/hepta-runtime/runtime.json`.
7. Install only exact root-owned helper scripts and matching narrow sudoers
   entries when privileged actions are required.
8. Start `hepta-runtime.service`, verify MCP discovery locally, then start the
   tunnel service and verify health/readiness.
9. Test representative allowed operations and negative cases for protected
   paths, duplicate idempotency keys, arbitrary PIDs, sudo and shell launch.
10. Keep Desktop Commander as a rescue path until reboot, reconnect, durable
    job recovery and rollback tests pass on every target.

## Rollback

Stop and disable the two services, remove the tunnel profile and key, and
restore the previous binary symlink. Durable target job directories are not
deleted automatically. Inspect or archive them before removal.

## Known v0.1 boundaries

- Durable processes survive controller/tunnel restarts, not arbitrary target
  reboots.
- PTYs are controller-process scoped.
- The controller-side JSONL audit is not yet a tamper-evident hash chain.
- macOS uses a detached Python supervisor and weaker OS-identity isolation.
- Remote inspection and descriptor-safe file RPCs require Python 3. Core MCP,
  lifecycle coordination and the Linux privileged helper are Rust.
- Each Linux target retains at most 128 job identities before refusing new
  starts. Archive completed records administratively; do not erase idempotency
  history to make capacity appear available.
- Job logs are capped at 16 MiB per stream and PTY output at a 4 MiB ring.
  Keep important artifacts in the workspace, not unbounded stdout.
- Jobs may alter their own workspace/output; outputs are not a proof of trusted
  computation. Audit records are not cryptographic attestations.
- No GUI capture or desktop input API is included in v0.1.
- Hardware includes raw kernel fields and normalized C/W/RPM/Hz readings.
  Preserve field names and units; unavailable readings are null and requested
  power limits are not sustained-power evidence.

### No-follow remote observation and cancellation (source-only candidates)

Remote process_read, process_status and process_wait pin the absolute job
directory component-by-component without following symlinks. Request metadata,
logs and status state are opened relative to a pinned descriptor, rejecting
symlinks, hard links, non-regular inodes and corrupt/oversized metadata. The
request ceiling is 4 MiB and log page ceiling remains 1 MiB. For status and
cancel, even an optional corrupt exit/launch/started JSON is an error rather
than silently interpreted as missing terminal evidence.

Remote process_cancel additionally requires the pinned job directory to be
owned by the executing SSH user and owner-private, verifies the immutable job,
directory, unit and complete SHA-256 request binding, refuses an unknown launch
backend, and for a detached supervisor requires a stored process-start identity
matching the current PID plus the recorded runner command. It rechecks this
identity before escalating to SIGKILL. Its cancel-request marker is written via
a no-follow, exclusive temporary inode, fsync and descriptor-relative rename
only after validating the backend and supervisor identity, preventing a denied
PID cancellation from leaving a misleading marker. Configure a physical
absolute remote state root without symlinked path components.

These source changes reduce log/status/cancel path substitution and some
recycled-PID risks. They do NOT make launch/runner writes, remote control-group
termination, SFTP physical confinement, DNS/SSH identity, cross-controller
once-only ownership or credentialed target-host effects race-free. A PID can
still disappear between identity verification and kill; host-side systemd
ownership and independent acceptance remain necessary. No independent
Final-use or production authority is granted. Retain DRAFT / DENY_ALL /
HOLD_NO_GO until exact-source and prospective-merge Rust gates, real SSH
negative tests and independent operator/release reviews are complete.

## Tunnel account binding

The official runtime client is installed independently of cloud credentials.
Create a workspace-associated tunnel and a dedicated Tunnels Read+Use runtime
key in OpenAI Platform. Provision it from a root-owned 0600 file, without putting
the secret in command-line arguments or chat:

```sh
sudo /usr/local/sbin/hepta-runtime-provision-tunnel \
  --tunnel-id tunnel_ACTUAL_ID --key-file /root/hepta-tunnel-runtime-key
sudo /usr/local/sbin/hepta-runtime-provision-tunnel --check
```

The helper never reuses OpenClaw/Codex credentials, creates tunnels by guessing
an organization, or treats client installation as a connected ChatGPT app.
After tunnel health is valid, add the tunnel to the correct ChatGPT workspace
and verify `host_list` followed by a read-only `hardware_snapshot` tool call.

## Explicit operator extension

The default isolated contracts above remain unchanged. For the opt-in full-SSH-account execution mode, new shell/process-signal/sudo tools and separate qualification criteria, see [OPERATOR_MODE.md](OPERATOR_MODE.md). Operator mode intentionally changes the trust boundary and is not covered by the isolated-account sandbox claims above.
