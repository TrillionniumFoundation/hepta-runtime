"""Materialize the exact original CI plan once, then exec the reviewed runner."""
import hashlib
import json
import os
from pathlib import Path
import stat
import subprocess
import sys

SPEC = {'actual_pins': {'JOB_ID': '1a1b03513b4-fc05-6f0c', 'SOURCE_MAP_SHA': '6c6d3512c0c41268e975ad40d0c1d6642cddec7757c4f0bbe4e1a97580e3988b', 'ISOLATED_SUMMARY_SHA': '0b5b1f4b7d921b591b38dc577e72b77c81be2623dfe7151913e25256a013b3e8', 'ISOLATED_AUDIT_SHA': 'c1e51bbf0a7229cc57bb5a0039b361376c02a7bf8036eed2ee36b739ca7bb0e3', 'QUALIFICATION_REPORT_SHA': '13faedb85f2a4d356575733deda6b51009dfe0f14399da7424032523dba2f492', 'PREPARATION_SHA': '03c828f842d979427e70e7c0a6b3a15e52fa1611d10fa5c3b1091817a93b9222', 'NATIVE_TERMINAL_SHA': '36525ded92c0da8e968852f8fa7f09b24961002f7600b96f1913906a08b637ff', 'PARENT_SHA': '7cb886eccbefb6f52464e2c0bbab995d185349864afd9f53eaf1a36334d0ae95', 'QUALIFICATION_BINDINGS_SHA': 'b3eb34e164a7211e168fbea6a1a3de8f8ea6d792592e69829cc5bd2df0113c81', 'FROZEN_COUNTS': {'passed': 1645, 'failed': 0, 'ignored': 34, 'selected': 1679, 'retries': 0}}, 'qualification_report': {'path': '/home/qian/hepta-runtime-optimization-20261106-r36/qualification-01/report.json', 'bytes': 83360, 'sha256': '13faedb85f2a4d356575733deda6b51009dfe0f14399da7424032523dba2f492'}, 'tools': {'run_rust_ci_01.py': {'bytes': 15182, 'sha256': '90c2ca749191c706f7980738c7907811fcd27d383b39492ab91b5ae618b89b00'}, 'audit_nextest_0137.py': {'bytes': 8563, 'sha256': '03fc242ae6ba3f5fa2fc948d3401e5f93a7a388ee9edb5b703183d6410aab8d2'}, 'canonical-workflow.yml': {'bytes': 7631, 'sha256': 'b9061fd671ac5fff33ad47d7ec5787f82cfadd88f5e71d54a8825cb55a02cd51'}, 'materialize_rust_ci_plan_01.py': {'bytes': 25785, 'sha256': '15eb84a0a03219b0b0594c5bf12e23dd35f259696a8bba259b541c24d89377ef'}}, 'manifest': {'bytes': 1005, 'sha256': '6c075d5101a6a58e9333f96b7e5ce120588fda2b8e2b998248ed89621781730c'}}
ROOT = Path('/home/qian/hepta-runtime-optimization-20261106-r36')
TOOLS = ROOT / 'rust-ci-tools-01'
PLAN = ROOT / 'rust-ci-plan-01.json'
OUT = ROOT / 'rust-ci-01'
CI_MANIFEST = Path('/home/qian/hepta-runtime-optimization-20261105-r25/ci-gates/ci-gate-manifest.json')
SELF = TOOLS / 'launch_exact_rust_ci_01.py'
NAMES = {'materialize_rust_ci_plan_01.py', 'run_rust_ci_01.py', 'audit_nextest_0137.py', 'canonical-workflow.yml'}


def need(value, reason):
    if not value:
        raise ValueError(reason)


def raw(path):
    need(path.resolve(strict=True) == path, 'indirect reviewed input')
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK | os.O_CLOEXEC)
    with os.fdopen(fd, 'rb') as stream:
        before = os.fstat(stream.fileno())
        need(stat.S_ISREG(before.st_mode) and before.st_uid == os.geteuid() and before.st_nlink == 1
             and 0 < before.st_size <= 16 * 1024 * 1024, 'unsafe or oversized reviewed input')
        body = stream.read(before.st_size + 1)
        after = os.fstat(stream.fileno())
    fields = ('st_dev', 'st_ino', 'st_mode', 'st_uid', 'st_nlink', 'st_size', 'st_mtime_ns', 'st_ctime_ns')
    need(len(body) == before.st_size and all(getattr(before, k) == getattr(after, k)
         == getattr(path.lstat(), k) for k in fields), 'reviewed input changed during read')
    return body


def identity(body):
    return {'bytes': len(body), 'sha256': hashlib.sha256(body).hexdigest()}


need(type(SPEC) is dict, 'actual qualification package is not bound')
need(sys.platform == 'linux' and os.geteuid() != 0 and Path(__file__).resolve() == SELF,
     'fixed native Linux CI launcher required')
need(len(sys.argv) == 3 and sys.argv[1] == '--launcher-sha256'
     and hashlib.sha256(raw(SELF)).hexdigest() == sys.argv[2], 'actual launcher identity differs')
need(TOOLS.resolve(strict=True) == TOOLS and not os.path.lexists(PLAN) and not os.path.lexists(OUT),
     'fresh plan/output paths required; original CI must not be replayed')
need({p.name for p in TOOLS.iterdir()} == NAMES | {'package-manifest-01.json', SELF.name},
     'fixed six-file tool inventory differs')
manifest_raw = raw(TOOLS / 'package-manifest-01.json')
need(identity(manifest_raw) == SPEC['manifest'], 'frozen tool manifest differs')
manifest = json.loads(manifest_raw)
need(manifest['schema'] == 'hepta-r36-exact-rust-ci-tools/v1' and manifest['attempt'] == '01'
     and manifest['actual_qualification_job_id'] == SPEC['actual_pins']['JOB_ID']
     and manifest['qualification_report'] == SPEC['qualification_report']
     and manifest['executed'] is False and manifest['hosted_actions_passed'] is False
     and manifest['files'] == SPEC['tools'] and set(manifest['files']) == NAMES,
     'actual qualification/tool manifest binding differs')
for name, expected in SPEC['tools'].items():
    need(identity(raw(TOOLS / name)) == expected, 'reviewed tool differs: ' + name)
command = ['/usr/bin/python3', '-I', '-B', str(TOOLS / 'materialize_rust_ci_plan_01.py'),
    '--qualification-sha256', SPEC['actual_pins']['QUALIFICATION_REPORT_SHA'],
    '--terminal-status-sha256', SPEC['actual_pins']['NATIVE_TERMINAL_SHA'],
    '--ci-manifest', str(CI_MANIFEST), '--out', str(PLAN)]
print(json.dumps({'phase': 'materialize', 'automatic_retries': 0,
                  'qualification_job_id': SPEC['actual_pins']['JOB_ID'],
                  'tools_manifest_sha256': SPEC['manifest']['sha256']}), flush=True)
result = subprocess.run(command, cwd=ROOT, timeout=300)
if result.returncode != 0:
    raise SystemExit(result.returncode)
plan_sha = hashlib.sha256(raw(PLAN)).hexdigest()
need(identity(raw(TOOLS / 'package-manifest-01.json')) == SPEC['manifest'], 'manifest changed during materialization')
for name, expected in SPEC['tools'].items():
    need(identity(raw(TOOLS / name)) == expected, 'tool changed during materialization: ' + name)
need(hashlib.sha256(raw(SELF)).hexdigest() == sys.argv[2], 'launcher changed during materialization')
print(json.dumps({'phase': 'execute_original_ci', 'plan_sha256': plan_sha, 'automatic_retries': 0}), flush=True)
sys.stdout.flush()
sys.stderr.flush()
os.execv('/usr/bin/python3', ['/usr/bin/python3', '-I', '-B', str(TOOLS / 'run_rust_ci_01.py'),
    '--plan', str(PLAN), '--plan-sha256', plan_sha,
    '--materializer-sha256', SPEC['tools']['materialize_rust_ci_plan_01.py']['sha256'],
    '--auditor-sha256', SPEC['tools']['audit_nextest_0137.py']['sha256']])
