# Preserved preparation attempt and r02 correction

The first x230 preparation attempt stopped with
`unique qualified release compiler-artifact required: serde_json`.
Job: `1a16cf9fe17-1b6abb-47ac`.
The existing `B/a27-observation-probe-build-r01/build.json` is retained. Formatting,
Rust compilation and probe execution had not begun. The original frozen r01
bundle remains unchanged.

Inspection of the already qualified release log found two `serde_json` artifacts
for the same Cargo.lock package/version, `serde_json 1.0.151`. Both are non-test
library artifacts in the release dependency directory. One has `opt_level="0"`
and features `default,std`; the other has `opt_level="3"` and features
`alloc,default,std`. The latter's complete profile equals the qualified runtime
profile, as do the other seven direct dependencies:

```json
{"debug_assertions":false,"debuginfo":0,"opt_level":"3","overflow_checks":false,"test":false}
```

The r01 selector checked only library kind, presence of an rlib and `test=false`.
Those conditions did not distinguish these two compilation uses. The inspected
records are preserved locally as `release-artifacts-inspection.json`, SHA256
`33360408e3b82640eaed0fa8d0b36c282ce5560ec0516747b3001c29064d4970`.
This digest identifies the local JSON copy, not a newly run workload.

r02 requires a complete profile match to the actual qualified runtime record and
exactly one rlib in that runtime's release dependency directory. It also checks
that the runtime record's optimization level matches the pinned Cargo release
profile. Selection must remain unique; zero or multiple matches still fail. It
retains every same-name compiler-artifact record with its selection/exclusion
reason in the build receipt. The original manifest, package ID, exact lockfile
version and full artifact hashing checks remain in force. Selection is independent
of record order and does not use a fixed hash filename, newest file or first match.

Only the preparation selector, its local regression checks and this explanation
change. PLAN.json, PLAN.md, the Rust probe/templates, runner, analyzer and candidate
patch remain byte-identical to r01. The fixed ABBA scale, statistics, deadline and
authority checks are unchanged. r02 uses fresh bundle/build/run paths; no probe
operation has been retried.
