#!/usr/bin/env python3
# Copyright 2026 Muvon Un Limited
# Copyright 2026 TrillionniumFoundation
# SPDX-License-Identifier: Apache-2.0
"""Generate and optionally compile two source-bound owner probes, never run them."""
import argparse
import difflib
import hashlib
import json
import os
from pathlib import Path
import re
import stat
import subprocess
import sys
import time
import tomllib

HERE = Path(__file__).resolve().parent
PINNED = {
    "src/mcp/runtime/ssh_observation_profile.rs": "4988b62ad917b4427c06875ba33f981af8f432f5df85932a5ef6a8a625a11e3e",
    "src/mcp/runtime/ssh_observation_pool.rs": "4d12d17f401161a546430fff811e00b67ad09f5585500f48d33e2f365ebc14ab",
    "src/mcp/runtime/ssh_observation_validation.rs": "dc254fcccfea85f27c21fa3496c6a20eee40936b2cceb5402d73ad207abecaa6",
    "src/mcp/runtime/config.rs": "30e42aa65d6a7d49af7f116e1e5b65468bbdb14a98fe0c16e4dd4d21f86a14ae",
    "src/mcp/runtime/config_tests.rs": "c7354e591a42a43615f7690ec2bfeba0d3de6992ead7dbe3488339986a1d6a9d",
    "src/mcp/runtime/ssh_observation_profile_tests.rs": "75f271fe1b44d379c8f5d68d66131e9d3a4b600e5437a2c558cb9f6ecca4e7a9",
    "src/mcp/runtime/ssh_observation_validation_tests.rs": "b74fd6acc5d780f8d939514f8eb4070d5e16d701e94f4a26c20612d34abe001e",
    "Cargo.toml": "3121870fbf66f65ce6b1925b3500eae8a05fc2d8019a2694da7d6fe941ad4d28",
    "Cargo.lock": "15b9fb468eb34a210238657d132cbf19e961552d1313de488e1f14936bfa4e5f",
    "rustfmt.toml": "bce79651b2e2ff42e1c54b9a26c5e17af5222f9f65ab51d9563a48fd159dae84",
}
# Exact A26 source receipts; no dependency version re-resolution.
DIRECT = ("anyhow", "libc", "regex", "ring", "serde", "serde_json", "tokio", "tokio_util")
BUNDLE_FILES = ("PLAN.json", "PLAN.md", "owner_probe.rs", "owner_module.rs.in", "path_semantics.rs",
                "prepare_owner_probe.py", "run_owner_probe.py", "summarize_owner_probe.py", "test_probe_tools.py",
                "FAILED_PREPARE_R01.md")


def need(value, message):
    if not value:
        raise ValueError(message)


def stamp(value):
    return (value.st_dev, value.st_ino, value.st_uid, value.st_mode, value.st_nlink,
            value.st_size, value.st_mtime_ns, value.st_ctime_ns)


def receipt(path, include_bytes=False):
    path = Path(path)
    before = path.lstat()
    need(stat.S_ISREG(before.st_mode), "regular nonsymlink input required: " + str(path))
    digest, chunks, total = hashlib.sha256(), [], 0
    fd = os.open(path, os.O_RDONLY | os.O_CLOEXEC | os.O_NOFOLLOW)
    with os.fdopen(fd, "rb") as stream:
        need(stamp(before) == stamp(os.fstat(stream.fileno())), "input changed while opening")
        while block := stream.read(1024 * 1024):
            digest.update(block)
            total += len(block)
            if include_bytes:
                need(total <= 32 * 1024 * 1024, "text input exceeds fixed bound")
                chunks.append(block)
        need(stamp(before) == stamp(os.fstat(stream.fileno())) == stamp(path.lstat())
             and total == before.st_size, "input changed while hashing")
    result = {"path": str(path), "sha256": digest.hexdigest(), "bytes": total, "stamp": list(stamp(before))}
    return (result, b"".join(chunks)) if include_bytes else result


def write_new(path, raw):
    with Path(path).open("xb") as stream:
        stream.write(raw)
        stream.flush()
        os.fsync(stream.fileno())


def checkpoint(directory, result, name="build.json"):
    temporary = directory / (name + ".next")
    write_new(temporary, (json.dumps(result, indent=2, sort_keys=True) + "\n").encode())
    os.replace(temporary, directory / name)
    fd = os.open(directory, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
    try:
        os.fsync(fd)
    finally:
        os.close(fd)


def span(text, start, end):
    need(text.count(start) == 1 and text.count(end) == 1, "ambiguous source extraction")
    first, last = text.index(start), text.index(end)
    need(first < last, "reversed source extraction")
    return text[first:last]


def candidate_profile(original):
    old = "\tlet parts: Vec<_> = path\n\t\t.components()"
    new = "\tlet mut parts = path\n\t\t.components()"
    changes = [(old, new),
               ("\t\t.collect();\n\tfor (index, part) in parts.iter().enumerate() {",
                "\t\t.peekable();\n\twhile let Some(part) = parts.next() {"),
               ("\t\t\t| if index + 1 < parts.len() || directory {",
                "\t\t\t| if parts.peek().is_some() || directory {")]
    result = original
    for before, after in changes:
        need(result.count(before) == 1, "candidate hunk differs from exact qualified source")
        result = result.replace(before, after, 1)
    before_fn = span(original, "pub(super) fn open_absolute(", "pub(super) fn private_directory(")
    after_fn = span(result, "pub(super) fn open_absolute(", "pub(super) fn private_directory(")
    need(original.replace(before_fn, "") == result.replace(after_fn, ""), "candidate changed another function")
    return result


def module_text(pool, template):
    markers = {
        "CONTROL_LIMIT": "const CONTROL_SOCKET_PATH_BYTES: usize = 108 - 17 - 1;",
        "CONTROL_CHECK": span(pool, "fn check_control_socket_path(", "// OpenSSH links its listening temporary socket"),
        "PRIVATE_ROOT": span(pool, "struct PrivateRoot {", "#[derive(Clone, Debug, PartialEq, Eq)]\nstruct ProcessIdentity"),
        "PROFILE_SCOPE": span(pool, "enum ProfileCheckScope {", "impl Core {"),
        "INITIAL_BIND_BODY": span(pool, "\t\tself.profile.verify_files()?;\n\t\tself.root.verify(&self.profile)?;",
                                  "\t\tlet deadline = Instant::now() + Duration::from_secs(30);"),
        "OWNER_METHODS": span(pool, "\tasync fn verify_profile(&self,", "\tfn arguments("),
    }
    need(pool.count(markers["CONTROL_LIMIT"]) == 1, "qualified socket limit changed")
    result = template
    for name, body in markers.items():
        token = "@@" + name + "@@"
        need(result.count(token) == 1, "template marker differs: " + name)
        result = result.replace(token, body.rstrip("\n"), 1)
    need("@@" not in result, "unresolved source template marker")
    return result, {name: {"sha256": hashlib.sha256(body.encode()).hexdigest(), "bytes": len(body.encode())}
                    for name, body in markers.items()}


def generate(source, output):
    contents = {relative: receipt(source / relative, True)[1] for relative in PINNED}
    for relative, expected in PINNED.items():
        need(hashlib.sha256(contents[relative]).hexdigest() == expected, "exact A26 source differs: " + relative)
    module, extracts = module_text(contents["src/mcp/runtime/ssh_observation_pool.rs"].decode(),
                                  (HERE / "owner_module.rs.in").read_text())
    original = contents["src/mcp/runtime/ssh_observation_profile.rs"].decode()
    changed = candidate_profile(original)
    patch = "".join(difflib.unified_diff(original.splitlines(True), changed.splitlines(True),
                  fromfile="a/src/mcp/runtime/ssh_observation_profile.rs",
                  tofile="b/src/mcp/runtime/ssh_observation_profile.rs"))
    write_new(output / "candidate.patch", patch.encode())
    generated = []
    for variant in ("A", "B"):
        directory = output / variant
        (directory / "observation").mkdir(parents=True, mode=0o700)
        (directory / "mcp/runtime").mkdir(parents=True, mode=0o700)
        files = {
            "main.rs": (HERE / "owner_probe.rs").read_bytes(),
            "observation/mod.rs": module.encode(),
            "observation/profile.rs": (original if variant == "A" else changed).encode(),
            "observation/validation.rs": contents["src/mcp/runtime/ssh_observation_validation.rs"],
            "observation/path_semantics.rs": (HERE / "path_semantics.rs").read_bytes(),
            "mcp/runtime/config.rs": contents["src/mcp/runtime/config.rs"],
            "mcp/runtime/config_tests.rs": contents["src/mcp/runtime/config_tests.rs"],
            "observation/ssh_observation_profile_tests.rs": contents["src/mcp/runtime/ssh_observation_profile_tests.rs"],
            "observation/ssh_observation_validation_tests.rs": contents["src/mcp/runtime/ssh_observation_validation_tests.rs"],
        }
        raw_directory = output / "generated-inputs" / variant
        for relative, raw in files.items():
            write_new(directory / relative, raw)
            copy = raw_directory / relative
            copy.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
            write_new(copy, raw)
            generated.extend([str(directory / relative), str(copy)])
    return {"verbatim_extracts": extracts, "generated_paths": generated,
            "candidate_patch": receipt(output / "candidate.patch")}


def parse_artifacts(raw):
    records = []
    for line in raw.decode().splitlines():
        try:
            row = json.loads(line)
        except json.JSONDecodeError:
            continue
        if isinstance(row, dict):
            records.append(row)
    return records


def release_artifact(records, name, runtime):
    runtime_profile = runtime.get("profile")
    need(isinstance(runtime_profile, dict) and runtime_profile.get("test") is False
         and runtime_profile.get("opt_level") == "3", "qualified runtime release profile required")
    dependency_dir = Path(runtime["executable"]).parent / "deps"
    decisions, found = [], []
    for row in records:
        if row.get("reason") != "compiler-artifact" or row.get("target", {}).get("name") != name:
            continue
        reasons = []
        if row.get("profile") != runtime_profile:
            reasons.append("profile_differs_from_qualified_runtime")
        if "lib" not in row.get("target", {}).get("kind", []):
            reasons.append("not_library_target")
        artifacts = [Path(value) for value in row.get("filenames", []) if Path(value).suffix == ".rlib"]
        if not (len(artifacts) == 1 and artifacts[0].is_absolute() and artifacts[0].parent == dependency_dir):
            reasons.append("not_single_rlib_in_runtime_release_deps")
        decisions.append({"compiler_artifact": row, "selected": not reasons, "excluded_reasons": reasons})
        if not reasons:
            found.append(row)
    need(len(found) == 1, "unique compiler-artifact matching qualified runtime profile/deps required: " + name)
    return found[0], {"rule": "complete profile equals qualified runtime and one rlib in its release deps directory",
                      "runtime_profile": runtime_profile, "runtime_dependency_dir": str(dependency_dir),
                      "considered_artifacts": decisions}


def select_dependency(records, name, locked, runtime):
    row, selection = release_artifact(records, name, runtime)
    artifacts = [Path(value) for value in row["filenames"] if Path(value).suffix == ".rlib"]
    need(len(artifacts) == 1 and artifacts[0].is_absolute(), "unique absolute rlib required")
    manifest, raw = receipt(Path(row["manifest_path"]), True)
    package = tomllib.loads(raw.decode())["package"]
    package_name = name.replace("_", "-") if name == "tokio_util" else name
    need(package["name"] == package_name, "dependency crate/package mismatch")
    source, fragment = row["package_id"].rsplit("#", 1)
    version = package["version"]
    need(fragment in (version, package_name + "@" + version), "dependency package ID/version differs")
    matches = [item for item in locked["package"] if item["name"] == package_name
               and item["version"] == version and item.get("source") == source]
    need(len(matches) == 1, "dependency does not match qualified lockfile")
    return {"name": name, "package_id": row["package_id"], "version": version, "manifest": manifest,
            "compiler_artifact": row, "lock_package": matches[0], "rlib": receipt(artifacts[0]),
            "selection": selection}


def run_logged(command, output, prefix, env=None):
    with (output / (prefix + ".stdout.log")).open("xb") as stdout, (output / (prefix + ".stderr.log")).open("xb") as stderr:
        child = subprocess.run(command, stdout=stdout, stderr=stderr, env=env, check=False)
        for stream in (stdout, stderr):
            stream.flush()
            os.fsync(stream.fileno())
    return {"command": command, "returncode": child.returncode,
            "stdout": receipt(output / (prefix + ".stdout.log")),
            "stderr": receipt(output / (prefix + ".stderr.log"))}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--qualification", type=Path, required=True)
    parser.add_argument("--qualification-receipt", type=Path, required=True)
    parser.add_argument("--rustc", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--compile", action="store_true")
    args = parser.parse_args()
    os.umask(0o077)
    output = args.output_dir.absolute()
    need(not os.path.lexists(output), "fresh standalone output directory required")
    output.mkdir(mode=0o700)
    result = {"schema": "hepta-x230-owner-path-probe-build/v1", "prepared": False, "compiled": False,
              "probe_executed": False, "retries": 0, "downloads": 0, "started_unix": time.time(),
              "compile_requested": args.compile, "stages": []}
    checkpoint(output, result)
    try:
        qualification_receipt, raw = receipt(args.qualification.absolute(), True)
        independent_receipt, iraw = receipt(args.qualification_receipt.absolute(), True)
        qualification, independent = json.loads(raw), json.loads(iraw)
        need(qualification.get("schema") == "runtime-candidate-qualification/v1"
             and qualification.get("qualified") is True and qualification.get("current_stage") == "complete",
             "complete successful qualification required")
        need(independent.get("schema") == "hepta-x230-qualification-independent-receipt/v1"
             and independent.get("candidate") == "A26" and independent.get("qualified") is True
             and independent.get("source_report_sha256") == qualification_receipt["sha256"]
             and independent.get("unmet_checks") == [], "independent A26 qualification differs")
        need(qualification.get("source_tested") == qualification.get("source_after"), "qualified source maps differ")
        source = Path(qualification["source"])
        need(source.is_absolute() and source.is_dir() and not source.is_symlink()
             and not output.is_relative_to(source), "standalone source/output roots required")
        source_receipts = {relative: receipt(source / relative) for relative in PINNED}
        for relative, value in source_receipts.items():
            need(value["sha256"] == PINNED[relative] == qualification["source_after"].get(relative),
                 "qualified A26 input changed: " + relative)
        cargo = tomllib.loads((source / "Cargo.toml").read_text())
        need(cargo.get("profile", {}).get("release", {}).get("panic") == "abort", "qualified release must use panic=abort")
        need(tomllib.loads((source / "rustfmt.toml").read_text()).get("hard_tabs") is True, "qualified hard_tabs required")
        runtime_binary = receipt(Path(qualification["binary"]["path"]))
        need(runtime_binary["sha256"] == qualification["binary"]["sha256"], "qualified A26 binary changed")
        releases = [row for row in qualification["stages"] if row.get("name") == "release"]
        need(len(releases) == 1 and releases[0].get("returncode") == 0, "unique successful release stage required")
        release = releases[0]
        release_receipt, raw_log = receipt(args.qualification.absolute().parent / "release.log", True)
        need(release_receipt["sha256"] == release["log_sha256"], "qualified artifact log changed")
        command = release["command"]
        need(len(command) > 2 and Path(command[0]).name == "cargo" and command[1] == "+1.95.0",
             "exact qualified Rust 1.95.0 toolchain required")
        records = parse_artifacts(raw_log)
        runtime = [row for row in records if row.get("reason") == "compiler-artifact"
                   and row.get("target", {}).get("name") == "hepta-runtime" and row.get("profile", {}).get("test") is False]
        need(len(runtime) == 1 and Path(runtime[0]["manifest_path"]) == source / "Cargo.toml"
             and Path(runtime[0]["target"]["src_path"]) == source / "src/main.rs", "qualified runtime source/artifact mismatch")
        runtime_artifact = receipt(Path(runtime[0]["executable"]))
        need(runtime_artifact["sha256"] == runtime_binary["sha256"], "original qualified artifact changed")
        need(runtime[0]["profile"]["opt_level"] == str(cargo["profile"]["release"]["opt-level"]),
             "qualified runtime artifact and Cargo release optimization differ")
        deps = {name: select_dependency(records, name, tomllib.loads((source / "Cargo.lock").read_text()), runtime[0])
                for name in DIRECT}
        dependency_dir = Path(runtime[0]["executable"]).parent / "deps"
        need(all(Path(value["rlib"]["path"]).parent == dependency_dir for value in deps.values()),
             "direct dependencies differ from qualified artifact directory")
        dependency_paths = sorted({str(Path(path)) for row in records if row.get("reason") == "compiler-artifact"
                                  for path in row.get("filenames", [])
                                  if Path(path).suffix in (".rlib", ".so") and Path(path).parent == dependency_dir})
        need(any(Path(path).suffix == ".so" for path in dependency_paths), "qualified procedural macro libraries missing")
        native_paths, native_archives = set(), set()
        for row in records:
            if row.get("reason") != "build-script-executed" or row.get("package_id") != deps["ring"]["package_id"]:
                continue
            paths = []
            for value in row.get("linked_paths", []):
                path = Path(value.removeprefix("native="))
                need(path.is_absolute() and path.is_dir(), "recorded ring native directory missing")
                paths.append(path)
                native_paths.add(str(path))
            for value in row.get("linked_libs", []):
                need(value.startswith("static="), "unexpected ring link kind")
                name = value.removeprefix("static=")
                need(re.fullmatch(r"[A-Za-z0-9_]+", name), "unexpected ring native library name")
                found = [path / ("lib" + name + ".a") for path in paths if (path / ("lib" + name + ".a")).is_file()]
                need(len(found) == 1, "unique recorded native archive required")
                native_archives.add(str(found[0]))
        rustc = args.rustc.resolve(strict=True)
        rustfmt = rustc.with_name("rustfmt").resolve(strict=True)
        need(args.rustc.is_absolute() and rustc.name == "rustc" and rustfmt.name == "rustfmt"
             and rustfmt.parent == rustc.parent, "actual installed rustc/rustfmt from same toolchain required")
        for name in BUNDLE_FILES:
            write_new(output / name, receipt(HERE / name, True)[1])
        generated = generate(source, output)
        commands = {}
        for variant in ("A", "B"):
            compiler = [str(rustc), "--edition=2021", "--crate-name", "hepta_owner_path_probe", "-C", "opt-level=3",
                        "-C", "debuginfo=0", "-C", "panic=abort", str(output / variant / "main.rs")]
            for name in DIRECT:
                compiler += ["--extern", name + "=" + deps[name]["rlib"]["path"]]
            compiler += ["-L", "dependency=" + str(dependency_dir)]
            for path in sorted(native_paths):
                compiler += ["-L", "native=" + path]
            compiler += ["-o", str(output / variant / "owner-probe")]
            commands[variant] = compiler
        paths = sorted(set(dependency_paths) | native_archives | {str(rustc), str(rustfmt),
            qualification_receipt["path"], independent_receipt["path"], release_receipt["path"], runtime_binary["path"],
            runtime_artifact["path"], *(row["path"] for row in source_receipts.values()),
            *(row["manifest"]["path"] for row in deps.values()),
            *(str(HERE / name) for name in BUNDLE_FILES), *(str(output / name) for name in BUNDLE_FILES),
            *generated["generated_paths"], str(output / "candidate.patch")})
        before = {path: receipt(Path(path)) for path in paths}
        result.update(prepared=True, qualification=qualification_receipt, independent_receipt=independent_receipt,
                      baseline_commit=json.loads((HERE / "PLAN.json").read_text())["baseline_commit"],
                      qualified_runtime_binary=runtime_binary, qualified_runtime_artifact=runtime_artifact,
                      source=source_receipts, toolchain="1.95.0", panic_strategy="abort", dependencies=deps,
                      dependency_dir=str(dependency_dir), native_search_paths=sorted(native_paths),
                      plan=receipt(output / "PLAN.json"), commands=commands, generated=generated, inputs_before=before)
        checkpoint(output, result)
        if args.compile:
            version = run_logged([str(rustc), "-vV"], output, "rustc-version")
            result["stages"].append(version)
            text = (output / "rustc-version.stdout.log").read_text()
            fields = dict(line.split(": ", 1) for line in text.splitlines() if ": " in line)
            need(version["returncode"] == 0 and fields.get("release") == "1.95.0"
                 and fields.get("host") == "x86_64-unknown-linux-gnu", "installed compiler differs from qualified toolchain")
            for variant in ("A", "B"):
                formatting = run_logged([str(rustfmt), "--edition", "2021", "--config-path", str(source / "rustfmt.toml"),
                                         str(output / variant / "main.rs")], output, "format-" + variant)
                result["stages"].append(formatting)
                checkpoint(output, result)
                need(formatting["returncode"] == 0, "standalone formatting failed")
            formatted = {path: receipt(Path(path)) for path in paths}
            allowed = {str(output / variant / name) for variant in ("A", "B")
                       for name in ("main.rs", "observation/mod.rs", "observation/path_semantics.rs", "observation/profile.rs")}
            need({path for path in paths if before[path] != formatted[path]} <= allowed,
                 "formatting changed a bound input outside standalone generated copies")
            # The production modules in A remain exact; B must differ only by the frozen hunk.
            need((output / "A/observation/profile.rs").read_bytes() == (source / "src/mcp/runtime/ssh_observation_profile.rs").read_bytes(),
                 "rustfmt changed baseline profile beyond the exact qualified source")
            need((output / "B/observation/profile.rs").read_text() == candidate_profile((output / "A/observation/profile.rs").read_text()),
                 "formatted B profile is not exactly the one-hunk candidate")
            need((output / "A/main.rs").read_bytes() == (output / "B/main.rs").read_bytes()
                 and (output / "A/observation/mod.rs").read_bytes() == (output / "B/observation/mod.rs").read_bytes(),
                 "formatted variant support sources differ")
            pool = (source / "src/mcp/runtime/ssh_observation_pool.rs").read_text()
            actual_owner = (output / "A/observation/mod.rs").read_text()
            for start, end in (("struct PrivateRoot {", "#[derive(Clone, Debug, PartialEq, Eq)]\nstruct ProcessIdentity"),
                               ("\tasync fn verify_profile(&self,", "\tfn arguments(")):
                need(span(pool, start, end).rstrip("\n") in actual_owner,
                     "formatted owner checks differ from verbatim qualified methods")
            result["inputs_before_format"] = before
            before = formatted
            result["inputs_before"] = before
            result["sources_to_publish"] = {variant: {str(Path(path).relative_to(output / variant)): before[path]
                    for path in paths if Path(path).is_relative_to(output / variant) and Path(path).suffix == ".rs"}
                    for variant in ("A", "B")}
            checkpoint(output, result)
            for variant in ("A", "B"):
                env = os.environ.copy()
                env["HEPTA_PATH_PROBE_VARIANT"] = variant
                env["HEPTA_PATH_PROBE_PLAN_SHA256"] = result["plan"]["sha256"]
                compiled = run_logged(commands[variant], output, "compile-" + variant, env=env)
                compiled["compile_time_values"] = {"variant": variant, "plan_sha256": result["plan"]["sha256"]}
                result["stages"].append(compiled)
                checkpoint(output, result)
                need(compiled["returncode"] == 0, "standalone compilation failed: " + variant)
            result["binaries"] = {variant: receipt(output / variant / "owner-probe") for variant in ("A", "B")}
        after = {path: receipt(Path(path)) for path in paths}
        result["inputs_after"] = after
        need(before == after, "bound inputs changed during preparation/compilation")
        result["compiled"] = args.compile
    except BaseException as error:
        result["error"] = {"type": type(error).__name__, "reason": str(error)}
    finally:
        result["finished_unix"] = time.time()
        checkpoint(output, result)
    print(json.dumps({"build": str(output / "build.json"), "prepared": result["prepared"], "compiled": result["compiled"],
                      "probe_executed": False, "error": result.get("error")}))
    return int("error" in result)


if __name__ == "__main__":
    sys.exit(main())
