#!/usr/bin/env python3
# Copyright 2026 Muvon Un Limited
# Copyright 2026 TrillionniumFoundation
# SPDX-License-Identifier: Apache-2.0
"""Strict, fixed-plan analysis of every complete owner-path probe cell."""
import argparse
import hashlib
import json
from pathlib import Path
import statistics
import sys

SCHEMA = "hepta-x230-owner-path-probe-analysis/v1"
ORDER = ("A", "B", "B", "A")
METRICS = ("process_cpu_ns", "owner_thread_cpu_ns", "wall_ns")


def need(value, message):
    if not value:
        raise ValueError(message)


def integer(value, minimum=0):
    return isinstance(value, int) and not isinstance(value, bool) and value >= minimum


def check_semantics(value, variant, plan_sha):
    need(value.get("schema") == "hepta-x230-owner-path-semantics/v1" and value.get("passed") is True
         and value.get("variant") == variant and value.get("plan_sha256") == plan_sha,
         "semantic preflight identity/pass differs")
    checks = value.get("checks", [])
    expected = ["regular_leaf", "nested_directory", "file_as_directory", "file_intermediate", "leaf_symlink",
                "intermediate_symlink", "missing_leaf", "relative", "parent_component", "dot_component",
                "whitespace", "nul", "invalid_utf8"]
    need([item.get("case") for item in checks] == expected, "semantic coverage differs")
    for index, row in enumerate(checks):
        field = "passed" if index < 2 else "rejected" if index < 7 else "lexically_rejected"
        need(row.get(field) is True, "semantic assertion did not pass")
    need(all(value.get(field) is True for field in
             ("root_readable", "leaf_bytes_match", "repeated_separator_same_inode")), "semantic root/bytes gate failed")
    need(value.get("recursive_cleanup") is False, "unexpected cleanup policy")


def check_cell(value, variant, plan_sha):
    need(value.get("schema") == "hepta-x230-owner-path-cell/v1" and value.get("variant") == variant
         and value.get("plan_sha256") == plan_sha and value.get("passed") is True, "cell identity/pass differs")
    need(value.get("warmup_expected") == 4 and value.get("measured_expected") == 64
         and value.get("caller_deadline_ms") == 5000, "cell frozen counts/deadline differ")
    need(value.get("worker_drain_succeeded") is True and value.get("agent_requests") == 69
         and value.get("agent_requests_expected") == 69, "cell agent/drain coverage differs")
    need(all(field in value and value[field] is None for field in ("bind_error", "cleanup_error", "agent_error")),
         "cell binding/cleanup/agent error")
    fixture = value.get("fixture", {})
    need(fixture.get("hosts") == 6 and fixture.get("local_synthetic_agent") is True
         and fixture.get("rpc_executed") is False and fixture.get("ssh_child_spawned") is False,
         "cell fixture scope differs")
    pins = fixture.get("system_and_fixture_sha256", {})
    need(set(pins) == {"ssh", "false", "shell", "config", "known_hosts"}
         and all(isinstance(pin, str) and len(pin) == 64 and all(char in "0123456789abcdef" for char in pin)
                 for pin in pins.values()), "fixture pin coverage differs")
    rows = value.get("rows", [])
    expected = [("warmup", index) for index in range(4)] + [("measured", index) for index in range(64)]
    need([(row.get("phase"), row.get("index")) for row in rows] == expected, "cell rows missing, duplicated or out of order")
    for row in rows:
        need(row.get("attempted") is True and row.get("passed") is True and row.get("stop_cancelled") is False,
             "cell operation was unattempted, failed or cancelled")
        need(all(key in row and row[key] is None for key in ("validation_error", "clock_error")), "cell row contains error")
        need(all(integer(row.get(key), 1) for key in METRICS), "invalid cell timing")
    return {metric: sum(row[metric] for row in rows if row["phase"] == "measured") for metric in METRICS}


def summarize(run):
    result = {"schema": SCHEMA, "valid_complete_experiment": False, "eligible_for_runtime_candidate": False,
              "runtime_optimization_adopted": False, "all_cells_preserved": True,
              "reason": None, "blocks": [], "cell_totals": [],
              "scope": "complete isolated owner verification, including local agent fixture; not RPC throughput"}
    try:
        need(run.get("schema") == "hepta-x230-owner-path-probe-run/v1" and run.get("completed") is True
             and run.get("error") is None and run.get("retries") == 0, "run incomplete or failed")
        need(run.get("inputs_unchanged") is True and run.get("binaries_unchanged") is True, "run input/binary fence failed")
        plan_sha = run.get("plan_sha256")
        need(isinstance(plan_sha, str) and len(plan_sha) == 64, "plan identity missing")
        preflights = run.get("semantics", [])
        need(len(preflights) == 2, "both semantic variants required")
        for value, variant in zip(preflights, ("A", "B")):
            need(value.get("variant") == variant and value.get("returncode") == 0 and value.get("stderr_bytes") == 0,
                 "semantic child failed")
            check_semantics(value["record"], variant, plan_sha)
        cells = run.get("cells", [])
        need(len(cells) == 32, "exactly 32 fixed ABBA cells required")
        previous_system_pins = None
        totals = []
        for sequence, cell in enumerate(cells):
            block, position = divmod(sequence, 4)
            variant = ORDER[position]
            need(cell.get("sequence") == sequence and cell.get("block") == block
                 and cell.get("position") == position and cell.get("variant") == variant
                 and cell.get("returncode") == 0 and cell.get("stderr_bytes") == 0,
                 "cell order/exit/stderr differs")
            total = check_cell(cell["record"], variant, plan_sha)
            pins = cell["record"]["fixture"]["system_and_fixture_sha256"]
            system_pins = {key: pins[key] for key in ("ssh", "false", "shell")}
            need(previous_system_pins is None or system_pins == previous_system_pins, "system executable content changed between cells")
            previous_system_pins = system_pins
            totals.append(total)
            result["cell_totals"].append({"sequence": sequence, "block": block, "position": position,
                                          "variant": variant, "measured_operations": 64, **total})
        for block in range(8):
            block_totals = totals[block * 4:block * 4 + 4]
            row = {"block": block, "measured_operations_per_slot": 128, "metrics": {}}
            for metric in METRICS:
                a = (block_totals[0][metric] + block_totals[3][metric]) / 128
                b = (block_totals[1][metric] + block_totals[2][metric]) / 128
                row["metrics"][metric] = {"A_ns_per_operation": a, "B_ns_per_operation": b,
                                          "improvement_percent": 100.0 * (a - b) / a}
            result["blocks"].append(row)
        summaries = {}
        for metric in METRICS:
            values = [block["metrics"][metric]["improvement_percent"] for block in result["blocks"]]
            median = statistics.median(values)
            mad = statistics.median(abs(value - median) for value in values)
            summaries[metric] = {"paired_improvements_percent": values, "median_improvement_percent": median,
                                  "median_absolute_deviation_percent": mad, "positive_blocks": sum(value > 0 for value in values)}
        cpu = summaries["process_cpu_ns"]
        wall = summaries["wall_ns"]
        gates = {"median_process_cpu_at_least_3_percent": cpu["median_improvement_percent"] >= 3.0,
                 "at_least_7_of_8_process_cpu_blocks_improve": cpu["positive_blocks"] >= 7,
                 "median_process_cpu_strictly_above_2_mad": cpu["median_improvement_percent"] > 2 * cpu["median_absolute_deviation_percent"],
                 "median_wall_regression_at_most_2_percent": wall["median_improvement_percent"] >= -2.0}
        result.update(valid_complete_experiment=True, summaries=summaries, gates=gates,
                      eligible_for_runtime_candidate=all(gates.values()), measured_operations=2048,
                      warmup_operations=128, system_content_sha256=previous_system_pins)
        result["reason"] = "eligible only for independent runtime qualification and end-to-end measurement" if all(gates.values()) else "preregistered gates not all met; retain A26"
    except (KeyError, TypeError, ValueError, ZeroDivisionError) as error:
        result["reason"] = str(error)
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--run", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    raw = args.run.read_bytes()
    result = summarize(json.loads(raw))
    result["run_sha256"] = hashlib.sha256(raw).hexdigest()
    with args.output.open("xb") as stream:
        stream.write((json.dumps(result, indent=2, sort_keys=True) + "\n").encode())
    print(json.dumps(result))
    return 0 if result["valid_complete_experiment"] else 1


if __name__ == "__main__":
    sys.exit(main())
