#!/usr/bin/env python3
# Copyright 2026 Muvon Un Limited
# Copyright 2026 TrillionniumFoundation
# SPDX-License-Identifier: Apache-2.0
"""Run one fresh, fixed ABBA owner-path experiment; never replay a cell."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import signal
import stat
import subprocess
import sys
import time

from prepare_owner_probe import HERE, BUNDLE_FILES, checkpoint, need, receipt, stamp, write_new
from summarize_owner_probe import check_cell, check_semantics, summarize


def verify_map(expected):
    actual = {}
    errors = []
    for path, value in expected.items():
        try:
            actual[path] = receipt(Path(path))
            if actual[path] != value:
                errors.append({"path": path, "reason": "receipt changed"})
        except BaseException as error:
            errors.append({"path": path, "reason": type(error).__name__ + ": " + str(error)})
    return actual, errors


def owned_wait(child, signal_state):
    while True:
        try:
            return child.wait()
        except KeyboardInterrupt:
            signal_state["interrupted"] = True
            if not signal_state["sent"]:
                signal_state["sent"] = True
                child.send_signal(signal.SIGINT)


def run_child(binary, mode, fixture, target):
    target.mkdir(mode=0o700)
    command = [str(binary), "--mode", mode, str(fixture)]
    result = {"command": command, "started_unix": time.time(), "returncode": None, "record": None,
              "signal_forwarded": False, "interrupted": False, "stderr_bytes": None, "parse_error": None}
    signal_state = {"interrupted": False, "sent": False}
    child = None
    try:
        with (target / "stdout.json").open("xb") as stdout, (target / "stderr.log").open("xb") as stderr:
            # Keep the child environment independent of all active runtime/agent configuration.
            env = {"PATH": "/usr/bin:/bin", "LANG": "C.UTF-8", "LC_ALL": "C.UTF-8"}
            child = subprocess.Popen(command, stdout=stdout, stderr=stderr, stdin=subprocess.DEVNULL, env=env,
                                     start_new_session=True)
            result["returncode"] = owned_wait(child, signal_state)
            for stream in (stdout, stderr):
                stream.flush()
                os.fsync(stream.fileno())
    except BaseException as error:
        result["process_error"] = {"type": type(error).__name__, "reason": str(error)}
        if child is not None and child.returncode is None:
            signal_state["interrupted"] = True
            if not signal_state["sent"]:
                signal_state["sent"] = True
                child.send_signal(signal.SIGINT)
            result["returncode"] = owned_wait(child, signal_state)
    finally:
        result["signal_forwarded"] = signal_state["sent"]
        result["interrupted"] = signal_state["interrupted"]
        result["finished_unix"] = time.time()
        for name in ("stdout.json", "stderr.log"):
            path = target / name
            if path.exists():
                result[name] = receipt(path)
        if "stderr.log" in result:
            result["stderr_bytes"] = result["stderr.log"]["bytes"]
        try:
            raw = receipt(target / "stdout.json", True)[1]
            result["record"] = json.loads(raw)
            need(isinstance(result["record"], dict), "child report must be one JSON object")
        except BaseException as error:
            result["parse_error"] = {"type": type(error).__name__, "reason": str(error)}
        checkpoint(target, result, "child.json")
    return result


def child_clean(value):
    need(value["returncode"] == 0 and value["stderr_bytes"] == 0 and value["parse_error"] is None
         and value["interrupted"] is False and "process_error" not in value, "child/evidence failure; no subsequent stage allowed")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--build", type=Path, required=True)
    parser.add_argument("--fixture-parent", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    args = parser.parse_args()
    os.umask(0o077)
    output = args.output_dir.absolute()
    fixture = args.fixture_parent
    need(fixture.is_absolute() and len(os.fsencode(fixture)) <= 32 and fixture == fixture.absolute()
         and not any(part in (".", "..") for part in str(fixture).split("/")), "short absolute fresh fixture parent required")
    need(not os.path.lexists(output) and not os.path.lexists(fixture), "fresh output and fixture parents required")
    need(not fixture.is_relative_to(output) and not output.is_relative_to(fixture), "separate output and fixture trees required")
    output.mkdir(mode=0o700)
    run = {"schema": "hepta-x230-owner-path-probe-run/v1", "completed": False, "retries": 0,
           "semantics": [], "cells": [], "error": None, "started_unix": time.time(),
           "inputs_unchanged": False, "binaries_unchanged": False, "fixture_parent": str(fixture)}
    checkpoint(output, run, "run.json")
    expected, binaries, build_before = {}, {}, None
    try:
        build_before, build_raw = receipt(args.build.absolute(), True)
        build = json.loads(build_raw)
        need(build.get("schema") == "hepta-x230-owner-path-probe-build/v1" and build.get("prepared") is True
             and build.get("compiled") is True and "error" not in build and build.get("inputs_before") == build.get("inputs_after"),
             "successful unchanged compiled build required")
        expected = build["inputs_after"]
        binaries = build["binaries"]
        need(set(binaries) == {"A", "B"}, "both compiled variants required")
        need(bool(expected), "bound build inputs missing")
        _, errors = verify_map(expected)
        need(not errors, "build inputs changed before run: " + json.dumps(errors))
        for variant in ("A", "B"):
            need(receipt(Path(binaries[variant]["path"])) == binaries[variant], "probe binary changed before run")
        build_dir = args.build.absolute().parent
        for name in BUNDLE_FILES:
            need(receipt(HERE / name)["sha256"] == receipt(build_dir / name)["sha256"], "runner/tool source differs from compiled bundle")
        plan_receipt, plan_raw = receipt(build_dir / "PLAN.json", True)
        need(plan_receipt == build["plan"], "compiled plan changed")
        plan = json.loads(plan_raw)
        need(plan["blocks"] == 8 and plan["order_per_block"] == ["A", "B", "B", "A"]
             and plan["warmup_per_cell"] == 4 and plan["measured_per_cell"] == 64
             and plan["measured_operations"] == 2048, "frozen scale differs")
        run.update(build=build_before, plan_sha256=plan_receipt["sha256"], plan=plan, binary_receipts=binaries,
                   input_receipts_before=expected)
        write_new(output / "PLAN.json", plan_raw)
        fixture.mkdir(mode=0o700)
        parent = fixture.lstat()
        need(stat.S_ISDIR(parent.st_mode) and parent.st_uid == os.geteuid() and stat.S_IMODE(parent.st_mode) == 0o700,
             "fresh fixture parent ownership/mode differs")
        run["fixture_parent_stamp"] = list(stamp(parent))
        checkpoint(output, run, "run.json")
        for variant in ("A", "B"):
            value = run_child(Path(binaries[variant]["path"]), "semantics", fixture / ("s" + variant), output / ("semantics-" + variant))
            value["variant"] = variant
            run["semantics"].append(value)
            checkpoint(output, run, "run.json")
            child_clean(value)
            check_semantics(value["record"], variant, run["plan_sha256"])
        fixed_system_pins = None
        for block in range(8):
            for position, variant in enumerate(("A", "B", "B", "A")):
                sequence = block * 4 + position
                label = f"c{sequence:02d}{variant}"
                need(receipt(Path(binaries[variant]["path"])) == binaries[variant], "probe binary changed before cell")
                value = run_child(Path(binaries[variant]["path"]), "measure", fixture / label, output / label)
                value.update(sequence=sequence, block=block, position=position, variant=variant)
                run["cells"].append(value)
                checkpoint(output, run, "run.json")
                child_clean(value)
                check_cell(value["record"], variant, run["plan_sha256"])
                pins = value["record"]["fixture"]["system_and_fixture_sha256"]
                system_pins = {key: pins[key] for key in ("ssh", "false", "shell")}
                need(fixed_system_pins is None or fixed_system_pins == system_pins,
                     "system executable content changed between cells; stop subsequent stages")
                fixed_system_pins = system_pins
                need(receipt(Path(binaries[variant]["path"])) == binaries[variant], "probe binary changed during cell")
        run["completed"] = True
    except BaseException as error:
        run["error"] = {"type": type(error).__name__, "reason": str(error)}
    finally:
        if expected:
            actual, errors = verify_map(expected)
            run["input_receipts_after"], run["input_fence_errors"] = actual, errors
            run["inputs_unchanged"] = not errors
        if binaries:
            binary_expected = {value["path"]: value for value in binaries.values()}
            actual, errors = verify_map(binary_expected)
            run["binary_receipts_after"], run["binary_fence_errors"] = actual, errors
            run["binaries_unchanged"] = not errors
        if build_before is not None:
            try:
                need(receipt(args.build.absolute()) == build_before, "build report changed during run")
            except BaseException as error:
                run["build_fence_error"] = str(error)
                run["inputs_unchanged"] = False
        run["finished_unix"] = time.time()
        checkpoint(output, run, "run.json")
        analysis = summarize(run)
        analysis["run_sha256"] = receipt(output / "run.json")["sha256"]
        write_new(output / "analysis.json", (json.dumps(analysis, indent=2, sort_keys=True) + "\n").encode())
    print(json.dumps({"run": str(output / "run.json"), "analysis": str(output / "analysis.json"),
                      "completed": run["completed"], "valid_complete_experiment": analysis["valid_complete_experiment"],
                      "eligible_for_runtime_candidate": analysis["eligible_for_runtime_candidate"],
                      "error": run["error"], "reason": analysis["reason"]}))
    return 0 if analysis["valid_complete_experiment"] else 1


if __name__ == "__main__":
    sys.exit(main())
