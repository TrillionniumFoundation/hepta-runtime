// Copyright 2026 Muvon Un Limited
// Copyright 2026 TrillionniumFoundation
// SPDX-License-Identifier: Apache-2.0
//! Untimed real-filesystem checks shared by both standalone variants.

use super::profile;
use anyhow::{bail, Context, Result};
use serde_json::{json, Value};
use std::fs::{self, DirBuilder, OpenOptions};
use std::io::{Read, Write};
use std::os::fd::AsRawFd;
use std::os::unix::ffi::OsStrExt;
use std::os::unix::fs::{DirBuilderExt, MetadataExt, OpenOptionsExt};
use std::path::Path;

fn require(value: bool, label: &str) -> Result<()> {
	if !value {
		bail!("semantic assertion failed: {label}");
	}
	Ok(())
}

pub(super) fn run(root: &Path) -> Result<Value> {
	profile::absolute(root)?;
	DirBuilder::new().mode(0o700).create(root)?;
	let nested = root.join("nested");
	DirBuilder::new().mode(0o700).create(&nested)?;
	let leaf = nested.join("file");
	let mut file = OpenOptions::new().write(true).create_new(true).mode(0o600).open(&leaf)?;
	file.write_all(b"owner-path-fixture")?;
	file.sync_all()?;
	drop(file);
	let mut records = Vec::new();
	for (path, directory) in [(&leaf, false), (&nested, true)] {
		let opened = profile::open_absolute(path, directory)?;
		let actual = opened.metadata()?;
		let expected = fs::symlink_metadata(path)?;
		require((actual.dev(), actual.ino()) == (expected.dev(), expected.ino()), "descriptor identity")?;
		let status = unsafe { libc::fcntl(opened.as_raw_fd(), libc::F_GETFL) };
		let descriptor = unsafe { libc::fcntl(opened.as_raw_fd(), libc::F_GETFD) };
		require(status >= 0 && descriptor >= 0, "fcntl result")?;
		require(status & libc::O_NONBLOCK != 0 && descriptor & libc::FD_CLOEXEC != 0, "nonblocking and cloexec")?;
		require(!directory || status & libc::O_DIRECTORY != 0, "directory flag")?;
		records.push(json!({"case": if directory {"nested_directory"} else {"regular_leaf"}, "passed": true}));
	}
	let mut bytes = Vec::new();
	profile::open_absolute(&leaf, false)?.read_to_end(&mut bytes)?;
	require(bytes == b"owner-path-fixture", "leaf bytes")?;
	require(profile::open_absolute(Path::new("/"), false)?.metadata()?.is_dir(), "root path")?;
	let repeated = format!("{}//nested///file", root.display());
	require(profile::open_absolute(Path::new(&repeated), false)?.metadata()?.ino() == fs::metadata(&leaf)?.ino(), "repeated separator")?;
	fs::symlink_metadata(&leaf)?;
	std::os::unix::fs::symlink(&leaf, root.join("leaf-link"))?;
	std::os::unix::fs::symlink(&nested, root.join("dir-link"))?;
	for (label, path, directory) in [
		("file_as_directory", leaf.clone(), true),
		("file_intermediate", leaf.join("child"), false),
		("leaf_symlink", root.join("leaf-link"), false),
		("intermediate_symlink", root.join("dir-link/file"), false),
		("missing_leaf", root.join("absent"), false),
	] {
		let error = profile::open_absolute(&path, directory).err().with_context(|| format!("unexpected open success: {label}"))?;
		records.push(json!({"case": label, "rejected": true,
			"errno": error.downcast_ref::<std::io::Error>().and_then(std::io::Error::raw_os_error)}));
	}
	let invalid_utf8 = Path::new(std::ffi::OsStr::from_bytes(b"/\xff"));
	for (label, path) in [
		("relative", Path::new("relative").to_owned()),
		("parent_component", root.join("nested/../file")),
		("dot_component", root.join("./file")),
		("whitespace", root.join("a b")),
		("nul", root.join(std::ffi::OsStr::from_bytes(b"bad\0name"))),
		("invalid_utf8", invalid_utf8.to_owned()),
	] {
		require(profile::absolute(&path).is_err(), label)?;
		require(profile::open_absolute(&path, false).is_err(), label)?;
		records.push(json!({"case": label, "lexically_rejected": true}));
	}
	Ok(json!({"schema": "hepta-x230-owner-path-semantics/v1", "passed": true,
		"checks": records, "root_readable": true, "leaf_bytes_match": true,
		"repeated_separator_same_inode": true, "recursive_cleanup": false}))
}
