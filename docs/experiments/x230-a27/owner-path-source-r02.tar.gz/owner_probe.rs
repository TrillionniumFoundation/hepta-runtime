// Copyright 2026 Muvon Un Limited
// Copyright 2026 TrillionniumFoundation
// SPDX-License-Identifier: Apache-2.0
//! Fixed complete-owner validation microprobe. No SSH child or RPC is created.

mod mcp {
	pub(crate) mod runtime {
		#[allow(dead_code)]
		pub(crate) mod config;
	}
}
mod observation;

use anyhow::{anyhow, bail, Context, Result};
use serde_json::{json, Value};
use std::collections::BTreeMap;
use std::fs::{self, DirBuilder, File, OpenOptions};
use std::io::{Read, Write};
use std::os::unix::fs::{DirBuilderExt, MetadataExt, OpenOptionsExt, PermissionsExt};
use std::path::{Path, PathBuf};
use std::sync::atomic::{AtomicUsize, Ordering};
use std::sync::Arc;
use std::time::Duration;
use tokio::io::{AsyncReadExt, AsyncWriteExt};
use tokio::net::UnixListener;
use tokio_util::sync::CancellationToken;

const VARIANT: &str = env!("HEPTA_PATH_PROBE_VARIANT");
const PLAN_SHA256: &str = env!("HEPTA_PATH_PROBE_PLAN_SHA256");
const WARMUP: usize = 4;
const MEASURED: usize = 64;
const DEADLINE_MS: u64 = 5000;

fn need(value: bool, message: &str) -> Result<()> {
	if !value { bail!("{message}"); }
	Ok(())
}

fn hex(bytes: &[u8]) -> String {
	bytes.iter().map(|value| format!("{value:02x}")).collect()
}

fn file_digest(path: &Path) -> Result<String> {
	let mut file = File::open(path)?;
	let mut context = ring::digest::Context::new(&ring::digest::SHA256);
	let mut buffer = [0; 16 * 1024];
	loop {
		let size = file.read(&mut buffer)?;
		if size == 0 { break; }
		context.update(&buffer[..size]);
	}
	Ok(hex(context.finish().as_ref()))
}

fn private_write(path: &Path, bytes: &[u8]) -> Result<()> {
	let mut output = OpenOptions::new().write(true).create_new(true).mode(0o600).open(path)?;
	output.write_all(bytes)?;
	output.sync_all()?;
	Ok(())
}

struct Fixture {
	profile: PathBuf,
	listener: std::os::unix::net::UnixListener,
	receipt: Value,
}

fn setup(root: &Path) -> Result<Fixture> {
	need(root.is_absolute(), "absolute fresh fixture required")?;
	let parent = root.parent().context("fixture parent missing")?;
	let before = fs::symlink_metadata(parent)?;
	need(before.is_dir() && before.uid() == unsafe { libc::geteuid() } && before.mode() & 0o7777 == 0o700,
		"fixture parent must be a private account-owned nonsymlink directory")?;
	DirBuilder::new().mode(0o700).create(root)?;
	let state = root.join("state");
	DirBuilder::new().mode(0o700).create(&state)?;
	let mut hosts = BTreeMap::new();
	for index in 0..6 {
		hosts.insert(format!("fixture-{index}"), json!({"ssh_target": format!("hepta-probe-{index}"),
			"platform": "linux", "remote_state_dir": "/private/unused-probe-jobs",
			"allow_execute": false, "allow_pty": false, "allow_write": false}));
	}
	let runtime = serde_json::from_value(json!({"state_dir": state, "hosts": hosts}))?;
	mcp::runtime::config::init_runtime(runtime)?;
	let known = root.join("known_hosts");
	private_write(&known, b"")?;
	let config = root.join("ssh_config");
	let aliases = (0..6).map(|index| format!("hepta-probe-{index}")).collect::<Vec<_>>().join(" ");
	private_write(&config, format!("Host {aliases}\n HostName 127.0.0.1\n Port 9\n User nobody\n BatchMode yes\n ForwardAgent no\n StrictHostKeyChecking yes\n UserKnownHostsFile {}\n GlobalKnownHostsFile /dev/null\n", known.display()).as_bytes())?;
	let socket = root.join("agent");
	let listener = std::os::unix::net::UnixListener::bind(&socket)?;
	listener.set_nonblocking(true)?;
	fs::set_permissions(&socket, fs::Permissions::from_mode(0o775))?;
	// A new standalone process owns this environment before creating any thread.
	std::env::set_var("SSH_AUTH_SOCK", &socket);
	let pins = json!({"ssh": file_digest(Path::new("/usr/bin/ssh"))?,
		"false": file_digest(Path::new("/usr/bin/false"))?, "shell": file_digest(Path::new("/bin/sh"))?,
		"config": file_digest(&config)?, "known_hosts": file_digest(&known)?});
	let profile = root.join("profile.json");
	private_write(&profile, &serde_json::to_vec(&json!({"schema": "hepta-observation-ssh-pool/v1",
		"allow_bounded_cached_authentication": true, "ssh_config": config,
		"ssh_config_sha256": pins["config"], "known_hosts": known, "known_hosts_sha256": pins["known_hosts"],
		"ssh_sha256": pins["ssh"], "false_sha256": pins["false"], "shell_sha256": pins["shell"],
		"agent_socket": socket, "socket_parent": root}))?)?;
	let receipt = json!({"fixture": root, "hosts": 6, "system_and_fixture_sha256": pins,
		"profile_sha256": file_digest(&profile)?, "local_synthetic_agent": true,
		"rpc_executed": false, "ssh_child_spawned": false});
	Ok(Fixture { profile, listener, receipt })
}

fn cpu_ns(clock: libc::clockid_t) -> Result<u64> {
	let mut value: libc::timespec = unsafe { std::mem::zeroed() };
	if unsafe { libc::clock_gettime(clock, &mut value) } != 0 {
		return Err(std::io::Error::last_os_error().into());
	}
	need(value.tv_sec >= 0 && (0..1_000_000_000).contains(&value.tv_nsec), "invalid clock result")?;
	u64::try_from(value.tv_sec)?.checked_mul(1_000_000_000)
		.and_then(|seconds| seconds.checked_add(value.tv_nsec as u64)).context("clock overflow")
}

async fn serve_agent(listener: UnixListener, stop: CancellationToken, requests: Arc<AtomicUsize>) -> Result<()> {
	let key = b"fixed-public-owner-probe-key";
	let mut response = vec![12, 0, 0, 0, 1];
	response.extend_from_slice(&(key.len() as u32).to_be_bytes());
	response.extend_from_slice(key);
	response.extend_from_slice(&0u32.to_be_bytes());
	let mut wire = (response.len() as u32).to_be_bytes().to_vec();
	wire.extend_from_slice(&response);
	loop {
		let accepted = tokio::select! {
			biased;
			_ = stop.cancelled() => return Ok(()),
			value = listener.accept() => value?,
		};
		let (mut stream, _) = accepted;
		let conversation = async {
			let mut request = [0; 5];
			stream.read_exact(&mut request).await?;
			need(request == [0, 0, 0, 1, 11], "unexpected agent fixture request")?;
			requests.fetch_add(1, Ordering::SeqCst);
			stream.write_all(&wire).await?;
			Ok::<(), anyhow::Error>(())
		};
		tokio::select! {
			biased;
			_ = stop.cancelled() => return Ok(()),
			value = conversation => value?,
		}
	}
}

async fn iteration(owner: &observation::Owner, phase: &str, index: usize) -> Value {
	let mut row = json!({"phase": phase, "index": index, "attempted": false, "passed": false,
		"process_cpu_ns": null, "owner_thread_cpu_ns": null, "wall_ns": null,
		"validation_error": null, "clock_error": null});
	let deadline = tokio::time::Instant::now() + Duration::from_millis(DEADLINE_MS);
	let before_process = cpu_ns(libc::CLOCK_PROCESS_CPUTIME_ID);
	let before_thread = cpu_ns(libc::CLOCK_THREAD_CPUTIME_ID);
	let (before_process, before_thread) = match (before_process, before_thread) {
		(Ok(process), Ok(thread)) => (process, thread),
		(process, thread) => {
			row["clock_error"] = json!({"process": process.err().map(|e| format!("{e:#}")),
				"owner_thread": thread.err().map(|e| format!("{e:#}"))});
			return row;
		}
	};
	let wall = std::time::Instant::now();
	let result = owner.verify(deadline).await;
	let wall_ns = u64::try_from(wall.elapsed().as_nanos());
	let after_thread = cpu_ns(libc::CLOCK_THREAD_CPUTIME_ID);
	let after_process = cpu_ns(libc::CLOCK_PROCESS_CPUTIME_ID);
	row["attempted"] = json!(true);
	row["validation_error"] = json!(result.as_ref().err().map(|error| format!("{error:#}")));
	let clocks = (|| -> Result<(u64, u64, u64)> {
		Ok((after_process?.checked_sub(before_process).context("process CPU regressed")?,
			after_thread?.checked_sub(before_thread).context("owner CPU regressed")?, wall_ns?))
	})();
	match clocks {
		Ok((process, thread, wall)) => {
			row["process_cpu_ns"] = json!(process);
			row["owner_thread_cpu_ns"] = json!(thread);
			row["wall_ns"] = json!(wall);
			row["passed"] = json!(result.is_ok() && !owner.stopped());
		}
		Err(error) => row["clock_error"] = json!(format!("{error:#}")),
	}
	row["stop_cancelled"] = json!(owner.stopped());
	row
}

async fn measure(owner: observation::Owner, fixture: Fixture) -> Value {
	let mut report = json!({"schema": "hepta-x230-owner-path-cell/v1", "variant": VARIANT,
		"plan_sha256": PLAN_SHA256, "fixture": fixture.receipt, "passed": false,
		"bind_error": null, "cleanup_error": null, "agent_error": null,
		"rows": [], "warmup_expected": WARMUP, "measured_expected": MEASURED,
		"caller_deadline_ms": DEADLINE_MS, "agent_requests_expected": 1 + WARMUP + MEASURED});
	let listener = match UnixListener::from_std(fixture.listener) {
		Ok(value) => value,
		Err(error) => { report["agent_error"] = json!(error.to_string()); return report; }
	};
	let agent_stop = CancellationToken::new();
	let requests = Arc::new(AtomicUsize::new(0));
	let server = tokio::spawn(serve_agent(listener, agent_stop.clone(), requests.clone()));
	let bound = owner.bind().await;
	report["bind_error"] = json!(bound.as_ref().err().map(|error| format!("{error:#}")));
	let mut rows = Vec::with_capacity(WARMUP + MEASURED);
	if bound.is_ok() {
		'phases: for (phase, count) in [("warmup", WARMUP), ("measured", MEASURED)] {
			for index in 0..count {
				let row = iteration(&owner, phase, index).await;
				let passed = row["passed"] == true;
				rows.push(row);
				if !passed { break 'phases; }
			}
		}
	}
	let drained = owner.finish().await;
	report["cleanup_error"] = json!(drained.as_ref().err().map(|error| format!("{error:#}")));
	agent_stop.cancel();
	let served = match server.await {
		Ok(value) => value,
		Err(error) => Err(anyhow!("local agent task join failed: {error}")),
	};
	report["agent_error"] = json!(served.as_ref().err().map(|error| format!("{error:#}")));
	let count = requests.load(Ordering::SeqCst);
	report["agent_requests"] = json!(count);
	report["worker_drain_succeeded"] = json!(drained.is_ok());
	report["rows"] = json!(rows);
	report["passed"] = json!(bound.is_ok() && drained.is_ok() && served.is_ok()
		&& rows.len() == WARMUP + MEASURED && rows.iter().all(|row| row["passed"] == true)
		&& count == 1 + WARMUP + MEASURED);
	// Worker completion precedes the original identity-checked PrivateRoot Drop.
	drop(owner);
	report
}

fn run() -> Result<Value> {
	let args: Vec<String> = std::env::args().collect();
	need(args.len() == 4 && args[1] == "--mode", "usage: owner-probe --mode measure|semantics FRESH_FIXTURE")?;
	let path = PathBuf::from(&args[3]);
	if args[2] == "semantics" {
		let mut report = observation::semantic_checks(&path)?;
		report["variant"] = json!(VARIANT);
		report["plan_sha256"] = json!(PLAN_SHA256);
		return Ok(report);
	}
	need(args[2] == "measure", "unsupported probe mode")?;
	let fixture = setup(&path)?;
	let owner = observation::Owner::create(&fixture.profile)?;
	let runtime = tokio::runtime::Builder::new_current_thread().enable_all().max_blocking_threads(2).build()?;
	Ok(runtime.block_on(measure(owner, fixture)))
}

fn main() {
	let result = match run() {
		Ok(value) => value,
		Err(error) => json!({"schema": "hepta-x230-owner-path-probe-failure/v1",
			"variant": VARIANT, "plan_sha256": PLAN_SHA256, "passed": false,
			"error": format!("{error:#}"), "retries": 0}),
	};
	let passed = result["passed"] == true;
	let write = (|| -> Result<()> {
		let mut stdout = std::io::stdout().lock();
		serde_json::to_writer(&mut stdout, &result)?;
		stdout.write_all(b"\n")?;
		stdout.flush()?;
		Ok(())
	})();
	if !passed || write.is_err() { std::process::exit(1); }
}
