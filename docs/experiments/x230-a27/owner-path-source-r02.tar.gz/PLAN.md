# A27 isolated observation owner-path experiment

This experiment compares committed, qualified A26 with one change: `open_absolute`
uses a streaming `peekable()` iterator instead of allocating a temporary `Vec` of
normal path components. Every `CString`, open flag, descriptor operation and error
path stays in the same order. It does not cache paths, descriptors, identities or
hashes. The private profile, fixed system executable pins, shell resolution,
serialized runtime policy and agent identity remain fully checked on every call.

The two standalone binaries use exact qualified `config`, `profile` and validation
worker modules. The builder extracts `PrivateRoot` and the owner verification
methods verbatim from the same `ssh_observation_pool.rs`. A reduced owner struct
contains only the fields those methods use. It has no SSH child, credential lease,
RPC or networking implementation. Startup pins one real private Unix agent socket;
each measured operation runs the complete original
`verify_profile_for(..., Request)` path, including both worker full-file checks,
both owner boundary checks, private root checks and a fresh agent lookup. The
original 5-second caller deadline, 2-second agent cap, stop rules and final worker
drain are retained. The local fixture agent returns a fixed public synthetic key.
It lives in this process, so its small response cost is included in both process
and owner-thread CPU. This is an isolated owner verification measurement, not an
RPC throughput or production SSH-agent CPU measurement.

The static call graph contains at least 48 `open_absolute` calls per successful
owner verification. Each worker full-file pass opens six pinned files twice plus
the policy parent, and its owner boundary pass opens six identities plus that
parent: 20 opens, twice. PrivateRoot adds two and the agent's before/after socket
checks add six. System shell resolution may add more. This count identifies
repeated temporary allocations; it is not a measured allocation count or proof of
a speedup. The candidate does not reduce the number of filesystem syscalls.

## Frozen execution and decision

Run exactly 8 ABBA blocks. Each cell starts a new standalone process with its own
fresh private fixture, binds the agent, runs 4 complete warmup operations and then
64 measured operations. There are 128 warmups and 2048 measured operations. The
expected successful agent request count is 69 per cell: one initial binding plus
the 68 complete checks. Cell paths have equal-length names. Two separate semantic
preflights exercise real descriptors, final-directory flags, no-follow behavior
and lexical rejection before any measured cells. No preflight performs an RPC.

Primary time is process CPU, including the real blocking workers. Owner-thread
CPU is supplemental. Wall time surrounds the same complete owner operation;
the process/thread CPU windows also include the fixed clock bookkeeping around
that operation. Setup, profile pinning, filesystem fixtures, output serialization,
shutdown and fixture reconciliation are outside each operation's timing window.
All warmup and measured observations remain in the raw cell record, including the
first failure. There is no per-allocation instrumentation in a timed binary.

Compute each block using both A cells and both B cells. The candidate is eligible
for a later runtime experiment only if all 32 cells are complete and clean, all
2048 measured operations passed, and all of these preregistered conditions hold:

- Median paired process CPU improvement is at least 3%.
- At least 7 of 8 process CPU blocks improve.
- Median CPU improvement is strictly greater than twice the median absolute
  deviation of the eight paired percentage improvements.
- Median wall regression is at most 2%.

Any failing semantic preflight, cell, cleanup, input identity or evidence check
stops subsequent stages. Preserve failed builds and measurements; do not retry a
failed cell, pick a successful subset, tune the scale after seeing results, or
infer an end-to-end benefit. An ineligible result retains A26. A passing result
only justifies separately qualifying a runtime candidate and measuring real RPCs.
The previous 16/64KiB hash-buffer experiment is unrelated; the buffer remains
16KiB in both binaries.

## Build and run boundaries

`prepare_owner_probe.py` reads the independently verified A26 qualification and
its compiler-artifact log. It selects direct dependencies by exact manifest,
Cargo.lock version and recorded release artifact, including the already built
procedural macro libraries. It binds all recorded rlibs/native archives, source
inputs and tools before and after compilation. It uses the already installed
qualified Rust 1.95.0 toolchain and `-C panic=abort`; it never invokes Cargo,
downloads a dependency, or writes the shared target. Formatting happens only in
the fresh standalone build tree with the qualified rustfmt configuration. Raw
template/generated inputs and actual formatted compilation sources are preserved.
The three original sibling test sources are copied and hash-bound as well, so
rustfmt can resolve the unchanged `cfg(test)` module wiring. They are not enabled
in the standalone executable. Tooling input receipts preserve and compare the
actual link count, including Cargo's possible hard-linked artifacts; the copied
production profile still independently requires `nlink == 1` for its pinned files.

The runner uses fresh output and fixture parents. It never recursively deletes a
fixture. The copied PrivateRoot Drop may remove its own empty identity-checked
root, exactly as in production. Other fixtures and logs remain for reconciliation.
Only the runner-owned subprocess handle may receive an interrupt, at most once;
there is no numeric-PID kill, detached process, spawn retry, or workload replay.

Suggested invocation (substitute actual qualification paths and installed rustc):

```sh
python3 -B prepare_owner_probe.py --qualification QUALIFICATION/report.json --qualification-receipt QUALIFICATION/independent-receipt.json --rustc ACTUAL_TOOLCHAIN/bin/rustc --output-dir FRESH_BUILD --compile
python3 -B run_owner_probe.py --build FRESH_BUILD/build.json --fixture-parent /home/qian/ha27p01 --output-dir FRESH_RUN
```

The fixture parent must be new, short and absolute. The runner rejects a parent
longer than 32 encoded bytes so the original control-socket publication path
limit remains usable even with a seven-digit PID. Compile and run only when the
root coordinator has reserved x230 and the qualified shared artifacts are stable.
