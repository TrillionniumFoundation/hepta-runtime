#!/usr/bin/env python3
# Copyright 2026 Muvon Un Limited
# Copyright 2026 TrillionniumFoundation
# SPDX-License-Identifier: Apache-2.0
"""Verify a complete archive experiment and evaluate the frozen gates, without rerunning it."""
import argparse
import json
import math
import os
from pathlib import Path
import statistics
import sys

sys.dont_write_bytecode = True
from prepare_build import canonical, need, read_stable, sha, write_new
from probe_plan import CONCURRENCIES, KINDS, SIZES, command_for, plan, validate_cell


def receipt(path):
    raw = read_stable(path)
    return {"sha256": sha(raw), "bytes": len(raw)}


def percentile(values, quantile):
    need(bool(values), "percentile needs actual samples")
    ordered = sorted(values)
    return ordered[max(0, math.ceil(len(ordered) * quantile) - 1)]


def blocks_for(specs, cells, rows, concurrency, kind, phase, count):
    blocks, latencies = [], {"A": [], "B": []}
    for block in range(count):
        chosen = [spec for spec in specs if (spec["rows"], spec["concurrency"], spec["kind"],
                  spec["phase"], spec["block"]) == (rows, concurrency, kind, phase, block)]
        valid = len(chosen) == 4 and [row["arm"] for row in chosen] == ["A", "B", "B", "A"]
        arm = {}
        for label in ("A", "B"):
            selected = [spec for spec in chosen if spec["arm"] == label]
            found = [cells.get(spec["id"]) for spec in selected]
            okay = (len(found) == 2 and all(item is not None and item["check"]["passed"] for item in found))
            valid = valid and okay
            if okay:
                total_calls = sum(spec["calls"] for spec in selected)
                total_cpu = sum(item["check"]["complete"]["process_cpu_ns_sum_of_query_waves"] for item in found)
                total_wall = sum(item["check"]["complete"]["query_wave_wall_ns_sum"] for item in found)
                arm[label] = {"calls": total_calls, "cpu_ns": total_cpu,
                              "cpu_ms_per_call": total_cpu / total_calls / 1e6,
                              "query_wave_wall_ns": total_wall}
                for item in found:
                    latencies[label].extend(row["latency_ns"] for row in item["events"] if row["event"] == "query")
            else:
                arm[label] = None
        gain = (100 * (arm["A"]["cpu_ms_per_call"] - arm["B"]["cpu_ms_per_call"])
                / arm["A"]["cpu_ms_per_call"]) if valid else None
        blocks.append({"block": block, "valid": valid, "arms": arm, "cpu_improvement_percent": gain,
                       "cell_ids": [spec["id"] for spec in chosen]})
    complete = len(blocks) == count and all(row["valid"] for row in blocks)
    values = [row["cpu_improvement_percent"] for row in blocks] if complete else []
    median = statistics.median(values) if complete else None
    mad = statistics.median(abs(value - median) for value in values) if complete else None
    p95 = ({arm: percentile(latencies[arm], .95) for arm in ("A", "B")} if complete else None)
    return {"rows": rows, "concurrency": concurrency, "kind": kind, "phase": phase,
            "valid": complete, "blocks": blocks, "median_cpu_improvement_percent": median,
            "cpu_improvement_mad_percentage_points": mad,
            "positive_blocks": sum(value > 0 for value in values) if complete else None,
            "expected_blocks": count, "p95_latency_ns": p95,
            "p95_latency_regression_percent": (100 * (p95["B"] - p95["A"]) / p95["A"]
                                                if p95 is not None and p95["A"] > 0 else None),
            "latency_samples_by_arm": {arm: len(latencies[arm]) for arm in ("A", "B")}}


def mixed_case(cases, rows, concurrency, gate):
    selected = [row for row in cases if row["rows"] == rows and row["concurrency"] == concurrency]
    valid = len(selected) == 2 and {row["kind"] for row in selected} == set(KINDS) \
        and all(row["valid"] for row in selected)
    blocks = []
    for block in range(8):
        arms = None
        gain = None
        if valid:
            arms = {label: sum(row["blocks"][block]["arms"][label]["cpu_ms_per_call"]
                               for row in selected) / 2 for label in ("A", "B")}
            gain = 100 * (arms["A"] - arms["B"]) / arms["A"]
        blocks.append({"block": block, "valid": valid, "cpu_ms_per_call": arms,
                       "cpu_improvement_percent": gain})
    if valid:
        values = [row["cpu_improvement_percent"] for row in blocks]
        median = statistics.median(values)
        mad = statistics.median(abs(value - median) for value in values)
        positive = sum(value > 0 for value in values)
        passed = (median >= gate["min_median_cpu_improvement_percent"]
                  and positive >= gate["min_positive_blocks_of_eight"]
                  and median > gate["median_improvement_must_exceed_mad_multiple"] * mad)
    else:
        median, mad, positive, passed = None, None, None, False
    return {"rows": rows, "concurrency": concurrency, "valid": valid, "blocks": blocks,
            "median_cpu_improvement_percent": median, "mad_percentage_points": mad,
            "positive_blocks": positive, "expected_blocks": 8, "passed": passed}


def metrics(declared, cells, evidence_verified):
    gate = declared["performance_gate"]
    warm = [blocks_for(declared["cells"], cells, rows, concurrency, kind, "measured", 8)
            for rows in SIZES for concurrency in CONCURRENCIES for kind in KINDS]
    for case in warm:
        case["guard_passed"] = (case["valid"]
            and case["median_cpu_improvement_percent"] >= -gate["max_per_kind_median_cpu_regression_percent"]
            and case["p95_latency_regression_percent"] is not None
            and case["p95_latency_regression_percent"] <= gate["max_per_kind_p95_latency_regression_percent"])
    mixed = [mixed_case(warm, rows, concurrency, gate) for rows in SIZES for concurrency in CONCURRENCIES]
    cold = [blocks_for(declared["cells"], cells, rows, concurrency, kind, "cold_guard", 4)
            for rows in SIZES for concurrency in (1, 8) for kind in KINDS]
    for case in cold:
        delta = (statistics.median(row["arms"]["B"]["cpu_ms_per_call"]
                                 - row["arms"]["A"]["cpu_ms_per_call"] for row in case["blocks"])
                 if case["valid"] else None)
        case["median_cpu_regression_ms"] = delta
        case["guard_passed"] = (case["valid"]
            and (case["median_cpu_improvement_percent"] >= -gate["cold_guard_max_median_cpu_regression_percent"]
                 or delta <= gate["cold_guard_absolute_cpu_regression_allowance_ms"]))
    eligibility = (evidence_verified and len(warm) == 12 and all(row["guard_passed"] for row in warm)
                   and len(mixed) == 6 and all(row["passed"] for row in mixed)
                   and len(cold) == 8 and all(row["guard_passed"] for row in cold))
    return {"comparison_valid": evidence_verified,
            "diagnostic_performance_gate_passed": eligibility,
            "adoption_authorized": False, "runtime_qualified_by_this_probe": False,
            "all_kind_shapes": warm, "equal_call_mixed_shapes": mixed, "all_cold_guard_shapes": cold,
            "allocation_calls": None, "allocation_bytes": None, "peak_live_heap_bytes": None,
            "source_hypothesis_is_not_allocation_or_cpu_attribution": True,
            "sampling_errors_are_not_interpreted_as_rpc_failures": True,
            "gate": gate}


def verify(directory):
    series_raw = read_stable(directory / "series.json")
    series = json.loads(series_raw)
    result = {"schema": "hepta-a27-archive-probe-analysis/v1", "series_sha256": sha(series_raw),
              "verified": False, "comparison_valid": False, "diagnostic_performance_gate_passed": False,
              "adopted": False, "errors": [], "raw_series_passed": series.get("passed"),
              "raw_series_errors": series.get("errors", []), "resource_reports": [], "cell_checks": []}
    declared = plan()
    cells = {}

    def check(value, message):
        if not value:
            result["errors"].append(message)
        return value

    check(series.get("schema") == "hepta-a27-archive-probe-series/v1", "series schema differs")
    plan_raw = read_stable(directory / "plan.json")
    check(plan_raw == canonical(declared) + b"\n" and sha(plan_raw) == series.get("plan_sha256"),
          "predeclared plan bytes differ")
    result["plan_sha256"] = sha(plan_raw)
    artifacts = series.get("artifact_hashes", {})
    check(bool(artifacts), "no artifact manifest")
    actual_paths = set()
    for path in directory.rglob("*"):
        relative = path.relative_to(directory).as_posix()
        if "fixture" in Path(relative).parts or relative == "series.json":
            continue
        if path.is_file():
            actual_paths.add(relative)
    check(actual_paths == set(artifacts), "complete non-fixture artifact set differs")
    for relative, expected in artifacts.items():
        path = directory / relative
        need(path.resolve().is_relative_to(directory) and not path.is_symlink(), "artifact path escaped")
        check(receipt(path) == expected, "artifact changed: " + relative)
    result["artifact_hashes"] = artifacts
    before = json.loads(read_stable(directory / "inputs-before.json"))
    after_path = directory / "inputs-after.json"
    after = json.loads(read_stable(after_path)) if after_path.is_file() else None
    check(after == before and series.get("inputs_unchanged") is True, "bound inputs not unchanged")
    result["input_binding"] = before
    records = series.get("cells", [])
    record_ids = [row.get("id") for row in records]
    check(record_ids == [row["id"] for row in declared["cells"]], "cell declaration/coverage differs")
    statuses = {row["id"]: row for row in records if isinstance(row.get("id"), str)}
    response_hashes = {}
    for spec in declared["cells"]:
        status = statuses.get(spec["id"], {})
        path = directory / "cells" / (spec["id"] + ".json")
        if not path.is_file():
            result["cell_checks"].append({"id": spec["id"], "status": "missing_or_not_run", "passed": False})
            check(False, "cell missing or not run: " + spec["id"])
            continue
        value = json.loads(read_stable(path))
        check(value.get("spec") == spec, "cell spec differs: " + spec["id"])
        actual = validate_cell(value.get("events", []), spec)
        value["check"] = actual
        cells[spec["id"]] = value
        checked = (actual["passed"] and value.get("driver_error") is None
                   and status.get("status") == "completed" and status.get("passed") is True
                   and status.get("complete") == actual["complete"])
        result["cell_checks"].append({"id": spec["id"], **actual, "passed": checked})
        check(checked, "cell did not fully pass: " + spec["id"])
        for row in value.get("events", []):
            if row.get("event") == "query" and row.get("raw_success") is True:
                key = (spec["rows"], spec["kind"], row["request"] % 12)
                digest = row["response_sha256"]
                check(key not in response_hashes or response_hashes[key] == digest,
                      "same synthetic request returned different complete bytes")
                response_hashes[key] = digest
    processes = series.get("processes", [])
    check(len(processes) == 4 and [row.get("spec") for row in processes] == declared["processes"],
          "four complete owned process receipts required")
    fixture_hashes = {}
    resource_complete = True
    for row in processes:
        spec = row["spec"]
        path = directory / spec["directory"]
        check(json.loads(read_stable(path / "process.json")) == row, "process receipt differs")
        passed = (row.get("passed") is True and row.get("returncode") == 0
                  and row.get("full_expected_work_completed") is True
                  and row.get("sigint_forwarded") is False and not row.get("cleanup_errors")
                  and not row.get("stdout_reader_errors"))
        check(passed, "owned process did not fully pass: " + spec["id"])
        own_cells = [cell for cell in declared["cells"] if cell["rows"] == spec["rows"] and cell["arm"] == spec["arm"]]
        raw_events = [json.loads(line) for line in read_stable(path / "stdout.jsonl").splitlines()]
        reconstructed = list(row.get("setup_events", []))
        for cell in own_cells:
            reconstructed.extend(cells.get(cell["id"], {}).get("events", []))
        reconstructed.extend(row.get("teardown_events", []))
        check(raw_events == reconstructed, "stdout events were dropped or not linked to a cell")
        commands = [json.loads(line) for line in read_stable(path / "commands.jsonl").splitlines()]
        check(commands == [command_for(cell) for cell in own_cells] + [{"command": "stop"}],
              "work was replayed, omitted, reordered or stopped abnormally")
        ready = row.get("ready", {})
        complete = [event for event in row.get("teardown_events", []) if event.get("event") == "complete"]
        check(len(complete) == 1 and complete[0].get("passed") is True
              and complete[0].get("originals_unchanged") is True
              and complete[0].get("original_input_sha256") == complete[0].get("final_input_sha256")
              == ready.get("input_sha256") and complete[0].get("cells") == spec["cells"]
              and complete[0].get("cell_calls") == spec["cell_calls"], "fixture hashes or final call counts differ")
        fixture_hashes[(spec["rows"], spec["arm"])] = ready.get("input_sha256")
        resource = row.get("resources")
        if not isinstance(resource, dict):
            check(False, "resource final receipt missing")
            resource_complete = False
            continue
        check(json.loads(read_stable(path / "resource-final.json")) == resource, "resource receipt differs")
        snapshot = resource.get("snapshot", {})
        raw_errors = read_stable(path / "resource-errors.jsonl")
        errors = [json.loads(line) for line in raw_errors.splitlines()]
        log_receipt = {"bytes": len(raw_errors), "sha256": sha(raw_errors), "rows": len(errors)}
        okay = (resource.get("complete_error_log_verified") is True and snapshot.get("sampler_thread_stopped") is True
                and snapshot.get("error_log_complete") is True and snapshot.get("error_log_finalized") is True
                and snapshot.get("error_log_failure") is None and resource.get("error_log_receipt") == log_receipt
                and snapshot.get("error_log_bytes") == len(raw_errors) and snapshot.get("error_log_sha256") == sha(raw_errors)
                and snapshot.get("error_count") == snapshot.get("error_log_rows_written") == len(errors)
                and [error.get("sequence") for error in errors] == list(range(len(errors))))
        resource_complete = resource_complete and okay
        check(okay, "sampler error log is incomplete or differs")
        result["resource_reports"].append({"process": spec["id"], "complete_error_log": okay,
            "error_log": spec["directory"] + "/resource-errors.jsonl", "error_log_receipt": log_receipt,
            "snapshot": snapshot, "errors_are_all_retained_in_bound_jsonl": okay,
            "metrics_are_non_atomic_estimates": True, "scope_ends_before_final_original_verification": True})
    for rows in SIZES:
        check(fixture_hashes.get((rows, "A")) is not None and fixture_hashes.get((rows, "A"))
              == fixture_hashes.get((rows, "B")), "A/B original fixture identity differs or missing")
    check(series.get("complete") is True and series.get("passed") is True and not series.get("errors"),
          "raw series did not pass")
    result["resource_evidence_complete"] = resource_complete and len(processes) == 4
    result["resource_claim_requires_per_field_coverage_review"] = True
    result["verified"] = not result["errors"]
    result.update(metrics(declared, cells, result["verified"]))
    result["observed_cell_count"] = len(cells)
    result["expected_cell_count"] = 536
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--series", type=Path, required=True, help="Preserved series.json")
    parser.add_argument("--out", type=Path, required=True, help="New analysis JSON outside the experiment directory")
    args = parser.parse_args()
    source, out = args.series.absolute(), args.out.absolute()
    need(source.name == "series.json" and source == source.resolve(), "series path differs or is indirect")
    need(out.parent == out.parent.resolve() and out.parent.is_dir() and not os.path.lexists(out)
         and not out.is_relative_to(source.parent), "analysis output must be fresh outside raw experiment")
    try:
        value = verify(source.parent)
    except Exception as error:
        value = {"schema": "hepta-a27-archive-probe-analysis/v1", "verified": False,
                 "comparison_valid": False, "diagnostic_performance_gate_passed": False, "adopted": False,
                 "series_sha256": sha(read_stable(source)),
                 "verification_error": {"type": type(error).__name__, "message": str(error)}}
    write_new(out, canonical(value) + b"\n")
    print(json.dumps({key: value.get(key) for key in
                      ("verified", "comparison_valid", "diagnostic_performance_gate_passed", "verification_error")}))
    return 0 if value["verified"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
