#!/usr/bin/env python3
# Copyright 2026 Muvon Un Limited
# Copyright 2026 TrillionniumFoundation
# SPDX-License-Identifier: Apache-2.0
"""Pure synthetic parser/gate checks. Never launches a probe or reports real measurements."""
import copy
import pathlib
import sys
import unittest

sys.dont_write_bytecode = True
from analyze_probe import metrics
from prepare_build import TEST_WIRING, remove_candidate_delta
from probe_plan import plan, validate_cell


def cell(spec, cpu_ms=1.0, latency_ns=1_000_000):
    start = {"event": "cell_started", **{key: spec[key] for key in
             ("sequence", "phase", "kind", "concurrency", "calls")},
             "hot_cache_miss_per_wave": spec["cold"]}
    queries = [{"event": "query", "sequence": spec["sequence"], "request": index,
                "owner_index": index % 4, "latency_ns": latency_ns, "passed": True,
                "raw_success": True, "error": None, "response_bytes": 100,
                "response_sha256": "f" * 64} for index in range(spec["calls"])]
    end = {**start, "event": "cell_complete", "passed": True,
           "successes": spec["calls"], "raw_successes": spec["calls"], "latency_rows": spec["calls"],
           "failures_or_missing": 0, "process_cpu_ns_sum_of_query_waves": round(cpu_ms * spec["calls"] * 1e6),
           "query_wave_wall_ns_sum": spec["calls"] * 1_000_000,
           "allocation_calls": None, "requested_allocation_bytes": None, "peak_live_heap_bytes": None,
           "allocator_instrumented": False}
    events = [start, *queries, end]
    return {"spec": spec, "events": events, "check": validate_cell(events, spec)}


class LogicTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.declared = plan()
        cls.complete = {spec["id"]: cell(spec, .9 if spec["arm"] == "B" else 1.0)
                        for spec in cls.declared["cells"]}

    def test_plan_is_exact_finite_and_sequences_are_contiguous(self):
        value = self.declared
        self.assertEqual(len(value["cells"]), 536)
        self.assertEqual(value["measurement_calls"], 49152)
        self.assertEqual(value["total_cell_calls"], 50944)
        self.assertEqual(len(set(row["id"] for row in value["cells"])), 536)
        for process in value["processes"]:
            selected = [row for row in value["cells"] if (row["rows"], row["arm"])
                        == (process["rows"], process["arm"])]
            self.assertEqual([row["sequence"] for row in selected], list(range(134)))
            self.assertEqual(sum(row["calls"] for row in selected), 12736)

    def test_empty_or_missing_completion_never_passes(self):
        spec = self.declared["cells"][0]
        self.assertFalse(validate_cell([], spec)["passed"])
        value = cell(spec)
        self.assertFalse(validate_cell(value["events"][:-1], spec)["passed"])

    def test_duplicate_or_missing_query_fails(self):
        spec = self.declared["cells"][0]
        value = cell(spec)
        value["events"][2] = value["events"][1]
        self.assertFalse(validate_cell(value["events"], spec)["passed"])

    def test_raw_or_oracle_failure_and_join_error_are_not_filtered(self):
        spec = self.declared["cells"][0]
        for change in ({"raw_success": False}, {"passed": False}, {"error": "test failure"}):
            value = cell(spec)
            value["events"][1].update(change)
            self.assertFalse(validate_cell(value["events"], spec)["passed"])
        value = cell(spec)
        value["events"].insert(1, {"event": "query_join_error", "error": "synthetic"})
        self.assertFalse(validate_cell(value["events"], spec)["passed"])

    def test_complete_synthetic_gate_and_invalid_evidence_gate(self):
        okay = metrics(self.declared, self.complete, True)
        self.assertTrue(okay["diagnostic_performance_gate_passed"])
        self.assertEqual([len(okay[key]) for key in
                          ("all_kind_shapes", "equal_call_mixed_shapes", "all_cold_guard_shapes")], [12, 6, 8])
        invalid = metrics(self.declared, self.complete, False)
        self.assertFalse(invalid["comparison_valid"])
        self.assertFalse(invalid["diagnostic_performance_gate_passed"])

    def test_missing_cell_invalidates_its_shape_and_overall_gate(self):
        values = self.complete.copy()
        target = next(row for row in self.declared["cells"] if row["phase"] == "measured")
        del values[target["id"]]
        result = metrics(self.declared, values, False)
        self.assertFalse(result["diagnostic_performance_gate_passed"])
        self.assertTrue(any(not row["valid"] for row in result["all_kind_shapes"]))

    def test_per_kind_latency_guard_cannot_hide_in_cpu_improvement(self):
        values = self.complete.copy()
        for spec in self.declared["cells"]:
            if spec["phase"] == "measured" and spec["arm"] == "B" and spec["kind"] == "history":
                values[spec["id"]] = cell(spec, .9, 1_100_000)
        result = metrics(self.declared, values, True)
        self.assertFalse(result["diagnostic_performance_gate_passed"])
        self.assertTrue(all(row["passed"] for row in result["equal_call_mixed_shapes"]))

    def test_cold_cost_is_retained_and_evaluated_separately(self):
        for cpu, passed in ((1.1, True), (1.3, False)):
            values = self.complete.copy()
            for spec in self.declared["cells"]:
                if spec["phase"] == "cold_guard" and spec["arm"] == "B":
                    values[spec["id"]] = cell(spec, cpu)
            result = metrics(self.declared, values, True)
            self.assertEqual(result["diagnostic_performance_gate_passed"], passed)
            self.assertTrue(all(row["median_cpu_improvement_percent"] < 0 for row in result["all_cold_guard_shapes"]))

    def test_equal_or_unmeasured_clock_cannot_show_a_gain(self):
        values = {spec["id"]: cell(spec) for spec in self.declared["cells"]}
        result = metrics(self.declared, values, True)
        self.assertFalse(result["diagnostic_performance_gate_passed"])
        spec = self.declared["cells"][0]
        events = copy.deepcopy(values[spec["id"]]["events"])
        events[-1]["process_cpu_ns_sum_of_query_waves"] = 0
        self.assertFalse(validate_cell(events, spec)["passed"])

    def test_frozen_candidate_delta_removes_to_exact_baseline(self):
        root = pathlib.Path(__file__).resolve().parent.parent
        candidate = (root / "modified/request_audit.rs").read_text()
        baseline = (root / "base/request_audit.rs").read_text()
        self.assertEqual(candidate.count(TEST_WIRING), 1)
        self.assertEqual(remove_candidate_delta(candidate.replace(TEST_WIRING, "")), baseline)


if __name__ == "__main__":
    unittest.main()
