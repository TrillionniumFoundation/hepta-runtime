#!/usr/bin/env python3
# Copyright 2026 Muvon Un Limited
# Copyright 2026 TrillionniumFoundation
# SPDX-License-Identifier: Apache-2.0
"""Immutable workload declaration and pure validation for one archive experiment."""

SIZES = (16_384, 65_536)
KINDS = ("usage", "history")
CONCURRENCIES = (1, 4, 8)
ORDER = ("A", "B", "B", "A")
SETTLE_SECONDS = 8
SETUP_WATCHDOG_SECONDS = 240
FINAL_WATCHDOG_SECONDS = 225
MAX_STDOUT_LINE_BYTES = 1_048_576


def need(value, message):
    if not value:
        raise ValueError(message)


def number(value):
    return isinstance(value, (int, float)) and not isinstance(value, bool)


def plan():
    cells = []
    processes = []
    for rows in SIZES:
        sequence = {"A": 0, "B": 0}

        def add(phase, kind, concurrency, block, slot, arm, calls, cold):
            cells.append({"id": f"cell-{len(cells):04d}", "rows": rows, "arm": arm,
                          "sequence": sequence[arm], "phase": phase, "kind": kind,
                          "concurrency": concurrency, "block": block, "slot": slot,
                          "calls": calls, "cold": cold})
            sequence[arm] += 1

        for concurrency in CONCURRENCIES:
            for kind in KINDS:
                for slot, arm in enumerate(("A", "B")):
                    add("warmup", kind, concurrency, None, slot, arm, 32, False)
        for block in range(8):
            for concurrency in CONCURRENCIES:
                for kind in KINDS:
                    for slot, arm in enumerate(ORDER):
                        add("measured", kind, concurrency, block, slot, arm, 128, False)
        for block in range(4):
            for concurrency in (1, 8):
                for kind in KINDS:
                    for slot, arm in enumerate(ORDER):
                        add("cold_guard", kind, concurrency, block, slot, arm, 8, True)
        for arm in ("A", "B"):
            selected = [row for row in cells if row["rows"] == rows and row["arm"] == arm]
            processes.append({"id": f"size-{rows}-arm-{arm}", "rows": rows, "arm": arm,
                              "directory": f"size-{rows}/arm-{arm}", "cells": len(selected),
                              "cell_calls": sum(row["calls"] for row in selected),
                              "setup_public_queries": 2})
    measured = sum(row["calls"] for row in cells if row["phase"] == "measured")
    warmups = sum(row["calls"] for row in cells if row["phase"] == "warmup")
    cold = sum(row["calls"] for row in cells if row["phase"] == "cold_guard")
    need((len(cells), measured, warmups, cold) == (536, 49_152, 768, 1024),
         "fixed workload count changed")
    need(len(processes) == 4 and all(row["cells"] == 134 and row["cell_calls"] == 12_736
                                   for row in processes), "fixed per-process bound changed")
    return {
        "schema": "hepta-a27-archive-probe-plan/v1",
        "hypothesis": "remove unused hot Record clones in two public metadata queries",
        "arms": {"A": "exact A26 plus common probe hooks",
                 "B": "A26 plus metadata_archive helper/two callsites and identical probe hooks"},
        "runtime_qualified": False, "adopted": False, "automatic_retries": 0,
        "network_operations": 0, "owned_probe_processes": 4,
        "fixture_originals": 163_840, "fixture_hot_copies": 2048,
        "estimated_fixture_reserve_bytes": 2 * 1024 ** 3,
        "sizes": list(SIZES), "owners_per_fixture": 4, "hot_records_per_fixture": 512,
        "tokio_worker_threads_per_probe": 2, "max_actual_metadata_closures_per_probe": 8,
        "public_api_deadline_ms": 3000, "query_deadline_reset": False,
        "index_setup": "one original ready/worker trigger; poll same state; no public query retry",
        "setup_cooperative_limit_seconds": 180, "setup_watchdog_seconds": SETUP_WATCHDOG_SECONDS,
        "settle_after_both_ready_seconds": SETTLE_SECONDS,
        "final_verification_watchdog_seconds": FINAL_WATCHDOG_SECONDS,
        "primary_clock": "CLOCK_PROCESS_CPUTIME_ID, sum of query-wave intervals",
        "wave_clock_includes": ["task scheduling", "public APIs", "actual worker-permit drain"],
        "wave_clock_excludes": ["fixture/index setup", "HOT_CACHE eviction for cold guard",
                                "oracle construction", "response verification", "JSONL output"],
        "cold_guard_scope": "one cache miss per wave; existing complete disk index stays ready",
        "query_scope": "precomputed owners and first/middle/tail pages through full public APIs",
        "allocator": "unchanged default allocator; allocation calls/bytes/peak live heap not measured",
        "resource_scope": "external sampled setup, idle and query lifetime; stopped before final original hash",
        "resource_semantics": "non-atomic estimates; unknown stays null; all error JSONL rows retained",
        "measurement_calls": measured, "warmup_calls": warmups, "cold_guard_calls": cold,
        "setup_public_queries": 8, "total_cell_calls": measured + warmups + cold,
        "failure_boundary": "finish the already submitted cell; no subsequent cell after any failure",
        "watchdog_or_interrupt": "one SIGINT per owned Popen at most; await actual child; no discovered PID signals",
        "blocked_kernel_io": "cooperative deadlines and SIGINT do not promise bounded kernel completion",
        "performance_gate": {
            "scope": "diagnostic eligibility only; independent candidate qualification still required",
            "required_mixed_shapes": 6,
            "mix": "equal calls to usage and history, paired by size/concurrency/ABBA block",
            "min_median_cpu_improvement_percent": 3.0,
            "min_positive_blocks_of_eight": 7,
            "median_improvement_must_exceed_mad_multiple": 2.0,
            "max_per_kind_median_cpu_regression_percent": 2.0,
            "max_per_kind_p95_latency_regression_percent": 5.0,
            "cold_guard_max_median_cpu_regression_percent": 5.0,
            "cold_guard_absolute_cpu_regression_allowance_ms": 0.2,
            "all_cells_and_oracles_must_pass": True,
            "all_originals_and_bound_inputs_must_remain_unchanged": True,
            "all_sampler_error_logs_must_be_finalized_and_complete": True,
            "sampling_errors_are_not_automatically_rpc_failures": True,
            "no_success_filtered_comparison": True,
        },
        "processes": processes, "cells": cells,
    }


def command_for(spec):
    return {"command": "cell", **{key: spec[key] for key in
            ("sequence", "phase", "kind", "concurrency", "calls", "cold")}}


def validate_cell(events, spec):
    """Retain all input events, and independently require a full successful cell."""
    starts = [row for row in events if row.get("event") == "cell_started"]
    ends = [row for row in events if row.get("event") == "cell_complete"]
    queries = [row for row in events if row.get("event") == "query"]
    unexpected = [row for row in events if row.get("event") not in
                  ("cell_started", "cell_complete", "query")]
    issues = []
    if len(starts) != 1 or len(ends) != 1:
        issues.append("requires exactly one start and completion")
    if unexpected:
        issues.append("unexpected/error event in cell")
    if events and (events[0].get("event") != "cell_started"
                   or events[-1].get("event") != "cell_complete"):
        issues.append("cell event ordering differs")
    for row in starts + ends:
        if any(row.get(key) != spec[key] for key in
               ("sequence", "phase", "kind", "concurrency", "calls")) \
                or row.get("hot_cache_miss_per_wave") is not spec["cold"]:
            issues.append("cell identity differs")
    if len(queries) != spec["calls"] or sorted(row.get("request", -1) for row in queries) \
            != list(range(spec["calls"])):
        issues.append("query coverage is incomplete or duplicated")
    for row in queries:
        if row.get("sequence") != spec["sequence"] or row.get("passed") is not True \
                or row.get("raw_success") is not True or row.get("error") is not None:
            issues.append("query failure or wrong sequence")
        request = row.get("request")
        if not isinstance(request, int) or row.get("owner_index") != request % 4:
            issues.append("query owner rotation differs")
        if not isinstance(row.get("latency_ns"), int) or row["latency_ns"] < 0:
            issues.append("query latency is unavailable")
        digest = row.get("response_sha256", "")
        if not isinstance(digest, str) or len(digest) != 64 \
                or any(value not in "0123456789abcdef" for value in digest) \
                or not isinstance(row.get("response_bytes"), int) or row["response_bytes"] <= 0:
            issues.append("complete response binding is missing")
    if ends:
        end = ends[0]
        if end.get("passed") is not True or any(end.get(key) != spec["calls"] for key in
                ("successes", "raw_successes", "latency_rows")) or end.get("failures_or_missing") != 0:
            issues.append("cell completion did not pass all calls")
        for key in ("process_cpu_ns_sum_of_query_waves", "query_wave_wall_ns_sum"):
            if not isinstance(end.get(key), int) or end[key] <= 0:
                issues.append("cell clock is missing or non-positive")
        if end.get("allocator_instrumented") is not False or any(end.get(key) is not None for key in
                ("allocation_calls", "requested_allocation_bytes", "peak_live_heap_bytes")):
            issues.append("allocator measurement contract differs")
    return {"passed": not issues, "issues": sorted(set(issues)), "query_rows": len(queries),
            "raw_failures": sum(row.get("raw_success") is not True for row in queries),
            "oracle_failures": sum(row.get("passed") is not True for row in queries),
            "complete": ends[0] if len(ends) == 1 else None}
