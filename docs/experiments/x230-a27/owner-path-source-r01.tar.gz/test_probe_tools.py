#!/usr/bin/env python3
# Copyright 2026 Muvon Un Limited
# Copyright 2026 TrillionniumFoundation
# SPDX-License-Identifier: Apache-2.0
"""Bounded local pure-Python checks; does not compile or execute a Rust probe."""
import copy
import hashlib
import importlib.util
import json
from pathlib import Path
import tempfile
import unittest

from prepare_owner_probe import HERE, PINNED, candidate_profile, generate
from summarize_owner_probe import summarize


def synthetic_run(cpu_b=95, wall_b=95):
    digest = "a" * 64
    checks = [{"case": label, key: True} for label, key in [
        ("regular_leaf", "passed"), ("nested_directory", "passed"),
        *[(name, "rejected") for name in ("file_as_directory", "file_intermediate", "leaf_symlink", "intermediate_symlink", "missing_leaf")],
        *[(name, "lexically_rejected") for name in ("relative", "parent_component", "dot_component", "whitespace", "nul", "invalid_utf8")]]]
    run = {"schema": "hepta-x230-owner-path-probe-run/v1", "completed": True, "error": None,
           "retries": 0, "inputs_unchanged": True, "binaries_unchanged": True, "plan_sha256": digest,
           "semantics": [], "cells": []}
    for variant in ("A", "B"):
        run["semantics"].append({"variant": variant, "returncode": 0, "stderr_bytes": 0,
            "record": {"schema": "hepta-x230-owner-path-semantics/v1", "passed": True, "variant": variant,
                "plan_sha256": digest, "checks": copy.deepcopy(checks), "root_readable": True,
                "leaf_bytes_match": True, "repeated_separator_same_inode": True, "recursive_cleanup": False}})
    for sequence in range(32):
        block, position = divmod(sequence, 4)
        variant = ("A", "B", "B", "A")[position]
        cpu, wall = (100, 100) if variant == "A" else (cpu_b, wall_b)
        rows = [{"phase": phase, "index": index, "attempted": True, "passed": True, "stop_cancelled": False,
                 "validation_error": None, "clock_error": None, "process_cpu_ns": cpu,
                 "owner_thread_cpu_ns": cpu, "wall_ns": wall}
                for phase, count in (("warmup", 4), ("measured", 64)) for index in range(count)]
        run["cells"].append({"sequence": sequence, "block": block, "position": position, "variant": variant,
            "returncode": 0, "stderr_bytes": 0, "record": {"schema": "hepta-x230-owner-path-cell/v1",
                "variant": variant, "plan_sha256": digest, "passed": True, "warmup_expected": 4,
                "measured_expected": 64, "caller_deadline_ms": 5000, "worker_drain_succeeded": True,
                "agent_requests": 69, "agent_requests_expected": 69, "bind_error": None, "cleanup_error": None,
                "agent_error": None, "rows": rows, "fixture": {"hosts": 6, "local_synthetic_agent": True,
                    "rpc_executed": False, "ssh_child_spawned": False, "system_and_fixture_sha256":
                    {name: digest for name in ("ssh", "false", "shell", "config", "known_hosts")}}}})
    return run


class Analysis(unittest.TestCase):
    def test_complete_all_cells_and_paired_counts(self):
        result = summarize(synthetic_run())
        self.assertTrue(result["valid_complete_experiment"])
        self.assertTrue(result["eligible_for_runtime_candidate"])
        self.assertEqual(result["measured_operations"], 2048)
        self.assertEqual(result["warmup_operations"], 128)
        self.assertEqual(len(result["blocks"]), 8)
        self.assertEqual(result["summaries"]["process_cpu_ns"]["median_improvement_percent"], 5.0)
        self.assertFalse(result["runtime_optimization_adopted"])

    def test_negative_and_wall_gate_are_independent(self):
        small = summarize(synthetic_run(99, 99))
        self.assertTrue(small["valid_complete_experiment"])
        self.assertFalse(small["eligible_for_runtime_candidate"])
        slow_wall = summarize(synthetic_run(90, 103))
        self.assertTrue(slow_wall["valid_complete_experiment"])
        self.assertFalse(slow_wall["eligible_for_runtime_candidate"])

    def test_no_empty_or_partial_success(self):
        for count in (0, 1, 31):
            run = synthetic_run()
            run["cells"] = run["cells"][:count]
            self.assertFalse(summarize(run)["valid_complete_experiment"])

    def test_failed_warmup_measured_cleanup_or_clock_never_filtered(self):
        for kind in ("warmup", "measured", "cleanup", "clock", "input"):
            run = synthetic_run()
            record = run["cells"][11]["record"]
            if kind in ("warmup", "measured"):
                record["rows"][0 if kind == "warmup" else 7]["passed"] = False
            elif kind == "cleanup":
                record["cleanup_error"] = "failed"
            elif kind == "clock":
                record["rows"][10]["clock_error"] = "clock failed"
            else:
                run["inputs_unchanged"] = False
            self.assertFalse(summarize(run)["valid_complete_experiment"], kind)

    def test_reorder_duplicates_and_system_pin_change_rejected(self):
        for kind in ("cell", "row", "pin", "semantic"):
            run = synthetic_run()
            if kind == "cell":
                run["cells"][1], run["cells"][2] = run["cells"][2], run["cells"][1]
            elif kind == "row":
                run["cells"][2]["record"]["rows"][8]["index"] = 0
            elif kind == "pin":
                run["cells"][2]["record"]["fixture"]["system_and_fixture_sha256"]["ssh"] = "b" * 64
            else:
                run["semantics"][1]["record"]["checks"] = []
            self.assertFalse(summarize(run)["valid_complete_experiment"], kind)

    def test_both_a_cells_and_both_b_cells_contribute(self):
        run = synthetic_run(cpu_b=90)
        for cell in run["cells"]:
            if cell["position"] == 2:
                for row in cell["record"]["rows"]:
                    row["process_cpu_ns"] = 120
        result = summarize(run)
        self.assertTrue(result["valid_complete_experiment"])
        self.assertEqual(result["summaries"]["process_cpu_ns"]["median_improvement_percent"], -5.0)
        self.assertFalse(result["eligible_for_runtime_candidate"])

    def test_eight_blocks_not_positive_subset(self):
        run = synthetic_run(cpu_b=90)
        for cell in run["cells"]:
            if cell["block"] in (0, 1) and cell["variant"] == "B":
                for row in cell["record"]["rows"]:
                    row["process_cpu_ns"] = 110
        result = summarize(run)
        self.assertTrue(result["valid_complete_experiment"])
        self.assertEqual(result["summaries"]["process_cpu_ns"]["positive_blocks"], 6)
        self.assertFalse(result["eligible_for_runtime_candidate"])


class Source(unittest.TestCase):
    def test_only_iterator_hunk_and_verbatim_owner_methods(self):
        source = HERE.parent / "a27-review-source"
        if not source.is_dir():
            self.skipTest("local exact review source is not part of uploaded bundle")
        for relative, digest in PINNED.items():
            self.assertEqual(hashlib.sha256((source / relative).read_bytes()).hexdigest(), digest)
        with tempfile.TemporaryDirectory(prefix="a27-static-", dir=HERE) as directory:
            generated = generate(source, Path(directory))
            original = (source / "src/mcp/runtime/ssh_observation_profile.rs").read_text()
            self.assertEqual((Path(directory) / "A/observation/profile.rs").read_text(), original)
            self.assertEqual((Path(directory) / "B/observation/profile.rs").read_text(), candidate_profile(original))
            self.assertIn("OWNER_METHODS", generated["verbatim_extracts"])
            for name in ("main.rs", "observation/mod.rs", "observation/validation.rs", "mcp/runtime/config.rs"):
                self.assertEqual((Path(directory) / "A" / name).read_bytes(), (Path(directory) / "B" / name).read_bytes())


if __name__ == "__main__":
    unittest.main()
