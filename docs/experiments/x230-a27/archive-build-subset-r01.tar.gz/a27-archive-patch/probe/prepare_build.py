#!/usr/bin/env python3
# Copyright 2026 Muvon Un Limited
# Copyright 2026 TrillionniumFoundation
# SPDX-License-Identifier: Apache-2.0
"""Create isolated full-source probe arms; optionally format/build them once."""
import argparse
import difflib
import hashlib
import json
import os
from pathlib import Path
import signal
import stat
import subprocess
import time

HERE = Path(__file__).resolve().parent
BASE_COMMIT = "65690e5bf8094888524ca2c2cd3cf4d01d846dc6"
BASE_MAP_SHA = "2822cb186ad0d6380a20baa699f5b6e7ed02a9c4cbd0079ca6e50c17a414d2a0"
BASE_AUDIT_SHA = "333ee110483a066e5bd1132839dd91e0d74b09ea5197895595bebc9d04614d1c"
CANDIDATE_AUDIT_SHA = "30ba7a00508b962ed732f9c6f5757c160ebf809698965684585ee6ab27dc6af7"
SAMPLER_SHA = "a9554e63416504428439a6cf3fe1f5b8ede090c2ef856bda3f1add413d06d40a"
AUDIT = "src/mcp/runtime/request_audit.rs"
INDEX = "src/mcp/runtime/request_archive_index.rs"
PROBE = "src/mcp/runtime/a27_archive_probe.rs"
MAIN = "src/main.rs"
TEST_WIRING = '\n#[cfg(all(test, unix))]\n#[path = "request_audit_preparation_tests.rs"]\nmod preparation_tests;\n'
AUDIT_HOOK = '''
#[cfg(target_os = "linux")]
pub(crate) async fn run_a27_archive_probe() -> Result<()> {
\tindex::a27_archive_probe::run().await
}
'''
INDEX_HOOK = '''
#[cfg(target_os = "linux")]
#[path = "a27_archive_probe.rs"]
pub(super) mod a27_archive_probe;
'''
MAIN_HOOK = '''async fn main() -> Result<()> {
\t#[cfg(target_os = "linux")]
\tif std::env::var_os("HEPTA_A27_ARCHIVE_PROBE_ROOT").is_some() {
\t\treturn mcp::runtime::request_audit::run_a27_archive_probe().await;
\t}
'''


def need(value, message):
    if not value:
        raise ValueError(message)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":")).encode()


def stamp(st):
    return (st.st_dev, st.st_ino, st.st_mode, st.st_uid, st.st_nlink,
            st.st_size, st.st_mtime_ns, st.st_ctime_ns)


def read_stable(path):
    path = Path(path)
    need(path.is_absolute() and path == path.resolve(), "source path is indirect")
    fd = os.open(path, os.O_RDONLY | os.O_CLOEXEC | os.O_NOFOLLOW | os.O_NONBLOCK)
    with os.fdopen(fd, "rb") as stream:
        before = os.fstat(stream.fileno())
        need(stat.S_ISREG(before.st_mode), "input is not regular")
        data = stream.read()
        need(len(data) == before.st_size and stamp(before) == stamp(os.fstat(stream.fileno()))
             == stamp(path.lstat()), "input changed while read")
    return data


def write_new(path, data, mode=0o600):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_CLOEXEC, mode)
    with os.fdopen(fd, "wb") as stream:
        stream.write(data)
        stream.flush()
        os.fsync(stream.fileno())


def source_map(root):
    paths = ["Cargo.toml", "Cargo.lock", "rustfmt.toml"]
    for path in (root / "src").rglob("*"):
        need(not path.is_symlink(), "source contains a symlink")
        if path.is_file():
            paths.append(path.relative_to(root).as_posix())
        else:
            need(path.is_dir(), "source contains a special file")
    return {name: sha(read_stable(root / name)) for name in sorted(paths)}


def remove_candidate_delta(text):
    marker = "/// Callers hold STORE_LOCK. Metadata queries consume the archive, not copies of\n"
    need(text.count(marker) == 1, "candidate helper marker differs")
    start = text.index(marker)
    end = text.index("#[cfg(unix)]\nfn hot_snapshot_at", start)
    text = text[:start] + text[end:]
    need(text.count("metadata_archive(root, &hot)?") == 2, "candidate query callsites differ")
    return text.replace("metadata_archive(root, &hot)?", "hot_snapshot(root, &hot)?.1")


def disjoint_target(target, protected):
    need(target != protected and not target.is_relative_to(protected)
         and not protected.is_relative_to(target), "probe target overlaps the qualified target")
    protected_inodes = set()
    if protected.exists():
        for directory, _dirs, names in os.walk(protected, followlinks=False):
            for name in names:
                value = (Path(directory) / name).lstat()
                if stat.S_ISREG(value.st_mode):
                    protected_inodes.add((value.st_dev, value.st_ino))
    checked = 0
    if target.exists():
        for directory, dirs, names in os.walk(target, followlinks=False):
            for name in dirs + names:
                value = (Path(directory) / name).lstat()
                need(not stat.S_ISLNK(value.st_mode), "probe target contains an indirect cache member")
                if stat.S_ISREG(value.st_mode):
                    need((value.st_dev, value.st_ino) not in protected_inodes,
                         "probe cache is hardlinked to the qualified target")
                    checked += 1
    return {"qualified_target_inodes_checked": len(protected_inodes),
            "existing_probe_target_files_checked": checked, "no_shared_regular_inodes": True}


def command(args, cwd, output, name):
    out = output / (name + ".stdout.log")
    err = output / (name + ".stderr.log")
    started = time.monotonic()
    forwarded = False
    with out.open("xb") as stdout, err.open("xb") as stderr:
        env = {key: value for key, value in os.environ.items()
               if not key.startswith("HEPTA_") and key not in ("RUSTFLAGS", "CARGO_ENCODED_RUSTFLAGS")}
        proc = subprocess.Popen(args, cwd=cwd, env=env, stdout=stdout, stderr=stderr)
        try:
            code = proc.wait()
        except KeyboardInterrupt:
            if proc.poll() is None:
                proc.send_signal(signal.SIGINT)
                forwarded = True
            code = proc.wait()
        stdout.flush()
        stderr.flush()
        os.fsync(stdout.fileno())
        os.fsync(stderr.fileno())
    return {"name": name, "command": args, "returncode": code,
            "seconds": time.monotonic() - started, "sigint_forwarded": forwarded,
            "stdout": {"file": out.name, "sha256": sha(out.read_bytes()), "bytes": out.stat().st_size},
            "stderr": {"file": err.name, "sha256": sha(err.read_bytes()), "bytes": err.stat().st_size}}


def compiler_binary(log, source):
    rows = []
    for line in log.read_bytes().splitlines():
        try:
            row = json.loads(line)
        except ValueError:
            continue
        if row.get("reason") == "compiler-artifact" and row.get("target", {}).get("name") == "hepta-runtime" \
                and row.get("profile", {}).get("test") is False:
            rows.append(row)
    need(len(rows) == 1, "exactly one release runtime artifact required")
    row = rows[0]
    need(row.get("manifest_path") == str(source / "Cargo.toml")
         and row.get("target", {}).get("src_path") == str(source / "src/main.rs"),
         "compiler artifact source binding differs")
    return Path(row["executable"])


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source", type=Path, required=True, help="Exact untouched qualified A26 source")
    parser.add_argument("--output", type=Path, required=True, help="New isolated source/build directory")
    parser.add_argument("--target-dir", type=Path, required=True, help="Independent archive-probe Cargo target")
    parser.add_argument("--protected-target", type=Path,
                        default=Path("/home/qian/.local/state/hepta-runtime-native-dev-20261018/target-v61-diagnostic-a1"))
    parser.add_argument("--cargo", type=Path, default=Path.home() / ".cargo/bin/cargo")
    parser.add_argument("--toolchain", default="1.95.0")
    parser.add_argument("--jobs", type=int, choices=[1, 2], default=2)
    parser.add_argument("--build", action="store_true", help="Format and compile both arms once after preparing them")
    args = parser.parse_args()
    source, output, target, protected = (value.absolute() for value in
        (args.source, args.output, args.target_dir, args.protected_target))
    need(source == source.resolve() and source.is_dir(), "source root is indirect or missing")
    need(output.parent.is_dir() and output.parent == output.parent.resolve()
         and not os.path.lexists(output), "output must have an existing direct parent and be fresh")
    need(target == target.resolve() and protected == protected.resolve(), "target path is indirect")
    need(not target.is_relative_to(source) and not source.is_relative_to(target), "target overlaps source")
    frozen = json.loads(read_stable(HERE / "baseline_source_map.json"))
    need(frozen["commit"] == BASE_COMMIT and len(frozen["files"]) == 156
         and sha(canonical(frozen["files"])) == BASE_MAP_SHA, "baseline source map differs")
    actual = source_map(source)
    need(actual == frozen["files"], "actual source differs from exact qualified A26")
    candidate = read_stable(HERE.parent / "modified/request_audit.rs")
    need(sha(candidate) == CANDIDATE_AUDIT_SHA, "candidate source differs")
    baseline = read_stable(source / AUDIT)
    need(sha(baseline) == BASE_AUDIT_SHA, "baseline audit differs")
    candidate_text = candidate.decode()
    need(candidate_text.count(TEST_WIRING) == 1, "candidate test-only wiring differs")
    candidate_text = candidate_text.replace(TEST_WIRING, "")
    need(remove_candidate_delta(candidate_text) == baseline.decode(), "production delta expanded")
    probe = read_stable(HERE / "a27_archive_probe.rs")
    need(sha(read_stable(HERE / "resource_sampler.py")) == SAMPLER_SHA, "resource sampler differs")
    target_check = disjoint_target(target, protected)
    output.mkdir(mode=0o700)
    report = {"schema": "hepta-a27-archive-probe-build/v1", "base_commit": BASE_COMMIT,
              "base_source_map_sha256": BASE_MAP_SHA, "probe_source_sha256": sha(probe),
              "resource_sampler_sha256": SAMPLER_SHA, "production_delta_verified": True,
              "target_separation": target_check, "build_requested": args.build,
              "probe_is_runtime_candidate": False, "runtime_qualified": False,
              "automatic_build_retries": 0, "dependency_downloads": 0, "arms": {}, "stages": [], "passed": False}
    try:
        for arm in ("A", "B"):
            root = output / ("source-" + arm)
            for relative in sorted(actual):
                raw = read_stable(source / relative)
                need(sha(raw) == actual[relative], "baseline source changed during copy")
                if relative == AUDIT:
                    raw = ((baseline.decode() if arm == "A" else candidate_text) + AUDIT_HOOK).encode()
                elif relative == INDEX:
                    raw += INDEX_HOOK.encode()
                elif relative == MAIN:
                    text = raw.decode()
                    need(text.count("async fn main() -> Result<()> {\n") == 1, "main hook anchor differs")
                    raw = text.replace("async fn main() -> Result<()> {\n", MAIN_HOOK).encode()
                write_new(root / relative, raw)
            write_new(root / PROBE, probe)
            report["arms"][arm] = {"source": root.name, "source_before_format": source_map(root)}
        if args.build:
            for arm in ("A", "B"):
                root = output / ("source-" + arm)
                cargo = [str(args.cargo), "+" + args.toolchain]
                stage = command(cargo + ["fmt", "--manifest-path", str(root / "Cargo.toml")],
                                root, output, "format-" + arm)
                report["stages"].append(stage)
                need(stage["returncode"] == 0 and not stage["sigint_forwarded"], "probe formatting failed or interrupted")
                tested = source_map(root)
                stage = command(cargo + ["build", "--release", "--locked", "--offline", "--all-features",
                    "--bin", "hepta-runtime", "--message-format=json", "--jobs", str(args.jobs),
                    "--target-dir", str(target), "--manifest-path", str(root / "Cargo.toml")],
                    root, output, "build-" + arm)
                report["stages"].append(stage)
                need(stage["returncode"] == 0 and not stage["sigint_forwarded"], "probe build failed or interrupted")
                after = source_map(root)
                need(tested == after, "probe source changed during build")
                executable = compiler_binary(output / ("build-" + arm + ".stdout.log"), root)
                binary = read_stable(executable)
                write_new(output / ("probe-" + arm), binary, 0o700)
                report["arms"][arm].update(source_tested=tested, source_after=after,
                    binary={"file": "probe-" + arm, "sha256": sha(binary), "bytes": len(binary),
                            "compiler_executable": str(executable), "copied_immediately_after_build": True})
            a = (output / "source-A" / AUDIT).read_text()
            b = (output / "source-B" / AUDIT).read_text()
            need(remove_candidate_delta(b) == a, "formatted production delta expanded")
            maps = {arm: source_map(output / ("source-" + arm)) for arm in ("A", "B")}
            need([path for path in maps["A"] if maps["A"][path] != maps["B"][path]] == [AUDIT],
                 "probe arms differ outside request_audit")
            report["runtime_difference_only"] = AUDIT
            report["passed"] = True
        report["source_original_unchanged"] = source_map(source) == actual
        need(report["source_original_unchanged"], "input source changed")
    except Exception as error:
        report["error"] = {"type": type(error).__name__, "message": str(error)}
    write_new(output / "build.json", canonical(report) + b"\n")
    print(json.dumps({"output": str(output), "passed": report["passed"],
                      "prepared": len(report["arms"]) == 2, "error": report.get("error")}))
    return 0 if (report["passed"] or (not args.build and "error" not in report)) else 1


if __name__ == "__main__":
    raise SystemExit(main())
