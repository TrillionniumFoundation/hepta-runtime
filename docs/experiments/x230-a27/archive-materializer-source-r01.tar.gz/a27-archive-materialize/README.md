# A27 archive candidate source preparation

`prepare_candidate_source.py` only prepares new source files. It does not run a
runtime, probe, compiler, test, formatter, qualifier, or network operation. It
does not grant adoption or deployment authority.

The input must be the actual analysis produced by the frozen archive experiment.
The script requires all three fields to be exactly `true`: `verified`,
`comparison_valid`, and `diagnostic_performance_gate_passed`. It also binds the
complete frozen bundle and predeclared plan, all 536 successful cells, the six
mixed shapes, twelve individual shapes, eight cold guards, and complete resource
error evidence. A failed or partial experiment cannot prepare a candidate.

The current A26 source is independently enumerated and read in full: exactly the
156 qualified source paths and their SHA256 values must match. Every file read
uses `O_NOFOLLOW`, requires a singly linked regular file, and verifies descriptor
and path stamps before/after. No symlink, shared inode, probe hook, or unrelated
source change is copied into the candidate.

Destination files are created through private directory descriptors using
`O_EXCL` and mode `0600`, then flushed and fsynced. The final tree must contain
157 files: `request_audit.rs` is the only changed existing file,
`request_audit_preparation_tests.rs` is the only new file, and 155 files are
unchanged. The A26 source and all bound inputs are rechecked at the end.

Example for the x230 owner, **only after the actual performance gates pass**:

```bash
python3 prepare_candidate_source.py \
  --source "$B/source-a26-r01" \
  --analysis "$B/archive-probe-analysis-r01.json" \
  --bundle "$B/a27-archive-probe-bundle-r01/a27-archive-patch" \
  --output "$B/archive-candidate-source-preparation-r01"
```

The output directory must be fresh. Successful preparation produces:

- `source/`: the candidate tree for the existing independent qualifier.
- `source-before-format.json`: exact 157-file hashes, sizes, source-map digest,
  and the one-changed/one-new delta.
- `inputs-before.json`: source and analysis/bundle hash bindings.
- `attempt.json` and `preparation.json`: create-only attempt and final receipts.

If a gate or copy fails, the output and any partial copy remain as failed
evidence. `prepared=true` only means that the source preparation passed; both
`runtime_qualified` and `adopted` remain false. Formatting and independent
qualification must run separately against the resulting `source/` directory.

The local author performed AST parsing only. The script was not imported or
executed, no actual or fabricated successful analysis was supplied, and no
candidate tree was generated locally.
