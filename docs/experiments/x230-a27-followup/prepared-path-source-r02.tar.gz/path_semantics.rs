// Copyright 2026 Muvon Un Limited
// Copyright 2026 TrillionniumFoundation
// SPDX-License-Identifier: Apache-2.0
//! Untimed real-filesystem checks shared by both standalone variants.

use super::profile;
use anyhow::{bail, Context, Result};
use serde_json::{json, Value};
use std::fs::{self, DirBuilder, File, OpenOptions};
use std::io::{Read, Write};
use std::os::fd::AsRawFd;
use std::os::unix::ffi::OsStrExt;
use std::os::unix::fs::{DirBuilderExt, MetadataExt, OpenOptionsExt};
use std::path::Path;

fn require(value: bool, label: &str) -> Result<()> {
	if !value {
		bail!("semantic assertion failed: {label}");
	}
	Ok(())
}

fn open(path: &Path, directory: bool) -> Result<File> {
	profile::ProbePath::new(path)?.open(directory)
}

fn write_new(path: &Path, bytes: &[u8]) -> Result<()> {
	let mut file = OpenOptions::new().write(true).create_new(true).mode(0o600).open(path)?;
	file.write_all(bytes)?;
	file.sync_all()?;
	Ok(())
}

pub(super) fn run(root: &Path) -> Result<Value> {
	profile::absolute(root)?;
	DirBuilder::new().mode(0o700).create(root)?;
	let nested = root.join("nested");
	DirBuilder::new().mode(0o700).create(&nested)?;
	let leaf = nested.join("file");
	let mut file = OpenOptions::new().write(true).create_new(true).mode(0o600).open(&leaf)?;
	file.write_all(b"owner-path-fixture")?;
	file.sync_all()?;
	drop(file);
	let mut records = Vec::new();
	for (path, directory) in [(&leaf, false), (&nested, true)] {
		let opened = open(path, directory)?;
		let actual = opened.metadata()?;
		let expected = fs::symlink_metadata(path)?;
		require((actual.dev(), actual.ino()) == (expected.dev(), expected.ino()), "descriptor identity")?;
		let status = unsafe { libc::fcntl(opened.as_raw_fd(), libc::F_GETFL) };
		let descriptor = unsafe { libc::fcntl(opened.as_raw_fd(), libc::F_GETFD) };
		let baseline = profile::open_absolute(path, directory)?;
		require(status >= 0 && descriptor >= 0, "fcntl result")?;
		require(status == unsafe { libc::fcntl(baseline.as_raw_fd(), libc::F_GETFL) }
			&& descriptor == unsafe { libc::fcntl(baseline.as_raw_fd(), libc::F_GETFD) }, "exact baseline flags")?;
		require(status & libc::O_NONBLOCK != 0 && descriptor & libc::FD_CLOEXEC != 0, "nonblocking and cloexec")?;
		require(!directory || status & libc::O_DIRECTORY != 0, "directory flag")?;
		records.push(json!({"case": if directory {"nested_directory"} else {"regular_leaf"}, "passed": true}));
	}
	let mut bytes = Vec::new();
	open(&leaf, false)?.read_to_end(&mut bytes)?;
	require(bytes == b"owner-path-fixture", "leaf bytes")?;
	for directory in [false, true] {
		let prepared = open(Path::new("/"), directory)?;
		let baseline = profile::open_absolute(Path::new("/"), directory)?;
		require(prepared.metadata()?.is_dir() && prepared.metadata()?.ino() == baseline.metadata()?.ino(), "root path")?;
		for command in [libc::F_GETFL, libc::F_GETFD] {
			require(unsafe { libc::fcntl(prepared.as_raw_fd(), command) } == unsafe {
				libc::fcntl(baseline.as_raw_fd(), command)
			}, "root flags")?;
		}
	}
	let repeated = format!("{}//nested///file", root.display());
	require(open(Path::new(&repeated), false)?.metadata()?.ino() == fs::metadata(&leaf)?.ino(), "repeated separator")?;
	fs::symlink_metadata(&leaf)?;
	std::os::unix::fs::symlink(&leaf, root.join("leaf-link"))?;
	std::os::unix::fs::symlink(&nested, root.join("dir-link"))?;
	for (label, path, directory) in [
		("file_as_directory", leaf.clone(), true),
		("file_intermediate", leaf.join("child"), false),
		("leaf_symlink", root.join("leaf-link"), false),
		("intermediate_symlink", root.join("dir-link/file"), false),
		("missing_leaf", root.join("absent"), false),
	] {
		let error = open(&path, directory).err().with_context(|| format!("unexpected open success: {label}"))?;
		records.push(json!({"case": label, "rejected": true,
			"errno": error.downcast_ref::<std::io::Error>().and_then(std::io::Error::raw_os_error)}));
	}
	let invalid_utf8 = Path::new(std::ffi::OsStr::from_bytes(b"/\xff"));
	for (label, path) in [
		("relative", Path::new("relative").to_owned()),
		("parent_component", root.join("nested/../file")),
		("dot_component", root.join("./file")),
		("whitespace", root.join("a b")),
		("nul", root.join(std::ffi::OsStr::from_bytes(b"bad\0name"))),
		("invalid_utf8", invalid_utf8.to_owned()),
	] {
		require(profile::absolute(&path).is_err(), label)?;
		require(profile::ProbePath::new(&path).is_err(), label)?;
		require(open(&path, false).is_err(), label)?;
		records.push(json!({"case": label, "lexically_rejected": true}));
	}
	let fresh = root.join("fresh");
	let mut caller_path = fresh.clone();
	let retained = profile::ProbePath::new(&caller_path)?;
	caller_path.set_file_name("different");
	require(retained.as_path() == fresh.as_path() && retained.open(false).is_err(), "owned lexical bytes")?;
	records.push(json!({"case": "owned_lexical_bytes", "passed": true}));
	write_new(&fresh, b"first")?;
	let first = retained.open(false)?.metadata()?;
	let previous = root.join("previous");
	fs::rename(&fresh, &previous)?;
	write_new(&fresh, b"replacement")?;
	let mut reopened = retained.open(false)?;
	require(reopened.metadata()?.ino() != first.ino(), "fresh descriptor after replacement")?;
	let mut changed = Vec::new();
	reopened.read_to_end(&mut changed)?;
	require(changed == b"replacement", "replacement contents")?;
	drop(reopened);
	records.push(json!({"case": "fresh_descriptor_after_replacement", "passed": true}));
	fs::remove_file(&fresh)?;
	std::os::unix::fs::symlink(&previous, &fresh)?;
	require(retained.open(false).is_err(), "late leaf symlink")?;
	records.push(json!({"case": "late_leaf_symlink", "rejected": true}));
	let retained_nested = profile::ProbePath::new(&leaf)?;
	let moved = root.join("moved-nested");
	fs::rename(&nested, &moved)?;
	std::os::unix::fs::symlink(&moved, &nested)?;
	require(retained_nested.open(false).is_err(), "late intermediate symlink")?;
	records.push(json!({"case": "late_intermediate_symlink", "rejected": true}));
	Ok(json!({"schema": "hepta-x230-owner-path-semantics/v1", "passed": true,
		"checks": records, "root_readable": true, "leaf_bytes_match": true,
		"repeated_separator_same_inode": true, "recursive_cleanup": false}))
}
