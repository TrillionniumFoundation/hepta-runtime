// Copyright 2026 Muvon Un Limited
// Copyright 2026 TrillionniumFoundation
// SPDX-License-Identifier: Apache-2.0
//! Prepared paths retain lexical, descriptor and no-follow behavior.

use super::*;
use std::io::Read;
use std::os::unix::ffi::OsStrExt;
use std::os::unix::fs::{symlink, MetadataExt};

#[test]
fn prepared_paths_reject_invalid_lexical_inputs_and_keep_root() {
	for path in [
		Path::new("relative"),
		Path::new("/one/./two"),
		Path::new("/one/../two"),
		Path::new("/space name"),
		Path::new(std::ffi::OsStr::from_bytes(b"/bad\0name")),
		Path::new(std::ffi::OsStr::from_bytes(b"/\xff")),
	] {
		assert!(PreparedPath::new(path).is_err());
		assert!(super::super::open_absolute(path, false).is_err());
	}
	let root = PreparedPath::new(Path::new("/")).unwrap();
	assert_eq!(root.as_path(), Path::new("/"));
	for directory in [false, true] {
		let prepared = root.open(directory).unwrap();
		let original = super::super::open_absolute(Path::new("/"), directory).unwrap();
		assert_eq!(prepared.metadata().unwrap().ino(), original.metadata().unwrap().ino());
		assert_eq!(unsafe { libc::fcntl(prepared.as_raw_fd(), libc::F_GETFL) }, unsafe {
			libc::fcntl(original.as_raw_fd(), libc::F_GETFL)
		});
	}
}

#[test]
fn prepared_paths_keep_flags_and_reject_leaf_and_intermediate_symlinks() {
	let root = tempfile::tempdir().unwrap();
	let nested = root.path().join("nested");
	std::fs::create_dir(&nested).unwrap();
	let leaf = nested.join("file");
	std::fs::write(&leaf, b"fixture").unwrap();
	for (path, directory) in [(&leaf, false), (&nested, true)] {
		let prepared = PreparedPath::new(path).unwrap().open(directory).unwrap();
		let original = super::super::open_absolute(path, directory).unwrap();
		assert_eq!(prepared.metadata().unwrap().ino(), original.metadata().unwrap().ino());
		for command in [libc::F_GETFL, libc::F_GETFD] {
			assert_eq!(unsafe { libc::fcntl(prepared.as_raw_fd(), command) }, unsafe {
				libc::fcntl(original.as_raw_fd(), command)
			});
		}
	}
	assert!(PreparedPath::new(&leaf).unwrap().open(true).is_err());
	assert!(PreparedPath::new(&leaf.join("child")).unwrap().open(false).is_err());
	symlink(&leaf, root.path().join("leaf-link")).unwrap();
	symlink(&nested, root.path().join("dir-link")).unwrap();
	assert!(PreparedPath::new(&root.path().join("leaf-link")).unwrap().open(false).is_err());
	assert!(PreparedPath::new(&root.path().join("dir-link/file")).unwrap().open(false).is_err());
}

#[test]
fn prepared_paths_own_lexical_bytes_and_reopen_replaced_paths() {
	let root = tempfile::tempdir().unwrap();
	let path = root.path().join("file");
	// Preparation does not require the file to exist and retains no descriptor.
	let mut input = path.clone();
	let prepared = PreparedPath::new(&input).unwrap();
	input.set_file_name("different");
	assert_eq!(prepared.as_path(), path.as_path());
	assert!(prepared.open(false).is_err());
	std::fs::write(&path, b"first").unwrap();
	let first = prepared.open(false).unwrap().metadata().unwrap();
	let previous = root.path().join("previous");
	std::fs::rename(&path, &previous).unwrap();
	std::fs::write(&path, b"replacement").unwrap();
	let mut opened = prepared.open(false).unwrap();
	assert_ne!(opened.metadata().unwrap().ino(), first.ino());
	let mut bytes = Vec::new();
	opened.read_to_end(&mut bytes).unwrap();
	assert_eq!(bytes, b"replacement");
	drop(opened);
	std::fs::remove_file(&path).unwrap();
	symlink(&previous, &path).unwrap();
	assert!(prepared.open(false).is_err());
}
