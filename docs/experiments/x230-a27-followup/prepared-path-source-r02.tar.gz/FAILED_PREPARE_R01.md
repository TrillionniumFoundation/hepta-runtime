# Preserved CString preparation r01 and exact formatter-check correction

The first CString preparation stopped after its compiler-version and two rustfmt
stages, all with return code 0. It did not enter either Rust compilation stage or
execute a probe. The recorded error was:

`formatted B profile differs from the frozen prepared-path candidate plus untimed adapter`

The original private `B/a27-prepared-path-probe-build-r01` remains preserved.
Its complete build report is 246,940 bytes, SHA256
`073d7ffb5d28c319a7f416ff3b9373773d7ec1d0c79750ca3437903d0b9181c4`.
It records `prepared=true`, `compiled=false`, `probe_executed=false`. The failed
assertion precedes compilation and the final successful input fence.

The actual formatted B profile was independently downloaded and hash-verified:
23,719 bytes, SHA256
`0151f05a59fe6170c459ac37d8451a880ae4c17ebf8e7e1434e574cfe80d4975`.
The frozen generated B profile before formatting is 23,710 bytes, SHA256
`8c11c1722ac669336920d4aa9e159fd3701453b7c3874f6a2f179eff19c6ae21`.
Their sole difference is the following Rust 1.95.0 rustfmt layout:

```diff
-        verify_read_with(&file, &stamp, length, self.maximum, || self.path.open(false))?;
+        verify_read_with(&file, &stamp, length, self.maximum, || {
+            self.path.open(false)
+        })?;
```

The block contains the same sole tail expression, with the same captures,
arguments, lazy invocation and return value. No other source bytes differ.

r02 changes only the preparation checker to construct this one exact observed
formatted representation, then compare the entire actual UTF-8 file exactly.
It does not strip whitespace, ignore tokens, accept arbitrary block rewriting or
alter the frozen candidate generator. The original generator, semantic adapter,
runtime patch, new Rust modules, PLAN, timing loop, runner and statistical gates
remain unchanged. Targeted local checks accept the real captured file and reject
changed open flags, changed reopen behavior, additional newline, and the
unformatted candidate. All original checks remain enabled.

This is a fresh preparation attempt with new output directories. No workload or
probe operation is replayed. The r01 bundle, source, failed build and evidence are
retained separately.
