# A27 prepared PinnedFile components: fixed owner-path experiment

Baseline: independently qualified A26 commit
`65690e5bf8094888524ca2c2cd3cf4d01d846dc6`.

## One hypothesis and its limits

The candidate prepares the normal components of each immutable `PinnedFile`
path as C strings once, while loading that pin. `PreparedPath` owns the original
path and a boxed slice of `CString` values behind private fields in a private
module. It exposes only construction, an immutable path borrow and fresh open.
Callers cannot mutate the original path separately from its prepared components.
Preparation performs lexical validation and copies strings; it does not open a
file or observe the filesystem.

Every later open still runs the original `absolute` check, opens a fresh `/`
descriptor and walks every component with the original openat flags and ordering.
The existing regular-file, ownership, mode, link-count, size, executable and
capability checks remain in one common predicate after opening. The original
length and held-descriptor metadata checks still precede the lazy final path
reopen. Every file byte is read and hashed with the unchanged 16KiB buffer.

Only the six `PinnedFile` values use this representation. Generic root, socket
and shell-resolution path operations retain the original A26 `open_absolute`,
including its temporary Vec. This experiment does not adopt or retest the
rejected peekable candidate. Shell links and directories are still revalidated
freshly before verifying the pinned shell target. Worker and owner checks on the
two sides of an await remain separate. Policy serialization is unchanged.

The static call graph has 36 prepared file opens per complete owner profile
check: two full-file passes each opening six files twice, and two owner boundary
passes each opening six identities once. This identifies repeated CString
allocation/copying; it is not a measured allocation count or CPU attribution.
The candidate retains extra lexical representation memory for those pins. Its
effect on complete owner process CPU is unknown and may fail the fixed gate.

## Measurement and decision are fixed

Use the same complete original `verify_request_profile` /
`verify_profile_for(Request)` scope as the earlier owner-path probe: both full
worker checks, both owner boundary checks, PrivateRoot and a fresh real Unix
socket/peer/key check. The copied config and validation-worker modules and owner
methods remain bound to the precise qualified source. The caller deadline is
5 seconds; the original agent cap is 2 seconds. Stop, timeout acceptance and
worker shutdown drain retain their original code and ordering.

Run exactly 8 ABBA blocks, each cell in a fresh process and private fixture. Each
cell binds the synthetic agent, then runs 4 complete warmups and 64 measured
checks. Total: 128 warmups, 2048 measured operations, 32 measured cells. A clean
cell has exactly 69 synthetic-agent requests. There is no SSH child or RPC.

Primary time is process CPU including blocking workers and the same-process
synthetic agent. Owner-thread CPU is supplemental. Wall time surrounds the same
complete operation; CPU windows also include fixed clock bookkeeping. Setup,
lexical preparation, pinning, output and shutdown are outside each timed window.
The candidate's persistent-memory tradeoff is not a measured memory benefit.

Use both A cells and both B cells within every block. The candidate is eligible
only if the complete experiment is valid and all four original gates pass:

- Paired process CPU improvement median is at least 3%.
- At least 7 of 8 CPU blocks improve.
- Median CPU improvement is strictly greater than twice the MAD of the eight
  paired percentage improvements.
- Median wall regression is at most 2%.

The runner and statistical calculation are unchanged. The semantic preflight
coverage is extended for this new representation. All rows and failures remain
in evidence. Any failed preflight, child, cleanup or input fence stops subsequent
cells. There is no retry, successful-subset selection or adaptive scaling. Failure
of the gates retains A26. Eligibility would justify a separate runtime
qualification and end-to-end experiment; it does not authorize adoption.

## Source and semantic checks

The runtime patch modifies only profile file handling and adds the private
prepared-path module with three sibling unit tests. The patch does not contain
probe adapters. Generated standalone profile copies append a small untimed
`ProbePath` adapter: A delegates to the exact original generic walk, B delegates
to `PreparedPath`. The adapter is used only by the separate semantic mode.
Timed `PinnedFile` and owner verification select neither adapter.

Both semantic preflights check invalid UTF-8, NUL, relative and dot components,
root paths, repeated separators, exact descriptor/open flags, leaf and
intermediate symlinks, and file-as-directory rejection. They also retain one
prepared object while changing the caller's PathBuf, replacing the leaf inode,
and introducing late leaf/intermediate symlinks. Reopening must observe the
replacement inode and reject both later links. Only fresh private fixture files
are changed; fixtures are retained after the probe.

Local Python checks verify that generic `open_absolute`, the post-open inode
predicate, lazy final-reopen predicate, full read/hash loop and copied owner
methods retain their exact code. No Rust build or execution occurs locally.

## Build and execution boundaries

The preparation script reuses the corrected qualified-artifact selector from the
previous r02 probe: full runtime profile equality, unique release-deps rlib,
exact package/manifest/Cargo.lock checks, all recorded inputs hashed before and
after. It uses existing Rust 1.95.0 and release rlibs with `panic=abort`. It never
invokes Cargo or writes the protected shared target. Formatting affects only the
fresh independent build tree. Original generated and actual formatted compiled
sources are both retained. Copied original and new sibling tests let rustfmt
resolve unchanged test wiring; the normal probe binary does not enable unit tests.

Root must serialize preparation and the single fixed run after the current
archive experiment. The protected A26 target and qualification inputs must stay
unchanged until their input fences complete. Use new bundle/build/run paths and
a new short private fixture parent, for example `/home/qian/ha27c01`.

```sh
python3 -B prepare_owner_probe.py --qualification QUALIFICATION/report.json --qualification-receipt QUALIFICATION/independent-receipt.json --rustc ACTUAL_TOOLCHAIN/bin/rustc --output-dir FRESH_BUILD --compile
python3 -B run_owner_probe.py --build FRESH_BUILD/build.json --fixture-parent /home/qian/ha27c01 --output-dir FRESH_RUN
```

Do not apply the runtime patch to the original source while preparing or running
this probe. If later eligible, use the actual rustfmt output as the candidate
source for independent full qualification.
