// Copyright 2026 Muvon Un Limited
// Copyright 2026 TrillionniumFoundation
// SPDX-License-Identifier: Apache-2.0
//! Immutable lexical preparation; every open still walks fresh descriptors.

use super::absolute;
use anyhow::Result;
use std::ffi::CString;
use std::fs::File;
use std::os::fd::{AsRawFd, FromRawFd};
use std::path::{Component, Path, PathBuf};

#[derive(Clone)]
pub(super) struct PreparedPath {
	// Only this module can construct or change the representation. Neither
	// field is exposed mutably, and it stores no filesystem observation.
	path: PathBuf,
	components: Box<[CString]>,
}

impl PreparedPath {
	pub(super) fn new(path: &Path) -> Result<Self> {
		absolute(path)?;
		let components = path
			.components()
			.filter_map(|value| match value {
				Component::Normal(value) => Some(value),
				_ => None,
			})
			.map(|value| CString::new(value.as_encoded_bytes()))
			.collect::<std::result::Result<Vec<_>, _>>()?
			.into_boxed_slice();
		Ok(Self {
			path: path.to_owned(),
			components,
		})
	}

	pub(super) fn as_path(&self) -> &Path {
		&self.path
	}

	pub(super) fn open(&self, directory: bool) -> Result<File> {
		// Keep the existing per-call lexical check as well as every fresh
		// descriptor, flag and error boundary of open_absolute.
		absolute(&self.path)?;
		let mut current = File::open("/")?;
		for (index, name) in self.components.iter().enumerate() {
			let flags = libc::O_RDONLY
				| libc::O_NOFOLLOW
				| libc::O_NONBLOCK
				| libc::O_CLOEXEC
				| if index + 1 < self.components.len() || directory {
					libc::O_DIRECTORY
				} else {
					0
				};
			let fd = unsafe { libc::openat(current.as_raw_fd(), name.as_ptr(), flags) };
			if fd < 0 {
				return Err(std::io::Error::last_os_error().into());
			}
			current = unsafe { File::from_raw_fd(fd) };
		}
		Ok(current)
	}
}

#[cfg(test)]
#[path = "ssh_observation_prepared_path_tests.rs"]
mod tests;
