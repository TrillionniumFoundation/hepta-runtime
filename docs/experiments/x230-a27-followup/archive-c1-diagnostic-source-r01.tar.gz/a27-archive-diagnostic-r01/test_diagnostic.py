#!/usr/bin/env python3
# Copyright 2026 TrillionniumFoundation; SPDX-License-Identifier: Apache-2.0
"""Pure adapter/parser checks; no real process, procfs read or workload."""
import hashlib
import importlib.util
from pathlib import Path
import subprocess
import sys
import unittest

sys.dont_write_bytecode = True
spec = importlib.util.spec_from_file_location('_fixed_diagnostic', Path(__file__).with_name('run_archive_diagnostic.py'))
d = importlib.util.module_from_spec(spec)
spec.loader.exec_module(d)


class DiagnosticChecks(unittest.TestCase):
    def fixture(self, launch):
        directory = Path('/synthetic-owned/size-65536/arm-A')
        binary = Path('/synthetic-build/probe-A')
        body = b'fixed fake baseline bytes'
        gate = d.OneBaselineLaunch(binary, directory, hashlib.sha256(body).hexdigest(), lambda _path: body, launch)
        env = {'HEPTA_A27_ARCHIVE_PROBE_ROOT': str(directory / 'fixture'),
               'HEPTA_A27_ARCHIVE_PROBE_ROWS': '65536', 'TOKIO_WORKER_THREADS': '2'}
        kw = {'cwd': directory, 'stdin': subprocess.PIPE, 'stdout': subprocess.PIPE,
              'stderr': object(), 'env': env}
        return gate, binary, kw

    def test_fixed_eighteen_queries_one_baseline_c1(self):
        self.assertEqual(d.PROCESS['setup_public_queries'] + sum(c['calls'] for c in d.CELLS), 18)
        self.assertEqual([(c['sequence'], c['kind'], c['concurrency'], c['arm']) for c in d.CELLS],
                         [(0, 'usage', 1, 'A'), (1, 'history', 1, 'A')])
        self.assertTrue(all(c['rows'] == 65536 and c['calls'] == 8 and not c['cold'] for c in d.CELLS))

    def test_trace_injected_only_at_original_direct_launch(self):
        seen = []; owned = object()
        def fake(argv, **kw):
            seen.append((argv, kw)); return owned
        gate, binary, kw = self.fixture(fake)
        self.assertIs(gate([str(binary)], **kw), owned)
        self.assertEqual(seen[0][1]['env']['HEPTA_ARCHIVE_INDEX_TRACE'], '1')
        self.assertNotIn('HEPTA_ARCHIVE_INDEX_TRACE', kw['env'])
        self.assertEqual(gate.calls, 1)
        self.assertTrue(gate.receipt['direct_executable_no_wrapper'])
        with self.assertRaises(ValueError): gate([str(binary)], **kw)
        self.assertEqual(len(seen), 1)

    def test_wrong_arm_scope_or_changed_binary_never_launches(self):
        seen = []
        for error in ('arm', 'scope', 'binary'):
            gate, binary, kw = self.fixture(lambda *a, **k: seen.append(a))
            argv = [str(binary)]
            if error == 'arm': argv = [str(binary.with_name('probe-B'))]
            if error == 'scope': kw['env']['HEPTA_UNEXPECTED'] = '1'
            if error == 'binary': gate.expected_sha = '0' * 64
            with self.assertRaises(ValueError): gate(argv, **kw)
        self.assertEqual(seen, [])

    def test_uncertain_launch_is_not_replayed(self):
        seen = []
        def uncertain(*a, **k):
            seen.append(a); raise OSError('synthetic uncertain launch')
        gate, binary, kw = self.fixture(uncertain)
        with self.assertRaises(OSError): gate([str(binary)], **kw)
        with self.assertRaises(ValueError): gate([str(binary)], **kw)
        self.assertEqual(len(seen), 1)
        self.assertEqual(gate.calls, 1)

    def test_trace_keeps_phase_values_without_cause_claim(self):
        raw = (b'archive_index steady_stage=metadata_drain elapsed_us=901000 input_rows=0 '
               b'store_lock_wait_us=10 state_us=20 snapshot_read_us=900970 outcome=ok\n'
               b'other stderr retained in the original log\n')
        r = d.trace_receipt(raw, [{'event': 'before_cell', 'unix_ns': 12}])
        self.assertEqual(r['metadata_drain_records'], 1)
        self.assertEqual(r['all_archive_index_trace_lines'][0]['fields']['snapshot_read_us'], 900970)
        self.assertEqual(r['complete_stderr']['sha256'], hashlib.sha256(raw).hexdigest())
        self.assertEqual(r['complete_stderr']['lines'], 2)
        self.assertTrue(r['input_rows_means_pending_records_not_scanned_originals'])
        self.assertFalse(r['content_version_none_directly_observed'])
        self.assertFalse(r['inotify_overflow_directly_observed'])

    def test_no_slow_trace_is_not_fabricated_phase_evidence(self):
        r = d.trace_receipt(b'', [])
        self.assertFalse(r['phase_evidence_available'])
        self.assertEqual(r['metadata_drain_records'], 0)
        self.assertFalse(r['content_version_none_directly_observed'])


if __name__ == '__main__':
    unittest.main()
