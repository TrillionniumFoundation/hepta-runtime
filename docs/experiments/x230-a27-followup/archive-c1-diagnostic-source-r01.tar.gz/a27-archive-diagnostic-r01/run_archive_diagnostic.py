#!/usr/bin/env python3
# Copyright 2026 TrillionniumFoundation; SPDX-License-Identifier: Apache-2.0
"""One fixed A-only, C1 archive diagnostic using the already built r02 binary."""
import argparse
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import shutil
import signal
import subprocess
import sys
import time
from types import SimpleNamespace

sys.dont_write_bytecode = True
DEPENDENCIES = {
    'run_probe.py': '36c5d56cbef8f90487bf95a42830c7761e7dc832e9a03bf9a725f53c1e62a533',
    'prepare_build.py': '1d96666e6c280b93439ed6c5cf40d3cb7ab765a929f71dae7de4ec12c480c816',
    'probe_plan.py': '69b0507835cdc7e37ee0d959e611d45fe5c1c116e510c0cac5e853465594fbe5',
    'resource_sampler.py': 'a9554e63416504428439a6cf3fe1f5b8ede090c2ef856bda3f1add413d06d40a',
    'bundle_manifest.json': 'bc00109b66379ede8ae3979a515999d851df91443de97f09bb86a016051ef277',
}
HEX = re.compile(r'[0-9a-f]{64}\Z')
BUILD_REPORT_SHA = '4ccfc46a0c0ed40b3a15dc9f496cc986ffa5bac9754df9761598a4fff72fafff'
BASELINE_BINARY_SHA = '403b9b4978e398775f177f464c5bad3b6b5537270e8ffd433b7d908af3f84f2a'
PROCESS = {'id': 'size-65536-arm-A', 'rows': 65536, 'arm': 'A',
           'directory': 'size-65536/arm-A', 'cells': 2, 'cell_calls': 16,
           'setup_public_queries': 2}
CELLS = [{'id': f'cell-{i:04d}', 'rows': 65536, 'arm': 'A', 'sequence': i,
          'phase': 'measured', 'kind': kind, 'concurrency': 1, 'block': None,
          'slot': 0, 'calls': 8, 'cold': False, 'case_offset': 0}
         for i, kind in enumerate(('usage', 'history'))]


def need(ok, message):
    if not ok:
        raise ValueError(message)


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def helper_receipts(directory):
    result = {}
    for name, expected in DEPENDENCIES.items():
        path = directory / name
        need(path == path.resolve() and path.is_file(), 'indirect or absent helper')
        body = path.read_bytes()
        need(digest(body) == expected, 'frozen helper changed: ' + name)
        result[name] = {'bytes': len(body), 'sha256': expected}
    return result


def load_runner(directory):
    sys.path.insert(0, str(directory))
    spec = importlib.util.spec_from_file_location('_a27_frozen_archive_runner', directory / 'run_probe.py')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    for name in ('prepare_build', 'probe_plan'):
        need(Path(sys.modules[name].__file__).resolve() == directory / (name + '.py'),
             'unexpected helper import')
    return module


def inotify_limits():
    result = {}
    for name in ('max_queued_events', 'max_user_instances', 'max_user_watches'):
        try:
            text = (Path('/proc/sys/fs/inotify') / name).read_text().strip()
            need(text.isdigit(), 'inotify limit was not an integer')
            result[name] = {'value': int(text), 'read_only': True}
        except (OSError, ValueError) as error:
            result[name] = {'value': None, 'error_type': type(error).__name__,
                            'errno': getattr(error, 'errno', None), 'read_only': True}
    return result


class OneBaselineLaunch:
    """Inject one trace variable after the unchanged helper sanitizes its env."""
    def __init__(self, binary, directory, expected_sha, read_stable, launch=subprocess.Popen):
        self.binary, self.directory = binary, directory
        self.expected_sha, self.read_stable, self.launch = expected_sha, read_stable, launch
        self.calls = 0
        self.receipt = None

    def __call__(self, argv, **kwargs):
        need(self.calls == 0 and argv == [str(self.binary)], 'only one original baseline launch is allowed')
        need(Path(kwargs.get('cwd', '')).absolute() == self.directory, 'unexpected child directory')
        need(kwargs.get('stdin') == subprocess.PIPE and kwargs.get('stdout') == subprocess.PIPE
             and kwargs.get('stderr') is not None and not kwargs.get('shell', False),
             'unexpected child transport')
        env = dict(kwargs['env'])
        hepta = {k: v for k, v in env.items() if k.startswith('HEPTA_')}
        need(hepta == {'HEPTA_A27_ARCHIVE_PROBE_ROOT': str(self.directory / 'fixture'),
                       'HEPTA_A27_ARCHIVE_PROBE_ROWS': '65536'}, 'unexpected probe scope')
        need(env.get('TOKIO_WORKER_THREADS') == '2' and 'RUST_LOG' not in env,
             'unexpected executor or logging configuration')
        need(digest(self.read_stable(self.binary)) == self.expected_sha, 'baseline binary changed before launch')
        env['HEPTA_ARCHIVE_INDEX_TRACE'] = '1'
        kwargs['env'] = env
        self.calls += 1  # Failed or uncertain Popen is never replayed.
        self.receipt = {'launch_attempts': self.calls, 'arm': 'A', 'binary_sha256': self.expected_sha,
                        'trace_variable': 'HEPTA_ARCHIVE_INDEX_TRACE', 'trace_value': '1',
                        'direct_executable_no_wrapper': True, 'requests_retried': 0}
        return self.launch(argv, **kwargs)


def trace_receipt(raw, markers):
    lines = raw.decode('utf-8', errors='strict').splitlines()
    retained = []
    for index, line in enumerate(lines):
        if line.startswith('archive_index '):
            fields = {}
            for token in line[len('archive_index '):].split():
                if '=' in token:
                    key, value = token.split('=', 1)
                    fields[key] = int(value) if value.isdigit() else value
            retained.append({'line': index + 1, 'text': line, 'fields': fields})
    steady = [row for row in retained if row['fields'].get('steady_stage') == 'metadata_drain']
    return {'complete_stderr': {'bytes': len(raw), 'sha256': digest(raw), 'lines': len(lines)},
            'all_archive_index_trace_lines': retained, 'metadata_drain_records': len(steady),
            'phase_evidence_available': bool(steady), 'cell_time_markers': markers,
            'trace_is_wall_time_not_per_phase_cpu': True, 'only_durations_over_100ms_are_emitted': True,
            'input_rows_means_pending_records_not_scanned_originals': True,
            'ready_and_initial_hot_preparation_are_outside_metadata_drain': True,
            'content_version_none_directly_observed': False, 'inotify_overflow_directly_observed': False,
            'classification': 'phase localization only; no automatic branch or cause attribution'}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--probe-dir', type=Path, required=True)
    parser.add_argument('--build', type=Path, required=True)
    parser.add_argument('--build-report-sha256', required=True)
    parser.add_argument('--baseline-binary-sha256', required=True)
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    probe, build, out = (value.absolute() for value in (args.probe_dir, args.build, args.out))
    need(HEX.fullmatch(args.build_report_sha256) and HEX.fullmatch(args.baseline_binary_sha256),
         'original build and baseline hashes must be explicitly pinned')
    need(args.build_report_sha256 == BUILD_REPORT_SHA and args.baseline_binary_sha256 == BASELINE_BINARY_SHA,
         'only the original failed-r02 baseline and build receipt are accepted')
    need(probe == probe.resolve() and build == build.resolve() and probe.is_dir() and build.is_dir(),
         'indirect or missing input directory')
    need(out.parent == build.parent and out.parent == out.parent.resolve() and not os.path.lexists(out)
         and not out.is_relative_to(probe) and not probe.is_relative_to(out)
         and not out.is_relative_to(build) and not build.is_relative_to(out),
         'output must be a fresh sibling of the isolated build')
    helpers = helper_receipts(probe)
    runner = load_runner(probe)
    need(digest(runner.read_stable(build / 'build.json')) == args.build_report_sha256,
         'original r02 build receipt changed')
    before = {'helpers': helpers, 'bundle': runner.bundle_inputs(), 'build': runner.build_inputs(build)}
    need(before['build']['binaries']['A']['sha256'] == args.baseline_binary_sha256,
         'original baseline binary pin differs from its build receipt')
    need(shutil.disk_usage(out.parent).free >= 2 * 1024 ** 3, 'less than fixed 2 GiB fixture reserve')
    source = Path(__file__).read_bytes()
    resources = runner.load_sampler()
    plan = {'schema': 'hepta-a27-archive-c1-phase-diagnostic-plan/v1', 'process': PROCESS, 'cells': CELLS,
            'source_sha256': digest(source), 'helper_sources': helpers,
            'build_report_sha256': args.build_report_sha256, 'baseline_binary_sha256': args.baseline_binary_sha256,
            'fresh_fixture_rows': 65536, 'hot_copies': 512, 'total_public_queries': 18,
            'setup_public_queries': 2, 'usage_cell_queries': 8, 'history_cell_queries': 8,
            'public_deadline_ms': 3000, 'deadline_reset': False, 'actual_metadata_closure_limit': 8,
            'concurrency': 1, 'settle_seconds': 8, 'setup_watchdog_seconds': 240,
            'each_cell_watchdog_seconds': 62, 'final_verification_watchdog_seconds': 225,
            'suggested_outer_job_budget_seconds': 660, 'outer_timeout_does_not_prove_cleanup': True,
            'trace': {'HEPTA_ARCHIVE_INDEX_TRACE': '1'}, 'runtime_rebuild': False,
            'automatic_retry': False, 'candidate_arm_run': False, 'relative_comparison': False,
            'runtime_adopted': False, 'network_calls': 0,
            'scope': 'fixed existing-baseline phase localization; instrumented durations are not a performance comparison',
            'branch_or_overflow_directly_observed': False,
            'blocked_io': 'original child wait/reader join/kernel I/O can outlast watchdogs; retain incomplete evidence'}
    out.mkdir(mode=0o700)
    (out / 'cells').mkdir(mode=0o700)
    runner.write_new(out / 'plan.json', runner.canonical(plan) + b'\n')
    runner.write_new(out / 'inputs-before.json', runner.canonical(before) + b'\n')
    runner.write_new(out / 'run_archive_diagnostic.py', source)
    runner.write_new(out / 'inotify-limits-before.json', runner.canonical(inotify_limits()) + b'\n')
    launch = OneBaselineLaunch(build / 'probe-A', out / PROCESS['directory'],
                               args.baseline_binary_sha256, runner.read_stable)
    # Rebind this imported helper's two subprocess attributes only; the standard
    # subprocess module is unchanged and the original Popen owns the actual A.
    runner.subprocess = SimpleNamespace(Popen=launch, PIPE=subprocess.PIPE)
    child = runner.OwnedProbe(build, out, PROCESS, resources)
    report = {'schema': 'hepta-a27-archive-c1-phase-diagnostic/v1', 'plan_sha256': digest(runner.canonical(plan) + b'\n'),
              'diagnostic_completed': False, 'runtime_adopted': False, 'relative_comparison': False,
              'cells': [{'id': c['id'], 'status': 'not_run'} for c in CELLS], 'errors': [],
              'original_build_binary': before['build']['binaries']['A'], 'new_fixture_only': True}
    markers, requested = [], {'closing': False, 'signals': 0}
    def interrupted(_signal, _frame):
        requested['signals'] += 1
        if not requested['closing']:
            raise KeyboardInterrupt('diagnostic interrupted; no query or process replay')
    previous = {sig: signal.signal(sig, interrupted) for sig in (signal.SIGINT, signal.SIGTERM)}
    normal = False
    try:
        child.start()
        time.sleep(8)
        for spec, status in zip(CELLS, report['cells']):
            status['status'] = 'started'
            markers.append({'cell': spec['id'], 'event': 'before_cell', 'unix_ns': time.time_ns()})
            try:
                check = child.cell(spec)
            finally:
                markers.append({'cell': spec['id'], 'event': 'after_cell', 'unix_ns': time.time_ns()})
            status.update(status='completed', passed=check['passed'])
        normal = True
    except BaseException as error:
        report['errors'].append({'phase': 'execution', 'type': type(error).__name__, 'message': str(error)})
    finally:
        requested['closing'] = True
        try:
            report['process'] = child.finish(normal=normal)
        except BaseException as error:
            report['errors'].append({'phase': 'owned_child_finish', 'type': type(error).__name__, 'message': str(error)})
        report['launch'] = launch.receipt
        report['signals_received'] = requested['signals']
        runner.write_new(out / 'cell-time-markers.json', runner.canonical(markers) + b'\n')
        try:
            after = {'helpers': helper_receipts(probe), 'bundle': runner.bundle_inputs(), 'build': runner.build_inputs(build)}
            runner.write_new(out / 'inputs-after.json', runner.canonical(after) + b'\n')
            report['inputs_unchanged'] = (after == before and Path(__file__).read_bytes() == source)
        except BaseException as error:
            report['inputs_unchanged'] = False
            report['errors'].append({'phase': 'input_fence', 'type': type(error).__name__, 'message': str(error)})
        try:
            report['trace'] = trace_receipt(runner.read_stable(child.directory / 'stderr.log'), markers)
        except BaseException as error:
            report['errors'].append({'phase': 'trace_capture', 'type': type(error).__name__, 'message': str(error)})
        runner.write_new(out / 'inotify-limits-after.json', runner.canonical(inotify_limits()) + b'\n')
        report['diagnostic_completed'] = (normal and not report['errors'] and report['inputs_unchanged']
            and launch.calls == 1 and report.get('process', {}).get('passed') is True
            and all(c.get('status') == 'completed' and c.get('passed') is True for c in report['cells']))
        try:
            report['artifact_hashes'] = runner.evidence_hashes(out)
        except BaseException as error:
            report['diagnostic_completed'] = False
            report['errors'].append({'phase': 'evidence_hashes', 'type': type(error).__name__, 'message': str(error)})
        runner.write_new(out / 'diagnostic-report.json', runner.canonical(report) + b'\n')
        for sig, handler in previous.items():
            signal.signal(sig, handler)
    print(json.dumps({'diagnostic_completed': report['diagnostic_completed'],
                      'completed_cells': sum(c['status'] == 'completed' for c in report['cells']),
                      'metadata_drain_records': report.get('trace', {}).get('metadata_drain_records'),
                      'runtime_adopted': False, 'relative_comparison': False}))
    return 0 if report['diagnostic_completed'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
