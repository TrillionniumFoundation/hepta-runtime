#!/usr/bin/env python3
# Copyright 2026 Muvon Un Limited
# Copyright 2026 TrillionniumFoundation
# SPDX-License-Identifier: Apache-2.0
"""Run the single predeclared A26/A27 archive-query experiment, with no retries."""
import argparse
import importlib.util
import json
import os
from pathlib import Path
import queue
import shutil
import signal
import subprocess
import sys
import threading
import time

sys.dont_write_bytecode = True
from prepare_build import (AUDIT, BASE_MAP_SHA, PROBE, SAMPLER_SHA, canonical,
                           compiler_binary, need, read_stable, remove_candidate_delta,
                           sha, source_map, write_new)
from probe_plan import (FINAL_WATCHDOG_SECONDS, MAX_STDOUT_LINE_BYTES, SETTLE_SECONDS,
                        SETUP_WATCHDOG_SECONDS, SIZES, command_for, plan, validate_cell)

HERE = Path(__file__).resolve().parent


def file_receipt(path):
    raw = read_stable(path)
    return {"sha256": sha(raw), "bytes": len(raw)}


def bundle_inputs():
    manifest_path = HERE / "bundle_manifest.json"
    raw = read_stable(manifest_path)
    manifest = json.loads(raw)
    need(manifest.get("schema") == "hepta-a27-archive-probe-bundle/v1"
         and manifest.get("experiment_revision") == "r02", "bundle schema or revision differs")
    files = manifest.get("files", {})
    need(files and "probe/run_probe.py" in files and "probe/probe_plan.py" in files,
         "bundle manifest lacks required sources")
    actual = {}
    for relative, expected in files.items():
        path = HERE.parent / relative
        need(path.resolve().is_relative_to(HERE.parent) and not path.is_symlink(), "bundle path escapes")
        actual[relative] = file_receipt(path)
        need(actual[relative] == expected, "frozen bundle member differs: " + relative)
    return {"manifest_sha256": sha(raw), "files": actual}


def build_inputs(build_dir):
    raw = read_stable(build_dir / "build.json")
    report = json.loads(raw)
    need(report.get("schema") == "hepta-a27-archive-probe-build/v1"
         and report.get("experiment_revision") == "r02"
         and report.get("passed") is True and report.get("build_requested") is True
         and report.get("production_delta_verified") is True
         and report.get("source_original_unchanged") is True
         and report.get("base_source_map_sha256") == BASE_MAP_SHA
         and report.get("resource_sampler_sha256") == SAMPLER_SHA
         and report.get("runtime_difference_only") == AUDIT
         and report.get("target_separation", {}).get("no_shared_regular_inodes") is True,
         "probe build did not pass exact source/input gates")
    need(set(report["arms"]) == {"A", "B"}, "both probe arms required")
    need([row.get("name") for row in report["stages"]]
         == ["format-A", "build-A", "format-B", "build-B"], "build stages differ")
    logs = {}
    for stage in report["stages"]:
        need(stage.get("returncode") == 0 and stage.get("sigint_forwarded") is False,
             "probe build stage failed or was interrupted")
        for stream in ("stdout", "stderr"):
            entry = stage[stream]
            need(Path(entry["file"]).name == entry["file"], "build log path is indirect")
            logs[entry["file"]] = file_receipt(build_dir / entry["file"])
            need(logs[entry["file"]] == {key: entry[key] for key in ("sha256", "bytes")},
                 "build log changed")
    maps, binaries = {}, {}
    for arm in ("A", "B"):
        detail = report["arms"][arm]
        need(detail["source"] == "source-" + arm, "arm source path differs")
        root = build_dir / detail["source"]
        maps[arm] = source_map(root)
        need(len(maps[arm]) == 157 and maps[arm] == detail["source_tested"]
             == detail["source_after"] and PROBE in maps[arm], "compiled source map differs")
        need(detail["source_before_format"][PROBE] == report["probe_source_sha256"]
             == sha(read_stable(HERE / "a27_archive_probe.rs")), "common probe source differs")
        binary = detail["binary"]
        need(binary["file"] == "probe-" + arm and binary["copied_immediately_after_build"] is True,
             "arm copied-binary identity differs")
        path = build_dir / binary["file"]
        need(os.access(path, os.X_OK), "probe binary is not executable")
        binaries[arm] = file_receipt(path)
        need(binaries[arm] == {key: binary[key] for key in ("sha256", "bytes")}, "probe binary changed")
        artifact = compiler_binary(build_dir / ("build-" + arm + ".stdout.log"), root)
        need(str(artifact) == binary["compiler_executable"], "compiler artifact binding differs")
    need(set(maps["A"]) == set(maps["B"])
         and [name for name in maps["A"] if maps["A"][name] != maps["B"][name]] == [AUDIT],
         "arms differ outside the accepted production file")
    need(remove_candidate_delta(read_stable(build_dir / "source-B" / AUDIT).decode())
         == read_stable(build_dir / "source-A" / AUDIT).decode(), "production delta expanded")
    return {"build_report_sha256": sha(raw), "experiment_revision": "r02", "source_maps": maps,
            "source_map_sha256": {arm: sha(canonical(value)) for arm, value in maps.items()},
            "binaries": binaries, "build_logs": logs}


def load_sampler():
    need(sha(read_stable(HERE / "resource_sampler.py")) == SAMPLER_SHA, "sampler changed")
    spec = importlib.util.spec_from_file_location("a27_archive_frozen_resources", HERE / "resource_sampler.py")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module.Resources


def brief_resources(value):
    # The complete final snapshot and every raw error row are saved separately.
    return {key: item for key, item in value.items()
            if key not in ("timeline", "errors", "observed_master_generations", "error_log")}


class OwnedProbe:
    def __init__(self, build_dir, out, spec, resources):
        self.build_dir, self.out, self.spec, self.resources_type = build_dir, out, spec, resources
        self.directory = out / spec["directory"]
        self.directory.mkdir(parents=True, mode=0o700)
        self.proc = None
        self.sampler = None
        self.sampler_final = None
        self.events = queue.Queue(maxsize=512)
        self.reader = None
        self.stderr = None
        self.commands = None
        self.reader_errors = []
        self.events_read = 0
        self.sigint_forwarded = False
        self.sigint_attempted = False
        self.interrupt_count = 0
        self.setup_events = []
        self.teardown_events = []
        self.ready = None
        self.finished = False
        self.cleanup_started = False
        self.receipt = {"spec": spec, "status": "not_started", "passed": False}

    def start(self):
        self.stderr = (self.directory / "stderr.log").open("xb")
        self.commands = (self.directory / "commands.jsonl").open("xb")
        env = {key: value for key, value in os.environ.items()
               if not key.startswith("HEPTA_") and key not in
               ("SSH_AUTH_SOCK", "RUSTFLAGS", "CARGO_ENCODED_RUSTFLAGS", "RUST_LOG")}
        env.update(HEPTA_A27_ARCHIVE_PROBE_ROOT=str(self.directory / "fixture"),
                   HEPTA_A27_ARCHIVE_PROBE_ROWS=str(self.spec["rows"]),
                   TOKIO_WORKER_THREADS="2", RUST_BACKTRACE="0")
        self.proc = subprocess.Popen([str(self.build_dir / ("probe-" + self.spec["arm"]))],
                                     stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                                     stderr=self.stderr, env=env, cwd=self.directory)
        self.receipt.update(status="started", pid=self.proc.pid)
        self.reader = threading.Thread(target=self.read_stdout, daemon=True)
        self.reader.start()
        self.sampler = self.resources_type(self.proc.pid, self.directory / "resource-errors.jsonl")
        deadline = time.monotonic() + SETUP_WATCHDOG_SECONDS
        while self.ready is None:
            row = self.next_event(deadline)
            self.setup_events.append(row)
            need(row.get("event") != "setup_failed", "probe fixture/index setup failed")
            if row.get("event") == "ready":
                self.ready = row
        kinds = [row.get("kind") for row in self.setup_events if row.get("event") == "setup_query"]
        need(kinds == ["usage", "history"] and all(row.get("passed") is True for row in
             self.setup_events if row.get("event") == "setup_query"), "both setup queries required")
        need([row.get("event") for row in self.setup_events]
             == ["plan", "seeded", "index_trigger", "index_ready", "setup_query", "setup_query", "ready"],
             "setup event order differs")
        head = self.setup_events[0]
        need(head.get("query_deadline_ms") == 3000 and head.get("actual_query_closure_limit") == 8
             and head.get("experiment_revision") == "r02" and head.get("fixed_cell_calls") == 8
             and head.get("maximum_cell_calls_per_process") == 1100
             and head.get("public_query_retries") == 0 and head.get("rows") == self.spec["rows"],
             "probe API/fixture contract differs")
        need(self.ready.get("rows") == self.spec["rows"] and self.ready.get("setup_public_queries") == 2
             and len(self.ready.get("input_sha256", "")) == 64, "fixture-ready binding missing")
        self.receipt.update(status="ready", ready=self.ready)

    def read_stdout(self):
        try:
            with (self.directory / "stdout.jsonl").open("xb") as log:
                while True:
                    raw = self.proc.stdout.readline(MAX_STDOUT_LINE_BYTES + 1)
                    if not raw:
                        break
                    log.write(raw)
                    log.flush()
                    try:
                        need(len(raw) <= MAX_STDOUT_LINE_BYTES and raw.endswith(b"\n"),
                             "stdout line exceeds bound or is incomplete")
                        row = json.loads(raw)
                        need(isinstance(row, dict), "stdout row is not an object")
                        self.events.put_nowait(row)
                        self.events_read += 1
                    except Exception as error:
                        self.reader_errors.append(type(error).__name__ + ": " + str(error))
                log.flush()
                os.fsync(log.fileno())
        except Exception as error:
            self.reader_errors.append(type(error).__name__ + ": " + str(error))
        finally:
            self.proc.stdout.close()

    def next_event(self, deadline):
        while True:
            need(not self.reader_errors, "stdout reader failed: " + str(self.reader_errors[:1]))
            remaining = deadline - time.monotonic()
            need(remaining > 0, "owned probe event watchdog elapsed")
            try:
                return self.events.get(timeout=min(1, remaining))
            except queue.Empty:
                if self.proc.poll() is not None and not self.reader.is_alive():
                    try:
                        return self.events.get_nowait()
                    except queue.Empty:
                        raise ValueError("probe EOF before expected event") from None

    def send(self, value):
        raw = canonical(value) + b"\n"
        self.commands.write(raw)
        self.commands.flush()
        os.fsync(self.commands.fileno())
        self.proc.stdin.write(raw)
        self.proc.stdin.flush()

    def cell(self, spec):
        before = brief_resources(self.sampler.snapshot())
        self.send(command_for(spec))
        deadline = time.monotonic() + 30 + 4 * (spec["calls"] // spec["concurrency"])
        events = []
        error = None
        try:
            while not events or events[-1].get("event") != "cell_complete":
                events.append(self.next_event(deadline))
                need(len(events) <= spec["calls"] + 16, "cell event bound exceeded")
        except BaseException as caught:
            error = {"type": type(caught).__name__, "message": str(caught)}
            raise
        finally:
            check = validate_cell(events, spec)
            value = {"schema": "hepta-a27-archive-probe-cell/v1", "spec": spec,
                     "events": events, "check": check, "driver_error": error,
                     "resource_before": before, "resource_after": brief_resources(self.sampler.snapshot())}
            write_new(self.out / "cells" / (spec["id"] + ".json"), canonical(value) + b"\n")
        need(check["passed"], "cell failed; every following cell is cancelled")
        return check

    def interrupt_once(self):
        if self.proc is not None and self.proc.poll() is None and not self.sigint_attempted:
            self.sigint_attempted = True
            try:
                self.proc.send_signal(signal.SIGINT)
                self.sigint_forwarded = True
            except ProcessLookupError:
                # The retained Popen may have exited between poll and send.
                pass

    def stop_sampler(self):
        if self.sampler is None or self.sampler_final is not None:
            return
        final = self.sampler.stop(join_timeout=5)
        # Avoid making a fresh integrity receipt while a live writer owns the log.
        complete = (final.get("sampler_thread_stopped") is True
                    and final.get("error_log_finalized") is True
                    and final.get("error_log_complete") is True
                    and final.get("error_log_failure") is None)
        error_receipt = None
        if complete:
            raw = read_stable(self.directory / "resource-errors.jsonl")
            rows = [json.loads(line) for line in raw.splitlines()]
            error_receipt = {"bytes": len(raw), "sha256": sha(raw), "rows": len(rows)}
            complete = (len(rows) == final.get("error_count") == final.get("error_log_rows_written")
                        and len(raw) == final.get("error_log_bytes") and sha(raw) == final.get("error_log_sha256")
                        and [row.get("sequence") for row in rows] == list(range(len(rows))))
        final["error_log"] = "resource-errors.jsonl"
        self.sampler_final = {"snapshot": final, "error_log_receipt": error_receipt,
                              "complete_error_log_verified": complete,
                              "scope_ends_before_final_original_verification": True}
        write_new(self.directory / "resource-final.json", canonical(self.sampler_final) + b"\n")

    def finish(self, normal):
        if self.finished:
            return self.receipt
        cleanup_errors = []
        if not self.cleanup_started:
            self.cleanup_started = True
            try:
                write_new(self.directory / "cleanup-started.json", canonical({
                    "schema": "hepta-a27-archive-probe-cleanup-started/v1", "process": self.spec["id"],
                    "normal_requested": normal, "owned_pid": None if self.proc is None else self.proc.pid,
                    "complete": False, "waits_for_actual_owned_child_and_stdout_reader": True,
                    "does_not_prove_cleanup_completed": True}) + b"\n")
            except BaseException as error:
                cleanup_errors.append({"phase": "cleanup_start_receipt", "type": type(error).__name__, "message": str(error)})
        try:
            self.stop_sampler()
        except BaseException as error:
            cleanup_errors.append({"phase": "sampler_stop", "type": type(error).__name__, "message": str(error)})
            normal = False
        try:
            if self.proc is not None and self.proc.poll() is None:
                if normal:
                    self.send({"command": "stop"})
                    deadline = time.monotonic() + FINAL_WATCHDOG_SECONDS
                    while not self.teardown_events or self.teardown_events[-1].get("event") != "complete":
                        self.teardown_events.append(self.next_event(deadline))
                        need(len(self.teardown_events) <= 4, "unexpected teardown events")
                else:
                    self.interrupt_once()
        except BaseException as error:
            cleanup_errors.append({"phase": "probe_stop", "type": type(error).__name__, "message": str(error)})
            try:
                self.interrupt_once()
            except BaseException as caught:
                cleanup_errors.append({"phase": "owned_sigint", "type": type(caught).__name__, "message": str(caught)})
        if self.proc is not None:
            if self.proc.stdin is not None:
                try:
                    self.proc.stdin.close()
                except (BrokenPipeError, OSError) as error:
                    cleanup_errors.append({"phase": "stdin_close", "type": type(error).__name__, "message": str(error)})
            while True:
                try:
                    code = self.proc.wait()
                    break
                except KeyboardInterrupt:
                    self.interrupt_count += 1
                    self.interrupt_once()
            if self.reader is not None:
                self.reader.join()
        else:
            code = None
        while not self.events.empty():
            self.teardown_events.append(self.events.get_nowait())
        for stream in (self.stderr, self.commands):
            if stream is not None:
                try:
                    stream.flush()
                    os.fsync(stream.fileno())
                except (OSError, ValueError) as error:
                    cleanup_errors.append({"phase": "log_close", "type": type(error).__name__, "message": str(error)})
                finally:
                    stream.close()
        completions = [row for row in self.teardown_events if row.get("event") == "complete"]
        complete = completions[0] if len(completions) == 1 else None
        expected = self.spec
        matched = (complete is not None and self.ready is not None
                   and complete.get("passed") is True and complete.get("originals_unchanged") is True
                   and complete.get("original_input_sha256") == complete.get("final_input_sha256")
                   == self.ready.get("input_sha256")
                   and complete.get("rows") == expected["rows"] and complete.get("cells") == expected["cells"]
                   and complete.get("cell_calls") == expected["cell_calls"])
        self.receipt.update(status="finished", returncode=code, setup_events=self.setup_events,
                            teardown_events=self.teardown_events, cleanup_errors=cleanup_errors,
                            stdout_reader_errors=self.reader_errors, stdout_events_read=self.events_read,
                            sigint_attempted=self.sigint_attempted, sigint_forwarded=self.sigint_forwarded,
                            interrupt_count=self.interrupt_count,
                            full_expected_work_completed=matched,
                            resources=self.sampler_final,
                            passed=(code == 0 and matched and not cleanup_errors and not self.reader_errors
                                    and not self.sigint_forwarded and self.sampler_final is not None
                                    and self.sampler_final["complete_error_log_verified"]))
        self.finished = True
        write_new(self.directory / "process.json", canonical(self.receipt) + b"\n")
        return self.receipt


def evidence_hashes(out):
    result = {}
    for path in out.rglob("*"):
        if "fixture" in path.relative_to(out).parts or path.name == "series.json":
            continue
        need(not path.is_symlink(), "evidence contains symlink")
        if path.is_file():
            result[path.relative_to(out).as_posix()] = file_receipt(path)
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--build", type=Path, required=True, help="Successful isolated prepare_build output")
    parser.add_argument("--out", type=Path, required=True, help="New experiment directory; never a runtime state root")
    args = parser.parse_args()
    build_dir, out = args.build.absolute(), args.out.absolute()
    need(build_dir == build_dir.resolve() and build_dir.is_dir(), "build directory is indirect")
    need(out.parent == out.parent.resolve() and out.parent.is_dir() and not os.path.lexists(out),
         "experiment output must be fresh under an existing direct parent")
    need(not out.is_relative_to(build_dir) and not build_dir.is_relative_to(out), "output overlaps build tree")
    declared = plan()
    before = {"bundle": bundle_inputs(), "build": build_inputs(build_dir)}
    need(shutil.disk_usage(out.parent).free >= declared["estimated_fixture_reserve_bytes"],
         "less than fixed 2 GiB fixture/index reserve")
    resources = load_sampler()
    out.mkdir(mode=0o700)
    write_new(out / "plan.json", canonical(declared) + b"\n")
    write_new(out / "inputs-before.json", canonical(before) + b"\n")
    series = {"schema": "hepta-a27-archive-probe-series/v1", "experiment_revision": "r02",
              "plan_sha256": sha(canonical(declared) + b"\n"),
              "runtime_qualified": False, "adopted": False, "automatic_retries": 0,
              "cells": [{"id": row["id"], "status": "not_run", "passed": False} for row in declared["cells"]],
              "processes": [], "errors": [], "complete": False, "passed": False}
    owned = []
    started = time.monotonic()
    cell_lookup = {row["id"]: row for row in series["cells"]}
    try:
        for rows in SIZES:
            pair = {}
            for arm in ("A", "B"):
                spec = next(row for row in declared["processes"] if row["rows"] == rows and row["arm"] == arm)
                child = OwnedProbe(build_dir, out, spec, resources)
                owned.append(child)
                pair[arm] = child
                child.start()
            need(pair["A"].ready["input_sha256"] == pair["B"].ready["input_sha256"],
                 "two arm fixtures differ")
            # One fixed quiet interval, never an adaptive retry or cherry-picked start.
            time.sleep(SETTLE_SECONDS)
            for spec in (row for row in declared["cells"] if row["rows"] == rows):
                status = cell_lookup[spec["id"]]
                status.update(status="started", receipt="cells/" + spec["id"] + ".json")
                result = pair[spec["arm"]].cell(spec)
                status.update(status="completed", passed=result["passed"], complete=result["complete"])
            results = [pair[arm].finish(normal=True) for arm in ("A", "B")]
            need(all(row["passed"] for row in results), "size pair shutdown/original/resource check failed")
        series["complete"] = True
    except BaseException as error:
        series["errors"].append({"type": type(error).__name__, "message": str(error)})
    finally:
        for child in owned:
            try:
                series["processes"].append(child.finish(normal=False))
            except BaseException as error:
                series["errors"].append({"phase": "owned_child_cleanup", "process": child.spec["id"],
                                         "type": type(error).__name__, "message": str(error)})
        try:
            after = {"bundle": bundle_inputs(), "build": build_inputs(build_dir)}
            write_new(out / "inputs-after.json", canonical(after) + b"\n")
            series["inputs_unchanged"] = after == before
        except BaseException as error:
            series["inputs_unchanged"] = False
            series["errors"].append({"phase": "final_inputs", "type": type(error).__name__, "message": str(error)})
        series["seconds_including_setup_and_teardown"] = time.monotonic() - started
        series["passed"] = (series["complete"] and not series["errors"] and series["inputs_unchanged"]
                            and len(series["processes"]) == 4
                            and all(row["passed"] for row in series["processes"])
                            and len(series["cells"]) == 536
                            and all(row["passed"] and row["status"] == "completed" for row in series["cells"]))
        try:
            series["artifact_hashes"] = evidence_hashes(out)
        except BaseException as error:
            series["passed"] = False
            series["errors"].append({"phase": "artifact_hashes", "type": type(error).__name__, "message": str(error)})
        write_new(out / "series.json", canonical(series) + b"\n")
    print(json.dumps({"schema": series["schema"], "passed": series["passed"],
                      "completed_cells": sum(row["status"] == "completed" for row in series["cells"]),
                      "errors": series["errors"], "output": str(out)}))
    return 0 if series["passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
