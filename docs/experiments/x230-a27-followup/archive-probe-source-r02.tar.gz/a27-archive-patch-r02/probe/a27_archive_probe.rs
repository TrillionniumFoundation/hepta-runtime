// Copyright 2026 Muvon Un Limited
// Copyright 2026 TrillionniumFoundation
// SPDX-License-Identifier: Apache-2.0
//! Isolated synthetic archive queries through the unchanged public async APIs.
//! Installed only in separate probe checkouts, never in the runtime candidate.
use super::*;
use std::os::unix::fs::PermissionsExt;
use std::path::PathBuf;
use tokio::io::{AsyncBufReadExt, BufReader};

const SETUP_SECONDS: u64 = 180;
const HOT_ROWS: usize = 512;
const MAX_CELLS: usize = 160;
const MAX_CELL_CALLS: usize = 1_100;

#[derive(Clone, Copy, Deserialize, Serialize, PartialEq, Eq)]
#[serde(rename_all = "snake_case")]
enum Kind {
	Usage,
	History,
}

#[derive(Deserialize)]
#[serde(tag = "command", rename_all = "snake_case", deny_unknown_fields)]
enum Command {
	Cell {
		sequence: usize,
		phase: String,
		kind: Kind,
		concurrency: usize,
		calls: usize,
		cold: bool,
		case_offset: usize,
	},
	Stop,
}

struct Fixture {
	root: PathBuf,
	rows: usize,
	archive: Archive,
	_slot: Arc<Slot>,
	input_sha256: String,
	usage_oracle: Vec<Value>,
	history_oracle: Vec<Value>,
}

fn ensure(value: bool, message: &str) -> Result<()> {
	if !value {
		bail!("{message}");
	}
	Ok(())
}

fn emit(value: Value) -> Result<()> {
	let mut out = std::io::stdout().lock();
	serde_json::to_writer(&mut out, &value)?;
	writeln!(out)?;
	out.flush()?;
	Ok(())
}

fn digest(bytes: &[u8]) -> String {
	ring::digest::digest(&ring::digest::SHA256, bytes)
		.as_ref()
		.iter()
		.map(|byte| format!("{byte:02x}"))
		.collect()
}

fn owner(number: usize) -> String {
	["a", "b", "c", "d"][number].repeat(64)
}

fn fixture_record(number: usize) -> Record {
	let state = match (number / 16) % 3 {
		0 => DurableState::Unknown,
		1 => DurableState::Completed,
		_ => DurableState::Failed,
	};
	Record {
		request_id: format!("{:02x}{:062x}", number % 256, number + 1),
		owner: owner(number % 4),
		tool_name: ["host_list", "host_health", "file_info", "effective_config"]
			[(number / 4) % 4]
			.to_owned(),
		state,
		accepted_unix_ms: 1_000_000 + number as u128,
		elapsed_ms: (state != DurableState::Unknown).then_some(1 + (number % 1000) as u64),
	}
}

fn write_fixture(directory: &File, record: &Record) -> Result<()> {
	let bytes = serde_json::to_vec(record)?;
	ensure(bytes.len() <= MAX_RECORD_BYTES, "synthetic receipt size exceeded")?;
	let mut file = open_at(
		directory,
		&format!("{}.json", record.request_id),
		libc::O_WRONLY | libc::O_CREAT | libc::O_EXCL,
		0o600,
	)?;
	file.write_all(&bytes)?;
	validate_file(&file)
}

fn fixture_digest(archive: &Archive, rows: usize, deadline: Instant) -> Result<String> {
	let mut count = 0usize;
	archive.walk(|_, filename, _| {
		ensure(Instant::now() < deadline, "fixture verification budget exceeded")?;
		ensure(filename.len() == 69 && filename.ends_with(".json"), "unexpected fixture name")?;
		count += 1;
		Ok(())
	})?;
	ensure(count == rows, "fixture original file set changed")?;
	let mut hash = ring::digest::Context::new(&ring::digest::SHA256);
	for number in 0..rows {
		ensure(Instant::now() < deadline, "fixture verification budget exceeded")?;
		let record = fixture_record(number);
		let filename = format!("{}.json", record.request_id);
		let directory = archive.directory_for_existing(&filename)?;
		let before = stamp_at(directory, &filename)?;
		let mut file = open_at(directory, &filename, libc::O_RDONLY | libc::O_NONBLOCK, 0)?;
		validate_file(&file)?;
		let mut bytes = Vec::new();
		Read::by_ref(&mut file)
			.take((MAX_RECORD_BYTES + 1) as u64)
			.read_to_end(&mut bytes)?;
		ensure(bytes == serde_json::to_vec(&record)?, "fixture original bytes changed")?;
		ensure(stamp_at(directory, &filename)? == before, "fixture original stamp changed")?;
		archive.fence_record(&filename, directory)?;
		hash.update(filename.as_bytes());
		hash.update(&(bytes.len() as u64).to_be_bytes());
		hash.update(&bytes);
	}
	archive.fence_at(archive.root())?;
	Ok(hash.finish().as_ref().iter().map(|byte| format!("{byte:02x}")).collect())
}

fn prepare(root: PathBuf, rows: usize) -> Result<Fixture> {
	let started = Instant::now();
	let deadline = started + Duration::from_secs(SETUP_SECONDS);
	ensure(root.is_absolute() && !root.exists(), "fixture root must be new and absolute")?;
	std::fs::create_dir(&root)?;
	std::fs::set_permissions(&root, std::fs::Permissions::from_mode(0o700))?;
	ensure(root.canonicalize()? == root, "fixture root must not traverse symlinks")?;
	let config: crate::mcp::runtime::RuntimeConfig = serde_json::from_value(json!({
		"state_dir": root,
		"hosts": {"synthetic": {"ssh_target": "unused.invalid", "remote_state_dir": "/unused"}}
	}))?;
	crate::mcp::runtime::init_runtime(config)?;
	let archive = {
		let _guard = store_lock()?;
		let hot = open_store(&root)?;
		let archive = open_archive(&root)?;
		archive.initialize_shards()?;
		for number in 0..rows {
			ensure(Instant::now() < deadline, "fixture seed exceeded setup budget")?;
			let record = fixture_record(number);
			let filename = format!("{}.json", record.request_id);
			write_fixture(archive.directory_for_write(&filename, false)?, &record)?;
			if number >= rows - HOT_ROWS {
				write_fixture(&hot, &record)?;
			}
		}
		// These synthetic originals are never a durability experiment. Whole
		// directory sync is outside timing; no per-receipt ACK barrier is claimed.
		for number in 0..256 {
			let filename = format!("{}.json", fixture_record(number).request_id);
			archive.directory_for_existing(&filename)?.sync_all()?;
		}
		hot.sync_all()?;
		archive.root().sync_all()?;
		hot_snapshot(&root, &hot)?;
		archive
	};
	emit(json!({"event":"seeded","rows":rows,"hot_rows":HOT_ROWS,
		"seconds":started.elapsed().as_secs_f64(),"durability_experiment":false}))?;
	let slot = slot_at_until(&root, &archive, deadline)?;
	let trigger = ready(&root, &archive, Instant::now() + QUERY_BUDGET);
	let trigger_error = trigger.as_ref().err().map(ToString::to_string);
	if let Some(error) = &trigger_error {
		ensure(
			error.starts_with("archive index preparing")
				|| error == "archive metadata query total deadline exceeded",
			"index setup trigger returned an unexpected error",
		)?;
	}
	emit(json!({"event":"index_trigger","invocations":1,"public_rpc":false,
		"ready_returned":trigger.is_ok(),"error":trigger_error,
		"seconds":started.elapsed().as_secs_f64()}))?;
	loop {
		ensure(Instant::now() < deadline, "index setup exceeded fixed 180 second budget")?;
		let state = slot.state.lock().map_err(|_| anyhow!("probe index state unavailable"))?;
		ensure(!state.failed && !state.retired, "original index worker failed during setup")?;
		let complete = state.database.is_some() && !state.busy && state.pending.is_empty()
			&& state.applied == state.generation;
		drop(state);
		if complete {
			break;
		}
		std::thread::sleep(Duration::from_millis(10));
	}
	emit(json!({"event":"index_ready","seconds":started.elapsed().as_secs_f64(),
		"worker_starts":1,"public_rpc_retries":0,"setup_limit_seconds":SETUP_SECONDS}))?;
	let input_sha256 = fixture_digest(&archive, rows, deadline)?;
	let usage_oracle = (0..12).map(|number| expected(rows, Kind::Usage, number)).collect();
	let history_oracle = (0..12).map(|number| expected(rows, Kind::History, number)).collect();
	ensure(Instant::now() < deadline, "complete fixture verification exceeded setup budget")?;
	Ok(Fixture { root, rows, archive, _slot: slot, input_sha256, usage_oracle, history_oracle })
}

fn history_start(rows: usize, request: usize) -> usize {
	match (request / 4) % 3 {
		0 => 0,
		1 => rows / 8,
		_ => rows / 4 - 16,
	}
}

fn history_params(rows: usize, request: usize) -> RequestHistoryParams {
	let start = history_start(rows, request);
	RequestHistoryParams {
		after_id: (start != 0).then(|| fixture_record(request % 4 + (start - 1) * 4).request_id),
		limit: Some(32),
	}
}

fn expected(rows: usize, kind: Kind, request: usize) -> Value {
	let owner_index = request % 4;
	if kind == Kind::History {
		let start = history_start(rows, request);
		let page: Vec<Value> = (start..(start + 32).min(rows / 4)).map(|number| {
			let record = fixture_record(owner_index + number * 4);
			let state = match record.state {
				DurableState::Unknown => "unknown",
				DurableState::Completed => "completed",
				DurableState::Failed => "failed",
			};
			json!({"request_id":record.request_id,"tool_name":record.tool_name,"state":state,
				"accepted_unix_ms":record.accepted_unix_ms,"elapsed_ms":record.elapsed_ms})
		}).collect();
		let next = if start + page.len() < rows / 4 {
			page.last().map(|row| row["request_id"].clone())
		} else { None };
		return json!({"requests":page,"next_after_id":next,"total":rows/4,
			"archive_retention":"no_automatic_metadata_eviction","history_is_live":true,
			"coverage":"metadata_retained_at_archive_introduction_and_subsequent_admitted_requests",
			"contains_parameters_or_output":false,"automatic_operation_retry":false});
	}
	let mut states = [0u64; 3];
	let mut tools = BTreeMap::<String, u64>::new();
	for number in (owner_index..rows).step_by(4) {
		let record = fixture_record(number);
		let state = match record.state {
			DurableState::Unknown => 0,
			DurableState::Completed => 1,
			DurableState::Failed => 2,
		};
		states[state] += 1;
		*tools.entry(record.tool_name).or_default() += 1;
	}
	json!({"schema":"hepta-private-usage-v1","total_requests":rows/4,
		"completed":states[1],"failed":states[2],"unknown":states[0],"active":0,
		"tool_counts":tools,"first_accepted_unix_ms":1_000_000+owner_index,
		"last_accepted_unix_ms":1_000_000+rows-4+owner_index,
		"retention":"archive_metadata_not_evicted_with_hot_cache",
		"coverage":"metadata_retained_at_archive_introduction_and_subsequent_admitted_requests",
		"semantics":"dispatch_observation_not_transport_delivery_or_business_success",
		"contains_parameters_or_output":false,"scope":"same_verified_credential_or_native_session"})
}

async fn query(rows: usize, kind: Kind, request: usize) -> (usize, u128, Result<String>) {
	let scope = owner(request % 4);
	let params = history_params(rows, request);
	let start = Instant::now();
	let result = match kind {
		Kind::Usage => super::super::usage_stats(&scope, UsageStatsParams::default()).await,
		Kind::History => super::super::archive_history(&scope, params).await,
	};
	(request, start.elapsed().as_nanos(), result)
}

fn process_cpu_ns() -> Result<u128> {
	let mut value = std::mem::MaybeUninit::<libc::timespec>::uninit();
	if unsafe { libc::clock_gettime(libc::CLOCK_PROCESS_CPUTIME_ID, value.as_mut_ptr()) } != 0 {
		return Err(std::io::Error::last_os_error().into());
	}
	let value = unsafe { value.assume_init() };
	ensure(value.tv_sec >= 0 && value.tv_nsec >= 0, "negative process CPU clock")?;
	Ok(value.tv_sec as u128 * 1_000_000_000 + value.tv_nsec as u128)
}

fn clear_hot_cache(root: &Path) -> Result<()> {
	let _guard = store_lock()?;
	let hot = open_store(root)?;
	let stamp = archive_stamp(&hot)?;
	HOT_CACHE.get_or_init(|| Mutex::new(VecDeque::new()))
		.lock().map_err(|_| anyhow!("probe hot cache unavailable"))?
		.retain(|entry| (entry.stamp.device, entry.stamp.inode) != (stamp.device, stamp.inode));
	Ok(())
}

async fn cell(
	fixture: &Arc<Fixture>, sequence: usize, phase: &str, kind: Kind,
	concurrency: usize, calls: usize, cold: bool, case_offset: usize,
) -> Result<bool> {
	let all_started = Instant::now();
	let mut cpu_ns = 0u128;
	let mut wall_ns = 0u128;
	let mut successes = 0usize;
	let mut raw_successes = 0usize;
	let mut latencies = Vec::with_capacity(calls);
	// Oracle construction/serialization and result verification stay outside all
	// query-wave clocks. At most one wave's returned strings is retained.
	let oracle = match kind {
		Kind::Usage => &fixture.usage_oracle,
		Kind::History => &fixture.history_oracle,
	};
	emit(json!({"event":"cell_started","sequence":sequence,"phase":phase,"kind":kind,
		"concurrency":concurrency,"calls":calls,"hot_cache_miss_per_wave":cold,
		"case_offset":case_offset}))?;
	for start in (0..calls).step_by(concurrency) {
		if cold {
			let root = fixture.root.clone();
			tokio::task::spawn_blocking(move || clear_hot_cache(&root)).await??;
		}
		let wave_start = Instant::now();
		let cpu_before = process_cpu_ns()?;
		let mut tasks = tokio::task::JoinSet::new();
		for request in start..start + concurrency {
			let rows = fixture.rows;
			let case_index = (request + case_offset) % 12;
			tasks.spawn(async move { (request, query(rows, kind, case_index).await) });
		}
		let mut replies = Vec::with_capacity(concurrency);
		let mut join_errors = Vec::new();
		while let Some(reply) = tasks.join_next().await {
			match reply {
				Ok(reply) => replies.push(reply),
				Err(error) => join_errors.push(error.to_string()),
			}
		}
		// Timeout/caller cancellation must not make still-running closures free.
		// The next wave starts only after all actual query permits are returned.
		let drained = metadata_query_slots()
			.acquire_many_owned(MAX_METADATA_QUERIES as u32).await?;
		drop(drained);
		cpu_ns += process_cpu_ns()?.checked_sub(cpu_before)
			.ok_or_else(|| anyhow!("process CPU clock moved backwards"))?;
		wall_ns += wave_start.elapsed().as_nanos();
		for error in join_errors {
			emit(json!({"event":"query_join_error","sequence":sequence,"wave_start":start,
				"error":error,"passed":false}))?;
		}
		for (request, (case_index, elapsed, reply)) in replies {
			latencies.push(elapsed);
			let (passed, raw_ok, bytes, sha256, error, response_on_failure) = match reply {
				Ok(value) => {
					raw_successes += 1;
					let parsed = serde_json::from_str::<Value>(&value);
					let passed = parsed.as_ref().is_ok_and(|actual| actual == &oracle[case_index]);
					let error = match parsed {
						Err(error) => Some(format!("response JSON: {error}")),
						Ok(_) if !passed => Some("complete response differs from synthetic oracle".to_owned()),
						Ok(_) => None,
					};
					let bytes = value.len();
					let sha256 = digest(value.as_bytes());
					(passed, true, Some(bytes), Some(sha256), error, (!passed).then_some(value))
				}
				Err(error) => (false, false, None, None, Some(error.to_string()), None),
			};
			successes += usize::from(passed);
			emit(json!({"event":"query","sequence":sequence,"request":request,
				"case_index":case_index,"owner_index":case_index%4,"latency_ns":elapsed,"passed":passed,
				"raw_success":raw_ok,"response_bytes":bytes,"response_sha256":sha256,"error":error,
				"response_on_failure":response_on_failure}))?;
		}
	}
	let passed = successes == calls && latencies.len() == calls;
	emit(json!({"event":"cell_complete","sequence":sequence,"phase":phase,"kind":kind,
		"concurrency":concurrency,"calls":calls,"successes":successes,"raw_successes":raw_successes,
		"case_offset":case_offset,
		"failures_or_missing":calls-successes,"latency_rows":latencies.len(),
		"process_cpu_ns_sum_of_query_waves":cpu_ns,"query_wave_wall_ns_sum":wall_ns,
		"cpu_ms_per_all_call":cpu_ns as f64/1_000_000.0/calls as f64,
		"cell_seconds_including_verification":all_started.elapsed().as_secs_f64(),
		"allocation_calls":null,"requested_allocation_bytes":null,"peak_live_heap_bytes":null,
		"allocator_instrumented":false,"hot_cache_miss_per_wave":cold,"passed":passed}))?;
	Ok(passed)
}

pub(crate) async fn run() -> Result<()> {
	let root = PathBuf::from(std::env::var_os("HEPTA_A27_ARCHIVE_PROBE_ROOT")
		.ok_or_else(|| anyhow!("explicit probe root required"))?);
	let rows: usize = std::env::var("HEPTA_A27_ARCHIVE_PROBE_ROWS")?.parse()?;
	ensure([16_384, 65_536].contains(&rows), "only the two declared archive sizes are allowed")?;
	emit(json!({"event":"plan","schema":"hepta-a27-archive-query-probe/v1","rows":rows,
		"experiment_revision":"r02","fixed_cell_calls":8,"maximum_cell_calls_per_process":MAX_CELL_CALLS,
		"hot_rows":HOT_ROWS,"owners":4,"query_deadline_ms":3000,"actual_query_closure_limit":8,
		"setup_limit_seconds":SETUP_SECONDS,"public_query_retries":0,"network_operations":0,
		"clock":"CLOCK_PROCESS_CPUTIME_ID; summed query waves; verification excluded",
		"allocation_measurement":"not collected; allocator and release optimizer unchanged"}))?;
	let prepared = tokio::task::spawn_blocking(move || prepare(root, rows)).await
		.map_err(|error| anyhow!("probe setup worker: {error}"))
		.and_then(|result| result);
	let fixture = match prepared {
		Ok(value) => Arc::new(value),
		Err(error) => {
			emit(json!({"event":"setup_failed","error":error.to_string(),"passed":false}))?;
			bail!("archive probe setup failed; no public query was retried");
		}
	};
	for kind in [Kind::Usage, Kind::History] {
		let (_, elapsed, response) = query(rows, kind, 0).await;
		let oracle = match kind {
			Kind::Usage => &fixture.usage_oracle[0],
			Kind::History => &fixture.history_oracle[0],
		};
		let (passed, error, raw_response) = match response {
			Ok(value) => {
				let parsed = serde_json::from_str::<Value>(&value);
				let passed = parsed.as_ref().is_ok_and(|actual| actual == oracle);
				let error = (!passed).then_some("setup complete response differs from oracle".to_owned());
				(passed, error, Some(value))
			}
			Err(error) => (false, Some(error.to_string()), None),
		};
		emit(json!({"event":"setup_query","kind":kind,"passed":passed,
			"latency_ns":elapsed,"error":error,"raw_response":raw_response}))?;
		ensure(passed, "setup public query failed; no retry is performed")?;
	}
	emit(json!({"event":"ready","rows":rows,"input_sha256":fixture.input_sha256,
		"setup_public_queries":2,"public_query_retries":0}))?;
	let mut input = BufReader::new(tokio::io::stdin()).lines();
	let mut cells = 0usize;
	let mut issued = 0usize;
	let mut stopped = false;
	while let Some(line) = input.next_line().await? {
		ensure(line.len() <= 4096, "probe command exceeds fixed bound")?;
		match serde_json::from_str::<Command>(&line)? {
			Command::Stop => { stopped = true; break; }
			Command::Cell { sequence, phase, kind, concurrency, calls, cold, case_offset } => {
				ensure(sequence == cells, "probe sequence changed")?;
				ensure([1,4,8].contains(&concurrency), "unexpected concurrency")?;
				ensure(calls == 8 && calls % concurrency == 0,
					"unexpected call count")?;
				ensure([0, 4, 8].contains(&case_offset), "unexpected request case offset")?;
				ensure((phase == "measured" && calls == 8 && !cold)
					|| (phase == "warmup" && calls == 8 && !cold && case_offset == 0)
					|| (phase == "cold_guard" && calls == 8 && cold), "unexpected phase")?;
				cells += 1;
				issued += calls;
				ensure(cells <= MAX_CELLS && issued <= MAX_CELL_CALLS, "probe fixed work bound exceeded")?;
				if !cell(&fixture, sequence, &phase, kind, concurrency, calls, cold, case_offset).await? {
					bail!("archive query cell failed; no following cell is accepted");
				}
			}
		}
	}
	ensure(stopped, "probe command stream ended without explicit stop")?;
	let retained = fixture.clone();
	let final_hash = tokio::task::spawn_blocking(move ||
		fixture_digest(&retained.archive, retained.rows,
			Instant::now() + Duration::from_secs(SETUP_SECONDS))).await??;
	let unchanged = final_hash == fixture.input_sha256;
	emit(json!({"event":"complete","cells":cells,"cell_calls":issued,"rows":rows,
		"original_input_sha256":fixture.input_sha256,"final_input_sha256":final_hash,
		"originals_unchanged":unchanged,"public_query_retries":0,"passed":unchanged}))?;
	ensure(unchanged, "synthetic originals changed")
}
