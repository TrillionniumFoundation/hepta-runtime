#!/usr/bin/env python3
# Copyright 2026 Muvon Un Limited
# Copyright 2026 TrillionniumFoundation
# SPDX-License-Identifier: Apache-2.0
"""Bounded local pure-Python checks; does not compile or execute a Rust probe."""
import copy
import hashlib
import importlib.util
import json
from pathlib import Path
import tempfile
import unittest

from prepare_owner_probe import HERE, PINNED, candidate_profile, generate, release_artifact, select_dependency, semantic_adapter, span
from summarize_owner_probe import summarize


def synthetic_run(cpu_b=95, wall_b=95):
    digest = "a" * 64
    checks = [{"case": label, key: True} for label, key in [
        ("regular_leaf", "passed"), ("nested_directory", "passed"),
        *[(name, "rejected") for name in ("file_as_directory", "file_intermediate", "leaf_symlink", "intermediate_symlink", "missing_leaf")],
        *[(name, "lexically_rejected") for name in ("relative", "parent_component", "dot_component", "whitespace", "nul", "invalid_utf8")]]]
    checks.extend([{"case": "owned_lexical_bytes", "passed": True},
                   {"case": "fresh_descriptor_after_replacement", "passed": True},
                   {"case": "late_leaf_symlink", "rejected": True},
                   {"case": "late_intermediate_symlink", "rejected": True}])
    run = {"schema": "hepta-x230-owner-path-probe-run/v1", "completed": True, "error": None,
           "retries": 0, "inputs_unchanged": True, "binaries_unchanged": True, "plan_sha256": digest,
           "semantics": [], "cells": []}
    for variant in ("A", "B"):
        run["semantics"].append({"variant": variant, "returncode": 0, "stderr_bytes": 0,
            "record": {"schema": "hepta-x230-owner-path-semantics/v1", "passed": True, "variant": variant,
                "plan_sha256": digest, "checks": copy.deepcopy(checks), "root_readable": True,
                "leaf_bytes_match": True, "repeated_separator_same_inode": True, "recursive_cleanup": False}})
    for sequence in range(32):
        block, position = divmod(sequence, 4)
        variant = ("A", "B", "B", "A")[position]
        cpu, wall = (100, 100) if variant == "A" else (cpu_b, wall_b)
        rows = [{"phase": phase, "index": index, "attempted": True, "passed": True, "stop_cancelled": False,
                 "validation_error": None, "clock_error": None, "process_cpu_ns": cpu,
                 "owner_thread_cpu_ns": cpu, "wall_ns": wall}
                for phase, count in (("warmup", 4), ("measured", 64)) for index in range(count)]
        run["cells"].append({"sequence": sequence, "block": block, "position": position, "variant": variant,
            "returncode": 0, "stderr_bytes": 0, "record": {"schema": "hepta-x230-owner-path-cell/v1",
                "variant": variant, "plan_sha256": digest, "passed": True, "warmup_expected": 4,
                "measured_expected": 64, "caller_deadline_ms": 5000, "worker_drain_succeeded": True,
                "agent_requests": 69, "agent_requests_expected": 69, "bind_error": None, "cleanup_error": None,
                "agent_error": None, "rows": rows, "fixture": {"hosts": 6, "local_synthetic_agent": True,
                    "rpc_executed": False, "ssh_child_spawned": False, "system_and_fixture_sha256":
                    {name: digest for name in ("ssh", "false", "shell", "config", "known_hosts")}}}})
    return run


class Analysis(unittest.TestCase):
    def test_complete_all_cells_and_paired_counts(self):
        result = summarize(synthetic_run())
        self.assertTrue(result["valid_complete_experiment"])
        self.assertTrue(result["eligible_for_runtime_candidate"])
        self.assertEqual(result["measured_operations"], 2048)
        self.assertEqual(result["warmup_operations"], 128)
        self.assertEqual(len(result["blocks"]), 8)
        self.assertEqual(result["summaries"]["process_cpu_ns"]["median_improvement_percent"], 5.0)
        self.assertFalse(result["runtime_optimization_adopted"])

    def test_negative_and_wall_gate_are_independent(self):
        small = summarize(synthetic_run(99, 99))
        self.assertTrue(small["valid_complete_experiment"])
        self.assertFalse(small["eligible_for_runtime_candidate"])
        slow_wall = summarize(synthetic_run(90, 103))
        self.assertTrue(slow_wall["valid_complete_experiment"])
        self.assertFalse(slow_wall["eligible_for_runtime_candidate"])

    def test_no_empty_or_partial_success(self):
        for count in (0, 1, 31):
            run = synthetic_run()
            run["cells"] = run["cells"][:count]
            self.assertFalse(summarize(run)["valid_complete_experiment"])

    def test_failed_warmup_measured_cleanup_or_clock_never_filtered(self):
        for kind in ("warmup", "measured", "cleanup", "clock", "input"):
            run = synthetic_run()
            record = run["cells"][11]["record"]
            if kind in ("warmup", "measured"):
                record["rows"][0 if kind == "warmup" else 7]["passed"] = False
            elif kind == "cleanup":
                record["cleanup_error"] = "failed"
            elif kind == "clock":
                record["rows"][10]["clock_error"] = "clock failed"
            else:
                run["inputs_unchanged"] = False
            self.assertFalse(summarize(run)["valid_complete_experiment"], kind)

    def test_reorder_duplicates_and_system_pin_change_rejected(self):
        for kind in ("cell", "row", "pin", "semantic"):
            run = synthetic_run()
            if kind == "cell":
                run["cells"][1], run["cells"][2] = run["cells"][2], run["cells"][1]
            elif kind == "row":
                run["cells"][2]["record"]["rows"][8]["index"] = 0
            elif kind == "pin":
                run["cells"][2]["record"]["fixture"]["system_and_fixture_sha256"]["ssh"] = "b" * 64
            else:
                run["semantics"][1]["record"]["checks"] = []
            self.assertFalse(summarize(run)["valid_complete_experiment"], kind)

    def test_both_a_cells_and_both_b_cells_contribute(self):
        run = synthetic_run(cpu_b=90)
        for cell in run["cells"]:
            if cell["position"] == 2:
                for row in cell["record"]["rows"]:
                    row["process_cpu_ns"] = 120
        result = summarize(run)
        self.assertTrue(result["valid_complete_experiment"])
        self.assertEqual(result["summaries"]["process_cpu_ns"]["median_improvement_percent"], -5.0)
        self.assertFalse(result["eligible_for_runtime_candidate"])

    def test_eight_blocks_not_positive_subset(self):
        run = synthetic_run(cpu_b=90)
        for cell in run["cells"]:
            if cell["block"] in (0, 1) and cell["variant"] == "B":
                for row in cell["record"]["rows"]:
                    row["process_cpu_ns"] = 110
        result = summarize(run)
        self.assertTrue(result["valid_complete_experiment"])
        self.assertEqual(result["summaries"]["process_cpu_ns"]["positive_blocks"], 6)
        self.assertFalse(result["eligible_for_runtime_candidate"])


class Source(unittest.TestCase):
    def test_only_prepared_pinned_path_and_verbatim_owner_methods(self):
        source = HERE.parent / "a27-review-source"
        if not source.is_dir():
            self.skipTest("local exact review source is not part of uploaded bundle")
        for relative, digest in PINNED.items():
            self.assertEqual(hashlib.sha256((source / relative).read_bytes()).hexdigest(), digest)
        with tempfile.TemporaryDirectory(prefix="a27-static-", dir=HERE) as directory:
            generated = generate(source, Path(directory))
            original = (source / "src/mcp/runtime/ssh_observation_profile.rs").read_text()
            self.assertEqual((Path(directory) / "A/observation/profile.rs").read_text(), original + semantic_adapter("A"))
            self.assertEqual((Path(directory) / "B/observation/profile.rs").read_text(), candidate_profile(original) + semantic_adapter("B"))
            self.assertIn("OWNER_METHODS", generated["verbatim_extracts"])
            for name in ("main.rs", "observation/mod.rs", "observation/validation.rs", "mcp/runtime/config.rs"):
                self.assertEqual((Path(directory) / "A" / name).read_bytes(), (Path(directory) / "B" / name).read_bytes())
            changed = candidate_profile(original)
            self.assertEqual(span(original, "pub(super) fn open_absolute(", "pub(super) fn private_directory("),
                             span(changed, "pub(super) fn open_absolute(", "pub(super) fn private_directory("))
            before = span(original, "fn checked_file(", "fn verify_read(").split("\tlet before = file.metadata()?;", 1)[1]
            after = span(changed, "fn check_opened_file(", "fn verify_read(").split("\tlet before = file.metadata()?;", 1)[1]
            self.assertEqual(before, after)
            before = span(original, "fn verify_read(", "fn read_file(").split(") -> Result<()> {\n", 1)[1]
            after = span(changed, "fn verify_read_with(", "fn read_file(").split(") -> Result<()> {\n", 1)[1]
            self.assertEqual(before, after.replace("reopen()?", "open_absolute(path, false)?"))
            self.assertEqual(span(original, "\t\tlet mut hash = ring::digest::Context::new", "\t\tverify_read(&self.path,"),
                             span(changed, "\t\tlet mut hash = ring::digest::Context::new", "\t\tverify_read_with(&file,"))
            prepared = (HERE / "ssh_observation_prepared_path.rs").read_text()
            fields = span(prepared, "pub(super) struct PreparedPath {", "impl PreparedPath {")
            self.assertIn("\tpath: PathBuf,", fields)
            self.assertIn("\tcomponents: Box<[CString]>,", fields)
            self.assertNotIn("pub path", fields)
            self.assertNotIn("pub components", fields)
            for forbidden in ("File,", "Metadata", "Stamp", "OnceLock", "Mutex", "&mut self"):
                self.assertNotIn(forbidden, fields)
            constructor = span(prepared, "\tpub(super) fn new(", "\tpub(super) fn as_path(")
            self.assertNotIn("openat", constructor)
            self.assertNotIn("File::open", constructor)


class DependencySelection(unittest.TestCase):
    PROFILE = {"debug_assertions": False, "debuginfo": 0, "opt_level": "3", "overflow_checks": False, "test": False}

    def records(self, directory):
        runtime = {"executable": str(directory / "release/hepta-runtime"), "profile": dict(self.PROFILE)}
        target = {"reason": "compiler-artifact", "target": {"name": "serde_json", "kind": ["lib"]},
                  "profile": dict(self.PROFILE), "features": ["alloc", "default", "std"],
                  "filenames": [str(directory / "release/deps/libserde_json-target.rlib")]}
        host = copy.deepcopy(target)
        host["profile"]["opt_level"] = "0"
        host["features"] = ["default", "std"]
        host["filenames"] = [str(directory / "release/deps/libserde_json-host.rlib")]
        return runtime, host, target

    def test_host_target_selection_is_profile_based_and_order_independent(self):
        runtime, host, target = self.records(Path("/fixture"))
        for records in ([host, target], [target, host]):
            chosen, evidence = release_artifact(records, "serde_json", runtime)
            self.assertEqual(chosen, target)
            self.assertEqual(len(evidence["considered_artifacts"]), 2)
            rejected = [row for row in evidence["considered_artifacts"] if not row["selected"]]
            self.assertEqual(rejected[0]["compiler_artifact"], host)
            self.assertEqual(rejected[0]["excluded_reasons"], ["profile_differs_from_qualified_runtime"])

    def test_no_match_duplicate_or_nonmatching_full_profile_never_falls_back(self):
        runtime, host, target = self.records(Path("/fixture"))
        duplicate = copy.deepcopy(target)
        duplicate["filenames"] = ["/fixture/release/deps/libserde_json-other.rlib"]
        for rows in ([host], [target, duplicate]):
            with self.assertRaises(ValueError):
                release_artifact(rows, "serde_json", runtime)
        for changed in ("profile", "path"):
            different = copy.deepcopy(target)
            if changed == "profile":
                different["profile"]["overflow_checks"] = True
            else:
                different["filenames"] = ["/other/release/deps/libserde_json-target.rlib"]
            with self.assertRaises(ValueError):
                release_artifact([different], "serde_json", runtime)

    def test_selected_dependency_still_requires_exact_manifest_lock_and_hash(self):
        with tempfile.TemporaryDirectory(prefix="a27-selector-", dir=HERE) as temporary:
            directory = Path(temporary)
            runtime, host, target = self.records(directory)
            artifact = Path(target["filenames"][0])
            artifact.parent.mkdir(parents=True)
            artifact.write_bytes(b"synthetic metadata fixture, not a Rust executable")
            manifest = directory / "Cargo.toml"
            manifest.write_text('[package]\nname = "serde_json"\nversion = "1.0.151"\n')
            source = "registry+https://github.com/rust-lang/crates.io-index"
            for row in (host, target):
                row["manifest_path"] = str(manifest)
                row["package_id"] = source + "#serde_json@1.0.151"
            locked = {"package": [{"name": "serde_json", "version": "1.0.151", "source": source}]}
            selected = select_dependency([host, target], "serde_json", locked, runtime)
            self.assertEqual(selected["compiler_artifact"], target)
            self.assertEqual(selected["rlib"]["sha256"], hashlib.sha256(artifact.read_bytes()).hexdigest())
            locked["package"][0]["version"] = "1.0.150"
            with self.assertRaises(ValueError):
                select_dependency([host, target], "serde_json", locked, runtime)


if __name__ == "__main__":
    unittest.main()
