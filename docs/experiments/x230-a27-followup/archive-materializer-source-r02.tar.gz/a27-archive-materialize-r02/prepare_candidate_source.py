#!/usr/bin/env python3
# Copyright 2026 Muvon Un Limited
# Copyright 2026 TrillionniumFoundation
# SPDX-License-Identifier: Apache-2.0
"""Materialize a fresh A27 source only after the frozen actual archive r02 probe passes.

No compiler, test, runtime, probe, subprocess, network call, or qualification is
started. A failed preparation and any partially copied files remain in the new
output directory; they are never treated as a qualified or adopted runtime.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import stat
import sys

BASE_COMMIT = "65690e5bf8094888524ca2c2cd3cf4d01d846dc6"
BASE_MAP_SHA = "2822cb186ad0d6380a20baa699f5b6e7ed02a9c4cbd0079ca6e50c17a414d2a0"
BUNDLE_MANIFEST_SHA = "bc00109b66379ede8ae3979a515999d851df91443de97f09bb86a016051ef277"
PLAN_SHA = "f52465a8773520c380b8f20e3875d877cccc1564611a8005ed3a89ad9211a559"
BASE_MAP_FILE_SHA = "7a7bb399b789c7449201e7383d7bafa7b5c9f6cefcb125bf6f41f97c21907194"
BASE_AUDIT_SHA = "333ee110483a066e5bd1132839dd91e0d74b09ea5197895595bebc9d04614d1c"
AUDIT = "src/mcp/runtime/request_audit.rs"
TEST = "src/mcp/runtime/request_audit_preparation_tests.rs"
PROBE = "src/mcp/runtime/a27_archive_probe.rs"
DELTA = {
    AUDIT: {"member": "modified/request_audit.rs", "bytes": 63326,
            "sha256": "30ba7a00508b962ed732f9c6f5757c160ebf809698965684585ee6ab27dc6af7"},
    TEST: {"member": "modified/request_audit_preparation_tests.rs", "bytes": 6548,
           "sha256": "c6fff2bb90491146521c52db82e5198775d51aa176beb2edadabe8ef6c77f48f"},
}
ROOT_FILES = {"Cargo.toml", "Cargo.lock", "rustfmt.toml"}


def need(value, message):
    if not value:
        raise ValueError(message)


def digest(data):
    return hashlib.sha256(data).hexdigest()


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":")).encode()


def stamp(value):
    return (value.st_dev, value.st_ino, value.st_mode, value.st_uid, value.st_gid,
            value.st_nlink, value.st_size, value.st_mtime_ns, value.st_ctime_ns)


def direct(path):
    return path.is_absolute() and path == path.resolve()


def read_stable(path):
    need(direct(path), "input path is indirect")
    fd = os.open(path, os.O_RDONLY | os.O_CLOEXEC | os.O_NOFOLLOW | os.O_NONBLOCK)
    with os.fdopen(fd, "rb") as stream:
        before = os.fstat(stream.fileno())
        need(stat.S_ISREG(before.st_mode) and before.st_nlink == 1, "input must be a singly linked regular file")
        raw = stream.read()
        need(len(raw) == before.st_size and stamp(before) == stamp(os.fstat(stream.fileno()))
             == stamp(path.lstat()) and direct(path), "input changed during stable read")
    return raw, stamp(before)


def regular_receipt(raw):
    return {"bytes": len(raw), "sha256": digest(raw)}


def valid_relative(value):
    path = Path(value)
    return (isinstance(value, str) and value and not path.is_absolute()
            and path.as_posix() == value and all(part not in ("", ".", "..") for part in path.parts)
            and "\0" not in value)


def source_names(root):
    need(direct(root) and root.is_dir() and not root.is_symlink(), "source root is missing or indirect")
    names = set(ROOT_FILES)
    src = root / "src"
    need(src.is_dir() and not src.is_symlink(), "source src directory is missing or indirect")
    for directory, subdirs, files in os.walk(src, followlinks=False):
        for name in subdirs:
            value = (Path(directory) / name).lstat()
            need(stat.S_ISDIR(value.st_mode), "source contains an indirect directory")
        for name in files:
            path = Path(directory) / name
            value = path.lstat()
            need(stat.S_ISREG(value.st_mode) and value.st_nlink == 1,
                 "source contains a symlink, hardlinked file or special member")
            names.add(path.relative_to(root).as_posix())
    return names


def source_snapshot(root, expected=None):
    names = source_names(root)
    if expected is not None:
        need(names == set(expected), "source path set differs from the exact qualified map")
    values, stamps = {}, {}
    for name in sorted(names):
        raw, before = read_stable(root / name)
        values[name], stamps[name] = regular_receipt(raw), before
        if expected is not None:
            need(values[name]["sha256"] == expected[name], "source content differs: " + name)
    need(source_names(root) == names, "source file set changed during enumeration")
    for name, before in stamps.items():
        need(stamp((root / name).lstat()) == before, "source stamp changed after verification: " + name)
    return values, stamps


def write_relative(root, name, raw):
    """Every destination directory and file is descriptor-relative and new."""
    need(valid_relative(name), "output member path is invalid")
    parts = Path(name).parts
    fd = os.open(root, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW | os.O_CLOEXEC)
    try:
        for part in parts[:-1]:
            try:
                os.mkdir(part, mode=0o700, dir_fd=fd)
            except FileExistsError:
                pass
            child = os.open(part, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW | os.O_CLOEXEC, dir_fd=fd)
            info = os.fstat(child)
            if not (stat.S_ISDIR(info.st_mode) and info.st_uid == os.geteuid()
                    and stat.S_IMODE(info.st_mode) == 0o700):
                os.close(child)
                raise ValueError("output directory identity or private mode differs")
            os.fsync(fd)
            os.close(fd)
            fd = child
        child = os.open(parts[-1], os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW | os.O_CLOEXEC,
                        0o600, dir_fd=fd)
        with os.fdopen(child, "wb") as stream:
            need(stream.write(raw) == len(raw), "incomplete destination write")
            stream.flush()
            os.fsync(stream.fileno())
            info = os.fstat(stream.fileno())
            need(stat.S_ISREG(info.st_mode) and info.st_nlink == 1 and info.st_uid == os.geteuid()
                 and stat.S_IMODE(info.st_mode) == 0o600, "destination file identity or mode differs")
        os.fsync(fd)
    finally:
        os.close(fd)


def write_json(root, name, value):
    write_relative(root, name, canonical(value) + b"\n")


def check_bundle(bundle):
    raw, _ = read_stable(bundle / "probe/bundle_manifest.json")
    need(digest(raw) == BUNDLE_MANIFEST_SHA, "frozen complete-bundle manifest differs")
    manifest = json.loads(raw)
    need(manifest.get("schema") == "hepta-a27-archive-probe-bundle/v1"
         and manifest.get("experiment_revision") == "r02"
         and manifest.get("frozen_build_subset_preserved") is True, "bundle declaration differs")
    expected = manifest.get("files", {})
    need(len(expected) == 18, "frozen complete-bundle member count differs")
    actual, identities = {}, set()
    for name, receipt in expected.items():
        need(valid_relative(name), "bundle member path is invalid")
        value, info = read_stable(bundle / name)
        actual[name] = regular_receipt(value)
        identities.add(info[:2])
        need(actual[name] == receipt, "frozen bundle member differs: " + name)
    return {"manifest_sha256": digest(raw), "files": actual}, identities


def check_analysis(raw, bundle_receipt, declared):
    value = json.loads(raw)
    need(value.get("schema") == "hepta-a27-archive-probe-analysis/v1"
         and value.get("experiment_revision") == "r02", "actual analysis schema or revision differs")
    for name in ("verified", "comparison_valid", "diagnostic_performance_gate_passed"):
        need(value.get(name) is True, "actual analysis gate is not true: " + name)
    need(value.get("raw_series_passed") is True and value.get("errors") == []
         and value.get("raw_series_errors") == [] and value.get("resource_evidence_complete") is True,
         "actual experiment or full evidence did not pass")
    need(value.get("plan_sha256") == PLAN_SHA and value.get("gate") == declared["performance_gate"],
         "actual analysis used a different predeclared plan or gate")
    need(value.get("input_binding", {}).get("bundle") == bundle_receipt,
         "actual analysis is not bound to these exact candidate/probe/tool bytes")
    rows = value.get("cell_checks", [])
    need(value.get("observed_cell_count") == value.get("expected_cell_count") == len(rows) == 536
         and [row.get("id") for row in rows] == [row["id"] for row in declared["cells"]]
         and all(row.get("passed") is True and row.get("query_rows") == 8
                 and row.get("raw_failures") == row.get("oracle_failures") == 0
                 and row.get("complete", {}).get("calls") == 8
                 and row.get("complete", {}).get("case_offset") == declared["cells"][index]["case_offset"]
                 for index, row in enumerate(rows)), "all 536 actual r02 cells and their eight rotated cases must have passed")
    need(len(value.get("equal_call_mixed_shapes", [])) == 6
         and all(row.get("passed") is True for row in value["equal_call_mixed_shapes"])
         and len(value.get("all_kind_shapes", [])) == 12
         and all(row.get("guard_passed") is True for row in value["all_kind_shapes"])
         and len(value.get("all_cold_guard_shapes", [])) == 8
         and all(row.get("guard_passed") is True for row in value["all_cold_guard_shapes"]),
         "an actual shape or cold/latency guard did not pass")
    need(isinstance(value.get("series_sha256"), str) and len(value["series_sha256"]) == 64,
         "actual analysis lacks a bound original series")
    return value


def public_error(error, paths):
    message = str(error)
    for path, label in sorted(paths, key=lambda item: len(str(item[0])), reverse=True):
        message = message.replace(str(path), label)
    return {"type": type(error).__name__, "message": message}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source", type=Path, required=True, help="Untouched exact qualified A26 source")
    parser.add_argument("--analysis", type=Path, required=True, help="Actual completed frozen-probe analysis JSON")
    parser.add_argument("--bundle", type=Path, required=True, help="Frozen complete bundle's a27-archive-patch directory")
    parser.add_argument("--output", type=Path, required=True, help="Fresh preparation directory; source will be its source/ child")
    args = parser.parse_args()
    source, analysis_path, bundle, output = (path.absolute() for path in
                                            (args.source, args.analysis, args.bundle, args.output))
    need(sys.platform == "linux", "candidate materializer requires Linux descriptor semantics")
    need(direct(source) and direct(analysis_path) and direct(bundle), "input root is indirect")
    need(direct(output.parent) and output.parent.is_dir() and not os.path.lexists(output),
         "output must be fresh under an existing direct parent")
    need(direct(output), "output path is not normalized")
    for existing in (source, bundle, analysis_path):
        need(not output.is_relative_to(existing) and not existing.is_relative_to(output),
             "fresh output overlaps an input")
    output.mkdir(mode=0o700)
    parent_fd = os.open(output.parent, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW | os.O_CLOEXEC)
    try:
        os.fsync(parent_fd)
    finally:
        os.close(parent_fd)
    report = {"schema": "hepta-a27-archive-source-preparation/v1", "experiment_revision": "r02", "prepared": False,
              "runtime_qualified": False, "adopted": False, "probe_hooks_included": False,
              "base_commit": BASE_COMMIT, "base_source_map_sha256": BASE_MAP_SHA,
              "source_directory": "source", "copy_method": "new regular O_EXCL files; no links",
              "source_files_copied": 0, "checks": {}, "errors": []}
    labels = [(source, "<qualified-a26>"), (analysis_path, "<actual-archive-analysis>"),
              (bundle, "<frozen-archive-bundle>"), (output, "<candidate-preparation>")]
    try:
        write_json(output, "attempt.json", {"schema": report["schema"], "prepared": False,
                                           "runtime_qualified": False, "adopted": False,
                                           "requires_actual_performance_gates": True})
        bundle_before, input_inodes = check_bundle(bundle)
        analysis_raw, analysis_stamp = read_stable(analysis_path)
        plan_raw, _ = read_stable(bundle / "probe/PREDECLARED_PLAN.json")
        need(digest(plan_raw) == PLAN_SHA, "frozen plan bytes differ")
        actual = check_analysis(analysis_raw, bundle_before, json.loads(plan_raw))
        report["checks"]["actual_verified_comparison_and_performance_gates"] = True
        report["analysis"] = {**regular_receipt(analysis_raw), "series_sha256": actual["series_sha256"],
                              "plan_sha256": PLAN_SHA, "three_required_gates": True}
        map_raw, _ = read_stable(bundle / "probe/baseline_source_map.json")
        need(digest(map_raw) == BASE_MAP_FILE_SHA, "frozen baseline-map file differs")
        baseline = json.loads(map_raw)
        expected = baseline.get("files", {})
        need(baseline.get("commit") == BASE_COMMIT and len(expected) == 156
             and digest(canonical(expected)) == BASE_MAP_SHA
             and all(valid_relative(name) and (name in ROOT_FILES or name.startswith("src/")) for name in expected)
             and expected.get(AUDIT) == BASE_AUDIT_SHA and TEST not in expected and PROBE not in expected,
             "exact qualified A26 map differs")
        before, source_stamps = source_snapshot(source, expected)
        input_inodes.update(info[:2] for info in source_stamps.values())
        report["checks"]["all_156_baseline_sources_and_full_path_set"] = True
        candidate = {}
        for name, pinned in DELTA.items():
            raw, _ = read_stable(bundle / pinned["member"])
            need(regular_receipt(raw) == {key: pinned[key] for key in ("sha256", "bytes")},
                 "frozen production candidate member differs")
            need(b"HEPTA_A27_ARCHIVE_PROBE" not in raw and b"run_a27_archive_probe" not in raw,
                 "production candidate contains a probe hook")
            candidate[name] = raw
        desired = dict(expected)
        desired.update({name: row["sha256"] for name, row in DELTA.items()})
        need(len(desired) == 157 and {name for name in desired if name not in expected} == {TEST}
             and {name for name in expected if desired[name] != expected[name]} == {AUDIT},
             "source delta is not exactly one changed and one new file")
        write_json(output, "inputs-before.json", {"analysis": report["analysis"], "bundle": bundle_before,
                   "baseline_source_map_sha256": BASE_MAP_SHA, "baseline_files": before,
                   "production_delta": DELTA})
        prepared = output / "source"
        prepared.mkdir(mode=0o700)
        for name in sorted(desired):
            if name in candidate:
                raw = candidate[name]
            else:
                raw, current_stamp = read_stable(source / name)
                need(current_stamp == source_stamps[name], "baseline source changed during copy")
            need(digest(raw) == desired[name], "copied content differs from declared candidate")
            write_relative(prepared, name, raw)
            report["source_files_copied"] += 1
        copied, copied_stamps = source_snapshot(prepared, desired)
        identities = [info[:2] for info in copied_stamps.values()]
        need(len(identities) == len(set(identities)) == 157 and not (set(identities) & input_inodes),
             "destination shares a regular inode internally or with an input")
        after, after_stamps = source_snapshot(source, expected)
        need(after == before and after_stamps == source_stamps, "qualified A26 source changed during preparation")
        bundle_after, _ = check_bundle(bundle)
        after_analysis, after_analysis_stamp = read_stable(analysis_path)
        need(bundle_after == bundle_before and after_analysis == analysis_raw
             and after_analysis_stamp == analysis_stamp, "bound analysis or frozen candidate input changed")
        final_names = source_names(prepared)
        need(final_names == set(desired), "prepared source file set changed")
        for name, saved in copied_stamps.items():
            need(stamp((prepared / name).lstat()) == saved, "prepared source stamp changed")
        source_manifest = {"schema": "hepta-a27-archive-source-before-format/v1", "measured_probe_revision": "r02", "file_count": 157,
            "files": copied, "source_map": desired, "source_map_sha256": digest(canonical(desired)),
            "changed": [AUDIT], "new": [TEST], "unchanged_count": 155,
            "probe_hooks_included": False, "formatted": False, "qualified": False}
        write_json(output, "source-before-format.json", source_manifest)
        report["checks"].update(frozen_candidate_sources=True, exact_157_file_destination=True,
            one_changed_one_new=True, all_destination_files_regular_single_link=True,
            no_shared_regular_inodes=True, baseline_source_bytes_and_stamps_unchanged=True,
            frozen_bundle_and_analysis_unchanged=True, no_probe_hooks=True)
        report.update(prepared=True, source_map_sha256=source_manifest["source_map_sha256"],
                      source_before_format=regular_receipt(canonical(source_manifest) + b"\n"),
                      changed=[AUDIT], new=[TEST], unchanged_count=155,
                      next_step="independent existing qualifier on source/; no qualification performed here")
    except BaseException as error:
        report["errors"].append(public_error(error, labels))
    write_json(output, "preparation.json", report)
    print(json.dumps({"prepared": report["prepared"], "runtime_qualified": False, "adopted": False,
                      "source_directory": "source", "source_files_copied": report["source_files_copied"],
                      "errors": report["errors"]}, sort_keys=True))
    return 0 if report["prepared"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
