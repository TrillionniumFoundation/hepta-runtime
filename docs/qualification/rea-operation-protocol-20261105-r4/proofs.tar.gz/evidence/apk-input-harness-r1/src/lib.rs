#![allow(dead_code)]
mod mcp {
    #[path = "/home/qian-qi/work/hepta-rea-contracts-20261104-r4-evidence/qualification/apk-input-harness-r1/rea_contract.rs"] mod rea_contract;
    #[path = "/home/qian-qi/work/hepta-rea-contracts-20261104-r4/qualification/src/mcp/rea_apk_mcp_input.rs"] mod rea_apk_mcp_input;
}
