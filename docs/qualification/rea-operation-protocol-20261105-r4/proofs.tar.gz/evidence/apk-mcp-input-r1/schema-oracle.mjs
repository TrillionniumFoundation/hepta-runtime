import fs from "node:fs";
import {pathToFileURL} from "node:url";
const [pkg,input]=process.argv.slice(2);
const {inspectApkSignatureInputSchema:schema}=await import(pathToFileURL(pkg+"/dist/domain/apkSignature/apkSignatureQuery.js").href);
const rows=JSON.parse(fs.readFileSync(input,"utf8")).map(c=>{const a=JSON.parse(c.raw_arguments);const r=schema.safeParse(a);return {id:c.id,argument_keys:Object.keys(a),view_keys:a.view&&typeof a.view==="object"&&!Array.isArray(a.view)?Object.keys(a.view):null,valid:r.success,...(r.success?{parsed:r.data}:{issues:r.error.issues})};});
process.stdout.write(JSON.stringify(rows,null,2)+"\n");
