#!/usr/bin/env python3
# Copyright 2026 TrillionniumFoundation
# SPDX-License-Identifier: Apache-2.0
"""Derive the next native candidate against fixed original C9 captures, offline only."""
from pathlib import Path
import argparse
import collections
import io
import re
import stat
import types
import gzip
import hashlib
import json

parser=argparse.ArgumentParser()
parser.add_argument("--plan",type=Path,required=True)
parser.add_argument("--plan-sha256",required=True)
parser.add_argument("--script-sha256",required=True)
args=parser.parse_args()
_plan_raw=args.plan.read_bytes()
assert hashlib.sha256(_plan_raw).hexdigest()==args.plan_sha256
PLAN=json.loads(_plan_raw)
BASE=Path(PLAN["base"])
assert BASE.is_absolute() and BASE.resolve(strict=True)==BASE and not BASE.is_symlink()
def directory_name(key):
 value=PLAN[key]
 assert isinstance(value,str) and re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_.-]{0,127}",value)
 return value
NATIVE_DIR=directory_name("native_capture")
HARNESS_DIR=directory_name("native_harness")
ORIGINAL_DIR="mcp-original-c9-r1"
OUT=BASE/directory_name("output")
assert len({NATIVE_DIR,HARNESS_DIR,ORIGINAL_DIR,OUT.name})==4
assert re.fullmatch(r"[0-9a-f]{40}",PLAN["source_commit"])
assert re.fullmatch(r"[0-9a-f]{64}",PLAN["binary_sha256"])
assert re.fullmatch(r"[0-9a-f]{64}",PLAN["source_tree_sha256"])
PINS=PLAN["pins"]
assert isinstance(PINS,dict) and PINS
for key in (NATIVE_DIR+"/capture.json",HARNESS_DIR+"/qualification.json",
            PLAN["state_consumer_summary"],PLAN["state_consumer_source"],PLAN["native_census"],PLAN["build_summary"]):
 assert key in PINS
PINS_FIXED={
 ORIGINAL_DIR+"/capture.json":"2981ca455fbb9f64c0d7a7917afc79a34e869f05c5b6d5f7f1c5ea8be937fb82",
 ORIGINAL_DIR+"/original-complete.bundle.json":"fa5884427caa3bb8f3effef348f04bc23dccc6d187fd4bb50797f17f4cc57dbd",
 "c9-source-snapshot/manifest.json":"d4dab7bdee3e00f00154c7fbb8a925337313f209ee3c9442c5b2daf69a43f143",
 "c9-post-execution-owner-census.json":"4b91630b7e4d370c2c9dae02a20b1549e9a0d27a13e3fd2930d3cf301fc19037",
 "c9-original-xref-source.json":"9cb8a3af824bf0eed53feabeaff8115fda91edf03fa58e9ae21fad90efb6a08e",
 "peer-derived-c9-r1/original-roundtrip-comparison-layers.json":"003308091a9fcb1a2ae1c48af1832627194968d50f435e4dc58c651066c16809"}
for key,value in PINS_FIXED.items():
 assert key not in PINS or PINS[key]==value
 PINS[key]=value
manifest={}
cache={}
def digest(raw):return hashlib.sha256(raw).hexdigest()
def read(path, expected=None):
 path=Path(path)
 assert path.is_absolute() and path.is_relative_to(BASE) and ".." not in path.parts,str(path)
 assert path.resolve(strict=True)==path and not path.is_symlink(),str(path)
 before=path.lstat()
 assert stat.S_ISREG(before.st_mode) and 0<=before.st_size<=16*1024*1024,str(path)
 raw=path.read_bytes()
 after=path.lstat()
 assert (before.st_dev,before.st_ino,before.st_size,before.st_mtime_ns,before.st_ctime_ns)==(
         after.st_dev,after.st_ino,after.st_size,after.st_mtime_ns,after.st_ctime_ns),str(path)
 key=str(path.relative_to(BASE))
 actual={"path":key,"bytes":len(raw),"sha256":digest(raw)}
 if expected is not None:assert actual["sha256"]==expected,(key,actual)
 if key in manifest:assert manifest[key]==actual,("input changed",key)
 manifest[key]=actual
 cache[key]=raw
 return raw
def pairs_no_duplicates(pairs):
 out={}
 for key,value in pairs:
  assert key not in out,("duplicate JSON key",key)
  out[key]=value
 return out
def parse(raw):
 return json.loads(raw,object_pairs_hook=pairs_no_duplicates,
  parse_constant=lambda value: (_ for _ in ()).throw(ValueError(value)))
def eq(a,b):
 if type(a) is not type(b):return False
 if isinstance(a,dict):return a.keys()==b.keys() and all(eq(a[k],b[k]) for k in a)
 if isinstance(a,list):return len(a)==len(b) and all(eq(x,y) for x,y in zip(a,b))
 return a==b
def ref(root,item):
 raw=read(root/item["path"],item["sha256"])
 assert len(raw)==item["bytes"]
 return raw
def save(name,value):
 raw=(json.dumps(value,ensure_ascii=True,sort_keys=True,indent=2,allow_nan=False)+"\n").encode()
 (OUT/name).write_bytes(raw)
 return {"path":name,"bytes":len(raw),"sha256":digest(raw)}
def pointer_piece(value):return str(value).replace("~","~0").replace("/","~1")
def leaves(value,path=""):
 if isinstance(value,dict) and value:
  for key in sorted(value):
   yield from leaves(value[key],path+"/"+pointer_piece(key))
 elif isinstance(value,list) and value:
  for index,item in enumerate(value):
   yield from leaves(item,path+"/"+str(index))
 else:yield path,value
def get(value,path):
 if path=="" :return value
 for part in path.split("/")[1:]:
  key=part.replace("~1","/").replace("~0","~")
  value=value[int(key)] if isinstance(value,list) else value[key]
 return value

def verify_build_identity(value,plan):
 assert value["schema"]=="hepta.rea.full-qualification.v1"
 assert value["qualified"] is True and value["status"]=="passed"
 assert value["invalid_reasons"]==[] and value["interrupted_by_signal"] is None
 assert value["source_changed"] is False and value["source_inventory_changed"] is False
 assert value["source_monitor_complete"] is True
 expected=("cargo-version","rustc-version","nextest-version","fmt-check",
  "clippy-all-features","clippy-no-default-features","nextest-all-features",
  "nextest-no-default-features","build-native-binary")
 assert tuple(stage["name"] for stage in value["stages"])==expected
 assert all(type(stage["exit_code"]) is int and stage["exit_code"]==0
  and stage["status"]=="passed" and stage["interrupted"] is False for stage in value["stages"])
 assert value["source_before"]["tree_sha256"]==value["source_after"]["tree_sha256"]==plan["source_tree_sha256"]
 assert value["final_binary"]["exists"] is True and value["binary_after_build"]["exists"] is True
 assert value["final_binary"]["sha256"]==value["binary_after_build"]["sha256"]==plan["binary_sha256"]
 assert value["final_binary"]["bytes"]==value["binary_after_build"]["bytes"]
 return {"summary_sha256":plan["pins"][plan["build_summary"]],
  "source_tree_sha256":plan["source_tree_sha256"],"binary_sha256":plan["binary_sha256"],
  "stages":list(expected),"scope":"Pinned matrix summary identity and terminal fields checked; full build-log consumer remains a separate proof."}

assert eq(parse(_plan_raw),PLAN|{"pins":parse(_plan_raw)["pins"]})
read(args.plan,args.plan_sha256)
read(Path(__file__).resolve(),args.script_sha256)
for rel,sha in PINS.items():
 assert not Path(rel).is_absolute() and ".." not in Path(rel).parts
 assert re.fullmatch(r"[0-9a-f]{64}",sha)
 read(BASE/rel,sha)
READER_SHA="089849d73b315c242a20845cc325e29823592f7796047655ccbe52b583692ce3"
assert PINS[PLAN["state_consumer_source"]]==READER_SHA
reader=types.ModuleType("_pinned_private_r4_reader")
reader.__file__=str(BASE/PLAN["state_consumer_source"])
exec(compile(cache[PLAN["state_consumer_source"]],reader.__file__,"exec"),reader.__dict__)
native=parse(cache[NATIVE_DIR+"/capture.json"])
original=parse(cache["mcp-original-c9-r1/capture.json"])
qualification=parse(cache[HARNESS_DIR+"/qualification.json"])
bundle=parse(cache["mcp-original-c9-r1/original-complete.bundle.json"])
census=parse(cache["c9-post-execution-owner-census.json"])
assert native["source_commit"]==PLAN["source_commit"]
assert original["source_commit"]=="c9c79e27a2bf56bd204df6591ca2311dc872e317"
assert qualification["runtime_sha256"]==native["runtime"]["sha256"]==PLAN["binary_sha256"]
state_consumer=parse(cache[PLAN["state_consumer_summary"]])
state_rederived=reader.validate_capture(BASE/NATIVE_DIR,PINS[NATIVE_DIR+"/capture.json"])
assert eq(state_consumer,state_rederived),"independent state consumer output was not reproducible"
native_census=parse(cache[PLAN["native_census"]])
build_summary=parse(cache[PLAN["build_summary"]])
build_identity=verify_build_identity(build_summary,PLAN)
assert native["source_unchanged"] and original["source_unchanged"]
assert native["completed"] and original["completed"] and qualification["qualified"]
OUT.mkdir(exist_ok=False)
wire_facts=[]
sessions={}
def verify_capture(report,dirname):
 root=BASE/dirname
 for session in report["sessions"]:
  sid=session["id"]
  sroot=root/sid
  artifacts=session["client_artifacts"]
  for item in artifacts.values():ref(root,item)
  index=ref(root,artifacts["wire.jsonl"])
  entries=[parse(line) for line in index.splitlines() if line]
  raw_by_path={}
  messages=[]
  for entry in entries:
   assert entry["encoding"]=="gzip-original-jsonrpc-line"
   assert 0<entry["raw_bytes"]<=16*1024*1024
   compressed=read(sroot/entry["path"],entry["gzip_sha256"])
   assert len(compressed)==entry["gzip_bytes"]
   with gzip.GzipFile(fileobj=io.BytesIO(compressed)) as stream:
    raw=stream.read(entry["raw_bytes"]+1)
    assert len(raw)==entry["raw_bytes"] and stream.read(1)==b""
   assert len(raw)==entry["raw_bytes"] and digest(raw)==entry["raw_sha256"]
   assert raw.endswith(b"\n")
   message=parse(raw)
   assert entry["path"] not in raw_by_path
   raw_by_path[entry["path"]]=raw
   messages.append((entry,message))
  for call in session["calls"]:
   assert call["status"]=="OBSERVED"
   request=parse(raw_by_path[call["request_wire"]["path"]])
   response=raw_by_path[call["response_wire"]["path"]]
   parsed=parse(response)
   assert eq(parsed,call["response_parsed"])
   assert request["id"]==parsed["id"]==call["request_id"]
   assert request["method"]=="tools/call"
   assert eq(request["params"],{"name":call["tool"],"arguments":call["arguments"]})
   for name in ("result_raw","error_raw","structured_content_raw"):
    if name not in call:continue
    item=call[name];raw=ref(root,item)
    start,end=item["source_frame_range"]
    assert response[start:end]==raw
    key="result" if name=="result_raw" else "error"
    value=parsed.get(key) if name!="structured_content_raw" else parsed["result"]["structuredContent"]
    assert eq(parse(raw),value)
   texts=[x["text"].encode() for x in parsed.get("result",{}).get("content",[]) if x.get("type")=="text"]
   assert len(texts)==len(call["content_text_utf8"])
   for raw,item in zip(texts,call["content_text_utf8"]):assert ref(root,item)==raw
   call["_response_bytes"]=response
   call["_root"]=root
   call["_session"]=sid
  process_raw=read(root/(sid+"-processes.json"))
  assert eq(parse(process_raw),session["processes"])
  assert session["wire_capture_drained"] and session["close"]["returncode"]==0
  assert session["close"]["forced_cleanup"]==[] and session["close"]["owner_pidfd_exited"]
  assert session["close"]["process_group_gone"] and session["close"]["reader_stopped"]
  assert session["processes"]["all_observed_original_identities_exited_without_fallback"]
  sessions[sid]=(session,messages)
  wire_facts.append({"session":sid,"frames":len(entries),"sent":sum(x["direction"]=="sent" for x in entries),
   "received":sum(x["direction"]=="received" for x in entries),"calls_with_exact_request_response_binding":len(session["calls"]),
   "all_raw_frame_hashes_verified":True,"all_saved_result_slices_verified":True,"all_opaque_text_utf8_verified":True,
   "owner":session["close"]["owner"],"normal_close":True,
   "observed_descendants":len(session["processes"]["observations"]),"observer_errors":session["processes"]["errors"]})
verify_capture(native,NATIVE_DIR)
verify_capture(original,ORIGINAL_DIR)
N={v["id"]:v for v in sessions["native-readback"][0]["calls"]}
O={v["id"]:v for v in sessions["original-main"][0]["calls"]}
I={v["id"]:v for v in sessions["original-import"][0]["calls"]}
C={v["id"]:v for v in sessions["original-cancel"][0]["calls"]}
def payload(call,required=True):
 result=call["response_parsed"].get("result",{})
 texts=[v["text"] for v in result.get("content",[]) if v.get("type")=="text"]
 value=None
 if len(texts)==1:
  try:value=parse(texts[0])
  except (ValueError,TypeError):pass
 if "structuredContent" in result:
  assert eq(result["structuredContent"],value)
  return result["structuredContent"]
 if required:assert value is not None
 return value
def analysis(call):
 p=payload(call)
 return {"provider_report":p,"analysis_stdout":parse(p["report"]["stdout"])}

def complete_bundle_equality(before,after):
 return eq(before["embedded_result"],after["embedded_result"]) if (
  before["complete_bundle"] and after["complete_bundle"]) else None

def full_controller_evidence():
 root=BASE/HARNESS_DIR
 launch_workspace=Path(qualification["workspace"])
 assert launch_workspace.is_absolute() and ".." not in launch_workspace.parts
 declared=qualification["controller_sessions"]
 assert qualification["expected_controller_sessions"]==5 and len(declared)==5
 assert len({item["session_id"] for item in declared})==5
 controller_facts=[];controller_wires={};owner_identities=set()
 for item in declared:
  sid=item["session_id"]
  assert re.fullmatch(r"controller-[0-9a-f]{32}",sid)
  receipt=item["receipt"]
  assert receipt["session_id"]==sid and item["normal_close"] is True
  assert receipt["schema"]=="hepta.rea.ghidra-controller-session.v1"
  assert receipt["construction_succeeded"] is True and receipt["normal_close"] is True
  assert receipt["construction_error"] is None and receipt["close_error"] is None and receipt["capture_errors"]==[]
  assert receipt["capture_root"]==str(launch_workspace/sid)
  assert eq(parse(read(root/sid/"session.json")),receipt)
  artifacts=receipt["artifacts"]
  expected_artifacts={"launch":"launch.json","close":"close.json","wire_index":"wire.jsonl",
   "stderr":"stderr.log","initialization_failure":"initialization-failure.json"}
  assert set(artifacts)==set(expected_artifacts)
  for key,item_ref in artifacts.items():
   if item_ref is None:
    assert key=="initialization_failure"
   else:
    assert item_ref["path"]==sid+"/"+expected_artifacts[key]
    ref(root,item_ref)
  owner_close=parse(ref(root,artifacts["close"]))
  assert eq(owner_close,receipt["owner_close"])
  assert type(owner_close["returncode"]) is int and owner_close["returncode"]==0 and owner_close["forced_cleanup"]==[]
  assert all(owner_close[field] is True for field in ("reader_stopped","owner_pidfd_exited","process_group_gone"))
  launch=parse(ref(root,artifacts["launch"]))
  assert eq(launch["owner"],owner_close["owner"])
  owner=launch["owner"]
  assert set(owner)=={"pid","parent_pid","process_group","start_time_ticks"}
  assert all(type(owner[key]) is int and owner[key]>0 for key in owner)
  assert launch["pid"]==owner["pid"]==owner["process_group"]
  assert (owner["pid"],owner["start_time_ticks"]) not in owner_identities
  owner_identities.add((owner["pid"],owner["start_time_ticks"]))
  assert eq(launch["argv"],[str(launch_workspace/"hepta-runtime-qualified"),"mcp",
   "--runtime-config",str(launch_workspace/"config.json")])
  assert launch["cwd"]==str(launch_workspace)
  assert eq(launch["environment"],{"PATH":"/usr/bin:/bin","LANG":"C.UTF-8",
   "HEPTA_EFFECT_OWNER_FENCE_DIR":str(launch_workspace/"authority"),
   "HEPTA_EFFECT_OWNER_SELF":"v4","HEPTA_EFFECT_OWNER_FENCE_REQUIRED":"1"})
  assert artifacts["wire_index"]["path"]==sid+"/wire.jsonl"
  entries=[parse(line) for line in ref(root,artifacts["wire_index"]).splitlines() if line]
  assert 1<=len(entries)<=16384
  sent={};received={};ordered=[];total=0;last=0;initialized=False
  for ordinal,entry in enumerate(entries):
   direction=entry["direction"]
   assert direction in ("sent","received")
   assert entry["path"]==f"wire-{ordinal:04d}-{direction}.json.gz"
   assert type(entry["monotonic_ns"]) is int and entry["monotonic_ns"]>=last
   last=entry["monotonic_ns"]
   compressed=read(root/sid/entry["path"],entry["gzip_sha256"])
   assert len(compressed)==entry["gzip_bytes"]
   raw=reader.read_gzip(root/sid,{key:entry[key] for key in reader.GZIP_KEYS})
   total+=len(raw);assert total<=256*1024*1024
   assert raw.endswith(b"\n") and b"\n" not in raw[:-1]
   message=parse(raw)
   assert message["jsonrpc"]=="2.0"
   frame={"entry":entry,"message":message,"raw":raw,"ordinal":ordinal}
   ordered.append(frame)
   if "id" not in message:
    assert not initialized and direction=="sent" and eq(message,{
     "jsonrpc":"2.0","method":"notifications/initialized","params":{}})
    assert len(sent)==len(received)==1 and next(iter(sent.values()))["message"]["method"]=="initialize"
    assert "result" in next(iter(received.values()))["message"]
    initialized=True
    continue
   identifier=message["id"]
   assert type(identifier) is int and identifier>0
   if direction=="sent":
    assert identifier not in sent and set(sent)==set(received)
    assert set(message)=={"jsonrpc","id","method","params"}
    if not sent:
     assert not initialized and message["method"]=="initialize" and eq(message["params"],{
      "protocolVersion":"2026-07-28","capabilities":{},
      "clientInfo":{"name":"hepta-rea-operation-qualification","version":"1"}})
    else:
     assert initialized and message["method"]=="tools/call"
    sent[identifier]=frame
   else:
    assert identifier in sent and identifier not in received
    assert set(message) in ({"jsonrpc","id","result"},{"jsonrpc","id","error"})
    received[identifier]=frame
  assert initialized and set(sent)==set(received)
  controller_wires[sid]={"sent":sent,"received":received,"ordered":ordered,"owner":owner_close["owner"]}
  controller_facts.append({"session_id":sid,"owner":owner_close["owner"],"normal_close":True,
   "frames":len(entries),"raw_wire_bytes":total,"requests":len(sent),"artifacts":artifacts,
   "scope":"original controller owner only; durable jobs and JVM helpers use separate proofs"})
 observations=qualification["native_evidence_observations"]
 assert len(observations)==2 and {item["phase"] for item in observations}=={"before-provider","after-provider"}
 observed={};all_keys={"artifacts","providers","environments","scenarios","captures","unknowns","records"}
 for item in observations:
  phase=item["phase"];sid=item["session_id"]
  assert sid in controller_wires and item["capture_root"]==str(launch_workspace/sid)
  assert eq(item["owner"],controller_wires[sid]["owner"])
  assert eq(parse(read(root/("native-evidence-"+phase+"-observation.json"))),item)
  assert eq(item["request"],{"name":"rea_get_evidence_bundle","arguments":{}})
  wire=controller_wires[sid]
  requests=[frame for frame in wire["sent"].values() if frame["message"]["method"]=="tools/call"
   and eq(frame["message"]["params"],item["request"])]
  assert len(requests)==2
  request=requests[0 if phase=="before-provider" else 1]
  response=wire["received"][request["message"]["id"]]
  assert "result" in response["message"]
  result=response["message"]["result"]
  assert eq(parse(ref(root,item["artifacts"]["call-tool-result"])),result)
  texts=[value["text"].encode() for value in result.get("content",[])
   if isinstance(value,dict) and value.get("type")=="text" and isinstance(value.get("text"),str)]
  parsed=None
  if len(texts)==1:
   if "opaque_text_sha256" in item:assert item["opaque_text_sha256"]==digest(texts[0])
   try:parsed=parse(texts[0])
   except (ValueError,TypeError):pass
  if "parsed-result" in item["artifacts"]:
   assert eq(parse(ref(root,item["artifacts"]["parsed-result"])),parsed)
  embedded=parsed.get("result") if isinstance(parsed,dict) else None
  complete=(("isError" not in result or result["isError"] is False)
   and isinstance(embedded,dict) and set(embedded)==all_keys
   and all(isinstance(embedded[key],list) for key in all_keys)
   and "structuredContent" in result and eq(result["structuredContent"],parsed))
  if "bundle" in item["artifacts"]:
   assert eq(parse(ref(root,item["artifacts"]["bundle"])),embedded)
  if complete:
   assert item["status"]=="CAPTURED_COMPLETE_BUNDLE"
   assert eq(item["manifest_counts"],{key:len(embedded[key]) for key in sorted(all_keys)})
   assert item["record_count"]==len(embedded["records"]) and item["unknown_count"]==len(embedded["unknowns"])
  else:
   assert item["status"] in ("CAPTURED_TOOL_ERROR","CAPTURED_INCOMPATIBLE_RESULT")
  result_bytes,result_range=reader.member_bytes(response["raw"],["result"])
  observed[phase]={"observation":item,"session_id":sid,"request":request,"response":response,
   "result_bytes":result_bytes,"result_range":result_range,"texts":texts,"payload":parsed,
   "embedded_result":embedded,"complete_bundle":complete}
 before,after=observed["before-provider"],observed["after-provider"]
 assert before["session_id"]==after["session_id"]
 assert before["response"]["ordinal"]<after["request"]["ordinal"]
 wire=controller_wires[before["session_id"]]
 completed=[]
 for name in ("functions","function","xrefs","decompile"):
  retained=payload(N[name+"-entry"])
  matches=[]
  for request in wire["sent"].values():
   message=request["message"]
   if not (before["response"]["ordinal"]<request["ordinal"]<after["request"]["ordinal"]):continue
   if message["method"]!="tools/call" or not eq(message["params"],{
       "name":"rea_static_read","arguments":N[name+"-entry"]["arguments"]}):continue
   response=wire["received"][message["id"]]
   actual=response["message"]
   if "error" in actual or not isinstance(actual.get("result"),dict):continue
   if "isError" in actual["result"] and actual["result"]["isError"] is not False:continue
   value=payload({"response_parsed":response["message"]},False)
   if (isinstance(value,dict) and value.get("complete") is True and eq(value,retained)
       and before["response"]["ordinal"]<response["ordinal"]<after["request"]["ordinal"]):
    complete_equal=eq(actual["result"],N[name+"-entry"]["response_parsed"]["result"])
    matches.append({"request_id":message["id"],"request_ordinal":request["ordinal"],
     "response_ordinal":response["ordinal"],"response_frame":response["entry"],
     "retained_capture_call":name+"-entry","parsed_retained_report_equal":True,
     "complete_calltoolresult_equal":complete_equal,
     "complete_calltoolresult_status":"MATCH" if complete_equal else "DIFF"})
  assert matches,"same original controller did not observe the completed retained "+name+" result"
  completed.append({"operation":name,"completed_original_reads":matches})
 return {"controllers":controller_facts,"phases":observed,
  "same_controller_completed_provider_reads":completed}

full_native=full_controller_evidence()
def source_description(call):
 return {"session":call["_session"],"case":call["id"],"tool":call["tool"],"arguments":call["arguments"],
  "request_frame":call["request_wire"],"response_frame":call["response_wire"],
  "result_raw":call.get("result_raw"),"error_raw":call.get("error_raw"),
  "structured_content_raw":call.get("structured_content_raw"),"content_text_utf8":call["content_text_utf8"]}

rows=[]
counts=collections.Counter()
def emit(layer,pair,opath,oval,npath,nval,have_o=True,have_n=True,mapping="identical JSON pointer"):
 status=("MATCH" if eq(oval,nval) else "DIFF") if have_o and have_n else ("ORIGINAL_ONLY" if have_o else "NATIVE_ONLY")
 item={"layer":layer,"operation_pair":pair,"status":status,"mapping":mapping,
       "original":({"pointer":opath,"value":oval,"json_type":type(oval).__name__} if have_o else None),
       "native":({"pointer":npath,"value":nval,"json_type":type(nval).__name__} if have_n else None)}
 rows.append(item);counts[(layer,pair,status)]+=1
 return status
def positional(layer,pair,a,b):
 left=dict(leaves(a));right=dict(leaves(b))
 for p in sorted(left.keys()|right.keys()):
  emit(layer,pair,p,left.get(p),p,right.get(p),p in left,p in right)
def mapped_semantics(pair,ocall,ncall,kind):
 a=payload(ocall);b=analysis(ncall)
 al=dict(leaves(a));bl=dict(leaves(b));used_a=set();used_b=set()
 mappings=[]
 def m(ap,bp,reason="explicit field-name mapping"):
  if ap not in al or bp not in bl:return
  mappings.append({"original_pointer":ap,"native_pointer":bp,"rule":reason})
  emit("mapped_complete_evidence_vs_native_report",pair,ap,al[ap],bp,bl[bp],mapping=reason)
  used_a.add(ap);used_b.add(bp)
 for ap,bp in (("/subject/digest/sha256","/analysis_stdout/source_sha256"),
               ("/provider/id","/provider_report/report/provider"),
               ("/provider/version","/analysis_stdout/engine_version"),
               ("/operation","/analysis_stdout/operation"),
               ("/parameters/procedure","/analysis_stdout/function_address_requested")):m(ap,bp)
 for key in ("path","canonical_path","original_path"):
  bp="/provider_report/report/subject/"+key
  if bp in bl:m("/subject/local_path",bp);break
 def f(ap,bp,address="entrypoint"):
  for x,y in ((address,"entry_address"),("name","name"),("signature","signature"),
              ("classification/external","external"),("classification/thunk","thunk"),
              ("body/total_bytes","body_address_count")):
   m(ap+"/"+x,bp+"/"+y,"explicit selected-function field mapping; numeric/string encodings remain distinct")
  ar=get(a,ap).get("body",{}).get("ranges",[])
  br=get(b,bp).get("body_ranges",[])
  for index in range(min(len(ar),len(br))):
   for x,y in (("start","min_address"),("end","max_address")):
    m(ap+"/body/ranges/"+str(index)+"/"+x,bp+"/body_ranges/"+str(index)+"/"+y)
 if kind=="functions":
  lookup={}
  for group in ("functions","external_functions"):
   for index,row in enumerate(b["analysis_stdout"][group]):
    assert row["entry_address"] not in lookup
    lookup[row["entry_address"]]=("/analysis_stdout/"+group+"/"+str(index),row)
  for index,row in enumerate(a["normalized_result"]):
   if row["address"] not in lookup:continue
   bp,_=lookup[row["address"]];ap="/normalized_result/"+str(index)
   for x,y in (("address","entry_address"),("value","name"),("procedure/external","external"),("procedure/thunk","thunk")):
    m(ap+"/"+x,bp+"/"+y,"join internal/external arrays by exact address; no ordering or absent metadata inferred")
 elif kind=="function":
  f("/normalized_result","/analysis_stdout/function")
 elif kind=="decompile":
  m("/normalized_result","/analysis_stdout/c_code","exact complete C string, including leading/trailing whitespace")
 elif kind in ("incoming","outgoing"):
  f("/normalized_result/procedure","/analysis_stdout/function","address")
  left=a["normalized_result"]["references"]
  right=b["analysis_stdout"][kind+"_references"]
  def ok(row):return (row["source_address"],row["kind"]["type"],row["kind"]["operand_index"],row["kind"]["primary"])
  def nk(row):return (row["from_address"],row["reference_type"],row["operand_index"],row["primary"])
  lc=collections.Counter(ok(row) for row in left);rc=collections.Counter(nk(row) for row in right)
  rid={nk(row):i for i,row in enumerate(right) if rc[nk(row)]==1}
  for i,row in enumerate(left):
   key=ok(row)
   if lc[key]!=1 or key not in rid:continue
   j=rid[key];ap="/normalized_result/references/"+str(i);bp="/analysis_stdout/"+kind+"_references/"+str(j)
   for x,y in (("source_address","from_address"),("target_address","to_address"),("kind/type","reference_type"),
               ("kind/operand_index","operand_index"),("kind/call","call"),("kind/primary","primary")):
    m(ap+"/"+x,bp+"/"+y,"unique (source,type,operand,primary) join; target encoding remains an exact comparison")
 for p in sorted(al.keys()-used_a):
  emit("mapped_complete_evidence_vs_native_report",pair,p,al[p],None,None,have_n=False,
       mapping="no admitted same-level native field in this captured report")
 for p in sorted(bl.keys()-used_b):
  emit("mapped_complete_evidence_vs_native_report",pair,None,None,p,bl[p],have_o=False,
       mapping="native operational/analysis field has no declared original Evidence counterpart")
 assert {r["original"]["pointer"] for r in rows if r["layer"]=="mapped_complete_evidence_vs_native_report" and r["operation_pair"]==pair and r["original"]}==al.keys()
 assert {r["native"]["pointer"] for r in rows if r["layer"]=="mapped_complete_evidence_vs_native_report" and r["operation_pair"]==pair and r["native"]}==bl.keys()
 return {"pair":pair,"original_leaf_count":len(al),"native_leaf_count":len(bl),"mapped_original_leaf_count":len(used_a),
         "mapped_native_leaf_count":len(used_b),"all_original_and_native_leaves_accounted_for":True,"mappings":mappings}

pairs=[
 ("functions","functions","functions-entry","functions"),
 ("function-entry","function-entry","function-entry","function"),
 ("function-interior","function-interior","function-interior","function"),
 ("incoming-entry","incoming-entry","xrefs-entry","incoming"),
 ("outgoing-entry","outgoing-entry","xrefs-entry","outgoing"),
 ("incoming-interior","incoming-interior","xrefs-interior","incoming"),
 ("outgoing-interior","outgoing-interior","xrefs-interior","outgoing"),
 ("decompile-entry","decompile-entry","decompile-entry","decompile"),
 ("decompile-interior","decompile-interior","decompile-interior","decompile"),
 ("unmapped-address","function-unmapped","function-unmapped",None),
 ("extra-field-refusal","invalid-extra-field","invalid-selector-3",None)]
raw_comparisons=[];mapping_specs=[]
for name,ol,nl,kind in pairs:
 o,n=O[ol],N[nl]
 orpc=o["response_parsed"];nrpc=n["response_parsed"]
 positional("complete_jsonrpc_response_fields",name,orpc,nrpc)
 positional("complete_calltoolresult_fields",name,orpc.get("result"),nrpc.get("result"))
 ot=[ref(o["_root"],r) for r in o["content_text_utf8"]]
 nt=[ref(n["_root"],r) for r in n["content_text_utf8"]]
 oraw=ref(o["_root"],o["result_raw"]) if "result_raw" in o else None
 nraw=ref(n["_root"],n["result_raw"]) if "result_raw" in n else None
 raw_comparisons.append({"pair":name,"pair_layer":"declared_provider_operation","original":source_description(o),"native":source_description(n),
  "original_frame_sha256":digest(o["_response_bytes"]),"native_frame_sha256":digest(n["_response_bytes"]),
  "original_frame_bytes":len(o["_response_bytes"]),"native_frame_bytes":len(n["_response_bytes"]),
  "raw_jsonrpc_frame_equal":o["_response_bytes"]==n["_response_bytes"],
  "complete_calltoolresult_bytes_equal":oraw==nraw,
  "complete_calltoolresult_parsed_fields_equal":eq(orpc.get("result"),nrpc.get("result")),
  "opaque_content_text_utf8_equal":ot==nt,
  "opaque_original":[{"bytes":len(t),"sha256":digest(t)} for t in ot],
  "opaque_native":[{"bytes":len(t),"sha256":digest(t)} for t in nt],
  "scope":("selected success operation mapping" if kind else
           ("same unowned memory selector 0x0, different API lifecycle/error surfaces" if name=="unmapped-address"
            else "unknown field flags=caller-script on selected procedure operations; operation tool names differ"))})
 if kind:mapping_specs.append(mapped_semantics(name,o,n,kind))
 else:
  # Optional JSON decoding is a separately identified diagnostic. Opaque bytes above remain untouched.
  oa=payload(o,False);na=payload(n,False)
  positional("decoded_error_or_retained_report_fields",name,
             oa if oa is not None else {"opaque_text":[x.decode() for x in ot]},
             na if na is not None else {"opaque_text":[x.decode() for x in nt]})

projections={}
old=payload(O["functions"])["normalized_result"]
new=analysis(N["functions-entry"])["analysis_stdout"]
lookup={row["entry_address"]:row for row in new["functions"]+new["external_functions"]}
inventory=[]
for row in old:
 newrow=lookup.get(row["address"])
 inventory.append({"address":row["address"],"native_present":newrow is not None,
  "exact_common_fields":{key:(newrow is not None and eq(value,newrow[nkey])) for key,value,nkey in (
   ("address",row["address"],"entry_address"),("name",row["value"],"name"),
   ("external",row["procedure"]["external"],"external"),("thunk",row["procedure"]["thunk"],"thunk"))},
  "original_only_metadata":{"symbol":row["symbol"],"thunk_target":row["procedure"]["thunk_target"]}})
projections["functions"]={"original_count":len(old),"native_internal_count":len(new["functions"]),
 "native_external_count":len(new["external_functions"]),"same_address_set":set(lookup)=={x["address"] for x in old},
 "exact_common_field_count":sum(sum(x["exact_common_fields"].values()) for x in inventory),
 "expected_common_field_count":len(old)*4,"rows":inventory,
 "not_qualified_as":"complete inventory/Evidence equality; the old diagnostic six-field projection is not this native functions schema"}
code_rows=[];ref_rows=[]
for suffix in ("entry","interior"):
 text=payload(O["decompile-"+suffix])["normalized_result"]
 native_text=analysis(N["decompile-"+suffix])["analysis_stdout"]["c_code"]
 code_rows.append({"selector":O["decompile-"+suffix]["arguments"]["procedure"],"original_bytes":len(text.encode()),
   "native_bytes":len(native_text.encode()),"original_sha256":digest(text.encode()),"native_sha256":digest(native_text.encode()),
   "complete_text_bytes_equal":text.encode()==native_text.encode()})
 for direction in ("incoming","outgoing"):
  left=payload(O[direction+"-"+suffix])["normalized_result"]["references"]
  right=analysis(N["xrefs-"+suffix])["analysis_stdout"][direction+"_references"]
  lfields=[{"source":x["source_address"],"target":x["target_address"],"type":x["kind"]["type"],
           "operand":x["kind"]["operand_index"],"call":x["kind"]["call"],"primary":x["kind"]["primary"]} for x in left]
  rfields=[{"source":x["from_address"],"target":x["to_address"],"type":x["reference_type"],
           "operand":x["operand_index"],"call":x["call"],"primary":x["primary"]} for x in right]
  ref_rows.append({"selector":O[direction+"-"+suffix]["arguments"]["procedure"],"direction":direction,
   "original":lfields,"native":rfields,"ordered_projection_equal":eq(lfields,rfields),
   "original_count":len(left),"native_count":len(right)})
projections["decompile"]=code_rows
projections["references"]=ref_rows

def compare_actual_bundle_tool(name,original_call,phase,scope):
 observed=full_native["phases"][phase]
 original_rpc=original_call["response_parsed"]
 native_rpc=observed["response"]["message"]
 positional("complete_jsonrpc_response_fields",name,original_rpc,native_rpc)
 positional("complete_calltoolresult_fields",name,original_rpc["result"],native_rpc["result"])
 original_result=ref(original_call["_root"],original_call["result_raw"])
 original_texts=[ref(original_call["_root"],item) for item in original_call["content_text_utf8"]]
 raw_comparisons.append({"pair":name,"pair_layer":"complete_evidence_tool","original":source_description(original_call),"native":{
   "session":observed["session_id"],"request_frame":observed["request"]["entry"],
   "response_frame":observed["response"]["entry"],"request":observed["request"]["message"],
   "result_source_frame_range":observed["result_range"],"observation":observed["observation"]},
  "original_frame_sha256":digest(original_call["_response_bytes"]),
  "native_frame_sha256":digest(observed["response"]["raw"]),
  "original_frame_bytes":len(original_call["_response_bytes"]),"native_frame_bytes":len(observed["response"]["raw"]),
  "raw_jsonrpc_frame_equal":original_call["_response_bytes"]==observed["response"]["raw"],
  "complete_calltoolresult_bytes_equal":original_result==observed["result_bytes"],
  "complete_calltoolresult_parsed_fields_equal":eq(original_rpc["result"],native_rpc["result"]),
  "opaque_content_text_utf8_equal":original_texts==observed["texts"],
  "opaque_original":[{"bytes":len(item),"sha256":digest(item)} for item in original_texts],
  "opaque_native":[{"bytes":len(item),"sha256":digest(item)} for item in observed["texts"]],"scope":scope})
compare_actual_bundle_tool("empty-bundle-before-work",I["empty-before-import"],"before-provider",
 "fresh empty namespaces observed directly; original fresh import session and native pre-provider session")
compare_actual_bundle_tool("complete-bundle-after-provider",O["bundle-complete"],"after-provider",
 "actual complete bundle after each recorded operation history; histories differ and are not asserted equivalent")
after_bundle=full_native["phases"]["after-provider"]
before_bundle=full_native["phases"]["before-provider"]
if after_bundle["complete_bundle"]:
 positional("complete_evidence_bundle_capture","complete-bundle",bundle,after_bundle["embedded_result"])
else:
 for pointer,value in leaves(bundle):
  emit("complete_evidence_bundle_capture","complete-bundle",pointer,value,None,None,have_n=False,
   mapping="native Evidence tool was sampled but did not return a compatible complete bundle; actual response kept separately")
bundle_state={"original_records":len(bundle["records"]),
 "original_bundle_sha256":PINS["mcp-original-c9-r1/original-complete.bundle.json"],
 "original_bundle_bytes":len(cache["mcp-original-c9-r1/original-complete.bundle.json"]),
 "native_samples":{phase:{"session_id":item["session_id"],"complete_bundle":item["complete_bundle"],
    "actual_record_count":len(item["embedded_result"]["records"]) if item["complete_bundle"] else None,
    "actual_unknown_count":len(item["embedded_result"]["unknowns"]) if item["complete_bundle"] else None,
    "observation":item["observation"],"request_frame":item["request"]["entry"],"response_frame":item["response"]["entry"]}
  for phase,item in full_native["phases"].items()},
 "same_controller_completed_provider_reads":full_native["same_controller_completed_provider_reads"],
 "original_and_native_tool_histories_are_identical":False,
 "native_before_after_parsed_bundle_equal":complete_bundle_equality(before_bundle,after_bundle),
 "native_after_complete_bundle_equals_original_export":after_bundle["complete_bundle"] and eq(bundle,after_bundle["embedded_result"]),
 "native_report_evidence_compatibility_flags":[payload(N[x])["rea_evidence_compatible"] for x in ("functions-entry","function-entry","xrefs-entry","decompile-entry")],
 "complete_upstream_evidence_qualified":False,
 "complete_bundle_parity":"MATCH_AT_THIS_CAPTURED_VALUE_LAYER" if after_bundle["complete_bundle"] and eq(bundle,after_bundle["embedded_result"]) else "DIFF",
 "no_provider_report_substitution":True,"all_original_bundle_leaves_listed":True}
assert eq(payload(O["bundle-complete"])["result"],bundle)
assert eq(payload(O["bundle-after-export"])["result"],bundle)
assert eq(payload(I["complete-after-import"])["result"],bundle)
original_checks=[
 eq(payload(O["inventory-page-repeat"]),payload(O["inventory-page-0"])),
 eq(payload(O["bundle-complete"])["result"],bundle),
 eq(payload(O["bundle-after-export"])["result"],bundle),
 payload(I["empty-before-import"])["result"]["records"]==[],
 eq(payload(I["complete-after-import"])["result"],payload(O["bundle-complete"])["result"]),
 eq(payload(I["complete-after-import"])["result"],bundle),
 eq(payload(I["page-after-import"]),payload(O["inventory-page-0"]))]
assert all(original_checks) and len(original_checks)==7
assert len(native["checks"])==23
native_checks=[]
for name in ("functions","function","xrefs","decompile"):
 saved=parse(ref(BASE/NATIVE_DIR,native["harness_inputs"][name+"-result.json"]))
 native_checks.append(eq(payload(N[name+"-entry"]),saved))
for name in ("function","xrefs","decompile"):
 saved=parse(ref(BASE/NATIVE_DIR,native["harness_inputs"]["interior-"+name+".json"]))
 native_checks.append(eq(payload(N[name+"-interior"]),saved["result"]))
saved=parse(ref(BASE/NATIVE_DIR,native["harness_inputs"]["no-function-refusal.json"]))
native_checks.append(eq(payload(N["function-unmapped"]),saved["result"]))
for name in ("same-key-conflict",)+tuple("invalid-selector-"+str(i) for i in range(4)):
 saved=parse(ref(BASE/NATIVE_DIR,native["harness_inputs"][name+".json"]))
 native_checks.append(eq(N[name]["response_parsed"]["result"],saved["call_tool_result"]))
def job_ids(call):
 p=payload(call)
 rows=p if isinstance(p,list) else p["jobs"]
 return sorted(x["id"] for x in rows)
before=job_ids(N["jobs-before-negative-replays"])
for i in range(5):native_checks.append(before==job_ids(N["jobs-after-negative-"+str(i)]))
assert len(native_checks)==18
assert state_rederived["comparison_count"]==23 and len(state_rederived["comparisons"])==23
state_non_directory=[item["equal"] for item in state_rederived["comparisons"] if item["category"]!="directory-membership"]
assert len(state_non_directory)==18
native_check_ids=[name+"-entry-report-exact" for name in ("functions","function","xrefs","decompile")]
native_check_ids += [name+"-interior-report-exact" for name in ("function","xrefs","decompile")]
native_check_ids += ["unmapped-retained-backend-error-exact"]
negative_names=("same-key-conflict",)+tuple("invalid-selector-"+str(i) for i in range(4))
native_check_ids += [name+"-calltool-result-exact" for name in negative_names]
native_check_ids += [name+"-no-new-job-identity" for name in negative_names]
assert len(set(native_check_ids))==18
assert eq(dict(zip(native_check_ids,native_checks)),{
 item["id"]:item["equal"] for item in state_rederived["comparisons"] if item["category"]!="directory-membership"})
native_directory_checks=[item["equal"] for item in state_rederived["comparisons"] if item["category"]=="directory-membership"]
assert len(native_directory_checks)==5
cancel=original["cancellation"]
sid="original-cancel";entries=sessions[sid][1]
sent=[(e,m) for e,m in entries if e["direction"]=="sent" and m.get("id")==cancel["request_id"]]
notifications=[(e,m) for e,m in entries if e["direction"]=="sent" and m.get("method")=="notifications/cancelled"]
replies=[(e,m) for e,m in entries if e["direction"]=="received" and m.get("id")==cancel["request_id"]]
assert len(sent)==1 and len(notifications)==1 and notifications[0][1]["params"]["requestId"]==cancel["request_id"]
assert sent[0][1]["params"]==cancel["request"]
assert cancel["live_witness"]["observed_ns"]<=notifications[0][0]["monotonic_ns"]
assert replies==[]
assert eq(payload(C["bundle-before-cancel"])["result"],payload(C["bundle-after-cancel"])["result"])
cancellation={"attempts":cancel["attempts"],"observed_status":cancel["status"],"all_wire_frames_checked_after_normal_close":True,
 "original_request_frames":len(sent),"cancel_notifications":len(notifications),"original_request_responses":len(replies),
 "successful_original_request_responses":0,"complete_bundle_unchanged":True,"live_witness":cancel["live_witness"],
 "causal_or_durable_job_equivalence_claimed":False,"native_durable_job_semantics_available":False}
unmapped=payload(O["function-unmapped"],False)
diagnostic_text=unmapped["error"]["details"]["diagnostics"]["stdout"]["text"]
assert "REA no-return fix: cleared=0 sites=0 refit=0" in diagnostic_text
policy={"schema":"hepta.rea.ghidra-complete-result-comparison-policy.v1",
 "candidate":PLAN["source_commit"],"complete_parity_qualified":False,
 "statuses":{"MATCH":"exact typed field equality under a declared pointer mapping",
 "DIFF":"both fields are present and their typed values differ","ORIGINAL_ONLY":"no declared native counterpart in this captured comparison layer",
 "NATIVE_ONLY":"no declared original counterpart in this captured comparison layer"},
 "opaque_policy":"Content text is compared as exact UTF-8 bytes separately. JSON decoding is only an additional explicitly named analysis layer.",
 "frame_policy":"Complete raw JSON-RPC response and CallToolResult byte identities are retained; identifiers, metadata, paths and formatting are not removed.",
 "field_policy":"Every leaf including empty arrays/objects of both mapped documents is accounted for. Explicit many-to-one aliases are visible; counts are per declared pair, not a capability score.",
 "negative_pairing":"Only unmapped-address and flags extra-field have analogous recorded pairs. Other negative inputs are unpaired, not invented or silently coerced.",
 "native_complete_evidence":"Same live native controller was sampled before and after entry Provider operations. Compare actual complete bundle separately; original bundle contains its own explicitly different operation history.",
 "configured_environment":"Same fixed Ghidra 12.1.4 archive, JDK, and main ELF bytes; original default auto-analysis configuration is source-supported. Its entire 146-option snapshot was not directly sampled.",
 "no_return_repair":"Original C9 diagnostics directly report cleared=0 sites=0 refit=0 for this fixture. Native does not execute NoReturnFix. Other inputs remain open."}
negative_cases={"original":[source_description(O[x])|{"response":O[x]["response_parsed"]} for x in ("function-unmapped","invalid-selector-type","invalid-extra-field")],
 "native":[source_description(N[x])|{"response":N[x]["response_parsed"]} for x in ("function-unmapped","same-key-conflict")+tuple("invalid-selector-"+str(i) for i in range(4))],
 "unpaired_original":["invalid-selector-type"],"unpaired_native":["same-key-conflict","invalid-selector-0","invalid-selector-1","invalid-selector-2"],
 "no_same_input_parity_claim_for_unpaired_cases":True}
for key,item in list(manifest.items()):
 assert read(BASE/key,item["sha256"])==cache[key],("input changed after derivation",key)
raw=(b"".join((json.dumps(row,ensure_ascii=True,sort_keys=True,separators=(",",":"),allow_nan=False)+"\n").encode() for row in rows))
compressed=gzip.compress(raw,mtime=0)
(OUT/"field-differences.jsonl.gz").write_bytes(compressed)
field_ref={"path":"field-differences.jsonl.gz","bytes":len(compressed),"sha256":digest(compressed),
 "uncompressed_bytes":len(raw),"uncompressed_sha256":digest(raw),"rows":len(rows)}
artifacts={
 "policy":save("comparison-policy.json",policy),
 "raw_and_opaque":save("raw-and-opaque-comparisons.json",raw_comparisons),
 "mapping_definitions":save("mapping-definitions.json",mapping_specs),
 "projections":save("mapped-observations.json",projections),
 "complete_evidence":save("complete-evidence-layer.json",bundle_state),
 "negative_cases":save("negative-cases.json",negative_cases),
 "cancellation":save("cancellation-observation.json",cancellation),
 "field_differences":field_ref,
 "wire_verification":save("wire-verification.json",{"sessions":wire_facts,
  "original_roundtrip_checks_rederived":len(original_checks),"original_roundtrip_checks_passed":sum(original_checks),
  "native_report_error_and_registry_checks_rederived":len(native_checks),"native_rederived_checks_passed":sum(native_checks),
  "native_directory_snapshot_checks":{"comparisons":5,"passed":sum(native_directory_checks),
   "separate_consumer":PLAN["state_consumer_summary"],"summary_sha256":PINS[PLAN["state_consumer_summary"]],
   "overall_status":state_rederived["status"],"adjacent_membership_status":state_rederived["adjacent_membership_status"]},
  "capture_clients_normal_close":True,"native_full_controllers":full_native["controllers"],"recorded_descendant_observations":sum(x["observed_descendants"] for x in wire_facts),
  "process_birth_history_complete":False}),
 "independent_state_consumer":save("negative-state-assessment-rederived.json",state_rederived),
 "full_controllers":save("full-controller-evidence.json",{"controllers":full_native["controllers"],
   "samples":bundle_state["native_samples"],"completed_original_provider_reads":full_native["same_controller_completed_provider_reads"]}),
 "inputs":save("inputs-manifest.json",{"files":manifest,"source_commit":native["source_commit"],
   "original_source_commit":original["source_commit"],"source_and_capture_plan_sha256":args.plan_sha256,
   "script_sha256":args.script_sha256,"pinned_r4_reader_sha256":READER_SHA})}
by_layer=collections.defaultdict(collections.Counter)
for (layer,pair,status),number in counts.items():by_layer[layer][status]+=number
def result_totals(values):
 return {"declared_pairs":len(values),
  "full_calltoolresult_byte_matches":sum(item["complete_calltoolresult_bytes_equal"] for item in values),
  "full_calltoolresult_parsed_matches":sum(item["complete_calltoolresult_parsed_fields_equal"] for item in values),
  "opaque_text_matches":sum(item["opaque_content_text_utf8_equal"] for item in values),
  "raw_frame_matches":sum(item["raw_jsonrpc_frame_equal"] for item in values)}
summary={"schema":"hepta.rea.ghidra-complete-result-differential.v1","candidate":PLAN["source_commit"],
 "runtime_sha256":qualification["runtime_sha256"],"qualified":False,"complete_upstream_parity_qualified":False,
 "build_identity":build_identity,
 "native_full_harness":{"checks":len(qualification["checks"]),"qualified_for_its_fixed_scope":qualification["qualified"],"full_parity":False},
 "native_raw_capture":{"producer_comparisons":23,"producer_differences":sum(not item["equal"] for item in native["checks"]),
  "report_error_registry_rederived":18,"directory_membership_rederived":5,
  "independently_rederived_comparisons":23,"independently_rederived_differences":23-sum(native_checks)-sum(native_directory_checks),
  "independent_state_consumer_status":state_rederived["status"],
  "adjacent_membership_status":state_rederived["adjacent_membership_status"],
  "directory_comparisons_only_retained_as_producer_checks":0},
 "original_evidence_roundtrip":{"parsed_value_or_predicate_checks":7,"parsed_value_or_predicate_differences":0,
  "cold_import_complete_calltoolresult_and_opaque_equal":False,
  "original_fixed_layer_report_sha256":PINS["peer-derived-c9-r1/original-roundtrip-comparison-layers.json"],"complete_export_bytes":bundle_state["original_bundle_bytes"],"records":len(bundle["records"])},
 "full_cross_implementation_comparisons":result_totals([item for item in raw_comparisons if item["pair_layer"]=="declared_provider_operation"]),
 "additional_evidence_tool_comparisons":result_totals([item for item in raw_comparisons if item["pair_layer"]=="complete_evidence_tool"]),
 "field_row_counts_by_layer":{k:dict(v) for k,v in by_layer.items()},"field_counts_are_not_a_qualification_score":True,
 "function_inventory_projection":{"original_rows":len(old),"native_rows":len(lookup),"common_fields_per_row":4,"matched_common_fields":projections["functions"]["exact_common_field_count"],"original_symbol_and_thunk_target_metadata_missing_in_native_functions":True},
 "complete_c_text_matches":sum(x["complete_text_bytes_equal"] for x in code_rows),"complete_c_text_comparisons":len(code_rows),
 "xref_projection_comparisons":len(ref_rows),
 "xref_ordered_projection_matches":sum(item["ordered_projection_equal"] for item in ref_rows),
 "xref_differences":[item for item in ref_rows if not item["ordered_projection_equal"]],
 "native_complete_evidence":bundle_state,
 "same_controller_retained_calltoolresult_comparisons":{
  "comparisons":sum(len(item["completed_original_reads"]) for item in full_native["same_controller_completed_provider_reads"]),
  "differences":sum(not witness["complete_calltoolresult_equal"]
   for item in full_native["same_controller_completed_provider_reads"] for witness in item["completed_original_reads"]),
  "scope":"Actual successful complete reads between samples; complete typed CallToolResult includes opaque text, and any parsed-only match remains an explicit DIFF."},
 "evidence_missing_fields":["original symbol metadata and thunk targets in native functions listing",
  "selected function basicblock_count, locals, symbol/provenance/body descriptive fields",
  "nested source_procedure/target_procedure and extended reference kinds/provenance",
  "original per-operation Evidence schema identity, confidence/authority/environment/locations/relationships/evidence links and exact error recovery metadata"],
 "cancellation":{k:cancellation[k] for k in ("attempts","observed_status","original_request_responses","complete_bundle_unchanged","causal_or_durable_job_equivalence_claimed")},
 "resource_close":{"capture_mcp_owners":4,"capture_owner_split":{"historical_original_c9":3,"current_native_readback":1},
  "capture_observed_descendants":sum(x["observed_descendants"] for x in wire_facts),
  "capture_owners_normal_close":True,"capture_observed_descendants_exited_without_fallback":True,
  "original_c9_census":PINS["c9-post-execution-owner-census.json"],
  "native_current_census":PINS[PLAN["native_census"]],
  "census_scope":"Pinned current and historical census records; this offline derivation does not repeat /proc or unit observations.",
  "native_full_controller_count":len(full_native["controllers"]),
  "native_full_controllers_normal_close":all(item["normal_close"] for item in full_native["controllers"]),
  "controller_receipts_do_not_replace_durable_job_or_jvm_cleanup":True},
 "artifacts":artifacts}
summary_ref=save("summary.json",summary)
readme="""# Complete original and native capture comparison

This is a lossless, explicitly layered offline derivation. It does not run a
runtime or engine and never changes the source captures. See summary.json for
actual comparisons, source identities and the explicit finite scope.

Complete CallToolResult, opaque text, JSON-RPC bytes and parsed field mappings
are separate layers. The original bundle's seven internal checks are parsed
value/predicate checks; its cold-import opaque text remains different because
of object member order. The fixed independent C9 layer report is retained as
an input, not replaced by a claim of raw equivalence.

The same live native controller is sampled before and after its entry Provider
operations, with exact wire requests and responses bound to the capture and
close receipt. Its actual Evidence is compared separately from Provider
reports. The original bundle came from its own recorded operation history;
these histories are documented, not silently treated as identical sequences.

Native raw checks include eight retained reads and five negative start replays.
Report/error/registry checks are independently rederived here. The separate
R4 state consumer binds all eleven raw membership samples and independently
checks the five directory comparisons; its result and inputs remain separate.

No result counts or source-field matches promote complete REA qualification.
Original NoReturnFix is directly observed as a no-op for this fixture only.
Original cancellation is the one historical C9 attempt; no new original
request or cancellation was executed by this derivation.
"""
(OUT/"README.md").write_text(readme)
print(json.dumps({"summary":summary_ref,"provider_comparison_pairs":summary["full_cross_implementation_comparisons"]["declared_pairs"],
 "additional_evidence_tool_pairs":summary["additional_evidence_tool_comparisons"]["declared_pairs"],
 "field_rows":len(rows),"field_rows_gzip":field_ref,
 "cross_calltoolresult_matches":summary["full_cross_implementation_comparisons"]["full_calltoolresult_byte_matches"],
 "original_records":len(bundle["records"]),"inventory_common_matches":projections["functions"]["exact_common_field_count"],
 "c_text_matches":summary["complete_c_text_matches"],"original_roundtrip_parsed_rederived":7,
 "native_report_error_registry_rederived":18,"qualified":False}))
