#!/usr/bin/env python3
# Copyright 2026 TrillionniumFoundation
# SPDX-License-Identifier: Apache-2.0
"""Package fixed R5/C9 evidence and replay only its frozen offline readers."""
from pathlib import Path, PurePosixPath
import copy
import datetime
import gzip
import hashlib
import io
import json
import os
import re
import stat
import subprocess
import sys
import tarfile
import time
import traceback

BASE = Path('/home/qian-qi/work/hepta-rea-ghidra-v4-ecb0b9-20261106-r1')
REPO = Path('/home/qian-qi/work/hepta-rea-family-ecb0b9d61c75-20261106')
COMMIT = 'fe3223cabbd2a8f1aa75a4ab57507bdb72291242'
OUT = BASE / 'r5-archive-replay-r1'
RELOCATED = OUT / 'relocated-inputs'
ARCHIVE = BASE / 'r5-raw-evidence.tar.gz'
MANIFEST = BASE / 'r5-raw-evidence-manifest.json'
VERIFICATION = BASE / 'r5-raw-evidence-verification.json'
RECEIPT = BASE / 'r5-archive-replay-invocation.json'
DIFF_SOURCE_SHA = 'fc968ead6031164d565cb7137d0892df62e908f68c4c7fc6813c074bded19a64'
STATE_SOURCE_SHA = '089849d73b315c242a20845cc325e29823592f7796047655ccbe52b583692ce3'
CAPTURE_SHA = '4c976fff29493ea65fcbd39ea25143a773fc717ab96d71682463a821dd593ea7'
ASSESSMENT_SHA = 'a53e0f95b1a171ca506097fad1892b4eccd904af7805ed8e9234afc502f10323'
SUMMARY_SHA = 'd23e0c27f730c7c54dcb4935af3c536e7d582ebeffc08498ea7a97b13aaff988'
FILE_CAP = 16 * 1024 * 1024
TOTAL_CAP = 128 * 1024 * 1024

def digest(raw):
    return hashlib.sha256(raw).hexdigest()

def read(path, expected=None):
    path = Path(path)
    assert path.resolve(strict=True) == path and not path.is_symlink(), str(path)
    before = path.lstat()
    assert stat.S_ISREG(before.st_mode) and before.st_nlink == 1
    assert 0 <= before.st_size <= FILE_CAP, (str(path), before.st_size)
    raw = path.read_bytes()
    after = path.lstat()
    assert (before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns, before.st_ctime_ns) == (
        after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns, after.st_ctime_ns)
    if expected is not None:
        assert digest(raw) == expected, (str(path), digest(raw), expected)
    return raw

def write_json(path, value):
    raw = (json.dumps(value, ensure_ascii=True, sort_keys=True, indent=2, allow_nan=False) + '\n').encode()
    with path.open('xb') as stream:
        stream.write(raw)
    return {'path': str(path), 'bytes': len(raw), 'sha256': digest(raw)}

def file_ref(path):
    raw = read(path)
    return {'path': str(path), 'bytes': len(raw), 'sha256': digest(raw)}

def safe_key(value):
    key = PurePosixPath(value)
    assert not key.is_absolute() and key.parts and str(key) == value
    assert all(part not in ('', '.', '..') for part in key.parts)
    assert not value.endswith('.hepta-lock')
    return value

def emit(event, **fields):
    print(json.dumps({'event': event, **fields}, sort_keys=True), flush=True)

def invoke(label, argv):
    start = time.monotonic_ns()
    with (OUT / (label + '.stdout.log')).open('xb') as stdout, (OUT / (label + '.stderr.log')).open('xb') as stderr:
        child = subprocess.run(argv, cwd=RELOCATED, stdin=subprocess.DEVNULL,
            stdout=stdout, stderr=stderr, timeout=45, check=False,
            env={'PATH': '/usr/bin:/bin', 'LANG': 'C.UTF-8', 'PYTHONDONTWRITEBYTECODE': '1'})
    value = {'argv': argv, 'cwd': str(RELOCATED), 'started_ns': start,
        'finished_ns': time.monotonic_ns(), 'returncode': child.returncode,
        'runtime_or_engine_started': False,
        'stdout': file_ref(OUT / (label + '.stdout.log')),
        'stderr': file_ref(OUT / (label + '.stderr.log'))}
    write_json(OUT / (label + '.invocation.json'), value)
    assert child.returncode == 0, (label, child.returncode)
    emit('offline_reader_finished', reader=label, returncode=child.returncode)
    return value

receipt = {'schema': 'hepta.rea.ghidra-r5-package-and-replay.v1',
    'started_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'runtime_or_engine_started': False, 'selected_source_written': False,
    'source_commit': COMMIT, 'stage': 'preflight', 'completed': False}
try:
    assert not any(x.exists() for x in (OUT, ARCHIVE, MANIFEST, VERIFICATION, RECEIPT))
    OUT.mkdir()
    read(BASE / 'derive_ghidra_final_diff_r1.py', DIFF_SOURCE_SHA)
    read(BASE / 'consume_r4_states.py', STATE_SOURCE_SHA)
    read(BASE / 'r5-full-result-diff-r1/summary.json', SUMMARY_SHA)
    frozen_inputs = json.loads(read(BASE / 'r5-full-result-diff-r1/inputs-manifest.json'))['files']
    selected = set()
    def add(path):
        path = Path(path)
        key = safe_key(str(path.relative_to(BASE)))
        if path.name.endswith('.hepta-lock'):
            return
        read(path)
        selected.add(key)
    def tree(path):
        assert path.is_dir() and not path.is_symlink() and path.resolve(strict=True) == path
        for current, dirs, files in os.walk(path, followlinks=False):
            for name in dirs:
                assert not (Path(current) / name).is_symlink()
            for name in files:
                if not name.endswith('.hepta-lock'):
                    add(Path(current) / name)
    for key, value in frozen_inputs.items():
        safe_key(key)
        raw = read(BASE / key, value['sha256'])
        assert len(raw) == value['bytes']
        selected.add(key)
    for name in ('consume_r4_states.py', 'derive_ghidra_final_diff_r1.py', 'ghidra_mcp_capture_r4.py'):
        add(BASE / name)
    for path in BASE.glob('r5-*'):
        if path.is_file() and path.suffix in ('.json', '.log') and not path.name.endswith('.hepta-lock'):
            add(path)
    add(Path(__file__).resolve())
    for name in ('mcp-native-r5-r1', 'mcp-native-wire-r5-r1', 'mcp-original-c9-r1'):
        for path in (BASE / name).iterdir():
            if path.is_file() and path.name != 'hepta-runtime-qualified' and not path.name.endswith('.hepta-lock'):
                add(path)
    controllers = [p for p in (BASE / 'mcp-native-r5-r1').iterdir()
        if re.fullmatch(r'controller-[0-9a-f]{32}', p.name)]
    assert len(controllers) == 5
    for path in controllers:
        tree(path)
    for name in ('mcp-native-wire-r5-r1/native-readback', 'mcp-native-wire-r5-r1/harness-inputs',
        'mcp-original-c9-r1/original-main', 'mcp-original-c9-r1/original-import',
        'mcp-original-c9-r1/original-cancel', 'native-r5-state-derived-r1',
        'r5-full-result-diff-r1', 'c9-source-snapshot'):
        tree(BASE / name)
    preflight = json.loads(read(BASE / 'r5-source-dependencies-preflight.json'))
    snapshot = BASE / 'r5-source-snapshot'
    assert not snapshot.exists()
    snapshot.mkdir()
    source_rows = []
    for item in preflight['files']:
        rel = item['path']
        raw = read(REPO / rel, item['sha256'])
        stored = subprocess.run(['/usr/bin/git', 'show', COMMIT + ':' + rel], cwd=REPO,
            stdin=subprocess.DEVNULL, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
            timeout=10, check=True).stdout
        assert raw == stored and len(raw) == item['bytes']
        target = snapshot / rel
        target.parent.mkdir(parents=True, exist_ok=True)
        with target.open('xb') as stream:
            stream.write(raw)
        source_rows.append(item)
    write_json(snapshot / 'manifest.json', {'schema': 'hepta.rea.ghidra-r5-direct-source-snapshot.v1',
        'source_commit': COMMIT, 'files': source_rows,
        'scope': 'Eleven declared direct execution dependencies, exact Git and actual preflight bytes; not the entire imported closure.'})
    tree(snapshot)
    with gzip.open(BASE / 'r5-full-result-diff-r1/field-differences.jsonl.gz', 'rt') as stream:
        mapped = [row for row in (json.loads(line) for line in stream)
            if row['layer'] == 'mapped_complete_evidence_vs_native_report' and row['status'] == 'DIFF']
    assert len(mapped) == 15
    write_json(BASE / 'r5-mapped-value-differences.json', {'schema': 'hepta.rea.ghidra-mapped-differences.v1',
        'source': {'path': 'r5-full-result-diff-r1/field-differences.jsonl.gz',
            'sha256': '69fd6380c4d5c518c9d69a0a3b5978bb3164f3a9fccfe3515dadf3cf1775411e'},
        'scope': 'Fifteen existing typed value DIFF rows; missing fields and opaque/full-frame differences remain in the full artifact.',
        'rows': mapped})
    add(BASE / 'r5-mapped-value-differences.json')
    receipt['stage'] = 'pack'
    rows = []
    for key in sorted(selected):
        raw = read(BASE / key)
        rows.append({'path': key, 'bytes': len(raw), 'sha256': digest(raw)})
    total = sum(row['bytes'] for row in rows)
    assert len(rows) <= 10000 and total <= TOTAL_CAP
    manifest_ref = write_json(MANIFEST, {'schema': 'hepta.rea.ghidra-r5-raw-archive-manifest.v1',
        'source_commit': COMMIT, 'files': rows, 'file_count': len(rows), 'total_bytes': total,
        'scope': 'Fixed raw R5 native and historical C9 original capture inputs, frozen offline readers, outputs, source snapshot and receipts. No runtime, JDK, Ghidra, npm dependency or engine-cache payload.',
        'excluded_native_binary': {'actual_argv_path': str(BASE / 'mcp-native-r5-r1/hepta-runtime-qualified'),
            'bytes': 51146872, 'sha256': '260205be5fd4cdf363b8f426002c057d1d939ce299843f979770a585bb72faf6'}})
    manifest_raw = read(MANIFEST)
    members = rows + [{'path': MANIFEST.name, 'bytes': len(manifest_raw), 'sha256': digest(manifest_raw)}]
    with ARCHIVE.open('xb') as output, gzip.GzipFile(fileobj=output, mode='wb', filename='', mtime=0) as gz:
        with tarfile.open(fileobj=gz, mode='w', format=tarfile.PAX_FORMAT) as tar:
            for row in members:
                raw = read(BASE / row['path'], row['sha256'])
                assert len(raw) == row['bytes']
                info = tarfile.TarInfo(row['path'])
                info.size = len(raw)
                info.mode = 0o644
                info.mtime = 0
                tar.addfile(info, io.BytesIO(raw))
    emit('archive_created', files=len(rows), total_bytes=total, archive=file_ref(ARCHIVE))
    receipt['stage'] = 'verify_and_extract'
    expected = {row['path']: row for row in members}
    RELOCATED.mkdir()
    observed = set()
    with tarfile.open(ARCHIVE, 'r:gz') as tar:
        for item in tar:
            key = safe_key(item.name)
            assert item.isfile() and key in expected and key not in observed
            row = expected[key]
            assert item.size == row['bytes']
            raw = tar.extractfile(item).read(FILE_CAP + 1)
            assert len(raw) == row['bytes'] and digest(raw) == row['sha256']
            target = RELOCATED / key
            target.parent.mkdir(parents=True, exist_ok=True)
            with target.open('xb') as stream:
                stream.write(raw)
            observed.add(key)
    assert observed == set(expected)
    for row in rows:
        read(BASE / row['path'], row['sha256'])
        read(RELOCATED / row['path'], row['sha256'])
    verification = {'schema': 'hepta.rea.ghidra-r5-archive-verification.v1', 'status': 'PASS',
        'archive': file_ref(ARCHIVE), 'manifest': manifest_ref,
        'file_count': len(rows), 'archive_members': len(members), 'source_bytes': total,
        'every_member_byte_length_and_sha256_verified': True,
        'all_source_members_rechecked_after_pack': True,
        'fresh_extraction_root': str(RELOCATED), 'runtime_or_engine_started': False}
    write_json(VERIFICATION, verification)
    receipt['stage'] = 'state_consumer_replay'
    state_output = OUT / 'negative-state-assessment.json'
    invoke('state-consumer', ['/usr/bin/python3', '-B', str(RELOCATED / 'consume_r4_states.py'),
        '--capture-dir', str(RELOCATED / 'mcp-native-wire-r5-r1'), '--sha256', CAPTURE_SHA,
        '--output', str(state_output)])
    assert read(state_output, ASSESSMENT_SHA) == read(BASE / 'native-r5-state-derived-r1/negative-state-assessment.json')
    receipt['stage'] = 'full_differential_replay'
    plan = json.loads(read(RELOCATED / 'r5-full-diff-inputs.json'))
    plan['base'] = str(RELOCATED)
    plan['output'] = 'r5-replayed-full-result-diff-r1'
    plan_path = RELOCATED / 'r5-replay-inputs.json'
    plan_ref = write_json(plan_path, plan)
    invoke('full-differential', ['/usr/bin/python3', '-B', str(RELOCATED / 'derive_ghidra_final_diff_r1.py'),
        '--plan', str(plan_path), '--plan-sha256', plan_ref['sha256'], '--script-sha256', DIFF_SOURCE_SHA])
    original_dir = BASE / 'r5-full-result-diff-r1'
    replayed_dir = RELOCATED / plan['output']
    comparisons = []
    for path in sorted(original_dir.iterdir()):
        other = replayed_dir / path.name
        original_raw, replay_raw = read(path), read(other)
        equal = original_raw == replay_raw
        comparisons.append({'path': path.name, 'bytes_equal': equal,
            'original': {'bytes': len(original_raw), 'sha256': digest(original_raw)},
            'replayed': {'bytes': len(replay_raw), 'sha256': digest(replay_raw)}})
        if path.name not in ('inputs-manifest.json', 'summary.json'):
            assert equal, path.name
    original_summary = json.loads(read(original_dir / 'summary.json'))
    replay_summary = json.loads(read(replayed_dir / 'summary.json'))
    original_inputs = original_summary['artifacts'].pop('inputs')
    replay_inputs = replay_summary['artifacts'].pop('inputs')
    assert original_summary == replay_summary
    old_manifest = json.loads(read(original_dir / 'inputs-manifest.json'))
    new_manifest = json.loads(read(replayed_dir / 'inputs-manifest.json'))
    old_plan_ref = old_manifest['files'].pop('r5-full-diff-inputs.json')
    new_plan_ref = new_manifest['files'].pop('r5-replay-inputs.json')
    assert old_manifest['source_and_capture_plan_sha256'] == old_plan_ref['sha256']
    assert new_manifest['source_and_capture_plan_sha256'] == plan_ref['sha256'] == new_plan_ref['sha256']
    old_manifest.pop('source_and_capture_plan_sha256')
    new_manifest.pop('source_and_capture_plan_sha256')
    assert old_manifest == new_manifest
    assessment = {'schema': 'hepta.rea.ghidra-r5-offline-relocation-assessment.v1',
        'status': 'PASS', 'qualified': False, 'runtime_or_engine_started': False,
        'archive': file_ref(ARCHIVE), 'archive_verification': file_ref(VERIFICATION),
        'relocated_root': str(RELOCATED), 'state_consumer': {'byte_exact': True, **file_ref(state_output)},
        'full_differential': {'artifacts': comparisons, 'byte_exact_artifacts': sum(x['bytes_equal'] for x in comparisons),
            'total_artifacts': len(comparisons), 'summary_all_other_fields_equal': True,
            'inputs_manifest_all_other_fields_equal': True,
            'allowed_provenance_changes': ['new plan relative filename and bytes/SHA/base/output',
                'inputs-manifest source_and_capture_plan_sha256 and plan file entry',
                'summary artifacts.inputs size and SHA256'],
            'original_summary_inputs_reference': original_inputs,
            'replayed_summary_inputs_reference': replay_inputs,
            'original_plan_reference': old_plan_ref, 'replayed_plan_reference': new_plan_ref},
        'scope': 'Actual fresh archive extraction and execution of the two pinned offline consumers. Historical process/census evidence is verified, never observed again or replayed as a new runtime run.'}
    assessment_ref = write_json(OUT / 'assessment.json', assessment)
    receipt.update(completed=True, stage='complete', status='PASS', assessment=assessment_ref,
        archive=file_ref(ARCHIVE), manifest=manifest_ref, verification=file_ref(VERIFICATION))
except BaseException as error:
    receipt.update(status='FAILED', error=repr(error), traceback=traceback.format_exc())
    traceback.print_exc()
    raise
finally:
    receipt['finished_at_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    write_json(RECEIPT, receipt)
    emit('package_and_replay_finished', **receipt)
