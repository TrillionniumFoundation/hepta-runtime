# Complete original and native capture comparison

This is a lossless, explicitly layered offline derivation. It does not run a
runtime or engine and never changes the source captures. See summary.json for
actual comparisons, source identities and the explicit finite scope.

Complete CallToolResult, opaque text, JSON-RPC bytes and parsed field mappings
are separate layers. The original bundle's seven internal checks are parsed
value/predicate checks; its cold-import opaque text remains different because
of object member order. The fixed independent C9 layer report is retained as
an input, not replaced by a claim of raw equivalence.

The same live native controller is sampled before and after its entry Provider
operations, with exact wire requests and responses bound to the capture and
close receipt. Its actual Evidence is compared separately from Provider
reports. The original bundle came from its own recorded operation history;
these histories are documented, not silently treated as identical sequences.

Native raw checks include eight retained reads and five negative start replays.
Report/error/registry checks are independently rederived here. The separate
R4 state consumer binds all eleven raw membership samples and independently
checks the five directory comparisons; its result and inputs remain separate.

No result counts or source-field matches promote complete REA qualification.
Original NoReturnFix is directly observed as a no-op for this fixture only.
Original cancellation is the one historical C9 attempt; no new original
request or cancellation was executed by this derivation.
