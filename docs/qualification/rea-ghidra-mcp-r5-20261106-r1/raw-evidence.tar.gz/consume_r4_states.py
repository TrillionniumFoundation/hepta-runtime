#!/usr/bin/env python3
"""Offline private R4 replay: original frames plus sampled directory membership.

This program never starts a runtime or engine. It derives the 23 native collector
comparisons, including the five newly retained directory comparisons. It does
not establish upstream parity, source/build provenance, or process cleanup.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import math
import os
from pathlib import Path, PurePosixPath
import re
import stat
import sys
import zlib

SCHEMA = "hepta.private-ghidra-r4-state-assessment.v1"
DRIVER_SHA = "4ea350a39c9d7eab4b0784c85fe40db24dabceada5c718fae498020cbb3cd4a2"
LIMIT = 16 * 1024 * 1024
CAPTURE_LIMIT = 32 * 1024 * 1024
SESSION_LIMIT = 256 * 1024 * 1024
GZIP_KEYS = {"path", "encoding", "raw_bytes", "raw_sha256", "gzip_bytes", "gzip_sha256"}
NEGATIVES = ["same-key-conflict"] + ["invalid-selector-" + str(i) for i in range(4)]
LABELS = ("functions", "function", "xrefs", "decompile")


def require(condition, reason):
    if not condition:
        raise ValueError(reason)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def integer(value, minimum=0):
    return type(value) is int and value >= minimum


def digest_ok(value):
    return isinstance(value, str) and re.fullmatch("[0-9a-f]{64}", value) is not None


def equal(a, b):
    if type(a) is not type(b):
        return False
    if isinstance(a, dict):
        return set(a) == set(b) and all(equal(a[key], b[key]) for key in a)
    if isinstance(a, list):
        return len(a) == len(b) and all(equal(x, y) for x, y in zip(a, b))
    return a == b


def parse(raw):
    def members(items):
        result = {}
        for key, value in items:
            require(key not in result, "duplicate JSON member")
            result[key] = value
        return result

    def number(token):
        value = float(token)
        require(math.isfinite(value), "non-finite JSON number")
        return value

    return json.loads(raw, object_pairs_hook=members, parse_float=number,
                      parse_constant=lambda _: (_ for _ in ()).throw(ValueError("non-finite JSON value")))


def parts(value, absolute=False):
    require(isinstance(value, str) and value and "\0" not in value and "\\" not in value,
            "unsafe artifact path")
    require(value.startswith("/") == absolute, "wrong artifact path kind")
    tokens = value[1:].split("/") if absolute else value.split("/")
    require(all(token not in {"", ".", ".."} for token in tokens), "unsafe artifact path component")
    return tokens


def read_regular(root, name, maximum=LIMIT):
    """Walk every root/artifact component via no-follow directory descriptors."""
    names = parts(str(root), absolute=True) + parts(name)
    parent = os.open("/", os.O_RDONLY | os.O_CLOEXEC | os.O_DIRECTORY)
    try:
        for token in names[:-1]:
            child = os.open(token, os.O_RDONLY | os.O_CLOEXEC | os.O_DIRECTORY | os.O_NOFOLLOW,
                            dir_fd=parent)
            os.close(parent)
            parent = child
        fd = os.open(names[-1], os.O_RDONLY | os.O_CLOEXEC | os.O_NOFOLLOW | os.O_NONBLOCK,
                     dir_fd=parent)
        with os.fdopen(fd, "rb") as stream:
            before = os.fstat(stream.fileno())
            require(stat.S_ISREG(before.st_mode) and before.st_nlink == 1,
                    "artifact must be a single-link regular file")
            require(0 <= before.st_size <= maximum, "artifact exceeds byte allowance")
            raw = stream.read(maximum + 1)
            after = os.fstat(stream.fileno())
        current = os.stat(names[-1], dir_fd=parent, follow_symlinks=False)
        fields = ("st_dev", "st_ino", "st_mode", "st_nlink", "st_size", "st_mtime_ns", "st_ctime_ns")
        require(len(raw) == before.st_size and all(getattr(before, key) == getattr(after, key)
                == getattr(current, key) for key in fields), "artifact changed while reading")
        return raw
    finally:
        os.close(parent)


def read_pinned(root, ref, maximum=LIMIT):
    require(isinstance(ref, dict) and set(ref) == {"path", "bytes", "sha256"}
            and integer(ref["bytes"]) and ref["bytes"] <= maximum and digest_ok(ref["sha256"]),
            "invalid plain artifact reference")
    raw = read_regular(root, ref["path"], ref["bytes"])
    require(len(raw) == ref["bytes"] and sha(raw) == ref["sha256"], "plain artifact pin mismatch")
    return raw


def read_gzip(root, ref):
    require(isinstance(ref, dict) and set(ref) == GZIP_KEYS
            and ref["encoding"] == "gzip-original-jsonrpc-line"
            and integer(ref["raw_bytes"]) and ref["raw_bytes"] <= LIMIT
            and digest_ok(ref["raw_sha256"]), "invalid original gzip reference")
    zipped = read_pinned(root, {"path": ref["path"], "bytes": ref["gzip_bytes"],
                               "sha256": ref["gzip_sha256"]}, LIMIT + 65536)
    decoder = zlib.decompressobj(16 + zlib.MAX_WBITS)
    try:
        raw = decoder.decompress(zipped, ref["raw_bytes"] + 1)
    except zlib.error as error:
        raise ValueError("invalid gzip data") from error
    require(len(raw) == ref["raw_bytes"] and decoder.eof and not decoder.unused_data
            and not decoder.unconsumed_tail and sha(raw) == ref["raw_sha256"],
            "gzip is oversized, incomplete, has trailing members, or has a wrong digest")
    return raw


def wire_index(root, ref):
    raw = read_pinned(root, ref)
    require(raw.endswith(b"\n"), "unterminated wire index")
    lines = raw.splitlines()
    require(1 <= len(lines) <= 1024, "wire frame count outside allowance")
    parent = PurePosixPath(ref["path"]).parent
    sent, received, frames, entries = {}, {}, {}, {}
    previous, total, initialized = -1, 0, False
    for ordinal, line in enumerate(lines):
        entry = parse(line)
        require(isinstance(entry, dict) and set(entry) == GZIP_KEYS | {"direction", "monotonic_ns"}
                and entry["direction"] in {"sent", "received"}
                and integer(entry["monotonic_ns"]) and entry["monotonic_ns"] >= previous,
                "invalid or unordered original wire entry")
        direction = entry["direction"]
        require(entry["path"] == f"wire-{ordinal:04d}-{direction}.json.gz", "substituted wire basename")
        previous = entry["monotonic_ns"]
        rooted = {**entry, "path": str(parent / entry["path"])}
        frame = read_gzip(root, {key: rooted[key] for key in GZIP_KEYS})
        total += len(frame)
        require(total <= SESSION_LIMIT and frame.endswith(b"\n") and b"\n" not in frame[:-1],
                "wire exceeds allowance or is not one JSON line")
        value = parse(frame)
        require(isinstance(value, dict) and value.get("jsonrpc") == "2.0", "invalid RPC envelope")
        if "id" not in value:
            require(not initialized and direction == "sent" and equal(value, {
                "jsonrpc": "2.0", "method": "notifications/initialized", "params": {}})
                and len(sent) == len(received) == 1 and next(iter(sent.values()))["method"] == "initialize",
                "unexpected or premature notification")
            initialized = True
            continue
        identifier = value["id"]
        target = sent if direction == "sent" else received
        require(integer(identifier, 1) and identifier not in target, "duplicate or invalid RPC ID")
        if direction == "sent":
            require(set(sent) == set(received), "overlapping or unfinished RPC requests")
            require(set(value) == {"jsonrpc", "id", "method", "params"}
                    and value["method"] in {"initialize", "tools/list", "tools/call"}, "unexpected client RPC")
            require((not sent and not initialized and value["method"] == "initialize")
                    or (initialized and value["method"] != "initialize"), "invalid initialization order")
        else:
            require(identifier in sent and set(value) in ({"jsonrpc", "id", "result"},
                    {"jsonrpc", "id", "error"}), "unmatched or malformed RPC response")
        target[identifier] = value
        frames[(direction, identifier)] = frame
        entries[(direction, identifier)] = rooted
    require(initialized and set(sent) == set(received), "incomplete RPC session")
    ordered = list(sent)
    init = sent[ordered[0]]
    require(equal(init["params"], {"protocolVersion": "2026-07-28", "capabilities": {},
                "clientInfo": {"name": "hepta-rea-operation-qualification", "version": "1"}})
            and "result" in received[ordered[0]], "unexpected initialize contract")
    cursor, catalogs, position = None, [], 1
    while position < len(ordered) and sent[ordered[position]]["method"] == "tools/list":
        identifier = ordered[position]
        require(equal(sent[identifier]["params"], {} if cursor is None else {"cursor": cursor}),
                "catalog cursor mismatch")
        result = received[identifier].get("result")
        require(isinstance(result, dict) and isinstance(result.get("tools"), list), "invalid catalog result")
        catalogs.extend(result["tools"])
        cursor = result.get("nextCursor")
        position += 1
        if cursor is None:
            break
        require(isinstance(cursor, str) and position <= 33, "invalid catalog continuation")
    require(position > 1 and cursor is None and all(sent[number]["method"] == "tools/call"
            for number in ordered[position:]), "catalog incomplete or repeated after tool calls")
    require(all(isinstance(row, dict) and isinstance(row.get("name"), str) for row in catalogs)
            and len({row["name"] for row in catalogs}) == len(catalogs), "invalid catalog tool identities")
    return {"sent": sent, "received": received, "frames": frames, "entries": entries,
            "call_ids": ordered[position:], "catalog": catalogs, "first_ns": parse(lines[0])["monotonic_ns"],
            "last_ns": previous, "frame_count": len(lines)}


def member_bytes(raw, names):
    """Locate the actual JSON token, retaining original whitespace/key order."""
    text = raw.decode("utf-8", errors="strict")
    decoder = json.JSONDecoder()
    lo, hi = 0, len(text)
    for name in names:
        i = lo
        while i < hi and text[i].isspace():
            i += 1
        require(i < hi and text[i] == "{", "raw member parent is not an object")
        i += 1
        selected = None
        while i < hi:
            while i < hi and (text[i].isspace() or text[i] == ","):
                i += 1
            if i >= hi or text[i] == "}":
                break
            key, i = decoder.raw_decode(text, i)
            while i < hi and text[i].isspace():
                i += 1
            require(i < hi and text[i] == ":", "invalid raw JSON member")
            i += 1
            while i < hi and text[i].isspace():
                i += 1
            start = i
            _, i = decoder.raw_decode(text, i)
            if key == name:
                selected = start, i
                break
        require(selected is not None, "raw JSON member is missing")
        lo, hi = selected
    return text[lo:hi].encode(), [len(text[:lo].encode()), len(text[:hi].encode())]


def payload(response):
    result = response.get("result")
    require(isinstance(result, dict) and result.get("isError") is not True, "expected successful tool response")
    content = result.get("content")
    require(isinstance(content, list) and len(content) == 1 and isinstance(content[0], dict)
            and content[0].get("type") == "text" and isinstance(content[0].get("text"), str),
            "expected one opaque text value")
    value = parse(content[0]["text"])
    require("structuredContent" not in result or equal(value, result["structuredContent"]),
            "structured/text value mismatch")
    return value


def registry_rows(response):
    value = payload(response)
    rows = value if isinstance(value, list) else value.get("jobs") if isinstance(value, dict) else None
    require(isinstance(rows, list) and rows and all(isinstance(row, dict)
            and isinstance(row.get("id"), str) and len(parts(row["id"])) == 1 for row in rows),
            "invalid actual registry rows")
    require(len({row["id"] for row in rows}) == len(rows), "duplicate registry identity")
    return rows


def bind_call(root, wire, row, identifier, label, tool, arguments):
    require(isinstance(row, dict) and row.get("id") == label and row.get("tool") == tool
            and equal(row.get("arguments"), arguments) and row.get("status") == "OBSERVED"
            and type(row.get("request_id")) is int and row["request_id"] == identifier,
            "call row differs from fixed actual request sequence")
    request, response = wire["sent"][identifier], wire["received"][identifier]
    require(equal(request["params"], {"name": tool, "arguments": arguments})
            and equal(row.get("response_parsed"), response) and "result" in response,
            "call row differs from original request/response")
    for direction, field in (("sent", "request_wire"), ("received", "response_wire")):
        recorded = row.get(field)
        require(isinstance(recorded, dict), "call lacks original frame reference")
        require(equal({**recorded, "path": "native-readback/" + recorded["path"]},
                      wire["entries"][(direction, identifier)]), "call references the wrong original frame")
    raw = wire["frames"][("received", identifier)]
    for field, names in (("result_raw", ["result"]), ("structured_content_raw", ["result", "structuredContent"])):
        if field == "structured_content_raw" and "structuredContent" not in response["result"]:
            require(field not in row, "invented structured result artifact")
            continue
        ref = row.get(field)
        require(isinstance(ref, dict) and set(ref) == {"path", "bytes", "sha256", "source_frame_range"},
                "missing raw response member pin")
        original, expected_range = member_bytes(raw, names)
        require(equal(ref["source_frame_range"], expected_range)
                and read_pinned(root, {key: ref[key] for key in ("path", "bytes", "sha256")}) == original,
                "raw member artifact is not the exact original frame slice")
    text_values = [item["text"] for item in response["result"].get("content", [])
                   if isinstance(item, dict) and item.get("type") == "text"]
    refs = row.get("content_text_utf8")
    require(isinstance(refs, list) and len(refs) == len(text_values), "opaque text artifact count differs")
    for ref, text in zip(refs, text_values):
        require(isinstance(text, str) and read_pinned(root, ref) == text.encode(), "opaque text bytes differ")
    return response


def read_state(root, ref, expected_name, call, wire, job_roots):
    require(ref["path"] == expected_name, "substituted state artifact name")
    state = parse(read_pinned(root, ref))
    require(isinstance(state, dict) and set(state) == {"schema", "registry", "directory"}
            and state["schema"] == "hepta.rea.ghidra-negative-state.v1", "invalid state schema")
    number = call["request_id"]
    rows = registry_rows(wire["received"][number])
    expected = {"call_id": call["id"], "request_id": number, "tool": "process_list", "arguments": {"host": "local"},
                "request_wire": wire["entries"][("sent", number)],
                "response_wire": wire["entries"][("received", number)],
                "result_raw": call["result_raw"], "content_text_utf8": call["content_text_utf8"],
                "rows": rows, "job_ids": sorted(row["id"] for row in rows),
                "scope": "actual abbreviated process_list rows; original frame retained"}
    require(equal(state["registry"], expected), "state registry is not bound to its original call")
    directory = state["directory"]
    require(isinstance(directory, dict) and set(directory) == {"job_roots", "sample_started_ns", "sample_finished_ns", "entries", "scope"}
            and directory["job_roots"] == job_roots and isinstance(directory["entries"], dict)
            and set(directory["entries"]) == set(job_roots)
            and directory["scope"] == "complete immediate member names; not recursive contents or process history",
            "directory roots/scope differ from actual bound jobs")
    for members in directory["entries"].values():
        require(isinstance(members, list) and all(isinstance(name, str) and len(parts(name)) == 1 for name in members)
                and members == sorted(set(members)), "directory snapshot is not a complete sorted unique name list")
    start, end = directory["sample_started_ns"], directory["sample_finished_ns"]
    require(integer(start) and integer(end) and wire["entries"][("received", number)]["monotonic_ns"] <= start <= end,
            "directory sample precedes its bound registry or reverses time")
    return state


def validate_capture(root, expected_sha256):
    require(digest_ok(expected_sha256), "capture SHA256 pin is required")
    raw = read_regular(root, "capture.json", CAPTURE_LIMIT)
    require(sha(raw) == expected_sha256, "capture.json pin mismatch")
    report = parse(raw)
    require(report.get("schema") == "hepta.rea.ghidra-mcp-wire-capture.v1"
            and report.get("mode") == "native-readback"
            and report.get("driver", {}).get("sha256") == DRIVER_SHA
            and report.get("driver_after_sha256") == DRIVER_SHA, "not the frozen private R4 native profile")
    sessions = report.get("sessions")
    require(isinstance(sessions, list) and len(sessions) == 1 and sessions[0].get("id") == "native-readback",
            "native capture session set differs")
    session = sessions[0]
    index_ref = session["client_artifacts"]["wire.jsonl"]
    require(index_ref["path"] == "native-readback/wire.jsonl", "substituted original wire index")
    wire = wire_index(root, index_ref)
    require(equal(parse(read_pinned(root, session["catalog"])), wire["catalog"]), "catalog file differs from actual wire")
    harness = report["harness_inputs"]
    names = ["config.json", "requests.json", "qualification.json"] + [name + suffix for suffix in
             ("-result.json", "-initial-job.json") for name in LABELS] + [
             "interior-" + name + ".json" for name in ("function", "xrefs", "decompile")] + [
             "no-function-refusal.json"] + [name + ".json" for name in NEGATIVES]
    require(set(harness) == set(names), "copied harness input set differs")
    inputs = {}
    for name in names:
        require(harness[name]["path"] == "harness-inputs/" + name, "substituted copied harness input")
        inputs[name] = parse(read_pinned(root, harness[name]))
    expected_calls = [(name + "-entry", "rea_static_read", inputs["requests.json"][name]) for name in LABELS]
    expected_calls += [(name + "-interior", "rea_static_read", inputs["interior-" + name + ".json"]["request"])
                       for name in ("function", "xrefs", "decompile")]
    expected_calls += [("function-unmapped", "rea_static_read", inputs["no-function-refusal.json"]["request"]),
                       ("jobs-before-negative-replays", "process_list", {"host": "local"})]
    for index, name in enumerate(NEGATIVES):
        expected_calls += [(name, "rea_static_start", inputs[name + ".json"]["request"]),
                           ("jobs-after-negative-" + str(index), "process_list", {"host": "local"})]
    calls = session["calls"]
    require(isinstance(calls, list) and len(calls) == len(expected_calls) == len(wire["call_ids"]),
            "missing or extra actual calls; fixed complete sequence was not observed")
    responses = {}
    for row, number, spec in zip(calls, wire["call_ids"], expected_calls):
        responses[spec[0]] = bind_call(root, wire, row, number, *spec)
    by_name = {row["id"]: row for row in calls}
    checks = []
    def check(name, passed, category):
        checks.append({"id": name, "equal": bool(passed), "category": category})
    for name in LABELS:
        check(name + "-entry-report-exact", equal(payload(responses[name + "-entry"]), inputs[name + "-result.json"]), "retained-result")
    for name in ("function", "xrefs", "decompile"):
        check(name + "-interior-report-exact", equal(payload(responses[name + "-interior"]), inputs["interior-" + name + ".json"]["result"]), "retained-result")
    check("unmapped-retained-backend-error-exact", equal(payload(responses["function-unmapped"]), inputs["no-function-refusal.json"]["result"]), "retained-result")
    initial = by_name["jobs-before-negative-replays"]
    initial_rows = registry_rows(responses[initial["id"]])
    before_ids = sorted(row["id"] for row in initial_rows)
    jobs = [inputs[name + "-initial-job.json"]["job"] for name in LABELS]
    require(all(job["id"] == inputs["qualification.json"]["job_ids"][name] and job["host"] == "local"
                and job["id"] in before_ids and PurePosixPath(job["remote_job_dir"]).name == job["id"]
                for name, job in zip(LABELS, jobs)), "original harness job identities differ")
    for job in jobs:
        parts(job["remote_job_dir"], absolute=True)
    job_roots = sorted({str(PurePosixPath(job["remote_job_dir"]).parent) for job in jobs})
    remote = PurePosixPath(inputs["config.json"]["hosts"]["local"]["remote_state_dir"])
    parts(str(remote), absolute=True)
    require(len(job_roots) == 1 and all(PurePosixPath(path).is_relative_to(remote) for path in job_roots),
            "job directory roots do not belong to the copied private host")
    baseline_ref = report["negative_replay_baseline"]
    baseline = read_state(root, baseline_ref, "negative-baseline-state.json", initial, wire, job_roots)
    require(set(before_ids).issubset(baseline["directory"]["entries"][job_roots[0]]),
            "initial registry jobs are absent from the initial directory sample")
    observations = report["negative_replay_observations"]
    require(isinstance(observations, list) and len(observations) == 5, "five before/after observations are required")
    previous = initial
    last_end = baseline["directory"]["sample_finished_ns"]
    witnesses = []
    for index, (name, observation) in enumerate(zip(NEGATIVES, observations)):
        require(set(observation) == {"case", "request", "harness_input", "comparison_baseline", "before_registry_timing", "before", "after"}
                and observation["case"] == name + ".json" and equal(observation["request"], inputs[name + ".json"]["request"])
                and equal(observation["harness_input"], harness[name + ".json"])
                and equal(observation["comparison_baseline"], baseline_ref)
                and observation["before_registry_timing"] == ("initial-before-loop" if index == 0 else "previous-case-after"),
                "replay observation does not bind its original request/baseline/timing")
        after_call = by_name["jobs-after-negative-" + str(index)]
        before = read_state(root, observation["before"], f"negative-{index:02d}-before-state.json", previous, wire, job_roots)
        after = read_state(root, observation["after"], f"negative-{index:02d}-after-state.json", after_call, wire, job_roots)
        negative_number = by_name[name]["request_id"]
        sent_ns = wire["entries"][("sent", negative_number)]["monotonic_ns"]
        received_ns = wire["entries"][("received", negative_number)]["monotonic_ns"]
        registry_ns = wire["entries"][("sent", after_call["request_id"])]["monotonic_ns"]
        require(last_end <= before["directory"]["sample_started_ns"]
                <= before["directory"]["sample_finished_ns"] <= sent_ns <= received_ns <= registry_ns,
                "before sample/negative request/after registry causal order differs")
        result = responses[name]["result"]
        require(result.get("isError") is True, "negative start was not refused; this finite safe sequence cannot pass")
        check(name + "-calltool-result-exact", equal(result, inputs[name + ".json"]["call_tool_result"]), "refusal-result")
        ids_equal = after["registry"]["job_ids"] == baseline["registry"]["job_ids"]
        dirs_equal = after["directory"]["entries"] == baseline["directory"]["entries"]
        check(name + "-no-new-job-identity", ids_equal, "registry-membership")
        check(name + "-no-new-job-directory", dirs_equal, "directory-membership")
        witnesses.append({"case": name, "before": observation["before"], "after": observation["after"],
                          "negative_request_id": negative_number, "before_registry_request_id": previous["request_id"],
                          "after_registry_request_id": after_call["request_id"],
                          "adjacent_registry_membership_equal": before["registry"]["job_ids"] == after["registry"]["job_ids"],
                          "adjacent_directory_membership_equal": before["directory"]["entries"] == after["directory"]["entries"]})
        previous, last_end = after_call, after["directory"]["sample_finished_ns"]
    require(integer(report["started_ns"]) and integer(report["finished_ns"])
            and report["started_ns"] <= wire["first_ns"] and report["finished_ns"] >= max(wire["last_ns"], last_end),
            "capture timing does not enclose actual wire/samples")
    require(len(checks) == 23, "consumer internal fixed comparison count differs")
    passed = sum(check["equal"] for check in checks)
    adjacent = all(row["adjacent_registry_membership_equal"]
                   and row["adjacent_directory_membership_equal"] for row in witnesses)
    return {"schema": SCHEMA, "status": "PASS" if passed == 23 and adjacent else "FAIL", "qualified": False,
            "capture_sha256": expected_sha256, "capture_bytes": len(raw), "driver_sha256": DRIVER_SHA,
            "wire_index": index_ref, "wire_frames": wire["frame_count"], "actual_tool_calls": len(calls),
            "comparisons": checks, "comparison_count": 23, "passed": passed,
            "original_23_comparison_status": "PASS" if passed == 23 else "FAIL",
            "adjacent_membership_status": "PASS" if adjacent else "FAIL",
            "breakdown": {category: {"count": sum(check["category"] == category for check in checks),
                "passed": sum(check["category"] == category and check["equal"] for check in checks)}
                for category in ("retained-result", "refusal-result", "registry-membership", "directory-membership")},
            "observations": witnesses,
            "scope": "native collector internal retained replay: eight parsed results, five complete refusal CallToolResults, five registry and five directory comparisons against initial baseline; additionally require each adjacent before/after membership pair to match; no upstream equivalence",
            "boundaries": ["Directory and registry samples are not atomic and do not exclude transient jobs/files between samples.",
                "Directory evidence is the complete recorded immediate-member list, not recursive content or process birth history.",
                "Frame/file pins bind recorded bytes; they do not attest a hostile collector/operator.",
                "Source/build/binary provenance, controller/JVM cleanup and complete Evidence parity require their separate consumers.",
                "Historical C9 missing after-directory samples are not inferred or backfilled."],
            "producer_check_booleans_used_as_authority": False}


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--capture-dir", type=Path, required=True)
    parser.add_argument("--sha256", required=True)
    parser.add_argument("--output", type=Path)
    args = parser.parse_args(argv)
    try:
        result = validate_capture(args.capture_dir, args.sha256)
        code = 0 if result["status"] == "PASS" else 1
    except (OSError, ValueError, KeyError, TypeError, AttributeError, IndexError, RecursionError) as error:
        result = {"schema": SCHEMA, "status": "INVALID", "qualified": False,
                  "capture_sha256": args.sha256, "error": type(error).__name__ + ": " + str(error)}
        code = 2
    raw = (json.dumps(result, sort_keys=True, ensure_ascii=True, allow_nan=False) + "\n").encode()
    if args.output is not None:
        require(args.output.is_absolute(), "derived output must be absolute")
        fd = os.open(args.output, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600)
        with os.fdopen(fd, "wb") as stream:
            stream.write(raw)
    sys.stdout.buffer.write(raw)
    return code


if __name__ == "__main__":
    raise SystemExit(main())
