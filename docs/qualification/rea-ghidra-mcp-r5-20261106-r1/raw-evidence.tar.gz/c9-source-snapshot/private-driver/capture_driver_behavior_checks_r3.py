#!/usr/bin/env python3
# Copyright 2026 TrillionniumFoundation
# SPDX-License-Identifier: Apache-2.0
"""Private driver checks: three owned pipe processes and transport stubs; no MCP/Ghidra."""
from pathlib import Path
from types import SimpleNamespace
import hashlib
import json
import os
import queue
import runpy
import select
import subprocess
import sys
import threading
import time
import traceback

BASE = Path("/home/qian-qi/work/hepta-rea-ghidra-v4-ecb0b9-20261106-r1")
DRIVER = BASE / "ghidra_mcp_capture_r3.py"
PIN = "552d497487e479562694820f35226db30ea016fb596595ea2e37bf4081a0454b"
OUT = BASE / "driver-behavior-checks-r3"
assert hashlib.sha256(DRIVER.read_bytes()).hexdigest() == PIN
OUT.mkdir(exist_ok=False)
module = runpy.run_path(str(DRIVER), run_name="__private_driver_behavior_checks__")
g = module["guarded_client"].__globals__
report = {"schema": "hepta.rea.ghidra-private-capture-driver-checks.v1",
          "driver_sha256": PIN, "mcp_processes_started": 0, "ghidra_processes_started": 0,
          "owned_python_pipe_processes_started": 0, "checks": [], "qualified": False}
all_children = []

def save():
    (OUT / "checks.json").write_text(json.dumps(report, indent=2) + "\n")

def group_exists(pid):
    try:
        os.killpg(pid, 0)
        return True
    except ProcessLookupError:
        return False

def record(name, callback):
    started = time.monotonic()
    try:
        value = callback()
        report["checks"].append({"id": name, "status": "PASS", "facts": value,
                                 "seconds": time.monotonic() - started})
    except BaseException as error:
        report["checks"].append({"id": name, "status": "FAIL", "error": repr(error),
                                 "traceback": traceback.format_exc(),
                                 "seconds": time.monotonic() - started})
    save()

def pipe_child(obj, output, marker):
    output.mkdir()
    obj.output = output
    obj.stderr = (output / "stderr.log").open("xb")
    obj.wire = (output / "wire.jsonl").open("xb")
    obj.process = subprocess.Popen(
        [sys.executable, "-c",
         "import pathlib,sys;sys.stdin.buffer.read();pathlib.Path(sys.argv[1]).write_text('EOF observed')",
         str(marker)], cwd=OUT, env={"PATH": "/usr/bin:/bin"},
        stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=obj.stderr, start_new_session=True)
    all_children.append(obj.process)
    report["owned_python_pipe_processes_started"] += 1

def partial_constructor_fault(kind):
    directory = OUT / kind
    marker = OUT / (kind + "-eof.txt")
    real_pidfd = os.pidfd_open
    real_census = g["Observer"].census
    observed = []
    class Broken:
        def __init__(self, argv, cwd, env, output):
            pipe_child(self, output, marker)
            observed.append(self)
            self.pidfd = os.pidfd_open(self.process.pid)
            raise OSError("injected persistent construction observer failure")
    frame = SimpleNamespace(CompressedMcp=Broken, q=SimpleNamespace(process_group_exists=group_exists))
    def fail_pidfd(*args, **kwargs):
        raise OSError("injected persistent pidfd_open failure")
    def fail_census(*args, **kwargs):
        raise OSError("injected persistent observer census failure")
    if kind == "pidfd_failure":
        os.pidfd_open = fail_pidfd
    else:
        g["Observer"].census = fail_census
    state = {"qualified": False}
    original = None
    try:
        try:
            g["guarded_client"](frame, ["owned-pipe-child"], OUT, {}, directory, state)
        except OSError as error:
            original = error
        assert original is not None and "injected persistent" in str(original)
    finally:
        os.pidfd_open = real_pidfd
        g["Observer"].census = real_census
    child = observed[0].process
    assert child.poll() == 0 and marker.read_text() == "EOF observed"
    cleanup = json.loads((OUT / (kind + "-partial-construction.json")).read_bytes())
    assert cleanup["stdin_closed"] and cleanup["returncode"] == 0 and cleanup["process_group_gone"]
    assert cleanup["construction_succeeded"] is False and cleanup["qualification_claimed"] is False
    assert cleanup["errors"] and cleanup["forced_cleanup"] == []
    return {"pid": child.pid, "returncode": child.returncode, "eof_marker": True,
            "original_exception_retained": str(original), "cleanup_errors_retained": cleanup["errors"],
            "source_proof_not_upgraded": True}

record("persistent-pidfd-failure-still-closes-own-child-stdin", lambda: partial_constructor_fault("pidfd_failure"))
record("persistent-census-failure-still-closes-own-child-stdin", lambda: partial_constructor_fault("census_failure"))

def observer_setup_fault():
    directory = OUT / "observer_setup_failure"
    marker = OUT / "observer-setup-eof.txt"
    actual_observer = g["Observer"]
    created = []
    class Initialized:
        def __init__(self, argv, cwd, env, output):
            pipe_child(self, output, marker)
            self.entries = []
            self.pidfd = os.pidfd_open(self.process.pid)
            self.owner = g["proc"](self.process.pid)
            self.reader = threading.Thread(target=lambda: None)
            g["write"](output / "launch.json", {"pid": self.process.pid, "owner": self.owner})
            created.append(self)
        def initialize(self):
            raise AssertionError("observer failure must stop before MCP initialize")
        def close(self):
            self.process.stdin.close()
            code = self.process.wait(timeout=15)
            exited = bool(select.select([self.pidfd], [], [], 0)[0])
            os.close(self.pidfd)
            self.process.stdout.close()
            self.stderr.close()
            self.wire.close()
            value = {"returncode": code, "owner_pidfd_exited": exited, "process_group_gone": not group_exists(self.process.pid),
                     "reader_stopped": True, "forced_cleanup": []}
            g["write"](self.output / "close.json", value)
            return value
    class FailingObserver:
        def __init__(self, *args, **kwargs):
            raise OSError("injected persistent observer setup failure")
    frame = SimpleNamespace(CompressedMcp=Initialized, q=SimpleNamespace(process_group_exists=group_exists))
    state = {"sessions": [], "qualified": False}
    g["Observer"] = FailingObserver
    try:
        try:
            g["Session"]("observer_setup_failure", ["owned-pipe-child"], OUT, {}, OUT, state, frame)
        except OSError as error:
            assert "observer setup" in str(error)
        else:
            raise AssertionError("observer error was upgraded to success")
    finally:
        g["Observer"] = actual_observer
    assert created[0].process.poll() == 0 and marker.read_text() == "EOF observed"
    session = state["sessions"][0]
    assert session["close"]["forced_cleanup"] == [] and session["processes"]["observer_started"] is False
    assert session["wire_capture_drained"] is True
    assert set(session["client_artifacts"]) == {"wire.jsonl", "launch.json", "close.json", "stderr.log"}
    return {"pid": created[0].process.pid, "returncode": 0, "eof_marker": True,
            "partial_session_retains_close_and_wire_artifacts": True, "construction_success_claimed": False}

record("observer-setup-failure-retains-client-cleanup-handle", observer_setup_fault)

def envelope(value):
    return {"result": {"content": [{"type": "text", "text": json.dumps(value)}], "structuredContent": value}}

def late_success_after_close():
    root = OUT / "late_success"
    root.mkdir()
    native = root / "native"
    native.mkdir()
    fixture = native / "synthetic.elf"
    fixture.write_bytes(b"private driver transport stub; never passed to an engine")
    digest = hashlib.sha256(fixture.read_bytes()).hexdigest()
    (native / "cancel-request.json").write_text(json.dumps({
        "artifact_path": str(fixture), "artifact_sha256": digest, "function_address": "0x401106"}))
    original_session, original_proc = g["Session"], g["proc"]
    class Client:
        def __init__(self):
            self.entries, self.raw = [], []
            self.responses = queue.Queue()
        def append(self, direction, message):
            raw = (json.dumps(message) + "\n").encode()
            self.raw.append(raw)
            self.entries.append({"direction": direction, "monotonic_ns": time.monotonic_ns(),
                                 "synthetic_raw_index": len(self.raw) - 1})
        def original(self, entry):
            return self.raw[entry["synthetic_raw_index"]]
        def begin(self, method, params):
            self.append("sent", {"jsonrpc": "2.0", "id": 51, "method": method, "params": params})
            return 51
        def send(self, method, params):
            self.append("sent", {"jsonrpc": "2.0", "method": method, "params": params})
    class FakeObserver:
        def native_live(self, java, native):
            return {"observed_ns": time.monotonic_ns(),
                    "java": {"pid": 900000001, "start_ticks": 1},
                    "native": {"pid": 900000002, "start_ticks": 2},
                    "synthetic_test_observation": True}
    class FakeSession:
        def __init__(self, *args):
            self.client, self.observer, self.record = Client(), FakeObserver(), {}
        def call(self, label, tool, arguments, seconds=30):
            return envelope({"result": {"records": []}} if tool == "get_evidence_bundle" else {})
        def close(self):
            # This is deliberately later than the final pre-close bundle query.
            self.client.append("received", {"jsonrpc": "2.0", "id": 51,
                               "result": {"content": [{"type": "text", "text": "late successful result"}]}})
            self.record.update(wire_capture_drained=True,
                               close={"returncode": 0, "forced_cleanup": []})
    def absent(*args):
        raise FileNotFoundError("synthetic non-existent PID")
    g["Session"], g["proc"] = FakeSession, absent
    state = {"qualified": False, "sessions": []}
    args = SimpleNamespace(cancel_fixture=fixture, native_workspace=native,
                           ghidra_home=root / "synthetic-ghidra", java_home=root / "synthetic-java")
    try:
        g["cancellation_capture"](args, root, state, None, {}, ["transport-stub-no-process"])
    finally:
        g["Session"], g["proc"] = original_session, original_proc
    result = state["cancellation"]
    assert result["conclusion_computed_after_client_close"] is True
    assert len(result["successful_request_responses"]) == 1
    assert result["complete_retention_unchanged"] is True
    assert result["completed_result_excluded"] is False
    assert result["status"] == "LIVE_NOTIFICATION_OBSERVED_TERMINAL_EFFECT_NOT_ESTABLISHED"
    return {"late_success_found_only_during_close": True, "status": result["status"],
            "no_real_notification_or_engine": True}

record("late-success-during-drain-downgrades-cancellation-conclusion", late_success_after_close)

def exact_job_cleanup():
    class FakeSession:
        def __init__(self):
            self.calls = []
        def call(self, label, tool, arguments):
            self.calls.append((tool, dict(arguments)))
            assert set(arguments) <= {"host", "job_id", "limit"}
            assert arguments["host"] == "local" and arguments["job_id"] == "synthetic-new-owned"
            if tool == "process_status":
                return envelope({"job": {"id": "synthetic-new-owned", "host": "local"},
                                 "status": {"state": "cancelled"}})
            return envelope({})
    session = FakeSession()
    response_job = {"id": "synthetic-new-owned", "host": "local"}
    registry = [{"id": "synthetic-old-owned", "host": "local"}, response_job]
    result = g["stop_confirmed_new_job"](session, response_job, registry, ["synthetic-old-owned"])
    assert [x[0] for x in session.calls] == ["process_cancel", "process_status", "process_read"]
    assert result["target"] == {"host": "local", "job_id": "synthetic-new-owned"}
    assert result["terminal_observed"] is True and result["resource_cleanup_qualified"] is False
    rejected = []
    for job, rows, before in (
        (response_job, [], []),
        (response_job, registry, ["synthetic-new-owned"]),
        ({"id": "synthetic-new-owned", "host": "other"}, registry, [])):
        refusal = FakeSession()
        try:
            g["stop_confirmed_new_job"](refusal, job, rows, before)
        except AssertionError:
            assert refusal.calls == []
            rejected.append(True)
        else:
            raise AssertionError("unconfirmed or old identity reached cancellation")
    return {"calls": session.calls, "old_or_unconfirmed_or_other_host_refused_before_call": len(rejected),
            "original_request_never_used_for_cleanup": True, "no_real_job_cancelled": True}

record("unexpected-submission-cleanup-uses-only-confirmed-response-id", exact_job_cleanup)

report["all_pipe_children_reaped"] = all(p.poll() is not None for p in all_children)
report["driver_unchanged"] = hashlib.sha256(DRIVER.read_bytes()).hexdigest() == PIN
report["passed"] = (all(x["status"] == "PASS" for x in report["checks"])
                    and report["all_pipe_children_reaped"] and report["driver_unchanged"])
save()
print(json.dumps({k: report[k] for k in ("schema", "passed", "owned_python_pipe_processes_started",
                  "mcp_processes_started", "ghidra_processes_started", "all_pipe_children_reaped", "driver_unchanged")}))
for row in report["checks"]:
    print(json.dumps({"check": row["id"], "status": row["status"], "error": row.get("error")}))
sys.exit(0 if report["passed"] else 1)
