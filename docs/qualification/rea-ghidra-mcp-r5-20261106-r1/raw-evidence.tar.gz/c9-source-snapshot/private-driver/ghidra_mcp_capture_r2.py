#!/usr/bin/env python3
# Copyright 2026 TrillionniumFoundation
# SPDX-License-Identifier: Apache-2.0
"""Private finite MCP capture. Preserve actual wire and report all unqualified scope."""
from __future__ import annotations
import argparse
import hashlib
import json
import os
import queue
from pathlib import Path
import select
import shutil
import signal
import subprocess
import sys
import threading
import time
import traceback

INPUT_SHA = "ec301f409d22314b43b4392fa80ada28213cd75ca77c6cbbbbfe1454555dd64a"
RELEASE_SHA = "ddac49f903da9d5bac833e5cc79395098b9c33cfd3279be5f31bd00387d2d4db"
MANIFEST_SHA = "f9726184ffcf1a3f9c192e93de04d66e1796b166ead8b3c1f0818559656fcdbe"
NODE_SHA = "94efd062ed066c1a0b332e18249859c905e920eeada5df55d24c99b919629a90"
JAVA_SHA = "1bf1aaef01e4f8d7c85d913c60fb2ee4624cbe54d4053254c59657b7ea913b25"

def write(path, value):
    raw = (json.dumps(value, indent=2, ensure_ascii=False, allow_nan=False) + "\n").encode()
    temp = path.with_name(path.name + ".pending")
    temp.write_bytes(raw)
    os.replace(temp, path)

def sha(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()

def artifact(path, root):
    path = Path(path)
    return {"path": str(path.relative_to(root)), "bytes": path.stat().st_size, "sha256": sha(path)}

def save_raw(path, raw, root):
    with path.open("xb") as f:
        f.write(raw)
    return artifact(path, root)

def json_member(raw, path):
    """Return an exact UTF-8 JSON value slice, with offsets in the original frame."""
    s = raw.decode("utf-8", errors="strict")
    decoder = json.JSONDecoder()
    lo, hi = 0, len(s)
    for selected in path:
        i = lo
        while i < hi and s[i].isspace():
            i += 1
        if s[i] != "{":
            return None
        i += 1
        found = None
        while i < hi:
            while i < hi and (s[i].isspace() or s[i] == ","):
                i += 1
            if s[i] == "}":
                break
            key, i = decoder.raw_decode(s, i)
            while s[i].isspace():
                i += 1
            assert s[i] == ":"
            i += 1
            while s[i].isspace():
                i += 1
            start = i
            _, i = decoder.raw_decode(s, i)
            if key == selected:
                found = (start, i)
                break
        if found is None:
            return None
        lo, hi = found
    return s[lo:hi].encode(), len(s[:lo].encode()), len(s[:hi].encode())

def payload(response, required=True):
    result = response.get("result")
    if not isinstance(result, dict) or result.get("isError"):
        if required:
            raise ValueError("expected successful CallToolResult")
        return None
    texts = [x["text"] for x in result.get("content", []) if x.get("type") == "text"]
    parsed = json.loads(texts[0]) if len(texts) == 1 else None
    if "structuredContent" in result:
        assert parsed == result["structuredContent"], "structured/text payloads disagree"
        return result["structuredContent"]
    if required:
        assert parsed is not None
    return parsed

def proc(pid):
    root = Path("/proc") / str(pid)
    raw = (root / "stat").read_text()
    t = raw[raw.rfind(")") + 2:].split()
    result = {"pid": pid, "state": t[0], "parent_pid": int(t[1]),
              "process_group": int(t[2]), "start_ticks": int(t[19])}
    result["command"] = (root / "cmdline").read_bytes().split(b"\0")
    result["command"] = [x.decode("utf-8", errors="replace") for x in result["command"] if x]
    try:
        result["executable"] = os.readlink(root / "exe")
    except FileNotFoundError:
        result["executable"] = None
    result["cgroup"] = (root / "cgroup").read_text()
    return result

class Observer:
    """Phase-independent live descendant samples, never a complete birth history."""
    def __init__(self, client, out):
        self.root = proc(client.process.pid)
        self.out = out
        self.lock = threading.Lock()
        self.seen = {}
        self.errors = []
        self.stop = threading.Event()
        self.thread = threading.Thread(target=self.run, daemon=True)
        self.thread.start()

    def census(self):
        try:
            current = proc(self.root["pid"])
        except FileNotFoundError:
            return {}
        if current["start_ticks"] != self.root["start_ticks"]:
            raise RuntimeError("MCP owner PID changed identity")
        line = next(x for x in current["cgroup"].splitlines() if x.startswith("0::"))
        cgroup_file = Path("/sys/fs/cgroup") / line[3:].lstrip("/") / "cgroup.procs"
        ids = [int(x) for x in cgroup_file.read_text().split()]
        assert len(ids) <= 20000, "private ownership census unexpectedly large"
        rows = {}
        for pid in ids:
            try:
                rows[pid] = proc(pid)
            except (FileNotFoundError, ProcessLookupError):
                continue
        owned = {}
        for pid, row in rows.items():
            if pid == self.root["pid"]:
                continue
            chain, parent, visited = [], row["parent_pid"], set()
            while parent in rows and parent not in visited:
                visited.add(parent)
                node = rows[parent]
                chain.append({"pid": parent, "start_ticks": node["start_ticks"],
                              "executable": node["executable"]})
                if parent == self.root["pid"]:
                    assert node["start_ticks"] == self.root["start_ticks"]
                    owned[pid] = {**row, "observed_ancestry": chain}
                    break
                parent = node["parent_pid"]
        return owned

    def run(self):
        while not self.stop.is_set():
            try:
                now = time.monotonic_ns()
                rows = self.census()
                with self.lock:
                    for row in rows.values():
                        key = (row["pid"], row["start_ticks"])
                        if key not in self.seen:
                            fd = None
                            try:
                                fd = os.pidfd_open(row["pid"])
                                again = proc(row["pid"])
                                if again["start_ticks"] != row["start_ticks"]:
                                    os.close(fd)
                                    continue
                            except BaseException as error:
                                if fd is not None:
                                    os.close(fd)
                                if isinstance(error, (FileNotFoundError, ProcessLookupError)):
                                    continue
                                raise
                            self.seen[key] = {**row, "first_observed_ns": now,
                                              "last_observed_ns": now, "pidfd": fd}
                        else:
                            self.seen[key]["last_observed_ns"] = now
            except (FileNotFoundError, ProcessLookupError):
                pass
            except BaseException as error:
                with self.lock:
                    self.errors.append(repr(error))
            self.stop.wait(0.02)

    def native_live(self, java_path, native_path):
        for row in self.census().values():
            if row["executable"] != str(native_path) or row["state"] == "Z":
                continue
            parents = [p for p in row["observed_ancestry"] if p["executable"] == str(java_path)]
            if not parents:
                continue
            java = proc(parents[0]["pid"])
            if java["start_ticks"] != parents[0]["start_ticks"] or java["state"] == "Z":
                continue
            return {"observed_ns": time.monotonic_ns(), "native": row, "java": java}
        return None

    def finish(self):
        self.stop.set()
        self.thread.join(timeout=2)
        assert not self.thread.is_alive(), "ownership observer did not stop"
        final = []
        with self.lock:
            values = list(self.seen.values())
        for row in values:
            value = {k: v for k, v in row.items() if k != "pidfd"}
            try:
                current = proc(row["pid"])
                value["final_state"] = ("pid_reused" if current["start_ticks"] != row["start_ticks"]
                                        else current["state"])
            except (FileNotFoundError, ProcessLookupError):
                value["final_state"] = "absent"
            value["pidfd_exited"] = bool(select.select([row["pidfd"]], [], [], 0)[0])
            value["exit_confirmed"] = value["pidfd_exited"] and value["final_state"] in ("absent", "pid_reused")
            value["forced_cleanup"] = []
            final.append(value)
        # Cleanup remains a failed lifecycle, even when this exact-owner fallback succeeds.
        remaining = [(row, value) for row, value in zip(values, final) if not value["exit_confirmed"]]
        for sig in (signal.SIGTERM, signal.SIGKILL):
            for row, value in remaining:
                try:
                    current = proc(row["pid"])
                    if (current["start_ticks"] == row["start_ticks"]
                            and current["cgroup"] == self.root["cgroup"]
                            and not select.select([row["pidfd"]], [], [], 0)[0]):
                        signal.pidfd_send_signal(row["pidfd"], sig, None, 0)
                        value["forced_cleanup"].append(sig.name)
                except (FileNotFoundError, ProcessLookupError):
                    pass
            deadline = time.monotonic() + 2
            while time.monotonic() < deadline and any(not select.select([row["pidfd"]], [], [], 0)[0]
                                                       for row, _ in remaining):
                time.sleep(0.02)
        for row, value in zip(values, final):
            try:
                current = proc(row["pid"])
                value["after_fallback_state"] = ("pid_reused" if current["start_ticks"] != row["start_ticks"] else current["state"])
            except (FileNotFoundError, ProcessLookupError):
                value["after_fallback_state"] = "absent"
            value["pidfd_after_fallback_exited"] = bool(select.select([row["pidfd"]], [], [], 0)[0])
            os.close(row["pidfd"])
        record = {"schema": "hepta.rea.mcp-descendant-observations.v1",
                  "scope": "sampled live descendants of exact MCP PID/start identity; no complete birth-history claim",
                  "owner": self.root, "sampling_seconds": 0.02, "observations": final,
                  "errors": self.errors,
                  "all_observed_original_identities_exited_without_fallback":
                  not self.errors and all(x["exit_confirmed"] for x in final)}
        write(self.out, record)
        return record

def guarded_client(frame, argv, cwd, env, output, report):
    # Hold the partial object before Popen can succeed inside inherited __init__.
    client = frame.CompressedMcp.__new__(frame.CompressedMcp)
    try:
        frame.CompressedMcp.__init__(client, argv, cwd, env, output)
        return client
    except BaseException as original:
        cleanup = {"schema": "hepta.rea.partial-mcp-construction-cleanup.v1",
                   "argv": argv, "cwd": str(cwd), "original_failure": repr(original),
                   "forced_cleanup": [], "errors": []}
        handles = []
        process = getattr(client, "process", None)
        try:
            if process is not None:
                try:
                    owner = proc(process.pid)
                    probe = Observer.__new__(Observer)
                    probe.root = owner
                    members = [owner] + list(probe.census().values())
                    for row in members:
                        fd = None
                        try:
                            fd = os.pidfd_open(row["pid"])
                            current = proc(row["pid"])
                            if current["start_ticks"] != row["start_ticks"]:
                                os.close(fd)
                                continue
                            handles.append((row, fd))
                        except (FileNotFoundError, ProcessLookupError):
                            if fd is not None:
                                os.close(fd)
                except (FileNotFoundError, ProcessLookupError):
                    pass
                if process.stdin is not None and not process.stdin.closed:
                    process.stdin.close()
                try:
                    process.wait(timeout=15)
                except subprocess.TimeoutExpired:
                    pass
                for sig in (signal.SIGTERM, signal.SIGKILL):
                    for row, fd in handles:
                        try:
                            current = proc(row["pid"])
                            if (current["start_ticks"] == row["start_ticks"]
                                    and current["cgroup"] == row["cgroup"]
                                    and not select.select([fd], [], [], 0)[0]):
                                signal.pidfd_send_signal(fd, sig, None, 0)
                                cleanup["forced_cleanup"].append(
                                    {"pid": row["pid"], "start_ticks": row["start_ticks"], "signal": sig.name})
                        except (FileNotFoundError, ProcessLookupError):
                            pass
                    deadline = time.monotonic() + 2
                    while time.monotonic() < deadline and any(
                            not select.select([fd], [], [], 0)[0] for _, fd in handles):
                        time.sleep(0.02)
                cleanup["returncode"] = process.wait(timeout=2)
                cleanup["process_group_gone"] = not frame.q.process_group_exists(process.pid)
        except BaseException as secondary:
            cleanup["errors"].append(repr(secondary))
        finally:
            cleanup["observed_processes"] = []
            for row, fd in handles:
                try:
                    current = proc(row["pid"])
                    state = "pid_reused" if current["start_ticks"] != row["start_ticks"] else current["state"]
                except (FileNotFoundError, ProcessLookupError):
                    state = "absent"
                cleanup["observed_processes"].append(
                    {"pid": row["pid"], "start_ticks": row["start_ticks"],
                     "final_state": state, "pidfd_exited": bool(select.select([fd], [], [], 0)[0])})
                os.close(fd)
            reader = getattr(client, "reader", None)
            if reader is not None and reader.ident is not None:
                reader.join(timeout=2)
            cleanup["reader_stopped"] = reader is None or not reader.is_alive()
            for stream in (getattr(process, "stdout", None), getattr(client, "stderr", None),
                           getattr(client, "wire", None)):
                if stream is not None and not stream.closed:
                    stream.close()
            if hasattr(client, "pidfd"):
                os.close(client.pidfd)
            path = output.parent / (output.name + "-partial-construction.json")
            write(path, cleanup)
            report.setdefault("partial_construction_failures", []).append(artifact(path, output.parent))
            original.add_note("Partial MCP construction cleanup is retained at " + str(path))
        raise

class Session:
    def __init__(self, label, argv, cwd, env, root, report, frame):
        self.root, self.report = root, report
        self.label = label
        self.client = None
        self.observer = None
        self.record = {"id": label, "calls": []}
        report["sessions"].append(self.record)
        try:
            self.client = guarded_client(frame, argv, cwd, env, root / label, report)
            self.observer = Observer(self.client, root / (label + "-processes.json"))
            self.record["initialize"] = self.client.initialize()
            self.tools = self.client.tools()
            write(root / (label + "-catalog.json"), self.tools)
            self.record["catalog"] = artifact(root / (label + "-catalog.json"), root)
            self.catalog = {x["name"]: x for x in self.tools}
        except BaseException as original:
            try:
                if self.client is not None:
                    self.close()
            except BaseException as cleanup:
                report.setdefault("secondary_failures", []).append(repr(cleanup))
                original.add_note("MCP construction cleanup failed: " + repr(cleanup))
            raise

    def call(self, label, tool, arguments, seconds=30):
        assert tool in self.catalog, "tool not advertised: " + tool
        first = len(self.client.entries)
        started = time.monotonic()
        request_id = self.client.begin("tools/call", {"name": tool, "arguments": arguments})
        case = {"id": label, "tool": tool, "arguments": arguments, "request_id": request_id,
                "deadline_seconds": seconds}
        self.record["calls"].append(case)
        try:
            response = self.client.receive(request_id, seconds=seconds)
            sent = []
            candidates = []
            for entry in self.client.entries[first:]:
                if entry["direction"] == "sent":
                    raw = self.client.original(entry)
                    message = json.loads(raw)
                    if message.get("id") == request_id:
                        assert message["method"] == "tools/call" and message["params"] == {
                            "name": tool, "arguments": arguments}
                        sent.append(entry)
                if entry["direction"] == "received":
                    raw = self.client.original(entry)
                    if json.loads(raw).get("id") == request_id:
                        candidates.append((entry, raw))
            assert len(sent) == 1, "missing or repeated original request frame"
            case["request_wire"] = sent[0]
            assert len(candidates) == 1, "missing or repeated original response frame"
            entry, raw = candidates[0]
            case["response_wire"] = entry
            case["response_parsed"] = response
            for key in ("result", "error"):
                selected = json_member(raw, [key])
                if selected is None:
                    continue
                value, start, end = selected
                ref = save_raw(self.root / (self.label + "-" + label + "-" + key + ".raw.json"), value, self.root)
                case[key + "_raw"] = {**ref, "source_frame_range": [start, end]}
            selected = json_member(raw, ["result", "structuredContent"])
            if selected is not None:
                value, start, end = selected
                ref = save_raw(self.root / (self.label + "-" + label + "-structured.raw.json"), value, self.root)
                case["structured_content_raw"] = {**ref, "source_frame_range": [start, end]}
            case["content_text_utf8"] = []
            for i, content in enumerate(response.get("result", {}).get("content", [])):
                if content.get("type") == "text":
                    case["content_text_utf8"].append(save_raw(
                        self.root / (self.label + "-" + label + "-text-" + str(i) + ".utf8"),
                        content["text"].encode(), self.root))
            case["status"] = "OBSERVED"
            return response
        except BaseException as error:
            case["status"] = "FAILED_CAPTURE"
            case["failure"] = repr(error)
            raise
        finally:
            case["seconds"] = time.monotonic() - started
            write(self.root / "capture.json", self.report)
            print(json.dumps({"event": "mcp_call", "session": self.label, "case": label,
                              "status": case.get("status"), "seconds": case["seconds"]}), flush=True)

    def close(self):
        try:
            self.record["close"] = self.client.close()
        finally:
            try:
                if self.observer is not None:
                    self.record["processes"] = self.observer.finish()
                else:
                    self.record["processes"] = {"observer_started": False}
            finally:
                directory = self.root / self.label
                self.record["client_artifacts"] = {
                    name: artifact(directory / name, self.root)
                    for name in ("wire.jsonl", "launch.json", "close.json", "stderr.log")
                    if (directory / name).is_file()}
                self.record["wire_capture_drained"] = not self.client.reader.is_alive()
                write(self.root / "capture.json", self.report)
        close = self.record["close"]
        assert (close["returncode"] == 0 and close["owner_pidfd_exited"]
                and close["process_group_gone"] and close["reader_stopped"]
                and not close["forced_cleanup"]), close
        if self.observer is not None:
            assert self.record["processes"]["all_observed_original_identities_exited_without_fallback"]


def close_session(session, report):
    primary = sys.exc_info()[1]
    try:
        session.close()
    except BaseException as cleanup:
        if primary is None:
            raise
        report.setdefault("secondary_failures", []).append(repr(cleanup))
        primary.add_note("MCP cleanup also failed: " + repr(cleanup))

def check(report, name, passed):
    report["checks"].append({"id": name, "equal": bool(passed)})

def native_job_rows(response):
    value = payload(response)
    rows = value if isinstance(value, list) else value.get("jobs")
    assert isinstance(rows, list) and rows, "expected nonempty private durable registry"
    assert all(isinstance(row, dict) and isinstance(row.get("id"), str) for row in rows)
    assert len({row["id"] for row in rows}) == len(rows)
    return rows

def job_directory_snapshot(roots):
    return {str(root): sorted(path.name for path in root.iterdir()) for root in roots}

def native_capture(args, root, report, frame):
    workspace = args.native_workspace
    runtime = workspace / "hepta-runtime-qualified"
    assert sha(runtime) == args.binary_sha256
    report["runtime"] = {"path": str(runtime), "sha256": sha(runtime), "bytes": runtime.stat().st_size}
    report["native_capture_scope"] = {
        "retained_report_reads": 8,
        "negative_start_surface_replays": 5,
        "negative_replays_are_read_only": False,
        "negative_requirement": "same request/key, error result, no new retained durable job identity or job directory",
        "complete_upstream_evidence_provided_by_native": False}
    inputs = root / "harness-inputs"
    inputs.mkdir()
    names = ["config.json", "requests.json", "qualification.json",
             "functions-result.json", "function-result.json", "xrefs-result.json", "decompile-result.json",
             "interior-function.json", "interior-xrefs.json", "interior-decompile.json",
             "no-function-refusal.json", "same-key-conflict.json"] + [
                 "invalid-selector-" + str(i) + ".json" for i in range(4)]
    report["harness_inputs"] = {}
    for name in names:
        saved = inputs / name
        saved.write_bytes((workspace / name).read_bytes())
        report["harness_inputs"][name] = artifact(saved, root)
    qualification = json.loads((inputs / "qualification.json").read_bytes())
    assert qualification["qualified"] is True
    config = json.loads((inputs / "config.json").read_bytes())
    remote_root = Path(config["hosts"]["local"]["remote_state_dir"])
    assert remote_root.is_relative_to(workspace)
    env = {"PATH": "/usr/bin:/bin", "LANG": "C.UTF-8",
           "HEPTA_EFFECT_OWNER_FENCE_DIR": str(workspace / "authority"),
           "HEPTA_EFFECT_OWNER_SELF": "v4", "HEPTA_EFFECT_OWNER_FENCE_REQUIRED": "1"}
    session = None
    try:
        session = Session("native-readback", [str(runtime), "mcp", "--runtime-config",
                          str(workspace / "config.json")], workspace, env, root, report, frame)
        requests = json.loads((inputs / "requests.json").read_bytes())
        for label in ("functions", "function", "xrefs", "decompile"):
            response = session.call(label + "-entry", "rea_static_read", requests[label])
            saved = json.loads((inputs / (label + "-result.json")).read_bytes())
            check(report, label + "-entry-report-exact", payload(response) == saved)
        for operation in ("function", "xrefs", "decompile"):
            saved = json.loads((inputs / ("interior-" + operation + ".json")).read_bytes())
            response = session.call(operation + "-interior", "rea_static_read", saved["request"])
            check(report, operation + "-interior-report-exact", payload(response) == saved["result"])
        saved = json.loads((inputs / "no-function-refusal.json").read_bytes())
        response = session.call("function-unmapped", "rea_static_read", saved["request"])
        check(report, "unmapped-retained-backend-error-exact", payload(response) == saved["result"])
        before_rows = native_job_rows(session.call("jobs-before-negative-replays", "process_list", {"host": "local"}))
        before_ids = sorted(row["id"] for row in before_rows)
        assert set(qualification["job_ids"].values()).issubset(before_ids)
        job_roots = sorted({Path(row["remote_job_dir"]).parent for row in before_rows})
        assert all(path.is_relative_to(remote_root) and path.is_dir() and not path.is_symlink()
                   for path in job_roots)
        before_dirs = job_directory_snapshot(job_roots)
        report["negative_replay_registry_before"] = {"job_ids": before_ids, "job_directories": before_dirs}
        for index, name in enumerate(["same-key-conflict.json"] + ["invalid-selector-" + str(i) + ".json" for i in range(4)]):
            saved = json.loads((inputs / name).read_bytes())
            response = session.call(name[:-5], "rea_static_start", saved["request"])
            equal = response.get("result") == saved["call_tool_result"]
            session.record["calls"][-1]["equal_to_harness_calltool_result"] = equal
            check(report, name[:-5] + "-calltool-result-exact", equal)
            after_rows = native_job_rows(session.call("jobs-after-negative-" + str(index), "process_list", {"host": "local"}))
            after_ids = sorted(row["id"] for row in after_rows)
            after_dirs = job_directory_snapshot(job_roots)
            check(report, name[:-5] + "-no-new-job-identity", after_ids == before_ids)
            check(report, name[:-5] + "-no-new-job-directory", after_dirs == before_dirs)
            is_error = response.get("result", {}).get("isError") is True
            if not is_error or after_ids != before_ids or after_dirs != before_dirs:
                value = payload(response, required=False)
                job = value.get("job") if isinstance(value, dict) else None
                report["unexpected_negative_submission"] = {
                    "case": name, "request": saved["request"], "response": response,
                    "new_job_ids": sorted(set(after_ids) - set(before_ids)),
                    "job_directories_after": after_dirs}
                if isinstance(job, dict) and isinstance(job.get("id"), str) and job["id"] not in before_ids:
                    report["unexpected_negative_submission"]["confirmed_new_job"] = job
                    cleanup = session.call("unexpected-new-job-cancel", "rea_static_cancel", saved["request"])
                    report["unexpected_negative_submission"]["cancel"] = cleanup
                    deadline = time.monotonic() + 125
                    while time.monotonic() < deadline:
                        final = session.call("unexpected-new-job-read-" + str(len(session.record["calls"])),
                                             "rea_static_read", saved["request"])
                        completed = payload(final)
                        if completed.get("complete") is True:
                            report["unexpected_negative_submission"]["terminal_read"] = final
                            break
                        time.sleep(0.1)
                raise RuntimeError("negative start surface did not remain refused without a new durable identity; stopped further negative replays")
        report["completed"] = True
    finally:
        if session is not None:
            close_session(session, report)
    assert sha(runtime) == args.binary_sha256
    report["harness_inputs_unchanged"] = all(
        sha(workspace / name) == item["sha256"] for name, item in report["harness_inputs"].items())
    assert report["harness_inputs_unchanged"]


def original_capture(args, root, report, frame, q, api, engine):
    npm, node = args.package, args.node
    baseline = json.loads(args.baseline_config.read_bytes())["rea_static_profiles"]["owned_ghidra"]
    identity_profile = json.loads(json.dumps(baseline))
    pins = identity_profile["ghidra_engine"]
    pins.update(bridge_revision=4, manifest_path=str(args.manifest), manifest_sha256=MANIFEST_SHA)
    assert Path(pins["java_home"]) == args.java_home and Path(pins["installation_root"]) == args.ghidra_home
    assert sha(args.manifest) == MANIFEST_SHA and sha(node) == NODE_SHA
    assert sha(args.java_home / "bin/java") == JAVA_SHA and sha(args.fixture) == INPUT_SHA
    report["reference_before"] = q.reference_package(npm, args.tarball)
    report["node"] = {"path": str(node), "sha256": sha(node),
                      "version": subprocess.check_output([str(node), "--version"], text=True).strip()}
    report["identity_profile"] = identity_profile
    _, report["installation_before"] = api.verify_installation(identity_profile, time.monotonic() + 120)
    manifest = json.loads(args.manifest.read_bytes())
    report["release_before"] = engine.verify_v4_release_members(args.release_archive, args.ghidra_home,
                                                                manifest["files"], RELEASE_SHA)
    # The original headless entry also executes release support scripts.
    import zipfile
    support = {}
    with zipfile.ZipFile(args.release_archive) as archive:
        for member in archive.infolist():
            prefix = "ghidra_12.1.4_PUBLIC/support/"
            if member.is_dir() or not member.filename.startswith(prefix):
                continue
            relative = member.filename[len("ghidra_12.1.4_PUBLIC/"):]
            expected = hashlib.sha256(archive.read(member)).hexdigest()
            assert sha(args.ghidra_home / relative) == expected, relative
            support[relative] = expected
    report["support_before"] = support
    fixture = root / "owned.elf"
    shutil.copyfile(args.fixture, fixture)
    assert sha(fixture) == INPUT_SHA
    for name in ("java-user", "tmp", "cache", "xdg-config", "data"):
        (root / name).mkdir()
    env = {"PATH": str(args.java_home / "bin") + ":/usr/bin:/bin", "LANG": "C", "LC_ALL": "C",
           "REA_MCP_INPUT_SCHEMA_PROFILE": "full", "REA_MCP_OUTPUT_SCHEMA_PROFILE": "full",
           "GHIDRA_HEADLESS_MAXMEM": "512M", "GHIDRA_INSTALL_DIR": str(args.ghidra_home),
           "JAVA_HOME": str(args.java_home), "REA_ANALYSIS_PROVIDER": "ghidra",
           "REA_GHIDRA_STARTUP_TIMEOUT_MS": "240000",
           "JDK_JAVA_OPTIONS": "-Duser.home=" + str(root / "java-user") + " -Djava.io.tmpdir=" + str(root / "tmp"),
           "TMPDIR": str(root / "tmp"), "XDG_CACHE_HOME": str(root / "cache"),
           "XDG_CONFIG_HOME": str(root / "xdg-config"), "XDG_DATA_HOME": str(root / "data")}
    argv = [str(node), str(npm / "scripts/rea.mjs"), "mcp"]
    report["request_deadlines"] = {"ordinary_seconds": 30, "first_analysis_seconds": 270,
                                    "original_config_startup_ms": 240000,
                                    "native_deadlines_equivalent": False}
    first = None
    complete = None
    try:
        first = Session("original-main", argv, root, env, root, report, frame)
        payload(first.call("open", "open_binary", {"path": str(fixture), "provider_id": "ghidra"}, seconds=270))
        funcs = payload(first.call("functions", "list_procedures", {}, seconds=270))
        assert funcs["operation"] == "list_procedures" and funcs["provider"]["id"] == "ghidra"
        report["inventory_parent_evidence_id"] = funcs["evidence_id"]
        for label, tool in (("function", "procedure_info"), ("incoming", "procedure_references"),
                            ("outgoing", "procedure_references"), ("decompile", "procedure_pseudo_code")):
            for suffix, address in (("entry", "0x401106"), ("interior", "0x401107")):
                arguments = {"procedure": address}
                if label in ("incoming", "outgoing"):
                    arguments["direction"] = label
                value = payload(first.call(label + "-" + suffix, tool, arguments))
                assert value["provider"]["id"] == "ghidra"
        first.call("function-unmapped", "procedure_info", {"procedure": "0x0"})
        first.call("invalid-selector-type", "procedure_info", {"procedure": 42})
        first.call("invalid-extra-field", "procedure_info", {"procedure": "0x401106", "flags": "caller-script"})
        first.call("functions-summary", "list_procedures", {"detail": "summary"})
        pages = []
        for offset in (0, 7, 14):
            args_view = {"source": {"kind": "retained-evidence", "evidence_id": funcs["evidence_id"]},
                         "view": {"kind": "native-inventory", "offset": offset, "limit": 7}}
            pages.append(payload(first.call("inventory-page-" + str(offset), "inspect_analysis_view", args_view)))
        page_args = {"source": {"kind": "retained-evidence", "evidence_id": funcs["evidence_id"]},
                     "view": {"kind": "native-inventory", "offset": 0, "limit": 7}}
        again = payload(first.call("inventory-page-repeat", "inspect_analysis_view", page_args))
        check(report, "same-retained-page-exact", again == pages[0])
        first.call("bundle-summary", "get_evidence_bundle", {"detail": "summary"})
        complete = payload(first.call("bundle-complete", "get_evidence_bundle", {}))["result"]
        export = root / "original-complete.bundle.json"
        payload(first.call("export", "export_evidence_bundle", {"path": str(export)}))
        check(report, "export-equals-complete-bundle", json.loads(export.read_bytes()) == complete)
        report["complete_export"] = artifact(export, root)
        check(report, "export-preserves-complete-bundle", payload(first.call("bundle-after-export", "get_evidence_bundle", {}))["result"] == complete)
        payload(first.call("close-binary", "close_binary", {}))
    finally:
        if first is not None:
            close_session(first, report)
    second = None
    try:
        second = Session("original-import", argv, root, env, root, report, frame)
        empty = payload(second.call("empty-before-import", "get_evidence_bundle", {}))["result"]
        check(report, "new-session-has-no-implicit-retention", empty["records"] == [])
        payload(second.call("import", "import_evidence_bundle", {"path": str(export)}))
        imported = payload(second.call("complete-after-import", "get_evidence_bundle", {}))["result"]
        check(report, "explicit-import-exact-complete-readback", imported == complete)
        check(report, "explicit-import-equals-exported-bytes-value", imported == json.loads(export.read_bytes()))
        payload(second.call("summary-after-import", "get_evidence_bundle", {"detail": "summary"}))
        imported_page = payload(second.call("page-after-import", "inspect_analysis_view", page_args))
        check(report, "imported-retained-page-exact", imported_page == pages[0])
        report["explicit_import_exact_readback"] = imported == complete
    finally:
        if second is not None:
            close_session(second, report)
    if args.cancel_fixture is not None:
        cancellation_capture(args, root, report, frame, env, argv)
    _, report["installation_after"] = api.verify_installation(identity_profile, time.monotonic() + 120)
    assert report["installation_after"] == report["installation_before"]
    assert sha(args.release_archive) == RELEASE_SHA
    assert all(sha(args.ghidra_home / path) == digest for path, digest in support.items())
    report["support_after_equal"] = True
    report["reference_after"] = q.reference_package(npm, args.tarball)
    assert report["reference_after"] == report["reference_before"] and sha(node) == NODE_SHA
    assert sha(fixture) == INPUT_SHA
    report["completed"] = True

def cancellation_capture(args, root, report, frame, env, argv):
    value = {"attempts_budget": 1, "attempts": 0, "status": "NOT_OBSERVED",
             "native_durable_job_semantics_available": False}
    report["cancellation"] = value
    target = root / "owned_cancel.elf"
    request_path = args.native_workspace / "cancel-request.json"
    request_raw = request_path.read_bytes()
    request = json.loads(request_raw)
    assert args.cancel_fixture.resolve(strict=True) == Path(request["artifact_path"]).resolve(strict=True)
    expected = request["artifact_sha256"]
    assert sha(args.cancel_fixture) == expected
    value["native_request"] = save_raw(root / "native-cancel-request.json", request_raw, root)
    shutil.copyfile(args.cancel_fixture, target)
    assert sha(target) == expected and sha(args.cancel_fixture) == expected
    value["fixture"] = {"sha256": expected, "bytes": target.stat().st_size,
                        "source": str(args.cancel_fixture)}
    session = None
    try:
        session = Session("original-cancel", argv, root, env, root, report, frame)
        payload(session.call("open", "open_binary", {"path": str(target), "provider_id": "ghidra"}, seconds=270))
        baseline_bundle = payload(session.call("bundle-before-cancel", "get_evidence_bundle", {}))["result"]
        params = {"name": "procedure_pseudo_code", "arguments": {"procedure": request["function_address"]}}
        request_id = session.client.begin("tools/call", params)
        value.update(attempts=1, request_id=request_id, request=params, sent_ns=time.monotonic_ns())
        write(root / "capture.json", report)
        deadline = time.monotonic() + 270
        native_path = args.ghidra_home / "Ghidra/Features/Decompiler/os/linux_x86_64/decompile"
        witness = None
        completed = None
        while time.monotonic() < deadline:
            try:
                queued = session.client.responses.get_nowait()
                if isinstance(queued, BaseException):
                    raise queued
                if queued["id"] == request_id:
                    completed = queued
                    break
                session.client.pending[queued["id"]] = queued
            except queue.Empty:
                pass
            witness = session.observer.native_live(args.java_home / "bin/java", native_path)
            if witness is not None:
                break
            time.sleep(0.01)
        value["live_witness"] = witness
        value["response_before_cancel"] = completed
        if witness is not None and completed is None:
            session.client.send("notifications/cancelled", {"requestId": request_id,
                                 "reason": "owned fixed-input live native decompile cancellation observation"})
            value["notification_sent_ns"] = time.monotonic_ns()
            deadline = time.monotonic() + 20
            final = []
            while time.monotonic() < deadline:
                final = []
                for row in (witness["java"], witness["native"]):
                    try:
                        current = proc(row["pid"])
                        state = "pid_reused" if current["start_ticks"] != row["start_ticks"] else current["state"]
                    except (FileNotFoundError, ProcessLookupError):
                        state = "absent"
                    final.append({"pid": row["pid"], "start_ticks": row["start_ticks"], "state": state})
                if all(row["state"] in ("absent", "pid_reused") for row in final):
                    break
                time.sleep(0.02)
            value["original_processes_after_cancel"] = final
            value["original_processes_gone"] = all(row["state"] in ("absent", "pid_reused") for row in final)
            after = payload(session.call("bundle-after-cancel", "get_evidence_bundle", {}))
            value["connection_recovered"] = True
            value["retained_record_count_before_cancel"] = len(baseline_bundle["records"])
            value["retained_record_count_after_cancel"] = len(after["result"]["records"])
            value["complete_retention_unchanged"] = after["result"] == baseline_bundle
            replies = []
            success_replies = []
            for entry in session.client.entries:
                if entry["direction"] == "received":
                    raw = session.client.original(entry)
                    message = json.loads(raw)
                    if message.get("id") == request_id:
                        replies.append(entry)
                        if "result" in message and message["result"].get("isError") is not True:
                            success_replies.append(entry)
            value["cancelled_request_responses"] = replies
            value["response_observed_before_notification"] = any(
                row["monotonic_ns"] <= value["notification_sent_ns"] for row in replies)
            value["successful_request_responses"] = success_replies
            value["completed_result_excluded"] = not success_replies and value["complete_retention_unchanged"]
            value["status"] = ("OBSERVED_LIVE_CANCEL_NOTIFICATION_WITH_NO_COMPLETED_RESULT_AND_RECOVERY"
                               if value["original_processes_gone"]
                               and not value["response_observed_before_notification"]
                               and value["completed_result_excluded"]
                               else "LIVE_NOTIFICATION_OBSERVED_TERMINAL_EFFECT_NOT_ESTABLISHED")
            value["causal_or_durable_job_equivalence_claimed"] = False
        else:
            value["reason"] = "no live same-private-JVM native decompile before completion or deadline"
        payload(session.call("close-binary", "close_binary", {}))
    finally:
        if session is not None:
            close_session(session, report)
        write(root / "capture.json", report)
    assert sha(target) == expected

def main():
    p = argparse.ArgumentParser()
    p.add_argument("--mode", choices=("native-readback", "original"), required=True)
    p.add_argument("--repo", type=Path, required=True)
    p.add_argument("--workspace", type=Path, required=True)
    p.add_argument("--native-workspace", type=Path, required=True)
    p.add_argument("--binary-sha256")
    p.add_argument("--package", type=Path)
    p.add_argument("--tarball", type=Path)
    p.add_argument("--node", type=Path, default=Path("/usr/bin/node"))
    p.add_argument("--java-home", type=Path)
    p.add_argument("--ghidra-home", type=Path)
    p.add_argument("--release-archive", type=Path)
    p.add_argument("--fixture", type=Path)
    p.add_argument("--manifest", type=Path)
    p.add_argument("--baseline-config", type=Path)
    p.add_argument("--cancel-fixture", type=Path)
    args = p.parse_args()
    root = args.workspace
    assert root.is_absolute() and not root.exists(), "fresh absolute workspace required"
    root.mkdir(parents=True)
    sys.path[:0] = [str(args.repo / "scripts"), str(args.repo / "tests")]
    import rea_operation_qualification as q
    import rea_frame_mcp_qualification as frame
    import rea_ghidra_v4_api as api
    import rea_ghidra_analysis_external as engine
    report = {"schema": "hepta.rea.ghidra-mcp-wire-capture.v1", "mode": args.mode,
              "qualified": False, "complete_upstream_parity_qualified": False, "sessions": [], "checks": [],
              "driver": {"path": str(Path(__file__).resolve()), "sha256": sha(__file__)},
              "argv": sys.argv, "started_ns": time.monotonic_ns(), "completed": False,
              "expected_comparison_count": 23 if args.mode == "native-readback" else 7}
    report["source_commit"] = subprocess.check_output(["git", "-C", str(args.repo), "rev-parse", "HEAD"], text=True).strip()
    report["imported_python_files"] = [{"path": str(Path(m.__file__)), "sha256": sha(m.__file__)}
        for m in list(sys.modules.values()) if getattr(m, "__file__", None)
        and str(Path(m.__file__)).startswith(str(args.repo) + "/") and str(m.__file__).endswith(".py")]
    write(root / "capture.json", report)
    code = 0
    try:
        if args.mode == "native-readback":
            native_capture(args, root, report, frame)
        else:
            original_capture(args, root, report, frame, q, api, engine)
    except BaseException as error:
        report["completed"] = False
        report["failure"] = repr(error)
        report["traceback"] = traceback.format_exc()
        code = 1
    finally:
        if args.mode == "original" and "identity_profile" in report and "reference_before" in report and "reference_after" not in report:
            try:
                _, report["installation_after"] = api.verify_installation(report["identity_profile"], time.monotonic() + 120)
                report["reference_after"] = q.reference_package(args.package, args.tarball)
                report["source_after"] = {"fixture_sha256": sha(args.fixture),
                                          "node_sha256": sha(args.node),
                                          "release_archive_sha256": sha(args.release_archive)}
                if "support_before" in report:
                    report["support_after_equal"] = all(
                        sha(args.ghidra_home / path) == digest for path, digest in report["support_before"].items())
            except BaseException as secondary:
                report.setdefault("secondary_failures", []).append("postflight: " + repr(secondary))
                code = 1
        try:
            report["driver_after_sha256"] = sha(__file__)
            report["imported_python_files_after"] = [
                {**row, "sha256": sha(row["path"])} for row in report["imported_python_files"]]
            report["source_unchanged"] = (
                report["driver_after_sha256"] == report["driver"]["sha256"]
                and report["imported_python_files_after"] == report["imported_python_files"])
            if not report["source_unchanged"]:
                code = 1
                report["completed"] = False
                report.setdefault("secondary_failures", []).append("private driver or imported source changed")
        except BaseException as secondary:
            code = 1
            report["completed"] = False
            report.setdefault("secondary_failures", []).append("source postflight: " + repr(secondary))
        report["comparisons_complete"] = len(report["checks"]) == report["expected_comparison_count"]
        report["comparison_differences"] = sum(not row["equal"] for row in report["checks"])
        report["all_recorded_comparisons_equal"] = (
            report["comparisons_complete"] and all(row["equal"] for row in report["checks"]))
        report["finished_ns"] = time.monotonic_ns()
        write(root / "capture.json", report)
        print(json.dumps({"event": "capture_finished", "mode": args.mode, "completed": report["completed"],
                          "failure": report.get("failure"), "workspace": str(root),
                          "comparisons_complete": report["comparisons_complete"],
                          "comparison_differences": report["comparison_differences"],
                          "all_recorded_comparisons_equal": report["all_recorded_comparisons_equal"],
                          "cancellation_status": report.get("cancellation", {}).get("status")}), flush=True)
    return code

if __name__ == "__main__":
    sys.exit(main())
