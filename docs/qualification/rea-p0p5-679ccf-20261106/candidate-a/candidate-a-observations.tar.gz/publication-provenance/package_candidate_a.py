#!/usr/bin/env python3
"""Publish closed Candidate A evidence only. No candidate, engine, Cargo, network or git mutation."""
from __future__ import annotations
import argparse
import ast
import gzip
import hashlib
import io
import json
import os
from pathlib import Path, PurePosixPath
import re
import stat
import subprocess
import sys
import tarfile
import time

E=Path('/home/qian-qi/work/hepta-rea-p0p5-679ccf-20261105-evidence')
X=Path('/home/qian-qi/work/hepta-rea-json-eof-173861-20261105-evidence/ignored-inputs-r1')
C=Path('/home/qian-qi/work/hepta-rea-p0p5-679ccf-chrome-causal-mcp-20261105-r1')
PUB=Path('/home/qian-qi/work/hepta-rea-p0p5-679ccf-20261105-publication')
DEST=PUB/'docs/qualification/rea-p0p5-679ccf-20261106/candidate-a'
OUT=E/'a-publication-packaging-r1'
A_REPO=Path('/home/qian-qi/work/hepta-rea-p0p5-679ccf-20261105')
COMMIT='c25e4cef0610816bfd1263b69d3dd63e4114aa49'
TREE='c6db025f5902570bd63520751cf84c57505eb6f4'
BINARY_SHA='9cde66234030515651177e3d8ab113b2b6f674ee76196283c71874348a0b6c90'
BINDING_SHA='7cee8cc6f6f141fcee5a744ae831ae0b24987e4e428bd91eb936c6ae3257503f'
SCAN_SHA='f05ab833fe5cd2cb0b789f7dfefee6e4b8533b6b75ad468ed60de9192d3530e3'
GIT_SCAN_SHA='fa51b7ee88c713078df088c70e3078bf6338afdc866d685fc5ba56c3917162e5'
A_DIRS=["matrix-r1","native-replay-r1","oracle-reference-r1","error-order-audit-r1","import-binding-r1","evidence-import-r1","evidence-import-overflow-r1","javascript-bound-r1","js-original-rea-r1","javascript-preload-c759-baseline.json.fixtures","python-regression-r1","provider-gates-r1","owned-real-apk-r2","owned-real-apk-r3"]
A_FILES=["binding.json","hepta-runtime","run-summary.json","run_matrix.py","matrix-driver-r1.stdout.log","matrix-driver-r1.stderr.log","matrix-controller-receipts-r1.json","source-identity-before.json","implementation-commit.json","build-environment.json","supplemental-source-before.json","supplemental-source-after.json","supplemental-source-events.json","javascript-preload-c759-baseline.json","run_bound_javascript_r1.py","run_bound_javascript_r2.py","javascript-controller-receipts-r1.json","replay_bound_candidate.py","run_bound_import_comparisons.py","run_python_regression.py","python-publication-controller-receipts.json","provider-inventory-current-r1.json","provider-inventory-path-addendum-r1.json","PROVIDER_GATES_PLAN_R1.md","provider-gates-plan-r1.json","run_bound_provider_gates_r1.py","run_owned_real_apk_r1.py","run_owned_real_apk_r2.py","run_owned_real_apk_r3.py","run_bound_owned_apk_r2.py","run_bound_owned_apk_r3.py","provider-gates-composed-r3.json","provider-gates-r1-outer-receipt.json","owned-real-apk-r2-outer-receipt.json","owned-real-apk-r3-outer-receipt.json","p1-persistence-audit.json","pre-freeze-checks.json","pre-freeze-controller-receipts.json","focused-json.stdout.log","focused-json.stderr.log","focused-json-r2.stdout.log","focused-json-r2.stderr.log","ignored-1.stdout.log","ignored-1.stderr.log","ignored-2.stdout.log","ignored-2.stderr.log","ignored-3.stdout.log","ignored-3.stderr.log","ignored-4.stdout.log","ignored-4.stderr.log","github-ci-final-c25-r1.json","github-ci-queue-r1.json"]
PINS={"binding.json":{"bytes":5002,"sha256":"7cee8cc6f6f141fcee5a744ae831ae0b24987e4e428bd91eb936c6ae3257503f"},"matrix-r1/summary.json":{"bytes":55033,"sha256":"205fcb07f1e2c26958e5d3c33f6d04d20e6e46585f6e041fbf92f551793c4fc6"},"import-binding-r1/summary.json":{"bytes":29585,"sha256":"5f61e51f10300e0e12b73a5e4775f2ea6209aeeb5017c79a330d8d0bf43de6c0"},"run-summary.json":{"bytes":14025,"sha256":"b9892310934f97b4da70b39448d0474426760f4a6fee6d5c9c75aad6193c0edd"},"python-regression-r1/summary.json":{"bytes":19563,"sha256":"423a14e4179a178727e130f6a20715fc9347a9113ddb97b2cd9030f0fc5263ac"},"javascript-bound-r1/summary.json":{"bytes":11443,"sha256":"57947c2de3514b85e3ac6761c360fae7b5c5aa696fab8e0ad48f219ff641cdf7"},"run_matrix.py":{"bytes":8881,"sha256":"e6ac4ac55c272074436bc40f653a4cedf4518610f5d1c5f54e5762d8b3ce120c"},"implementation-commit.json":{"bytes":337,"sha256":"c0a4c6269a5e8d6af31c929aaeeff0942d70e18b0c277c3d58b48b618bda680b"},"source-identity-before.json":{"bytes":129,"sha256":"7d79d0f7eef924633035297047cf64415716fbe2c2d13f7c2974b551c79a3c5c"},"run_bound_javascript_r2.py":{"bytes":7757,"sha256":"bc36bee4713d52a7b30942f0574a6a6490f400c894ebe2ef0686cbc8a0903d94"},"run_python_regression.py":{"bytes":5353,"sha256":"91a4d6265b81c2e8b04cdab291b032750a1d8018ddb69c08132cd02669a6fecf"},"github-ci-final-c25-r1.json":{"bytes":2543,"sha256":"8c75e2e207a313f761a74b60e19537d06872c980550369bfad6fdb103f062f0e"},"github-ci-queue-r1.json":{"bytes":2383,"sha256":"be9334ff0cd8d7e8755ee1bc6700e8b596564ebf982ae07c3e00e552c7b87084"},"python-publication-controller-receipts.json":{"bytes":1921,"sha256":"b146641fd70e26c35775099b8979b00ee5262df2f4df7a46c6f655ae4b420498"},"pre-freeze-controller-receipts.json":{"bytes":1925,"sha256":"4ce4af6f114696711f40fe244f63eff0d2a5e7c3248eec970dd092c522c96d2f"},"provider-gates-composed-r3.json":{"bytes":35914,"sha256":"89af9c015156efe00115569eaac196b38fa6f0336db2020ae4ffe519fef597b7"},"owned-real-apk-r3/summary.json":{"bytes":8730,"sha256":"5e75a581853c910af08d4fa212097ae75cdfc42a64e227952a4367298522a2e6"}}
SUMMARIES={"binding.json":"build-binding.json","matrix-r1/summary.json":"matrix-summary.json","run-summary.json":"four-original-corpus-gates.json","native-replay-r1/comparison-summary.json":"json-evidence-116-comparison.json","error-order-audit-r1/audit.json":"error-text-order-audit.json","import-binding-r1/summary.json":"import-118-and-22-binding.json","evidence-import-r1/qualification.json":"import-118-qualification.json","evidence-import-overflow-r1/qualification.json":"import-22-qualification.json","javascript-bound-r1/summary.json":"javascript-dual-oracle-and-workers.json","js-original-rea-r1/observations/observation.json":"javascript-original-rea-observation.json","python-regression-r1/summary.json":"python-564-source-regressions.json","provider-gates-composed-r3.json":"provider-six-gates-composed.json","provider-gates-r1/summary.json":"provider-r1-original-red.json","owned-real-apk-r2/summary.json":"generated-apk-r2-original-red.json","owned-real-apk-r3/summary.json":"generated-apk-r3-bound-run.json","provider-gates-r1-outer-receipt.json":"provider-r1-original-outer.json","owned-real-apk-r2-outer-receipt.json":"generated-apk-r2-original-outer.json","owned-real-apk-r3-outer-receipt.json":"generated-apk-r3-original-outer.json","provider-inventory-current-r1.json":"provider-six-host-inventory.json","provider-inventory-path-addendum-r1.json":"provider-inventory-path-addendum.json","p1-persistence-audit.json":"p1-persistence-readonly-audit.json","github-ci-final-c25-r1.json":"github-ci-cancelled-observation.json","github-ci-queue-r1.json":"github-ci-historical-queue.json","provider-gates-r1/01-ghidra/workspace/qualification.json":"ghidra-qualification.json","provider-gates-r1/02-jadx/workspace/qualification.json":"jadx-qualification.json","provider-gates-r1/03-chrome/workspace/qualification.json":"chrome-qualification.json","provider-gates-r1/04-apk-three-way/qualification.json":"apk-three-way-qualification.json","provider-gates-r1/05-apk-mcp/workspace/qualification.json":"apk-mcp-qualification.json","owned-real-apk-r3/workspace/qualification.json":"generated-apk-qualification.json","provider-gates-r1/06-apk-generated/workspace/qualification.json":"generated-apk-r1-raw-red.json","owned-real-apk-r2/workspace/qualification.json":"generated-apk-r2-raw-red.json"}
README="# Candidate A：c25 固定组合审计归档\n\n**完整替代资格：0；生产资格：0；结论：NO_GO。** 本目录整理已结束的 Candidate A 观察，不运行或重新解释 A，也不包含 Candidate B 的运行结果。通过项均为下表列明的有限门。\n\n## 固定组合\n\n| 对象 | 绑定 |\n| --- | --- |\n| Source commit | c25e4cef0610816bfd1263b69d3dd63e4114aa49 |\n| Git tree | c6db025f5902570bd63520751cf84c57505eb6f4 |\n| Runtime | 50,656,984 B；SHA256 9cde66234030515651177e3d8ab113b2b6f674ee76196283c71874348a0b6c90 |\n| Build binding | 5,002 B；SHA256 7cee8cc6f6f141fcee5a744ae831ae0b24987e4e428bd91eb936c6ae3257503f |\n| 原版 | rea-agents 6.8.0；实际安装、2,398 个包文件、tarball、Node 与 Provider 安装身份见原始收据 |\n\n原始 binding 的构建与源码消费者结果、构建特性、工具链与完整 source snapshots 均保留。A 当时的 working tree 已被主线用于 B；本归档的源码内容只取固定 c25 Git blob，不复制当前工作目录来冒充 A。\n\n## 已完成结果与实际边界\n\n| 门 | A 的实际结果 | 必须保留的边界 |\n| --- | --- | --- |\n| Rust all-features | 2,229 passed，40 skipped | skips 不算通过；原始 nextest 日志保留 |\n| Rust no-default-features | 2,201 passed，28 skipped | 独立配置的原始日志与最终显式 binary build 均保留 |\n| 四个 ignored 原版语料门 | 各 1 项真实执行并 PASS | 四份输入按固定 SHA 核对；不是零测试的成功退出 |\n| 116 项 JSON / Evidence 回放 | parsed 115/116；state 116/116；full object 1/116；raw frame 0/116 | 修复 14、回归 0；原始 outer failed/exit 1 是有效语义差异证据，不能改成 PASS |\n| 原有 118 + 22 import 门 | 各有限比较集合通过 | 118 包含 113 response/object-order、3 tool-contract、2 canonical export；22 包含 19 response/object-order、3 canonical export。均不代表 raw-wire 相等 |\n| 独立错误文本 / 顺序审计 | 38 个 JSON error：parsed 38/38，text 0/38，order 0/38；4 个 plain SDK errors：text 4/4 | 此限制同时约束原有 118/22 门的表述，不能把有限门扩展为错误文本兼容 |\n| JS / TS | 7 个 Node + 原版双 oracle 案例全部一致；7 个原始 worker 回放全部通过 | 实际原版观察与投影来源、完整请求和原始 worker 双流均保留 |\n| Python CI 源码回归 | 20 条命令，564 项，全部 OK | 只证明固定 c25 的源码回归；这些命令没有执行候选 Runtime 或 Cargo |\n| Provider | 6 组有限门通过 | Ghidra 11、JADX 8、Chrome 14；APK 三方 20+4；MCP 6；现场生成 APK 14 个检查 / 14 个原始命令 |\n| GitHub CI | 两个 c25 jobs completed/cancelled | steps/logs 未提供；不推断原因、不算 PASS。本地固定组合矩阵独立保存 |\n\n现有 Evidence 可在新会话显式 import 完整导出 bundle；这不证明自动认证会话冷重启持久化。库存表示当时六台物理主机的有限路径观察，不能将缺失安装或未执行设备能力计为通过。\n\n## Provider RED 与组合规则\n\nR1 总 driver 的前五组通过后，第六组在准备阶段因实际 JDK 缺少 lib/libsunec.so 停止：0 checks / 0 commands。该 failed 收据保持原样。R2 绑定完整实际 JDK 树并明确记录缺失文件后，实际 AAPT2 version 以 exit 0 将严格预期的 50 字节版本行写入 stderr；旧 stdout-only 观察断言停止在 1 check / 2 commands，该 RED 也保留。\n\nR3 只修正已诊断的版本输出通道观察，仍绑定相同可执行文件、严格版本字节、完整独立双流、原 14 条命令与预算。实际执行得到 12 个零退出和 2 个普通拒绝。最终 composed receipt 引用 R1 前五组和 R3 的第六组，并分别引用 R1/R2 原始 RED 与原 outer terminal，未改写失败报告、未重跑前五组。\n\n正常 Chrome capture/cancel 是未注入运行；测试专用 constructor 的环境回执仅证明那份 instrumented exec 边界。8 个真实环境负控制及 10 个空/缺字段 executable receipt 拒绝控制保留。历史 /proc environ 的 NUL 现象和旧 RED 另置历史前缀，旧二进制不能当作 A 的通过证据。\n\n## 文件导航\n\n- [关键原文报告副本](summaries/)：保持原始字节，文件名扁平化仅为方便审阅。\n- [审阅摘要](review-summary.json)：从原始报告提取的有限计数、绑定与 NO_GO。\n- [逐文件索引](file-index.json)：原 path、归档 path、bytes、SHA256、原始身份、来源类别、Git blob 与明确 omissions。\n- [完整选定原始观察归档](candidate-a-observations.tar.gz)：A 原始输入、wire、生命周期日志、driver、三轮 Provider 原始报告，四个外部语料 producer provenance，及固定 c25 相关源码。\n- [归档核验](archive-verification.json)：实际解压流逐成员 bytes / SHA、集合完整性、gzip 完整读取及所有选定原文件前后不变的核对。\n- [核验程序](verify_archive.py)：只流式读取 tar.gz 和索引，不解压到目录，不执行任何候选。\n- [打包 original outer 回执](publication-outer-receipt.json)：打包过程结束后独立收取；它不是新的 A 功能测试。\n\n归档中的 observations/evidence/ 是本轮 A 的已结束证据；observations/ignored-inputs-r1/ 是四份固定外部输入及其 producer provenance；observations/historical-chrome-red/ 是明确标注的历史失败；source/c25/ 是历史 Git 对象；publication-provenance/ 是本次只读归档过程与原 job 的新读回。\n\n## 有意排除与可复核性\n\n重复 frozen Runtime 二进制和历史 Chrome 二进制仅保留身份，不带入压缩包。原编译 target、npm 安装树、引擎安装目录、工具链与缓存不归档，它们在原始输入/环境清单中按身份绑定。B 的源码修复、focused/matrix、准备、P5 新脚本及结果均在本目录范围之外。\n\n生成凭据 owned-real-apk-r3/workspace/keystore/test-only.p12 仅记录 bytes / SHA / 元数据并明确排除，原文件未删除。六个非本轮执行的历史测试源码存在 credential-like literal，内容也排除、保留 Git blob 和 SHA；不发布其字面值。c25 树中的旧 tests/evidence 与 tools/x230/*/evidence 不是本轮 A 观察，不带入。\n\n所有软链只记录 lstat / link-target identity，不跟随也不写入 tar 成员；特殊文件同样不归档。included / omitted 在索引中逐项明示，未声称打包完整安装环境或整个仓库。原始观察没有脱敏改写；需要排除的整份内容以可核对的 omission 保存。\n\n打包以单次压缩流写入，不复制大中间目录；随后从 gzip/tar 实际读取每个成员并对照索引，重新读取原文件确认 bytes / SHA 与身份未变。上述核对证明归档保真，不增加 REA 全替代、生产、全部 Android 签名策略、GDB/LLDB、ADB/Frida、IDA/Hopper 或完整成本比较资格。\n"
PROVENANCE_FILES=('scan_sources_r1.py','source-scan-r1.json','scan_git_scope_r1.py',
                  'git-source-scope-r1.json','original-outer-readback-r1.json',
                  'package_candidate_a.py','verify_archive.py')
GIT_SECRET_OMIT=["tests/chatgpt_bridge_acceptance.py","tests/chatgpt_bridge_installed_acceptance.py","tests/dc_compat_independence_tests.py","tests/dc_compat_x11_keyboard_tests.py","tests/dc_functional_v8_signal_fixture_safety_tests.py","tests/dc_functional_v9_signal_fixture_safety_tests.py"]
STAT_KEYS=('st_dev','st_ino','st_size','st_mode','st_uid','st_gid','st_nlink','st_mtime_ns','st_ctime_ns')
KEY_PATTERNS=(
 re.compile(rb'-----BEGIN (?:[A-Z0-9 ]+ )?PRIVATE KEY-----'),
 re.compile(rb'(?i)(?:authorization["\x27]?\s*[:=]\s*["\x27]?\s*bearer\s+[A-Za-z0-9._~-]{12,})'),
 re.compile(rb'(?i)["\x27](?:auth_token|access_token|refresh_token|client_secret|api_key|private_key|password|token)["\x27]\s*:\s*["\x27]([A-Za-z0-9_./+=:~-]{12,})["\x27]'))
MIN_FREE=1024**3

def require(v,msg):
 if not v: raise AssertionError(msg)

def meta(st):
 return {k[3:]:getattr(st,k) for k in STAT_KEYS}

def sha(raw):
 return hashlib.sha256(raw).hexdigest()

def encode(value):
 return (json.dumps(value,ensure_ascii=False,sort_keys=True,indent=2)+'\n').encode()

def create(path,raw):
 path.parent.mkdir(parents=True,exist_ok=True)
 fd=os.open(path,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW|os.O_CLOEXEC,0o644)
 with os.fdopen(fd,'wb') as h:
  h.write(raw);h.flush();os.fsync(h.fileno())

def read_regular(path,limit=None):
 fd=os.open(path,os.O_RDONLY|os.O_CLOEXEC|os.O_NOFOLLOW|os.O_NONBLOCK)
 with os.fdopen(fd,'rb') as f:
  before=os.fstat(f.fileno())
  require(stat.S_ISREG(before.st_mode),'not a regular source: '+str(path))
  require(limit is None or before.st_size<=limit,'bounded source too large')
  raw=f.read()
  require(meta(before)==meta(os.fstat(f.fileno())) and len(raw)==before.st_size,'source changed in read')
 return raw

def identity(path,scan=False):
 fd=os.open(path,os.O_RDONLY|os.O_CLOEXEC|os.O_NOFOLLOW|os.O_NONBLOCK)
 digest=hashlib.sha256();count=0;tail=b''
 with os.fdopen(fd,'rb') as f:
  before=os.fstat(f.fileno())
  require(stat.S_ISREG(before.st_mode),'nonregular hash source')
  for block in iter(lambda:f.read(1048576),b''):
   count+=len(block);digest.update(block)
   if scan:
    portion=tail+block
    require(not any(p.search(portion) for p in KEY_PATTERNS),'credential-like raw content requires omission review: '+str(path))
    tail=portion[-2048:]
  after=os.fstat(f.fileno())
 require(meta(before)==meta(after) and count==before.st_size,'source changed during identity')
 if scan and str(path).endswith('.gz'):
  tail=b'';expanded=0
  with gzip.open(path,'rb') as z:
   for block in iter(lambda:z.read(1048576),b''):
    expanded+=len(block)
    require(expanded<=256*1024**2,'expanded input exceeds reviewed bound')
    require(not any(p.search(tail+block) for p in KEY_PATTERNS),'credential-like compressed observation requires omission review: '+str(path))
    tail=(tail+block)[-2048:]
  require(meta(path.lstat())==meta(before),'source changed during gzip scan')
 return {'bytes':count,'sha256':digest.hexdigest(),'metadata':meta(before)}

def inspect(path,label,root):
 st=path.lstat();rel=path.relative_to(root).as_posix()
 row={'source_kind':'original_file','source_label':label,'original_path':str(path),
      'source_relative_path':rel,'archive_path':None,'disposition':'omitted',
      'omission_reason':None,'bytes':st.st_size,'sha256':None,'metadata_before':meta(st)}
 if stat.S_ISLNK(st.st_mode):
  target=os.readlink(path);raw=os.fsencode(target)
  row.update(kind='symlink',link_target=target,link_target_bytes=len(raw),sha256=sha(raw),
             sha256_scope='link target bytes only',omission_reason='Symlink identity only; target not followed or archived')
  require(meta(st)==meta(path.lstat()),'symlink changed')
  return row
 if not stat.S_ISREG(st.st_mode):
  row.update(kind='special',omission_reason='Nonregular filesystem object; identity only')
  return row
 row['kind']='regular'
 if path.name in ('hepta-runtime','hepta-runtime-qualified'):
  row['omission_reason']='Frozen runtime executable identity only; avoid duplicate/historical binaries in publication'
 elif path.suffix.lower() in ('.p12','.pfx','.jks','.pk8','.key'):
  row['omission_reason']='Generated credential/private-key container; content excluded from publication; original retained'
 elif '__pycache__' in path.parts or path.suffix=='.pyc' or path.name.startswith('.hepta-lock-'):
  row['omission_reason']='Interpreter cache or filesystem coordination artifact, not original observation'
 else:
  row['disposition']='included'
  prefix='publication-provenance' if label=='publication-provenance' else 'observations/'+label
  row['archive_path']=prefix+'/'+rel
 ident=identity(path,scan=row['disposition']=='included')
 require(ident['metadata']==row['metadata_before'],'source changed from lstat')
 row.update(bytes=ident['bytes'],sha256=ident['sha256'])
 if label=='evidence' and path.name in ('hepta-runtime','hepta-runtime-qualified'):
  require(row['sha256']==BINARY_SHA and row['bytes']==50656984,'A runtime identity mismatch')
 return row

def walk(root):
 stack=[root]
 while stack:
  current=stack.pop()
  with os.scandir(current) as entries:
   children=sorted(entries,key=lambda e:os.fsencode(e.name))
  for entry in children:
   p=Path(entry.path)
   if entry.is_dir(follow_symlinks=False):stack.append(p)
   else:yield p

def git(*args):
 return subprocess.check_output(['git','-C',str(PUB),*args])

def json_at(relative):
 return json.loads(read_regular(E/relative,2*1024**2))

def validate_results():
 binding=json_at('binding.json')
 require(sha(read_regular(E/'binding.json'))==BINDING_SHA,'binding SHA')
 require(binding['source_commit']==COMMIT and binding['source_git_tree']==TREE,'binding source')
 require(binding['runtime']=={'path':str(E/'hepta-runtime'),'bytes':50656984,'sha256':BINARY_SHA},'runtime binding')
 matrix=json_at('matrix-r1/summary.json')
 require(matrix['qualified'] is True and matrix['status']=='passed' and len(matrix['stages'])==9,'matrix incomplete')
 require(all(s['exit_code']==0 and s['status']=='passed' for s in matrix['stages']),'matrix stages')
 lines={s['name']:s['summary']['nextest_summary_lines'] for s in matrix['stages']}
 require(any('2229 tests run: 2229 passed' in s and '40 skipped' in s for s in lines['nextest-all-features']),'all-feature counts')
 require(any('2201 tests run: 2201 passed' in s and '28 skipped' in s for s in lines['nextest-no-default-features']),'no-default counts')
 gates=json_at('run-summary.json')
 require(gates['all_four_passed'] and len(gates['supplemental_gates'])==4,'four gates incomplete')
 require(all(g['passed'] and g['exact_test_executed'] and g['returncode']==0 and g['input_unchanged'] for g in gates['supplemental_gates']),'real gate execution missing')
 replay=json_at('native-replay-r1/comparison-summary.json')
 require(replay['source_commit']==COMMIT and replay['evidence_valid'] and replay['collection_complete'] and not replay['qualified'],'116 evidence scope')
 audit=json_at('error-order-audit-r1/audit.json')
 require(audit['source_candidate']==COMMIT and audit['binary_sha256']==BINARY_SHA,'audit binding')
 require(audit['json_replay_counts']=={'denominator':116,'evidence_after_equal':116,'full_response_object_equal':1,'parsed_content_and_evidence_equal':115,'parsed_content_equal':115,'raw_frame_bytes_equal':0},'116 actual counts')
 require(len(audit['repaired_json_cases'])==14 and len(audit['regressed_json_cases'])==0,'repair/regression counts')
 ec=audit['import_error_counts']
 require(ec['json_error_responses']==38 and ec['parsed_equal']==38 and ec['exact_text']==0 and ec['exact_order']==0 and ec['plain_sdk_errors']==4 and ec['plain_sdk_text_equal']==4,'error text/order counts')
 imports=json_at('import-binding-r1/summary.json')
 require(imports['source_commit']==COMMIT and imports['passed'] and not imports['qualified'],'import binding')
 require([(s['comparisons'],s['passed_comparisons'],s['returncode']) for s in imports['stages']]==[(118,118,0),(22,22,0)],'import counts')
 js=json_at('javascript-bound-r1/summary.json')
 require(js['source_commit']==COMMIT and js['passed'] and len(js['raw_worker_cases'])==7 and all(c['passed'] for c in js['raw_worker_cases']),'JS workers')
 require(js['oracle_summary']=={'denominator':7,'node_matches':7,'oracles_agree':7,'original_rea_matches':7,'runtime_contract_passes':7},'JS dual oracle')
 py=json_at('python-regression-r1/summary.json')
 require(py['source_commit']==COMMIT and py['source_tree']==TREE and py['total_top_level_tests']==564 and len(py['stages'])==20 and py['all_plain_ok'] and py['complete'] and not py['runtime_executed'],'Python scope/counts')
 provider=json_at('provider-gates-composed-r3.json')
 require(provider['source_commit']==COMMIT and provider['source_git_tree']==TREE and provider['passed_finite_stage_count']==6 and len(provider['stages'])==6 and all(s['qualified'] for s in provider['stages']),'provider finite composition')
 require(provider['original_engine_job_count']==16 and provider['generated_apk_original_child_count']==14,'provider original children')
 require(not provider['rea_full_parity'] and not provider['production_qualified'] and not provider['full_cost_comparison'],'scope enlarged')
 require(json_at('provider-gates-r1/summary.json')['status']=='failed' and json_at('owned-real-apk-r2/summary.json')['status']=='failed','original RED reclassified')
 ci=json_at('github-ci-final-c25-r1.json')
 require(ci['source_commit']==COMMIT and len(ci['actual_jobs'])==2 and all(x['status']=='completed' and x['conclusion']=='cancelled' for x in ci['actual_jobs']) and not ci['github_execution_passed'],'CI cancellation changed')
 return {'schema':'hepta.rea.candidate-a.review.v1','source_commit':COMMIT,'source_git_tree':TREE,
         'binding_sha256':BINDING_SHA,'runtime':binding['runtime'],
         'global_status':'NO_GO','complete_replacement_qualified':False,'production_qualified':False,
         'rust':{'all_features':{'passed':2229,'skipped':40},'no_default_features':{'passed':2201,'skipped':28}},
         'four_ignored_real_gates':[{'test':g['test'],'passed':g['passed'],'exact_test_executed':g['exact_test_executed'],'input':g['input']} for g in gates['supplemental_gates']],
         'json_116':audit['json_replay_counts'],'repaired_json_cases':len(audit['repaired_json_cases']),
         'regressed_json_cases':len(audit['regressed_json_cases']),'import_error_audit':ec,
         'old_import_finite_gates':[{'comparisons':s['comparisons'],'passed':s['passed_comparisons']} for s in imports['stages']],
         'javascript':dict(js['oracle_summary'],raw_worker_passed=7),
         'python':{'commands':20,'tests':564,'candidate_runtime_executed':False},
         'provider':{'finite_groups_passed':6,'original_engine_jobs':16,'generated_apk_commands':14,
                     'retained_r1_red':True,'retained_r2_red':True,'repeated_first_five':False},
         'github_ci':{'observed_at':ci['observed_at'],'jobs':ci['actual_jobs'],'passed':False},
         'historical_sources_not_current_passes':['oracle/reference and c759 comparison baseline','historical Chrome RED'],
         'candidate_b_results_included':False,'candidate_executed_during_publication':False}

class HashedReader:
 def __init__(self,handle):self.handle=handle;self.digest=hashlib.sha256();self.count=0
 def read(self,size=-1):
  raw=self.handle.read(size);self.digest.update(raw);self.count+=len(raw);return raw

def tarinfo(name,size):
 require(not name.startswith('/') and '..' not in PurePosixPath(name).parts,'bad archive path')
 info=tarfile.TarInfo(name);info.size=size;info.mode=0o644;info.uid=0;info.gid=0;info.uname='';info.gname='';info.mtime=0
 return info

def main():
 parser=argparse.ArgumentParser();parser.add_argument('--execute',action='store_true');args=parser.parse_args()
 require(args.execute,'explicit packaging execution required')
 os.umask(0o077);os.nice(10)
 require(not DEST.exists(),'new publication destination must not exist')
 require(os.statvfs(PUB).f_bavail*os.statvfs(PUB).f_frsize>MIN_FREE,'disk reserve')
 require(git('rev-parse',COMMIT+'^{tree}').decode().strip()==TREE,'historical commit/tree unavailable')
 scan_raw=read_regular(OUT/'source-scan-r1.json',8*1024**2)
 git_scan_raw=read_regular(OUT/'git-source-scope-r1.json',2*1024**2)
 require(sha(scan_raw)==SCAN_SHA and sha(git_scan_raw)==GIT_SCAN_SHA,'preparation scan changed')
 scanned=json.loads(scan_raw);gits=json.loads(git_scan_raw)
 require(scanned['potential_secret_markers_only_no_values']==[],'unresolved source content marker')
 require({x['path'] for x in gits['potential_secret_markers_only_no_values']}==set(GIT_SECRET_OMIT),'Git omission set differs')
 facts=validate_results()
 for rel,want in PINS.items():
  got=identity(E/rel)
  require({k:got[k] for k in ('bytes','sha256')}==want,'pinned report changed: '+rel)
 rows=[]
 for name in A_DIRS:
  root=E/name;require(root.is_dir() and not root.is_symlink(),'A subtree absent or symlink: '+name)
  rows.extend(inspect(p,'evidence',E) for p in walk(root))
 for name in A_FILES:rows.append(inspect(E/name,'evidence',E))
 for label,root in [('ignored-inputs-r1',X),('historical-chrome-red',C)]:
  require(root.is_dir() and not root.is_symlink(),'selected external scope absent')
  rows.extend(inspect(p,label,root) for p in walk(root))
 for name in PROVENANCE_FILES:rows.append(inspect(OUT/name,'publication-provenance',OUT))
 original_keys={(r['source_label'],r['source_relative_path']) for r in rows if r['source_label']!='publication-provenance'}
 scanned_keys={(r['source_label'],r['relative']) for r in scanned['selected_source_files']}
 extra_expected={('evidence','github-ci-final-c25-r1.json'),('evidence','github-ci-queue-r1.json')}
 symlinks={(r['source_label'],r['source_relative_path']) for r in rows if r['kind']!='regular'}
 require(original_keys==scanned_keys|extra_expected|symlinks,'A source member set changed after preparation')
 by_path={r['original_path']:r for r in rows}
 require(len(by_path)==len(rows),'duplicate selected source path')
 for gate in facts['four_ignored_real_gates']:
  item=by_path[gate['input']['path']]
  require(item['bytes']==gate['input']['bytes'] and item['sha256']==gate['input']['sha256'] and item['disposition']=='included','fixed original corpus mismatch')
 snapshot=json.loads(read_regular(E/'matrix-r1/source-before.json',2*1024**2))
 used={x['path']:x for x in snapshot['files']}
 git_rows=[]
 for row in gits['files']:
  path=row['path'];reason=None
  if path in GIT_SECRET_OMIT:reason='Credential-like literal in unrelated historical test source; only immutable identity published'
  elif path.startswith('tests/evidence/') or (path.startswith('tools/') and '/evidence/' in path):
   reason='Historical committed evidence archive outside this Candidate A run; identity only'
  elif row['mode']=='120000':reason='Historical Git symlink identity only; target not followed or archived'
  item={'source_kind':'historical_git_blob','source_label':'source/c25','original_path':str(A_REPO/path),
        'source_relative_path':path,'original_revision':COMMIT,'git_blob':row['git_blob'],'git_mode':row['mode'],
        'current_worktree_read':False,'bytes':row['bytes'],'sha256':row['sha256'],
        'disposition':'omitted' if reason else 'included','omission_reason':reason,
        'archive_path':None if reason else 'source/c25/'+path,
        'matrix_snapshot_bound':path in used}
  if path in used:
   require(used[path]['bytes']==row['bytes'] and used[path]['sha256']==row['sha256'],'historical blob differs from A execution snapshot: '+path)
  git_rows.append(item)
 rows.extend(git_rows)
 require(sum(1 for r in rows if r['source_kind']=='original_file' and r['omission_reason'] and 'credential/private' in r['omission_reason'])==1,'unexpected generated credential inventory')
 require(by_path[str(E/'owned-real-apk-r3/workspace/keystore/test-only.p12')]['disposition']=='omitted','credential included')
 root_exclusions=sorted(p.name for p in E.iterdir() if p.name not in set(A_DIRS)|set(A_FILES))
 index={'schema':'hepta.rea.candidate-a.publication.file-index.v1','source_commit':COMMIT,'source_git_tree':TREE,
        'binding_sha256':BINDING_SHA,'binary_sha256':BINARY_SHA,'entries':sorted(rows,key=lambda r:(r['source_label'],r['source_relative_path'])),
        'excluded_evidence_root_entries':root_exclusions,
        'scope_exclusions':[
         {'path':str(A_REPO),'reason':'Current working tree is B; A source comes only from immutable c25 Git objects'},
         {'path':str(A_REPO)+'-target','reason':'Compilation target directory not traversed or archived'},
         {'path':'Installed npm package / SDK / engines / toolchains / caches','reason':'Identity references are preserved in original receipts; installation contents not traversed or archived'},
         {'path':'Other committed repository paths outside declared Git prefixes','reason':'Not a full repository export; immutable source tree id retained'}],
        'regular_sources_unchanged_before_after':False,'candidate_executed':False,'qualification_reclassified':False}
 DEST.mkdir(parents=True,mode=0o755)
 archive_partial=DEST/'candidate-a-observations.tar.gz.part'
 archived_count=0;archived_bytes=0
 fd=os.open(archive_partial,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_CLOEXEC,0o644)
 with os.fdopen(fd,'wb') as output:
  with gzip.GzipFile(filename='',mode='wb',fileobj=output,compresslevel=6,mtime=0) as compressed:
   with tarfile.open(fileobj=compressed,mode='w|',format=tarfile.PAX_FORMAT) as tar:
    for row in index['entries']:
     if row['disposition']!='included' or row['source_kind']!='original_file':continue
     source=Path(row['original_path'])
     raw_fd=os.open(source,os.O_RDONLY|os.O_NOFOLLOW|os.O_CLOEXEC|os.O_NONBLOCK)
     with os.fdopen(raw_fd,'rb') as raw:
      require(meta(os.fstat(raw.fileno()))==row['metadata_before'],'source changed before archive read')
      reader=HashedReader(raw)
      tar.addfile(tarinfo(row['archive_path'],row['bytes']),reader)
      require(reader.count==row['bytes'] and reader.digest.hexdigest()==row['sha256'],'archive input differs')
      require(meta(os.fstat(raw.fileno()))==row['metadata_before'],'source changed during archive read')
     archived_count+=1;archived_bytes+=row['bytes']
     if archived_count%200==0:
      require(os.statvfs(DEST).f_bavail*os.statvfs(DEST).f_frsize>MIN_FREE,'disk reserve during archive')
    proc=subprocess.Popen(['git','-C',str(PUB),'cat-file','--batch'],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
    try:
     for row in index['entries']:
      if row['source_kind']!='historical_git_blob' or row['disposition']!='included':continue
      proc.stdin.write((row['git_blob']+'\n').encode());proc.stdin.flush()
      header=proc.stdout.readline().decode().strip().split()
      require(header==[row['git_blob'],'blob',str(row['bytes'])],'unexpected immutable git object')
      raw=proc.stdout.read(row['bytes']);ending=proc.stdout.read(1)
      require(len(raw)==row['bytes'] and ending==b'\n' and sha(raw)==row['sha256'],'historical Git bytes changed')
      require(hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()==row['git_blob'],'Git object identity')
      require(not any(p.search(raw) for p in KEY_PATTERNS),'unreviewed credential-like source content')
      tar.addfile(tarinfo(row['archive_path'],len(raw)),io.BytesIO(raw))
      archived_count+=1;archived_bytes+=len(raw)
    finally:
     proc.stdin.close();stderr=proc.stderr.read();code=proc.wait()
     require(code==0 and not stderr,'Git blob stream failed')
  output.flush();os.fsync(output.fileno())
 require(archive_partial.stat().st_size<768*1024**2,'unexpected archive growth')
 for row in index['entries']:
  if row['source_kind']!='original_file':continue
  path=Path(row['original_path']);st=path.lstat()
  require(meta(st)==row['metadata_before'],'original source metadata changed: '+str(path))
  if row['kind']=='regular':
   after=identity(path)
   require(after['bytes']==row['bytes'] and after['sha256']==row['sha256'] and after['metadata']==row['metadata_before'],'original source bytes changed')
  elif row['kind']=='symlink':
   require(os.readlink(path)==row['link_target'],'original symlink target changed')
  row['metadata_after']=meta(st);row['source_unchanged']=True
 require(git('rev-parse',COMMIT+'^{tree}').decode().strip()==TREE,'historical source tree changed')
 index['regular_sources_unchanged_before_after']=True
 index['included_count']=sum(r['disposition']=='included' for r in rows)
 index['omitted_count']=sum(r['disposition']=='omitted' for r in rows)
 index['included_bytes']=sum(r['bytes'] for r in rows if r['disposition']=='included')
 index['omitted_bytes']=sum(r['bytes'] for r in rows if r['disposition']=='omitted')
 require(index['included_count']==archived_count and index['included_bytes']==archived_bytes,'archive accounting')
 from verify_archive import verify
 verification=verify(archive_partial,index)
 archive=DEST/'candidate-a-observations.tar.gz'
 require(not archive.exists(),'archive already exists');os.rename(archive_partial,archive)
 archive_identity=identity(archive)
 for rel,name in SUMMARIES.items():
  row=by_path[str(E/rel)]
  require(row['disposition']=='included','review summary omitted')
  raw=read_regular(E/rel,2*1024**2)
  require(len(raw)==row['bytes'] and sha(raw)==row['sha256'],'summary changed during exact copy')
  create(DEST/'summaries'/name,raw);row['review_copy']='summaries/'+name
 historical=by_path[str(C/'qualification.json')]
 raw=read_regular(C/'qualification.json',2*1024**2)
 require(sha(raw)==historical['sha256'],'historical RED changed')
 create(DEST/'summaries/historical-chrome-original-red.json',raw)
 historical['review_copy']='summaries/historical-chrome-original-red.json'
 facts['report_references']={name:{'source':str(E/rel),'bytes':by_path[str(E/rel)]['bytes'],'sha256':by_path[str(E/rel)]['sha256']} for rel,name in SUMMARIES.items()}
 create(DEST/'README.md',README.encode())
 create(DEST/'review-summary.json',encode(facts))
 create(DEST/'file-index.json',encode(index))
 create(DEST/'verify_archive.py',read_regular(OUT/'verify_archive.py'))
 verification.update(schema='hepta.rea.candidate-a.archive-verification.v1',
   archive={'path':archive.name,'bytes':archive_identity['bytes'],'sha256':archive_identity['sha256']},
   file_index={k:v for k,v in identity(DEST/'file-index.json').items() if k!='metadata'},
   source_regular_files_rehashed_after=sum(r['source_kind']=='original_file' and r['kind']=='regular' for r in rows),
   source_symlinks_not_followed=sum(r['source_kind']=='original_file' and r['kind']=='symlink' for r in rows),
   source_original_identities_unchanged=True,historical_git_tree= TREE,
   historical_git_blob_bytes_verified=True,omitted_entries=index['omitted_count'],
   source_commit=COMMIT,binary_sha256=BINARY_SHA,binding_sha256=BINDING_SHA,
   source_checkout_written=False,candidate_executed=False,git_or_index_mutated=False,
   complete_replacement_qualified=False,production_qualified=False,global_status='NO_GO',
   outer_terminal_receipt_required=True)
 create(DEST/'archive-verification.json',encode(verification))
 summary={'schema':'hepta.rea.candidate-a.packaging-result.v1','destination':str(DEST),'source_commit':COMMIT,
          'archive':verification['archive'],'index':verification['file_index'],
          'member_count':archived_count,'uncompressed_bytes':archived_bytes,
          'omitted_count':index['omitted_count'],'omitted_bytes':index['omitted_bytes'],
          'original_sources_unchanged':True,'original_regular_count':verification['source_regular_files_rehashed_after'],
          'publication_verification':{k:v for k,v in identity(DEST/'archive-verification.json').items() if k!='metadata'},
          'readme':{k:v for k,v in identity(DEST/'README.md').items() if k!='metadata'},
          'candidate_executed':False,'source_checkout_written':False,'git_or_index_mutated':False,
          'global_status':'NO_GO','outer_terminal_collected':False}
 create(OUT/'package-result-r1.json',encode(summary))
 print(json.dumps(summary,sort_keys=True),flush=True)

if __name__=='__main__':
 try:main()
 except BaseException as error:
  failure={'schema':'hepta.rea.candidate-a.packaging-failure.v1','type':type(error).__name__,'error':str(error),
           'candidate_executed':False,'source_checkout_written':False,'global_status':'NO_GO','no_automatic_retry':True}
  failure_path=OUT/'package-failure-r1.json'
  if not failure_path.exists():create(failure_path,encode(failure))
  raise
