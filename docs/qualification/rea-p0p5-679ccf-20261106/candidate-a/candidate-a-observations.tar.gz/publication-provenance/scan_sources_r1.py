#!/usr/bin/env python3
"""Read-only inventory for an A-only evidence publication; no candidate runs."""
import gzip,hashlib,json,os,re,stat,subprocess
from pathlib import Path
E=Path('/home/qian-qi/work/hepta-rea-p0p5-679ccf-20261105-evidence')
X=Path('/home/qian-qi/work/hepta-rea-json-eof-173861-20261105-evidence/ignored-inputs-r1')
C=Path('/home/qian-qi/work/hepta-rea-p0p5-679ccf-chrome-causal-mcp-20261105-r1')
PUB=Path('/home/qian-qi/work/hepta-rea-p0p5-679ccf-20261105-publication')
OUT=E/'a-publication-packaging-r1'
DIRS=set(["matrix-r1","native-replay-r1","oracle-reference-r1","error-order-audit-r1","import-binding-r1","evidence-import-r1","evidence-import-overflow-r1","javascript-bound-r1","js-original-rea-r1","javascript-preload-c759-baseline.json.fixtures","python-regression-r1","provider-gates-r1","owned-real-apk-r2","owned-real-apk-r3"])
FILES=set(["binding.json","hepta-runtime","run-summary.json","run_matrix.py","matrix-driver-r1.stdout.log","matrix-driver-r1.stderr.log","matrix-controller-receipts-r1.json","source-identity-before.json","implementation-commit.json","build-environment.json","supplemental-source-before.json","supplemental-source-after.json","supplemental-source-events.json","javascript-preload-c759-baseline.json","run_bound_javascript_r1.py","run_bound_javascript_r2.py","javascript-controller-receipts-r1.json","replay_bound_candidate.py","run_bound_import_comparisons.py","run_python_regression.py","python-publication-controller-receipts.json","provider-inventory-current-r1.json","provider-inventory-path-addendum-r1.json","PROVIDER_GATES_PLAN_R1.md","provider-gates-plan-r1.json","run_bound_provider_gates_r1.py","run_owned_real_apk_r1.py","run_owned_real_apk_r2.py","run_owned_real_apk_r3.py","run_bound_owned_apk_r2.py","run_bound_owned_apk_r3.py","provider-gates-composed-r3.json","provider-gates-r1-outer-receipt.json","owned-real-apk-r2-outer-receipt.json","owned-real-apk-r3-outer-receipt.json","p1-persistence-audit.json","pre-freeze-checks.json","pre-freeze-controller-receipts.json","focused-json.stdout.log","focused-json.stderr.log","focused-json-r2.stdout.log","focused-json-r2.stderr.log","ignored-1.stdout.log","ignored-1.stderr.log","ignored-2.stdout.log","ignored-2.stderr.log","ignored-3.stdout.log","ignored-3.stderr.log","ignored-4.stdout.log","ignored-4.stderr.log"])
def rg(root):
 p=subprocess.run(['rg','--files','--hidden','--no-ignore','-0',str(root)],stdout=subprocess.PIPE,stderr=subprocess.PIPE,check=True)
 return sorted(Path(os.fsdecode(b)) for b in p.stdout.split(b'\0') if b)
def digest(path):
 h=hashlib.sha256()
 with path.open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return h.hexdigest()
patterns={
 'private_key_header':re.compile(rb'-----BEGIN (?:[A-Z0-9 ]+ )?PRIVATE KEY-----'),
 'authorization_bearer_literal':re.compile(rb'(?i)(?:authorization["\x27]?\s*[:=]\s*["\x27]?\s*bearer\s+[A-Za-z0-9._~-]{12,})'),
 'credential_value':re.compile(rb'(?i)["\x27](?:auth_token|access_token|refresh_token|client_secret|api_key|private_key|password|token)["\x27]\s*:\s*["\x27]([A-Za-z0-9_./+=:~-]{12,})["\x27]'),
 'credential_flag_literal':re.compile(rb'(?i)--(?:auth-token|access-token|password)(?:\s+|=)[A-Za-z0-9_./+=:~-]{12,}')}
rows=[];potential=[]
for label,root in [('evidence',E),('ignored-inputs-r1',X),('historical-chrome-red',C)]:
 if not root.exists():continue
 for path in rg(root):
  rel=str(path.relative_to(root))
  if label=='evidence' and not (rel.split('/')[0] in DIRS or rel in FILES):continue
  s=path.lstat()
  row={'source_label':label,'relative':rel,'bytes':s.st_size,'kind':'regular' if stat.S_ISREG(s.st_mode) else 'symlink' if stat.S_ISLNK(s.st_mode) else 'other'}
  rows.append(row)
  if not stat.S_ISREG(s.st_mode) or path.name in ('hepta-runtime','hepta-runtime-qualified') or path.suffix.lower() in ('.p12','.pfx','.jks','.key','.pk8'):continue
  hits=set();seen=0;tail=b''
  opener=gzip.open if str(path).endswith('.gz') else open
  try:
   with opener(path,'rb') as f:
    for b in iter(lambda:f.read(1048576),b''):
     seen+=len(b)
     if seen>256*1024*1024:raise ValueError('scan expanded bound exceeded')
     scan=tail+b
     for k,p in patterns.items():
      if p.search(scan):hits.add(k)
     tail=scan[-2048:]
  except (gzip.BadGzipFile,EOFError,OSError) as error:
   potential.append({'source_label':label,'relative':rel,'scan_error':type(error).__name__})
  if hits:potential.append({'source_label':label,'relative':rel,'matches':sorted(hits)})
tree=subprocess.check_output(['git','-C',str(PUB),'rev-parse','c25e4cef0610816bfd1263b69d3dd63e4114aa49^{tree}'],text=True).strip()
assert tree=='c6db025f5902570bd63520751cf84c57505eb6f4'
raw=subprocess.check_output(['git','-C',str(PUB),'ls-tree','-r','-l','-z','c25e4cef0610816bfd1263b69d3dd63e4114aa49'])
git_entries=[]
for line in raw.split(b'\0'):
 if not line:continue
 info,name=line.split(b'\t',1);mode,kind,oid,size=info.split()
 git_entries.append({'path':os.fsdecode(name),'mode':mode.decode(),'type':kind.decode(),'git_blob':oid.decode(),'bytes':None if size==b'-' else int(size)})
groups={}
for row in git_entries:
 k=row['path'].split('/')[0];v=groups.setdefault(k,{'files':0,'bytes':0});v['files']+=1;v['bytes']+=row['bytes'] or 0
report={'schema':'hepta.rea.a.publication.scan.v1','source_commit':'c25e4cef0610816bfd1263b69d3dd63e4114aa49','source_git_tree':tree,'candidate_executed':False,'source_files_modified':False,'selected_source_files':rows,'potential_secret_markers_only_no_values':potential,'git_entries':git_entries}
raw=(json.dumps(report,sort_keys=True,indent=2)+'\n').encode()
fd=os.open(OUT/'source-scan-r1.json',os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
with os.fdopen(fd,'wb') as f:f.write(raw);f.flush();os.fsync(f.fileno())
print(json.dumps({'report':str(OUT/'source-scan-r1.json'),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'source_count':len(rows),'logical_source_bytes':sum(x['bytes'] for x in rows),'potential_secret_markers_only_no_values':potential,'git_groups':groups,'historical_chrome_files':[x for x in rows if x['source_label']=='historical-chrome-red']},sort_keys=True))
