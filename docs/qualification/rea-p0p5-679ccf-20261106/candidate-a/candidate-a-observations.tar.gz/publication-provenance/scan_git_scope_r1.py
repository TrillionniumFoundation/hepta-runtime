#!/usr/bin/env python3
import hashlib,json,os,re,subprocess
from pathlib import Path
E=Path('/home/qian-qi/work/hepta-rea-p0p5-679ccf-20261105-evidence')
OUT=E/'a-publication-packaging-r1'
PUB=Path('/home/qian-qi/work/hepta-rea-p0p5-679ccf-20261105-publication')
raw=(OUT/'source-scan-r1.json').read_bytes()
assert hashlib.sha256(raw).hexdigest()=='f05ab833fe5cd2cb0b789f7dfefee6e4b8533b6b75ad468ed60de9192d3530e3'
source=json.loads(raw)
PREFIXES=('src/','scripts/','tests/','vendor/','workers/','.github/workflows/','deploy/maintenance_20261017/','tools/x230/20261028/','tools/x230/20261029/','tools/x230/20261030/')
ROOTS={'Cargo.toml','Cargo.lock','rustfmt.toml','LICENSE','LICENSES/MIT.txt','LICENSES/Apache-2.0.txt'}
selected=[x for x in source['git_entries'] if x['path'] in ROOTS or x['path'].startswith(PREFIXES)]
p=subprocess.Popen(['git','-C',str(PUB),'cat-file','--batch'],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
potential=[];rows=[]
patterns={'private_key_header':re.compile(rb'-----BEGIN (?:[A-Z0-9 ]+ )?PRIVATE KEY-----'),
'authorization_bearer_literal':re.compile(rb'(?i)(?:authorization["\x27]?\s*[:=]\s*["\x27]?\s*bearer\s+[A-Za-z0-9._~-]{12,})'),
'credential_value':re.compile(rb'(?i)["\x27](?:auth_token|access_token|refresh_token|client_secret|api_key|private_key|password|token)["\x27]\s*:\s*["\x27]([A-Za-z0-9_./+=:~-]{12,})["\x27]')}
try:
 for row in selected:
  p.stdin.write((row['git_blob']+'\n').encode());p.stdin.flush()
  header=p.stdout.readline().decode().strip().split()
  assert header==[row['git_blob'],'blob',str(row['bytes'])],header
  b=p.stdout.read(row['bytes']);assert len(b)==row['bytes'] and p.stdout.read(1)==b'\n'
  assert hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()==row['git_blob']
  record=dict(row,sha256=hashlib.sha256(b).hexdigest())
  rows.append(record)
  hits=[k for k,v in patterns.items() if v.search(b)]
  if hits:potential.append({'path':row['path'],'markers':hits})
finally:
 p.stdin.close();stderr=p.stderr.read();assert p.wait()==0 and not stderr
snap=json.loads((E/'matrix-r1/source-before.json').read_bytes())
ci=(E/'github-ci-final-c25-r1.json').read_bytes()
report={'schema':'hepta.rea.a.publication.git-scope.v1','source_commit':source['source_commit'],'source_git_tree':source['source_git_tree'],'source_scan_sha256':hashlib.sha256(raw).hexdigest(),'git_prefixes':list(PREFIXES),'git_root_files':sorted(ROOTS),'files':rows,'potential_secret_markers_only_no_values':potential,'ci_final':{'path':str(E/'github-ci-final-c25-r1.json'),'bytes':len(ci),'sha256':hashlib.sha256(ci).hexdigest()},'matrix_snapshot_structure':{k:(list(v)[:5] if isinstance(v,dict) else {'length':len(v),'first':v[0] if v else None} if isinstance(v,list) else v) for k,v in snap.items()}}
out=(json.dumps(report,indent=2,sort_keys=True)+'\n').encode();path=OUT/'git-source-scope-r1.json'
fd=os.open(path,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
with os.fdopen(fd,'wb') as f:f.write(out);f.flush();os.fsync(f.fileno())
groups={}
for row in rows:
 k=row['path'].split('/')[0];v=groups.setdefault(k,{'files':0,'bytes':0});v['files']+=1;v['bytes']+=row['bytes']
print(json.dumps({'report':str(path),'bytes':len(out),'sha256':hashlib.sha256(out).hexdigest(),'groups':groups,'file_count':len(rows),'source_bytes':sum(x['bytes'] for x in rows),'potential_secret_markers_only_no_values':potential,'ci_final':report['ci_final'],'matrix_snapshot_structure':report['matrix_snapshot_structure']},sort_keys=True))
