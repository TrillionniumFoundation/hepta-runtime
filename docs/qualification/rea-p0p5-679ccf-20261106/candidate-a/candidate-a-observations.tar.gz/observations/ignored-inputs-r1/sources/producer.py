#!/usr/bin/env python3
"""Generate only fixed original Node/REA inputs; never build or run native Rust."""
from __future__ import annotations
import argparse
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import signal
import stat
import subprocess
import sys
import time
import traceback

sys.dont_write_bytecode = True
REPO = Path('/home/qian-qi/work/hepta-rea-json-eof-173861-20261105')
EVIDENCE = Path(str(REPO) + '-evidence')
SOURCE_REFERENCE = '3beb8a28c6145988f8e225d5eef5e5bfca514acc'
NODE = Path('/usr/bin/node')
NODE_SHA = '94efd062ed066c1a0b332e18249859c905e920eeada5df55d24c99b919629a90'
PACKAGE = Path('/home/qian-qi/work/hepta-rea-reference-recovery-ca464-20261105-r1/install/node_modules/rea-agents')
TARBALL = Path('/home/qian-qi/work/hepta-rea-reference-20261103/pack/rea-agents-6.8.0.tgz')
COLLECTOR = EVIDENCE / 'oracle-source-r4/collect_eof_oracle_v5.py'
COLLECTOR_SHA = 'a50826baf7d3fa6cc0634befff43fbb9faadff8574c2e99506068905fd2c6f99'
ELF = Path('/home/qian-qi/rea-ledger-inputs-20261104-r1/oracle/REA_6_8_0_ELF_NOTES_EVIDENCE.json')
ELF_SHA = '5d555ee7942a0355db5901719ae6a40706b684a3c182f3a9b09085969f110622'
PINS = {
    'rea-number-bit-reference.mjs': '9ab5ab164889f6ebde4ce2d7f074584a74c4276a55adf67c1be1102122ce6603',
    'rea-number-reference.mjs': 'c8a443a1ec38a74db385efd49ce099cf17bac472f55985a48b7b89903c41a969',
}
BIT_SHA = 'c02f4b12d3ed29c2a1598328fd5f7d9837a530df0f94b4330be554dea23d8846'
FLOAT_SHA = 'e72cf0239101d1bc2365df8215150162839571b29a3de39d0ac2b4386afd4fa4'


def require(ok, message):
    if not ok:
        raise RuntimeError(message)


def read(path):
    p = Path(path)
    before = p.lstat()
    require(stat.S_ISREG(before.st_mode) and before.st_nlink == 1, 'not single-link regular file: ' + str(p))
    raw = p.read_bytes()
    after = p.lstat()
    fields = ('st_dev', 'st_ino', 'st_size', 'st_mtime_ns', 'st_ctime_ns')
    require(tuple(getattr(before, k) for k in fields) == tuple(getattr(after, k) for k in fields), 'file changed: ' + str(p))
    require(len(raw) == before.st_size, 'read length differs: ' + str(p))
    return raw


def ident(path):
    raw = read(path)
    return {'path': str(path), 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


def publish(path, raw, mode=0o400):
    with Path(path).open('xb') as stream:
        stream.write(raw)
        stream.flush()
        os.fsync(stream.fileno())
    Path(path).chmod(mode)
    return ident(path)


def save(path, obj):
    return publish(path, (json.dumps(obj, sort_keys=True, ensure_ascii=False, indent=2, allow_nan=False) + '\n').encode())


def strict_load(path):
    return json.loads(read(path).decode('utf-8'), parse_constant=lambda x: (_ for _ in ()).throw(ValueError('nonfinite ' + x)))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    output = args.output
    require(output == EVIDENCE / 'ignored-inputs-r1' and output.resolve() == output, 'unexpected output location')
    require(not output.exists(), 'fresh output directory required; never replace prior attempt')
    require(not {'NODE_OPTIONS', 'NODE_PATH'}.intersection(os.environ), 'ambient Node overrides refused')
    os.umask(0o077)
    output.mkdir(mode=0o700)
    for name in ('sources', 'inputs', 'npm-oracle', 'logs'):
        (output / name).mkdir(mode=0o700)
    report = {
        'schema': 'hepta.rea.fixed-original-four-gate-inputs.v1', 'complete': False,
        'qualified': False, 'global_status': 'HOLD/NO_GO', 'errors': [], 'stages': [],
        'native_execution': False, 'native_source_binding': None,
        'producer_source_reference': SOURCE_REFERENCE,
        'scope': 'Only original Node JSON.stringify and fixed real npm domain-module producers plus exact historical CLI ELF fixture. No Cargo, no native binary, no new optional cases.',
        'source_lifetime': 'Pinned immutable producer copies are independent of later native source candidates; original repository scripts are read once with expected hashes, not mutated or required to remain at HEAD.',
        'identity_boundary': 'Trusted-path stable reads and pre/post Node/npm-own-file authentication. No continuous hostile-filesystem or transitive upstream-content authentication claim.',
    }
    before = None
    helpers = None
    child = None
    interrupted = []
    prior_handlers = {}
    input_before = {}
    driver_before = ident(Path(__file__).resolve())
    env = os.environ.copy()
    env.update({'PYTHONDONTWRITEBYTECODE': '1', 'LC_ALL': 'C.UTF-8', 'LANG': 'C.UTF-8', 'TZ': 'UTC'})

    def on_signal(number, frame):
        interrupted.append(number)
        # The handler never signals a numeric PID/PGID: wait() may already
        # have reaped the leader before the main thread clears its variable.

    def run(name, argv, timeout=300):
        nonlocal child
        row = {'name': name, 'argv': argv, 'cwd': str(output), 'returncode': None, 'forced_cleanup': []}
        report['stages'].append(row)
        start = time.monotonic_ns()
        stdout = output / 'logs' / (name + '.stdout')
        stderr = output / 'logs' / (name + '.stderr')
        with stdout.open('xb') as out, stderr.open('xb') as err:
            child = subprocess.Popen(argv, cwd=output, env=env, stdin=subprocess.DEVNULL,
                                     stdout=out, stderr=err, start_new_session=True)
            row['pid'] = child.pid
            deadline = time.monotonic() + timeout
            while child is not None:
                try:
                    row['returncode'] = child.wait(timeout=0.25)
                    row['owned_direct_child_reaped'] = True
                    child = None
                except subprocess.TimeoutExpired:
                    if not interrupted and time.monotonic() < deadline:
                        continue
                    # TimeoutExpired means this sole waiter has not reaped
                    # the leader. Its live/zombie PID still holds numeric
                    # group identity until the wait below; no handler signals.
                    row['forced_cleanup'].append('interrupted/timeout: SIGTERM while leader waitable')
                    try:
                        os.killpg(child.pid, signal.SIGTERM)
                    except ProcessLookupError:
                        pass
                    try:
                        row['returncode'] = child.wait(timeout=10)
                    except subprocess.TimeoutExpired:
                        row['forced_cleanup'].append('SIGKILL while leader still waitable')
                        try:
                            os.killpg(child.pid, signal.SIGKILL)
                        except ProcessLookupError:
                            pass
                        row['returncode'] = child.wait()
                    row['owned_direct_child_reaped'] = True
                    child = None
        row.update(elapsed_ns=time.monotonic_ns()-start, stdout=ident(stdout), stderr=ident(stderr))
        print(json.dumps({'stage': name, 'returncode': row['returncode'], 'forced_cleanup': row['forced_cleanup']}), flush=True)
        require(row['returncode'] == 0 and not row['forced_cleanup'] and not interrupted, 'producer stage failed/interrupted: ' + name)
        return read(stdout)

    try:
        for number in (signal.SIGTERM, signal.SIGINT):
            prior_handlers[number] = signal.signal(number, on_signal)
        copies = {'producer.py': publish(output / 'sources' / 'producer.py', read(Path(__file__).resolve()))}
        for name, expected in PINS.items():
            source = REPO / 'scripts' / name
            raw = read(source)
            require(hashlib.sha256(raw).hexdigest() == expected, 'producer source pin mismatch: ' + name)
            copies[name] = publish(output / 'sources' / name, raw)
        collector_raw = read(COLLECTOR)
        require(hashlib.sha256(collector_raw).hexdigest() == COLLECTOR_SHA, 'collector helper pin mismatch')
        copies['collect_eof_oracle_v5.py'] = publish(output / 'sources' / 'collect_eof_oracle_v5.py', collector_raw)
        spec = importlib.util.spec_from_file_location('original_inputs_collector_v5', output / 'sources' / 'collect_eof_oracle_v5.py')
        helpers = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(helpers)
        require(ident(NODE.resolve())['sha256'] == NODE_SHA, 'Node executable pin mismatch')
        version = run('01-node-version', [str(NODE), '--version'], 30).decode('ascii').strip()
        require(version == 'v22.23.4', 'Node version differs')
        before = {'node': ident(NODE.resolve()), 'node_version': version,
                  'package': helpers.package_identity(PACKAGE, TARBALL), 'producers': copies,
                  'historical_elf': ident(ELF), 'driver': driver_before}
        require(before['historical_elf']['bytes'] == 8193 and before['historical_elf']['sha256'] == ELF_SHA, 'historical ELF fixture identity mismatch')
        save(output / 'identity-before.json', before)
        report['identity_before'] = ident(output / 'identity-before.json')
        controlled = {k: env[k] for k in ('PYTHONDONTWRITEBYTECODE', 'LC_ALL', 'LANG', 'TZ')}
        save(output / 'controlled-environment.json', controlled)
        report['controlled_environment'] = ident(output / 'controlled-environment.json')
        report['elf_copy'] = publish(output / 'inputs' / ELF.name, read(ELF))
        require(report['elf_copy']['sha256'] == ELF_SHA, 'ELF copied bytes differ')
        run('02-node-bit-corpus', [str(NODE), str(output / 'sources' / 'rea-number-bit-reference.mjs'), str(output / 'bit-oracle'), '1000000'])
        run('03-npm-evidence', [str(NODE), str(output / 'sources' / 'rea-number-reference.mjs'), str(PACKAGE.parent.parent), str(output / 'npm-oracle')])
        bit = output / 'bit-oracle' / 'number-cases.tsv'
        bit_manifest = strict_load(output / 'bit-oracle' / 'number-oracle-manifest.json')
        positive = output / 'npm-oracle' / 'REA_6_8_0_FINITE_NUMBER_EVIDENCE.json'
        negative = output / 'npm-oracle' / 'REA_6_8_0_INVALID_EVIDENCE_SCHEMA.json'
        positive_manifest = strict_load(output / 'npm-oracle' / 'REA_6_8_0_FINITE_NUMBER_MANIFEST.json')
        cases = strict_load(positive)['cases']
        invalid = strict_load(negative)['cases']
        require(type(bit_manifest['finite_cases']) is int and bit_manifest['finite_cases'] == 1052304, 'finite bit denominator differs')
        require(bit_manifest['node'] == '22.23.4' and bit_manifest['generator_sha256'] == PINS['rea-number-bit-reference.mjs'], 'bit oracle identity differs')
        require(ident(bit)['sha256'] == BIT_SHA == bit_manifest['corpus_sha256'], 'bit corpus bytes differ from fixed reference')
        require(len(cases) == 438 and ident(positive)['sha256'] == FLOAT_SHA, 'positive original corpus differs')
        require(type(positive_manifest['cases']) is int and positive_manifest['cases'] == 438 and positive_manifest['allVerifiedByUpstreamParseEvidence'] is True, 'upstream positive verification missing')
        require(hashlib.sha256(read(positive)[:-1]).hexdigest() == positive_manifest['corpusSha256'] and read(positive).endswith(b'\n'), 'manifest sans-LF digest mismatch')
        require(len(invalid) == 20 and all(x['authenticatedHashButRejectedSchema'] is True for x in invalid), 'twenty hash-consistent upstream schema rejections required')
        require(len({x['label'] for x in invalid}) == 20, 'negative labels are repeated')
        report['counts'] = {'finite_bit_patterns': 1052304, 'real_npm_positive_evidence': 438, 'real_npm_schema_negatives': 20, 'historical_cli_elf_records': 1}
        report['negative_labels'] = [x['label'] for x in invalid]
        for directory in ('inputs', 'bit-oracle', 'npm-oracle', 'sources'):
            for path in sorted((output / directory).iterdir()):
                require(path.is_file() and not path.is_symlink(), 'unexpected generated member')
                path.chmod(0o400)
                input_before[str(path.relative_to(output))] = ident(path)
        for name, original in copies.items():
            require(input_before['sources/' + name] == original, 'producer copy changed since initial pin: ' + name)
        save(output / 'immutable-inputs.json', input_before)
        report['immutable_inputs'] = ident(output / 'immutable-inputs.json')
    except BaseException as error:
        report['errors'].append({'type': type(error).__name__, 'message': str(error), 'traceback': traceback.format_exc()})
    finally:
        if child is not None:
            # poll() reaps a completed direct child; never signal its old
            # numeric process group after that. A None result preserves the
            # sole waiter's unreaped-leader custody until our next wait.
            if child.poll() is None:
                try:
                    os.killpg(child.pid, signal.SIGTERM)
                except ProcessLookupError:
                    pass
                try:
                    child.wait(timeout=10)
                except subprocess.TimeoutExpired:
                    try:
                        os.killpg(child.pid, signal.SIGKILL)
                    except ProcessLookupError:
                        pass
                    child.wait()
            report['errors'].append({'phase': 'cleanup', 'message': 'interrupted owned producer cleaned; no success claim'})
            child = None
        if helpers is not None and before is not None:
            try:
                after = {'node': ident(NODE.resolve()), 'package': helpers.package_identity(PACKAGE, TARBALL), 'historical_elf': ident(ELF), 'driver': ident(Path(__file__).resolve())}
                for key in after:
                    require(after[key] == before[key], key + ' changed during original generation')
                for relative, expected in input_before.items():
                    require(ident(output / relative) == expected, 'frozen input changed: ' + relative)
                save(output / 'identity-after.json', after)
                report['identity_after'] = ident(output / 'identity-after.json')
            except BaseException as error:
                report['errors'].append({'phase': 'identity-postflight', 'type': type(error).__name__, 'message': str(error)})
        for number, previous in prior_handlers.items():
            signal.signal(number, previous)
    report['signals'] = interrupted
    report['complete'] = not report['errors'] and not interrupted and bool(input_before)
    report['status'] = 'ORIGINAL_INPUTS_GENERATED' if report['complete'] else 'FAIL'
    report['completed_utc'] = time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())
    receipt = save(output / 'result.json', report)
    print(json.dumps({'complete': report['complete'], 'counts': report.get('counts'), 'receipt': receipt, 'errors': report['errors']}), flush=True)
    return 0 if report['complete'] else 2


if __name__ == '__main__':
    raise SystemExit(main())
