#!/usr/bin/env python3
"""Bind the finite preload oracle and lossless worker observations to candidate c25."""
import argparse, hashlib, json, os
from pathlib import Path
import subprocess, sys, time
BASE=Path("/home/qian-qi/work/hepta-rea-p0p5-679ccf-20261105")
EVIDENCE=Path(str(BASE)+"-evidence")
TARGET=Path(str(BASE)+"-target")
COMMIT="c25e4cef0610816bfd1263b69d3dd63e4114aa49"
NODE=Path("/usr/bin/node")
PINS={
 "scripts/qualify_javascript_preload_wrappers.mjs":"1a1c23021ee2a23acfefebdf87949a58ef7f6e20b49b223fc06de2022d379696",
 "tests/fixtures/rea_javascript/preload-original-rea-6_8_0-679ccf.json":"b1640feec76ac2ad11c08b469c103af382b4e4c99a63058dd35db16cc8256509"}
def identity(path):
    digest=hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda:stream.read(1048576),b""):digest.update(block)
    return {"path":str(path),"bytes":path.stat().st_size,"sha256":digest.hexdigest()}
def save(path,value):
    with path.open("x") as f:
        json.dump(value,f,indent=2,sort_keys=True);f.write("\n");f.flush();os.fsync(f.fileno())
def run(out,name,argv,*,cwd,env,input_bytes=None,timeout=120):
    stdout,stderr=out/(name+".stdout.log"),out/(name+".stderr.log")
    start=time.monotonic_ns()
    with stdout.open("xb") as o,stderr.open("xb") as e:
        p=subprocess.Popen(argv,cwd=cwd,env=env,stdin=subprocess.PIPE if input_bytes is not None else subprocess.DEVNULL,stdout=o,stderr=e,start_new_session=True)
        pid=p.pid
        timed_out=False
        try:p.communicate(input=input_bytes,timeout=timeout)
        except subprocess.TimeoutExpired:
            timed_out=True
            import signal
            os.killpg(pid,signal.SIGKILL);p.wait(timeout=10)
    row={"argv":argv,"cwd":str(cwd),"selected_environment":env,"pid":pid,"returncode":p.returncode,"timed_out":timed_out,"elapsed_ns":time.monotonic_ns()-start,"stdout":identity(stdout),"stderr":identity(stderr)}
    save(out/(name+".process.json"),row)
    assert p.returncode==0 and not timed_out,row
    return row
def main():
    args=argparse.ArgumentParser()
    args.add_argument("--expected-binding-sha256",required=True)
    args.add_argument("--expected-binary-sha256",required=True)
    options=args.parse_args()
    binding_path=EVIDENCE/"binding.json"
    assert identity(binding_path)["sha256"]==options.expected_binding_sha256
    binding=json.loads(binding_path.read_bytes())
    assert binding["source_commit"]==COMMIT
    binary=EVIDENCE/"hepta-runtime"
    assert identity(binary)==binding["runtime"]
    assert identity(binary)["sha256"]==options.expected_binary_sha256
    assert subprocess.check_output(["git","-C",str(BASE),"rev-parse","HEAD"],text=True).strip()==COMMIT
    assert not subprocess.check_output(["git","-C",str(BASE),"status","--porcelain=v1"],text=True).strip()
    complete=json.loads((EVIDENCE/"run-summary.json").read_bytes())
    assert complete["all_four_passed"] and complete["source_unchanged"] and complete["supplemental_source_unchanged"]
    assert identity(NODE)["sha256"]=="94efd062ed066c1a0b332e18249859c905e920eeada5df55d24c99b919629a90"
    for relative,expected in PINS.items():assert identity(BASE/relative)["sha256"]==expected,relative
    assert identity(EVIDENCE/"js-original-rea-r1/observation.json")["sha256"]=="2f571cb41568ba6c710d0983d406ca524792a73e9a323e7f04ddf5bbc5b07046"
    sys.path.insert(0,str(BASE/"scripts"))
    import rea_full_qualification as matrix
    import rea_build_evidence as consumer
    selection=matrix.Selection(BASE,TARGET,EVIDENCE/"matrix-r1")
    before=selection.snapshot()
    validated=consumer.validate_matrix((EVIDENCE/"matrix-r1/summary.json").read_bytes(),lambda name:consumer.read_regular(EVIDENCE/"matrix-r1",name),before,identity(binary))
    assert validated==binding["independent_consumer"]
    out=EVIDENCE/"javascript-bound-r1"
    out.mkdir()
    save(out/"source-before.json",before)
    save(out/"inputs.json",{"binding":identity(binding_path),"binary":identity(binary),"node":identity(NODE),"selected_sources":[identity(BASE/p) for p in PINS],"original_observation":identity(EVIDENCE/"js-original-rea-r1/observation.json"),"independent_consumer":validated})
    monitor=matrix.SourceMonitor(selection);monitor.start()
    report={"source_commit":COMMIT,"full_rea_parity":False,"production_qualified":False,"passed":False,"raw_worker_cases":[]}
    try:
        result_path=out/"preload-wrappers.json"
        report["oracle_harness"]=run(out,"oracle-harness",[str(NODE),str(BASE/"scripts/qualify_javascript_preload_wrappers.mjs"),str(binary),str(result_path)],cwd=BASE,env={"PATH":"/usr/bin:/bin"},timeout=240)
        observed=json.loads(result_path.read_bytes())
        assert observed["passed"] and observed["scope"]=="finite_preload_literal_observations_only"
        assert observed["oracle_summary"]=={"denominator":7,"node_matches":7,"original_rea_matches":7,"oracles_agree":7,"runtime_contract_passes":7}
        original=json.loads((BASE/"tests/fixtures/rea_javascript/preload-original-rea-6_8_0-679ccf.json").read_bytes())
        original_cases={x["id"]:x for x in original["cases"]}
        for index,case in enumerate(observed["cases"],1):
            source=(Path(observed["fixture_directory"])/case["id"]).read_bytes()
            assert hashlib.sha256(source).hexdigest()==case["source_sha256"]==original_cases[case["id"]]["source_sha256"]
            request={"sources":[{"id":case["id"],"syntax":case["syntax"],"module_kind":"commonjs","text":source.decode()}],"collection":"electron_calls","offset":0,"limit":256,"expected_graph_sha256":None}
            request_bytes=json.dumps(request,separators=(",",":")).encode()
            request_path=out/("worker-"+str(index)+".request.json");request_path.write_bytes(request_bytes)
            child=run(out,"worker-"+str(index),[str(binary),"rea-javascript-worker"],cwd=Path("/"),env={},input_bytes=request_bytes,timeout=25)
            raw=Path(child["stdout"]["path"]).read_bytes()
            assert len(raw)<2*1024*1024
            reply=json.loads(raw)
            assert reply["analysis_profile"]=="hepta.javascript-selected-source-graph.v4"
            assert reply["javascript_executed"] is False and len(reply["rows"])==1
            row=reply["rows"][0]
            assert row["runtime_observed"] is False
            projected={k:row[k] for k in ("preload_declaration_present","literal_preload")}
            assert projected==case["expected"]==case["original_expected"]==original_cases[case["id"]]["expected"]
            assert reply["graph_sha256"]==case["graph_sha256"]
            report["raw_worker_cases"].append({"id":case["id"],"request":identity(request_path),"process":child,"projected":projected,"graph_sha256":reply["graph_sha256"],"passed":True})
        report["oracle_result"]=identity(result_path)
        report["oracle_summary"]=observed["oracle_summary"]
        report["passed"]=True
    except BaseException as error:
        report["failure"]=type(error).__name__+": "+str(error)
        raise
    finally:
        after=selection.snapshot();events=monitor.stop()
        save(out/"source-after.json",after);save(out/"source-events.json",events)
        report["source_unchanged"]=after==before and events.get("event_count")==0 and not events.get("errors")
        report["binary_unchanged"]=identity(binary)==binding["runtime"]
        report["passed"]=report["passed"] and report["source_unchanged"] and report["binary_unchanged"]
        save(out/"summary.json",report)
    assert report["passed"],report
    print(json.dumps({"passed":True,"cases":len(report["raw_worker_cases"]),"oracle_summary":report["oracle_summary"],"summary":identity(out/"summary.json")}),flush=True)
if __name__=="__main__":main()
