const {BrowserWindow}=require("electron"); new BrowserWindow((<Record<string, unknown>>{webPreferences:{preload:"./preload.cjs"}}));
