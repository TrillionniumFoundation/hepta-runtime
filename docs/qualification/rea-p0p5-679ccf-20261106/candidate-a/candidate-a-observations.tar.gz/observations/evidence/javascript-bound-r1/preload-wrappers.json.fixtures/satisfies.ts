const {BrowserWindow}=require("electron"); new BrowserWindow(({webPreferences:{preload:"./preload.cjs"}} satisfies Record<string, unknown>));
