const {BrowserWindow}=require("electron"); new BrowserWindow(({webPreferences:{preload:"./preload.cjs"}} as const));
