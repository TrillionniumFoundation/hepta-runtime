#!/usr/bin/env python3
"""Run only diagnosed stage 6 R3, preserving and consuming the complete R1 record."""
from __future__ import annotations
import argparse
import ast
import hashlib
import importlib
import importlib.util
import json
import os
from pathlib import Path
import stat
import sys

sys.dont_write_bytecode = True
EVIDENCE = Path("/home/qian-qi/work/hepta-rea-p0p5-679ccf-20261105-evidence")
BASE_PATH = EVIDENCE / "run_bound_provider_gates_r1.py"
BASE_SHA = "b4fc9d821c09ebe6d0bacaff24e4cc2f722bf3b4734d7edd7d884e660c28f5fa"
OLD_HELPER = EVIDENCE / "run_owned_real_apk_r1.py"
OLD_HELPER_SHA = "df35e61f96d90d7420ff86a8d1a6466dc5555f20d1282ba000499436a2638901"
HELPER = EVIDENCE / "run_owned_real_apk_r3.py"
HELPER_SHA = "196ded588c3146b5e2902d46de3069d119ab46896c1f537baa19a8741eff1da6"
R1 = EVIDENCE / "provider-gates-r1"
R1_SUMMARY_SHA = "bfe1bc1d4cf1be52dad4c6b69381279169173e9b21d8044f10d11d8748554842"
R1_OUTER = EVIDENCE / "provider-gates-r1-outer-receipt.json"
R1_OUTER_SHA = "6d02e33d5a71f73bb64ddde3004ec1d2165db9c1974f21cafb9b31603bd6b18f"
R1_FAILURE_SHA = "f4cc17f07b4335a82e1cd387c10404012014ecc0ab060553c408d17d060b6a07"
RUN = EVIDENCE / "owned-real-apk-r3"
MISSING = "/usr/lib/jvm/java-21-openjdk-amd64/lib/libsunec.so"

R2_HELPER = EVIDENCE / "run_owned_real_apk_r2.py"
R2_HELPER_SHA = "4f7f70b65fd5f63408829d862a4c1189c538db3c5940ec36d24c309bda9158a1"
R2_WRAPPER = EVIDENCE / "run_bound_owned_apk_r2.py"
R2_WRAPPER_SHA = "dc2cccf24cd2c62a002ddd15e700e49670e30bb152ccd70753bb192b46450e77"
R2_ROOT = EVIDENCE / "owned-real-apk-r2"
R2_SUMMARY_SHA = "c9f5d30b88432a298ada5d2a542f6f2c86f8a4ad4df207a1210e8d11f5927046"
R2_FAILURE_SHA = "5e5e0170ba2f367cfecbfe13882a39976d8a64a006555d0a7277d59ac42749aa"
R2_OUTER = EVIDENCE / "owned-real-apk-r2-outer-receipt.json"
R2_OUTER_SHA = "247686fa6e7b8d8bbfafcb3d0536c7202c1af5770bf2512d3468601d5dc646a7"
AAPT_VERSION_BYTES = b"Android Asset Packaging Tool (aapt) 2.19-12874835\n"

ROLE_SETS = {
    "ghidra": {"inventory_v2", "functions", "function", "decompile", "xrefs",
               "cancel", "worker_crash", "owner_timeout", "interior_refusal"},
    "jadx": {"classes", "sources", "cancel"},
    "chrome": {"tamper", "capture", "cancel", "environment"},
}
STAGES = ["ghidra", "jadx", "chrome", "apk-three-way", "apk-mcp"]
COMMAND_NAMES = ["source-commit-tree", "aapt2-version", "aapt2-compile", "aapt2-link",
    "keytool-owned-pkcs12", "apksigner-sign", "apksigner-verify-signed",
    "worker-preview-signed", "worker-native-signed", "apksigner-verify-tampered",
    "worker-preview-tampered", "worker-native-tampered", "worker-native-truncated",
    "source-commit-tree-after"]
COMMAND_BUDGETS = [15, 15, 60, 60, 120, 120, 60, 60, 35, 60, 60, 35, 35, 15]
INTEGRITY_KEYS = ("source_bytes_unchanged", "source_monitor_complete", "source_git_unchanged",
                  "host_unchanged", "binding_unchanged", "runtime_unchanged", "driver_unchanged")
EMPTY_MONITOR = {"event_count": 0, "retained_events": [], "events_truncated": False, "errors": []}

def require(value, message):
    if not value:
        raise AssertionError(message)

def bootstrap():
    raw = BASE_PATH.read_bytes()
    require(hashlib.sha256(raw).hexdigest() == BASE_SHA, "frozen R1 shared consumer changed")
    require(BASE_PATH.is_file() and not BASE_PATH.is_symlink(), "base consumer is not regular")
    module_spec = importlib.util.spec_from_file_location("bound_provider_r1_read_only", BASE_PATH)
    module = importlib.util.module_from_spec(module_spec)
    module_spec.loader.exec_module(module)
    return module

base = bootstrap()

def verify_reference(ref, root=None):
    require(isinstance(ref, dict) and all(key in ref for key in ("path", "bytes", "sha256")),
            "file reference has an incomplete schema")
    path = Path(ref["path"])
    require(path.is_absolute() and (root is None or path.is_relative_to(root)), "evidence path outside its root")
    value = base.reference(path)
    require(value == {key: ref[key] for key in ("path", "bytes", "sha256")}, "referenced evidence bytes changed: " + str(path))
    return path

def helper_scope():
    require(base.reference(OLD_HELPER)["sha256"] == OLD_HELPER_SHA
            and base.reference(HELPER)["sha256"] == HELPER_SHA, "R1/R3 helper bytes changed")
    require(base.reference(R2_HELPER)["sha256"] == R2_HELPER_SHA, "retained R2 helper changed")
    r2_text = R2_HELPER.read_text()
    old_version_block = "        _row, version_out, _err = commands.success(\"aapt2-version\", [SDK / \"aapt2\", \"version\"], timeout=15)\n        record[\"actual_aapt2_version\"] = version_out.read_text().strip()\n        require(record[\"actual_aapt2_version\"].startswith(\"Android Asset Packaging Tool\"),\n                \"actual AAPT2 version output is absent or unexpected\")"
    new_version_block = "        _row, version_out, version_err = commands.success(\"aapt2-version\", [SDK / \"aapt2\", \"version\"], timeout=15)\n        version_bytes = version_out.read_bytes() + version_err.read_bytes()\n        record[\"actual_aapt2_version\"] = version_bytes.decode(\"utf-8\").strip()\n        require(version_bytes == b\"Android Asset Packaging Tool (aapt) 2.19-12874835\\n\",\n                \"actual pinned AAPT2 version bytes across stdout and stderr differ\")"
    require(r2_text.count(old_version_block) == 1
            and r2_text.replace(old_version_block, new_version_block).encode() == HELPER.read_bytes(),
            "R3 changed anything beyond the diagnosed strict version channel assertion")
    old, new = ast.parse(OLD_HELPER.read_bytes()), ast.parse(R2_HELPER.read_bytes())
    def assignments(tree):
        return {node.targets[0].id: ast.literal_eval(node.value)
                for node in tree.body if isinstance(node, ast.Assign)
                and len(node.targets) == 1 and isinstance(node.targets[0], ast.Name)
                and node.targets[0].id in {"JDK_CORE", "JDK_OBSERVED_ABSENT", "CHECKS"}}
    a, b = assignments(old), assignments(new)
    require(b["JDK_CORE"] == tuple(name for name in a["JDK_CORE"] if name != "lib/libsunec.so")
            and b["JDK_OBSERVED_ABSENT"] == ("lib/libsunec.so",), "R3 core/absence scope changed")
    def retained(tree):
        result = []
        for node in tree.body:
            if isinstance(node, ast.FunctionDef) and node.name in {"closure", "jdk_installation_tree"}:
                continue
            if isinstance(node, ast.Assign) and any(isinstance(target, ast.Name)
                    and target.id in {"JDK_CORE", "JDK_OBSERVED_ABSENT"} for target in node.targets):
                continue
            result.append(ast.dump(node, include_attributes=False))
        return result
    require(retained(old) == retained(new), "R3 changed command logic, assertions, budgets, or unrelated module code")
    require(len(a["CHECKS"]) == 14 and a["CHECKS"] == b["CHECKS"], "R3 check contract changed")
    return {"old_helper": base.reference(OLD_HELPER), "new_helper": base.reference(HELPER),
            "r2_helper": base.reference(R2_HELPER),
            "original_child_order_budgets_and_apk_assertions_unchanged": True,
            "version_assertion_revision": "exact pinned 50 bytes across stdout plus stderr",
            "changed_existing_functions": ["closure", "main:aapt2-version-observation"],
            "added_functions": ["jdk_installation_tree"],
            "checks": a["CHECKS"]}

def complete_status(status, job_id, expected_state=None, expected_exit=None):
    require(status.get("job_id") == job_id and type(status.get("exit_code")) is int,
            "original terminal identity is incomplete")
    require(status.get("state") in {"succeeded", "failed", "cancelled", "timed_out"}
            and status.get("output_complete") is True and status.get("output_durable") is True
            and status.get("terminal_publication_confirmed") is True, "original terminal was not durably complete")
    if expected_state is not None:
        require(status["state"] == expected_state and status["exit_code"] == expected_exit, "original terminal verdict differs")
    for stream in ("stdout", "stderr"):
        count = status["log_bytes"][stream]
        require(type(count["stored"]) is int and 0 <= count["stored"] <= 4 * base.MIB
                and count["seen"] == count["stored"] and status["log_errors"][stream] is None
                and status["log_synced"][stream] is True and status["log_truncated"][stream] is False,
                "original terminal log accounting is incomplete")

def verify_pages(pages, status, job_id, *, terminal_pages=True):
    require(0 < len(pages) <= 257, "original log page set is empty or excessive")
    data = {"stdout": bytearray(), "stderr": bytearray()}
    for page in pages:
        require(page.get("job_id") == job_id, "original read page job identity differs")
        for stream in data:
            item = page[stream]
            raw = bytes.fromhex(item["bytes_hex"])
            require(item["offset"] == len(data[stream]) and item["next_offset"] == len(data[stream]) + len(raw),
                    "original log page cursor discontinuity")
            data[stream].extend(raw)
            require(item["next_offset"] <= item["size"] <= status["log_bytes"][stream]["stored"],
                    "original page size exceeds complete terminal bytes")
            if terminal_pages:
                require(item["size"] == status["log_bytes"][stream]["stored"], "original terminal page total differs")
    for stream in data:
        require(pages[-1][stream]["eof"] is True
                and len(data[stream]) == status["log_bytes"][stream]["stored"], "original log pages incomplete")
    return {key: bytes(value) for key, value in data.items()}

def validate_r1_outer():
    require(base.reference(R1_OUTER)["sha256"] == R1_OUTER_SHA, "R1 original outer receipt changed")
    outer = base.read_json(R1_OUTER)
    job_id = "1a1ae74be39-fc05-5fad"
    require(outer["schema"] == "hepta.rea.c25.provider-gates.outer-receipt.v1"
            and outer["host"] == "desktop" and outer["job_id"] == job_id
            and outer["launch"]["job"]["id"] == job_id
            and outer["launch"]["reused"] is False, "R1 original launch binding differs")
    status = outer["final_status"]
    complete_status(status, job_id, "failed", 1)
    require(status["automatic_retry"] is False and status["timed_out"] is False
            and status["cancelled"] is False, "R1 outer did not end in the diagnosed ordinary failure")
    logs = verify_pages(outer["original_read_pages"], status, job_id, terminal_pages=False)
    lines = [json.loads(line) for line in logs["stdout"].splitlines()]
    require(lines[0]["prelaunch_sha_guard"] == "passed"
            and [line["stage"] for line in lines[1:-1]] == STAGES
            and all(line["status"] == "passed" for line in lines[1:-1])
            and lines[-1]["provider_gates"] == "failed" and lines[-1]["qualified"] is False
            and lines[-1]["summary"]["sha256"] == R1_SUMMARY_SHA, "R1 original stage output is incomplete")
    require(b"stage process did not complete cleanly: apk-generated" in logs["stderr"],
            "R1 ordinary failure stderr is missing")
    return {"receipt": base.reference(R1_OUTER), "job_id": job_id,
            "terminal_state": status["state"], "exit_code": status["exit_code"],
            "complete_log_bytes": {key: len(value) for key, value in logs.items()}}

def verify_artifacts(directory, ref):
    manifest_path = verify_reference(ref, directory)
    expected = base.read_json(manifest_path)
    current = base.artifact_inventory(directory)
    current["files"] = [row for row in current["files"] if row["path"] != str(manifest_path)]
    current["file_count"] -= 1
    current["regular_bytes"] -= manifest_path.stat().st_size
    require(current == expected, "R1 complete stage artifact inventory changed: " + directory.name)
    return {"manifest": ref, "files_revalidated": expected["file_count"], "bytes_revalidated": expected["regular_bytes"]}

def verify_original_jobs(name, directory, report, rows):
    require(len(rows) == len(ROLE_SETS[name]) and {row["role"] for row in rows} == ROLE_SETS[name]
            and len({row["job_id"] for row in rows}) == len(rows), "R1 original terminal set differs")
    destination = directory / "original-terminals"
    saved = base.read_json(destination / "summary.json")
    require(saved["original_jobs"] == rows and saved["close"]["exit_code"] == 0
            and saved["close"]["teardown_actions"] == [] and saved["read_only_tools"] is True
            and saved["runtime_or_engine_relaunch"] is False, "R1 terminal reader did not close cleanly")
    if name == "ghidra":
        roles = dict(report["job_ids"])
        roles["interior_refusal"] = base.read_json(directory / "workspace/interior-refusal.json")["initial"]["job"]["id"]
    elif name == "jadx":
        roles = {"classes": report["classes_job_id"], "cancel": report["cancel_job_id"],
                 "sources": base.read_json(destination / "sources-static-status.json")["job"]["id"]}
    else:
        roles = {"tamper": report["tamper_job_id"], "capture": report["capture_job_id"],
                 "cancel": report["cancel_job_id"],
                 "environment": report["environment_observation"]["instrumented_environment_job_id"]}
    require(roles == {row["role"]: row["job_id"] for row in rows}, "R1 report/original job identities differ")
    for row in rows:
        role, job_id = row["role"], row["job_id"]
        status = base.read_json(verify_reference(row["status"], destination))
        complete_status(status, job_id)
        require(status["state"] == row["state"] and status["exit_code"] == row["exit_code"], "R1 terminal result differs")
        if role in {"inventory_v2", "functions", "function", "decompile", "xrefs", "classes", "sources", "capture"}:
            require(status["state"] == "succeeded" and status["exit_code"] == 0, "R1 positive role failed")
        elif role == "owner_timeout":
            require(status["state"] == "timed_out" and status["exit_code"] != 0, "R1 timeout was not actual")
        elif role in {"worker_crash", "interior_refusal", "tamper"}:
            require(status["state"] == "failed" and status["exit_code"] != 0, "R1 expected failure missing")
        else:
            require(status["state"] in {"cancelled", "failed"} and status["exit_code"] != 0, "R1 cancellation missing")
        paths = sorted((destination / role).glob("page-*.json"))
        require([path.name for path in paths] == ["page-%04d.json" % i for i in range(len(paths))],
                "R1 original terminal page membership is incomplete")
        raw = verify_pages([base.read_json(path) for path in paths], status, job_id)
        for stream in ("stdout", "stderr"):
            require(verify_reference(row[stream], destination).read_bytes() == raw[stream],
                    "R1 paged bytes differ from original archive bytes")
    return len(rows)

def consume_r1(expected_binary, expected_source):
    require(base.reference(R1 / "summary.json")["sha256"] == R1_SUMMARY_SHA, "R1 RED summary changed")
    outer = validate_r1_outer()
    summary = base.read_json(R1 / "summary.json")
    require(summary["source_commit"] == base.COMMIT and summary["source_git_tree"] == base.GIT_TREE
            and summary["runtime"]["sha256"] == expected_binary
            and summary["status"] == "failed" and summary["qualified"] is False
            and summary["automatic_retry"] is False
            and all(summary.get(key) is True for key in INTEGRITY_KEYS), "R1 candidate/final integrity differs")
    require(base.read_json(R1 / "source-before.json") == base.read_json(R1 / "source-after.json") == expected_source
            and base.read_json(R1 / "source-events.json") == EMPTY_MONITOR, "R1 source bytes/monitor do not bind current candidate")
    require([row["name"] for row in summary["stages"]] == STAGES + ["apk-generated"], "R1 stage membership differs")
    consumed = []
    for index, row in enumerate(summary["stages"][:5], 1):
        name = row["name"]
        directory = R1 / ("%02d-%s" % (index, name))
        require(row["status"] == "passed" and row["qualified"] is True, "R1 stage was not passed")
        process = base.read_json(directory / "process.json")
        require(process == row["process"] and process["returncode"] == 0 and process["timed_out"] is False
                and process["cleanup_actions"] == [] and process["failure"] is None
                and process["automatic_retry"] is False, "R1 stage process completion differs")
        for stream in ("stdout", "stderr"):
            verify_reference(process[stream], directory)
        report = base.read_json(verify_reference(row["qualification"], directory))
        if name in ROLE_SETS:
            result = base.validate_engine(name, directory / "workspace", report, expected_binary)
            count = verify_original_jobs(name, directory, report, row["original_terminals"])
        elif name == "apk-three-way":
            result = base.validate_apk_oracle(report, expected_binary)
            count = 0
        else:
            result = base.validate_apk_mcp(report, expected_binary)
            count = 0
        require(result == row["result"], "R1 independently recomputed stage result differs")
        require(base.read_json(directory / "inputs-before.json") == base.read_json(directory / "inputs-after.json"),
                "R1 stage installation bytes changed during execution")
        artifacts = verify_artifacts(directory, row["artifact_inventory"])
        consumed.append({"name": name, "qualified": True, "result": result,
                         "original_terminal_count": count, "qualification": row["qualification"],
                         "artifact_revalidation": artifacts, "rerun": False})
    failed = summary["stages"][5]
    failure_path = R1 / "06-apk-generated/workspace/qualification.json"
    require(base.reference(failure_path)["sha256"] == R1_FAILURE_SHA, "R1 zero-command RED helper report changed")
    failure = base.read_json(failure_path)
    require(failed["status"] == "failed" and failed["qualified"] is False
            and failed["process"]["returncode"] == 1 and failed["process"]["timed_out"] is False
            and failed["process"]["cleanup_actions"] == [] and failed["engine_or_gate_retry_performed"] is False
            and failed["inputs_unchanged_after_failure"] is True and failed["post_failure_observation_errors"] == [],
            "R1 preparation failure completion differs")
    require(failure["status"] == "failed" and failure["qualified"] is False
            and failure["checks"] == [] and failure["commands"] == [] and failure["runtime_sha256"] is None
            and failure["failure"]["type"] == "FileNotFoundError"
            and failure["failure"]["message"] == "[Errno 2] No such file or directory: '" + MISSING + "'",
            "R1 failure was not the diagnosed zero-command precondition defect")
    require(base.read_json(R1 / "06-apk-generated/process.json") == failed["process"], "R1 failed process record differs")
    for stream in ("stdout", "stderr"):
        verify_reference(failed["process"][stream], R1 / "06-apk-generated")
    verify_artifacts(R1 / "06-apk-generated", failed["artifact_inventory_after_failure"])
    return {"summary": base.reference(R1 / "summary.json"), "outer": outer,
            "passed_stages": consumed, "zero_command_failure": base.reference(failure_path),
            "original_red_preserved": True, "passed_stages_rerun": False}

def consume_r2_red(expected_binary, expected_source):
    require(base.reference(R2_HELPER)["sha256"] == R2_HELPER_SHA
            and base.reference(R2_WRAPPER)["sha256"] == R2_WRAPPER_SHA
            and base.reference(R2_ROOT / "summary.json")["sha256"] == R2_SUMMARY_SHA
            and base.reference(R2_OUTER)["sha256"] == R2_OUTER_SHA, "retained R2 original file pins changed")
    outer = base.read_json(R2_OUTER)
    job_id = "1a1ae86be38-fc05-6012"
    require(outer["schema"] == "hepta.rea.c25.owned-apk-r2.outer-receipt.v1"
            and outer["host"] == "desktop" and outer["job_id"] == job_id
            and outer["launch"]["job"]["id"] == job_id and outer["launch"]["reused"] is False,
            "R2 original outer launch identity changed")
    status = outer["final_status"]
    complete_status(status, job_id, "failed", 1)
    require(status["automatic_retry"] is False and status["timed_out"] is False
            and status["cancelled"] is False, "R2 did not finish in the diagnosed ordinary failure")
    logs = verify_pages(outer["original_read_pages"], status, job_id, terminal_pages=False)
    lines = [json.loads(line) for line in logs["stdout"].splitlines()]
    require(len(lines) == 3 and lines[0]["stage6_r2_prelaunch_sha_guard"] == "passed"
            and lines[1]["r1_five_stage_consumer"] == "passed"
            and lines[-1]["stage6_r2"] == "failed" and lines[-1]["finite_provider_checks_qualified"] is False
            and lines[-1]["summary"]["sha256"] == R2_SUMMARY_SHA,
            "R2 complete original output does not bind the diagnosed failure")
    summary = base.read_json(R2_ROOT / "summary.json")
    require(summary["schema"] == "hepta.rea.c25.stage6-r2-bound-run.v1"
            and summary["source_commit"] == base.COMMIT and summary["source_git_tree"] == base.GIT_TREE
            and summary["status"] == "failed" and summary["qualified"] is False
            and summary["finite_provider_checks_qualified"] is False
            and summary["runtime"]["sha256"] == expected_binary
            and summary["passed_stages_rerun"] is False and summary["original_r1_red_reclassified"] is False
            and all(summary.get(key) is True for key in INTEGRITY_KEYS),
            "R2 original failure/source integrity changed")
    require(base.read_json(R2_ROOT / "source-before.json") == base.read_json(R2_ROOT / "source-after.json") == expected_source
            and base.read_json(R2_ROOT / "source-events.json") == EMPTY_MONITOR,
            "R2 source snapshot/monitor does not bind c25")
    workspace = R2_ROOT / "workspace"
    path = workspace / "qualification.json"
    require(base.reference(path)["sha256"] == R2_FAILURE_SHA, "R2 original helper failure report changed")
    report = base.read_json(path)
    require(report["status"] == "failed" and report["qualified"] is False
            and report["runtime_sha256"] == expected_binary and report["closure_unchanged_after_failure"] is True
            and report["checks"] == ["frozen_source_binary_and_configured_installation_closure_bound"]
            and report["failure"] == {"type": "RuntimeError", "message": "actual AAPT2 version output is absent or unexpected"},
            "R2 failure was not the diagnosed version observation defect")
    commands = report["commands"]
    require(len(commands) == 2 and [row["name"] for row in commands] == ["source-commit-tree", "aapt2-version"]
            and [row["timeout_seconds"] for row in commands] == [15, 15], "R2 executed an unexpected operation")
    for command in commands:
        require(command["exit_code"] == 0 and command["wait_reaped"] is True
                and command["output_complete"] is True and command["timed_out"] is False
                and command["manual_cleanup"] == [] and command["launch_error"] is None
                and command["stdin"]["bytes"] == command["stdin"]["written_bytes"] == 0,
                "R2 original preparation child terminal incomplete")
        for stream in ("stdout", "stderr"):
            log = command["logs"][stream]
            verify_reference(log, workspace)
            require(log["eof"] is True and log["truncated"] is False
                    and log["seen"] == log["stored"] == log["bytes"], "R2 preparation child log incomplete")
        require(base.read_json(verify_reference(command["receipt"], workspace))
                == {key: value for key, value in command.items() if key != "receipt"},
                "R2 original child receipt differs")
    version = commands[1]
    require(version["argv"] == [str(base.SDK / "build-tools/35.0.1/aapt2"), "version"]
            and Path(version["logs"]["stdout"]["path"]).read_bytes() == b""
            and Path(version["logs"]["stderr"]["path"]).read_bytes() == AAPT_VERSION_BYTES,
            "R2 actual exact version channel evidence differs")
    before = base.read_json(verify_reference(report["inputs_before"], workspace))
    after = base.read_json(verify_reference(report["inputs_after_failure"], workspace))
    require(before == after and before["helper"]["sha256"] == R2_HELPER_SHA
            and before["binary"]["sha256"] == expected_binary, "R2 input closure changed")
    process = base.read_json(R2_ROOT / "process.json")
    require(process == summary["process"] and process["returncode"] == 1
            and process["timed_out"] is False and process["cleanup_actions"] == []
            and process["automatic_retry"] is False, "R2 failed helper process terminal differs")
    for stream in ("stdout", "stderr"):
        verify_reference(process[stream], R2_ROOT)
    verify_reference(summary["r1_consumed"], R2_ROOT)
    artifact_path = verify_reference(summary["artifacts"], R2_ROOT)
    original_inventory = base.read_json(artifact_path)
    current_inventory = base.artifact_inventory(R2_ROOT)
    # R2 intentionally wrote its final summary after inventory publication.
    # Pin that final summary separately; compare every other original artifact.
    exclusions = {str(artifact_path), str(R2_ROOT / "summary.json")}
    old_files = [row for row in original_inventory["files"] if row["path"] not in exclusions]
    new_files = [row for row in current_inventory["files"] if row["path"] not in exclusions]
    require(old_files == new_files and len(old_files) > 10, "R2 original artifact closure changed")
    return {"summary": base.reference(R2_ROOT / "summary.json"), "outer": base.reference(R2_OUTER),
            "helper_failure": base.reference(path), "actual_original_children": 2,
            "actual_passed_checks": 1, "ordinary_child_exits": [0, 0],
            "aapt2_actual_stderr": version["logs"]["stderr"],
            "aapt2_actual_stdout": version["logs"]["stdout"],
            "full_original_artifacts_revalidated_except_separately_pinned_final_summary": len(old_files),
            "original_red_preserved": True, "generated_apk_behavior_exercised": False}


def validate_generated(workspace, expected_binary, expected_checks):
    path = workspace / "qualification.json"
    report = base.read_json(path)
    require(report.get("schema") == "hepta.rea.owned-aapt2-apk-two-workers.v1"
            and report.get("status") == "passed" and report.get("qualified") is True
            and report["runtime_sha256"] == expected_binary
            and report["expected_binary_sha256"] == expected_binary
            and report["source_commit"] == base.COMMIT and report["source_git_tree"] == base.GIT_TREE
            and report["checks"] == report["expected_check_names"] == expected_checks,
            "R3 generated APK report or exact check contract differs")
    commands = report["commands"]
    require(len(commands) == report["expected_original_command_count"] == 14
            and [row["name"] for row in commands] == COMMAND_NAMES
            and [row["timeout_seconds"] for row in commands] == COMMAND_BUDGETS,
            "R3 original child membership/order/budgets differ")
    for command in commands:
        refusal = command["name"] in {"apksigner-verify-tampered", "worker-native-truncated"}
        require(type(command["exit_code"]) is int
                and (command["exit_code"] > 0 if refusal else command["exit_code"] == 0)
                and command["wait_reaped"] is True and command["output_complete"] is True
                and command["timed_out"] is False and command["manual_cleanup"] == []
                and command["launch_error"] is None
                and command["stdin"]["bytes"] == command["stdin"]["written_bytes"],
                "R3 original command terminal/custody is incomplete")
        if command["name"].startswith("worker-"):
            require(command["environment"] == {} and command["cwd"] == "/"
                    and command["argv"][0] == str(base.BINARY), "R3 worker environment/binary boundary changed")
            source = Path(command["stdin"]["source"])
            require(source.is_relative_to(workspace), "R3 worker input escaped workspace")
            ref = base.reference(source)
            require(ref["bytes"] == command["stdin"]["bytes"] and ref["sha256"] == command["stdin"]["sha256"],
                    "R3 actual worker stdin differs from retained original input")
        for stream in ("stdout", "stderr"):
            log = command["logs"][stream]
            verify_reference(log, workspace)
            require(log["eof"] is True and log["truncated"] is False
                    and log["seen"] == log["stored"] == log["bytes"], "R3 child logs incomplete")
        receipt = base.read_json(verify_reference(command["receipt"], workspace))
        require(receipt == {key: value for key, value in command.items() if key != "receipt"},
                "R3 immutable original command receipt differs from report")
    version = commands[1]
    require(Path(version["logs"]["stdout"]["path"]).read_bytes()
            + Path(version["logs"]["stderr"]["path"]).read_bytes() == AAPT_VERSION_BYTES
            and report["actual_aapt2_version"] == AAPT_VERSION_BYTES.decode().strip(),
            "R3 exact pinned AAPT2 version bytes were not independently confirmed")
    before = base.read_json(verify_reference(report["inputs_before"], workspace))
    after = base.read_json(verify_reference(report["inputs_after"], workspace))
    require(before == after and before["helper"]["sha256"] == HELPER_SHA
            and before["binary"]["sha256"] == expected_binary, "R3 configured input closure changed")
    jdk = before["jdk_installation_tree"]
    require(jdk["root"] == str(base.JDK21) and jdk["entry_count"] == len(jdk["entries"])
            and len(jdk["entries"]) >= 214
            and jdk["inventory_sha256"] == hashlib.sha256(
                (json.dumps(jdk["entries"], indent=2, sort_keys=True, ensure_ascii=True, allow_nan=False) + "\n").encode()).hexdigest(),
            "R3 complete JDK inventory is empty, malformed or not bound")
    require(len(jdk["observed_absent"]) == 1
            and jdk["observed_absent"][0]["path"] == MISSING
            and jdk["observed_absent"][0]["state"] == "observed_absent"
            and not os.path.lexists(MISSING), "R3 explicit absent-library observation differs")
    source_links = [row for row in jdk["entries"] if row["relative"] == "lib/src.zip"]
    require(len(source_links) == 1 and source_links[0]["target_state"] == "observed_absent",
            "R3 diagnosed optional source link was silently omitted")
    for row in jdk["entries"]:
        if row["kind"] == "regular":
            verify_reference(row["identity"])
        elif row["kind"] == "symlink":
            target = Path(row["path"])
            require(target.is_symlink() and os.readlink(target) == row["target"]
                    and str(target.resolve(strict=False)) == row["resolved"], "R3 JDK symlink identity changed")
            if row["target_state"] == "regular":
                verify_reference(row["target_identity"])
    for key in ("full_android_verification", "rea_evidence_compatibility", "rea_full_parity",
                "production_qualified", "devices_contacted", "apk_payloads_executed"):
        require(report[key] is False, "R3 expanded qualification scope: " + key)
    require(report["output_inventory"]["maximum_bytes_exclusive"] == 64 * base.MIB
            and report["output_inventory"]["total_bytes"] < 64 * base.MIB - base.MIB,
            "R3 output budget changed")
    verify_reference(report["generated_inputs"], workspace)
    return {"report": base.reference(path), "checks": 14, "original_child_terminals": 14,
            "ordinary_positive_exits": 12, "actual_refusal_exits": 2,
            "worker_environment_empty": True, "original_budgets_unchanged": True,
            "jdk_entry_count": jdk["entry_count"], "jdk_inventory_sha256": jdk["inventory_sha256"],
            "jdk_observed_absent": jdk["observed_absent"], "output_bytes": report["output_inventory"]["total_bytes"]}

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--execute", action="store_true")
    parser.add_argument("--expected-binding-sha256", required=True)
    parser.add_argument("--expected-binary-sha256", required=True)
    args = parser.parse_args()
    require(args.execute and base.SHA.fullmatch(args.expected_binding_sha256)
            and base.SHA.fullmatch(args.expected_binary_sha256), "explicit execution and full expected hashes required")
    os.umask(0o077)
    os.environ["PYTHONDONTWRITEBYTECODE"] = "1"
    RUN.mkdir(mode=0o700, exist_ok=False)
    record = {"schema": "hepta.rea.c25.stage6-r3-bound-run.v1", "status": "running",
              "finite_provider_checks_qualified": False, "qualified": False,
              "outer_terminal_required_for_composition": True, "automatic_retry": False,
              "new_execution_after_diagnosed_preparation_fix": True, "source_commit": base.COMMIT,
              "source_git_tree": base.GIT_TREE, "started_at": base.now(),
              "passed_stages_rerun": False, "original_r1_red_reclassified": False,
              "original_r2_red_reclassified": False,
              "rea_full_parity": False, "production_qualified": False,
              "native_gdb_lldb_adapter_qualified": False}
    base.save(RUN / "summary.json", record)
    selection = monitor = before = None
    consumed = None
    try:
        record["wrapper"] = base.reference(Path(__file__).resolve())
        record["base_driver"] = base.reference(BASE_PATH)
        record["helper_scope"] = helper_scope()
        record["git_before"] = base.git_identity()
        record["host_before"] = base.host_identity()
        base.save(RUN / "source-script-pins.json", base.pinned_sources())
        sys.path.insert(0, str(base.REPO / "scripts"))
        matrix = importlib.import_module("rea_full_qualification")
        consumer = importlib.import_module("rea_build_evidence")
        selection = matrix.Selection(base.REPO, base.TARGET, base.MATRIX)
        monitor = matrix.SourceMonitor(selection)
        monitor.start()
        before = selection.snapshot()
        base.save(RUN / "source-before.json", before)
        binding, validation = base.validate_binding(args, selection, consumer)
        record["binding"] = base.reference(base.BINDING)
        record["runtime"] = base.reference(base.BINARY)
        base.save(RUN / "binding-consumer-recomputed.json", validation)
        consumed = consume_r1(args.expected_binary_sha256, before)
        base.save(RUN / "r1-consumer-before.json", consumed)
        record["r1_consumed"] = base.reference(RUN / "r1-consumer-before.json")
        r2_consumed = consume_r2_red(args.expected_binary_sha256, before)
        base.save(RUN / "r2-consumer-before.json", r2_consumed)
        record["r2_consumed"] = base.reference(RUN / "r2-consumer-before.json")
        record["disk_before"] = base.check_disk(128 * base.MIB)
        stage = {"name": "apk-generated-r3", "kind": "generated",
                 "directory": str(RUN), "cwd": str(RUN), "timeout_seconds": 300,
                 "argv": [str(Path(sys.executable).resolve()), "-B", str(HELPER),
                          "--binary", str(base.BINARY), "--expected-binary-sha256",
                          args.expected_binary_sha256, "--output", str(RUN / "workspace")]}
        base.save(RUN / "plan.json", stage)
        env = dict(os.environ, PYTHONDONTWRITEBYTECODE="1", PYTHONNOUSERSITE="1", LC_ALL="C",
                   PATH=str(base.JDK21 / "bin") + ":/usr/bin:/bin", JAVA_HOME=str(base.JDK21),
                   TMPDIR=str(RUN / "tmp"))
        for key in ("PYTHONPATH", "PYTHONHOME", "LD_PRELOAD", "LD_LIBRARY_PATH", "NODE_OPTIONS", "NODE_PATH",
                    "JAVA_TOOL_OPTIONS", "JDK_JAVA_OPTIONS", "_JAVA_OPTIONS"):
            env.pop(key, None)
        Path(env["TMPDIR"]).mkdir(mode=0o700)
        record["selected_environment"] = {key: env.get(key) for key in
            ("PATH", "JAVA_HOME", "LC_ALL", "PYTHONDONTWRITEBYTECODE", "PYTHONNOUSERSITE", "TMPDIR")}
        base.save(RUN / "summary.json", record)
        print(json.dumps({"r1_five_stage_consumer": "passed", "original_r1_red_preserved": True,
                          "original_r2_two_command_red_consumer": "passed", "new_stage6_only": True}), flush=True)
        record["process"] = base.run_process(stage, env)
        record["stage6"] = validate_generated(RUN / "workspace", args.expected_binary_sha256,
                                               record["helper_scope"]["checks"])
        after_consumed = consume_r1(args.expected_binary_sha256, before)
        base.save(RUN / "r1-consumer-after.json", after_consumed)
        require(after_consumed == consumed, "R1 positive receipts or original RED changed during R3")
        record["r1_evidence_unchanged"] = True
        r2_after = consume_r2_red(args.expected_binary_sha256, before)
        base.save(RUN / "r2-consumer-after.json", r2_after)
        require(r2_after == r2_consumed, "R2 original preparation RED changed during R3")
        record["r2_evidence_unchanged"] = True
        record["status"] = "passed"
    except BaseException as error:
        record["status"] = "failed"
        record["failure"] = {"type": type(error).__name__, "message": str(error)}
        if (RUN / "process.json").exists():
            record["process"] = base.read_json(RUN / "process.json")
        raise
    finally:
        errors = []
        try:
            if selection is not None:
                after = selection.snapshot()
                base.save(RUN / "source-after.json", after)
                record["source_bytes_unchanged"] = before == after
        except BaseException as error:
            errors.append({"step": "source-after", "message": str(error)})
        finally:
            if monitor is not None:
                try:
                    events = monitor.stop()
                    base.save(RUN / "source-events.json", events)
                    record["source_monitor_complete"] = events == EMPTY_MONITOR
                except BaseException as error:
                    errors.append({"step": "source-monitor", "message": str(error)})
        try:
            record["git_after"] = base.git_identity()
            record["source_git_unchanged"] = record.get("git_before") == record["git_after"]
            record["host_after"] = base.host_identity()
            record["host_unchanged"] = record.get("host_before") == record["host_after"]
            record["binding_unchanged"] = base.reference(base.BINDING)["sha256"] == args.expected_binding_sha256
            record["runtime_unchanged"] = base.reference(base.BINARY)["sha256"] == args.expected_binary_sha256
            record["driver_unchanged"] = record.get("wrapper") == base.reference(Path(__file__).resolve())
            record["helper_unchanged"] = base.reference(HELPER)["sha256"] == HELPER_SHA
            record["r1_summary_still_failed"] = base.reference(R1 / "summary.json")["sha256"] == R1_SUMMARY_SHA
            record["r1_outer_unchanged"] = base.reference(R1_OUTER)["sha256"] == R1_OUTER_SHA
            record["r1_helper_unchanged"] = base.reference(OLD_HELPER)["sha256"] == OLD_HELPER_SHA
            record["r1_driver_unchanged"] = base.reference(BASE_PATH)["sha256"] == BASE_SHA
            inventory = base.artifact_inventory(RUN)
            excluded = {str(RUN / "summary.json"), str(RUN / "artifacts.json")}
            inventory["files"] = [row for row in inventory["files"] if row["path"] not in excluded]
            inventory["file_count"] = len(inventory["files"])
            inventory["regular_bytes"] = sum(row.get("bytes", 0) for row in inventory["files"])
            inventory["scope"] = "all owned files except self and separately pinned final summary"
            base.save(RUN / "artifacts.json", inventory)
            record["artifacts"] = base.reference(RUN / "artifacts.json")
        except BaseException as error:
            errors.append({"step": "final-identities-or-artifacts", "message": str(error)})
        record["finite_provider_checks_qualified"] = record["status"] == "passed" and not errors and all(
            record.get(key) is True for key in (*INTEGRITY_KEYS, "helper_unchanged", "r1_evidence_unchanged", "r2_evidence_unchanged",
                    "r1_summary_still_failed", "r1_outer_unchanged", "r1_helper_unchanged", "r1_driver_unchanged"))
        if errors:
            record["finalization_errors"] = errors
        if record["status"] == "passed" and not record["finite_provider_checks_qualified"]:
            record["status"] = "invalid"
        record["finished_at"] = base.now()
        base.save(RUN / "summary.json", record)
        print(json.dumps({"stage6_r3": record["status"],
                          "finite_provider_checks_qualified": record["finite_provider_checks_qualified"],
                          "outer_terminal_pending": True, "summary": base.reference(RUN / "summary.json")}), flush=True)
    return 0 if record["finite_provider_checks_qualified"] else 1

if __name__ == "__main__":
    raise SystemExit(main())
