public class OwnedFixture { public static int add(int left, int right) { return left + right; } public String label() { return "HEPTA_OWNED_JADX_FIXTURE"; } }
