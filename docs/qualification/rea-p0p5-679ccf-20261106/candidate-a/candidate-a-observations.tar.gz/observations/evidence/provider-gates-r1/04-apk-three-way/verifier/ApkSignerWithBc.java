import java.security.Security;
import org.bouncycastle.jce.provider.BouncyCastleProvider;
public class ApkSignerWithBc { public static void main(String[] args) throws Exception { Security.addProvider(new BouncyCastleProvider()); com.android.apksigner.ApkSignerTool.main(args); } }
