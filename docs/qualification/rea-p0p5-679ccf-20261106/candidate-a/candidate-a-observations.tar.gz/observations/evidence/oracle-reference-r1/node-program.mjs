
import fs from 'node:fs';
import crypto from 'node:crypto';
const corpus=JSON.parse(fs.readFileSync(process.argv[1],'utf8'));
const rows=corpus.cases.map(c=>{
  const raw=Buffer.from(c.input,'utf8');
  const r={id:c.id,utf8_bytes:raw.length,utf16_code_units:c.input.length,sha256:crypto.createHash('sha256').update(raw).digest('hex')};
  try {r.value=JSON.parse(c.input);r.ok=true;} catch(error) {r.ok=false;r.name=error.name;r.message=error.message;}
  if ('append_to_complete' in c) {
    try {JSON.parse(c.input+c.append_to_complete);r.append_witness_valid=true;}
    catch(error) {r.append_witness_valid=false;r.append_witness_error=error.message;}
  }
  return r;
});
process.stdout.write(JSON.stringify({schema:'hepta.rea.eof-independent-node-observation.v1',node:process.version,cases:rows},null,2)+'\n');
