#!/usr/bin/env python3
"""Execute the existing CI Python regressions once on the frozen candidate."""
from pathlib import Path
import hashlib
import json
import os
import re
import subprocess
import sys
import time

REPO = Path("/home/qian-qi/work/hepta-rea-p0p5-679ccf-20261105")
OUT = Path(str(REPO) + "-evidence")
TARGET = Path(str(REPO) + "-target")
EXPECTED_COMMIT = "c25e4cef0610816bfd1263b69d3dd63e4114aa49"
CONTROL = [
 "tests/runtime_registry_page_tests.py", "tests/test_native_canary_resume.py",
 "tests/chatgpt_v11_layered_read_tests.py", "tests/chatgpt_v11_process_start_concurrency_tests.py",
 "tests/chatgpt_v11_v4_session_binding_tests.py", "tests/runtime_workflow_owner_tests.py",
 "tests/chatgpt_v10_single_v4_effect_tests.py", "tests/chatgpt_v10_stream_custody_tests.py",
 "tests/test_computer_http.py", "tests/full_operator_facade_tests.py",
 "tests/full_operator_cancel_tests.py", "tests/chatgpt_request_identity_tests.py",
 "tests/full_operator_session_recovery_tests.py",
 "deploy/maintenance_20261017/native_rollout_tests.py",
 "deploy/maintenance_20261017/recover_control_channel_tests.py",
]
COMMANDS = [
 ["tests/file_capabilities.py"],
 ["-m", "unittest", "discover", "-s", "tests", "-p", "rea_*tests.py", "-v"],
] + [[path] for path in CONTROL] + [
 ["-m", "unittest", "discover", "-s", "tools/x230/" + day, "-p", "*_tests.py", "-v"]
 for day in ("20261028", "20261029", "20261030")
]

def identity(path):
    raw = path.read_bytes()
    return {"path":str(path), "bytes":len(raw), "sha256":hashlib.sha256(raw).hexdigest()}

def git(*args):
    return subprocess.check_output(["git", "-C", str(REPO), *args], text=True).strip()

def save(path, value):
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + "\n")

def main():
    assert git("rev-parse","HEAD") == EXPECTED_COMMIT
    assert not git("status","--porcelain=v1")
    target = OUT/"python-regression-r1"
    target.mkdir()
    sys.path.insert(0, str(REPO/"scripts"))
    from rea_full_qualification import Selection, SourceMonitor
    selection = Selection(REPO, TARGET, OUT/"matrix-r1")
    monitor = SourceMonitor(selection)
    monitor.start()
    before = selection.snapshot()
    save(target/"source-before.json",before)
    env = os.environ.copy()
    env["PYTHONDONTWRITEBYTECODE"] = "1"
    temporary = target/"tmp"
    temporary.mkdir(mode=0o700)
    env["TMPDIR"] = str(temporary)
    report = {
        "schema":"hepta.rea.ci-python-regression.v1",
        "source_commit":EXPECTED_COMMIT,
        "source_tree":git("rev-parse","HEAD^{tree}"),
        "runtime_executed":False,
        "evidence_scope":"Python source regressions on the frozen commit; no candidate runtime or Cargo execution",
        "ci_source":identity(REPO/".github/workflows/ci.yml"),
        "selection":"Existing CI Python commands, deduplicating explicit ledger/browser tests already selected by rea_*tests.py discovery",
        "expected_command_count":20, "stages":[], "status":"running",
        "production_qualified":False, "rea_full_parity":False,
    }
    assert len(COMMANDS) == 20
    save(target/"summary.json",report)
    try:
        for index, suffix in enumerate(COMMANDS,1):
            cmd=["/usr/bin/python3","-B",*suffix]
            stdout=target/(f"{index:02d}.stdout.log")
            stderr=target/(f"{index:02d}.stderr.log")
            started=time.time()
            with stdout.open("xb") as out,stderr.open("xb") as err:
                run=subprocess.run(cmd,cwd=REPO,env=env,stdout=out,stderr=err,
                                   timeout=900,check=False,umask=0o022)
            raw=stderr.read_text()
            summaries=re.findall(r"^Ran (\d+) tests? in ([0-9.]+)s$",raw,re.M)
            statuses=re.findall(r"^(OK(?: \([^\n]*\))?|FAILED(?: \([^\n]*\))?)$",raw,re.M)
            plain_success=run.returncode==0 and len(summaries)==1 and int(summaries[0][0])>0 and statuses==["OK"]
            row={"index":index,"command":cmd,"exit_code":run.returncode,
                 "elapsed_seconds":time.time()-started,"stdout":identity(stdout),"stderr":identity(stderr),
                 "unittest_summaries":summaries,"unittest_statuses":statuses,
                 "plain_ok_without_skips_or_expected_failures":plain_success}
            report["stages"].append(row)
            save(target/"summary.json",report)
            print(json.dumps(row),flush=True)
    finally:
        after=selection.snapshot()
        events=monitor.stop()
        save(target/"source-after.json",after)
        save(target/"source-events.json",events)
        report["source_unchanged"] = before==after and events.get("event_count")==0 and not events.get("errors") and git("rev-parse","HEAD")==EXPECTED_COMMIT and not git("status","--porcelain=v1")
        report["complete"] = len(report["stages"]) == len(COMMANDS)
        report["all_plain_ok"] = report["complete"] and all(x["plain_ok_without_skips_or_expected_failures"] for x in report["stages"])
        report["total_top_level_tests"] = sum(int(x["unittest_summaries"][0][0]) for x in report["stages"] if len(x["unittest_summaries"])==1)
        report["status"] = "passed" if report["all_plain_ok"] and report["source_unchanged"] else "failed"
        save(target/"summary.json",report)
    return 0 if report["status"]=="passed" else 1

if __name__ == "__main__":
    raise SystemExit(main())
