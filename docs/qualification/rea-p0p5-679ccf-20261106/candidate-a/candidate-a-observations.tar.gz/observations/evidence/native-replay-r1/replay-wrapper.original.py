#!/usr/bin/env python3
"""Replay the fixed 116-case corpus after consuming the c25e4cef build binding.

Exit 0: complete parsed-content AND Evidence match. Exit 1: complete finite
comparison with differences. Exit 2: incomplete/unbound evidence. Full response
object and raw-frame equality are independent reported layers, never implied by
the parsed-content gate. No P5 cost or production qualification is asserted.
"""
from __future__ import annotations
import argparse
import hashlib
import importlib.util
import json
from pathlib import Path
import re
import subprocess
import sys
import time
import traceback

sys.dont_write_bytecode = True
REPO = Path('/home/qian-qi/work/hepta-rea-p0p5-679ccf-20261105')
EVIDENCE = Path(str(REPO)+'-evidence')
TARGET = Path(str(REPO)+'-target')
MATRIX = EVIDENCE/'matrix-r1'
REFERENCE = EVIDENCE/'oracle-reference-r1'
LEGACY_ROOT = Path('/home/qian-qi/work/hepta-rea-json-eof-173861-20261105-evidence')
LEGACY_REFERENCE = LEGACY_ROOT/'oracle-reference-r4'
LEGACY_NATIVE = LEGACY_ROOT/'oracle-native-r2'
COMMIT = 'c25e4cef0610816bfd1263b69d3dd63e4114aa49'
TREE = 'c6db025f5902570bd63520751cf84c57505eb6f4'
LEGACY_COMMIT = 'c759624715f24d5c7f09d66df34a77043a6950b2'
REFERENCE_SHA = '797b320f3b9d7dec1b1677892531689469dbdf11ad12003482fa6195bf7f03b2'
LEGACY_REFERENCE_SHA = '6f69a69374f6e748a52aa378c0c68550fd63b0c6361c4484ea646b340d10f4a3'
LEGACY_NATIVE_SHA = '13f4acb62925d194ad13d3f98d2ef62013dd614283f72fcfe81503cba01cc9c5'
NODE_OBSERVATIONS_SHA = '8e6528511e3fdf42b9ed8829699003b79c4fab12a7eb2579adcda583c908f110'
CORPUS_SHA = '289d512884e2ee47fa784ad6f70d76813da1e2f54b84a9b35522320b63f0b4fb'
COLLECTOR_SHA = 'a50826baf7d3fa6cc0634befff43fbb9faadff8574c2e99506068905fd2c6f99'
MATRIX_PRODUCER_SHA = '8a6594e1e146d5f841539c125a83c6aed88e175586f2ecf81d022da43bd8a0ed'
CONSUMER_SHA = '02cfb97960e075a954bc57b5b0ee8f6fbfdf511c754cc6512717920872f3a4ed'
NODE_SHA = '94efd062ed066c1a0b332e18249859c905e920eeada5df55d24c99b919629a90'
PACKAGE_SHA = '8d542ec76a9cb350584b60a6c9c088706ff812d5bb5b094c20c95b6dc25698bb'
OWN_FILES_SHA = '7f06a93473f1f74139d710545850ebab47e2bc026909113b7d010740e922e4e0'
DENOMINATOR = 116


def require(condition, message):
    if not condition:
        raise ValueError(message)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def identity(path, raw=None):
    if raw is None:
        raw = read(path)
    return dict(path=str(path), bytes=len(raw), sha256=sha(raw))


def read(path):
    # Same trusted-host endpoint boundary as the collector. The matrix consumer
    # separately verifies its fixed sibling paths without following links.
    import stat
    before = path.lstat()
    require(stat.S_ISREG(before.st_mode) and before.st_nlink == 1, 'not a single-link regular file: '+str(path))
    raw = path.read_bytes()
    after = path.lstat()
    keys = ('st_dev', 'st_ino', 'st_mode', 'st_size', 'st_mtime_ns', 'st_ctime_ns')
    require(all(getattr(before, key) == getattr(after, key) for key in keys), 'changed read: '+str(path))
    return raw


def pinned(path, digest):
    raw = read(path)
    require(sha(raw) == digest, 'pinned identity mismatch: '+str(path))
    return raw


def save(path, value):
    raw = (json.dumps(value, sort_keys=True, indent=2, ensure_ascii=True, allow_nan=False)+'\n').encode()
    with path.open('xb') as stream:
        stream.write(raw)
    return identity(path, raw)


def copy(path, raw):
    with path.open('xb') as stream:
        stream.write(raw)
    return identity(path, raw)


def load_module(name, path, digest):
    pinned(path, digest)
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def git_identity():
    def git(*args):
        return subprocess.check_output(['git', '-C', str(REPO), *args], text=True).strip()
    result = dict(commit=git('rev-parse', 'HEAD'), tree=git('rev-parse', 'HEAD^{tree}'),
                  status=git('status', '--porcelain=v1', '--untracked-files=all'))
    require(result == dict(commit=COMMIT, tree=TREE, status=''), 'candidate commit/tree/clean differs')
    return result


def check_receipt_close(report):
    close = report.get('close', {})
    require(close.get('returncode') == 0 and close.get('forced_cleanup') == []
            and close.get('reader_stopped') is True and close.get('stdout_eof') is True
            and close.get('owner_pidfd_exited') is True and close.get('process_group_gone') is True
            and close.get('cleanup_errors') == [] and close.get('trailing_protocol_errors') == []
            and close.get('capture_truncated') is False and close.get('managed_resources_closed') is True,
            'collector did not close normally with complete capture')


def load_report(directory, expected_sha, mode, collector):
    raw = pinned(directory/'observation.json', expected_sha)
    report = json.loads(raw)
    require(report.get('schema') == 'hepta.rea.eof-independent-public-observation.v1'
            and report.get('runner_revision') == 5 and report.get('mode') == mode
            and report.get('denominator') == DENOMINATOR and report.get('collection_complete') is True
            and report.get('errors') == [] and len(report.get('cases', [])) == DENOMINATOR,
            'incomplete or incompatible '+mode+' report')
    check_receipt_close(report)
    require(report['before'] == report['after'], 'reported pre/post endpoint identities differ')
    require(report['before']['runner']['sha256'] == COLLECTOR_SHA, 'report used a different collector')
    pinned(directory/'runner.py', COLLECTOR_SHA)
    corpus_raw = pinned(directory/'corpus.json', CORPUS_SHA)
    corpus = json.loads(corpus_raw)
    ids = [case['id'] for case in corpus['cases']]
    require(corpus['denominator'] == DENOMINATOR and len(set(ids)) == DENOMINATOR
            and [case['id'] for case in report['cases']] == ids, 'corpus/report case set or order differs')
    rows = {}
    for entry, case in zip(report['cases'], corpus['cases'], strict=True):
        case_path = directory/(case['id']+'.json')
        case_raw = read(case_path)
        require(identity(case_path, case_raw) == entry['artifact'], 'per-case artifact changed: '+case['id'])
        row = json.loads(case_raw)
        require(row['id'] == case['id'] and row['group'] == case['group']
                and row['input_identity']['sha256'] == case['input_sha256']
                and row['input_identity']['bytes'] == len(bytes.fromhex(case['input_hex']))
                and row['arguments'] == {'path':row['input_identity']['path']},
                'per-case input identity mismatch: '+case['id'])
        require(row['input_identity']['path'] == str(Path(report['workspace'])/(case['id']+'.json')),
                'per-case workspace binding mismatch')
        wire = bytes.fromhex(row['response_wire_hex'])
        require(wire.endswith(b'\n') and wire.count(b'\n') == 1, 'response wire is not one complete frame')
        require(not collector.diff(collector.strict_frame_json(wire), row['response']), 'raw frame/response mismatch')
        require(not collector.diff(collector.value(row['response']), row['value']), 'parsed-content derivation mismatch')
        require(entry['evidence_unchanged'] == row['evidence_unchanged'], 'Evidence state flag mismatch')
        require(type(row.get('elapsed_ns')) is int and row['elapsed_ns'] >= 0, 'invalid call-only elapsed observation')
        rows[case['id']] = row
    return report, corpus, rows


def load_reference(directory, expected_sha, collector):
    report, corpus, rows = load_report(directory, expected_sha, 'reference', collector)
    before = report['before']
    require(before['node']['sha256'] == NODE_SHA and before['package']['file_count'] == 2398
            and before['package']['own_files_sha256'] == OWN_FILES_SHA
            and before['package']['tarball']['sha256'] == PACKAGE_SHA,
            'reference Node/npm combination differs')
    node_raw = pinned(directory/'node.stdout.json', NODE_OBSERVATIONS_SHA)
    require(identity(directory/'node.stdout.json', node_raw) == report['node_output_identity'],
            'Node observation/report binding differs')
    node = json.loads(node_raw)
    require(node['node'] == 'v22.23.4' and len(node['cases']) == DENOMINATOR, 'Node fixture denominator differs')
    for case, observation in zip(corpus['cases'], node['cases'], strict=True):
        require(case['id'] == observation['id'] and observation['sha256'] == case['input_sha256']
                and observation['utf16_code_units'] == case['utf16_code_units']
                and rows[case['id']]['node_observation'] == observation,
                'Node/corpus/public record binding differs: '+case['id'])
        source = directory/'workspace'/(case['id']+'.json')
        require(read(source) == bytes.fromhex(case['input_hex']), 'reference input bytes changed: '+case['id'])
    return report, corpus, rows


def comparisons(native_report, native_rows, reference_rows, collector):
    require(len(native_report.get('comparisons', [])) == DENOMINATOR, 'native comparison denominator incomplete')
    records = []
    for stored, case in zip(native_report['comparisons'], native_report['cases'], strict=True):
        case_id = case['id']
        old, new = reference_rows[case_id], native_rows[case_id]
        require(old['input_identity'] == new['input_identity'] and old['arguments'] == new['arguments']
                and old['node_observation'] == new['node_observation'], 'native/reference actual input differs')
        parsed = collector.diff(old['value'], new['value'])
        state = collector.diff(old['evidence_after'], new['evidence_after'])
        objects = collector.diff(old['response'], new['response'])
        wire_equal = old['response_wire_hex'] == new['response_wire_hex']
        status = 'PASS' if not parsed and not state else 'FAIL'
        require(stored['id'] == case_id and stored['group'] == new['group'] and stored['status'] == status
                and stored['differences'] == parsed and stored['evidence_differences'] == state
                and stored['unnormalized_object_differences'] == objects
                and stored['unnormalized_object_equal'] == (not objects)
                and stored['raw_frame_bytes_equal'] == wire_equal,
                'collector comparison does not reproduce from raw case artifacts: '+case_id)
        records.append(dict(id=case_id, group=new['group'],
                            original_nine_gap_index=new.get('original_nine_gap_index'),
                            parsed_content_equal=not parsed, evidence_after_equal=not state,
                            parsed_content_and_evidence_equal=not parsed and not state,
                            full_response_object_equal=not objects, raw_frame_bytes_equal=wire_equal,
                            parsed_content_differences=parsed, evidence_after_differences=state,
                            full_response_object_differences=objects))
    counts = dict(denominator=len(records))
    for key in ('parsed_content_equal', 'evidence_after_equal', 'parsed_content_and_evidence_equal',
                'full_response_object_equal', 'raw_frame_bytes_equal'):
        counts[key] = sum(row[key] for row in records)
    require(native_report['counts'] == dict(collected=DENOMINATOR, comparisons=DENOMINATOR,
            exact=counts['parsed_content_and_evidence_equal'],
            different=DENOMINATOR-counts['parsed_content_and_evidence_equal']), 'collector counts mismatch')
    require(native_report['comparison_layers'] == dict(denominator=DENOMINATOR,
            parsed_content_exact=counts['parsed_content_and_evidence_equal'],
            unnormalized_object_exact=counts['full_response_object_equal'],
            raw_frame_bytes_exact=counts['raw_frame_bytes_equal']), 'collector layer summaries mismatch')
    return dict(counts=counts, groups={group:{key:sum(row[key] for row in records if row['group'] == group)
                    for key in counts if key != 'denominator'} | {'denominator':sum(row['group'] == group for row in records)}
                for group in ('eof', 'non-eof-invalid', 'valid-json', 'valid-evidence')}, cases=records)


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--binding-sha256', required=True)
    ap.add_argument('--binary-sha256', required=True)
    ap.add_argument('--output-dir', type=Path, default=EVIDENCE/'native-replay-r1')
    args = ap.parse_args()
    require(all(re.fullmatch(r'[0-9a-f]{64}', value) for value in
                (args.binding_sha256, args.binary_sha256)), 'fixed binding/binary SHA256 required')
    out = args.output_dir
    require(out.is_absolute() and out.parent == EVIDENCE, 'output must be a new direct child of the evidence directory')
    out.mkdir(mode=0o700)
    report = dict(schema='hepta.rea.bound-json-replay.v1', source_commit=COMMIT, source_git_tree=TREE,
                  qualified=False, global_status='HOLD/NO_GO', errors=[],
                  collection_complete=False, parsed_content_gate_passed=False,
                  full_response_object_gate_passed=False, wire_gate_passed=False,
                  comparison_semantics='Recompute collector v5 diff without changing fields: content[0].text is parsed as JSON only in the parsed layer; full-object keeps that original text string; wire compares exact response bytes. Parsed-content gate also requires equal evidence_after. Numeric int/float equality follows the pinned v5 comparator.',
                  started_utc=time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()),
                  cost=dict(current_candidate_cost_qualified=False, conclusion=None,
                            observed_field='elapsed_ns: one monotonic import tools/call measurement per case',
                            exclusions=['MCP startup/initialize', 'before/after Evidence requests', 'input hashing',
                                        'result comparisons', 'cleanup', 'CPU/RSS/I/O end-to-end costs'],
                            reason='Correctness replay has one sample per heterogeneous input, no controlled warmup/repetition schedule, and no whole-operation cost accounting. Historical c759 cost-r1 is a separate older combination and cannot qualify this candidate.'))
    monitor = None
    before = None
    selections = None
    pinned_files = {}
    try:
        report['wrapper'] = identity(Path(__file__).resolve())
        copy(out/'replay-wrapper.original.py', read(Path(__file__).resolve()))
        before = git_identity()
        report['source_before'] = before
        collector_path = REPO/'scripts/rea_json_differential.py'
        producer_path = REPO/'scripts/rea_full_qualification.py'
        consumer_path = REPO/'scripts/rea_build_evidence.py'
        collector = load_module('replay_json_collector', collector_path, COLLECTOR_SHA)
        producer = load_module('replay_matrix_producer', producer_path, MATRIX_PRODUCER_SHA)
        consumer = load_module('replay_build_consumer', consumer_path, CONSUMER_SHA)
        binding_path = EVIDENCE/'binding.json'
        binary_path = EVIDENCE/'hepta-runtime'
        pinned_files = {collector_path:COLLECTOR_SHA, producer_path:MATRIX_PRODUCER_SHA,
                        consumer_path:CONSUMER_SHA, binding_path:args.binding_sha256,
                        binary_path:args.binary_sha256,
                        REFERENCE/'observation.json':REFERENCE_SHA,
                        REFERENCE/'node.stdout.json':NODE_OBSERVATIONS_SHA,
                        LEGACY_REFERENCE/'observation.json':LEGACY_REFERENCE_SHA,
                        LEGACY_NATIVE/'observation.json':LEGACY_NATIVE_SHA}
        binding_raw = pinned(binding_path, args.binding_sha256)
        binding = consumer.parse_json(binding_raw)
        runtime = identity(binary_path, pinned(binary_path, args.binary_sha256))
        require(binding['schema'] == 'hepta.rea.p0p5.build-binding.v1'
                and binding['source_commit'] == COMMIT and binding['source_git_tree'] == TREE
                and binding['runtime'] == runtime, 'binding candidate/source/runtime mismatch')
        build_raw = read(MATRIX/'summary.json')
        require(binding['build_summary'] == identity(MATRIX/'summary.json', build_raw), 'binding build-summary mismatch')
        selections = producer.Selection(REPO, TARGET, MATRIX)
        monitor = producer.SourceMonitor(selections)
        monitor.start()
        snapshot = selections.snapshot()
        report['source_snapshot_before'] = save(out/'source-before.json', snapshot)
        validation = consumer.validate_matrix(build_raw, lambda name:consumer.read_regular(MATRIX, name), snapshot, runtime)
        require(validation == binding['independent_consumer'], 'independent build-consumer result differs from binding')
        report['build_validation'] = validation
        report['binding'] = copy(out/'build-binding.original.json', binding_raw)
        report['runtime'] = runtime
        report['collector_snapshot'] = copy(out/'collector.original.py', pinned(collector_path, COLLECTOR_SHA))
        current_reference, corpus, reference_rows = load_reference(REFERENCE, REFERENCE_SHA, collector)
        legacy_reference, old_corpus, legacy_reference_rows = load_reference(LEGACY_REFERENCE, LEGACY_REFERENCE_SHA, collector)
        require(corpus == old_corpus, 'old/current corpus differs')
        legacy, _, legacy_rows = load_report(LEGACY_NATIVE, LEGACY_NATIVE_SHA, 'native', collector)
        require(legacy['before']['source']['commit'] == LEGACY_COMMIT
                and legacy['before']['source']['clean'] is True
                and legacy['before']['source']['status'] == ''
                and legacy['before']['reference_report'] == identity(LEGACY_REFERENCE/'observation.json'),
                'legacy c759/reference association differs')
        report['baseline'] = comparisons(legacy, legacy_rows, legacy_reference_rows, collector)
        report['baseline']['observation'] = identity(LEGACY_NATIVE/'observation.json')
        report['baseline']['source'] = legacy['before']['source']
        report['baseline']['runtime'] = legacy['before']['binary']
        require(report['baseline']['counts']['parsed_content_and_evidence_equal'] == 101
                and report['baseline']['counts']['full_response_object_equal'] == 1
                and report['baseline']['counts']['raw_frame_bytes_equal'] == 0, 'frozen c759 baseline counts differ')
        # Preserve raw cross-reference differences. Only report whether differing
        # leaves are the exact per-case absolute request path; never normalize a
        # replay comparison or relabel those raw original values as identical.
        reference_deltas = []
        for case in corpus['cases']:
            case_id = case['id']
            old, new = legacy_reference_rows[case_id], reference_rows[case_id]
            delta = collector.diff(old['value'], new['value'])
            state_delta = collector.diff(old['evidence_after'], new['evidence_after'])
            path_only = all(row.get('reference') == old['input_identity']['path']
                            and row.get('native') == new['input_identity']['path'] for row in delta)
            reference_deltas.append(dict(id=case_id, raw_parsed_content_differences=delta,
                                         evidence_after_differences=state_delta,
                                         only_exact_request_path_differences=path_only and not state_delta))
        report['reference_cohorts'] = dict(current=identity(REFERENCE/'observation.json'),
            baseline=identity(LEGACY_REFERENCE/'observation.json'), node_observations_sha256=NODE_OBSERVATIONS_SHA,
            corpus_sha256=CORPUS_SHA, same_corpus_and_node_bytes=True,
            only_exact_request_path_differences=all(row['only_exact_request_path_differences'] for row in reference_deltas),
            cases=reference_deltas)
        require(report['reference_cohorts']['only_exact_request_path_differences'],
                'original reference cohorts differ beyond their exact per-case input path')
        command = [sys.executable, '-B', str(out/'collector.original.py'), 'native',
            '--output-dir', str(out/'native'), '--reference-dir', str(REFERENCE),
            '--reference-report-sha256', REFERENCE_SHA, '--node-observations-sha256', NODE_OBSERVATIONS_SHA,
            '--binary', str(binary_path), '--binary-sha256', args.binary_sha256,
            '--repo', str(REPO), '--source-commit', COMMIT,
            '--build-binding', str(binding_path), '--build-binding-sha256', args.binding_sha256]
        save(out/'launch-plan.json', dict(argv=command, cwd=str(REPO)))
        started = time.monotonic_ns()
        with (out/'collector.stdout.log').open('xb') as stdout, (out/'collector.stderr.log').open('xb') as stderr:
            completed = subprocess.run(command, cwd=REPO, stdout=stdout, stderr=stderr, check=False)
        report['collector_process'] = dict(returncode=completed.returncode,
            elapsed_ns_observation_only=time.monotonic_ns()-started,
            stdout=identity(out/'collector.stdout.log'), stderr=identity(out/'collector.stderr.log'))
        require(completed.returncode == 0, 'collector incomplete; raw logs retained')
        native_identity = identity(out/'native/observation.json')
        native, _, native_rows = load_report(out/'native', native_identity['sha256'], 'native', collector)
        require(native['before']['reference_report'] == identity(REFERENCE/'observation.json')
                and native['before']['binary'] == runtime and native['before']['binding'] == identity(binding_path)
                and native['before']['source']['commit'] == COMMIT and native['before']['source']['clean'] is True,
                'candidate collector association differs')
        report['candidate'] = comparisons(native, native_rows, reference_rows, collector)
        report['candidate']['observation'] = native_identity
        report['transitions'] = []
        for old, new in zip(report['baseline']['cases'], report['candidate']['cases'], strict=True):
            require(old['id'] == new['id'], 'baseline/candidate comparison order differs')
            report['transitions'].append(dict(id=new['id'], group=new['group'],
                baseline_parsed_and_evidence_equal=old['parsed_content_and_evidence_equal'],
                candidate_parsed_and_evidence_equal=new['parsed_content_and_evidence_equal'],
                repaired=not old['parsed_content_and_evidence_equal'] and new['parsed_content_and_evidence_equal'],
                regressed=old['parsed_content_and_evidence_equal'] and not new['parsed_content_and_evidence_equal']))
        report['collection_complete'] = True
        report['parsed_content_gate_passed'] = report['candidate']['counts']['parsed_content_and_evidence_equal'] == DENOMINATOR
        report['full_response_object_gate_passed'] = report['candidate']['counts']['full_response_object_equal'] == DENOMINATOR
        report['wire_gate_passed'] = report['candidate']['counts']['raw_frame_bytes_equal'] == DENOMINATOR
    except BaseException as error:
        report['errors'].append(dict(type=type(error).__name__, message=str(error), traceback=traceback.format_exc()))
    finally:
        try:
            report['source_after'] = git_identity()
            require(before is None or report['source_after'] == before, 'source endpoints differ')
            if selections is not None:
                after_snapshot = selections.snapshot()
                report['source_snapshot_after'] = save(out/'source-after.json', after_snapshot)
                require('source_snapshot_before' in report and after_snapshot == snapshot, 'source content snapshot changed')
            for path, digest in pinned_files.items():
                pinned(path, digest)
        except BaseException as error:
            report['errors'].append(dict(phase='postflight', type=type(error).__name__, message=str(error)))
        if monitor is not None:
            try:
                events = monitor.stop()
                report['source_events'] = save(out/'source-events.json', events)
                require(events == dict(event_count=0, retained_events=[], events_truncated=False, errors=[]),
                        'source monitor detected changes or lost coverage')
            except BaseException as error:
                report['errors'].append(dict(phase='source-monitor', type=type(error).__name__, message=str(error)))
    report['evidence_valid'] = not report['errors'] and report['collection_complete']
    report['finite_status'] = ('INCOMPLETE_OR_UNBOUND' if not report['evidence_valid'] else
                              'PARSED_CONTENT_AND_EVIDENCE_PASS' if report['parsed_content_gate_passed'] else
                              'PARSED_CONTENT_AND_EVIDENCE_DIFFERENCES')
    report['completed_utc'] = time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())
    receipt = save(out/'comparison-summary.json', report)
    print(json.dumps(dict(receipt=receipt, finite_status=report['finite_status'],
        evidence_valid=report['evidence_valid'], parsed_content_gate_passed=report['parsed_content_gate_passed'],
        baseline=report.get('baseline', {}).get('counts'), candidate=report.get('candidate', {}).get('counts'),
        errors=report['errors'], qualified=False, global_status='HOLD/NO_GO')), flush=True)
    return 2 if not report['evidence_valid'] else 0 if report['parsed_content_gate_passed'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
