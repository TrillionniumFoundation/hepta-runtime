#!/usr/bin/env python3
"""Run the two existing import differentials once on the bound c25 candidate.

Run only after the 116-case replay has completed. This observes cold sessions
with explicit import; it does not establish automatic authenticated persistence.
"""
import argparse
import hashlib
import importlib.util
import json
from pathlib import Path
import subprocess
import sys
import time
import traceback

sys.dont_write_bytecode = True
EVIDENCE = Path('/home/qian-qi/work/hepta-rea-p0p5-679ccf-20261105-evidence')
HELPER = EVIDENCE/'replay_bound_candidate.py'
HELPER_SHA = 'cc0b4b41e6c966e548fbbad1697649ff45727d973e8f772642035f45d7c61614'
PACKAGE = Path('/home/qian-qi/work/hepta-rea-reference-recovery-ca464-20261105-r1/install/node_modules/rea-agents')
TARBALL = Path('/home/qian-qi/work/hepta-rea-reference-20261103/pack/rea-agents-6.8.0.tgz')
NODE = Path('/usr/bin/node')
STAGES = [
    ('evidence-import-r1', 'rea_evidence_import_qualification.py',
     'c3036552976cc6d518e492ef56e2db3aa3f913d02cc2f7fccc78fb7a9520723e',
     'hepta.rea.public-import.v1', 118,
     dict(main=68, cold=3, union=4, capture=7, proto=11, exception=8, labels=6, cancel=6)),
    ('evidence-import-overflow-r1', 'rea_evidence_import_overflow.py',
     '4127b3d01b0d1d9800967c0fbd5d1da3f2f1ef0b267142e47e998c1519bc59b4',
     'hepta.rea.public-import-overflow.v1', 22, dict(producer=3, import_=12, cold=4)),
]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--binding-sha256', required=True)
    parser.add_argument('--binary-sha256', required=True)
    parser.add_argument('--json-replay-summary-sha256', required=True)
    args = parser.parse_args()
    raw = HELPER.read_bytes()
    if hashlib.sha256(raw).hexdigest() != HELPER_SHA:
        raise ValueError('fixed binding helper changed')
    spec = importlib.util.spec_from_file_location('bound_import_helper', HELPER)
    r = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = r
    spec.loader.exec_module(r)
    out = EVIDENCE/'import-binding-r1'
    out.mkdir(mode=0o700)
    report = dict(schema='hepta.rea.bound-import-comparisons.v1', qualified=False,
                  global_status='HOLD/NO_GO', source_commit=r.COMMIT, source_git_tree=r.TREE,
                  retries=0, stages=[], errors=[],
                  persistence_scope='Fresh cold sessions and explicit public import. Ordinary import checks cold-empty first; overflow starts another fresh session and explicitly imports the complete exported history. No automatic authenticated restart persistence is established.',
                  comparison_scope='118: 113 response-value/object-order pairs, 3 tool-contract pairs and 2 canonical export byte pairs. 22: 19 response-value/object-order pairs and 3 canonical export byte pairs. These are not raw-wire equality claims.',
                  started_utc=time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()))
    monitor = selection = None
    snapshot = None
    try:
        r.copy(out/'runner.original.py', r.read(Path(__file__).resolve()))
        report['source_before'] = r.git_identity()
        report['node_before'] = r.identity(NODE, r.pinned(NODE, r.NODE_SHA))
        report['tarball_before'] = r.identity(TARBALL, r.pinned(TARBALL, r.PACKAGE_SHA))
        replay_path = EVIDENCE/'native-replay-r1/comparison-summary.json'
        replay_raw = r.pinned(replay_path, args.json_replay_summary_sha256)
        replay = json.loads(replay_raw)
        r.require(replay['evidence_valid'] is True and replay['collection_complete'] is True
                  and replay['source_commit'] == r.COMMIT and replay['source_git_tree'] == r.TREE
                  and replay['runtime']['sha256'] == args.binary_sha256,
                  '116-case replay has not completed on this candidate')
        report['prior_json_replay'] = r.identity(replay_path, replay_raw)
        producer = r.load_module('bound_import_matrix', r.REPO/'scripts/rea_full_qualification.py', r.MATRIX_PRODUCER_SHA)
        consumer = r.load_module('bound_import_consumer', r.REPO/'scripts/rea_build_evidence.py', r.CONSUMER_SHA)
        binding_path = EVIDENCE/'binding.json'
        binary_path = EVIDENCE/'hepta-runtime'
        binding_raw = r.pinned(binding_path, args.binding_sha256)
        binding = consumer.parse_json(binding_raw)
        runtime = r.identity(binary_path, r.pinned(binary_path, args.binary_sha256))
        r.require(binding['schema'] == 'hepta.rea.p0p5.build-binding.v1'
                  and binding['source_commit'] == r.COMMIT and binding['source_git_tree'] == r.TREE
                  and binding['runtime'] == runtime, 'binding/source/binary mismatch')
        report['binding'] = r.copy(out/'build-binding.original.json', binding_raw)
        report['runtime'] = runtime
        selection = producer.Selection(r.REPO, r.TARGET, r.MATRIX)
        monitor = producer.SourceMonitor(selection)
        monitor.start()
        snapshot = selection.snapshot()
        r.save(out/'source-before.json', snapshot)
        build_raw = r.read(r.MATRIX/'summary.json')
        r.require(binding['build_summary'] == r.identity(r.MATRIX/'summary.json', build_raw), 'build-summary binding differs')
        validation = consumer.validate_matrix(build_raw, lambda name:consumer.read_regular(r.MATRIX, name), snapshot, runtime)
        r.require(validation == binding['independent_consumer'], 'independent build-consumer result differs')
        report['build_validation'] = validation
        for name, filename, digest, schema, denominator, scenario_counts in STAGES:
            r.git_identity()
            r.pinned(binding_path, args.binding_sha256)
            r.pinned(binary_path, args.binary_sha256)
            r.pinned(NODE, r.NODE_SHA)
            r.pinned(TARBALL, r.PACKAGE_SHA)
            r.require(selection.snapshot() == snapshot, 'source changed before '+name)
            script = r.REPO/'scripts'/filename
            r.pinned(script, digest)
            target = EVIDENCE/name
            r.require(not target.exists(), 'zero-retry profile output already exists: '+name)
            command = [sys.executable, '-B', str(script), '--binary', str(binary_path),
                '--binary-sha256', args.binary_sha256, '--reference-package', str(PACKAGE),
                '--reference-tarball', str(TARBALL), '--node', str(NODE),
                '--repo', str(r.REPO), '--output-dir', str(target)]
            r.save(out/(name+'-launch.json'), dict(argv=command, cwd=str(r.REPO), retries=0))
            start = time.monotonic_ns()
            with (out/(name+'.stdout.log')).open('xb') as stdout, (out/(name+'.stderr.log')).open('xb') as stderr:
                completed = subprocess.run(command, cwd=r.REPO, stdout=stdout, stderr=stderr, check=False)
            row = dict(name=name, script=r.identity(script), returncode=completed.returncode,
                       elapsed_ns_observation_only=time.monotonic_ns()-start, passed=False,
                       stdout=r.identity(out/(name+'.stdout.log')), stderr=r.identity(out/(name+'.stderr.log')),
                       expected_comparisons=denominator, validation_errors=[])
            try:
                result_path = target/'qualification.json'
                result = json.loads(r.read(result_path))
                row['qualification'] = r.identity(result_path)
                row['finite_status'] = result.get('finite_status')
                row['reported_errors'] = result.get('errors')
                expected = {label+'/'+scenario.removesuffix('_'):count
                            for label in ('reference', 'native') for scenario,count in scenario_counts.items()}
                comparisons = result['comparisons']
                row['comparisons'] = len(comparisons)
                row['passed_comparisons'] = sum(item['status'] == 'PASS' for item in comparisons)
                row['failed_comparisons'] = [item for item in comparisons if item['status'] != 'PASS']
                r.require(result['schema'] == schema and result['qualified'] is False
                          and result['binary_before'] == result['binary_after'] == runtime,
                          'profile schema or runtime identity differs')
                r.require(result['reference_before'] == result['reference_after']
                          and result['reference_before']['tarball_sha256'] == r.PACKAGE_SHA
                          and result['reference_before']['file_count'] == 2398
                          and result['node']['sha256'] == r.NODE_SHA, 'original producer identity differs')
                r.require(json.loads(r.read(target/'producer-before.json')) == snapshot
                          and json.loads(r.read(target/'producer-after.json')) == snapshot
                          and result['source_unchanged'] is True, 'profile source inventory differs')
                r.require(json.loads(r.read(target/'producer-events.json')) == dict(
                    event_count=0, retained_events=[], events_truncated=False, errors=[]), 'profile source monitor incomplete')
                r.require(result['counts'] == expected and set(result['sessions']) == set(expected),
                          'actual scenario/call denominators differ')
                for session_name, state in result['sessions'].items():
                    close = state['close']
                    r.require(close['returncode'] == 0 and close['forced_cleanup'] == []
                              and close['reader_stopped'] and close['owner_pidfd_exited'] and close['process_group_gone'],
                              'MCP owner did not close normally: '+session_name)
                    session_dir = target/session_name.replace('/', '-')
                    r.require(json.loads(r.read(session_dir/'close.json')) == close, 'MCP close receipt differs')
                    row.setdefault('mcp_receipts', {})[session_name] = {
                        'close':r.identity(session_dir/'close.json'),
                        'launch':r.identity(session_dir/'launch.json'),
                        'compressed_wire_manifest':r.identity(session_dir/'wire.jsonl')}
                r.require(len(comparisons) == denominator and len({item['id'] for item in comparisons}) == denominator,
                          'comparison denominator or IDs differ')
                row['passed'] = (completed.returncode == 0 and result['errors'] == []
                                 and row['passed_comparisons'] == denominator and result['finite_status'] == 'PASS')
            except Exception as error:
                row['validation_errors'].append(dict(type=type(error).__name__, message=str(error)))
            # Failure in one finite profile does not repeat it or skip the next
            # independent profile, provided the original fixed inputs remain valid.
            r.git_identity()
            r.pinned(binary_path, args.binary_sha256)
            r.pinned(binding_path, args.binding_sha256)
            r.require(selection.snapshot() == snapshot, 'source changed after '+name)
            report['stages'].append(row)
            r.save(out/(name+'-result.json'), row)
            print(json.dumps(dict(name=name, returncode=completed.returncode, passed=row['passed'],
                                  comparisons=row.get('comparisons'), passed_comparisons=row.get('passed_comparisons'),
                                  validation_errors=row['validation_errors'])), flush=True)
    except BaseException as error:
        report['errors'].append(dict(type=type(error).__name__, message=str(error), traceback=traceback.format_exc()))
    finally:
        try:
            report['source_after'] = r.git_identity()
            r.require(report['source_after'] == report.get('source_before'), 'Git identity changed')
            if selection is not None:
                after = selection.snapshot()
                r.save(out/'source-after.json', after)
                r.require(after == snapshot, 'source snapshot changed')
            r.pinned(EVIDENCE/'binding.json', args.binding_sha256)
            r.pinned(EVIDENCE/'hepta-runtime', args.binary_sha256)
            report['node_after'] = r.identity(NODE, r.pinned(NODE, r.NODE_SHA))
            report['tarball_after'] = r.identity(TARBALL, r.pinned(TARBALL, r.PACKAGE_SHA))
            r.require(report['node_before'] == report['node_after']
                      and report['tarball_before'] == report['tarball_after'], 'original executable/archive changed')
            r.pinned(HELPER, HELPER_SHA)
        except BaseException as error:
            report['errors'].append(dict(phase='postflight', type=type(error).__name__, message=str(error)))
        if monitor is not None:
            try:
                events = monitor.stop()
                r.save(out/'source-events.json', events)
                r.require(events == dict(event_count=0, retained_events=[], events_truncated=False, errors=[]),
                          'source monitor detected changes or lost coverage')
            except BaseException as error:
                report['errors'].append(dict(phase='source-monitor', type=type(error).__name__, message=str(error)))
    report['passed'] = not report['errors'] and len(report['stages']) == 2 and all(row['passed'] for row in report['stages'])
    report['completed_utc'] = time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())
    receipt = r.save(out/'summary.json', report)
    print(json.dumps(dict(receipt=receipt, passed=report['passed'], errors=report['errors'],
                          stages=[{key:row.get(key) for key in ('name', 'passed', 'comparisons', 'passed_comparisons')}
                                  for row in report['stages']], qualified=False, global_status='HOLD/NO_GO')), flush=True)
    return 0 if report['passed'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
