# c25 同一候选 Provider gates：执行准备

状态：**只完成准备和语法检查，尚未运行本轮 binary 或任何重型引擎。**

固定源码：`c25e4cef0610816bfd1263b69d3dd63e4114aa49`  
Git tree：`c6db025f5902570bd63520751cf84c57505eb6f4`  
源码目录：`/home/qian-qi/work/hepta-rea-p0p5-679ccf-20261105`  
所有新增输出：`/home/qian-qi/work/hepta-rea-p0p5-679ccf-20261105-evidence`

## 执行入口

必须等父任务明确确认本轮 build binding ready。两个完整 SHA 来自那份已完成、已批准的 binding，不可读取旧 binary 回执代填。

```sh
python3 -B /home/qian-qi/work/hepta-rea-p0p5-679ccf-20261105-evidence/run_bound_provider_gates_r1.py \
  --execute \
  --expected-binding-sha256 "$APPROVED_BINDING_SHA256" \
  --expected-binary-sha256 "$APPROVED_BINARY_SHA256"
```

总 driver SHA256：`b4fc9d821c09ebe6d0bacaff24e4cc2f722bf3b4734d7edd7d884e660c28f5fa`（54,792 bytes）。  
现场 APK helper SHA256：`df35e61f96d90d7420ff86a8d1a6466dc5555f20d1282ba000499436a2638901`（35,175 bytes）。

全部顺序执行，首个失败立即停止；不会重试、跳过、重建 Rust 或更换 binary。输出根 `provider-gates-r1` 必须原本不存在。现成 harness 的内部超时、取消观察预算和断言保持不变。外层期限仅防止 orchestration 永久挂起，超时及失败清理一律不能计为 pass。

## 六组计划与验收

| 顺序 | 入口 | 必须观察的实际结果 | 原始终态 |
|---|---|---|---|
| 1 | 现成 Ghidra native harness，12.2／JDK25 | 精确 11 项；同 binary；独立 nm/objdump；原 owner 取消、崩溃、超时清理 | 9 个不同原始 durable jobs；角色对应成功、拒绝、取消、崩溃、超时 |
| 2 | 现成 JADX harness，1.5.6／JDK21 | 精确 8 项；真实 javac fixture／JADX classes+sources；原 owner 清理 | 3 个原始 jobs：classes、sources、cancel |
| 3 | 现成 native Chrome harness | 精确 14 项；8 个真实 exec 环境负控制；10 个空／缺字段 receipt 拒绝 | 4 个原始 jobs：tamper、capture、cancel、instrumented environment |
| 4 | APK native／原版 REA／Android 三方 | 精确 20 个 fixture、19 个 Android-valid、1 个伪造签名拒绝、4 个实际 worker 损坏拒绝；2398 原包文件逐字节一致 | 原脚本输出、每个 Android 判定、native 回执与完整 stdout/stderr |
| 5 | 现成 APK public MCP | 精确 6 项；原 5 秒取消、30 秒 worker deadline／35 秒观察预算；2 个 controller 正常 EOF 退出 | 原始 MCP wire、原 owner 杀死／回收与恢复证据；人工 cleanup 不计通过 |
| 6 | 自有 AAPT2 → seed → 签名 → 篡改／截断 → 两种 worker | 精确 14 项；14 个实际子进程：12 个正常成功、2 个普通非零拒绝；候选相同 | 每个原始命令的 argv/cwd/env/stdin SHA、实际写入字节、PID、wait/reap、exit、stdout/stderr EOF/SHA |

三方原包位置固定为：

`/home/qian-qi/work/hepta-rea-reference-recovery-ca464-20261105-r1/install/node_modules/rea-agents`

tarball 固定为：

`/home/qian-qi/work/hepta-rea-reference-20261103/pack/rea-agents-6.8.0.tgz`

SHA256：`8d542ec76a9cb350584b60a6c9c088706ff812d5bb5b094c20c95b6dc25698bb`。旧 `reference-20261103/install/node_modules` 路径已失效，不使用它。

实际 SDK 固定 `/opt/android-sdk/build-tools/35.0.1`，平台固定 `android-35`。旧 workflow 的 35.0.0 与本轮 35.0.1 差异明确保留。三方 oracle 的 BC provider 只为 Android verifier 补 JDK RSA/PSS 别名，实体为 `/usr/share/java/bcprov-1.77.jar`，不成为 runtime 依赖。三方 Java/Node PATH 固定为 JDK21/bin、/usr/bin、/bin。

## SHA、源码监控与配置

运行前会重新计算原始 `rea_build_evidence.validate_matrix`，使用原 `matrix-r1/summary.json` 和 sibling artifacts、与构建相同的 `Selection(REPO,TARGET,MATRIX).snapshot()`、实际 runtime 身份，并要求返回值与 binding 中 `independent_consumer` 完全相同。

执行期间对完整 c25 source selection 开 inotify monitor，保存前后每个源码／fixture 字节身份；事件必须为零，不能有丢失或错误。每组还核对原 HEAD/tree/clean 与同一 binary。外部 driver、helper 各有独立 SHA，不属于源码构建，不能混入正在开发的 P1 下一候选。

每组保存 `inputs-before.json`、`inputs-after.json`、实际 `process.json`、完整 stdout/stderr、qualification SHA 和产物目录清单。Ghidra 安装树、Chrome 安装树、原版 node_modules 是命名安装根的完整文件 inventory；JDK／JADX／SDK／Python／工具与原 fixture 按实际闭包文件绑定。生成的 engine config、安装 manifest、authority/request/manifest 文件都在该组全新 workspace 中并保留 SHA。配置是在新 workspace 生成，准备阶段不伪造尚不存在的 config SHA。

物理宿主绑定当前 desktop machine-id SHA、boot ID、UID，与原 `provider-inventory-current-r1.json` 的 SHA 一起重新核对。六台 inventory 中的缺失只保留为有限搜索声明。

## 原始终态收集

三组 engine 完成后，总 driver 仅重新启动该组私有 controller 做只读观察，允许的方法只有 initialize、rea_static_status、process_status、process_read。它不会重新提交 engine job。

必须对上述 9／3／4 个原始 job 保存原始 MCP wire、status、lossless byte pages 与重建 stdout/stderr；终态必须与预期角色一致，`output_complete`、`output_durable`、`terminal_publication_confirmed` 必须为 true；所有日志必须 EOF、无截断、无同步错误，分页字节数必须与原 stored/seen 字节数相等。私有读取 controller 必须正常 EOF 退出。

**最外层 durable driver job** 由调用者另外保存 shell_start 原始 job/nonce/idempotency 元数据，以及完成后的 process_status 和逐页 process_read 原始字节。若 launch_unknown，只查询原 job，不以新 key 重发。driver 本地 `summary.json` 成功不代替外层 durable 终态证据。

## 空间与范围

不复制安装树；只有现成 Ghidra/JADX/Chrome harness 各复制一份 runtime。启动整套要求空闲至少 1 GiB reserve + 3 倍实际 runtime 大小 + 768 MiB；每组开始再次核对 reserve。APK MCP 自有大 fixture 约 64 MiB，现场生成 helper 总输出严格低于 64 MiB。不会清理旧回执。

Chrome 正常 capture/cancel 为未注入运行；单独 constructor 证据只认证同一个 instrumented Chrome exec 边界。不会证明另一个未注入进程的运行时 getenv，也不会改写原 /proc 空 map 的 RED。

GDB/LLDB 无 native adapter，不启动独立探针凑资格；不启动 IDA/Hopper，不联系设备。所有 full REA parity、full Android verification、生产资格仍为 false。只有本轮实际执行并取得完整结果的有限 gate 才可标记通过。

完整 argv、输入／安装／源码 SHA 清单与预期数量在 `provider-gates-plan-r1.json`；准备状态不是执行回执。
