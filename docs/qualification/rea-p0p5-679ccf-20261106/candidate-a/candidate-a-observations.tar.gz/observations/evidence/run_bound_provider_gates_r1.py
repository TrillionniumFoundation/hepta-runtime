#!/usr/bin/env python3
"""Execute the frozen c25 provider gates once, sequentially, after explicit build binding.

Preparation does not execute this file. No Cargo, package installation, external
device, GDB/LLDB adapter claim, or production controller is used. Every new path
is below the selected evidence directory. First failure stops the sequence.
"""
from __future__ import annotations

import argparse
import datetime as dt
import hashlib
import importlib
import json
import os
from pathlib import Path
import queue
import re
import shutil
import signal
import stat
import subprocess
import sys
import tarfile
import threading
import time

REPO = Path("/home/qian-qi/work/hepta-rea-p0p5-679ccf-20261105")
EVIDENCE = Path(str(REPO) + "-evidence")
TARGET = Path(str(REPO) + "-target")
MATRIX = EVIDENCE / "matrix-r1"
BINARY = EVIDENCE / "hepta-runtime"
BINDING = EVIDENCE / "binding.json"
RUN = EVIDENCE / "provider-gates-r1"
OWNED_APK_HELPER = EVIDENCE / "run_owned_real_apk_r1.py"
OWNED_APK_HELPER_SHA256 = "df35e61f96d90d7420ff86a8d1a6466dc5555f20d1282ba000499436a2638901"
COMMIT = "c25e4cef0610816bfd1263b69d3dd63e4114aa49"
GIT_TREE = "c6db025f5902570bd63520751cf84c57505eb6f4"
GHIDRA = Path("/home/qian-qi/work/hepta-rea-engines-20261103-r1/ghidra/ghidra_12.2_PUBLIC")
JDK25 = Path("/home/qian-qi/work/hepta-rea-engines-20261103-r1/jdk25/jdk-25.0.5+8")
JADX = Path("/home/qian-qi/work/hepta-rea-engines-20261103-r1/jadx")
JDK21 = Path("/usr/lib/jvm/java-21-openjdk-amd64")
SDK = Path("/opt/android-sdk")
REA = Path("/home/qian-qi/work/hepta-rea-reference-recovery-ca464-20261105-r1/install/node_modules/rea-agents")
TARBALL = Path("/home/qian-qi/work/hepta-rea-reference-20261103/pack/rea-agents-6.8.0.tgz")
TARBALL_SHA256 = "8d542ec76a9cb350584b60a6c9c088706ff812d5bb5b094c20c95b6dc25698bb"
BC = Path("/usr/share/java/bcprov-1.77.jar")
BC_SHA256 = "5e0be358a7038ddae4fdad253b20aa7beb6cc261d70069b703b7f3e16d109ea6"
FIXTURES = REPO / "tests/fixtures/rea_apk_signature"
MCP_FIXTURE = FIXTURES / "custom-0103-rsa.apk"
MCP_FIXTURE_SHA256 = "2319675743cca6f540fb2fe04385ddf25209d65a5f342613f4ddba0f8010aa7d"
MIB = 1024 * 1024
GIB = 1024 * MIB
RESERVE_BYTES = GIB
JDK_COMPONENTS = ("release", "lib/modules", "lib/server/libjvm.so", "lib/libjava.so",
                  "lib/libzip.so", "lib/libnio.so", "lib/libjli.so")
SOURCE_PINS = json.loads("{\"scripts/rea_full_qualification.py\":\"8a6594e1e146d5f841539c125a83c6aed88e175586f2ecf81d022da43bd8a0ed\",\"scripts/rea_build_evidence.py\":\"02cfb97960e075a954bc57b5b0ee8f6fbfdf511c754cc6512717920872f3a4ed\",\"tests/rea_ghidra_analysis_external.py\":\"e93f5a89a2dcf63efff21bf1751a154533214563d060ec8265b32f46234c53b3\",\"tests/rea_java_external.py\":\"42011fb7685208659f89603aa382a263c4145abe4c7847d6c102a7bb567a1f60\",\"tests/rea_engine_cleanup_assertions.py\":\"fd5d02dbf8abc5d476d3abd0b9236db1127e2686a1aeb21f3e6c403a2ee20601\",\"tests/rea_java_kernel_probe.py\":\"09676e856ede6109595bc4c30d9833117f161f0da188818a3ac924041ff9036c\",\"tests/rea_browser_external.py\":\"108b7a0ee5cfeeb4ee28100109ef9e3d7d4c117f733796ca43c41d60f4e0d08d\",\"tests/rea_browser_environment.py\":\"2b67b11e81f0a57e6a0acdbbecf63a980011111c67dd45190776ffa5ba0a5b50\",\"tests/fixtures/rea_browser_env_observer.c\":\"87d9ed9110936af7aec8261357373786dad69cbc737f41a9e964f3bc4cfbd902\",\"scripts/qualify_apk_signature_native.py\":\"e48840986768a84e29fbab1839e62699b60362179822b0e70d31a08abd5cb784\",\"scripts/generate_apk_signature_fixtures.py\":\"f1854eb05127309d7f98702b5305bd863e7e048280914aebeee3ba964e833194\",\"tests/rea_apk_signature_mcp.py\":\"633dd05e70696b5082f6d5f092e02a56f50ed5d43d7faf8b4ba64ff4105b1bbf\"}")
EXPECTED_CHECKS = json.loads("{\"ghidra\":[\"revision_two_named_byte_provider_repairs_dynamic_elf_import_with_distinct_profile_and_bridge\",\"dynamic_library_elf_named_bytes_real_analysis_and_independent_nm_entries\",\"analyzed_incoming_call_xrefs_match_independent_gnu_objdump\",\"actual_native_decompiler_selected_function_complete_c_digest_and_child_cleanup\",\"controller_restart_returns_original_decompilation_without_relaunch\",\"changed_content_same_key_and_invalid_or_extra_selectors_refused\",\"interior_address_is_real_backend_failure_without_successful_facts\",\"frozen_original_owner_cancel_during_real_native_decompilation_and_no_relaunch\",\"cancelled_scratch_cleaned_by_original_owner_and_receipt_survives_controller_restart\",\"live_native_decompiler_worker_sigkill_original_group_cleanup_and_restart_readback\",\"live_java_stopped_worker_original_owner_timeout_cleanup_and_restart_readback\"],\"jadx\":[\"actual_native_worker_owned_class\",\"actual_jadx_mcp_classes_same_key_same_job\",\"actual_jadx_bounded_source_preview_and_digest\",\"controller_restart_original_result_without_relaunch\",\"changed_payload_profile_rebinding_and_unsubmitted_observation_rejected\",\"frozen_owner_observation_cancel_original_job_and_no_relaunch\",\"inspected_artifact_bytes_unchanged\",\"cancelled_scratch_cleaned_by_original_owner_and_receipt_survives_controller_restart\"],\"chrome\":[\"eight_actual_chrome_exec_missing_and_non_private_environment_controls_rejected\",\"unchanged_manifest_and_request_refuse_changed_resource_before_browser_and_same_key_reuses_failed_job\",\"receipt_durability_confirmed_by_original_success_and_post_sync_complete_event\",\"original_native_job_and_same_key_single_browser\",\"reachable_second_loopback_origin_received_zero_browser_requests\",\"private_chrome_and_profile_removed_after_success\",\"real_complete_empty_base64_missing_and_repeated_request_observations\",\"same_origin_before_after_has_two_true_response_changes\",\"mcp_restart_same_job_same_har_sha_without_browser_restart\",\"saved_representation_replay_exact_bytes_and_zero_requests_to_live_sentinels\",\"changed_original_request_and_saved_har_identity_refused\",\"uninstrumented_original_chrome_executable_and_private_directories_verified\",\"original_job_cancel_confirmed_and_no_owned_browser_profile_or_relaunch\",\"separate_instrumented_original_chrome_exec_four_private_keys_and_cancel_cleanup\"],\"apk_mcp\":[\"actual_public_mcp_worker_and_source_binding\",\"root_symlink_regular_file_and_identity_refusals\",\"malformed_worker_input_then_successful_recovery\",\"ordinary_mcp_cancellation_original_owner_kills_reaps_and_recovers\",\"fixed_runtime_deadline_original_owner_kills_reaps_and_recovers\",\"cold_controller_reinspection_preserves_captured_identity\"]}")
SHA = re.compile(r"[0-9a-f]{64}")
JOB_ID = re.compile(r"[0-9a-f]+-[0-9a-f]+-[0-9a-f]+")
INVENTORY = EVIDENCE / "provider-inventory-current-r1.json"
INVENTORY_SHA256 = "92cca10a5f6ae9081fcea553ba3303327de8603c9083524f9250080ab3555ecc"
MACHINE_ID_SHA256 = "4aa975e602e314286bf831630a241bcb35e6a64a85a1918f561f2576a1c7a099"
BOOT_ID = "14f92beb-43c6-4786-839e-b57307ae8048"

def require(value, message):
    if not value:
        raise AssertionError(message)


def now():
    return dt.datetime.now(dt.timezone.utc).isoformat()


def canonical(value):
    return json.dumps(value, sort_keys=True, ensure_ascii=True, separators=(",", ":"), allow_nan=False).encode()


def save(path, value):
    raw = json.dumps(value, sort_keys=True, indent=2, ensure_ascii=True, allow_nan=False).encode() + b"\n"
    temporary = path.with_name(path.name + ".next")
    with temporary.open("xb") as stream:
        stream.write(raw)
        stream.flush()
        os.fsync(stream.fileno())
    os.replace(temporary, path)
    fd = os.open(path.parent, os.O_DIRECTORY)
    try:
        os.fsync(fd)
    finally:
        os.close(fd)


def identity(path):
    path = Path(path)
    actual = path.resolve(strict=True)
    before = actual.stat()
    require(stat.S_ISREG(before.st_mode) and 0 <= before.st_size <= 6 * GIB,
            "not a bounded regular input: " + str(path))
    digest = hashlib.sha256()
    with actual.open("rb") as stream:
        for block in iter(lambda: stream.read(MIB), b""):
            digest.update(block)
    after = actual.stat()
    fields = ("st_dev", "st_ino", "st_mode", "st_size", "st_nlink", "st_uid", "st_gid", "st_mtime_ns", "st_ctime_ns")
    require(all(getattr(before, field) == getattr(after, field) for field in fields)
            and path.resolve(strict=True) == actual, "input changed while hashing: " + str(path))
    return {"path": str(path), "realpath": str(actual), "bytes": before.st_size, "sha256": digest.hexdigest(),
            "metadata": {field: getattr(before, field) for field in fields}}


def reference(path):
    row = identity(path)
    return {key: row[key] for key in ("path", "bytes", "sha256")}


def read_json(path):
    require(path.stat().st_size <= 32 * MIB, "JSON exceeds evidence bound: " + str(path))
    def members(pairs):
        result = {}
        for key, value in pairs:
            require(key not in result, "duplicate JSON key: " + key)
            result[key] = value
        return result
    return json.loads(path.read_bytes(), object_pairs_hook=members,
                      parse_constant=lambda value: (_ for _ in ()).throw(ValueError(value)))


def tree_identity(root, byte_limit=6 * GIB, file_limit=50000):
    """Hash only a named installation/input root; never follow directory links."""
    root = root.resolve(strict=True)
    files, total = [], 0
    for base, directories, names in os.walk(root, followlinks=False):
        directory = Path(base)
        for name in list(directories):
            path = directory / name
            if path.is_symlink():
                target = path.resolve(strict=True)
                require(target.is_relative_to(root), "installation directory link leaves bound root")
                files.append({"relative": path.relative_to(root).as_posix(), "symlink": os.readlink(path)})
                directories.remove(name)
        directories.sort()
        for name in sorted(names):
            path = directory / name
            relative = path.relative_to(root).as_posix()
            if path.is_symlink():
                require(path.resolve(strict=True).is_relative_to(root), "installation file link leaves bound root")
                files.append({"relative": relative, "symlink": os.readlink(path)})
            else:
                row = identity(path)
                total += row["bytes"]
                require(total <= byte_limit, "installation byte inventory bound exceeded")
                files.append({"relative": relative, **row})
            require(len(files) <= file_limit, "installation file inventory bound exceeded")
    files.sort(key=lambda row: row["relative"])
    return {"root": str(root), "file_count": len(files), "bytes_hashed": total,
            "inventory_sha256": hashlib.sha256(canonical(files)).hexdigest(), "files": files}


def git_identity():
    env = dict(os.environ, GIT_OPTIONAL_LOCKS="0")
    def query(*args):
        return subprocess.check_output(["/usr/bin/git", "-C", str(REPO), *args],
                                       env=env, text=True, timeout=30).strip()
    result = {"commit": query("rev-parse", "HEAD"), "tree": query("rev-parse", "HEAD^{tree}"),
              "status": query("status", "--porcelain=v1")}
    require(result == {"commit": COMMIT, "tree": GIT_TREE, "status": ""}, "frozen source checkout is not c25/clean")
    return result


def pinned_sources():
    rows = {}
    for name, expected in SOURCE_PINS.items():
        row = identity(REPO / name)
        require(row["sha256"] == expected, "reviewed source script changed: " + name)
        rows[name] = row
    return rows


def host_identity():
    value = {"machine_id_sha256": hashlib.sha256(Path("/etc/machine-id").read_bytes().strip().lower()).hexdigest(),
             "boot_id": Path("/proc/sys/kernel/random/boot_id").read_text().strip(),
             "uid": os.geteuid(), "kernel": os.uname().release, "machine": os.uname().machine}
    require(value["machine_id_sha256"] == MACHINE_ID_SHA256 and value["boot_id"] == BOOT_ID
            and value["uid"] == 1000, "physical desktop/operator/boot differs from current inventory")
    require(reference(INVENTORY)["sha256"] == INVENTORY_SHA256, "current inventory original bytes changed")
    return value


def check_disk(needed):
    disk = shutil.disk_usage(EVIDENCE)
    require(disk.free >= RESERVE_BYTES + needed, "insufficient free space for next owned gate plus 1 GiB reserve")
    return {"free_bytes": disk.free, "required_next_bytes": needed, "reserve_bytes": RESERVE_BYTES,
            "installation_copies": 0, "old_evidence_deleted": False}


def stage_plan(binary_sha):
    python = str(Path(sys.executable).resolve(strict=True))
    test = REPO / "tests"
    base = RUN
    rows = [
        ("ghidra", 1200, "engine", [python, "-B", str(test / "rea_ghidra_analysis_external.py"),
         "--runtime", str(BINARY), "--java-home", str(JDK25), "--ghidra-home", str(GHIDRA),
         "--workspace", str(base / "01-ghidra/workspace"), "--execution-mode", "operator", "--allow-local-ssh"]),
        ("jadx", 600, "engine", [python, "-B", str(test / "rea_java_external.py"),
         "--runtime", str(BINARY), "--java-home", str(JDK21), "--jadx-home", str(JADX),
         "--workspace", str(base / "02-jadx/workspace"), "--execution-mode", "operator", "--allow-local-ssh"]),
        ("chrome", 480, "engine", [python, "-B", str(test / "rea_browser_external.py"),
         "--runtime", str(BINARY), "--native-capture", "--workspace", str(base / "03-chrome/workspace"),
         "--allow-owned-browser", "--allow-local-ssh"]),
        ("apk-three-way", 240, "oracle", [python, "-B", str(REPO / "scripts/qualify_apk_signature_native.py"),
         "--binary", str(BINARY), "--rea-install", str(REA), "--rea-tarball", str(TARBALL),
         "--apksigner", str(SDK / "build-tools/35.0.1/apksigner"), "--bc-provider", str(BC),
         "--fixtures", str(FIXTURES), "--scratch", str(base / "04-apk-three-way/verifier"),
         "--output", str(base / "04-apk-three-way/qualification.json")]),
        ("apk-mcp", 120, "mcp", [python, "-B", str(test / "rea_apk_signature_mcp.py"),
         "--binary", str(BINARY), "--binary-sha256", binary_sha, "--fixture", str(MCP_FIXTURE),
         "--fixture-sha256", MCP_FIXTURE_SHA256, "--output", str(base / "05-apk-mcp/workspace")]),
        ("apk-generated", 300, "generated", [python, "-B", str(OWNED_APK_HELPER),
         "--binary", str(BINARY), "--expected-binary-sha256", binary_sha,
         "--output", str(base / "06-apk-generated/workspace")]),
    ]
    return [{"index": index, "name": name, "timeout_seconds": timeout, "kind": kind, "argv": argv,
             "directory": str(base / ("%02d-%s" % (index, name))),
             "cwd": str(REPO if kind == "oracle" else base / ("%02d-%s" % (index, name)))}
            for index, (name, timeout, kind, argv) in enumerate(rows, 1)]


def installation_inputs(name):
    paths = [Path(sys.executable), BINARY]
    trees = {}
    if name in ("ghidra", "jadx", "chrome"):
        paths += [Path("/usr/bin/ssh")]
    if name == "ghidra":
        paths += [Path("/usr/bin/cc"), Path("/usr/bin/nm"), Path("/usr/bin/objdump"),
                  JDK25 / "bin/java", *[JDK25 / item for item in JDK_COMPONENTS]]
        trees["ghidra"] = tree_identity(GHIDRA / "Ghidra")
    elif name == "jadx":
        paths += [JDK21 / "bin/java", JDK21 / "bin/javac",
                  *[JDK21 / item for item in JDK_COMPONENTS], JADX / "lib/jadx-1.5.6-all.jar"]
    elif name == "chrome":
        paths += [Path("/usr/bin/cc"), Path("/usr/bin/google-chrome"), Path("/opt/google/chrome/chrome")]
        trees["chrome_installation"] = tree_identity(Path("/opt/google/chrome"), byte_limit=2 * GIB)
        # The browser harness separately pins launcher/ELF identity and observer closure.
    elif name == "apk-three-way":
        paths += [Path("/usr/bin/node"), JDK21 / "bin/java", JDK21 / "bin/javac",
                  *[JDK21 / item for item in JDK_COMPONENTS], TARBALL, BC,
                  SDK / "build-tools/35.0.1/apksigner", SDK / "build-tools/35.0.1/lib/apksigner.jar"]
        trees["node_modules"] = tree_identity(REA.parent, byte_limit=2 * GIB)
        trees["committed_apks"] = tree_identity(FIXTURES, byte_limit=128 * MIB)
    elif name == "apk-mcp":
        paths += [MCP_FIXTURE]
    elif name == "apk-generated":
        paths += [OWNED_APK_HELPER, JDK21 / "bin/java", JDK21 / "bin/keytool",
                  *[JDK21 / item for item in JDK_COMPONENTS], SDK / "build-tools/35.0.1/aapt2",
                  SDK / "build-tools/35.0.1/apksigner", SDK / "build-tools/35.0.1/lib/apksigner.jar",
                  SDK / "platforms/android-35/android.jar", REPO / ".github/workflows/rea-real-apk.yml"]
    rows = {str(path): identity(path) for path in paths}
    if str(TARBALL) in rows:
        require(rows[str(TARBALL)]["sha256"] == TARBALL_SHA256, "frozen tarball changed")
        require(rows[str(BC)]["sha256"] == BC_SHA256, "Bouncy Castle entity changed")
    if str(MCP_FIXTURE) in rows:
        require(rows[str(MCP_FIXTURE)]["sha256"] == MCP_FIXTURE_SHA256, "MCP fixture changed")
    if str(OWNED_APK_HELPER) in rows:
        require(rows[str(OWNED_APK_HELPER)]["sha256"] == OWNED_APK_HELPER_SHA256, "owned APK helper changed")
    return {"files": rows, "trees": trees}


def run_process(stage, env):
    directory = Path(stage["directory"])
    started, clock = now(), time.monotonic()
    process = None
    cleanup = []
    returncode = None
    timed_out = False
    failure = None
    stdout_path, stderr_path = directory / "process.stdout.log", directory / "process.stderr.log"
    try:
        with stdout_path.open("xb") as stdout, stderr_path.open("xb") as stderr:
            process = subprocess.Popen(stage["argv"], cwd=stage["cwd"], env=env, stdin=subprocess.DEVNULL,
                                       stdout=stdout, stderr=stderr, start_new_session=True)
            try:
                returncode = process.wait(timeout=stage["timeout_seconds"])
            except subprocess.TimeoutExpired:
                timed_out = True
                cleanup.append("SIGINT_to_owned_unreaped_runner_group_after_outer_deadline")
                os.killpg(process.pid, signal.SIGINT)
                try:
                    returncode = process.wait(timeout=15)
                except subprocess.TimeoutExpired:
                    cleanup.append("SIGKILL_to_owned_unreaped_runner_group_after_interrupt_grace")
                    os.killpg(process.pid, signal.SIGKILL)
                    returncode = process.wait(timeout=10)
                failure = "outer runner deadline exceeded; no retry and no pass"
            finally:
                if process.poll() is None:
                    cleanup.append("SIGKILL_owned_runner_on_driver_exception")
                    os.killpg(process.pid, signal.SIGKILL)
                    returncode = process.wait(timeout=10)
    except BaseException as error:
        failure = type(error).__name__ + ": " + str(error)
        raise
    finally:
        row = {"argv": stage["argv"], "cwd": stage["cwd"], "started_at": started, "finished_at": now(),
               "elapsed_seconds": time.monotonic() - clock, "timeout_seconds": stage["timeout_seconds"],
               "pid": process.pid if process else None, "returncode": returncode,
               "timed_out": timed_out, "cleanup_actions": cleanup, "failure": failure,
               "stdout": reference(stdout_path) if stdout_path.exists() else None,
               "stderr": reference(stderr_path) if stderr_path.exists() else None,
               "automatic_retry": False}
        save(directory / "process.json", row)
    require(returncode == 0 and not timed_out and not cleanup, "stage process did not complete cleanly: " + stage["name"])
    return row


class WireMcp:
    """Only initialize + original process_status/process_read/status discovery."""
    def __init__(self, directory, workspace):
        directory.mkdir(mode=0o700)
        self.directory, self.messages, self.sequence = directory, queue.Queue(), 0
        self.requests = (directory / "requests.jsonl").open("xb")
        self.stdout = (directory / "stdout.jsonl").open("xb")
        self.stderr = (directory / "stderr.log").open("xb")
        env = dict(os.environ, HEPTA_EFFECT_OWNER_FENCE_DIR=str(workspace / "authority"),
                   HEPTA_EFFECT_OWNER_SELF="v4", HEPTA_EFFECT_OWNER_FENCE_REQUIRED="1")
        self.process = subprocess.Popen([str(workspace / "hepta-runtime-qualified"), "mcp", "--runtime-config",
                                         str(workspace / "config.json")], cwd=directory, env=env,
                                        stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=self.stderr)
        self.reader = threading.Thread(target=self.pump, daemon=True)
        self.reader.start()
        try:
            self.server_info = self.request("initialize", {"protocolVersion": "2026-07-28", "capabilities": {},
                "clientInfo": {"name": "frozen-provider-original-terminal-reader", "version": "1"}}).get("serverInfo")
            self.send({"jsonrpc": "2.0", "method": "notifications/initialized", "params": {}})
        except BaseException:
            self.close()
            raise

    def pump(self):
        try:
            while True:
                line = self.process.stdout.readline(MIB + 1)
                if not line:
                    self.messages.put(EOFError("private terminal reader exited"))
                    return
                require(len(line) <= MIB and line.endswith(b"\n"), "incomplete or oversized MCP line")
                self.stdout.write(line)
                self.stdout.flush()
                self.messages.put(json.loads(line))
        except BaseException as error:
            self.messages.put(error)

    def send(self, value):
        data = canonical(value) + b"\n"
        self.requests.write(data)
        self.requests.flush()
        self.process.stdin.write(data)
        self.process.stdin.flush()

    def request(self, method, params):
        self.sequence += 1
        request_id = self.sequence
        self.send({"jsonrpc": "2.0", "id": request_id, "method": method, "params": params})
        deadline = time.monotonic() + 60
        while time.monotonic() < deadline:
            value = self.messages.get(timeout=max(0.001, deadline - time.monotonic()))
            if isinstance(value, BaseException):
                raise value
            if value.get("id") == request_id:
                require("error" not in value, "terminal reader RPC failed: " + str(value))
                return value["result"]
        raise TimeoutError("terminal reader fixed observation deadline")

    def call(self, name, arguments):
        require(name in ("process_status", "process_read", "rea_static_status"), "read-only collector allowlist")
        reply = self.request("tools/call", {"name": name, "arguments": arguments})
        require(reply.get("isError") is not True, "terminal read tool failed: " + str(reply))
        return json.loads(reply["content"][0]["text"])

    def close(self):
        actions = []
        if self.process.poll() is None:
            self.process.stdin.close()
            try:
                self.process.wait(timeout=5)
            except subprocess.TimeoutExpired:
                actions.append("owned_terminal_reader_terminate_after_EOF_timeout")
                self.process.terminate()
                try:
                    self.process.wait(timeout=5)
                except subprocess.TimeoutExpired:
                    actions.append("owned_terminal_reader_kill_after_terminate_timeout")
                    self.process.kill()
                    self.process.wait(timeout=5)
        self.reader.join(timeout=5)
        if self.reader.is_alive():
            actions.append("terminal_reader_thread_not_finished")
        self.requests.close()
        self.stdout.close()
        self.stderr.close()
        row = {"pid": self.process.pid, "exit_code": self.process.returncode, "teardown_actions": actions,
               "requests": reference(self.directory / "requests.jsonl"),
               "stdout": reference(self.directory / "stdout.jsonl"), "stderr": reference(self.directory / "stderr.log")}
        save(self.directory / "close.json", row)
        return row


def collect_terminals(name, workspace, destination, qualification):
    server = WireMcp(destination, workspace)
    rows = []
    try:
        if name == "ghidra":
            roles = dict(qualification["job_ids"])
            roles["interior_refusal"] = read_json(workspace / "interior-refusal.json")["initial"]["job"]["id"]
            require(set(roles) == {"inventory_v2", "functions", "function", "decompile", "xrefs",
                                  "cancel", "worker_crash", "owner_timeout", "interior_refusal"},
                    "Ghidra durable job role set differs")
        elif name == "jadx":
            request = read_json(workspace / "requests.json")["sources"]
            status = server.call("rea_static_status", request)
            save(destination / "sources-static-status.json", status)
            roles = {"classes": qualification["classes_job_id"], "sources": status["job"]["id"],
                     "cancel": qualification["cancel_job_id"]}
        else:
            roles = {"tamper": qualification["tamper_job_id"], "capture": qualification["capture_job_id"],
                     "cancel": qualification["cancel_job_id"],
                     "environment": qualification["environment_observation"]["instrumented_environment_job_id"]}
        require(len(set(roles.values())) == len(roles), "different original gate roles alias one job")
        for role, job_id in sorted(roles.items()):
            require(JOB_ID.fullmatch(job_id) is not None, "unexpected original durable job identity")
            directory = destination / role
            directory.mkdir(mode=0o700)
            status = server.call("process_status", {"host": "local", "job_id": job_id})
            save(directory / "status.json", status)
            require(status.get("job_id") == job_id and type(status.get("exit_code")) is int, "missing terminal job/exit identity")
            require(status.get("state") in {"succeeded", "failed", "cancelled", "timed_out"}, "original job is not terminal")
            require(status.get("output_complete") is True and status.get("output_durable") is True,
                    "original terminal output is incomplete or nondurable")
            require(status.get("terminal_publication_confirmed") is True, "original terminal publication not confirmed")
            for stream in ("stdout", "stderr"):
                require(status.get("log_errors", {}).get(stream) is None
                        and status.get("log_synced", {}).get(stream) is True
                        and status.get("log_truncated", {}).get(stream) is False,
                        "original terminal log loss/sync error")
                counts = status["log_bytes"][stream]
                require(type(counts["stored"]) is int and counts["seen"] == counts["stored"]
                        and 0 <= counts["stored"] <= 4 * MIB, "terminal log count or evidence budget differs")
            if role in {"inventory_v2", "functions", "function", "decompile", "xrefs", "classes", "sources", "capture"}:
                require(status["state"] == "succeeded" and status["exit_code"] == 0, "positive original job failed")
            elif role == "owner_timeout":
                require(status["state"] == "timed_out" and status["exit_code"] != 0, "owner timeout not observed")
            elif role in {"worker_crash", "interior_refusal", "tamper"}:
                require(status["state"] == "failed" and status["exit_code"] != 0, "expected original failure absent")
            else:
                require(status["state"] in {"cancelled", "failed"} and status["exit_code"] != 0, "original cancellation absent")
            positions = {"stdout_offset": 0, "stderr_offset": 0}
            streams = {name: (directory / (name + ".original.bin")).open("xb") for name in ("stdout", "stderr")}
            try:
                for index in range(257):
                    page = server.call("process_read", {"host": "local", "job_id": job_id, "limit": 16384, **positions})
                    save(directory / ("page-%04d.json" % index), page)
                    for stream in streams:
                        data = bytes.fromhex(page[stream]["bytes_hex"])
                        require(page[stream]["next_offset"] == positions[stream + "_offset"] + len(data),
                                "process byte cursor discontinuity")
                        streams[stream].write(data)
                        positions[stream + "_offset"] = page[stream]["next_offset"]
                    if page["stdout"]["eof"] and page["stderr"]["eof"]:
                        break
                else:
                    raise AssertionError("original terminal logs exceed page budget")
            finally:
                for stream in streams.values():
                    stream.close()
            for stream in streams:
                require(positions[stream + "_offset"] == status["log_bytes"][stream]["stored"],
                        "terminal stored bytes do not match original paged bytes")
            rows.append({"role": role, "job_id": job_id, "status": reference(directory / "status.json"),
                         "state": status["state"], "exit_code": status["exit_code"],
                         "stdout": reference(directory / "stdout.original.bin"),
                         "stderr": reference(directory / "stderr.original.bin")})
    finally:
        close = server.close()
    require(close["exit_code"] == 0 and not close["teardown_actions"], "terminal-reader cleanup cannot count as pass")
    save(destination / "summary.json", {"original_jobs": rows, "close": close, "read_only_tools": True,
                                      "runtime_or_engine_relaunch": False})
    return rows


def validate_engine(name, workspace, report, expected_binary):
    require(report.get("qualified") is True and report.get("runtime_sha256") == expected_binary, "engine candidate binding/result")
    require(report.get("checks") == EXPECTED_CHECKS[name], "engine check set/count/order differs: " + name)
    require(report.get("execution_mode") == "operator", "engine execution mode changed")
    require(reference(workspace / "hepta-runtime-qualified")["sha256"] == expected_binary, "engine copied different binary")
    require(not report.get("cleanup_unknown"), "engine cleanup was uncertain")
    config = read_json(workspace / "config.json")
    require(config["state_dir"] == str(workspace / "controller-state")
            and config["controller_workspace_roots"] == [str(workspace)], "engine state escaped owned workspace")
    if name in ("ghidra", "jadx"):
        require(report.get("rea_full_parity") is False and report.get("isolated_host_qualification") is False,
                "finite operator gate claimed full or isolated qualification")
        profiles = config["rea_static_profiles"]
        for profile in profiles.values():
            require(profile["runtime_sha256"] == expected_binary
                    and identity(profile["backend_executable"])["sha256"] == profile["backend_sha256"], "backend/profile binding")
            engine = profile["ghidra_engine"] if name == "ghidra" else profile["java_engine"]
            java = Path(engine["java_home"])
            for relative, digest in engine["runtime_files"].items():
                require(identity(java / relative)["sha256"] == digest, "admitted JDK component changed")
            if name == "ghidra":
                require(reference(Path(engine["manifest_path"]))["sha256"] == engine["manifest_sha256"], "Ghidra manifest binding")
                require(profile["memory_max_bytes"] == 1610612736, "Ghidra memory contract changed")
            else:
                require(identity(engine["jar_path"])["sha256"] == engine["jar_sha256"], "JADX JAR binding")
    else:
        observation = report["environment_observation"]
        require(observation["uninstrumented_environment_qualified"] is False
                and observation["instrumented_exec_environment_qualified"] is True
                and observation["no_claim_about_current_getenv_after_constructor"] is True
                and observation["original_proc_failure_reclassified"] is False, "Chrome observation scopes changed")
        controls = report["environment_negative_controls"]
        require(len(controls) == 8 and all(row.get("accepted") is False for row in controls), "Chrome real negative controls incomplete")
        schema_controls = report["environment_observer"]["executable_receipt_schema_controls"]
        require(len(schema_controls) == 10 and all(row.get("accepted") is False for row in schema_controls),
                "Chrome empty/missing executable schema controls incomplete")
        require(report["capture_implementation"] == "native-rust"
                and report["input_application_scripts_executed"] is False
                and report["input_page_dom_inspected"] is False
                and report["complete_application_behavior_recording"] is False
                and report["process_level_network_isolation"] is False, "Chrome gate scope changed")
    return {"checks": len(report["checks"]), "config": reference(workspace / "config.json")}


def validate_apk_oracle(report, expected_binary):
    require(report.get("format") == "hepta.apk-native-qualification.v1"
            and report.get("native_binary_sha256") == expected_binary, "APK oracle candidate binding")
    require(report.get("positive_fixtures") == 19 and report.get("forged_matching_digest_fixture") == 1
            and report.get("rea_tarball_sha256") == TARBALL_SHA256
            and report.get("rea_package_files_checked") == 2398, "APK original producer/fixture counts")
    require(report.get("full_android_verification") is False and report.get("rea_evidence_compatibility") is False, "APK scope changed")
    rows = report["results"]
    expected = {path.name: reference(path) for path in FIXTURES.glob("*.apk")}
    require(len(rows) == len(expected) == 20 and {row["file"] for row in rows} == set(expected), "APK result coverage/duplicates")
    for row in rows:
        require(row["sha256"] == expected[row["file"]]["sha256"] and row["byte_length"] == expected[row["file"]]["bytes"],
                "APK fixture identity differs")
        forged = row["file"] == "forged-matching-digest.apk"
        require((row["android_exit"] != 0) if forged else (row["android_exit"] == 0), "Android oracle verdict differs")
        partial = {"custom-0202-p521.apk", "custom-0103-rsa1024.apk", "custom-0103-rsa34.apk", "custom-0103-rsa34audit.apk"}
        wanted = "invalid" if forged else "absent" if row["file"] == "v1-only.apk" else "partial" if row["file"] in partial else "verified"
        require(row["native_record_status"] == wanted, "native APK record boundary differs")
        fields = row["rea_field_comparison"]
        require(set(fields) == {"source_digest", "source_length", "scheme_signer_counts",
                "leaf_certificate_fingerprints", "public_key_lengths", "signed_tail_lengths", "algorithm_ids",
                "declared_and_computed_digest_agreement", "v3_sdk_ranges", "v3_1_presence"}
                and all(value is True for value in fields.values()), "empty/incomplete APK three-way comparison")
    rejections = report["worker_malformed_rejections"]
    require(len(rejections) == 4 and [row["case"] for row in rejections] == [0, 1, 2, 3]
            and all(type(row["exit"]) is int and row["exit"] != 0 for row in rejections), "malformed worker refusal count")
    return {"positive": 19, "forged": 1, "malformed": 4, "rea_package_files_checked": 2398}


def validate_apk_mcp(report, expected_binary):
    require(report.get("schema") == "hepta.rea.apk-signature-public-mcp-qualification.v1"
            and report.get("status") == "pass", "APK public MCP did not pass")
    require(report["binary"]["sha256"] == expected_binary and report["binary_sha256_after"] == expected_binary
            and report["fixture"]["sha256"] == MCP_FIXTURE_SHA256
            and report["fixture_sha256_after"] == MCP_FIXTURE_SHA256, "APK MCP input identity changed")
    require(report.get("script_sha256") == SOURCE_PINS["tests/rea_apk_signature_mcp.py"], "APK MCP harness identity")
    require([row["gate"] for row in report["results"]] == EXPECTED_CHECKS["apk_mcp"]
            and all(row.get("pass") is True for row in report["results"]), "APK MCP actual gate set/count")
    require(report.get("manual_worker_cleanup") == [] and len(report["controllers"]) == 2
            and all(row["exit_code"] == 0 and not row["teardown_actions"] for row in report["controllers"]),
            "APK MCP original owner/clean controller completion")
    require(report["cancel_observation_budget_seconds"] == 5 and report["worker_deadline_seconds"] == 30
            and report["deadline_observation_budget_seconds"] == 35, "APK MCP original budgets changed")
    require(report["full_upstream_parity_qualified"] is False, "APK MCP full parity claim")
    return {"gates": 6, "controllers_clean": 2, "owned_fixture_bytes": report["large_owned_fixture_bytes"]}


def artifact_inventory(root):
    rows, total = [], 0
    for base, directories, names in os.walk(root, followlinks=False):
        directory = Path(base)
        for name in list(directories):
            path = directory / name
            if path.is_symlink():
                rows.append({"path": str(path), "kind": "symlink", "target": os.readlink(path)})
                directories.remove(name)
        for name in sorted(names):
            path = directory / name
            item = path.lstat()
            if stat.S_ISREG(item.st_mode):
                total += item.st_size
                require(total <= 2 * GIB and item.st_size <= GIB, "owned gate artifact budget exceeded")
                rows.append(identity(path))
            elif stat.S_ISLNK(item.st_mode):
                rows.append({"path": str(path), "kind": "symlink", "target": os.readlink(path)})
            else:
                rows.append({"path": str(path), "kind": "special", "mode": oct(item.st_mode)})
            require(len(rows) <= 30000, "owned artifact file count exceeded")
    return {"file_count": len(rows), "regular_bytes": total, "files": sorted(rows, key=lambda row: row["path"])}


def validate_binding(args, selection, consumer):
    require(reference(BINDING)["sha256"] == args.expected_binding_sha256, "approved binding bytes changed")
    binding = read_json(BINDING)
    require(binding.get("schema") == "hepta.rea.p0p5.build-binding.v1"
            and binding.get("source_commit") == COMMIT and binding.get("source_git_tree") == GIT_TREE,
            "binding source schema/commit/tree differs")
    native = reference(BINARY)
    require(native == binding["runtime"] and native["sha256"] == args.expected_binary_sha256,
            "actual executable differs from approved binding")
    require(reference(MATRIX / "summary.json") == binding["build_summary"], "original matrix summary changed")
    raw = consumer.read_regular(MATRIX, "summary.json")
    validation = consumer.validate_matrix(raw, lambda name: consumer.read_regular(MATRIX, name), selection.snapshot(), native)
    require(validation == binding["independent_consumer"], "independent build consumer differs")
    require(binding["rea_full_parity"] is False and binding["production_qualified"] is False, "build scope changed")
    return binding, validation


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--execute", action="store_true", help="Required only after parent reports c25 build binding ready")
    parser.add_argument("--expected-binding-sha256", required=True)
    parser.add_argument("--expected-binary-sha256", required=True)
    args = parser.parse_args()
    require(args.execute, "Preparation only: explicit --execute is required after binding ready")
    require(SHA.fullmatch(args.expected_binding_sha256) is not None and SHA.fullmatch(args.expected_binary_sha256) is not None,
            "expected hashes must be exact lowercase SHA256")
    require(SHA.fullmatch(OWNED_APK_HELPER_SHA256) is not None, "owned APK helper is not frozen")
    sys.dont_write_bytecode = True
    os.umask(0o077)
    os.environ["PYTHONDONTWRITEBYTECODE"] = "1"
    RUN.mkdir(mode=0o700, exist_ok=False)
    summary = {"schema": "hepta.rea.c25.provider-gates.v1", "status": "running", "qualified": False,
               "source_commit": COMMIT, "source_git_tree": GIT_TREE, "started_at": now(),
               "expected_binding_sha256": args.expected_binding_sha256,
               "expected_binary_sha256": args.expected_binary_sha256,
               "automatic_retry": False, "stages": [], "rea_full_parity": False, "production_qualified": False,
               "native_gdb_lldb_adapter_qualified": False,
               "historical_receipts_used_as_current_results": False,
               "original_chrome_proc_failure_preserved":
                 "/home/qian-qi/work/hepta-rea-p0p5-679ccf-chrome-causal-mcp-20261105-r1/qualification.json"}
    save(RUN / "summary.json", summary)
    monitor, selection, before = None, None, None
    try:
        summary["git_before"] = git_identity()
        summary["host_before"] = host_identity()
        summary["current_inventory"] = reference(INVENTORY)
        summary["driver"] = reference(Path(__file__).resolve())
        source_pins = pinned_sources()
        save(RUN / "source-script-pins.json", source_pins)
        require(identity(OWNED_APK_HELPER)["sha256"] == OWNED_APK_HELPER_SHA256, "owned generated APK helper changed")
        sys.path.insert(0, str(REPO / "scripts"))
        matrix_module = importlib.import_module("rea_full_qualification")
        consumer = importlib.import_module("rea_build_evidence")
        selection = matrix_module.Selection(REPO, TARGET, MATRIX)
        monitor = matrix_module.SourceMonitor(selection)
        monitor.start()
        before = selection.snapshot()
        save(RUN / "source-before.json", before)
        binding, validation = validate_binding(args, selection, consumer)
        save(RUN / "binding-consumer-recomputed.json", validation)
        summary["binding"] = reference(BINDING)
        summary["runtime"] = reference(BINARY)
        summary["disk_before"] = check_disk(3 * binding["runtime"]["bytes"] + 768 * MIB)
        plan = stage_plan(args.expected_binary_sha256)
        save(RUN / "plan.json", plan)
        env = dict(os.environ, PYTHONDONTWRITEBYTECODE="1", PYTHONNOUSERSITE="1", LC_ALL="C", PATH="/usr/bin:/bin")
        for key in ("PYTHONPATH", "PYTHONHOME", "LD_PRELOAD", "LD_LIBRARY_PATH", "NODE_OPTIONS", "NODE_PATH",
                    "JAVA_TOOL_OPTIONS", "JDK_JAVA_OPTIONS", "_JAVA_OPTIONS"):
            env.pop(key, None)
        for stage in plan:
            directory = Path(stage["directory"])
            directory.mkdir(mode=0o700)
            inputs = None
            row = {"name": stage["name"], "status": "running", "qualified": False}
            summary["stages"].append(row)
            save(RUN / "summary.json", summary)
            needed = binding["runtime"]["bytes"] + 128 * MIB if stage["kind"] == "engine" else 128 * MIB
            row["disk_before"] = check_disk(needed)
            stage_sources = selection.snapshot()
            require(stage_sources == before and git_identity() == summary["git_before"], "source changed before provider gate")
            require(reference(BINARY) == binding["runtime"], "runtime changed before provider gate")
            inputs = installation_inputs(stage["name"])
            save(directory / "inputs-before.json", inputs)
            stage_env = dict(env, TMPDIR=str(directory / "tmp"))
            Path(stage_env["TMPDIR"]).mkdir(mode=0o700)
            if stage["name"] in ("apk-three-way", "apk-generated"):
                stage_env.update(JAVA_HOME=str(JDK21), PATH=str(JDK21 / "bin") + ":/usr/bin:/bin")
                for key in ("JAVA_TOOL_OPTIONS", "JDK_JAVA_OPTIONS", "_JAVA_OPTIONS"):
                    stage_env.pop(key, None)
            row["selected_environment"] = {key: stage_env.get(key) for key in
                ("PATH", "JAVA_HOME", "LC_ALL", "PYTHONDONTWRITEBYTECODE", "PYTHONNOUSERSITE", "TMPDIR")}
            row["process"] = run_process(stage, stage_env)
            workspace = directory / "workspace"
            report_path = directory / "qualification.json" if stage["kind"] == "oracle" else workspace / "qualification.json"
            report = read_json(report_path)
            if stage["kind"] == "engine":
                row["result"] = validate_engine(stage["name"], workspace, report, args.expected_binary_sha256)
                row["original_terminals"] = collect_terminals(stage["name"], workspace, directory / "original-terminals", report)
            elif stage["kind"] == "oracle":
                row["result"] = validate_apk_oracle(report, args.expected_binary_sha256)
            elif stage["kind"] == "mcp":
                row["result"] = validate_apk_mcp(report, args.expected_binary_sha256)
            else:
                require(report.get("qualified") is True and report.get("status") == "passed"
                        and report.get("schema") == "hepta.rea.owned-aapt2-apk-two-workers.v1",
                        "generated APK helper did not qualify")
                require(report.get("runtime_sha256") == args.expected_binary_sha256, "generated APK helper binary differs")
                require(report.get("checks") == ["frozen_source_binary_and_configured_installation_closure_bound","actual_aapt2_binary_manifest_and_resources_generated","owned_pkcs12_key_and_real_android_v1_v2_v3_signing","actual_apksigner_accepts_signed_apk_with_v2_and_v3","same_binary_structural_signed_preview_is_partial_not_cryptographic","same_binary_native_signed_v2_v3_records_verified","exact_manifest_payload_single_byte_tamper_preserves_archive_structure","actual_apksigner_rejects_tampered_signed_apk","same_binary_structural_tampered_preview_remains_partial","same_binary_native_tamper_is_invalid_with_matching_signature_and_digest_mismatch","truncated_real_apk_native_worker_rejects_without_success_stdout","binary_source_installation_and_generated_inputs_unchanged_after_checks","all_fourteen_original_children_exited_reaped_and_output_complete","owned_output_remains_below_sixty_four_mib"], "generated APK exact checks differ")
                expected_commands = ["source-commit-tree", "aapt2-version", "aapt2-compile", "aapt2-link",
                    "keytool-owned-pkcs12", "apksigner-sign", "apksigner-verify-signed", "worker-preview-signed",
                    "worker-native-signed", "apksigner-verify-tampered", "worker-preview-tampered",
                    "worker-native-tampered", "worker-native-truncated", "source-commit-tree-after"]
                command_rows = report["commands"]
                require(len(command_rows) == report["expected_original_command_count"] == 14
                        and [item["name"] for item in command_rows] == expected_commands,
                        "generated APK original child set/count differs")
                for command in command_rows:
                    expected_refusal = command["name"] in {"apksigner-verify-tampered", "worker-native-truncated"}
                    require(type(command["exit_code"]) is int
                            and (command["exit_code"] > 0 if expected_refusal else command["exit_code"] == 0)
                            and command["wait_reaped"] is True and command["output_complete"] is True
                            and command["timed_out"] is False and command["manual_cleanup"] == []
                            and command["launch_error"] is None, "generated APK original child terminal incomplete")
                    require(command["stdin"]["bytes"] == command["stdin"]["written_bytes"],
                            "generated APK original child did not receive all input bytes")
                    for stream in ("stdout", "stderr"):
                        log = command["logs"][stream]
                        path = Path(log["path"])
                        require(path.is_relative_to(workspace) and log["eof"] is True
                                and log["truncated"] is False and log["seen"] == log["stored"] == log["bytes"]
                                and reference(path)["sha256"] == log["sha256"], "generated APK original child log differs")
                    receipt = command["receipt"]
                    require(Path(receipt["path"]).is_relative_to(workspace)
                            and reference(Path(receipt["path"]))["sha256"] == receipt["sha256"],
                            "generated APK immutable original command receipt differs")
                require(report["full_android_verification"] is False and report["rea_evidence_compatibility"] is False
                        and report["devices_contacted"] is False and report["apk_payloads_executed"] is False,
                        "generated APK finite scope changed")
                row["result"] = {"checks": len(report["checks"]), "original_child_terminals": 14,
                                 "ordinary_positive_exits": 12, "actual_refusal_exits": 2,
                                 "report": reference(report_path)}
            row["qualification"] = reference(report_path)
            after_inputs = installation_inputs(stage["name"])
            save(directory / "inputs-after.json", after_inputs)
            require(after_inputs == inputs, "actual installation/fixture/executable changed during gate")
            require(reference(BINARY) == binding["runtime"] and reference(BINDING)["sha256"] == args.expected_binding_sha256,
                    "frozen binary/binding changed during gate")
            require(selection.snapshot() == before, "source bytes changed during gate")
            save(directory / "artifacts.json", artifact_inventory(directory))
            row.update(status="passed", qualified=True, artifact_inventory=reference(directory / "artifacts.json"))
            save(RUN / "summary.json", summary)
            print(json.dumps({"stage": stage["name"], "status": "passed", "result": row["result"]}), flush=True)
        require(len(summary["stages"]) == 6 and all(row["qualified"] for row in summary["stages"]), "provider sequence incomplete")
        summary["status"] = "passed"
    except BaseException as error:
        summary["status"] = "failed"
        summary["failure"] = {"type": type(error).__name__, "message": str(error)}
        if summary["stages"] and summary["stages"][-1]["status"] == "running":
            failed = summary["stages"][-1]
            failed.update(status="failed", qualified=False, failure=summary["failure"])
            failed["post_failure_observation_errors"] = []
            if (directory / "process.json").exists():
                failed["process"] = read_json(directory / "process.json")
            try:
                if inputs is not None:
                    observed = installation_inputs(stage["name"])
                    save(directory / "inputs-after-failure.json", observed)
                    failed["inputs_unchanged_after_failure"] = observed == inputs
                else:
                    failed["input_inventory_unavailable_before_launch"] = True
            except BaseException as observation_error:
                failed["post_failure_observation_errors"].append(str(observation_error))
            try:
                save(directory / "artifacts-after-failure.json", artifact_inventory(directory))
                failed["artifact_inventory_after_failure"] = reference(directory / "artifacts-after-failure.json")
            except BaseException as observation_error:
                failed["post_failure_observation_errors"].append(str(observation_error))
            failed["engine_or_gate_retry_performed"] = False
        raise
    finally:
        finalization_errors = []
        try:
            if selection is not None:
                after = selection.snapshot()
                save(RUN / "source-after.json", after)
                summary["source_bytes_unchanged"] = before == after
        except BaseException as error:
            finalization_errors.append({"step": "source-after", "type": type(error).__name__, "message": str(error)})
        finally:
            if monitor is not None:
                try:
                    events = monitor.stop()
                    save(RUN / "source-events.json", events)
                    summary["source_monitor_complete"] = events == {
                        "event_count": 0, "retained_events": [], "events_truncated": False, "errors": []}
                except BaseException as error:
                    finalization_errors.append({"step": "source-monitor", "type": type(error).__name__, "message": str(error)})
        try:
            summary["git_after"] = git_identity()
            summary["source_git_unchanged"] = summary.get("git_before") == summary["git_after"]
            summary["host_after"] = host_identity()
            summary["host_unchanged"] = summary.get("host_before") == summary["host_after"]
            summary["binding_unchanged"] = reference(BINDING)["sha256"] == args.expected_binding_sha256
            summary["runtime_unchanged"] = reference(BINARY)["sha256"] == args.expected_binary_sha256
            summary["driver_unchanged"] = summary.get("driver") == reference(Path(__file__).resolve())
        except BaseException as error:
            finalization_errors.append({"step": "final-identities", "type": type(error).__name__, "message": str(error)})
        summary["qualified"] = summary["status"] == "passed" and not finalization_errors and all(
            summary.get(key) is True for key in
            ("source_bytes_unchanged", "source_monitor_complete", "source_git_unchanged", "host_unchanged",
             "binding_unchanged", "runtime_unchanged", "driver_unchanged"))
        if finalization_errors:
            summary["finalization_errors"] = finalization_errors
        if not summary["qualified"] and summary["status"] == "passed":
            summary["status"] = "invalid"
        summary["finished_at"] = now()
        save(RUN / "summary.json", summary)
        print(json.dumps({"provider_gates": summary["status"], "qualified": summary["qualified"],
                          "summary": reference(RUN / "summary.json")}), flush=True)
    return 0 if summary["qualified"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
