#!/usr/bin/env python3
"""Owned real APK producer/oracle gate for the frozen c25 candidate.

This file is prepared outside the source checkout. It is inert until explicitly
invoked with a pinned binary and a fresh output directory. It never builds Rust,
installs software/APKs, contacts devices, attaches to another process, or executes
APK payloads. All subprocesses are owned children; failures are retained and are
never retried. Exact commands, complete bounded output and wait/reap results are
recorded before expectations are evaluated.
"""
from __future__ import annotations

import argparse
import datetime as dt
import hashlib
import json
import os
from pathlib import Path
import re
import resource
import selectors
import signal
import stat
import struct
import subprocess
import sys
import time
import zipfile

sys.dont_write_bytecode = True

REPO = Path("/home/qian-qi/work/hepta-rea-p0p5-679ccf-20261105")
EVIDENCE = Path(str(REPO) + "-evidence")
SOURCE_COMMIT = "c25e4cef0610816bfd1263b69d3dd63e4114aa49"
SOURCE_TREE = "c6db025f5902570bd63520751cf84c57505eb6f4"
WORKFLOW = REPO / ".github/workflows/rea-real-apk.yml"
WORKFLOW_SHA = "528e604a4622ea5b32e7d50cd21c150465101aeb0868a7f7060b796067fae254"
SDK = Path("/opt/android-sdk/build-tools/35.0.1")
PLATFORM = Path("/opt/android-sdk/platforms/android-35/android.jar")
JAVA = Path("/usr/lib/jvm/java-21-openjdk-amd64")
MAX_OUTPUT = 64 * 1024 * 1024
MAX_FILE = 8 * 1024 * 1024
MAX_STREAM = 1024 * 1024
SHA = re.compile(r"[0-9a-f]{64}")

SOURCE_FILES = (
    ".github/workflows/rea-real-apk.yml", "Cargo.toml", "Cargo.lock",
    "src/main.rs", "src/cli.rs", "src/mcp/rea_zip.rs",
    "src/mcp/rea_apk_signature.rs", "src/mcp/rea_apk_signature_parser.rs",
    "src/mcp/rea_apk_signature_worker.rs",
)
INSTALL_PINS = {
    str(SDK / "aapt2"): "5bca541bb691be2783137821b4304beabdf02daacd159ae56e1a4a3a52980637",
    str(SDK / "apksigner"): "b47549e373b895ce6ca620d0c7887e674d9615ffa837a86ac601dcfd04adb0f0",
    str(SDK / "lib/apksigner.jar"): "00ef9948f843fe395d2440ae3ef41405b8040a6d5d46493bd1902ac0ee6deae7",
    str(PLATFORM): "4566663c3876e022b4fa4ced8c8697c4ab1688267f090114fd92d027b32e619b",
    str(JAVA / "release"): "b9e13ce6cefa91fdda9f7fe0ac88ddd34dc8b3c37c791667a579d16b1dae702d",
}
JDK_CORE = (
    "release", "bin/java", "bin/keytool", "lib/modules",
    "lib/server/libjvm.so", "lib/libjava.so", "lib/libzip.so", "lib/libnio.so",
    "lib/libjli.so", "lib/libjimage.so", "lib/libnet.so", "lib/libverify.so",
    "lib/libsunec.so", "conf/security/java.security",
)
CHECKS = [
    "frozen_source_binary_and_configured_installation_closure_bound",
    "actual_aapt2_binary_manifest_and_resources_generated",
    "owned_pkcs12_key_and_real_android_v1_v2_v3_signing",
    "actual_apksigner_accepts_signed_apk_with_v2_and_v3",
    "same_binary_structural_signed_preview_is_partial_not_cryptographic",
    "same_binary_native_signed_v2_v3_records_verified",
    "exact_manifest_payload_single_byte_tamper_preserves_archive_structure",
    "actual_apksigner_rejects_tampered_signed_apk",
    "same_binary_structural_tampered_preview_remains_partial",
    "same_binary_native_tamper_is_invalid_with_matching_signature_and_digest_mismatch",
    "truncated_real_apk_native_worker_rejects_without_success_stdout",
    "binary_source_installation_and_generated_inputs_unchanged_after_checks",
    "all_fourteen_original_children_exited_reaped_and_output_complete",
    "owned_output_remains_below_sixty_four_mib",
]


def require(value, message):
    if not value:
        raise RuntimeError(message)


def now():
    return dt.datetime.now(dt.timezone.utc).isoformat()


def sha(data):
    return hashlib.sha256(data).hexdigest()


def json_bytes(value):
    return (json.dumps(value, indent=2, sort_keys=True, ensure_ascii=True,
                       allow_nan=False) + "\n").encode()


def write_new(path, data):
    data = data if isinstance(data, bytes) else json_bytes(data)
    with path.open("xb") as handle:
        handle.write(data)
        handle.flush()
        os.fsync(handle.fileno())


def publish(path, value):
    temporary = path.with_name("." + path.name + ".next")
    encoded = json_bytes(value)
    require(len(encoded) < MAX_STREAM, "qualification record exceeds its reserved one-MiB budget")
    write_new(temporary, encoded)
    os.replace(temporary, path)
    fd = os.open(path.parent, os.O_RDONLY | os.O_CLOEXEC | os.O_DIRECTORY)
    try:
        os.fsync(fd)
    finally:
        os.close(fd)


def file_identity(path):
    invoked = Path(path).absolute()
    resolved = invoked.resolve(strict=True)
    fd = os.open(resolved, os.O_RDONLY | os.O_CLOEXEC | os.O_NOFOLLOW | os.O_NONBLOCK)
    with os.fdopen(fd, "rb") as stream:
        before = os.fstat(stream.fileno())
        require(stat.S_ISREG(before.st_mode), "input is not a regular file: " + str(invoked))
        value = hashlib.sha256()
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            value.update(block)
        after = os.fstat(stream.fileno())
    current = resolved.stat()
    fields = ("st_dev", "st_ino", "st_size", "st_mode", "st_uid", "st_gid",
              "st_nlink", "st_mtime_ns", "st_ctime_ns")
    require(all(getattr(before, key) == getattr(after, key) == getattr(current, key)
                for key in fields), "input changed while hashing: " + str(invoked))
    return {"path": str(invoked), "resolved": str(resolved), "bytes": before.st_size,
            "sha256": value.hexdigest(),
            "metadata": {key.removeprefix("st_"): getattr(before, key) for key in fields}}


def output_inventory(root):
    rows = []
    total = 0
    for directory, subdirs, files in os.walk(root, followlinks=False):
        for name in subdirs:
            require(not (Path(directory) / name).is_symlink(), "owned output directory became a symlink")
        for name in files:
            path = Path(directory) / name
            require(not path.is_symlink(), "owned output file became a symlink")
            item = path.stat()
            require(stat.S_ISREG(item.st_mode) and item.st_nlink == 1,
                    "owned output is not a private regular file")
            total += item.st_size
            require(total < MAX_OUTPUT, "owned output reached the 64 MiB budget")
            rows.append({"path": str(path.relative_to(root)), "bytes": item.st_size})
    return {"files": sorted(rows, key=lambda row: row["path"]), "total_bytes": total,
            "maximum_bytes_exclusive": MAX_OUTPUT}


def closure(binary):
    install = [
        SDK / "aapt2", SDK / "apksigner", SDK / "lib/apksigner.jar",
        SDK / "source.properties", PLATFORM, PLATFORM.parent / "source.properties",
        *(JAVA / name for name in JDK_CORE),
        Path("/bin/bash"), Path("/usr/bin/expr"), Path("/usr/bin/dirname"),
        Path("/usr/bin/basename"), Path("/usr/bin/git"), Path(sys.executable),
    ]
    install = sorted(set(install), key=str)
    result = {
        "binary": file_identity(binary),
        "helper": file_identity(Path(__file__)),
        "sources": {name: file_identity(REPO / name) for name in SOURCE_FILES},
        "installation": {str(path): file_identity(path) for path in install},
        "python": sys.version,
        "installation_scope": (
            "Exact configured AAPT2/apksigner/platform files, launcher shell utilities "
            "and JDK core byte inputs; this is not an attestation of the whole OS/shared-library loader."
        ),
    }
    require(result["sources"][".github/workflows/rea-real-apk.yml"]["sha256"] == WORKFLOW_SHA,
            "reviewed source workflow changed")
    for name, expected in INSTALL_PINS.items():
        require(result["installation"][name]["sha256"] == expected, "installation pin differs: " + name)
    revision = (SDK / "source.properties").read_text()
    require("Pkg.Revision=35.0.1" in revision.splitlines(), "unexpected Android build-tools revision")
    return result


def read_json(path):
    def members(items):
        result = {}
        for key, value in items:
            require(key not in result, "duplicate JSON member in " + str(path))
            result[key] = value
        return result
    raw = path.read_bytes()
    require(0 < len(raw) <= MAX_STREAM, "JSON output is empty or exceeds one MiB")
    return json.loads(raw, object_pairs_hook=members,
                      parse_constant=lambda token: (_ for _ in ()).throw(
                          RuntimeError("non-finite JSON number: " + token)))


def child_limits():
    resource.setrlimit(resource.RLIMIT_CORE, (0, 0))
    resource.setrlimit(resource.RLIMIT_FSIZE, (MAX_FILE, MAX_FILE))


class Commands:
    def __init__(self, root, record, environment):
        self.root, self.record, self.environment = root, record, environment
        self.directory = root / "commands"
        self.directory.mkdir(mode=0o700)

    def run(self, name, argv, *, timeout=60, data=None, input_path=None, worker=False):
        require(1 <= timeout <= 120, "invalid per-command timeout")
        output_inventory(self.root)
        index = len(self.record["commands"]) + 1
        prefix = self.directory / f"{index:02d}-{name}"
        stdout_path = prefix.with_suffix(".stdout")
        stderr_path = prefix.with_suffix(".stderr")
        receipt_path = prefix.with_suffix(".receipt.json")
        environment = {} if worker else self.environment
        cwd = "/" if worker else str(self.root)
        row = {
            "name": name, "argv": [str(arg) for arg in argv], "cwd": cwd,
            "environment": environment, "timeout_seconds": timeout,
            "started_at": now(), "stdin": {
                "source": str(input_path) if input_path is not None else None,
                "mode": "pipe" if data is not None else "devnull",
                "bytes": len(data) if data is not None else 0,
                "sha256": sha(data or b""), "written_bytes": 0,
            },
            "state": "launching", "exit_code": None, "pid": None,
            "wait_reaped": False, "timed_out": False, "output_complete": False,
            "manual_cleanup": [], "launch_error": None,
        }
        streams = {
            "stdout": {"seen": 0, "stored": 0, "eof": False, "truncated": False},
            "stderr": {"seen": 0, "stored": 0, "eof": False, "truncated": False},
        }
        started = time.monotonic()
        process = None
        selector = selectors.DefaultSelector()
        problem = None
        handles = {}
        try:
            handles = {"stdout": stdout_path.open("xb"), "stderr": stderr_path.open("xb")}
            process = subprocess.Popen(
                row["argv"], cwd=cwd, env=environment, stdin=subprocess.PIPE if data is not None else subprocess.DEVNULL,
                stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                start_new_session=True, preexec_fn=child_limits,
            )
            row["pid"] = process.pid
            row["state"] = "running"
            for stream in ("stdout", "stderr"):
                pipe = getattr(process, stream)
                os.set_blocking(pipe.fileno(), False)
                selector.register(pipe, selectors.EVENT_READ, stream)
            sent = 0
            if data is not None:
                if data:
                    os.set_blocking(process.stdin.fileno(), False)
                    selector.register(process.stdin, selectors.EVENT_WRITE, "stdin")
                else:
                    process.stdin.close()
            deadline = started + timeout
            draining_deadline = None
            while selector.get_map():
                current = time.monotonic()
                if draining_deadline is None and current >= deadline:
                    problem = "original command exceeded its fixed timeout"
                    row["timed_out"] = True
                if problem is not None and draining_deadline is None:
                    # The unreaped Popen child retains custody of its session-leader PID.
                    try:
                        os.killpg(process.pid, signal.SIGKILL)
                        row["manual_cleanup"].append("owned_process_group_sigkill_after_failure")
                    except ProcessLookupError:
                        pass
                    draining_deadline = current + 5
                if draining_deadline is not None and current >= draining_deadline:
                    break
                for key, _events in selector.select(0.05):
                    if key.data == "stdin":
                        try:
                            sent += os.write(key.fd, data[sent:sent + 65536])
                            row["stdin"]["written_bytes"] = sent
                        except BrokenPipeError:
                            problem = "original child closed stdin before receiving the complete fixture"
                            selector.unregister(key.fileobj)
                            key.fileobj.close()
                            continue
                        except BlockingIOError:
                            continue
                        if sent == len(data):
                            selector.unregister(key.fileobj)
                            key.fileobj.close()
                    else:
                        try:
                            chunk = os.read(key.fd, 65536)
                        except BlockingIOError:
                            continue
                        observed = streams[key.data]
                        if not chunk:
                            observed["eof"] = True
                            selector.unregister(key.fileobj)
                            key.fileobj.close()
                            continue
                        observed["seen"] += len(chunk)
                        keep = chunk[:max(0, MAX_STREAM - observed["stored"])]
                        handles[key.data].write(keep)
                        observed["stored"] += len(keep)
                        if len(keep) != len(chunk):
                            observed["truncated"] = True
                            problem = "original command exceeded its one-MiB output stream budget"
                if draining_deadline is None:
                    try:
                        output_inventory(self.root)
                    except BaseException as error:
                        problem = str(error)
            if process is not None:
                try:
                    process.wait(timeout=max(0.01, deadline - time.monotonic()) if problem is None else 5)
                except subprocess.TimeoutExpired:
                    row["timed_out"] = True
                    problem = problem or "original child remained alive after closing its output"
                    try:
                        os.killpg(process.pid, signal.SIGKILL)
                        row["manual_cleanup"].append("owned_process_group_sigkill_after_failure")
                    except ProcessLookupError:
                        pass
                    process.wait(timeout=5)
                row["exit_code"] = process.returncode
                row["wait_reaped"] = True
        except BaseException as error:
            problem = problem or (type(error).__name__ + ": " + str(error))
            if process is None:
                row["launch_error"] = problem
            elif process.returncode is None:
                try:
                    os.killpg(process.pid, signal.SIGKILL)
                    row["manual_cleanup"].append("owned_process_group_sigkill_after_failure")
                except ProcessLookupError:
                    pass
                process.wait(timeout=5)
                row["exit_code"] = process.returncode
                row["wait_reaped"] = True
        finally:
            for key in list(selector.get_map().values()):
                selector.unregister(key.fileobj)
                key.fileobj.close()
            selector.close()
            for handle in handles.values():
                handle.flush()
                os.fsync(handle.fileno())
                handle.close()
            row["finished_at"] = now()
            row["duration_seconds"] = time.monotonic() - started
            row["output_complete"] = all(value["eof"] and not value["truncated"] for value in streams.values())
            row["state"] = "timed_out" if row["timed_out"] else (
                "succeeded" if problem is None and row["exit_code"] == 0 else "failed")
            if problem is not None:
                row["failure"] = problem
            row["logs"] = {}
            for name_, path in (("stdout", stdout_path), ("stderr", stderr_path)):
                if path.exists():
                    row["logs"][name_] = {**file_identity(path), **streams[name_]}
            write_new(receipt_path, row)
            self.record["commands"].append({**row, "receipt": file_identity(receipt_path)})
            publish(self.root / "qualification.json", self.record)
        require(problem is None, name + ": " + str(problem))
        require(row["wait_reaped"] and row["output_complete"] and not row["manual_cleanup"],
                name + ": original child/complete-output custody was not confirmed")
        return row, stdout_path, stderr_path

    def success(self, name, argv, **kwargs):
        row, stdout, stderr = self.run(name, argv, **kwargs)
        require(row["exit_code"] == 0, name + ": exit " + str(row["exit_code"]))
        return row, stdout, stderr


def check_preview(path, data):
    report = read_json(path)
    require(isinstance(report, dict) and report, "empty/non-object structural preview")
    require(report["rea_evidence_compatible"] is False, "structural preview claimed Evidence compatibility")
    require(report["coverage"]["status"] == "partial", "structural preview lost its partial boundary")
    require(report["subject"]["sha256"] == sha(data), "structural preview source digest differs")
    require(report["normalized_result"]["format"] == "zip", "structural preview did not identify ZIP")
    facts = report["normalized_result"]["header_facts"]
    require(facts["apk_signing_block_structure_present"] is True and facts["apk_v2_scheme_id_present"] is True,
            "structural signing-block markers were not observed")
    require("NOT cryptographic" in " ".join(report["limitations"]),
            "structural preview omitted its no-cryptographic-verification limitation")
    return report


def check_native(path, data, expected):
    report = read_json(path)
    require(isinstance(report, dict) and report.get("record_format") == "hepta.rea-apk-signature.v1",
            "empty or wrong native record profile")
    require(report["source"]["sha256"] == sha(data) and report["source"]["byte_length"] == len(data),
            "native report is not bound to the exact input")
    require(report["rea_evidence_compatible"] is False and
            report["verification"]["complete_android_verification"] is False,
            "native finite contract was widened")
    require(report["verification"]["v2_v3_records"] == expected, "native v2/v3 record verdict differs")
    require(report["signing_block"]["present"] is True, "native signing block absent")
    signers = report["signers"]
    require(isinstance(signers, list) and len(signers) == 2 and
            {row["scheme"] for row in signers} == {"v2", "v3"}, "expected exactly one v2 and one v3 signer")
    for signer in signers:
        require(signer["status"] == expected and signer["certificate_public_key_binding"] == "match",
                "signer status or certificate SPKI binding differs")
        algorithms = signer["algorithms"]
        require(isinstance(algorithms, list) and algorithms, "native signer has no observed algorithm")
        require(all(row["signature_status"] == "verified" and
                    row["content_digest_status"] == ("match" if expected == "verified" else "mismatch")
                    for row in algorithms), "native signature/digest distinction differs")
    return report


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--binary", required=True, type=Path)
    parser.add_argument("--expected-binary-sha256", required=True)
    parser.add_argument("--output", required=True, type=Path)
    args = parser.parse_args()
    require(sys.platform.startswith("linux"), "Linux host required")
    require(args.binary.is_absolute() and args.output.is_absolute(), "absolute input/output paths required")
    require(re.fullmatch(r"/[A-Za-z0-9_./-]+", str(args.output)) is not None,
            "output path must use the reviewed plain absolute-path profile")
    require(SHA.fullmatch(args.expected_binary_sha256) is not None, "expected binary SHA256 is invalid")
    binary = args.binary.resolve(strict=True)
    parent = args.output.parent.resolve(strict=True)
    root = parent / args.output.name
    require(root.is_relative_to(EVIDENCE.resolve(strict=True)) and root != EVIDENCE,
            "all new files must be below the designated evidence directory")
    require(not root.is_relative_to(REPO), "output cannot overlap the frozen source checkout")
    def interrupted(signum, _frame):
        raise RuntimeError("owned APK qualification interrupted by signal " + str(signum))
    signal.signal(signal.SIGTERM, interrupted)
    os.umask(0o077)
    root.mkdir(mode=0o700, exist_ok=False)
    record = {
        "schema": "hepta.rea.owned-aapt2-apk-two-workers.v1",
        "status": "running", "qualified": False, "started_at": now(),
        "source_commit": SOURCE_COMMIT, "source_git_tree": SOURCE_TREE,
        "workflow_sha256": WORKFLOW_SHA, "sdk_build_tools": "35.0.1",
        "expected_binary_sha256": args.expected_binary_sha256, "runtime_sha256": None,
        "source_workflow_build_tools": "35.0.0",
        "actual_configuration": "Existing pinned 35.0.1 SDK with existing JDK 21; no installation/build.",
        "checks": [], "commands": [], "expected_check_names": CHECKS,
        "expected_original_command_count": 14,
        "rea_full_parity": False, "production_qualified": False,
        "full_android_verification": False, "rea_evidence_compatibility": False,
        "apk_payloads_executed": False, "devices_contacted": False,
        "scope": "Owned real AAPT2/APK signatures and same-binary finite worker behavior; no device, trust, installation or full REA contract.",
    }
    publish(root / "qualification.json", record)
    before = None
    inputs = {}
    record["generated_input_observations_before_use"] = inputs
    try:
        before = closure(binary)
        record["runtime_sha256"] = before["binary"]["sha256"]
        require(record["runtime_sha256"] == args.expected_binary_sha256, "binary differs before execution")
        write_new(root / "inputs-before.json", before)
        record["inputs_before"] = file_identity(root / "inputs-before.json")
        for name in ("home", "tmp", "res", "compiled", "keystore"):
            (root / name).mkdir(mode=0o700)
        (root / "res/values").mkdir(mode=0o700)
        environment = {
            "PATH": str(JAVA / "bin") + ":/usr/bin:/bin", "JAVA_HOME": str(JAVA),
            "HOME": str(root / "home"), "TMPDIR": str(root / "tmp"),
            "JAVA_TOOL_OPTIONS": "-XX:-UsePerfData -Djava.io.tmpdir=" + str(root / "tmp") + " -Duser.home=" + str(root / "home"),
            "LC_ALL": "C", "TZ": "UTC", "GIT_OPTIONAL_LOCKS": "0",
        }
        write_new(root / "execution-environment.json", environment)
        commands = Commands(root, record, environment)
        _row, git_out, _err = commands.success(
            "source-commit-tree", ["/usr/bin/git", "-C", str(REPO), "rev-parse", "HEAD", "HEAD^{tree}"], timeout=15)
        require(git_out.read_text().splitlines() == [SOURCE_COMMIT, SOURCE_TREE], "source commit/tree changed")
        record["checks"].append(CHECKS[0])
        _row, version_out, _err = commands.success("aapt2-version", [SDK / "aapt2", "version"], timeout=15)
        record["actual_aapt2_version"] = version_out.read_text().strip()
        require(record["actual_aapt2_version"].startswith("Android Asset Packaging Tool"),
                "actual AAPT2 version output is absent or unexpected")
        manifest = b"""<manifest xmlns:android="http://schemas.android.com/apk/res/android"
    package="org.trillionnium.rea.smoke"
    android:versionCode="1" android:versionName="1">
    <uses-sdk android:minSdkVersion="24" android:targetSdkVersion="35" />
    <application android:label="@string/app_name" android:hasCode="false" />
</manifest>
"""
        strings = b"""<resources>
    <string name="app_name">REA real APK signing reference</string>
</resources>
"""
        write_new(root / "AndroidManifest.xml", manifest)
        write_new(root / "res/values/strings.xml", strings)
        inputs.update({name: file_identity(root / name) for name in (
            "AndroidManifest.xml", "res/values/strings.xml", "execution-environment.json")})
        commands.success("aapt2-compile", [SDK / "aapt2", "compile", "--dir", root / "res", "-o", root / "compiled"], timeout=60)
        flat = root / "compiled/values_strings.arsc.flat"
        require(flat.is_file() and flat.stat().st_size > 0, "actual AAPT2 compiled flat output missing")
        inputs[str(flat.relative_to(root))] = file_identity(flat)
        unsigned = root / "unsigned.apk"
        commands.success("aapt2-link", [
            SDK / "aapt2", "link", "--auto-add-overlay", "-o", unsigned, "-I", PLATFORM,
            "--manifest", root / "AndroidManifest.xml", "-R", flat], timeout=60)
        with zipfile.ZipFile(unsigned) as archive:
            require({"AndroidManifest.xml", "resources.arsc"} <= set(archive.namelist()), "real resource APK members missing")
            require(archive.testzip() is None, "generated APK CRC check failed")
            require(not archive.read("AndroidManifest.xml").lstrip().startswith(b"<"),
                    "AAPT2 did not compile a binary Android manifest")
        inputs[str(unsigned.relative_to(root))] = file_identity(unsigned)
        record["checks"].append(CHECKS[1])
        key = root / "keystore/test-only.p12"
        commands.success("keytool-owned-pkcs12", [
            JAVA / "bin/keytool", "-genkeypair", "-noprompt", "-storetype", "PKCS12",
            "-keystore", key, "-storepass", "changeit", "-keypass", "changeit",
            "-alias", "rea-fixture", "-keyalg", "RSA", "-keysize", "2048", "-validity", "30",
            "-dname", "CN=REA isolated CI fixture, O=TrillionniumFoundation"], timeout=120)
        inputs[str(key.relative_to(root))] = file_identity(key)
        signed = root / "real-signed.apk"
        commands.success("apksigner-sign", [
            SDK / "apksigner", "sign", "--ks", key, "--ks-pass", "pass:changeit", "--key-pass", "pass:changeit",
            "--min-sdk-version", "24", "--v1-signing-enabled", "true", "--v2-signing-enabled", "true",
            "--v3-signing-enabled", "true", "--v4-signing-enabled", "false", "--out", signed, unsigned], timeout=120)
        inputs[str(signed.relative_to(root))] = file_identity(signed)
        record["checks"].append(CHECKS[2])
        _row, verify_out, _err = commands.success("apksigner-verify-signed", [
            SDK / "apksigner", "verify", "--verbose", "--print-certs", "--min-sdk-version", "24", signed], timeout=60)
        verify_text = verify_out.read_text()
        for scheme in ("v2", "v3"):
            require(f"Verified using {scheme} scheme (APK Signature Scheme {scheme}): true" in verify_text,
                    "actual Android verifier did not confirm " + scheme)
        record["checks"].append(CHECKS[3])
        clean = signed.read_bytes()
        require(0 < len(clean) < MAX_FILE, "real signed APK exceeds this fixture's eight-MiB allowance")
        _row, preview_clean, preview_err = commands.success(
            "worker-preview-signed", [binary, "rea-worker", "--selected-path=/controlled/real-signed.apk"],
            timeout=60, data=clean, input_path=signed, worker=True)
        require(preview_err.stat().st_size == 0, "signed structural worker emitted diagnostics")
        check_preview(preview_clean, clean)
        record["checks"].append(CHECKS[4])
        _row, native_clean, native_err = commands.success(
            "worker-native-signed", [binary, "rea-apk-signature-worker"],
            timeout=35, data=clean, input_path=signed, worker=True)
        require(native_err.stat().st_size == 0, "signed native worker emitted diagnostics")
        check_native(native_clean, clean, "verified")
        record["checks"].append(CHECKS[5])
        with zipfile.ZipFile(signed) as archive:
            member = archive.getinfo("AndroidManifest.xml")
            require(archive.testzip() is None and member.compress_size > 0, "signed APK is already damaged")
        local = member.header_offset
        changed = bytearray(clean)
        require(changed[local:local + 4] == b"PK\x03\x04", "manifest local header missing")
        name_len, extra_len = struct.unpack_from("<HH", changed, local + 26)
        offset = local + 30 + name_len + extra_len
        require(offset < len(changed) and offset + member.compress_size <= len(changed), "manifest payload extent invalid")
        old_byte = changed[offset]
        changed[offset] ^= 1
        corrupt = bytes(changed)
        require(len(clean) == len(corrupt) and sum(a != b for a, b in zip(clean, corrupt)) == 1,
                "tamper changed more than one payload byte")
        tampered = root / "tampered-signed.apk"
        write_new(tampered, corrupt)
        inputs[str(tampered.relative_to(root))] = file_identity(tampered)
        record["tamper"] = {"member": "AndroidManifest.xml", "absolute_offset": offset,
                            "original_byte": old_byte, "mutated_byte": corrupt[offset],
                            "length_unchanged": True, "single_byte_difference": True,
                            "source_sha256": sha(clean), "tampered_sha256": sha(corrupt)}
        record["checks"].append(CHECKS[6])
        rejected, rejection_out, rejection_err = commands.run("apksigner-verify-tampered", [
            SDK / "apksigner", "verify", "--verbose", "--min-sdk-version", "24", tampered], timeout=60)
        require(type(rejected["exit_code"]) is int and rejected["exit_code"] > 0,
                "Android verifier did not reject the tampered APK with an ordinary failure exit")
        require(b"DOES NOT VERIFY" in (rejection_out.read_bytes() + rejection_err.read_bytes()).upper(),
                "Android verifier failure lacks its actual DOES NOT VERIFY verdict")
        record["checks"].append(CHECKS[7])
        _row, preview_bad, preview_bad_err = commands.success(
            "worker-preview-tampered", [binary, "rea-worker", "--selected-path=/controlled/tampered-signed.apk"],
            timeout=60, data=corrupt, input_path=tampered, worker=True)
        require(preview_bad_err.stat().st_size == 0, "tampered structural worker emitted diagnostics")
        check_preview(preview_bad, corrupt)
        record["checks"].append(CHECKS[8])
        _row, native_bad, native_bad_err = commands.success(
            "worker-native-tampered", [binary, "rea-apk-signature-worker"],
            timeout=35, data=corrupt, input_path=tampered, worker=True)
        require(native_bad_err.stat().st_size == 0, "tampered native worker emitted diagnostics")
        check_native(native_bad, corrupt, "invalid")
        record["checks"].append(CHECKS[9])
        truncated = root / "truncated-signed.apk"
        write_new(truncated, clean[:-7])
        inputs[str(truncated.relative_to(root))] = file_identity(truncated)
        failed, rejected_stdout, rejected_stderr = commands.run(
            "worker-native-truncated", [binary, "rea-apk-signature-worker"],
            timeout=35, data=clean[:-7], input_path=truncated, worker=True)
        require(type(failed["exit_code"]) is int and failed["exit_code"] > 0 and
                rejected_stdout.stat().st_size == 0 and 0 < rejected_stderr.stat().st_size < 65536,
                "truncated native worker did not reject without a success report")
        record["checks"].append(CHECKS[10])
        _row, git_after, _err = commands.success(
            "source-commit-tree-after", ["/usr/bin/git", "-C", str(REPO), "rev-parse", "HEAD", "HEAD^{tree}"], timeout=15)
        require(git_after.read_text().splitlines() == [SOURCE_COMMIT, SOURCE_TREE],
                "source commit/tree changed after actual checks")
        write_new(root / "generated-inputs.json", inputs)
        after = closure(binary)
        write_new(root / "inputs-after.json", after)
        require(before == after, "binary/source/configured installation closure changed during execution")
        require(all(file_identity(root / name) == value for name, value in inputs.items()),
                "a generated fixture or configuration changed during validation")
        record["inputs_after"] = file_identity(root / "inputs-after.json")
        record["generated_inputs"] = file_identity(root / "generated-inputs.json")
        record["checks"].append(CHECKS[11])
        require(len(record["commands"]) == 14 and all(
            row["wait_reaped"] and row["output_complete"] and not row["timed_out"] and
            not row["manual_cleanup"] and not row["launch_error"] and
            type(row["exit_code"]) is int for row in record["commands"]),
            "original command terminal set is incomplete")
        record["checks"].append(CHECKS[12])
        record["output_inventory"] = output_inventory(root)
        require(record["output_inventory"]["total_bytes"] < MAX_OUTPUT - MAX_STREAM,
                "owned output lacks the reserved final-report byte allowance")
        record["checks"].append(CHECKS[13])
        require(record["checks"] == CHECKS, "nonempty exact check set differs")
        record["status"] = "passed"
        record["qualified"] = True
    except BaseException as error:
        record["status"] = "failed"
        record["qualified"] = False
        record["failure"] = {"type": type(error).__name__, "message": str(error)}
        raise
    finally:
        record["finished_at"] = now()
        if before is not None and "inputs_after" not in record:
            try:
                observed = closure(binary)
                write_new(root / "inputs-after-failure.json", observed)
                record["inputs_after_failure"] = file_identity(root / "inputs-after-failure.json")
                record["closure_unchanged_after_failure"] = observed == before
            except BaseException as error:
                record["closure_recheck_failure"] = {"type": type(error).__name__, "message": str(error)}
        publish(root / "qualification.json", record)
        print(json.dumps({"qualified": record["qualified"], "status": record["status"],
                          "checks": len(record["checks"]), "commands": len(record["commands"]),
                          "qualification": str(root / "qualification.json")}, sort_keys=True), flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
