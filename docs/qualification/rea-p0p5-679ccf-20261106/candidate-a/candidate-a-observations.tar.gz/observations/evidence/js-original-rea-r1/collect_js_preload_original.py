#!/usr/bin/env python3
"""Original REA 6.8.0 public MCP observations for seven authored wrappers.

Sources remain inert, keep their original filename/extension and original bytes.
Only the declared BrowserWindow preload projection is compared with prior native
worker results. Full public REA responses and transport bytes are retained.
"""
from __future__ import annotations
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys
import time
import traceback

sys.dont_write_bytecode = True
from mcp_client_snapshot import (
    MCP, NODE_SHA, NODE_VERSION, identity, json_bytes, package_identity,
    read_regular, require, save, write,
)

ROOT = Path(__file__).resolve().parent
REFERENCE_PACKAGE = Path('/home/qian-qi/work/hepta-rea-reference-recovery-ca464-20261105-r1/install/node_modules/rea-agents')
REFERENCE_TAR = Path('/home/qian-qi/work/hepta-rea-reference-20261103/pack/rea-agents-6.8.0.tgz')
OWN_FILES_SHA = '7f06a93473f1f74139d710545850ebab47e2bc026909113b7d010740e922e4e0'
NODE = Path('/usr/bin/node')
BASELINE = Path('/home/qian-qi/work/hepta-rea-p0p5-679ccf-20261105-evidence/javascript-preload-c759-baseline.json')
BASELINE_SHA = 'dc47b4aa2b33e82299f6a3f71df3bcdb0b4d7341ebf81388a1defb7f5e5d4365'
CLIENT_SHA = 'a50826baf7d3fa6cc0634befff43fbb9faadff8574c2e99506068905fd2c6f99'
EXPECTED_IDS = ['plain.js', 'parentheses.js', 'as-const.ts', 'satisfies.ts', 'type-assertion.ts', 'non-null.ts', 'nested-values.js']
TOOL = 'analyze_javascript_application'


class PreloadMCP(MCP):
    def initialize(self):
        response = self.request('initialize', dict(
            protocolVersion='2026-07-28', capabilities={},
            clientInfo=dict(name='hepta-rea-preload-wrapper-original-audit', version='1')))
        require('result' in response, 'MCP initialize failed')
        self.send('notifications/initialized', {})
        save(self.out/'initialize.json', response)


def children(value):
    yield value
    if isinstance(value, dict):
        for item in value.values():
            yield from children(item)
    elif isinstance(value, list):
        for item in value:
            yield from children(item)


def payloads(response):
    result = response.get('result', {})
    values = [result]
    if isinstance(result, dict):
        for block in result.get('content', []):
            if isinstance(block, dict) and block.get('type') == 'text':
                try:
                    values.append(json.loads(block['text']))
                except (KeyError, ValueError):
                    pass
    return values


def analysis_projection(response):
    candidates, evidence_ids = {}, set()
    for payload in payloads(response):
        for obj in children(payload):
            if isinstance(obj, str) and re.fullmatch(r'ev_[0-9a-f]{64}', obj):
                evidence_ids.add(obj)
            if not isinstance(obj, dict):
                continue
            graph, summary = obj.get('graph'), obj.get('summary')
            if (isinstance(graph, dict) and isinstance(graph.get('nodes'), list)
                    and isinstance(summary, dict) and isinstance(summary.get('ipc'), dict)
                    and isinstance(obj.get('statistics'), dict)):
                candidates[hashlib.sha256(json_bytes(obj)).hexdigest()] = obj
    projection = dict(analysis_candidates=len(candidates), evidence_ids=sorted(evidence_ids))
    if len(candidates) != 1:
        return projection
    digest, analysis = next(iter(candidates.items()))
    nodes = analysis['graph']['nodes']
    browser_nodes = [node for node in nodes if node.get('kind') == 'browser-window']
    preload_nodes = [node for node in nodes if node.get('kind') == 'electron-preload']
    windows = []
    for node in browser_nodes:
        for observation in node.get('observations', []):
            properties = observation.get('properties', {})
            if 'web_preferences' not in properties:
                continue
            windows.append(dict(
                node_id=node.get('node_id'), observation_id=observation.get('observation_id'),
                source_path=properties.get('source_path'),
                preload_declaration_present=any(
                    prop.get('name') == 'preload' for prop in properties['web_preferences']),
                literal_preload=properties.get('preload_path'),
                options_status=properties.get('options_status'),
                web_preferences_status=properties.get('web_preferences_status'),
                preload_resolution_context=properties.get('preload_resolution_context')))
    projection.update(
        analysis_sha256=digest, electron_summary=analysis['summary'],
        statistics=analysis['statistics'], limitations=analysis.get('limitations'),
        source_selection=analysis.get('source_selection'),
        graph_coverage=analysis['graph'].get('coverage'),
        browser_window_nodes=browser_nodes, electron_preload_nodes=preload_nodes,
        windows=windows,
        observation=(dict(preload_declaration_present=windows[0]['preload_declaration_present'],
                          literal_preload=windows[0]['literal_preload'])
                     if len(windows) == 1 else None))
    return projection


def main():
    out = ROOT/'observations'
    out.mkdir(mode=0o700)
    report = dict(
        schema='hepta.rea.js-preload-wrapper-original-observation.v1',
        started_utc=time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()),
        tool=TOOL, qualified=False, global_status='HOLD/NO_GO',
        scope='Seven authored JS/TS files preserved byte-for-byte; one package.json with main naming each unchanged source. No preload implementation is added. Only the declared BrowserWindow preload presence/literal projection is compared with the earlier native worker result.',
        fixture_execution=False, full_rea_parity_claimed=False,
        unqualified=['Full public-tool envelope/Evidence equality', 'Error/cancellation equivalence',
                     'Runtime Electron execution', 'Performance/deployment',
                     'Complete dependency authentication', 'Continuous source mutation monitoring',
                     'Arbitrary escaped descendant cleanup'],
        before={}, after={}, fixtures_before=[], cases=[], errors=[], cleanup=None)
    client = None
    fixtures = []
    baseline = None
    actions = {
        'runner': lambda: identity(Path(__file__).resolve()),
        'client_snapshot': lambda: identity(ROOT/'mcp_client_snapshot.py'),
        'node': lambda: identity(NODE.resolve()),
        'package': lambda: package_identity(REFERENCE_PACKAGE, REFERENCE_TAR),
        'baseline_report': lambda: identity(BASELINE),
    }
    try:
        for label, action in actions.items():
            report['before'][label] = action()
        require(report['before']['client_snapshot']['sha256'] == CLIENT_SHA, 'MCP client snapshot changed')
        require(report['before']['node']['sha256'] == NODE_SHA, 'Pinned Node hash mismatch')
        require(report['before']['package']['own_files_sha256'] == OWN_FILES_SHA, 'Original npm own-files digest mismatch')
        require(report['before']['baseline_report']['sha256'] == BASELINE_SHA, 'Frozen native baseline report changed')
        version = subprocess.run([str(NODE), '--version'], stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                                 timeout=10, check=False)
        write(out/'node-version.stdout', version.stdout)
        write(out/'node-version.stderr', version.stderr)
        require(version.returncode == 0 and version.stdout.decode().strip() == NODE_VERSION,
                'Pinned Node version mismatch')
        report['node_version'] = NODE_VERSION
        baseline_raw = read_regular(BASELINE)
        baseline = json.loads(baseline_raw)
        require([row['id'] for row in baseline['cases']] == EXPECTED_IDS, 'Unexpected baseline fixtures')
        write(out/'native-prior-report.json', baseline_raw)
        actions['baseline_binary'] = lambda: identity(Path(baseline['runtime']['path']))
        report['before']['baseline_binary'] = actions['baseline_binary']()
        require(report['before']['baseline_binary']['sha256'] == baseline['runtime']['sha256'],
                'Frozen baseline runtime identity changed')
        for row in baseline['cases']:
            case_id = row['id']
            prior_path = Path(baseline['fixture_directory'])/case_id
            source_raw = read_regular(prior_path)
            require(hashlib.sha256(source_raw).hexdigest() == row['source_sha256'], 'Fixture source hash mismatch: '+case_id)
            case_root = ROOT/'fixtures'/case_id.rsplit('.', 1)[0]
            case_root.mkdir(parents=True, mode=0o700)
            package_file = save(case_root/'package.json', dict(
                name='hepta-owned-preload-wrapper-fixture', version='1.0.0',
                type='commonjs', main=case_id, private=True))
            source_file = write(case_root/case_id, source_raw)
            fixtures.append(dict(id=case_id, syntax=row['syntax'], root=str(case_root),
                                 source=source_file, prior_source=identity(prior_path),
                                 package=package_file))
        report['fixtures_before'] = fixtures
        save(out/'fixtures.json', fixtures)
        env = {'PATH':'/usr/bin:/bin', 'LANG':'C.UTF-8',
               'REA_MCP_INPUT_SCHEMA_PROFILE':'full', 'REA_MCP_OUTPUT_SCHEMA_PROFILE':'full'}
        client = PreloadMCP([str(NODE), str(REFERENCE_PACKAGE/'scripts/rea.mjs'), 'mcp'],
                            ROOT, env, out/'wire')
        client.initialize()
        catalog = client.request('tools/list', {})
        save(out/'tools-list.json', catalog)
        selected = [tool for tool in catalog.get('result', {}).get('tools', []) if tool.get('name') == TOOL]
        require(len(selected) == 1, 'Actual original catalog did not contain exactly one selected tool')
        save(out/'selected-tool.json', selected[0])
        report['catalog'] = dict(count=len(catalog['result']['tools']), selected=identity(out/'selected-tool.json'))
        for fixture, prior in zip(fixtures, baseline['cases'], strict=True):
            case_dir = out/fixture['id'].rsplit('.', 1)[0]
            case_dir.mkdir(mode=0o700)
            arguments = dict(input_path=fixture['root'], format='directory', integrity_policy='fail',
                             source_paths=['package.json', fixture['id']], detail='complete')
            save(case_dir/'request-arguments.json', arguments)
            start = time.monotonic()
            response = client.call(TOOL, arguments)
            elapsed = time.monotonic()-start
            response_id = save(case_dir/'response.json', response)
            frame_id = write(case_dir/'response-frame.ndjson', client.last_response_raw)
            projection = analysis_projection(response)
            projection_id = save(case_dir/'projection.json', projection)
            observation = projection.get('observation')
            row = dict(
                id=fixture['id'], source_sha256=fixture['source']['sha256'], arguments=arguments,
                response=response_id, raw_frame=frame_id, projection_identity=projection_id,
                projection=projection, original_rpc_error=response.get('error'),
                original_is_error=response.get('result', {}).get('isError', False),
                elapsed_seconds_observation_only=elapsed,
                prior_node_stub_expected=prior['expected'], native_baseline_observation=prior['observed'],
                original_matches_prior_node_stub=(observation == prior['expected'] if observation is not None else None),
                original_matches_native_baseline=(observation == prior['observed'] if observation is not None else None),
                comparison_scope='Only one BrowserWindow preload-declaration presence and literal path; no full graph/public-envelope/Evidence equality')
            report['cases'].append(row)
            save(case_dir/'case.json', row)
            print(json.dumps(dict(id=row['id'], original=observation,
                                  rpc_error=row['original_rpc_error'], is_error=row['original_is_error'])), flush=True)
    except BaseException as error:
        report['errors'].append(dict(type=type(error).__name__, message=str(error), traceback=traceback.format_exc()))
    finally:
        if client is not None:
            report['cleanup'] = client.close()
            cleanup = report['cleanup']
            if (cleanup['cleanup_errors'] or cleanup['trailing_protocol_errors'] or cleanup['capture_truncated']
                    or not cleanup['managed_resources_closed'] or not cleanup['owner_pidfd_exited']
                    or not cleanup['process_group_gone']):
                report['errors'].append(dict(type='CleanupOrCaptureIncomplete', details=cleanup))
        for label, action in actions.items():
            try:
                report['after'][label] = action()
                if label in report['before'] and report['before'][label] != report['after'][label]:
                    report['errors'].append(dict(type='EndpointIdentityChanged', subject=label))
            except BaseException as error:
                report['errors'].append(dict(type='AfterIdentityFailure', subject=label, message=repr(error)))
        for fixture in fixtures:
            for field in ('source', 'package', 'prior_source'):
                try:
                    if identity(Path(fixture[field]['path'])) != fixture[field]:
                        report['errors'].append(dict(type='FixtureChanged', id=fixture['id'], field=field))
                except BaseException as error:
                    report['errors'].append(dict(type='FixtureReadbackFailure', id=fixture['id'], field=field, message=repr(error)))
    report['collection_complete'] = not report['errors'] and len(report['cases']) == len(EXPECTED_IDS)
    report['analysis_complete'] = report['collection_complete'] and all(
        not row['original_rpc_error'] and not row['original_is_error']
        and row['projection']['analysis_candidates'] == 1 for row in report['cases'])
    report['counts'] = dict(
        denominator=len(EXPECTED_IDS), collected=len(report['cases']),
        original_matches_prior_node_stub=sum(row['original_matches_prior_node_stub'] is True for row in report['cases']),
        original_matches_native_baseline=sum(row['original_matches_native_baseline'] is True for row in report['cases']))
    report['completed_utc'] = time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())
    receipt = save(out/'observation.json', report)
    print(json.dumps(dict(receipt=receipt, counts=report['counts'],
                          collection_complete=report['collection_complete'], analysis_complete=report['analysis_complete'],
                          errors=report['errors'], cleanup=report['cleanup'])), flush=True)
    return 0 if report['collection_complete'] else 2


if __name__ == '__main__':
    raise SystemExit(main())
