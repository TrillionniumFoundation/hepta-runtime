#!/usr/bin/env python3
"""Finite, read-only target analysis by original npm REA 6.8.0.

The program creates only its own fixtures and receipts. It does not assert
original-tool parity, error/cancellation equivalence or deployment qualification.
"""
from __future__ import annotations

import hashlib
import json
from pathlib import Path
import re
import subprocess
import time
import traceback

from mcp_client_snapshot import (
    MCP, NODE_SHA, NODE_VERSION, identity, json_bytes, package_identity,
    read_regular, require, save, write,
)

REFERENCE_PACKAGE = Path('/home/qian-qi/work/hepta-rea-reference-recovery-ca464-20261105-r1/install/node_modules/rea-agents')
REFERENCE_TAR = Path('/home/qian-qi/work/hepta-rea-reference-20261103/pack/rea-agents-6.8.0.tgz')
OWN_FILES_SHA = '7f06a93473f1f74139d710545850ebab47e2bc026909113b7d010740e922e4e0'
NODE = Path('/usr/bin/node')
NATIVE = Path('/home/qian-qi/work/hepta-rea-sixpack-ca464-20261105-evidence/final-combination-r5/prepared/hepta-runtime')
NATIVE_SHA = 'b80ff24a78afeb2f20a658f1fde6d6a20c989df8699d9485f3c2bc0b26e78983'
PRIOR = Path('/home/qian-qi/work/hepta-rea-js-public-173861-20261105-r2/baseline')
SOURCES_SHA = '8f755e7eb7a2051fc95072818ce220ede58ae8993d21d3923472bd9cf1a21220'
SCRIPT_ROOT = Path(__file__).resolve().parent
TOOL = 'analyze_javascript_application'


class JsMCP(MCP):
    def initialize(self):
        response = self.request('initialize', dict(
            protocolVersion='2026-07-28', capabilities={},
            clientInfo=dict(name='hepta-rea-js-source-order-audit', version='1')))
        require('result' in response, 'MCP initialize failed')
        self.send('notifications/initialized', {})
        save(self.out/'initialize.json', response)


def children(value):
    yield value
    if isinstance(value, dict):
        for item in value.values():
            yield from children(item)
    elif isinstance(value, list):
        for item in value:
            yield from children(item)


def payloads(response):
    result = response.get('result', {})
    values = [result]
    if isinstance(result, dict):
        for block in result.get('content', []):
            if isinstance(block, dict) and block.get('type') == 'text':
                try:
                    values.append(json.loads(block['text']))
                except (KeyError, ValueError):
                    pass
    return values


def analysis_projection(response):
    """Retain interpretation separately from the unmodified public response."""
    candidates = {}
    evidence_ids = set()
    for payload in payloads(response):
        for obj in children(payload):
            if isinstance(obj, str) and re.fullmatch(r'ev_[0-9a-f]{64}', obj):
                evidence_ids.add(obj)
            if not isinstance(obj, dict):
                continue
            graph, summary = obj.get('graph'), obj.get('summary')
            if (isinstance(graph, dict) and isinstance(graph.get('nodes'), list)
                    and isinstance(summary, dict) and isinstance(summary.get('ipc'), dict)
                    and isinstance(obj.get('statistics'), dict)):
                digest = hashlib.sha256(json_bytes(obj)).hexdigest()
                candidates[digest] = obj
    projection = dict(analysis_candidates=len(candidates), evidence_ids=sorted(evidence_ids))
    if len(candidates) == 1:
        digest, analysis = next(iter(candidates.items()))
        nodes = analysis['graph']['nodes']
        kinds = {}
        for item in nodes:
            kind = str(item.get('kind', 'MISSING'))
            kinds[kind] = kinds.get(kind, 0)+1
        ipc_nodes = [item for item in nodes if 'ipc' in str(item.get('kind', '')).lower()]
        projection.update(
            analysis_sha256=digest, ipc_summary=analysis['summary']['ipc'], electron_summary=analysis['summary'],
            statistics=analysis['statistics'], limitations=analysis.get('limitations'),
            source_selection=analysis.get('source_selection'),
            graph_coverage=analysis['graph'].get('coverage'), graph_kinds=kinds,
            ipc_nodes=ipc_nodes)
    return projection


def main():
    out = SCRIPT_ROOT/'observations'
    out.mkdir(mode=0o700)
    report = dict(
        schema='hepta.rea.js-source-order-original-observation.v1',
        started_utc=time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()),
        qualified=False, global_status='HOLD/NO_GO', tool=TOOL,
        scope='Thirteen authored CommonJS sources; original full public result retained. Native comparison is only a declared static IPC projection from prior internal-worker outputs.',
        unqualified=['Full original public-tool equality', 'Errors and cancellation',
                     'Runtime Electron execution', 'Performance/deployment',
                     'Complete dependency authentication', 'Continuous source mutation monitoring',
                     'Arbitrary escaped descendant cleanup'],
        cases=[], errors=[], before={}, after={}, cleanup=None)
    client = None
    fixtures = []
    try:
        report['before']['node'] = identity(NODE.resolve())
        require(report['before']['node']['sha256'] == NODE_SHA, 'Pinned Node hash mismatch')
        node_version = subprocess.run([str(NODE), '--version'], stdout=subprocess.PIPE,
                                      stderr=subprocess.PIPE, timeout=10, check=False)
        write(out/'node-version.stdout', node_version.stdout)
        write(out/'node-version.stderr', node_version.stderr)
        require(node_version.returncode == 0 and node_version.stdout.decode().strip() == NODE_VERSION,
                'Pinned Node version mismatch')
        report['before']['package'] = package_identity(REFERENCE_PACKAGE, REFERENCE_TAR)
        require(report['before']['package']['own_files_sha256'] == OWN_FILES_SHA,
                'Original package own-files digest differs from independently verified current R1')
        report['before']['native'] = identity(NATIVE)
        require(report['before']['native']['sha256'] == NATIVE_SHA, 'Native frozen binary changed')
        source_raw = read_regular(PRIOR/'sources.json')
        require(hashlib.sha256(source_raw).hexdigest() == SOURCES_SHA, 'Prior three source contents changed')
        sources = json.loads(source_raw)
        require([x['id'] for x in sources] == ['before.js', 'after.js', 'mutated.js', 'chain-before.js', 'chain-after.js', 'shadow.js', 'shadow-require.js', 'cycle.js', 'mutated-alias.js', 'namespace-after.js', 'destructure-after.js', 'window-after.js', 'redeclared.js'], 'Unexpected fixture set')
        prior = json.loads(read_regular(PRIOR/'report.json'))
        require(prior['runtime_sha256_before'] == prior['runtime_sha256_after'] == NATIVE_SHA,
                'Prior native result has wrong runtime identity')
        require(prior['sources'] == sources, 'Prior native source contents differ')
        report['before']['native_report'] = identity(PRIOR/'report.json')
        report['before']['prior_sources'] = identity(PRIOR/'sources.json')
        write(out/'sources.json', source_raw)
        write(out/'native-prior-report.json', read_regular(PRIOR/'report.json'))
        for source in sources:
            case_id = source['id'].removesuffix('.js')
            root = SCRIPT_ROOT/'fixtures'/case_id
            root.mkdir(mode=0o700, parents=True)
            package = {'name':'hepta-owned-js-alias-fixture', 'version':'1.0.0',
                       'type':'commonjs', 'main':'main.js', 'private':True}
            package_file = save(root/'package.json', package)
            source_file = write(root/'main.js', source['text'].encode('utf-8'))
            fixtures.append(dict(id=source['id'], root=str(root), source=source_file, package=package_file))
        report['fixtures_before'] = fixtures
        save(out/'fixtures.json', fixtures)
        for name in ('home', 'xdg-config', 'xdg-cache', 'xdg-data'):
            (SCRIPT_ROOT/name).mkdir(mode=0o700)
        env = {'PATH':'/usr/bin:/bin', 'LANG':'C.UTF-8',
               'HOME':str(SCRIPT_ROOT/'home'), 'XDG_CONFIG_HOME':str(SCRIPT_ROOT/'xdg-config'),
               'XDG_CACHE_HOME':str(SCRIPT_ROOT/'xdg-cache'), 'XDG_DATA_HOME':str(SCRIPT_ROOT/'xdg-data'),
               'REA_MCP_INPUT_SCHEMA_PROFILE':'full', 'REA_MCP_OUTPUT_SCHEMA_PROFILE':'full'}
        client = JsMCP([str(NODE), str(REFERENCE_PACKAGE/'scripts/rea.mjs'), 'mcp'], SCRIPT_ROOT, env, out/'wire')
        client.initialize()
        catalog = client.request('tools/list', {})
        save(out/'tools-list.json', catalog)
        tools = catalog.get('result', {}).get('tools', [])
        selected = [tool for tool in tools if tool.get('name') == TOOL]
        require(len(selected) == 1, 'Actual original catalog must contain exactly one selected tool')
        save(out/'selected-tool.json', selected[0])
        report['catalog'] = dict(count=len(tools), selected=identity(out/'selected-tool.json'),
            full_input_sha256=hashlib.sha256(json.dumps(selected[0]['inputSchema'],
                sort_keys=True, ensure_ascii=True, separators=(',', ':')).encode()).hexdigest())
        for fixture in fixtures:
            case_id = fixture['id'].removesuffix('.js')
            case_dir = out/case_id
            case_dir.mkdir(mode=0o700)
            arguments = dict(input_path=fixture['root'], format='directory', integrity_policy='fail',
                             source_paths=['package.json', 'main.js'], detail='complete')
            save(case_dir/'request-arguments.json', arguments)
            start = time.monotonic()
            response = client.call(TOOL, arguments)
            elapsed = time.monotonic()-start
            save(case_dir/'response.json', response)
            write(case_dir/'response-frame.ndjson', client.last_response_raw)
            projection = analysis_projection(response)
            save(case_dir/'projection.json', projection)
            native = next(x for x in prior['results'] if x['source_id'] == fixture['id'])
            native_json = json.loads(native['stdout'])
            require(native['exit_code'] == 0 and native['stderr'] == '', 'Prior native fixture was not successful')
            row = dict(id=fixture['id'], arguments=arguments, response=identity(case_dir/'response.json'),
                       raw_frame=identity(case_dir/'response-frame.ndjson'), projection=projection,
                       elapsed_seconds_observation_only=elapsed,
                       original_rpc_error=response.get('error'),
                       original_is_error=response.get('result', {}).get('isError', False),
                       native_count=native_json['counts']['electron_calls'], native_rows=native_json['rows'],
                       comparison_scope='Original IPC operations versus native electron_calls on one possible send call per source; no full-envelope or Evidence equality asserted')
            if 'ipc_summary' in projection:
                row['original_count'] = projection['ipc_summary']['operations']
                row['projected_count_equal'] = row['original_count'] == row['native_count']
            report['cases'].append(row)
            save(case_dir/'case.json', row)
    except BaseException as error:
        report['errors'].append(dict(type=type(error).__name__, message=str(error), traceback=traceback.format_exc()))
    finally:
        if client is not None:
            report['cleanup'] = client.close()
            cleanup = report['cleanup']
            if (cleanup['cleanup_errors'] or cleanup['trailing_protocol_errors'] or cleanup['capture_truncated']
                    or not cleanup['managed_resources_closed'] or not cleanup['owner_pidfd_exited']
                    or not cleanup['process_group_gone']):
                report['errors'].append(dict(type='CleanupOrCaptureIncomplete', details=cleanup))
        for label, action in (
                ('node', lambda:identity(NODE.resolve())),
                ('package', lambda:package_identity(REFERENCE_PACKAGE, REFERENCE_TAR)),
                ('native', lambda:identity(NATIVE)),
                ('native_report', lambda:identity(PRIOR/'report.json')),
                ('prior_sources', lambda:identity(PRIOR/'sources.json'))):
            try:
                report['after'][label] = action()
                if label in report['before'] and report['before'][label] != report['after'][label]:
                    report['errors'].append(dict(type='EndpointIdentityChanged', subject=label))
            except BaseException as error:
                report['errors'].append(dict(type='AfterIdentityFailure', subject=label, message=repr(error)))
        for fixture in fixtures:
            for field in ('source', 'package'):
                try:
                    if identity(Path(fixture[field]['path'])) != fixture[field]:
                        report['errors'].append(dict(type='FixtureChanged', id=fixture['id'], field=field))
                except BaseException as error:
                    report['errors'].append(dict(type='FixtureReadbackFailure', id=fixture['id'], field=field, message=repr(error)))
    report['collection_complete'] = not report['errors'] and len(report['cases']) == 13
    report['analysis_complete'] = report['collection_complete'] and all(
        not row['original_rpc_error'] and not row['original_is_error']
        and row['projection']['analysis_candidates'] == 1 for row in report['cases'])
    report['completed_utc'] = time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())
    receipt = save(out/'observation.json', report)
    print(json.dumps(dict(collection_complete=report['collection_complete'], analysis_complete=report['analysis_complete'],
                          qualified=False, global_status='HOLD/NO_GO', receipt=receipt,
                          cases=[{k:row.get(k) for k in ('id', 'original_count', 'native_count', 'original_rpc_error', 'original_is_error')}
                                 for row in report['cases']], errors=report['errors'])), flush=True)
    return 0 if report['collection_complete'] else 2


if __name__ == '__main__':
    raise SystemExit(main())
