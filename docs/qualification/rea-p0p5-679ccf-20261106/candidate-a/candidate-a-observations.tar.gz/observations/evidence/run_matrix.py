#!/usr/bin/env python3
"""Run the existing matrix and four actual upstream corpus gates on one committed tree."""
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import time

REPO = Path("/home/qian-qi/work/hepta-rea-p0p5-679ccf-20261105")
OUT = Path(str(REPO) + "-evidence")
TARGET = Path(str(REPO) + "-target")
CACHE = Path("/home/qian-qi/work/hepta-rea-sixpack-ca464-20261105-cargo-home")
TOOLCHAIN = Path("/home/qian-qi/.rustup/toolchains/1.95.0-x86_64-unknown-linux-gnu/bin")
INPUTS = Path("/home/qian-qi/work/hepta-rea-json-eof-173861-20261105-evidence/ignored-inputs-r1")
GATES = [
 ("real_npm_reference_evidence_matches_native_subset_identity", "REA_REAL_EVIDENCE_JSON", "inputs/REA_6_8_0_ELF_NOTES_EVIDENCE.json", "5d555ee7942a0355db5901719ae6a40706b684a3c182f3a9b09085969f110622"),
 ("extensive_ecmascript_finite_number_corpus_matches_native_renderer", "REA_REAL_NUMBER_CASES_TSV", "bit-oracle/number-cases.tsv", "c02f4b12d3ed29c2a1598328fd5f7d9837a530df0f94b4330be554dea23d8846"),
 ("real_npm_fractional_reference_evidence_matches_native", "REA_REAL_FLOAT_EVIDENCE_JSON", "npm-oracle/REA_6_8_0_FINITE_NUMBER_EVIDENCE.json", "e72cf0239101d1bc2365df8215150162839571b29a3de39d0ac2b4386afd4fa4"),
 ("real_npm_rejected_schema_matrix_is_independently_rejected_by_rust", "REA_REAL_INVALID_EVIDENCE_JSON", "npm-oracle/REA_6_8_0_INVALID_EVIDENCE_SCHEMA.json", "0ae91f93c3538f066b6136890850c9371949e49c223f07e19f9017e6f9423672"),
]
def ident(path):
    digest=hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda:f.read(1048576),b""): digest.update(block)
    return {"path":str(path),"bytes":path.stat().st_size,"sha256":digest.hexdigest()}
def save(path,data):
    path.write_text(json.dumps(data,indent=2,sort_keys=True)+"\n")
def git(*args):
    return subprocess.check_output(["git","-C",str(REPO),*args],text=True).strip()
def source_identity():
    return {"commit":git("rev-parse","HEAD"),"tree":git("rev-parse","HEAD^{tree}"),"status":git("status","--porcelain=v1")}
def run(name,cmd,env):
    started=time.time()
    with (OUT/(name+".stdout.log")).open("xb") as stdout,(OUT/(name+".stderr.log")).open("xb") as stderr:
        result=subprocess.run(cmd,cwd=REPO,env=env,stdout=stdout,stderr=stderr,umask=0o022,check=False)
    row={"name":name,"argv":cmd,"returncode":result.returncode,"elapsed_seconds":time.time()-started,
         "stdout":ident(OUT/(name+".stdout.log")),"stderr":ident(OUT/(name+".stderr.log"))}
    print(json.dumps(row),flush=True)
    return row
def main():
    before=source_identity()
    if before["status"]: raise RuntimeError("source must be committed and clean")
    save(OUT/"source-identity-before.json",before)
    env=os.environ.copy()
    for key in list(env):
        if key.startswith(("CARGO_","RUSTFLAGS","RUSTC_","RUSTDOC","NEXTEST_")): env.pop(key)
    env.update({"PATH":str(TOOLCHAIN)+":/home/qian-qi/.cargo/bin:/usr/local/bin:/usr/bin:/bin",
        "CARGO_HOME":str(CACHE),"CARGO_TARGET_DIR":str(TARGET),"CARGO_BUILD_JOBS":"2",
        "CARGO_NET_OFFLINE":"true","RUSTUP_TOOLCHAIN":"1.95.0","RUSTC":str(TOOLCHAIN/"rustc"),
        "CARGO_PROFILE_DEV_DEBUG":"0","CARGO_PROFILE_TEST_DEBUG":"0",
        "CARGO_PROFILE_DEV_INCREMENTAL":"false","CARGO_PROFILE_TEST_INCREMENTAL":"false",
        "CARGO_TERM_COLOR":"never","NEXTEST_RETRIES":"0","NEXTEST_TEST_THREADS":"1"})
    save(OUT/"build-environment.json",{k:v for k,v in env.items() if k.startswith(("CARGO_","RUSTUP_","RUSTC","NEXTEST_"))})
    command=[sys.executable,"-B",str(REPO/"scripts/rea_full_qualification.py"),
        "--repo",str(REPO),"--cargo-home",str(CACHE),"--target-dir",str(TARGET),
        "--output-dir",str(OUT/"matrix-r1"),"--jobs","2",
        "--cargo",str(TOOLCHAIN/"cargo"),"--rustc",str(TOOLCHAIN/"rustc")]
    matrix=run("matrix-driver-r1",command,env)
    report={"source":before,"matrix":matrix,"supplemental_gates":[],"qualified":False}
    save(OUT/"run-summary.json",report)
    if matrix["returncode"] != 0: return matrix["returncode"]
    if source_identity()!=before: raise RuntimeError("source changed during matrix")
    sys.path.insert(0,str(REPO/"scripts"))
    import rea_full_qualification as matrix_module
    import rea_build_evidence as consumer
    shutil.copy2(TARGET/"debug/hepta-runtime",OUT/"hepta-runtime")
    (OUT/"hepta-runtime").chmod(0o555)
    runtime=ident(OUT/"hepta-runtime")
    selection=matrix_module.Selection(REPO,TARGET,OUT/"matrix-r1").snapshot()
    build_raw=(OUT/"matrix-r1/summary.json").read_bytes()
    validation=consumer.validate_matrix(build_raw,lambda n:consumer.read_regular(OUT/"matrix-r1",n),selection,runtime)
    binding={"schema":"hepta.rea.p0p5.build-binding.v1","source_commit":before["commit"],
        "source_git_tree":before["tree"],"runtime":runtime,
        "build_summary":ident(OUT/"matrix-r1/summary.json"),"independent_consumer":validation,
        "rea_full_parity":False,"production_qualified":False}
    save(OUT/"binding.json",binding)
    report["binding"]=ident(OUT/"binding.json")
    supplemental_selection=matrix_module.Selection(REPO,TARGET,OUT/"matrix-r1")
    supplemental_monitor=matrix_module.SourceMonitor(supplemental_selection)
    supplemental_monitor.start()
    supplemental_before=supplemental_selection.snapshot()
    save(OUT/"supplemental-source-before.json",supplemental_before)
    for i,(short,key,relative,expected) in enumerate(GATES,1):
        path=INPUTS/relative
        original=ident(path)
        if original["sha256"]!=expected: raise RuntimeError("upstream corpus identity differs: "+relative)
        name="mcp::rea_evidence::rea_evidence_tests::"+short
        gate_env=dict(env,**{key:str(path)})
        cmd=[str(TOOLCHAIN/"cargo"),"test","--locked","--offline","--all-features","--lib",
             "--jobs","2","--message-format=json-render-diagnostics",name,
             "--","--exact","--ignored","--test-threads=1","--nocapture"]
        row=run("ignored-"+str(i),cmd,gate_env)
        raw=(OUT/("ignored-"+str(i)+".stdout.log")).read_text()
        row.update({"test":name,"input":original,"input_unchanged":ident(path)==original})
        summaries=re.findall(r"^test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored;",raw,re.M)
        names=re.findall(r"^test (\S+) \.\.\. (\S+)$",raw,re.M)
        # Assert the actual named libtest result; a successful cargo command alone is insufficient.
        row["exact_test_executed"]=names==[(name,"ok")] and summaries==[("ok","1","0","0")] and re.findall(r"^running (\d+) tests?$",raw,re.M)==["1"]
        row["passed"]=row["returncode"]==0 and row["exact_test_executed"] and row["input_unchanged"]
        artifacts=[]
        for line in raw.splitlines():
            if not line.startswith("{"): continue
            item=json.loads(line)
            if item.get("reason")=="compiler-artifact" and item.get("target",{}).get("name")=="hepta_runtime" and item.get("profile",{}).get("test") and item.get("executable"):
                artifacts.append(item)
        if len(artifacts)!=1: raise RuntimeError("cannot bind exact lib test executable")
        artifact=artifacts[0]
        if artifact.get("manifest_path")!=str(REPO/"Cargo.toml") or artifact["target"].get("src_path")!=str(REPO/"src/lib.rs") or artifact["target"].get("kind")!=["lib"] or not {"default","remote-fs"}.issubset(artifact.get("features",[])):
            raise RuntimeError("ignored test artifact does not belong to the selected source and feature set")
        finished=[json.loads(line).get("success") for line in raw.splitlines() if line.startswith("{") and json.loads(line).get("reason")=="build-finished"]
        if finished!=[True]: raise RuntimeError("ignored test compile did not finish successfully")
        row["compiler_artifact"]=artifact
        row["test_binary"]=ident(Path(artifacts[0]["executable"]))
        report["supplemental_gates"].append(row)
        save(OUT/"run-summary.json",report)
    supplemental_after=supplemental_selection.snapshot()
    supplemental_events=supplemental_monitor.stop()
    save(OUT/"supplemental-source-after.json",supplemental_after)
    save(OUT/"supplemental-source-events.json",supplemental_events)
    report["supplemental_source_unchanged"]=supplemental_after==supplemental_before and supplemental_events.get("event_count")==0 and not supplemental_events.get("errors")
    report["source_after"]=source_identity()
    report["source_unchanged"]=report["source_after"]==before
    report["all_four_passed"]=all(g["passed"] for g in report["supplemental_gates"]) and len(report["supplemental_gates"])==4
    save(OUT/"run-summary.json",report)
    return 0 if report["source_unchanged"] and report["supplemental_source_unchanged"] and report["all_four_passed"] else 1
if __name__=="__main__":
    raise SystemExit(main())
