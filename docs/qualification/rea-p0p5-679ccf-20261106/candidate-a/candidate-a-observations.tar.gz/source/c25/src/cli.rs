// Copyright 2026 Muvon Un Limited
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//! Runtime command-line transport, policy and optional durability settings.

use clap::{Parser, Subcommand};
use std::path::PathBuf;

#[derive(Parser, Debug)]
#[command(name = "hepta-runtime")]
#[command(version, author = "TrillionniumFoundation")]
#[command(about = "Policy-enforced multi-host MCP runtime", long_about = None)]
pub struct Cli {
	#[command(subcommand)]
	pub command: Commands,
}

#[derive(Subcommand, Debug)]
pub enum Commands {
	/// Start MCP server exposing filesystem tools (view, text_editor, batch_edit, shell, workdir, extract_lines)
	Mcp {
		/// Working directory for filesystem operations (default: current directory).
		/// Supports ssh:// or sftp:// paths for remote filesystem access.
		#[arg(long, value_name = "PATH")]
		path: Option<PathBuf>,

		/// Bind to HTTP server on host:port instead of using stdin/stdout (e.g., "0.0.0.0:12345")
		#[arg(long, value_name = "HOST:PORT")]
		bind: Option<String>,

		/// Path to SSH private key for remote filesystem access
		#[arg(long, value_name = "FILE")]
		ssh_key: Option<String>,

		/// SSH connection timeout in seconds for remote filesystem access
		#[arg(long, value_name = "SECS")]
		ssh_timeout: Option<u64>,

		/// Hepta Runtime host/policy JSON. Enables multi-host process, PTY, inspection and exact privileged-action tools.
		#[arg(long, value_name = "FILE")]
		runtime_config: Option<PathBuf>,

		/// File containing the X-Hepta-Runtime-Token value for HTTP MCP requests.
		#[arg(long, value_name = "FILE")]
		auth_token_file: Option<PathBuf>,

		/// Prepare verified private audit/result stores before accepting requests.
		#[arg(long, requires = "runtime_config")]
		runtime_prewarm: bool,

		/// Batch at most 32 already queued audit operations, without a gather timer.
		#[arg(long, requires = "runtime_config")]
		runtime_audit_group_commit: bool,

		/// Explicit private profile authorizing bounded cached SSH authentication for job observations.
		#[arg(long, value_name = "FILE", requires = "runtime_config")]
		runtime_observation_pool_profile: Option<PathBuf>,

		/// Also use the explicitly configured observation pool for file_info and binary_read.
		#[arg(long, requires_all = ["runtime_config", "runtime_observation_pool_profile"])]
		runtime_file_observation_pool: bool,
	},
	/// Internal, stdin-only REA analysis worker. Does not open any artifact path.
	#[command(hide = true)]
	ReaWorker {
		/// Display-only path; bytes are provided on stdin, not read by this worker.
		#[arg(long)]
		selected_path: String,
		/// Internal test proving syscall denials after worker input admission.
		#[arg(long, hide = true)]
		sandbox_probe: bool,
	},
	/// Internal model parser. Reads one admitted read-only regular-file descriptor.
	#[command(hide = true)]
	ReaModelWorker {
		#[arg(long)]
		request: String,
	},
	/// Internal pinned native transport for an existing weight worker job.
	#[command(hide = true)]
	WeightClient(hepta_runtime::mcp::weight_native::WeightClientArgs),
	/// Internal pinned static-provider worker. Reads one structured request on stdin.
	#[command(hide = true)]
	ReaStaticWorker,
	/// Internal bounded JS/TS AST parser over controller-admitted source bytes.
	#[command(hide = true)]
	ReaJavascriptWorker,
	/// Internal bounded source-map parser over controller-admitted bytes.
	#[command(hide = true)]
	ReaSourceMapWorker,
	/// Internal isolated ELF note parser.
	#[command(hide = true)]
	ReaElfNotesWorker,
	/// Internal bounded APK signature verifier over captured stdin bytes.
	#[command(hide = true)]
	ReaApkSignatureWorker,
	/// Internal bounded static APK report over controller-admitted bytes.
	#[command(hide = true)]
	ReaApkStaticWorker,
	/// Fixed local-resource capture under an existing durable process job (Linux).
	ReaBrowserCapture(hepta_runtime::mcp::rea_browser::BrowserCaptureArgs),
	/// Internal bounded ASAR parser over one admitted read-only descriptor.
	#[command(hide = true)]
	ReaAsarWorker {
		#[arg(long)]
		request: String,
	},
	/// Internal ZIP directory parser over one admitted read-only descriptor.
	#[command(hide = true)]
	ReaArchiveWorker {
		#[arg(long)]
		request: String,
	},
}

#[cfg(test)]
#[path = "cli_tests.rs"]
mod tests;
