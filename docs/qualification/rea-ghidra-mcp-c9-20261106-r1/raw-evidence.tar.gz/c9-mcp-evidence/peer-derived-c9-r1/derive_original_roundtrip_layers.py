#!/usr/bin/env python3
"""Add comparison layers to the immutable C9 peer assessment; no engines/imported producer."""
import hashlib
import importlib.util
import json
from pathlib import Path
import zlib

ROOT = Path('/home/qian-qi/work/hepta-rea-ghidra-v4-ecb0b9-20261106-r1/peer-derived-c9-r1')
BASE = ROOT.parent
READER_SHA = 'e6ec1f42b8f398adbf9ad59fecb000507c4ed679f2d4d20326a21e5c61078bb8'
reader_path = ROOT / 'derive_c9_peer_r3.py'
assert hashlib.sha256(reader_path.read_bytes()).hexdigest() == READER_SHA
spec = importlib.util.spec_from_file_location('fixed_private_peer_reader', reader_path)
peer = importlib.util.module_from_spec(spec)
spec.loader.exec_module(peer)


def pin(raw):
    return {'bytes': len(raw), 'sha256': peer.sha(raw)}


def byte_difference(left, right):
    first = next((i for i, (a, b) in enumerate(zip(left, right)) if a != b),
                 min(len(left), len(right)))
    return {'equal': left == right, 'original': pin(left), 'comparison': pin(right),
            'first_different_byte': None if left == right else first,
            'original_context_utf8': left[max(0, first - 70):first + 110].decode('utf-8', 'replace'),
            'comparison_context_utf8': right[max(0, first - 70):first + 110].decode('utf-8', 'replace')}


def order_differences(left, right, path='$'):
    if type(left) is dict and type(right) is dict:
        if list(left) != list(right):
            yield {'path': path, 'original_keys': list(left), 'comparison_keys': list(right)}
        for key in sorted(left.keys() & right.keys()):
            yield from order_differences(left[key], right[key], path + '[' + json.dumps(key) + ']')
    elif type(left) is list and type(right) is list:
        for i, (a, b) in enumerate(zip(left, right)):
            yield from order_differences(a, b, path + f'[{i}]')


def compact(value, sort=False):
    return json.dumps(value, ensure_ascii=False, sort_keys=sort, separators=(',', ':'), allow_nan=False).encode()


def row_reference(value):
    return {'tool': value['row']['tool'], 'arguments': value['row']['arguments'],
            'request_id': value['row']['request_id'], 'result': value['row']['result_raw'],
            'opaque_text': value['row']['content_text_utf8'], 'response_wire': value['row']['response_wire'],
            'structured_content': value['row'].get('structured_content_raw')}


def paired(label, left, right, diff_rows):
    lp, rp = peer.parse(left['text']), peer.parse(right['text'])
    differences = list(peer.differences(left['result'], right['result']))
    diff_rows.extend({'check': label, **row} for row in differences)
    return {'id': label, 'kind': 'two_actual_calltoolresults', 'original': row_reference(left),
            'comparison': row_reference(right), 'parsed_text_value_equal_type_sensitive': peer.equal(lp, rp),
            'structured_content_equal_type_sensitive': peer.equal(left['result']['structuredContent'], right['result']['structuredContent']),
            'complete_calltoolresult_equal_preserving_opaque_text': peer.equal(left['result'], right['result']),
            'opaque_content_text': byte_difference(left['text'].encode(), right['text'].encode()),
            'raw_calltoolresult': byte_difference(left['raw_result'], right['raw_result']),
            'raw_jsonrpc_frame': byte_difference(left['raw_frame'], right['raw_frame']),
            'export_member_bytes': None, 'export_member_comparison_reason': 'No export is involved in this pair.',
            'complete_calltoolresult_difference_count': len(differences),
            'object_member_order_changes_in_parsed_text': list(order_differences(lp, rp)),
            'both_texts_exact_compact_serializations_of_their_own_ordered_values':
                left['text'].encode() == compact(lp) and right['text'].encode() == compact(rp)}


def exported(label, row, export, export_pin):
    structured = peer.artifact(BASE / 'mcp-original-c9-r1', row['row']['structured_content_raw'])
    start, end = peer.member_span(structured, 'result')
    member = structured[start:end]
    value, exported_value = peer.parse(member), peer.parse(export)
    return {'id': label, 'kind': 'actual_bundle_member_and_original_export_file',
            'original': row_reference(row), 'export': export_pin,
            'parsed_bundle_value_equal_type_sensitive': peer.equal(value, exported_value),
            'complete_calltoolresult_equal_preserving_opaque_text': None,
            'opaque_content_text': None, 'raw_calltoolresult': None, 'raw_jsonrpc_frame': None,
            'not_applicable_reason': 'An export file is not a second CallToolResult or JSON-RPC frame.',
            'export_member_bytes': byte_difference(export, member),
            'export_is_exact_sorted_compact_encoding_of_bundle_value': compact(value, sort=True) == export,
            'object_member_order_changes_export_to_member': list(order_differences(exported_value, value))}


def main():
    original_root = BASE / 'mcp-original-c9-r1'
    cap_raw = peer.read(original_root / 'capture.json')
    assert peer.sha(cap_raw) == peer.PINS['mcp-original-c9-r1/capture.json']
    capture = peer.parse(cap_raw)
    states = {s['id']: s for s in capture['sessions']}
    original = peer.session(original_root, states['original-main'])['rows']
    restored = peer.session(original_root, states['original-import'])['rows']
    export = peer.artifact(original_root, capture['complete_export'])
    all_diffs = []
    rows = [paired('same-retained-page-exact', original['inventory-page-0'], original['inventory-page-repeat'], all_diffs),
            exported('export-equals-complete-bundle', original['bundle-complete'], export, capture['complete_export']),
            paired('export-preserves-complete-bundle', original['bundle-complete'], original['bundle-after-export'], all_diffs)]
    empty = restored['empty-before-import']
    empty_bundle = empty['result']['structuredContent']['result']
    rows.append({'id': 'new-session-has-no-implicit-retention', 'kind': 'single_actual_empty_retention_observation',
                 'original': row_reference(empty), 'record_count': len(empty_bundle['records']),
                 'all_seven_bundle_list_counts': {key: len(value) for key, value in empty_bundle.items()},
                 'predicate_empty_records': empty_bundle['records'] == [],
                 'paired_parsed_value_equal': None, 'complete_calltoolresult_equal_preserving_opaque_text': None,
                 'opaque_content_text': None, 'raw_calltoolresult': None, 'raw_jsonrpc_frame': None,
                 'export_member_bytes': None,
                 'not_applicable_reason': 'A single empty-retention predicate has no second text, frame, or export.'})
    rows.extend([paired('explicit-import-exact-complete-readback', original['bundle-complete'], restored['complete-after-import'], all_diffs),
                 exported('explicit-import-equals-exported-bytes-value', restored['complete-after-import'], export, capture['complete_export']),
                 paired('imported-retained-page-exact', original['inventory-page-0'], restored['page-after-import'], all_diffs)])
    assert [r['id'] for r in rows] == [r['id'] for r in capture['checks']]
    for original_pin in list(peer.INPUTS.values()):
        peer.read(Path(original_pin['path']), original_pin)
    raw = b''.join((json.dumps(item, ensure_ascii=True, sort_keys=True, allow_nan=False) + '\n').encode() for item in all_diffs)
    compressor = zlib.compressobj(9, zlib.DEFLATED, 31)
    packed = compressor.compress(raw) + compressor.flush()
    diff_path = ROOT / 'original-roundtrip-complete-differences.jsonl.gz'
    with diff_path.open('xb') as stream:
        stream.write(packed)
    result = {'schema': 'hepta.rea.ghidra-c9-original-roundtrip-comparison-layers.v1',
              'qualified': False, 'complete_upstream_parity_qualified': False,
              'source_commit': capture['source_commit'], 'capture_sha256': peer.sha(cap_raw),
              'comparison_levels_are_not_interchangeable': True,
              'producer_equal_booleans_used_as_proof': False, 'current_repo_source_read': False,
              'raw_or_opaque_inputs_rewritten': False, 'engines_started': 0,
              'script': {'path': str(Path(__file__).absolute()), **pin(Path(__file__).read_bytes())},
              'fixed_private_reader': {'path': str(reader_path), 'sha256': READER_SHA},
              'checks': rows,
              'complete_opaque_difference_artifact': {'path': str(diff_path), **pin(packed),
                                                       'raw': pin(raw), 'rows': len(all_diffs)},
              'interpretation': ['All seven producer checks concern parsed values or a single empty-retention predicate.',
                                 'Three paired result/text comparisons are byte-exact; their raw RPC frames differ because real request IDs differ.',
                                 'Full bundle before/after explicit import has equal typed parsed payload and structuredContent, but unequal opaque text and complete CallToolResult.',
                                 'This observed opaque change is solely object member order: values/types are equal and both texts exactly match compact serialization of their own member order.',
                                 'Before/after complete bundle values both sort-compact to the actual export bytes; actual member bytes differ from export bytes.',
                                 'The original seven parsed checks do not establish native Provider Evidence equivalence.']}
    path = ROOT / 'original-roundtrip-comparison-layers.json'
    encoded = (json.dumps(result, ensure_ascii=True, sort_keys=True, indent=2, allow_nan=False) + '\n').encode()
    with path.open('xb') as stream:
        stream.write(encoded)
    print(json.dumps({'path': str(path), **pin(encoded), 'check_count': len(rows),
                      'opaque_changed_checks': [r['id'] for r in rows if isinstance(r.get('opaque_content_text'), dict)
                                                and r['opaque_content_text']['equal'] is False],
                      'full_difference_rows': len(all_diffs), 'qualified': False}, sort_keys=True))


if __name__ == '__main__':
    main()
