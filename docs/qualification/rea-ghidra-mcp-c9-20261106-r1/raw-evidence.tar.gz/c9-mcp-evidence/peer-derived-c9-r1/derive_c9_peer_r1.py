#!/usr/bin/env python3
"""Independent, fixed-input C9 raw-wire audit. No producer/repository imports."""

import collections
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import stat
import sys
import zlib


BASE = Path('/home/qian-qi/work/hepta-rea-ghidra-v4-ecb0b9-20261106-r1')
OUTPUT = BASE / 'peer-derived-c9-r1'
COMMIT = 'c9c79e27a2bf56bd204df6591ca2311dc872e317'
PINS = {
    'mcp-original-c9-r1/capture.json': '2981ca455fbb9f64c0d7a7917afc79a34e869f05c5b6d5f7f1c5ea8be937fb82',
    'mcp-native-wire-c9-r1/capture.json': '5355fd59368b14fe80846f457bad0e4aee857ba3ae02dbe84d2194c9f95937dd',
}
MAX_FILE = 16 * 1024 * 1024
INPUTS = {}
MISSING = object()


def require(condition, message):
    if not condition:
        raise ValueError(message)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def pairs(rows):
    result = {}
    for key, value in rows:
        require(key not in result, 'duplicate JSON key: ' + key)
        result[key] = value
    return result


def parse(raw):
    return json.loads(raw, object_pairs_hook=pairs,
                      parse_constant=lambda value: (_ for _ in ()).throw(ValueError(value)))


def equal(a, b):
    if type(a) is not type(b):
        return False
    if isinstance(a, dict):
        return a.keys() == b.keys() and all(equal(a[key], b[key]) for key in a)
    if isinstance(a, list):
        return len(a) == len(b) and all(equal(x, y) for x, y in zip(a, b))
    return a == b


def read(path, pin=None, cap=MAX_FILE):
    path = Path(path)
    require(path.is_absolute(), 'nonabsolute actual input')
    relative = path.relative_to(BASE)
    current = BASE
    for part in relative.parts:
        require(part not in ('', '.', '..'), 'ambiguous path')
        current = current / part
        require(not stat.S_ISLNK(current.lstat().st_mode), 'symlink input: ' + str(current))
    info = path.lstat()
    require(stat.S_ISREG(info.st_mode) and info.st_nlink == 1 and info.st_size <= cap,
            'input type, links, or size: ' + str(path))
    raw = path.read_bytes()
    digest = sha(raw)
    require(len(raw) == info.st_size, 'input changed during read')
    if pin is not None:
        require(type(pin['bytes']) is int and len(raw) == pin['bytes']
                and digest == pin['sha256'], 'input pin mismatch: ' + str(path))
    actual = {'path': str(path), 'bytes': len(raw), 'sha256': digest}
    require(str(path) not in INPUTS or INPUTS[str(path)] == actual, 'input changed between reads')
    INPUTS[str(path)] = actual
    return raw


def artifact(root, pin):
    require(isinstance(pin, dict), 'missing artifact pin')
    name = pin['path']
    require(isinstance(name, str), 'artifact path type')
    p = PurePosixPath(name)
    require(str(p) == name and '..' not in p.parts, 'noncanonical artifact path')
    return read(Path(name) if p.is_absolute() else root / name, pin)


def inflate(root, entry):
    require(set(entry) == {'direction', 'monotonic_ns', 'encoding', 'path', 'raw_bytes',
                           'raw_sha256', 'gzip_bytes', 'gzip_sha256'}, 'wire index fields')
    require(entry['encoding'] == 'gzip-original-jsonrpc-line', 'wire encoding')
    require(type(entry['raw_bytes']) is int and 0 < entry['raw_bytes'] <= MAX_FILE,
            'raw frame size')
    packed = artifact(root, {'path': entry['path'], 'bytes': entry['gzip_bytes'],
                             'sha256': entry['gzip_sha256']})
    reader = zlib.decompressobj(31)
    raw = reader.decompress(packed, MAX_FILE + 1)
    require(reader.eof and not reader.unused_data and not reader.unconsumed_tail,
            'truncated, trailing, multiple-member, or over-limit gzip')
    require(len(raw) == entry['raw_bytes'] and sha(raw) == entry['raw_sha256'], 'wire raw pin')
    require(raw.endswith(b'\n') and raw.count(b'\n') == 1, 'not exactly one LF JSON-RPC line')
    return raw


def member_span(raw, key):
    """Find the actual direct member value, independently of claimed offsets."""
    text = raw.decode('utf-8')
    decoder = json.JSONDecoder(object_pairs_hook=pairs)
    length = len(text)

    def ws(index):
        while index < length and text[index].isspace():
            index += 1
        return index

    index = ws(0)
    require(index < length and text[index] == '{', 'member parent is not an object')
    index = ws(index + 1)
    found = None
    while index < length and text[index] != '}':
        name, index = decoder.raw_decode(text, index)
        require(type(name) is str, 'member name is not string')
        index = ws(index)
        require(text[index] == ':', 'member colon')
        start = ws(index + 1)
        _, end = decoder.raw_decode(text, start)
        if name == key:
            require(found is None, 'duplicate direct member')
            found = (len(text[:start].encode('utf-8')), len(text[:end].encode('utf-8')))
        index = ws(end)
        if text[index] == ',':
            index = ws(index + 1)
        else:
            require(text[index] == '}', 'member separator')
    require(found is not None, 'direct member missing: ' + key)
    return found


def normal_close(value):
    return (type(value.get('returncode')) is int and value['returncode'] == 0
            and value.get('forced_cleanup') == []
            and all(value.get(name) is True for name in
                    ['owner_pidfd_exited', 'process_group_gone', 'reader_stopped']))


def session(root, state, extra_tool_ids=()):
    sid = state['id']
    wire_pin = state['client_artifacts']['wire.jsonl']
    wire_root = root / str(PurePosixPath(wire_pin['path']).parent)
    wire = artifact(root, wire_pin)
    require(wire.endswith(b'\n'), 'wire index has no terminal LF')
    entries = [parse(line) for line in wire.splitlines()]
    require(len(entries) <= 256, 'unexpected transcript size')
    close = parse(artifact(root, state['client_artifacts']['close.json']))
    require(equal(close, state['close']), 'close receipt differs from original')
    launch = parse(artifact(root, state['client_artifacts']['launch.json']))
    artifact(root, state['client_artifacts']['stderr.log'])
    row_ids = [row['request_id'] for row in state['calls']]
    require(len(set(row_ids)) == len(row_ids), 'duplicate row request ID')
    sent, received, by_path, notifications = {}, {}, {}, []
    previous = -1
    total = 0
    for entry in entries:
        require(type(entry['monotonic_ns']) is int and entry['monotonic_ns'] >= 0
                and entry['monotonic_ns'] >= previous, 'wire time ordering')
        previous = entry['monotonic_ns']
        require(entry['path'] not in by_path, 'duplicate wire path')
        by_path[entry['path']] = entry
        raw = inflate(wire_root, entry)
        total += len(raw)
        require(total <= 64 * 1024 * 1024, 'session raw bytes budget')
        value = parse(raw)
        require(type(value) is dict and value.get('jsonrpc') == '2.0', 'invalid JSON-RPC')
        direction = entry['direction']
        require(direction in ('sent', 'received'), 'wire direction')
        if 'id' not in value:
            notifications.append({'entry': entry, 'message': value})
            continue
        rid = value['id']
        require(type(rid) is int and rid > 0, 'noninteger or invalid ID')
        if direction == 'sent':
            require(rid not in sent and 'method' in value and 'result' not in value
                    and 'error' not in value, 'invalid or duplicate request')
            sent[rid] = (entry, raw, value)
        else:
            require(rid in sent and rid not in received and 'method' not in value
                    and (('result' in value) != ('error' in value)), 'unmatched/duplicate response')
            # Catalog replies can exceed 11 MiB. Verify them, then retain only
            # the identity unless a comparison row actually consumes them.
            received[rid] = ((entry, raw, value) if rid in row_ids
                             else (entry, None, {'jsonrpc': value['jsonrpc'], 'id': rid,
                                                'has_error': 'error' in value}))
    call_ids = [rid for rid, (_, _, value) in sent.items() if value['method'] == 'tools/call']
    require([rid for rid in call_ids if rid not in extra_tool_ids] == row_ids,
            'case rows differ from actual tools/call order')
    require(set(call_ids) == set(row_ids) | set(extra_tool_ids), 'unaccounted tools/call')
    rows = {}
    for row in state['calls']:
        require(row['id'] not in rows, 'duplicate case label')
        rid = row['request_id']
        require(rid in received, 'comparison lacks actual reply')
        request_entry, request_raw, request = sent[rid]
        response_entry, response_raw, response = received[rid]
        require(equal(row['request_wire'], request_entry)
                and equal(row['response_wire'], response_entry), 'row-to-index pin mismatch')
        require(equal(request['params'], {'name': row['tool'], 'arguments': row['arguments']})
                and request['method'] == 'tools/call', 'row-to-request mismatch')
        require(equal(response, row['response_parsed']), 'row-to-response mismatch')
        require('result' in response, 'RPC errors require a separate comparison profile')
        result = response['result']
        raw_result = artifact(root, row['result_raw'])
        span = member_span(response_raw, 'result')
        require(list(span) == row['result_raw']['source_frame_range']
                and response_raw[slice(*span)] == raw_result and equal(parse(raw_result), result),
                'result is not its exact direct raw frame slice')
        structured = row['structured_content_raw']
        if structured is None:
            require('structuredContent' not in result, 'missing structured evidence artifact')
        else:
            original = artifact(root, structured)
            relative_span = member_span(raw_result, 'structuredContent')
            absolute_span = [span[0] + part for part in relative_span]
            require(absolute_span == structured['source_frame_range']
                    and response_raw[slice(*absolute_span)] == original
                    and equal(parse(original), result['structuredContent']), 'structured raw mismatch')
        content = result.get('content')
        require(type(content) is list and len(content) == len(row['content_text_utf8']), 'content count')
        for item, pin in zip(content, row['content_text_utf8']):
            require(item['type'] == 'text' and type(item['text']) is str
                    and artifact(root, pin) == item['text'].encode('utf-8'), 'opaque content changed')
        rows[row['id']] = {'result': result, 'raw_result': raw_result, 'raw_frame': response_raw,
                           'row': row, 'text': content[0]['text']}
    return {'rows': rows, 'close': close, 'launch': launch, 'normal_close': normal_close(close),
            'summary': {'id': sid, 'row_count': len(rows), 'wire_frames': len(entries),
                        'raw_wire_bytes': total, 'request_count': len(sent), 'response_count': len(received),
                        'unanswered_request_ids': sorted(set(sent) - set(received)),
                        'normal_close': normal_close(close), 'close': close,
                        'first_wire_ns': entries[0]['monotonic_ns'],
                        'last_wire_ns': entries[-1]['monotonic_ns'],
                        'notifications': notifications, 'client_artifacts': state['client_artifacts']}}


def differences(a, b, path='$'):
    if a is MISSING or b is MISSING:
        value = b if a is MISSING else a
        if isinstance(value, dict) and value:
            for key in sorted(value):
                yield from differences(MISSING if a is MISSING else value[key],
                                       value[key] if a is MISSING else MISSING,
                                       path + '[' + json.dumps(key) + ']')
        elif isinstance(value, list) and value:
            for index, item in enumerate(value):
                yield from differences(MISSING if a is MISSING else item,
                                       item if a is MISSING else MISSING, path + f'[{index}]')
        else:
            yield {'path': path, 'kind': 'missing_original' if a is MISSING else 'missing_native',
                   **({'native': b} if a is MISSING else {'original': a})}
    elif type(a) is not type(b):
        yield {'path': path, 'kind': 'type', 'original': a, 'native': b}
    elif isinstance(a, dict):
        for key in sorted(a.keys() | b.keys()):
            yield from differences(a.get(key, MISSING), b.get(key, MISSING),
                                   path + '[' + json.dumps(key) + ']')
    elif isinstance(a, list):
        for index in range(max(len(a), len(b))):
            yield from differences(a[index] if index < len(a) else MISSING,
                                   b[index] if index < len(b) else MISSING, path + f'[{index}]')
    elif a != b:
        yield {'path': path, 'kind': 'value', 'original': a, 'native': b}


def body(row):
    return parse(row['text'])


def bridge(row):
    return parse(body(row)['report']['stdout'])


def evidence(row):
    value = row['result']['structuredContent']
    require('evidence_id' in value and 'normalized_result' in value, 'not an original Evidence')
    return value


def original_reference(row):
    kind = row['kind']
    return {'from_address': row['source_address'], 'to_address': row['target_address'],
            'reference_type': kind['type'], 'operand_index': kind['operand_index'],
            'call': kind['call'], 'primary': kind['primary']}


def native_reference(row):
    return {key: row[key] for key in
            ('from_address', 'to_address', 'reference_type', 'operand_index', 'call', 'primary')}


def save(name, value):
    raw = (json.dumps(value, ensure_ascii=True, sort_keys=True, indent=2, allow_nan=False) + '\n').encode()
    path = OUTPUT / name
    with path.open('xb') as stream:
        stream.write(raw)
    return {'path': str(path), 'bytes': len(raw), 'sha256': sha(raw)}


def main():
    require(not (OUTPUT / 'summary.json').exists(), 'do not overwrite an earlier peer assessment')
    OUTPUT.mkdir(exist_ok=True)
    captures = {}
    for relative, digest in PINS.items():
        raw = read(BASE / relative, cap=4 * 1024 * 1024)
        require(sha(raw) == digest, 'capture differs from independently supplied SHA')
        value = parse(raw)
        require(value['source_commit'] == COMMIT, 'wrong historical candidate')
        captures[relative.split('/')[0]] = value
    oc = captures['mcp-original-c9-r1']
    nc = captures['mcp-native-wire-c9-r1']
    require([s['id'] for s in oc['sessions']] == ['original-main', 'original-import', 'original-cancel'],
            'unexpected original owner set')
    require([s['id'] for s in nc['sessions']] == ['native-readback'], 'unexpected native capture owner set')
    owners = {}
    for cap, directory in [(oc, 'mcp-original-c9-r1'), (nc, 'mcp-native-wire-c9-r1')]:
        for state in cap['sessions']:
            extra = (oc['cancellation']['request_id'],) if state['id'] == 'original-cancel' else ()
            owners[state['id']] = session(BASE / directory, state, extra)
    o = owners['original-main']['rows']
    i = owners['original-import']['rows']
    n = owners['native-readback']['rows']
    fixed_pairs = [('functions', 'functions-entry'), ('function-entry', 'function-entry'),
                   ('function-interior', 'function-interior'), ('incoming-entry', 'xrefs-entry'),
                   ('incoming-interior', 'xrefs-interior'), ('outgoing-entry', 'xrefs-entry'),
                   ('outgoing-interior', 'xrefs-interior'), ('decompile-entry', 'decompile-entry'),
                   ('decompile-interior', 'decompile-interior'), ('function-unmapped', 'function-unmapped'),
                   ('invalid-extra-field', 'invalid-selector-3')]
    compared, full_diff = [], []
    for original_name, native_name in fixed_pairs:
        left, right = o[original_name], n[native_name]
        case = original_name + '__' + native_name
        items = list(differences(left['result'], right['result']))
        full_diff.extend({'case': case, **item} for item in items)
        compared.append({'case': case, 'original_tool': left['row']['tool'], 'native_tool': right['row']['tool'],
                         'same_public_contract': False,
                         'complete_call_tool_result_equal': equal(left['result'], right['result']),
                         'opaque_content_text_equal': equal(left['result']['content'], right['result']['content']),
                         'result_raw_bytes_equal': left['raw_result'] == right['raw_result'],
                         'full_rpc_frame_bytes_equal': left['raw_frame'] == right['raw_frame'],
                         'complete_result_diff_leaf_count': len(items),
                         'original_result': left['row']['result_raw'], 'native_result': right['row']['result_raw'],
                         'original_response_wire': left['row']['response_wire'],
                         'native_response_wire': right['row']['response_wire'],
                         'original_evidence_fields': list(left['result'].get('structuredContent', {})),
                         'native_structured_content_present': 'structuredContent' in right['result']})
    raw_diff = b''.join((json.dumps(row, ensure_ascii=True, sort_keys=True, allow_nan=False) + '\n').encode()
                        for row in full_diff)
    compressor = zlib.compressobj(9, zlib.DEFLATED, 31)
    packed = compressor.compress(raw_diff) + compressor.flush()

    original_inventory = evidence(o['functions'])['normalized_result']
    native_inventory_observation = bridge(n['functions-entry'])
    native_inventory = native_inventory_observation['functions'] + native_inventory_observation['external_functions']
    projected_original = {row['address']: {'name': row['value'], 'external': row['procedure']['external'],
                                          'thunk': row['procedure']['thunk']} for row in original_inventory}
    projected_native = {row['entry_address']: {'name': row['name'], 'external': row['external'],
                                              'thunk': row['thunk']} for row in native_inventory}
    require(len(projected_original) == len(original_inventory)
            and len(projected_native) == len(native_inventory), 'duplicate inventory address')
    inventory = {'selected_field_names': ['address', 'name', 'external', 'thunk'],
                 'original_rows': len(original_inventory), 'native_internal_rows': len(native_inventory_observation['functions']),
                 'native_external_rows': len(native_inventory_observation['external_functions']),
                 'four_field_values_equal_by_address': equal(projected_original, projected_native),
                 'original_order': [row['address'] for row in original_inventory],
                 'native_internal_then_external_order': [row['entry_address'] for row in native_inventory],
                 'original_rows_complete': original_inventory, 'native_rows_complete': native_inventory,
                 'native_rows_have_symbol': any('symbol' in row for row in native_inventory),
                 'native_rows_have_thunk_target': any('thunk_target' in row for row in native_inventory),
                 'complete_evidence_equal': False}
    xrefs = []
    decompile = []
    functions = []
    for selector in ('entry', 'interior'):
        xbridge = bridge(n['xrefs-' + selector])
        for direction in ('incoming', 'outgoing'):
            left = evidence(o[direction + '-' + selector])['normalized_result']
            right = xbridge[direction + '_references']
            lp = [original_reference(row) for row in left['references']]
            rp = [native_reference(row) for row in right]
            xrefs.append({'selector': selector, 'direction': direction, 'original_count': len(lp), 'native_count': len(rp),
                          'shared_six_fields_sequence_equal': equal(lp, rp), 'original_projection': lp,
                          'native_projection': rp, 'original_full_references': left['references'],
                          'native_full_references': right,
                          'native_scope': xbridge[direction + '_scope'],
                          'original_reference_kind_fields': sorted(left['references'][0]['kind']),
                          'native_reference_fields': sorted(right[0])})
        original_code = evidence(o['decompile-' + selector])['normalized_result']
        native_code = bridge(n['decompile-' + selector])['c_code']
        decompile.append({'selector': selector, 'exact_c_utf8_equal': original_code.encode() == native_code.encode(),
                          'original_bytes': len(original_code.encode()), 'native_bytes': len(native_code.encode()),
                          'original_sha256': sha(original_code.encode()), 'native_sha256': sha(native_code.encode()),
                          'original_c': original_code, 'native_c': native_code, 'complete_evidence_equal': False})
        original_function = evidence(o['function-' + selector])['normalized_result']
        native_function = bridge(n['function-' + selector])['function']
        functions.append({'selector': selector, 'original_normalized': original_function,
                          'native_function': native_function,
                          'native_missing_direct_fields': [key for key in ('symbol', 'locals', 'basicblock_count', 'thunk_target')
                                                           if key not in native_function],
                          'complete_evidence_equal': False})

    export = artifact(BASE / 'mcp-original-c9-r1', oc['complete_export'])
    require(len(export) == 64297 and sha(export) == 'fa5884427caa3bb8f3effef348f04bc23dccc6d187fd4bb50797f17f4cc57dbd',
            'wrong original export')
    complete_structured = artifact(BASE / 'mcp-original-c9-r1', o['bundle-complete']['row']['structured_content_raw'])
    export_span = member_span(complete_structured, 'result')
    retained = o['bundle-complete']['result']['structuredContent']['result']
    closure = {
        'original_export_raw_bytes_equal_complete_bundle_member': export == complete_structured[slice(*export_span)],
        'original_export_value_equal_complete_bundle': equal(parse(export), retained),
        'export_does_not_change_complete_calltoolresult': equal(o['bundle-complete']['result'], o['bundle-after-export']['result']),
        'new_session_starts_without_records': i['empty-before-import']['result']['structuredContent']['result']['records'] == [],
        'explicit_import_same_export_path': i['import']['row']['arguments']['path'] == o['export']['row']['arguments']['path'],
        'explicit_import_full_result_raw_bytes_equal': o['bundle-complete']['raw_result'] == i['complete-after-import']['raw_result'],
        'explicit_import_summary_raw_bytes_equal': o['bundle-summary']['raw_result'] == i['summary-after-import']['raw_result'],
        'repeated_page_raw_bytes_equal': o['inventory-page-0']['raw_result'] == o['inventory-page-repeat']['raw_result'],
        'explicit_import_page_raw_bytes_equal': o['inventory-page-0']['raw_result'] == i['page-after-import']['raw_result'],
        'retained_records': len(retained['records']),
        'native_same_layer_evidence_bundle_counterpart': 'ABSENT_FROM_THIS_CAPTURE',
        'export_pin': oc['complete_export'],
    }
    require(owners['original-main']['summary']['last_wire_ns'] < owners['original-import']['summary']['first_wire_ns'],
            'original import wire precedes original producer end')

    # The retained report and negative result replay comparisons are additional
    # native-only facts. They cannot establish upstream parity.
    replay = []
    report_files = {'functions-entry': 'functions-result.json', 'function-entry': 'function-result.json',
                    'xrefs-entry': 'xrefs-result.json', 'decompile-entry': 'decompile-result.json',
                    'function-interior': 'interior-function.json', 'xrefs-interior': 'interior-xrefs.json',
                    'decompile-interior': 'interior-decompile.json', 'function-unmapped': 'no-function-refusal.json'}
    for label, name in report_files.items():
        old = parse(artifact(BASE / 'mcp-native-c9-r1', nc['harness_inputs'][name]))
        if name.startswith('interior-') or name == 'no-function-refusal.json':
            old = old['result']
        replay.append({'case': label, 'kind': 'retained_provider_result', 'equal': equal(body(n[label]), old)})
    for label in ['same-key-conflict'] + ['invalid-selector-' + str(k) for k in range(4)]:
        old = parse(artifact(BASE / 'mcp-native-c9-r1', nc['harness_inputs'][label + '.json']))
        replay.append({'case': label, 'kind': 'complete_negative_calltoolresult',
                       'equal': equal(n[label]['result'], old), 'actual_isError': n[label]['result'].get('isError')})
    before = body(n['jobs-before-negative-replays'])
    initial_ids = sorted(job['id'] for job in before['jobs'])
    for k in range(5):
        value = body(n['jobs-after-negative-' + str(k)])
        ids = sorted(job['id'] for job in value['jobs'])
        replay.append({'case': 'jobs-after-negative-' + str(k), 'kind': 'actual_registry_ids',
                       'equal': ids == initial_ids, 'before': initial_ids, 'after': ids})

    fixture_o = read(BASE / 'mcp-original-c9-r1/owned.elf', cap=1024 * 1024)
    fixture_n = read(BASE / 'mcp-native-c9-r1/owned.elf', cap=1024 * 1024)
    require(fixture_o == fixture_n and sha(fixture_o) == 'ec301f409d22314b43b4392fa80ada28213cd75ca77c6cbbbbfe1454555dd64a',
            'different actual binary inputs')
    for pin in list(INPUTS.values()):
        read(Path(pin['path']), pin)
    with (OUTPUT / 'complete-calltoolresult-differences.jsonl.gz').open('xb') as stream:
        stream.write(packed)
    projections = save('selected-observation-comparisons.json', {'inventory': inventory, 'functions': functions,
                                                                'decompile': decompile, 'xrefs': xrefs})
    diff_pin = {'path': str(OUTPUT / 'complete-calltoolresult-differences.jsonl.gz'),
                'bytes': len(packed), 'sha256': sha(packed), 'raw_bytes': len(raw_diff),
                'raw_sha256': sha(raw_diff), 'rows': len(full_diff)}
    inputs_pin = save('authenticated-inputs.json', {'files': sorted(INPUTS.values(), key=lambda row: row['path']),
                                                    'source_files_unchanged_during_offline_audit': True})
    summary = {
        'schema': 'hepta.rea.ghidra-c9-independent-peer-diff.v1', 'qualified': False,
        'complete_upstream_parity_qualified': False, 'historical_source_commit': COMMIT,
        'current_repository_source_read': False, 'producer_pass_booleans_used_as_proof': False,
        'engines_started': 0, 'scope': 'Fixed C9 captured frames only; a provider report is not upstream Evidence.',
        'script': {'path': str(Path(__file__).absolute()), 'sha256': sha(Path(__file__).read_bytes())},
        'capture_pins': PINS, 'same_fixture_bytes': len(fixture_o), 'fixture_sha256': sha(fixture_o),
        'complete_result_pairs': compared,
        'complete_result_equal_count': sum(row['complete_call_tool_result_equal'] for row in compared),
        'opaque_content_equal_count': sum(row['opaque_content_text_equal'] for row in compared),
        'full_rpc_frame_equal_count': sum(row['full_rpc_frame_bytes_equal'] for row in compared),
        'complete_diff': diff_pin, 'selected_observations': projections, 'inputs': inputs_pin,
        'inventory_four_field_values_equal_by_address': inventory['four_field_values_equal_by_address'],
        'inventory_scope': '15 address/name/external/thunk observations; symbol and thunk_target are not projected away from full differences.',
        'c_code_exact_equal_selectors': [row['selector'] for row in decompile if row['exact_c_utf8_equal']],
        'original_export_import_observations': closure,
        'native_replay_observations': replay,
        'native_replay_equal_count': sum(row['equal'] for row in replay),
        'native_after_directory_sets': 'NOT_INDEPENDENTLY_REPLAYABLE: no five separately captured after snapshots; no producer boolean promoted.',
        'capture_owner_sessions': [value['summary'] for value in owners.values()],
        'owner_scope': 'Only these four private capture clients. Historical full-harness controller close is not inferred.',
        'open_boundaries': ['Native Ghidra report has no same-layer complete upstream Evidence/bundle/export/import proof.',
                            'Nine successful original Evidence calls have no native structuredContent counterpart.',
                            'Native inventory lacks original symbol and thunk_target observations.',
                            'Native selected function lacks original locals/basicblock_count/symbol/thunk_target observations.',
                            'Native xrefs lack related source/target procedures and multiple reference-kind observations.',
                            'Incoming C9 has a synthetic Entry Point row and a different remaining row order.',
                            'Outgoing C9 formats negative stack addresses as display labels rather than original unsigned64 canonical strings.',
                            'Raw RPC frame comparison includes actual request IDs and provider/tool contract differences.',
                            'Invalid selector type has no identical native case in this captured pairing.',
                            'This audit does not establish deadline, causal cancellation, cross-platform, release, or all-operation qualification.'],
    }
    summary_pin = save('summary.json', summary)
    print(json.dumps({'summary': summary_pin, 'pairs': len(compared), 'full_equal': summary['complete_result_equal_count'],
                      'opaque_equal': summary['opaque_content_equal_count'], 'frame_equal': summary['full_rpc_frame_equal_count'],
                      'native_replay_equal': summary['native_replay_equal_count'], 'native_replay_count': len(replay),
                      'qualified': False}, sort_keys=True))


if __name__ == '__main__':
    main()
