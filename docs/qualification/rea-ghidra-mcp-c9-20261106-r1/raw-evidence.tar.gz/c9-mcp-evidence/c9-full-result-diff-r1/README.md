# C9 Ghidra: complete captured results and explicit differences

This is a historical, unqualified cross-implementation comparison. Native fixed-profile execution passed its 13 harness checks. Native raw follow-up recorded 23/23 internal comparisons; this independent derivation can reconstruct 18 report/error/registry comparisons. Five before/after directory checks were retained only as producer booleans, so those five are not independently rederived here.

The original npm MCP execution produced complete Evidence, a 64,297-byte exported bundle containing 13 records, and exact explicit import/readback in a fresh session. All seven original roundtrip checks are independently rederived from the original raw frames and export.

## Complete results remain different

All eleven declared full CallToolResult pairs differ, as do their opaque text bytes and raw JSON-RPC frames. The field ledger retains every field, including metadata, paths, errors, and native operational details. It also contains every leaf of the complete original Evidence bundle. No same-layer native static-provider Evidence bundle was captured; complete provider reports are not a substitute.

The current native functions schema agrees on 15 exact addresses and four common fields per row (address, name, external, thunk), or 60/60 fields. It does not expose the original symbol metadata or thunk targets. This is not the old diagnostic six-field projection and not complete inventory parity.

Both entry and interior selectors produce the same complete 63-byte C text in both implementations. Native incoming references include one synthetic Entry Point row (4 versus 3). Native stack targets are display strings (Stack[-0xc]) instead of the original canonical stack:0xfffffffffffffff4. Fixed original source additionally covers function body plus entry, deduplicates, and sorts; the native baseline uses entry-only incoming enumeration. This source-domain gap is explicit and has not been promoted into a fixture-based equivalence claim.

Original function/local/block/provenance metadata, nested reference procedure identities and extra reference kinds remain recorded as original-only fields. Native job/process/cleanup and bounded-analysis fields remain native-only. Shared scalar fields are compared with types intact; a numeric count and its decimal string remain different encodings.

## Cancellation and ownership

There was exactly one original live cancellation attempt. The original raw wire records the selected request and one cancellation notification after the witnessed Java/native process was live. After close and complete drain, there was no response to that original request ID and the complete retained bundle was unchanged. This is an observational result, not causal proof or native durable-job equivalence.

The four fully instrumented MCP owners (native raw follow-up plus three original sessions) closed normally with no forced fallback. All 68 sampled descendant observations exited. A separate read-only census examined 81 previously recorded PID/start identities and the exact owned unit cgroups: all original identities were absent or reused, no matching current processes remained, and no observation error occurred. The frozen native full harness used a legacy close helper whose 5-second kill fallback was not separately recorded; this evidence does not reconstruct that missing history.

## Files

- summary.json: complete results, limits, counts, and output hashes.
- comparison-policy.json and mapping-definitions.json: exact comparison and join rules.
- raw-and-opaque-comparisons.json: byte identities for complete frames, CallToolResults and opaque text.
- field-differences.jsonl.gz: complete typed leaf ledger; no values are truncated.
- mapped-observations.json: inventory, C text and reference projections.
- complete-evidence-layer.json: complete bundle boundary and missing native counterpart.
- negative-cases.json: all sampled error inputs and full responses, including unpaired negatives.
- cancellation-observation.json and wire-verification.json: independent wire checks and ownership scope.
- inputs-manifest.json: SHA256 for every input actually read.

The selected release/JDK/input are fixed. Original diagnostics directly record NoReturnFix cleared=0 sites=0 refit=0 for this fixture; native does not execute that repair script. Other targets remain open. The original complete 146-option snapshot was not directly sampled, even though its default configuration is supported by pinned source and logs.
