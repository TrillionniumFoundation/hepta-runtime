#!/usr/bin/env python3
# Copyright 2026 TrillionniumFoundation
# SPDX-License-Identifier: Apache-2.0
"""Derive a lossless, explicitly layered C9 comparison. Never execute an engine."""
from pathlib import Path
import collections
import gzip
import hashlib
import json

BASE=Path("/home/qian-qi/work/hepta-rea-ghidra-v4-ecb0b9-20261106-r1")
OUT=BASE/"c9-full-result-diff-r1"
PINS={
 "mcp-native-wire-c9-r1/capture.json":"5355fd59368b14fe80846f457bad0e4aee857ba3ae02dbe84d2194c9f95937dd",
 "mcp-original-c9-r1/capture.json":"2981ca455fbb9f64c0d7a7917afc79a34e869f05c5b6d5f7f1c5ea8be937fb82",
 "mcp-native-c9-r1/qualification.json":"5c5b7ca8862c56668073cc35ee03481771d603bf0eed01e50cce7429c302ed77",
 "mcp-original-c9-r1/original-complete.bundle.json":"fa5884427caa3bb8f3effef348f04bc23dccc6d187fd4bb50797f17f4cc57dbd",
 "c9-source-snapshot/manifest.json":"d4dab7bdee3e00f00154c7fbb8a925337313f209ee3c9442c5b2daf69a43f143",
 "c9-post-execution-owner-census.json":"4b91630b7e4d370c2c9dae02a20b1549e9a0d27a13e3fd2930d3cf301fc19037",
 "c9-original-xref-source.json":"9cb8a3af824bf0eed53feabeaff8115fda91edf03fa58e9ae21fad90efb6a08e"}
manifest={}
cache={}
def digest(raw):return hashlib.sha256(raw).hexdigest()
def read(path, expected=None):
 path=Path(path)
 assert path.is_absolute() and path.is_relative_to(BASE) and not path.is_symlink(),str(path)
 raw=path.read_bytes()
 key=str(path.relative_to(BASE))
 actual={"path":key,"bytes":len(raw),"sha256":digest(raw)}
 if expected is not None:assert actual["sha256"]==expected,(key,actual)
 if key in manifest:assert manifest[key]==actual,("input changed",key)
 manifest[key]=actual
 cache[key]=raw
 return raw
def pairs_no_duplicates(pairs):
 out={}
 for key,value in pairs:
  assert key not in out,("duplicate JSON key",key)
  out[key]=value
 return out
def parse(raw):
 return json.loads(raw,object_pairs_hook=pairs_no_duplicates,
  parse_constant=lambda value: (_ for _ in ()).throw(ValueError(value)))
def eq(a,b):
 if type(a) is not type(b):return False
 if isinstance(a,dict):return a.keys()==b.keys() and all(eq(a[k],b[k]) for k in a)
 if isinstance(a,list):return len(a)==len(b) and all(eq(x,y) for x,y in zip(a,b))
 return a==b
def ref(root,item):
 raw=read(root/item["path"],item["sha256"])
 assert len(raw)==item["bytes"]
 return raw
def save(name,value):
 raw=(json.dumps(value,ensure_ascii=True,sort_keys=True,indent=2,allow_nan=False)+"\n").encode()
 (OUT/name).write_bytes(raw)
 return {"path":name,"bytes":len(raw),"sha256":digest(raw)}
def pointer_piece(value):return str(value).replace("~","~0").replace("/","~1")
def leaves(value,path=""):
 if isinstance(value,dict) and value:
  for key in sorted(value):
   yield from leaves(value[key],path+"/"+pointer_piece(key))
 elif isinstance(value,list) and value:
  for index,item in enumerate(value):
   yield from leaves(item,path+"/"+str(index))
 else:yield path,value
def get(value,path):
 if path=="" :return value
 for part in path.split("/")[1:]:
  key=part.replace("~1","/").replace("~0","~")
  value=value[int(key)] if isinstance(value,list) else value[key]
 return value

for rel,sha in PINS.items():read(BASE/rel,sha)
native=parse(cache["mcp-native-wire-c9-r1/capture.json"])
original=parse(cache["mcp-original-c9-r1/capture.json"])
qualification=parse(cache["mcp-native-c9-r1/qualification.json"])
bundle=parse(cache["mcp-original-c9-r1/original-complete.bundle.json"])
census=parse(cache["c9-post-execution-owner-census.json"])
assert native["source_commit"]==original["source_commit"]=="c9c79e27a2bf56bd204df6591ca2311dc872e317"
assert native["source_unchanged"] and original["source_unchanged"]
assert native["completed"] and original["completed"] and qualification["qualified"]
OUT.mkdir(exist_ok=False)
wire_facts=[]
sessions={}
def verify_capture(report,dirname):
 root=BASE/dirname
 for session in report["sessions"]:
  sid=session["id"]
  sroot=root/sid
  artifacts=session["client_artifacts"]
  for item in artifacts.values():ref(root,item)
  index=ref(root,artifacts["wire.jsonl"])
  entries=[parse(line) for line in index.splitlines() if line]
  raw_by_path={}
  messages=[]
  for entry in entries:
   assert entry["encoding"]=="gzip-original-jsonrpc-line"
   assert 0<entry["raw_bytes"]<=16*1024*1024
   compressed=read(sroot/entry["path"],entry["gzip_sha256"])
   assert len(compressed)==entry["gzip_bytes"]
   raw=gzip.decompress(compressed)
   assert len(raw)==entry["raw_bytes"] and digest(raw)==entry["raw_sha256"]
   assert raw.endswith(b"\n")
   message=parse(raw)
   assert entry["path"] not in raw_by_path
   raw_by_path[entry["path"]]=raw
   messages.append((entry,message))
  for call in session["calls"]:
   assert call["status"]=="OBSERVED"
   request=parse(raw_by_path[call["request_wire"]["path"]])
   response=raw_by_path[call["response_wire"]["path"]]
   parsed=parse(response)
   assert eq(parsed,call["response_parsed"])
   assert request["id"]==parsed["id"]==call["request_id"]
   assert request["method"]=="tools/call"
   assert eq(request["params"],{"name":call["tool"],"arguments":call["arguments"]})
   for name in ("result_raw","error_raw","structured_content_raw"):
    if name not in call:continue
    item=call[name];raw=ref(root,item)
    start,end=item["source_frame_range"]
    assert response[start:end]==raw
    key="result" if name=="result_raw" else "error"
    value=parsed.get(key) if name!="structured_content_raw" else parsed["result"]["structuredContent"]
    assert eq(parse(raw),value)
   texts=[x["text"].encode() for x in parsed.get("result",{}).get("content",[]) if x.get("type")=="text"]
   assert len(texts)==len(call["content_text_utf8"])
   for raw,item in zip(texts,call["content_text_utf8"]):assert ref(root,item)==raw
   call["_response_bytes"]=response
   call["_root"]=root
   call["_session"]=sid
  process_raw=read(root/(sid+"-processes.json"))
  assert eq(parse(process_raw),session["processes"])
  assert session["wire_capture_drained"] and session["close"]["returncode"]==0
  assert session["close"]["forced_cleanup"]==[] and session["close"]["owner_pidfd_exited"]
  assert session["close"]["process_group_gone"] and session["close"]["reader_stopped"]
  assert session["processes"]["all_observed_original_identities_exited_without_fallback"]
  sessions[sid]=(session,messages)
  wire_facts.append({"session":sid,"frames":len(entries),"sent":sum(x["direction"]=="sent" for x in entries),
   "received":sum(x["direction"]=="received" for x in entries),"calls_with_exact_request_response_binding":len(session["calls"]),
   "all_raw_frame_hashes_verified":True,"all_saved_result_slices_verified":True,"all_opaque_text_utf8_verified":True,
   "owner":session["close"]["owner"],"normal_close":True,
   "observed_descendants":len(session["processes"]["observations"]),"observer_errors":session["processes"]["errors"]})
verify_capture(native,"mcp-native-wire-c9-r1")
verify_capture(original,"mcp-original-c9-r1")
N={v["id"]:v for v in sessions["native-readback"][0]["calls"]}
O={v["id"]:v for v in sessions["original-main"][0]["calls"]}
I={v["id"]:v for v in sessions["original-import"][0]["calls"]}
C={v["id"]:v for v in sessions["original-cancel"][0]["calls"]}
def payload(call,required=True):
 result=call["response_parsed"].get("result",{})
 texts=[v["text"] for v in result.get("content",[]) if v.get("type")=="text"]
 value=None
 if len(texts)==1:
  try:value=parse(texts[0])
  except (ValueError,TypeError):pass
 if "structuredContent" in result:
  assert eq(result["structuredContent"],value)
  return result["structuredContent"]
 if required:assert value is not None
 return value
def analysis(call):
 p=payload(call)
 return {"provider_report":p,"analysis_stdout":parse(p["report"]["stdout"])}
def source_description(call):
 return {"session":call["_session"],"case":call["id"],"tool":call["tool"],"arguments":call["arguments"],
  "request_frame":call["request_wire"],"response_frame":call["response_wire"],
  "result_raw":call.get("result_raw"),"error_raw":call.get("error_raw"),
  "structured_content_raw":call.get("structured_content_raw"),"content_text_utf8":call["content_text_utf8"]}

rows=[]
counts=collections.Counter()
def emit(layer,pair,opath,oval,npath,nval,have_o=True,have_n=True,mapping="identical JSON pointer"):
 status=("MATCH" if eq(oval,nval) else "DIFF") if have_o and have_n else ("ORIGINAL_ONLY" if have_o else "NATIVE_ONLY")
 item={"layer":layer,"operation_pair":pair,"status":status,"mapping":mapping,
       "original":({"pointer":opath,"value":oval,"json_type":type(oval).__name__} if have_o else None),
       "native":({"pointer":npath,"value":nval,"json_type":type(nval).__name__} if have_n else None)}
 rows.append(item);counts[(layer,pair,status)]+=1
 return status
def positional(layer,pair,a,b):
 left=dict(leaves(a));right=dict(leaves(b))
 for p in sorted(left.keys()|right.keys()):
  emit(layer,pair,p,left.get(p),p,right.get(p),p in left,p in right)
def mapped_semantics(pair,ocall,ncall,kind):
 a=payload(ocall);b=analysis(ncall)
 al=dict(leaves(a));bl=dict(leaves(b));used_a=set();used_b=set()
 mappings=[]
 def m(ap,bp,reason="explicit field-name mapping"):
  if ap not in al or bp not in bl:return
  mappings.append({"original_pointer":ap,"native_pointer":bp,"rule":reason})
  emit("mapped_complete_evidence_vs_native_report",pair,ap,al[ap],bp,bl[bp],mapping=reason)
  used_a.add(ap);used_b.add(bp)
 for ap,bp in (("/subject/digest/sha256","/analysis_stdout/source_sha256"),
               ("/provider/id","/provider_report/report/provider"),
               ("/provider/version","/analysis_stdout/engine_version"),
               ("/operation","/analysis_stdout/operation"),
               ("/parameters/procedure","/analysis_stdout/function_address_requested")):m(ap,bp)
 for key in ("path","canonical_path","original_path"):
  bp="/provider_report/report/subject/"+key
  if bp in bl:m("/subject/local_path",bp);break
 def f(ap,bp,address="entrypoint"):
  for x,y in ((address,"entry_address"),("name","name"),("signature","signature"),
              ("classification/external","external"),("classification/thunk","thunk"),
              ("body/total_bytes","body_address_count")):
   m(ap+"/"+x,bp+"/"+y,"explicit selected-function field mapping; numeric/string encodings remain distinct")
  ar=get(a,ap).get("body",{}).get("ranges",[])
  br=get(b,bp).get("body_ranges",[])
  for index in range(min(len(ar),len(br))):
   for x,y in (("start","min_address"),("end","max_address")):
    m(ap+"/body/ranges/"+str(index)+"/"+x,bp+"/body_ranges/"+str(index)+"/"+y)
 if kind=="functions":
  lookup={}
  for group in ("functions","external_functions"):
   for index,row in enumerate(b["analysis_stdout"][group]):
    assert row["entry_address"] not in lookup
    lookup[row["entry_address"]]=("/analysis_stdout/"+group+"/"+str(index),row)
  for index,row in enumerate(a["normalized_result"]):
   if row["address"] not in lookup:continue
   bp,_=lookup[row["address"]];ap="/normalized_result/"+str(index)
   for x,y in (("address","entry_address"),("value","name"),("procedure/external","external"),("procedure/thunk","thunk")):
    m(ap+"/"+x,bp+"/"+y,"join internal/external arrays by exact address; no ordering or absent metadata inferred")
 elif kind=="function":
  f("/normalized_result","/analysis_stdout/function")
 elif kind=="decompile":
  m("/normalized_result","/analysis_stdout/c_code","exact complete C string, including leading/trailing whitespace")
 elif kind in ("incoming","outgoing"):
  f("/normalized_result/procedure","/analysis_stdout/function","address")
  left=a["normalized_result"]["references"]
  right=b["analysis_stdout"][kind+"_references"]
  def ok(row):return (row["source_address"],row["kind"]["type"],row["kind"]["operand_index"],row["kind"]["primary"])
  def nk(row):return (row["from_address"],row["reference_type"],row["operand_index"],row["primary"])
  lc=collections.Counter(ok(row) for row in left);rc=collections.Counter(nk(row) for row in right)
  rid={nk(row):i for i,row in enumerate(right) if rc[nk(row)]==1}
  for i,row in enumerate(left):
   key=ok(row)
   if lc[key]!=1 or key not in rid:continue
   j=rid[key];ap="/normalized_result/references/"+str(i);bp="/analysis_stdout/"+kind+"_references/"+str(j)
   for x,y in (("source_address","from_address"),("target_address","to_address"),("kind/type","reference_type"),
               ("kind/operand_index","operand_index"),("kind/call","call"),("kind/primary","primary")):
    m(ap+"/"+x,bp+"/"+y,"unique (source,type,operand,primary) join; target encoding remains an exact comparison")
 for p in sorted(al.keys()-used_a):
  emit("mapped_complete_evidence_vs_native_report",pair,p,al[p],None,None,have_n=False,
       mapping="no admitted same-level native field in this captured report")
 for p in sorted(bl.keys()-used_b):
  emit("mapped_complete_evidence_vs_native_report",pair,None,None,p,bl[p],have_o=False,
       mapping="native operational/analysis field has no declared original Evidence counterpart")
 assert {r["original"]["pointer"] for r in rows if r["layer"]=="mapped_complete_evidence_vs_native_report" and r["operation_pair"]==pair and r["original"]}==al.keys()
 assert {r["native"]["pointer"] for r in rows if r["layer"]=="mapped_complete_evidence_vs_native_report" and r["operation_pair"]==pair and r["native"]}==bl.keys()
 return {"pair":pair,"original_leaf_count":len(al),"native_leaf_count":len(bl),"mapped_original_leaf_count":len(used_a),
         "mapped_native_leaf_count":len(used_b),"all_original_and_native_leaves_accounted_for":True,"mappings":mappings}

pairs=[
 ("functions","functions","functions-entry","functions"),
 ("function-entry","function-entry","function-entry","function"),
 ("function-interior","function-interior","function-interior","function"),
 ("incoming-entry","incoming-entry","xrefs-entry","incoming"),
 ("outgoing-entry","outgoing-entry","xrefs-entry","outgoing"),
 ("incoming-interior","incoming-interior","xrefs-interior","incoming"),
 ("outgoing-interior","outgoing-interior","xrefs-interior","outgoing"),
 ("decompile-entry","decompile-entry","decompile-entry","decompile"),
 ("decompile-interior","decompile-interior","decompile-interior","decompile"),
 ("unmapped-address","function-unmapped","function-unmapped",None),
 ("extra-field-refusal","invalid-extra-field","invalid-selector-3",None)]
raw_comparisons=[];mapping_specs=[]
for name,ol,nl,kind in pairs:
 o,n=O[ol],N[nl]
 orpc=o["response_parsed"];nrpc=n["response_parsed"]
 positional("complete_jsonrpc_response_fields",name,orpc,nrpc)
 positional("complete_calltoolresult_fields",name,orpc.get("result"),nrpc.get("result"))
 ot=[ref(o["_root"],r) for r in o["content_text_utf8"]]
 nt=[ref(n["_root"],r) for r in n["content_text_utf8"]]
 oraw=ref(o["_root"],o["result_raw"]) if "result_raw" in o else None
 nraw=ref(n["_root"],n["result_raw"]) if "result_raw" in n else None
 raw_comparisons.append({"pair":name,"original":source_description(o),"native":source_description(n),
  "original_frame_sha256":digest(o["_response_bytes"]),"native_frame_sha256":digest(n["_response_bytes"]),
  "original_frame_bytes":len(o["_response_bytes"]),"native_frame_bytes":len(n["_response_bytes"]),
  "raw_jsonrpc_frame_equal":o["_response_bytes"]==n["_response_bytes"],
  "complete_calltoolresult_bytes_equal":oraw==nraw,
  "complete_calltoolresult_parsed_fields_equal":eq(orpc.get("result"),nrpc.get("result")),
  "opaque_content_text_utf8_equal":ot==nt,
  "opaque_original":[{"bytes":len(t),"sha256":digest(t)} for t in ot],
  "opaque_native":[{"bytes":len(t),"sha256":digest(t)} for t in nt],
  "scope":("selected success operation mapping" if kind else
           ("same unowned memory selector 0x0, different API lifecycle/error surfaces" if name=="unmapped-address"
            else "unknown field flags=caller-script on selected procedure operations; operation tool names differ"))})
 if kind:mapping_specs.append(mapped_semantics(name,o,n,kind))
 else:
  # Optional JSON decoding is a separately identified diagnostic. Opaque bytes above remain untouched.
  oa=payload(o,False);na=payload(n,False)
  positional("decoded_error_or_retained_report_fields",name,
             oa if oa is not None else {"opaque_text":[x.decode() for x in ot]},
             na if na is not None else {"opaque_text":[x.decode() for x in nt]})

projections={}
old=payload(O["functions"])["normalized_result"]
new=analysis(N["functions-entry"])["analysis_stdout"]
lookup={row["entry_address"]:row for row in new["functions"]+new["external_functions"]}
inventory=[]
for row in old:
 newrow=lookup.get(row["address"])
 inventory.append({"address":row["address"],"native_present":newrow is not None,
  "exact_common_fields":{key:(newrow is not None and eq(value,newrow[nkey])) for key,value,nkey in (
   ("address",row["address"],"entry_address"),("name",row["value"],"name"),
   ("external",row["procedure"]["external"],"external"),("thunk",row["procedure"]["thunk"],"thunk"))},
  "original_only_metadata":{"symbol":row["symbol"],"thunk_target":row["procedure"]["thunk_target"]}})
projections["functions"]={"original_count":len(old),"native_internal_count":len(new["functions"]),
 "native_external_count":len(new["external_functions"]),"same_address_set":set(lookup)=={x["address"] for x in old},
 "exact_common_field_count":sum(sum(x["exact_common_fields"].values()) for x in inventory),
 "expected_common_field_count":len(old)*4,"rows":inventory,
 "not_qualified_as":"complete inventory/Evidence equality; the old diagnostic six-field projection is not this native functions schema"}
code_rows=[];ref_rows=[]
for suffix in ("entry","interior"):
 text=payload(O["decompile-"+suffix])["normalized_result"]
 native_text=analysis(N["decompile-"+suffix])["analysis_stdout"]["c_code"]
 code_rows.append({"selector":O["decompile-"+suffix]["arguments"]["procedure"],"original_bytes":len(text.encode()),
   "native_bytes":len(native_text.encode()),"original_sha256":digest(text.encode()),"native_sha256":digest(native_text.encode()),
   "complete_text_bytes_equal":text.encode()==native_text.encode()})
 for direction in ("incoming","outgoing"):
  left=payload(O[direction+"-"+suffix])["normalized_result"]["references"]
  right=analysis(N["xrefs-"+suffix])["analysis_stdout"][direction+"_references"]
  lfields=[{"source":x["source_address"],"target":x["target_address"],"type":x["kind"]["type"],
           "operand":x["kind"]["operand_index"],"call":x["kind"]["call"],"primary":x["kind"]["primary"]} for x in left]
  rfields=[{"source":x["from_address"],"target":x["to_address"],"type":x["reference_type"],
           "operand":x["operand_index"],"call":x["call"],"primary":x["primary"]} for x in right]
  ref_rows.append({"selector":O[direction+"-"+suffix]["arguments"]["procedure"],"direction":direction,
   "original":lfields,"native":rfields,"ordered_projection_equal":eq(lfields,rfields),
   "original_count":len(left),"native_count":len(right)})
projections["decompile"]=code_rows
projections["references"]=ref_rows

for p,value in leaves(bundle):
 emit("complete_evidence_bundle_capture","complete-bundle",p,value,None,None,have_n=False,
      mapping="original complete bundle captured; no same-layer native static-provider Evidence bundle captured")
bundle_state={"original_records":len(bundle["records"]),"original_bundle_sha256":PINS["mcp-original-c9-r1/original-complete.bundle.json"],
 "original_bundle_bytes":len(cache["mcp-original-c9-r1/original-complete.bundle.json"]),
 "native_same_layer_bundle":"NOT_CAPTURED_FOR_STATIC_PROVIDER; native provider report is not substituted",
 "native_report_evidence_compatibility_flags":[payload(N[x])["rea_evidence_compatible"] for x in ("functions-entry","function-entry","xrefs-entry","decompile-entry")],
 "complete_bundle_parity":"OPEN","all_original_bundle_leaves_listed":True,
 "missing_native_payload_does_not_prove_global_runtime_capability_absence":True}
assert eq(payload(O["bundle-complete"])["result"],bundle)
assert eq(payload(O["bundle-after-export"])["result"],bundle)
assert eq(payload(I["complete-after-import"])["result"],bundle)
original_checks=[
 eq(payload(O["inventory-page-repeat"]),payload(O["inventory-page-0"])),
 eq(payload(O["bundle-complete"])["result"],bundle),
 eq(payload(O["bundle-after-export"])["result"],bundle),
 payload(I["empty-before-import"])["result"]["records"]==[],
 eq(payload(I["complete-after-import"])["result"],payload(O["bundle-complete"])["result"]),
 eq(payload(I["complete-after-import"])["result"],bundle),
 eq(payload(I["page-after-import"]),payload(O["inventory-page-0"]))]
assert all(original_checks) and len(original_checks)==7
assert all(x["equal"] for x in native["checks"]) and len(native["checks"])==23
native_checks=[]
for name in ("functions","function","xrefs","decompile"):
 saved=parse(ref(BASE/"mcp-native-wire-c9-r1",native["harness_inputs"][name+"-result.json"]))
 native_checks.append(eq(payload(N[name+"-entry"]),saved))
for name in ("function","xrefs","decompile"):
 saved=parse(ref(BASE/"mcp-native-wire-c9-r1",native["harness_inputs"]["interior-"+name+".json"]))
 native_checks.append(eq(payload(N[name+"-interior"]),saved["result"]))
saved=parse(ref(BASE/"mcp-native-wire-c9-r1",native["harness_inputs"]["no-function-refusal.json"]))
native_checks.append(eq(payload(N["function-unmapped"]),saved["result"]))
for name in ("same-key-conflict",)+tuple("invalid-selector-"+str(i) for i in range(4)):
 saved=parse(ref(BASE/"mcp-native-wire-c9-r1",native["harness_inputs"][name+".json"]))
 native_checks.append(eq(N[name]["response_parsed"]["result"],saved["call_tool_result"]))
def job_ids(call):
 p=payload(call)
 rows=p if isinstance(p,list) else p["jobs"]
 return sorted(x["id"] for x in rows)
before=job_ids(N["jobs-before-negative-replays"])
for i in range(5):native_checks.append(before==job_ids(N["jobs-after-negative-"+str(i)]))
assert len(native_checks)==18 and all(native_checks)
cancel=original["cancellation"]
sid="original-cancel";entries=sessions[sid][1]
sent=[(e,m) for e,m in entries if e["direction"]=="sent" and m.get("id")==cancel["request_id"]]
notifications=[(e,m) for e,m in entries if e["direction"]=="sent" and m.get("method")=="notifications/cancelled"]
replies=[(e,m) for e,m in entries if e["direction"]=="received" and m.get("id")==cancel["request_id"]]
assert len(sent)==1 and len(notifications)==1 and notifications[0][1]["params"]["requestId"]==cancel["request_id"]
assert sent[0][1]["params"]==cancel["request"]
assert cancel["live_witness"]["observed_ns"]<=notifications[0][0]["monotonic_ns"]
assert replies==[]
assert eq(payload(C["bundle-before-cancel"])["result"],payload(C["bundle-after-cancel"])["result"])
cancellation={"attempts":cancel["attempts"],"observed_status":cancel["status"],"all_wire_frames_checked_after_normal_close":True,
 "original_request_frames":len(sent),"cancel_notifications":len(notifications),"original_request_responses":len(replies),
 "successful_original_request_responses":0,"complete_bundle_unchanged":True,"live_witness":cancel["live_witness"],
 "causal_or_durable_job_equivalence_claimed":False,"native_durable_job_semantics_available":False}
unmapped=payload(O["function-unmapped"],False)
diagnostic_text=unmapped["error"]["details"]["diagnostics"]["stdout"]["text"]
assert "REA no-return fix: cleared=0 sites=0 refit=0" in diagnostic_text
policy={"schema":"hepta.rea.ghidra-complete-result-comparison-policy.v1",
 "candidate":"C9 historical execution baseline","complete_parity_qualified":False,
 "statuses":{"MATCH":"exact typed field equality under a declared pointer mapping",
 "DIFF":"both fields are present and their typed values differ","ORIGINAL_ONLY":"no declared native counterpart in this captured comparison layer",
 "NATIVE_ONLY":"no declared original counterpart in this captured comparison layer"},
 "opaque_policy":"Content text is compared as exact UTF-8 bytes separately. JSON decoding is only an additional explicitly named analysis layer.",
 "frame_policy":"Complete raw JSON-RPC response and CallToolResult byte identities are retained; identifiers, metadata, paths and formatting are not removed.",
 "field_policy":"Every leaf including empty arrays/objects of both mapped documents is accounted for. Explicit many-to-one aliases are visible; counts are per declared pair, not a capability score.",
 "negative_pairing":"Only unmapped-address and flags extra-field have analogous recorded pairs. Other negative inputs are unpaired, not invented or silently coerced.",
 "native_complete_evidence":"No same-layer native static-provider bundle was captured. Full provider reports are preserved and never promoted into original REA Evidence.",
 "configured_environment":"Same fixed Ghidra 12.1.4 archive, JDK, and main ELF bytes; original default auto-analysis configuration is source-supported. Its entire 146-option snapshot was not directly sampled.",
 "no_return_repair":"Original C9 diagnostics directly report cleared=0 sites=0 refit=0 for this fixture. Native does not execute NoReturnFix. Other inputs remain open."}
negative_cases={"original":[source_description(O[x])|{"response":O[x]["response_parsed"]} for x in ("function-unmapped","invalid-selector-type","invalid-extra-field")],
 "native":[source_description(N[x])|{"response":N[x]["response_parsed"]} for x in ("function-unmapped","same-key-conflict")+tuple("invalid-selector-"+str(i) for i in range(4))],
 "unpaired_original":["invalid-selector-type"],"unpaired_native":["same-key-conflict","invalid-selector-0","invalid-selector-1","invalid-selector-2"],
 "no_same_input_parity_claim_for_unpaired_cases":True}
raw=(b"".join((json.dumps(row,ensure_ascii=True,sort_keys=True,separators=(",",":"),allow_nan=False)+"\n").encode() for row in rows))
compressed=gzip.compress(raw,mtime=0)
(OUT/"field-differences.jsonl.gz").write_bytes(compressed)
field_ref={"path":"field-differences.jsonl.gz","bytes":len(compressed),"sha256":digest(compressed),
 "uncompressed_bytes":len(raw),"uncompressed_sha256":digest(raw),"rows":len(rows)}
artifacts={
 "policy":save("comparison-policy.json",policy),
 "raw_and_opaque":save("raw-and-opaque-comparisons.json",raw_comparisons),
 "mapping_definitions":save("mapping-definitions.json",mapping_specs),
 "projections":save("mapped-observations.json",projections),
 "complete_evidence":save("complete-evidence-layer.json",bundle_state),
 "negative_cases":save("negative-cases.json",negative_cases),
 "cancellation":save("cancellation-observation.json",cancellation),
 "field_differences":field_ref,
 "wire_verification":save("wire-verification.json",{"sessions":wire_facts,
  "original_roundtrip_checks_rederived":len(original_checks),"original_roundtrip_checks_passed":sum(original_checks),
  "native_report_error_and_registry_checks_rederived":len(native_checks),"native_rederived_checks_passed":sum(native_checks),
  "native_directory_snapshot_checks":"5 producer checks reported true; after-directory snapshots were not separately retained, so not independently rederived",
  "all_four_owners_normal_close":True,"recorded_descendant_observations":sum(x["observed_descendants"] for x in wire_facts),
  "process_birth_history_complete":False}),
 "inputs":save("inputs-manifest.json",{"files":manifest,"source_commit":native["source_commit"]})}
by_layer=collections.defaultdict(collections.Counter)
for (layer,pair,status),number in counts.items():by_layer[layer][status]+=number
summary={"schema":"hepta.rea.ghidra-complete-result-differential.v1","candidate":"c9c79e27a2bf56bd204df6591ca2311dc872e317",
 "runtime_sha256":qualification["runtime_sha256"],"qualified":False,"complete_upstream_parity_qualified":False,
 "native_full_harness":{"checks":len(qualification["checks"]),"qualified_for_its_fixed_scope":qualification["qualified"],"full_parity":False},
 "native_raw_capture":{"producer_comparisons":23,"producer_differences":0,"independently_rederived_comparisons":18,"independently_rederived_differences":0,
  "directory_comparisons_only_retained_as_producer_checks":5},
 "original_evidence_roundtrip":{"checks":7,"differences":0,"complete_export_bytes":bundle_state["original_bundle_bytes"],"records":len(bundle["records"])},
 "full_cross_implementation_comparisons":{"declared_pairs":len(pairs),"full_calltoolresult_byte_matches":sum(x["complete_calltoolresult_bytes_equal"] for x in raw_comparisons),
  "full_calltoolresult_parsed_matches":sum(x["complete_calltoolresult_parsed_fields_equal"] for x in raw_comparisons),
  "opaque_text_matches":sum(x["opaque_content_text_utf8_equal"] for x in raw_comparisons),"raw_frame_matches":sum(x["raw_jsonrpc_frame_equal"] for x in raw_comparisons)},
 "field_row_counts_by_layer":{k:dict(v) for k,v in by_layer.items()},"field_counts_are_not_a_qualification_score":True,
 "function_inventory_projection":{"original_rows":len(old),"native_rows":len(lookup),"common_fields_per_row":4,"matched_common_fields":projections["functions"]["exact_common_field_count"],"original_symbol_and_thunk_target_metadata_missing_in_native_functions":True},
 "complete_c_text_matches":sum(x["complete_text_bytes_equal"] for x in code_rows),"complete_c_text_comparisons":len(code_rows),
 "xref_differences":["Native incoming retains a synthetic Entry Point reference: 4 versus original 3, at both entry/interior selectors.",
                     "Native outgoing stack target is Stack[-0xc], original stack:0xfffffffffffffff4, at both selectors.",
                     "Native incoming enumeration is entry-only and iterator order; fixed original source covers body+entry, deduplicates and sorts. This larger-domain difference is source-derived, not independently exercised by another fixture."],
 "evidence_missing_fields":["same-layer native complete Evidence bundle","original symbol metadata and thunk targets in native functions listing",
  "selected function basicblock_count, locals, symbol/provenance/body descriptive fields","nested source_procedure/target_procedure and extended reference kinds/provenance",
  "original schema identity, confidence/authority/environment/locations/relationships/evidence links and exact error recovery metadata"],
 "cancellation":{k:cancellation[k] for k in ("attempts","observed_status","original_request_responses","complete_bundle_unchanged","causal_or_durable_job_equivalence_claimed")},
 "resource_close":{"recorded_mcp_owners":4,"recorded_descendants":sum(x["observed_descendants"] for x in wire_facts),
  "all_recorded_owners_normal":True,"all_observed_descendants_exited_without_fallback":True,
  "current_census":PINS["c9-post-execution-owner-census.json"],"native_full_controller_historical_forcing":"NOT_RECORDED"},
 "artifacts":artifacts}
summary_ref=save("summary.json",summary)
readme="""# C9 Ghidra: complete captured results and explicit differences

This is a historical, unqualified cross-implementation comparison. Native fixed-profile execution passed its 13 harness checks. Native raw follow-up recorded 23/23 internal comparisons; this independent derivation can reconstruct 18 report/error/registry comparisons. Five before/after directory checks were retained only as producer booleans, so those five are not independently rederived here.

The original npm MCP execution produced complete Evidence, a 64,297-byte exported bundle containing 13 records, and exact explicit import/readback in a fresh session. All seven original roundtrip checks are independently rederived from the original raw frames and export.

## Complete results remain different

All eleven declared full CallToolResult pairs differ, as do their opaque text bytes and raw JSON-RPC frames. The field ledger retains every field, including metadata, paths, errors, and native operational details. It also contains every leaf of the complete original Evidence bundle. No same-layer native static-provider Evidence bundle was captured; complete provider reports are not a substitute.

The current native functions schema agrees on 15 exact addresses and four common fields per row (address, name, external, thunk), or 60/60 fields. It does not expose the original symbol metadata or thunk targets. This is not the old diagnostic six-field projection and not complete inventory parity.

Both entry and interior selectors produce the same complete 63-byte C text in both implementations. Native incoming references include one synthetic Entry Point row (4 versus 3). Native stack targets are display strings (Stack[-0xc]) instead of the original canonical stack:0xfffffffffffffff4. Fixed original source additionally covers function body plus entry, deduplicates, and sorts; the native baseline uses entry-only incoming enumeration. This source-domain gap is explicit and has not been promoted into a fixture-based equivalence claim.

Original function/local/block/provenance metadata, nested reference procedure identities and extra reference kinds remain recorded as original-only fields. Native job/process/cleanup and bounded-analysis fields remain native-only. Shared scalar fields are compared with types intact; a numeric count and its decimal string remain different encodings.

## Cancellation and ownership

There was exactly one original live cancellation attempt. The original raw wire records the selected request and one cancellation notification after the witnessed Java/native process was live. After close and complete drain, there was no response to that original request ID and the complete retained bundle was unchanged. This is an observational result, not causal proof or native durable-job equivalence.

The four fully instrumented MCP owners (native raw follow-up plus three original sessions) closed normally with no forced fallback. All 68 sampled descendant observations exited. A separate read-only census examined 81 previously recorded PID/start identities and the exact owned unit cgroups: all original identities were absent or reused, no matching current processes remained, and no observation error occurred. The frozen native full harness used a legacy close helper whose 5-second kill fallback was not separately recorded; this evidence does not reconstruct that missing history.

## Files

- summary.json: complete results, limits, counts, and output hashes.
- comparison-policy.json and mapping-definitions.json: exact comparison and join rules.
- raw-and-opaque-comparisons.json: byte identities for complete frames, CallToolResults and opaque text.
- field-differences.jsonl.gz: complete typed leaf ledger; no values are truncated.
- mapped-observations.json: inventory, C text and reference projections.
- complete-evidence-layer.json: complete bundle boundary and missing native counterpart.
- negative-cases.json: all sampled error inputs and full responses, including unpaired negatives.
- cancellation-observation.json and wire-verification.json: independent wire checks and ownership scope.
- inputs-manifest.json: SHA256 for every input actually read.

The selected release/JDK/input are fixed. Original diagnostics directly record NoReturnFix cleared=0 sites=0 refit=0 for this fixture; native does not execute that repair script. Other targets remain open. The original complete 146-option snapshot was not directly sampled, even though its default configuration is supported by pinned source and logs.
"""
(OUT/"README.md").write_text(readme)
print(json.dumps({"summary":summary_ref,"comparison_pairs":len(pairs),"field_rows":len(rows),"field_rows_gzip":field_ref,
 "cross_calltoolresult_matches":summary["full_cross_implementation_comparisons"]["full_calltoolresult_byte_matches"],
 "original_records":len(bundle["records"]),"inventory_common_matches":projections["functions"]["exact_common_field_count"],
 "c_text_matches":summary["complete_c_text_matches"],"original_roundtrip_rederived":7,"native_rederived":18,"qualified":False}))
