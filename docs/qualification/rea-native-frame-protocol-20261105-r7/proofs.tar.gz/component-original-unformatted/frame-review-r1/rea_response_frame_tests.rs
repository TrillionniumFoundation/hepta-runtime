// Copyright 2026 Muvon Un Limited
// Copyright 2026 TrillionniumFoundation
// SPDX-License-Identifier: Apache-2.0

use super::*;

fn context(id: Value, modern: bool) -> FrameContext {
	FrameContext {operation:"inspect_apk_signature",id:serde_json::from_value(id).unwrap(),
		modern,limit:rea_contract::RESPONSE_BYTES}
}

#[test]
fn native_frame_measurement_includes_protocol_discriminator_metadata_and_newline() {
	for modern in [false,true] {
		let frame = context(json!(17),modern);
		let mut result = CallToolResult::structured(json!({"number":1.0,"text":"雪\n\""}));
		result.meta = Some(rmcp::model::MetaObject(serde_json::from_value(json!({"private_runtime_fact":"kept"})).unwrap()));
		let completed = frame.finish(Ok(CallToolResponse::Complete(result))).unwrap();
		let CallToolResponse::Complete(result) = completed else { panic!("ordinary response changed type") };
		assert_eq!(result.result_type.is_some(),modern);
		let actual = serde_json::to_vec(&SuccessFrame {jsonrpc:"2.0",id:&frame.id,result:&result}).unwrap();
		assert_eq!(frame.count_result(&result).ok(),Some(actual.len()+1));
		assert_eq!(result.meta.unwrap()["private_runtime_fact"],"kept");
	}
}

#[test]
fn a_large_identifier_cannot_hide_an_oversized_native_frame() {
	let frame = context(json!("i".repeat(7*1024*1024)),true);
	let id = format!("ev_{}","a".repeat(64));
	let original = CallToolResult::structured(json!({"evidence_id":id,"payload":"x".repeat(2*1024*1024)}));
	assert!(matches!(frame.count_result(&original),Err(CountFailure::Overflow(_))));
	let completed = frame.finish(Ok(CallToolResponse::Complete(original))).unwrap();
	let CallToolResponse::Complete(result) = completed else { panic!("bounded tool refusal expected") };
	assert_eq!(result.is_error,Some(true));
	let body: Value = serde_json::from_str(&result.content[0].as_text().unwrap().text).unwrap();
	assert_eq!(body["error"]["details"]["reported_limits"]["boundary"],"native-mcp-frame");
	assert_eq!(body["error"]["details"]["reported_limits"]["evidence_id"],id);
	assert!(frame.count_result(&result).is_ok());
}

#[test]
fn the_minimal_error_fits_the_largest_admitted_identifier() {
	let limit = rea_contract::RESPONSE_BYTES;
	let mut request = json!({"jsonrpc":"2.0","id":"","method":"tools/call","params":{"name":"rea_get_evidence_bundle"}});
	let room = limit-serde_json::to_vec(&request).unwrap().len()-1;
	request["id"] = json!("z".repeat(room));
	assert_eq!(serde_json::to_vec(&request).unwrap().len()+1,limit);
	let frame = context(request["id"].clone(),false);
	let result = CallToolResult::structured(json!({"payload":"x".repeat(4096)}));
	let error = frame.finish(Ok(CallToolResponse::Complete(result))).unwrap_err();
	let encoded = serde_json::to_vec(&ErrorFrame {jsonrpc:"2.0",id:&frame.id,error:&error}).unwrap();
	assert!(encoded.len()+1<=limit);
	assert_eq!(serde_json::from_slice::<Value>(&encoded).unwrap()["id"],request["id"]);
}
