//! Test support only: the production Failure resource projection with the fixed
//! default budget. This mini does not qualify environment configuration or the
//! separate upstream chunk encoder. The actual integrated module is owned by root.
use rmcp::model::{CallToolResult, ContentBlock};
use serde_json::{json, Value};
pub(super) const RESPONSE_BYTES: usize = 10 * 1024 * 1024;
pub(super) struct Failure(Value);
impl Failure {
    pub(super) fn resource(operation: &str, resource: &str, reason: &str, limits: Value, retryable: bool, remediation: &str) -> Self {
        Self(json!({"code":"resource_constraint","category":"resource_constraint",
            "message":reason,"retryable":retryable,"remediation":{"action":remediation},
            "details":{"operation":operation,"resource":resource,"reason":reason,"reported_limits":limits}}))
    }
    pub(super) fn wire(self) -> CallToolResult {
        let mut result = CallToolResult::error(vec![ContentBlock::text(json!({"error":self.0}).to_string())]);
        result.meta = Some(rmcp::model::MetaObject(serde_json::from_value(json!({
            "provenance":{"untrusted_content":true,"source":"analysis_target"}
        })).unwrap()));
        result
    }
}
pub(super) fn response_budget() -> Result<usize, Failure> { Ok(RESPONSE_BYTES) }
