// Copyright 2026 Muvon Un Limited
// Copyright 2026 TrillionniumFoundation
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

//! Final native wire accounting for admitted frozen-contract STDIO requests.
//! This counts the real serde representation, negotiated resultType, request ID,
//! metadata added by the runtime, JSON-RPC envelope and terminating newline.
//! It is separate from the original REA chunk-based result-budget decision.

use super::rea_contract::{self, Failure};
use super::rea_mcp_transport::ReaRawArguments;
use rmcp::model::{CallToolResponse, CallToolResult, ErrorData, ProtocolVersion, RequestId};
use rmcp::service::RequestContext;
use rmcp::RoleServer;
use serde::Serialize;
use serde_json::{json, Value};
use std::io::{self, Write};

pub(super) struct FrameContext {
	operation: &'static str,
	id: RequestId,
	modern: bool,
	limit: usize,
}

struct Counter { bytes: usize, limit: usize, exceeded: bool }
enum CountFailure { Overflow(usize), Encoding }
impl Write for Counter {
	fn write(&mut self, bytes: &[u8]) -> io::Result<usize> {
		self.bytes = self.bytes.saturating_add(bytes.len());
		if self.bytes > self.limit {
			self.exceeded = true;
			return Err(io::Error::other("Native MCP frame exceeds response budget"));
		}
		Ok(bytes.len())
	}
	fn flush(&mut self) -> io::Result<()> { Ok(()) }
}

#[derive(Serialize)]
struct SuccessFrame<'a> { jsonrpc: &'static str, id: &'a RequestId, result: &'a CallToolResult }
#[derive(Serialize)]
struct ErrorFrame<'a> { jsonrpc: &'static str, id: &'a RequestId, error: &'a ErrorData }

impl FrameContext {
	pub(super) fn for_request(name: &str, context: &RequestContext<RoleServer>) -> Option<Self> {
		let operation = match name {
			"rea_inspect_elf_notes" => "inspect_elf_notes",
			"rea_inspect_apk_signature_evidence" => "inspect_apk_signature",
			"rea_inspect_analysis_view" => "inspect_analysis_view",
			"rea_get_evidence_bundle" => "get_evidence_bundle",
			"rea_export_evidence_bundle" => "export_evidence_bundle",
			_ => return None,
		};
		// The private raw boundary proves the request, including its ID, fits
		// the frozen STDIO admission limit. HTTP and rejected raw frames retain
		// their existing handling and are not qualified by this guard.
		if context.extensions.get::<ReaRawArguments>()?.protocol_error().is_some() { return None; }
		Some(Self { operation, id:context.id.clone(),
			modern:context.protocol_version().is_some_and(|version| version >= ProtocolVersion::V_2026_07_28),
			limit:rea_contract::response_budget().unwrap_or(rea_contract::RESPONSE_BYTES) })
	}

	fn count<T: Serialize>(&self, value: &T) -> Result<usize, CountFailure> {
		let mut counter = Counter {bytes:1,limit:self.limit,exceeded:false};
		match serde_json::to_writer(&mut counter,value) {
			Ok(()) => Ok(counter.bytes),
			Err(_) if counter.exceeded => Err(CountFailure::Overflow(counter.bytes)),
			Err(_) => Err(CountFailure::Encoding),
		}
	}

	fn count_result(&self, result: &CallToolResult) -> Result<usize, CountFailure> {
		self.count(&SuccessFrame {jsonrpc:"2.0",id:&self.id,result})
	}

	fn normalize(&self, result: &mut CallToolResult) {
		if !self.modern && result.result_type.as_ref().is_some_and(|kind| kind.is_complete()) {
			result.result_type = None;
		}
	}

	pub(super) fn finish(&self, result: Result<CallToolResponse, ErrorData>) -> Result<CallToolResponse, ErrorData> {
		let mut complete = match result {
			Ok(CallToolResponse::Complete(value)) => value,
			other => return other,
		};
		self.normalize(&mut complete);
		let lower_bound = match self.count_result(&complete) {
			Ok(_) => return Ok(CallToolResponse::Complete(complete)),
			Err(CountFailure::Overflow(bytes)) => bytes,
			Err(CountFailure::Encoding) => return Err(ErrorData::internal_error("Native response serialization failed",None)),
		};
		let evidence_id = complete.structured_content.as_ref()
			.and_then(|value| value.get("evidence_id")).and_then(Value::as_str);
		let mut limits = json!({"boundary":"native-mcp-frame","max_frame_bytes":self.limit,
			"frame_bytes_at_least":lower_bound,"includes_request_id":true,"includes_newline":true});
		if let Some(id) = evidence_id {
			limits["evidence_id"] = json!(id);
			limits["evidence_reference"] = json!({"kind":"retained-evidence","evidence_id":id});
		}
		let mut refusal = Failure::resource(self.operation,"transport",
			"The complete native MCP frame exceeds its configured byte budget. The completed result was not truncated.",limits,false,
			"Use a shorter request identifier and retrieve or export the retained Evidence.").wire();
		if self.operation == "export_evidence_bundle" { refusal.meta = None; }
		self.normalize(&mut refusal);
		if self.count_result(&refusal).is_ok() { return Ok(CallToolResponse::Complete(refusal)); }
		// An unusually long admitted request ID can leave no room for a tool
		// error. This minimal protocol error is smaller than the recognized
		// tools/call envelope that admitted the same ID; preserve the exact ID.
		let short = ErrorData::internal_error("Response exceeds the configured frame budget", None);
		if self.count(&ErrorFrame {jsonrpc:"2.0",id:&self.id,error:&short}).is_ok() { return Err(short); }
		Err(ErrorData::internal_error("",None))
	}
}

#[cfg(test)]
#[path = "rea_response_frame_tests.rs"]
mod tests;
