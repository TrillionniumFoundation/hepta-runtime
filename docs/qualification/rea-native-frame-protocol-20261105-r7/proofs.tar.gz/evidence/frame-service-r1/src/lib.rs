#![allow(dead_code)]
mod mcp {
#[path = "/home/qian-qi/work/hepta-rea-contracts-20261104-r4-evidence/qualification/frame-service-r1/contract_default_budget_fixture.rs"] mod rea_contract;
#[path = "/home/qian-qi/work/hepta-rea-contracts-20261104-r4/qualification/src/mcp/rea_mcp_transport.rs"] pub mod rea_mcp_transport;
#[path = "/home/qian-qi/work/hepta-rea-contracts-20261104-r4/qualification/src/mcp/rea_response_frame.rs"] mod rea_response_frame;
}
