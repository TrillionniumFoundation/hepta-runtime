// Copyright 2026 Muvon Un Limited
// Copyright 2026 TrillionniumFoundation
// SPDX-License-Identifier: Apache-2.0
//! Adversarial body-membership and namespace controls for revision 4 observations.

use super::*;
use serde_json::json;

fn named_row(address: &str, external: bool) -> Value {
	json!({"entry_address":address,"external":external,"thunk":false,
		"name":"owned","name_complete":true,"name_sha256":sha256(b"owned"),
		"signature":"int owned(void)","signature_complete":true,
		"signature_sha256":sha256(b"int owned(void)")})
}

fn selected() -> Value {
	let mut row = named_row("0x401000", false);
	row["body_min_address"] = json!("0x401000");
	row["body_max_address"] = json!("0x40102f");
	row["body_address_count"] = json!("32");
	row["body_range_count"] = json!(2);
	row["body_ranges_complete"] = json!(true);
	row["body_ranges"] = json!([
		{"min_address":"0x401000","max_address":"0x40100f"},
		{"min_address":"0x401020","max_address":"0x40102f"}
	]);
	json!({"function":row,"function_resolution":"containing"})
}

#[test]
fn containment_uses_inclusive_ranges_and_never_the_enclosing_min_max_span() {
	let value = selected();
	for address in ["0x401001", "0x40100f", "0x401020", "0x40102f"] {
		validate_selected(&value, address).unwrap();
	}
	for address in ["0x400fff", "0x401010", "0x401018", "0x40101f", "0x401030"] {
		assert!(validate_selected(&value, address).is_err(), "{address}");
	}
	let mut exact = value;
	exact["function_resolution"] = json!("entry");
	validate_selected(&exact, "0x401000").unwrap();
	assert!(validate_selected(&exact, "0x401001").is_err());
}

#[test]
fn complete_body_metadata_cannot_be_substituted_or_coerced() {
	let original = selected();
	for case in 0..15 {
		let mut value = original.clone();
		let row = &mut value["function"];
		match case {
			0 => row["body_ranges_complete"] = json!(false),
			1 => row["body_ranges_complete"] = json!(1),
			2 => row["body_range_count"] = json!(true),
			3 => row["body_range_count"] = json!(1),
			4 => row["body_address_count"] = json!(32),
			5 => row["body_address_count"] = json!("032"),
			6 => row["body_address_count"] = json!("48"),
			7 => row["body_min_address"] = json!("0x400fff"),
			8 => row["body_max_address"] = json!("0x401030"),
			9 => row["entry_address"] = json!("0x401018"),
			10 => row["external"] = json!(true),
			11 => row["body_ranges"][0]["min_address"] = json!("0x0401000"),
			12 => row["body_ranges"][0]["max_address"] = json!("EXTERNAL:0x40100f"),
			13 => row["body_ranges"][0]["invented_space"] = json!("ram"),
			14 => row["body_ranges"] = json!([]),
			_ => unreachable!(),
		}
		assert!(
			validate_selected(&value, "0x401001").is_err(),
			"case {case}"
		);
	}
}

#[test]
fn ranges_must_be_bounded_ordered_nonoverlapping_and_noninverted() {
	for ranges in [
		json!([{"min_address":"0x401020","max_address":"0x40102f"},
			{"min_address":"0x401000","max_address":"0x40100f"}]),
		json!([{"min_address":"0x401000","max_address":"0x40100f"},
			{"min_address":"0x40100f","max_address":"0x40102f"}]),
		json!([{"min_address":"0x401000","max_address":"0x400fff"}]),
		json!(vec![
			json!({"min_address":"0x401000","max_address":"0x40100f"});
			MAX_BODY_RANGES + 1
		]),
	] {
		let mut value = selected();
		value["function"]["body_range_count"] = json!(ranges.as_array().unwrap().len());
		value["function"]["body_ranges"] = ranges;
		assert!(validate_selected(&value, "0x401001").is_err());
	}
}

#[test]
fn upper_unsigned_addresses_do_not_wrap_or_become_signed_ranges() {
	let mut row = named_row("0xfffffffffffffff0", false);
	row["body_min_address"] = json!("0xfffffffffffffff0");
	row["body_max_address"] = json!("0xffffffffffffffff");
	row["body_address_count"] = json!("16");
	row["body_range_count"] = json!(1);
	row["body_ranges_complete"] = json!(true);
	row["body_ranges"] =
		json!([{"min_address":"0xfffffffffffffff0","max_address":"0xffffffffffffffff"}]);
	let mut value = json!({"function":row,"function_resolution":"containing"});
	validate_selected(&value, "0xffffffffffffffff").unwrap();
	value["function"]["body_ranges"][0]["min_address"] = json!("0x0");
	value["function"]["body_min_address"] = json!("0x0");
	value["function"]["body_address_count"] = json!("18446744073709551616");
	assert!(validate_selected(&value, "0xffffffffffffffff").is_err());
}

fn functions() -> Value {
	json!({"function_inventory_scope":"internal_and_external_separate",
		"functions":[named_row("0x1", false)],"returned_functions":1,
		"scanned_functions":1,"omitted_functions_in_scan":0,"function_scan_complete":true,
		"external_functions":[named_row("EXTERNAL:0x1", true)],"returned_external_functions":1,
		"scanned_external_functions":1,"omitted_external_functions_in_scan":0,
		"external_function_scan_complete":true})
}

#[test]
fn equal_offsets_in_distinct_address_spaces_remain_distinct_functions() {
	validate_functions(&functions()).unwrap();
	for address in [
		"0x1",
		"external:0x1",
		"EXTERNAL:00000001",
		"EXTERNAL:0x01",
		"EXTERNAL:0x10000000000000000",
	] {
		let mut value = functions();
		value["external_functions"][0]["entry_address"] = json!(address);
		assert!(validate_functions(&value).is_err(), "{address}");
	}
}

#[test]
fn inventory_count_kind_scope_duplicates_and_truncation_are_checked() {
	for case in 0..10 {
		let mut value = functions();
		match case {
			0 => value["function_inventory_scope"] = json!("all_functions"),
			1 => value["external_functions"][0]["external"] = json!(false),
			2 => value["returned_external_functions"] = json!(true),
			3 => value["scanned_external_functions"] = json!(4097),
			4 => value["external_function_scan_complete"] = json!(false),
			5 => value["external_function_scan_complete"] = json!(1),
			6 => value["omitted_external_functions_in_scan"] = json!(1),
			7 => value["scanned_functions"] = json!(0),
			8 => {
				value["external_functions"] = json!([
					named_row("EXTERNAL:0x1", true),
					named_row("EXTERNAL:0x1", true)
				]);
				value["returned_external_functions"] = json!(2);
				value["scanned_external_functions"] = json!(2);
			}
			9 => value["functions"] = json!([named_row("0x1", false), named_row("0x1", false)]),
			_ => unreachable!(),
		}
		assert!(validate_functions(&value).is_err(), "case {case}");
	}
	let mut bounded = functions();
	bounded["scanned_external_functions"] = json!(4096);
	bounded["omitted_external_functions_in_scan"] = json!(4095);
	bounded["external_function_scan_complete"] = json!(false);
	validate_functions(&bounded).unwrap();
}

#[test]
fn complete_names_and_signatures_must_match_their_digests() {
	for field in ["name", "signature"] {
		let mut value = functions();
		value["external_functions"][0][field] = json!("invented");
		assert!(validate_functions(&value).is_err());
		value["external_functions"][0][format!("{field}_complete")] = json!(false);
		validate_functions(&value).unwrap();
	}
}
