// Copyright 2026 Muvon Un Limited
// Copyright 2026 TrillionniumFoundation
// SPDX-License-Identifier: Apache-2.0
//! Revision 4 checks for exact body containment and explicitly separated external functions.

use anyhow::{bail, Context, Result};
use serde_json::Value;
use std::collections::BTreeSet;

use super::{counted_rows, function_row, is_sha256, sha256, valid_address};

const MAX_BODY_RANGES: usize = 128;

fn offset(address: &str) -> Result<u64> {
	if !valid_address(address) {
		bail!("Ghidra memory offset is not canonical");
	}
	u64::from_str_radix(&address[2..], 16).context("Ghidra memory offset is outside u64")
}

fn observed_offset(value: &Value) -> Result<u64> {
	offset(value.as_str().context("Ghidra memory address absent")?)
}

fn names(row: &Value) -> Result<()> {
	for (field, maximum) in [("name", 1024), ("signature", 4096)] {
		let text = row[field].as_str().context("Ghidra function text absent")?;
		let complete = row[format!("{field}_complete")]
			.as_bool()
			.context("Ghidra function text completeness absent")?;
		let digest = row[format!("{field}_sha256")]
			.as_str()
			.context("Ghidra function text digest absent")?;
		if text.len() > maximum
			|| !is_sha256(digest)
			|| (complete && digest != sha256(text.as_bytes()))
		{
			bail!("Ghidra function text digest or budget is inconsistent");
		}
	}
	if !row["thunk"].is_boolean() {
		bail!("Ghidra function thunk flag absent");
	}
	Ok(())
}

pub(super) fn validate_selected(observation: &Value, selected: &str) -> Result<()> {
	let row = &observation["function"];
	function_row(row, None)?;
	names(row)?;
	let selected_offset = offset(selected)?;
	let entry = observed_offset(&row["entry_address"])?;
	let ranges = row["body_ranges"]
		.as_array()
		.context("Ghidra selected function ranges absent")?;
	if ranges.is_empty()
		|| ranges.len() > MAX_BODY_RANGES
		|| row["body_range_count"].as_u64() != Some(ranges.len() as u64)
		|| row["body_ranges_complete"] != true
	{
		bail!("Ghidra selected function requires its complete bounded body ranges");
	}
	let mut previous_end = None;
	let mut first_start = None;
	let mut count = 0u128;
	let mut contains_selected = false;
	let mut contains_entry = false;
	for range in ranges {
		if range.as_object().is_none_or(|object| object.len() != 2) {
			bail!("Ghidra body range must contain only its two endpoints");
		}
		let start = observed_offset(&range["min_address"])?;
		let end = observed_offset(&range["max_address"])?;
		if start > end || previous_end.is_some_and(|previous| start <= previous) {
			bail!("Ghidra body ranges overlap or are not in address order");
		}
		first_start.get_or_insert(start);
		previous_end = Some(end);
		count += u128::from(end) - u128::from(start) + 1;
		contains_selected |= start <= selected_offset && selected_offset <= end;
		contains_entry |= start <= entry && entry <= end;
	}
	let declared_count = row["body_address_count"]
		.as_str()
		.context("Ghidra body address count absent")?;
	let resolution = if selected_offset == entry {
		"entry"
	} else {
		"containing"
	};
	if !contains_selected
		|| !contains_entry
		|| count > u128::from(u64::MAX)
		|| declared_count != count.to_string()
		|| Some(observed_offset(&row["body_min_address"])?) != first_start
		|| Some(observed_offset(&row["body_max_address"])?) != previous_end
		|| observation["function_resolution"] != resolution
	{
		bail!("Ghidra requested address, resolved entry or complete body ranges disagree");
	}
	Ok(())
}

pub(super) fn validate_functions(observation: &Value) -> Result<()> {
	if observation["function_inventory_scope"] != "internal_and_external_separate" {
		bail!("Ghidra revision 4 must keep internal and external inventories distinct");
	}
	let internal = observation["functions"]
		.as_array()
		.context("Ghidra internal function rows absent")?;
	let mut internal_entries = BTreeSet::new();
	for row in internal {
		function_row(row, None)?;
		names(row)?;
		if !internal_entries.insert(observed_offset(&row["entry_address"])?) {
			bail!("Ghidra internal function inventory duplicates an entry");
		}
	}
	counted_rows(
		observation,
		"external_functions",
		"returned_external_functions",
		128,
	)?;
	let external = observation["external_functions"]
		.as_array()
		.context("Ghidra external function rows absent")?;
	let mut external_entries = BTreeSet::new();
	for row in external {
		let address = row["entry_address"]
			.as_str()
			.and_then(|value| value.strip_prefix("EXTERNAL:"))
			.context("Ghidra external entry must retain its EXTERNAL address space")?;
		if row["external"] != true || !external_entries.insert(offset(address)?) {
			bail!("Ghidra external function identity is inconsistent or duplicated");
		}
		names(row)?;
	}
	for (scan, returned, omitted, complete) in [
		(
			"scanned_functions",
			"returned_functions",
			"omitted_functions_in_scan",
			"function_scan_complete",
		),
		(
			"scanned_external_functions",
			"returned_external_functions",
			"omitted_external_functions_in_scan",
			"external_function_scan_complete",
		),
	] {
		let scanned = observation[scan]
			.as_u64()
			.context("Ghidra function scan count absent")?;
		let returned = observation[returned]
			.as_u64()
			.context("Ghidra returned count absent")?;
		let complete = observation[complete]
			.as_bool()
			.context("Ghidra function completeness absent")?;
		if scanned > 4096
			|| scanned < returned
			|| (!complete && scanned != 4096)
			|| observation[omitted].as_u64() != Some(scanned - returned)
		{
			bail!("Ghidra function inventory counts or completeness are inconsistent");
		}
	}
	Ok(())
}

#[cfg(test)]
#[path = "rea_ghidra_contract_v4_tests.rs"]
mod tests;
