#!/usr/bin/env python3
"""Offline consumer for one supplemental native cold-session complete pager."""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import sys

COMMIT = 'fe3223cabbd2a8f1aa75a4ab57507bdb72291242'
TREE = '1a83f83cf62bf3d96e50c944722977b6971ffe686aecd131cab5e728dd802424'
BINARY = '260205be5fd4cdf363b8f426002c057d1d939ce299843f979770a585bb72faf6'
BINARY_BYTES = 51146872
SUMMARY = 'ac9bd1e247ee2e2dc95f080f3b078ddb0d6cb2e82ed2bb4f641f18dba713c407'
FAMILY_REPORT = 'fae9227f3fd60bf5c0226d95ec2409b93a8dc85f83351278c8374291c5a2f65b'
BUNDLE_SHA = 'c6517498ecbf04562c50f6a93c66e6fa9f17123df0a645d759df701b61ae8be8'
BUNDLE_BYTES = 6302590
SCHEMA = 'hepta.rea.native-cold-full-pager.v1'
PROFILE = 'r5/elf-native-cold-full-pager/supplement-v1'
SCENARIO = 'extension-cold-full'
MISSING_REASON = ('Snapshot is not retained in this session; it may have been released. '
                  'Explicitly request a new snapshot at offset zero.')


def load_modules(repo):
    sys.path.insert(0, str(Path(repo) / 'scripts'))
    global q, build, family, profile, Selection
    import rea_operation_qualification as q
    import rea_build_evidence as build
    import rea_elf_evidence_family_evidence as family
    import rea_elf_evidence_family_qualification as profile
    from rea_full_qualification import Selection


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def load_source(repo, family_path):
    """Validate the original family, then select its actual native export bytes."""
    family_path = Path(family_path)
    q.require(family_path.is_absolute(), 'family report must be an absolute caller-selected input')
    source_root = family_path.parent
    raw_report = build.read_regular(source_root, family_path.name, q.MAX_WIRE_BYTES)
    q.require(sha(raw_report) == FAMILY_REPORT, 'wrong original R5 family receipt')
    source_report = q.parse_json(raw_report)
    assessment = family.validate_report(repo, family_path, FAMILY_REPORT)
    q.require(assessment['finite_status'] == 'PASS' and assessment['normal_owner_closes'] == 8
              and assessment['source_tree_sha256'] == TREE and assessment['native_binary_sha256'] == BINARY,
              'source family is not the independently validated R5 observation')
    producer = source_report['sessions']['native/producer']
    export = producer['exports']['export-full']
    raw = family.read_gzip(source_root, export['artifact'], profile.MAX_EXPORT_BYTES)
    bundle = profile.validate_bundle(q.parse_json(raw))
    q.require(len(raw) == BUNDLE_BYTES and sha(raw) == BUNDLE_SHA
              and raw == profile.canonical_json(bundle) and len(bundle['records']) == 3,
              'selected original complete native export differs')
    rows = [row for row in producer['rows'] if row['id'] == 'export-full']
    q.require(len(rows) == 1 and rows[0]['operation'] == 'export_evidence_bundle',
              'original native export row missing or duplicated')
    previous = assessment['native_readback']
    q.require(previous['old_snapshot_id'] == 'ebs1_' + BUNDLE_SHA,
              'original released cursor does not identify selected complete bytes')
    last_state = source_report['sessions']['native/extension-cold']
    last_wire = family.wire_index(source_root, last_state['wire_index'])
    owners = [state['close']['owner'] for state in source_report['sessions'].values()]
    metadata = {
        'family_report': {'path': family_path.name, 'bytes': len(raw_report), 'sha256': sha(raw_report)},
        'source_session': 'native/producer', 'source_case': 'export-full',
        'export': export, 'export_call': rows[0],
        'original_live_snapshot_id': previous['snapshot_id'],
        'original_released_snapshot_id': previous['old_snapshot_id'],
        'source_last_wire_monotonic_ns': last_wire['last_ns'],
        'normal_source_owners': owners,
    }
    return raw, bundle, metadata, source_report


def missing_snapshot(response):
    failure = profile.public_error(response)
    message = 'Evidence is invalid or has changed. Recreate or re-import it, then try again.'
    q.require(q.json_equal(failure, {
        'code': 'evidence_integrity_mismatch', 'category': 'integrity_mismatch',
        'message': message, 'retryable': False, 'remediation': {'action': message},
        'details': {'reason': MISSING_REASON}}), 'cursor refusal was not the expected missing-session snapshot error')


def verify_sequence(session, workspace, raw, bundle, source):
    """Consume every call in a separately fixed sequence; page only by returned cursor."""
    records = bundle['records']
    profile.complete(session.call('empty', 'get_evidence_bundle', {}), [])
    tokens = [('live', source['original_live_snapshot_id']), ('released', source['original_released_snapshot_id'])]
    for label, token in tokens:
        missing_snapshot(session.call('foreign-' + label, 'read_evidence_bundle', {'snapshot_id': token, 'length': 1}))
    profile.counts(session.call('import-full', 'import_evidence_bundle', {'path': str(workspace / 'import-source.json')}),
                   len(records), len(records))
    for label, token in tokens:
        missing_snapshot(session.call('import-does-not-restore-' + label, 'read_evidence_bundle',
                                      {'snapshot_id': token, 'length': 1}))
    page = profile.readback_page(session.call('explicit-fresh-snapshot', 'read_evidence_bundle', {}),
                                 raw, len(records), 0, 65536)
    snapshot = page['snapshot_id']
    # A fresh explicit freeze of identical content is allowed to reproduce the
    # prior content-addressed ID. Only the earlier implicit cursor lookups fail.
    reconstructed = bytearray(bytes.fromhex(page['bytes_hex']))
    pages = 1
    while not page['eof']:
        q.require(pages < 65 and type(page['next_offset']) is int and page['next_offset'] == len(reconstructed),
                  'nonprogressing or noncontiguous continuation')
        offset = page['next_offset']
        page = profile.readback_page(session.call(f'continuation-{pages:02d}', 'read_evidence_bundle',
                                                  {'snapshot_id': snapshot, 'offset': offset, 'length': 262144}),
                                     raw, len(records), offset, 262144, snapshot)
        reconstructed.extend(bytes.fromhex(page['bytes_hex']))
        pages += 1
    q.require(bytes(reconstructed) == raw and len(reconstructed) == len(raw) and pages > 1,
              'cold continuation did not read the complete imported canonical bytes')
    session.export('export-complete', workspace / 'export-complete.json', records, raw)
    profile.snapshot_release(session.call('release-fresh', 'close_evidence_snapshot', {'snapshot_id': snapshot}),
                             snapshot, True, len(raw), 0, 0)
    missing_snapshot(session.call('released-fresh-cursor', 'read_evidence_bundle', {'snapshot_id': snapshot, 'length': 1}))
    session.finish()
    return {'pages': pages, 'bytes': len(reconstructed), 'sha256': sha(reconstructed),
            'snapshot_id': snapshot, 'ended_at_eof': True}, bytes(reconstructed)


def verify_files_and_source(repo, root, report, source_report, expected_raw):
    q.require(report['source_commit'] == COMMIT and report['schema'] == SCHEMA and report['profile'] == PROFILE,
              'wrong supplemental profile or source commit')
    before = family.json_artifact(root, report['source_before'])
    after = family.json_artifact(root, report['source_after'])
    events = family.json_artifact(root, report['source_events'])
    q.require(q.json_equal(before, after) and before['tree_sha256'] == TREE
              and q.json_equal(before, Selection(repo, root / 'unused-target', root).snapshot()),
              'supplement selected source differs or changed')
    q.require(type(events['event_count']) is int and events['event_count'] == 0
              and events['retained_events'] == [] and events['events_truncated'] is False and events['errors'] == [],
              'supplement source-monitor coverage failed')
    expected_binary = source_report['binary_before']
    q.require(expected_binary['bytes'] == BINARY_BYTES and expected_binary['sha256'] == BINARY
              and q.json_equal(report['binary_before'], expected_binary)
              and q.json_equal(report['binary_after'], expected_binary), 'supplement native binary identity differs')
    binding = build.validate_bundle(root, report['build_evidence'], before, expected_binary)
    q.require(binding['build_summary_sha256'] == SUMMARY and q.json_equal(binding, report['build_binding']),
              'supplement build binding differs')
    workspace = Path(build.absolute_name(report['workspace']))
    expected_identity = {'path': str(workspace / 'import-source.json'), 'bytes': len(expected_raw), 'sha256': sha(expected_raw)}
    q.require(q.json_equal(report['input_before'], expected_identity)
              and q.json_equal(report['input_after'], expected_identity)
              and family.read_pinned(root, report['import_artifact']) == expected_raw
              and report['import_artifact']['path'] == 'workspace/import-source.json',
              'import file did not preserve the selected original native export bytes')
    config = family.json_artifact(root, report['config'])
    expected_config = {'controller_workspace_roots': [str(workspace)], 'state_dir': str(workspace.parent / 'state'),
        'hosts': {'never-connect': {'ssh_target': 'never-connect-invalid',
             'remote_state_dir': str(workspace.parent / 'unused-remote'), 'allow_execute': False, 'allow_pty': False,
             'allow_write': False, 'allow_job_network': False}}}
    q.require(report['config']['path'] == 'runtime.json' and q.json_equal(config, expected_config),
              'supplement runtime config differs from the fixed local profile')
    q.require(q.json_equal(report['private_tools_before'], report['private_tools_after'])
              and set(report['private_tools_before']) == {'run_cold_pager.py', 'consume_cold_pager.py'},
              'private producer/consumer source changed')
    for name, reference in report['private_tools_before'].items():
        raw = family.read_pinned(root, reference)
        q.require(reference['path'] == 'tooling/' + name, 'private tool capture path differs')
        q.require(raw == Path(__file__).with_name(name).read_bytes(),
                  'private runner/consumer does not match its retained reviewed source')
    return workspace, binding


def validate(repo, receipt_path, expected_sha, source_family_path):
    repo, receipt_path = Path(repo), Path(receipt_path)
    q.require(repo.is_absolute() and receipt_path.is_absolute(), 'repo and receipt must be absolute')
    root = receipt_path.parent
    report_bytes = build.read_regular(root, receipt_path.name, q.MAX_WIRE_BYTES)
    q.require(sha(report_bytes) == expected_sha, 'supplement original receipt SHA differs')
    report = q.parse_json(report_bytes)
    raw, bundle, source, source_report = load_source(repo, source_family_path)
    q.require(q.json_equal(report['source_family'], source), 'original family/export provenance differs')
    workspace, binding = verify_files_and_source(repo, root, report, source_report, raw)
    key = 'native/' + SCENARIO
    q.require(set(report['sessions']) == {key}, 'supplement must contain exactly one native owner')
    session = family.ReplaySession(root, 'native', SCENARIO, report['sessions'][key], report, workspace)
    owner = session.close['owner']
    prior_owners = {(item['pid'], item['start_time_ticks']) for item in source['normal_source_owners']}
    q.require((owner['pid'], owner['start_time_ticks']) not in prior_owners
              and session.wire['first_ns'] > source['source_last_wire_monotonic_ns'],
              'supplement reuses an original owner or predates the original close sequence')
    derived, reconstructed = verify_sequence(session, workspace, raw, bundle, source)
    q.require(derived['pages'] == 25 and derived['bytes'] == BUNDLE_BYTES and derived['sha256'] == BUNDLE_SHA,
              'fixed complete cold-page coverage differs')
    q.require(family.read_gzip(root, report['reconstructed'], profile.MAX_EXPORT_BYTES) == reconstructed,
              'retained reconstruction differs from actual complete wire pages')
    q.require(report['errors'] == [], 'producer reported an execution/cleanup/source failure')
    return {'schema': 'hepta.rea.native-cold-full-pager-assessment.v1', 'profile': PROFILE,
            'status': 'PASS', 'qualified': False, 'source_commit': COMMIT, 'source_tree_sha256': TREE,
            'binary_sha256': BINARY, 'receipt_sha256': expected_sha,
            'source_family_receipt_sha256': FAMILY_REPORT, 'source_native_export_sha256': BUNDLE_SHA,
            'normal_owner_closes': 1, 'actual_tool_calls': len(session.rows), 'readback': derived,
            'build_source_binding': binding,
            'checks': ['empty-registry', 'both-original-cursors-refused-before-import',
                       'explicit-import-of-complete-original-native-export', 'both-original-cursors-refused-after-import',
                       'explicit-fresh-freeze', 'every-returned-next-offset-through-eof',
                       'all-page-fields-and-chunk-hashes', 'complete-import-paged-bytes-exact',
                       'complete-reexport-bytes-exact', 'release-zero-snapshot-accounting',
                       'released-cursor-refused', 'one-fresh-owner-normal-close'],
            'scope': 'Supplemental native-only cold complete pager; original family 50 comparisons/53 extension calls/8 owners and lifecycle six sessions remain unchanged. No upstream or whole-operation qualification.'}


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    for flag in ('repo', 'receipt', 'source-family-report'):
        parser.add_argument('--' + flag, required=True, type=Path)
    parser.add_argument('--sha256', required=True)
    args = parser.parse_args(argv)
    load_modules(args.repo)
    try:
        result = validate(args.repo, args.receipt, args.sha256, args.source_family_report)
    except (OSError, ValueError, KeyError, TypeError) as error:
        print(json.dumps({'status': 'INVALID', 'qualified': False, 'error': str(error)}, sort_keys=True), file=sys.stderr)
        return 2
    print(json.dumps(result, sort_keys=True))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
