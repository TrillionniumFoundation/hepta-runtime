#!/usr/bin/env python3
"""Pure-data sequence checks; no process, runtime, MCP or engine is started."""
import copy
import hashlib
import json
from pathlib import Path
import sys
import unittest

import consume_cold_pager as c

REPO = Path(sys.argv.pop(1)) if len(sys.argv) > 1 and sys.argv[1].startswith('/') else Path(__file__).parents[1] / 'hepta-runtime'
c.load_modules(REPO)


def result(value, error=False, target=True):
    body = {'error': value} if error else {'result': value}
    payload = {'content': [{'type': 'text', 'text': json.dumps(body)}], 'isError': error, 'structuredContent': body}
    if target:
        payload['_meta'] = c.q.TARGET_META
    return {'jsonrpc': '2.0', 'id': 1, 'result': payload}


def missing():
    message = 'Evidence is invalid or has changed. Recreate or re-import it, then try again.'
    return result({'code': 'evidence_integrity_mismatch', 'category': 'integrity_mismatch',
                   'message': message, 'retryable': False, 'remediation': {'action': message},
                   'details': {'reason': c.MISSING_REASON}}, error=True)


def page(raw, offset, requested):
    selected = raw[offset:offset + requested]
    end = offset + len(selected)
    digest = hashlib.sha256(raw).hexdigest()
    return result({'profile': c.profile.READBACK_PROFILE, 'snapshot_id': 'ebs1_' + digest, 'sha256': digest,
                   'total_bytes': len(raw), 'records': 0, 'unknowns': 0, 'encoding': 'hex', 'offset': offset,
                   'length': len(selected), 'bytes_hex': selected.hex(), 'chunk_sha256': hashlib.sha256(selected).hexdigest(),
                   'next_offset': None if end == len(raw) else end, 'eof': end == len(raw), 'persistence': 'session-only'})


def mutate_body(row, function):
    response = row[3]
    value = response['result']['structuredContent']
    function(value)
    response['result']['content'][0]['text'] = json.dumps(value)


class Tape:
    def __init__(self, rows, raw):
        self.rows, self.raw, self.position = rows, raw, 0

    def call(self, name, operation, arguments):
        c.q.require(self.position < len(self.rows), 'missing call')
        row = self.rows[self.position]
        self.position += 1
        c.q.require(row[:2] == [name, operation] and c.q.json_equal(row[2], arguments), 'sequence/input differs')
        return row[3]

    def export(self, name, path, expected, expected_raw):
        response = self.call(name, 'export_evidence_bundle', {'path': str(path), 'overwrite': True})
        c.q.require(expected_raw == self.raw and expected == [], 'export bytes differ')
        c.q.require(c.q.json_equal(c.profile.payload(response, target=False)['result'],
                                  {'path': str(path), 'bytes': len(self.raw), 'records': 0, 'unknowns': 0}),
                    'export response differs')
        return self.raw, {'records': []}

    def finish(self):
        c.q.require(self.position == len(self.rows), 'unconsumed calls')


class ColdSequenceTests(unittest.TestCase):
    def setUp(self):
        self.raw = bytes(range(256)) * 2734 + b'abcdefgh'
        self.workspace = Path('/recorded/cold/workspace')
        self.bundle = {name: [] for name in c.profile.BUNDLE_KEYS}
        token = 'ebs1_' + hashlib.sha256(self.raw).hexdigest()
        self.source = {'original_live_snapshot_id': 'ebs1_' + '1' * 64,
                       'original_released_snapshot_id': token}
        self.rows = [['empty', 'get_evidence_bundle', {}, result(self.bundle)]]
        for label in ('live', 'released'):
            self.rows.append(['foreign-' + label, 'read_evidence_bundle',
                              {'snapshot_id': self.source['original_' + label + '_snapshot_id'], 'length': 1}, missing()])
        self.rows.append(['import-full', 'import_evidence_bundle', {'path': str(self.workspace / 'import-source.json')},
                          result({'imported': 0, 'unknowns_added': 0, 'total': 0})])
        for label in ('live', 'released'):
            self.rows.append(['import-does-not-restore-' + label, 'read_evidence_bundle',
                              {'snapshot_id': self.source['original_' + label + '_snapshot_id'], 'length': 1}, missing()])
        self.rows.append(['explicit-fresh-snapshot', 'read_evidence_bundle', {}, page(self.raw, 0, 65536)])
        # The small pure-data fixture spans exactly four independently selected pages.
        for index, offset in enumerate((65536, 327680, 589824), 1):
            self.rows.append([f'continuation-{index:02d}', 'read_evidence_bundle',
                              {'snapshot_id': token, 'offset': offset, 'length': 262144}, page(self.raw, offset, 262144)])
        self.rows.append(['export-complete', 'export_evidence_bundle',
                          {'path': str(self.workspace / 'export-complete.json'), 'overwrite': True},
                          result({'path': str(self.workspace / 'export-complete.json'), 'bytes': len(self.raw),
                                  'records': 0, 'unknowns': 0}, target=False)])
        self.rows.append(['release-fresh', 'close_evidence_snapshot', {'snapshot_id': token},
                          result({'profile': c.profile.READBACK_PROFILE, 'snapshot_id': token, 'released': True,
                                  'released_bytes': len(self.raw), 'retained_snapshots': 0, 'retained_bytes': 0})])
        self.rows.append(['released-fresh-cursor', 'read_evidence_bundle', {'snapshot_id': token, 'length': 1}, missing()])

    def run_tape(self):
        return c.verify_sequence(Tape(self.rows, self.raw), self.workspace, self.raw, self.bundle, self.source)

    def rejected(self):
        with self.assertRaises(c.q.QualificationError):
            self.run_tape()

    def test_complete_eof_and_content_derived_id_reuse(self):
        derived, raw = self.run_tape()
        self.assertEqual(raw, self.raw)
        self.assertEqual(derived['pages'], 4)
        self.assertEqual(derived['snapshot_id'], self.source['original_released_snapshot_id'])

    def test_post_import_old_cursor_success_refused(self):
        self.rows[5][3] = page(self.raw, 0, 1)
        self.rejected()

    def test_seven_byte_first_page_does_not_meet_profile(self):
        self.rows[6][3] = page(self.raw, 0, 7)
        self.rejected()

    def test_missing_continuation_refused(self):
        self.rows.pop(8)
        self.rejected()

    def test_reordered_continuations_refused(self):
        self.rows[7], self.rows[8] = self.rows[8], self.rows[7]
        self.rejected()

    def test_duplicate_continuation_refused(self):
        self.rows.insert(8, copy.deepcopy(self.rows[7]))
        self.rejected()

    def test_premature_eof_refused(self):
        mutate_body(self.rows[7], lambda value: value['result'].update(eof=True, next_offset=None))
        self.rejected()

    def test_wrong_chunk_refused(self):
        mutate_body(self.rows[7], lambda value: value['result'].update(bytes_hex='ff' + value['result']['bytes_hex'][2:]))
        self.rejected()

    def test_wrong_next_offset_refused(self):
        mutate_body(self.rows[7], lambda value: value['result'].update(next_offset=327681))
        self.rejected()

    def test_bool_offset_refused(self):
        mutate_body(self.rows[6], lambda value: value['result'].update(offset=False))
        self.rejected()


if __name__ == '__main__':
    unittest.main(verbosity=2)
