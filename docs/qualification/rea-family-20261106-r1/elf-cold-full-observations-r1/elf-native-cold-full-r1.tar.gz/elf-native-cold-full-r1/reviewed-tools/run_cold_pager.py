#!/usr/bin/env python3
"""One fresh native MCP owner to read an imported complete bundle through EOF."""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import traceback

import consume_cold_pager as consumer


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    for flag in ('repo', 'binary', 'output-dir', 'source-family-report', 'build-summary'):
        parser.add_argument('--' + flag, type=Path, required=True)
    args = parser.parse_args(argv)
    consumer.load_modules(args.repo)
    q, profile, build = consumer.q, consumer.profile, consumer.build
    from rea_full_qualification import Selection, SourceMonitor
    q.require(all(value.is_absolute() for value in vars(args).values()), 'all paths must be absolute')
    output = args.output_dir
    output.mkdir(mode=0o700, parents=True, exist_ok=False)
    report = {'schema': consumer.SCHEMA, 'profile': consumer.PROFILE, 'qualified': False,
              'status': 'FAILED', 'source_commit': consumer.COMMIT,
              'scope': 'One supplemental native-only cold complete pager; prior family/lifecycle receipts unchanged.',
              'sessions': {}, 'errors': []}
    session = monitor = selection = before = None
    tool_paths = {'run_cold_pager.py': Path(__file__), 'consume_cold_pager.py': Path(consumer.__file__)}
    source_originals = {}
    sequence_complete = False
    try:
        head = subprocess.run(['/usr/bin/git', 'rev-parse', 'HEAD'], cwd=args.repo,
                              stdin=subprocess.DEVNULL, capture_output=True, timeout=15, check=True).stdout.decode().strip()
        q.require(head == consumer.COMMIT, 'selected checkout is not the final R5 source commit')
        report['binary_before'] = q.identity(args.binary)
        q.require(report['binary_before']['sha256'] == consumer.BINARY
                  and report['binary_before']['bytes'] == consumer.BINARY_BYTES, 'wrong final shipping binary')
        raw, bundle, provenance, original_report = consumer.load_source(args.repo, args.source_family_report)
        q.require(q.json_equal(report['binary_before'], original_report['binary_before']), 'family/supplement binary path differs')
        report['source_family'] = provenance
        report['family_report_path_at_execution'] = str(args.source_family_report)
        (output / 'tooling').mkdir(mode=0o700)
        report['private_tools_before'] = {}
        for name, path in tool_paths.items():
            source_originals[name] = path.read_bytes()
            profile.write_new(output / 'tooling' / name, source_originals[name])
            report['private_tools_before'][name] = q.artifact_reference(output / 'tooling' / name, output)
        selection = Selection(args.repo, output / 'unused-target', output)
        monitor = SourceMonitor(selection)
        monitor.start()
        before = selection.snapshot()
        q.require(before['tree_sha256'] == consumer.TREE, 'wrong selected source-tree hash')
        report['source_before'] = q.artifact_json(output, 'source-before.json', before)
        evidence, binding = build.capture_build(args.build_summary, consumer.SUMMARY, output, before, report['binary_before'])
        report['build_evidence'], report['build_binding'] = evidence, binding
        workspace = output / 'workspace'
        workspace.mkdir(mode=0o700)
        report['workspace'] = str(workspace)
        report['input_before'] = profile.write_new(workspace / 'import-source.json', raw)
        report['import_artifact'] = q.artifact_reference(workspace / 'import-source.json', output)
        config = {'controller_workspace_roots': [str(workspace)], 'state_dir': str(output / 'state'),
            'hosts': {'never-connect': {'ssh_target': 'never-connect-invalid', 'remote_state_dir': str(output / 'unused-remote'),
                     'allow_execute': False, 'allow_pty': False, 'allow_write': False, 'allow_job_network': False}}}
        report['config'] = q.artifact_json(output, 'runtime.json', config)
        command = [str(args.binary), 'mcp', '--runtime-config', str(output / 'runtime.json')]
        session = profile.Session.__new__(profile.Session)
        profile.Session.__init__(session, 'native', consumer.SCENARIO, command, {}, workspace,
                                 output / ('native-' + consumer.SCENARIO), output, report)
        session.initialize()
        profile.complete(session.call('empty', 'get_evidence_bundle', {}), [])
        tokens = [('live', provenance['original_live_snapshot_id']), ('released', provenance['original_released_snapshot_id'])]
        for label, token in tokens:
            consumer.missing_snapshot(session.call('foreign-' + label, 'read_evidence_bundle', {'snapshot_id': token, 'length': 1}))
        records = bundle['records']
        profile.counts(session.call('import-full', 'import_evidence_bundle', {'path': str(workspace / 'import-source.json')}),
                       len(records), len(records))
        for label, token in tokens:
            consumer.missing_snapshot(session.call('import-does-not-restore-' + label, 'read_evidence_bundle',
                                                   {'snapshot_id': token, 'length': 1}))
        page = profile.readback_page(session.call('explicit-fresh-snapshot', 'read_evidence_bundle', {}),
                                     raw, len(records), 0, 65536)
        snapshot = page['snapshot_id']
        reconstructed, pages = bytearray(bytes.fromhex(page['bytes_hex'])), 1
        while not page['eof']:
            q.require(pages < 65 and type(page['next_offset']) is int and page['next_offset'] == len(reconstructed),
                      'nonprogressing continuation')
            offset = page['next_offset']
            page = profile.readback_page(session.call(f'continuation-{pages:02d}', 'read_evidence_bundle',
                                                      {'snapshot_id': snapshot, 'offset': offset, 'length': 262144}),
                                         raw, len(records), offset, 262144, snapshot)
            reconstructed.extend(bytes.fromhex(page['bytes_hex']))
            pages += 1
        q.require(bytes(reconstructed) == raw and pages == 25, 'incomplete cold canonical-byte reconstruction')
        report['reconstructed'] = profile.archive_raw(output, session.output / 'reconstructed.bundle.json.gz', reconstructed)
        report['readback'] = {'pages': pages, 'bytes': len(reconstructed), 'sha256': hashlib.sha256(reconstructed).hexdigest(),
                              'snapshot_id': snapshot, 'ended_at_eof': True}
        session.export('export-complete', workspace / 'export-complete.json', records, raw)
        profile.snapshot_release(session.call('release-fresh', 'close_evidence_snapshot', {'snapshot_id': snapshot}),
                                 snapshot, True, len(raw), 0, 0)
        consumer.missing_snapshot(session.call('released-fresh-cursor', 'read_evidence_bundle', {'snapshot_id': snapshot, 'length': 1}))
        sequence_complete = True
        session.close()
    except BaseException as error:
        report['errors'].append({'stage': 'execution', 'type': type(error).__name__, 'message': str(error),
                                 'notes': list(getattr(error, '__notes__', []))})
        q.write_json(output / 'execution-error.json', {'traceback': traceback.format_exc(), 'error': report['errors'][-1]})
    finally:
        if session is not None and hasattr(session, 'client') and not session.client.closed:
            try:
                session.close()
            except BaseException as error:
                report['errors'].append({'stage': 'close', 'type': type(error).__name__, 'message': str(error),
                                         'notes': list(getattr(error, '__notes__', []))})
        if monitor is not None:
            try:
                events = monitor.stop()
                after = selection.snapshot()
                report['source_after'] = q.artifact_json(output, 'source-after.json', after)
                report['source_events'] = q.artifact_json(output, 'source-events.json', events)
                q.require(q.json_equal(before, after) and events['event_count'] == 0 and events['errors'] == [],
                          'source changed or monitoring failed')
            except BaseException as error:
                report['errors'].append({'stage': 'source', 'type': type(error).__name__, 'message': str(error)})
        try:
            report['binary_after'] = q.identity(args.binary)
            q.require(q.json_equal(report.get('binary_before'), report['binary_after']), 'binary changed during observation')
            if 'workspace' in report:
                report['input_after'] = q.identity(Path(report['workspace']) / 'import-source.json')
                q.require(q.json_equal(report.get('input_before'), report['input_after']), 'import file changed')
            report['private_tools_after'] = {}
            for name, original in source_originals.items():
                q.require(tool_paths[name].read_bytes() == original, 'private code changed during observation')
                report['private_tools_after'][name] = q.artifact_reference(output / 'tooling' / name, output)
        except BaseException as error:
            report['errors'].append({'stage': 'identity', 'type': type(error).__name__, 'message': str(error)})
    state = report['sessions'].get('native/' + consumer.SCENARIO, {})
    normal = profile.closed_normally(state.get('close', {}))
    report['finite_status'] = 'PASS' if sequence_complete and normal and not report['errors'] else 'FAIL'
    report['status'] = 'OPEN' if report['finite_status'] == 'PASS' else 'FAILED'
    report['normal_owner_closes'] = int(normal)
    report['actual_tool_calls'] = len(state.get('rows', []))
    receipt = q.artifact_json(output, 'qualification.json', report)
    print(json.dumps({'receipt': receipt, 'finite_status': report['finite_status'], 'status': report['status'],
                      'qualified': False, 'normal_owner_closes': report['normal_owner_closes'],
                      'actual_tool_calls': report['actual_tool_calls'], 'readback': report.get('readback'),
                      'errors': report['errors']}, sort_keys=True))
    return 0 if report['finite_status'] == 'PASS' else 1


if __name__ == '__main__':
    raise SystemExit(main())
