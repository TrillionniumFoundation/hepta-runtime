# One supplemental cold native pager

Status: private tools prepared for static review only. No MCP, runtime, parser worker or engine was launched during preparation. Actual execution requires root's host-release signal after the ongoing Ghidra work. This is one native owner and no additional original npm run.

This supplements the R5 family observation's cold-session gap. The original cold extension read seven bytes from its newly frozen snapshot and re-exported the full bundle; its original 50 comparisons, 53 extension calls, eight owners and original receipt remain unchanged. The lifecycle six-session result also remains unchanged.

## Fixed inputs

- Repository: `/home/qian-qi/work/hepta-rea-family-ecb0b9d61c75-20261106`.
- Source commit: `fe3223cabbd2a8f1aa75a4ab57507bdb72291242`.
- Selected source-tree SHA-256: `1a83f83cf62bf3d96e50c944722977b6971ffe686aecd131cab5e728dd802424`.
- Binary: `/home/qian-qi/work/hepta-rea-family-ecb0b9d61c75-20261106-target/debug/hepta-runtime`, 51,146,872 bytes, SHA-256 `260205be5fd4cdf363b8f426002c057d1d939ce299843f979770a585bb72faf6`.
- Matrix: `...-evidence/matrix-r3/summary.json`, SHA-256 `ac9bd1e247ee2e2dc95f080f3b078ddb0d6cb2e82ed2bb4f641f18dba713c407`.
- Original family report: `...-evidence/elf-family-r2/qualification.json`, SHA-256 `fae9227f3fd60bf5c0226d95ec2409b93a8dc85f83351278c8374291c5a2f65b`.
- The actual source is that report's `native/producer` session, `export-full` call and retained gzip export. The existing independent family consumer first verifies the entire original family. The selected export must then be exactly 6,302,590 bytes with SHA-256 `c6517498ecbf04562c50f6a93c66e6fa9f17123df0a645d759df701b61ae8be8`, with its original request/response/row references retained in the new provenance metadata. An assessment hash alone is not the source input.

The producer verifies the actual Git HEAD before launching an owner. Keep HEAD at the selected R5 commit until this supplemental run has finished. The actual qualification runner imports the frozen remote R5 helpers, including the reviewed constructor-abort cleanup. Local pure-data tests use existing functions but do not claim to test R5 constructor cleanup.

## Exact fresh destinations and commands

Private tool directory: `/home/qian-qi/work/hepta-rea-family-ecb0b9d61c75-20261106-evidence/elf-cold-full-pager-tools-r1`.

Actual output (must not exist): `/home/qian-qi/work/hepta-rea-family-ecb0b9d61c75-20261106-evidence/elf-native-cold-full-r1`.

Run once under one durable idempotency key after host release, with stdout/stderr captured separately and terminal receipt preserved:

```sh
/usr/bin/python3 -B /home/qian-qi/work/hepta-rea-family-ecb0b9d61c75-20261106-evidence/elf-cold-full-pager-tools-r1/run_cold_pager.py \
  --repo /home/qian-qi/work/hepta-rea-family-ecb0b9d61c75-20261106 \
  --binary /home/qian-qi/work/hepta-rea-family-ecb0b9d61c75-20261106-target/debug/hepta-runtime \
  --output-dir /home/qian-qi/work/hepta-rea-family-ecb0b9d61c75-20261106-evidence/elf-native-cold-full-r1 \
  --source-family-report /home/qian-qi/work/hepta-rea-family-ecb0b9d61c75-20261106-evidence/elf-family-r2/qualification.json \
  --build-summary /home/qian-qi/work/hepta-rea-family-ecb0b9d61c75-20261106-evidence/matrix-r3/summary.json
```

Then hash the newly written original `qualification.json` and pass its actual hash to this independent offline consumer; do not guess the value:

```sh
/usr/bin/python3 -B /home/qian-qi/work/hepta-rea-family-ecb0b9d61c75-20261106-evidence/elf-cold-full-pager-tools-r1/consume_cold_pager.py \
  --repo /home/qian-qi/work/hepta-rea-family-ecb0b9d61c75-20261106 \
  --receipt /home/qian-qi/work/hepta-rea-family-ecb0b9d61c75-20261106-evidence/elf-native-cold-full-r1/qualification.json \
  --sha256 ACTUAL_NEW_ORIGINAL_RECEIPT_SHA256 \
  --source-family-report /home/qian-qi/work/hepta-rea-family-ecb0b9d61c75-20261106-evidence/elf-family-r2/qualification.json
```

## Finite sequence and interpretation

The expected 34 tools/call requests are: empty registry; two old cursor refusals; explicit import; both old cursors still refused; explicit new snapshot at the default 65,536-byte first page; 24 continuations of at most 262,144 bytes driven by each actual returned `next_offset` until EOF; full canonical re-export; release to zero retained snapshot bytes/count; released cursor refusal. All page fields, per-chunk SHA-256, full SHA-256 and complete reconstructed bytes are checked. The fresh freeze may produce the same content-derived ID as the prior owner; that is allowed. Import itself must not restore either cursor.

The session captures complete original gzip JSON-RPC frames, all call rows with opaque text preserved, initialize/tools contracts, launch/close/stderr, complete reconstruction and export. It also retains source before/after plus monitor events, the exact 22-file final build bundle, input before/after and private tool source snapshots. The independent consumer replays every call through the reviewed frame and owner bindings, then independently walks the fixed complete sequence. Forced cleanup, missing close proof, partial pagination, errors or changed source/input/binary cannot pass.

Capture any failed result and run its consumer when a receipt exists; do not retry a failed/uncertain actual observation under a new key. Only after the original owner is closed and its identity/process group are confirmed gone should root be notified of host release. Store this supplement in its own new qualification archive with member hashes and actual relocated replay; the already complete original family archive is a separately pinned replay dependency. Do not merge supplemental counts into the original family or lifecycle receipts. A supplemental PASS still does not qualify the complete operation or change the 0/229 ledger.
