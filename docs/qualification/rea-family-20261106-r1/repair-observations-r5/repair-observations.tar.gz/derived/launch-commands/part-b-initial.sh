/usr/bin/python3 - <<'PY'
from pathlib import Path
import hashlib,json,os
root=Path('/home/qian-qi/work/hepta-rea-family-ecb0b9d61c75-20261106-evidence')
chunks=json.loads("[{\"path\":\"/home/qian-qi/work/hepta-rea-family-ecb0b9d61c75-20261106-evidence/r5-approved-repairs-part-b.tar.gz.part-00\",\"bytes\":32768,\"sha256\":\"b7364dbd55b55dcab81cbdc634a8695714d95d593c3bbb5207e8bc01155e21a0\"},{\"path\":\"/home/qian-qi/work/hepta-rea-family-ecb0b9d61c75-20261106-evidence/r5-approved-repairs-part-b.tar.gz.part-01\",\"bytes\":32768,\"sha256\":\"9a27d88d91bcbfb1199b4078cca1cb78e1d555690d2ebfa575ccc8b62b01b421\"},{\"path\":\"/home/qian-qi/work/hepta-rea-family-ecb0b9d61c75-20261106-evidence/r5-approved-repairs-part-b.tar.gz.part-02\",\"bytes\":32768,\"sha256\":\"4439a7c3e2502fa221f0e63344b9cf363695081e78ce211b80b48542206cc470\"},{\"path\":\"/home/qian-qi/work/hepta-rea-family-ecb0b9d61c75-20261106-evidence/r5-approved-repairs-part-b.tar.gz.part-03\",\"bytes\":15452,\"sha256\":\"d83e44083cf0b5eee5a622276ffd09dbd751d36a7cfeed07b315dc6e4f0ca3a1\"}]")
parts=[]
for item in chunks:
    p=Path(item['path']);b=p.read_bytes()
    assert len(b)==item['bytes'] and hashlib.sha256(b).hexdigest()==item['sha256']
    parts.append(b)
raw=b''.join(parts)
assert len(raw)==113756 and hashlib.sha256(raw).hexdigest()=='508b15649387affcc3598e57817e02629f4597796b46e27bfe91e7a594893cf3'
archive=root/'r5-approved-repairs-part-b.tar.gz'
with archive.open('xb') as stream:
    stream.write(raw);stream.flush();os.fsync(stream.fileno())
script=root/'r5_b_integrate_and_check.py'
assert hashlib.sha256(script.read_bytes()).hexdigest()=='f4e41edb329bc9bc3b189d880e3760379bc444ffe116625dc42baa1a0fd6da52'
receipt={'schema':'hepta.rea.part-b-transfer.v1','archive':str(archive),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'chunks':chunks,'script_sha256':hashlib.sha256(script.read_bytes()).hexdigest()}
with (root/'part-b-transfer.json').open('x') as stream:json.dump(receipt,stream,indent=2);stream.write('\n')
print('REA_PART_B_TRANSFER '+json.dumps({'bytes':len(raw),'sha256':receipt['sha256']}),flush=True)
os.execv('/usr/bin/python3',['/usr/bin/python3','-B',str(script),'--archive',str(archive),'--sha256',receipt['sha256']])
PY