/usr/bin/python3 -B - <<'PY'
from pathlib import Path
import hashlib,json,os,sys
repo=Path('/home/qian-qi/work/hepta-rea-family-ecb0b9d61c75-20261106');evidence=Path(str(repo)+'-evidence');root=evidence/'repair-checks-r5-b-r2'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(root/'summary.json')=='e4006eb11d50b4e0c497bd684b48b945c128489c6ba7c7bc2b24700546a5a159'
assert sha(root/'stderr.log')=='7128e7ff531b8f7228379761eafb651d58c5e4111393c0161294da2ea3dcbf7c'
summary=json.loads((root/'summary.json').read_bytes())
assert summary['exit_code']==0 and summary['source_unchanged'] is True
text=(root/'stderr.log').read_text();lines=[line for line in text.splitlines() if line.strip().startswith('PASS [')]
names=[line.split()[-1] for line in lines]
assert len(lines)==len(set(names))==31
assert all(any(name.endswith('::'+required) for name in names) for required in summary['required_new_tests'])
assert any(line.rstrip().endswith('31 tests run: 31 passed, 2242 skipped') for line in text.splitlines())
assert not any(line.strip().startswith(('FAIL [','LEAK [','TIMEOUT [')) for line in text.splitlines())
assert sha(root/'source-before.json')==sha(root/'source-after.json')
source=json.loads((root/'source-before.json').read_bytes());assert source['tree_sha256']=='1a83f83cf62bf3d96e50c944722977b6971ffe686aecd131cab5e728dd802424'
sys.path.insert(0,str(repo/'scripts'))
from rea_full_qualification import Selection
assert Selection(repo,Path(str(repo)+'-target'),evidence/'matrix-r3').snapshot()==source
assessment={'schema':'hepta.rea.targeted-test-log-reassessment.v1','status':'PASS_FINITE_RUST_TESTS','qualified':False,'scope':'Independent read-only reassessment of original nextest stderr and original subprocess exit; no tests rerun; not full matrix or Provider qualification','original_wrapper_job':'1a1b26f9dd7-fc05-7e03','original_wrapper_exit_code':1,'original_wrapper_failure':'Over-escaped PASS regex in postprocessing; the original failed wrapper and summary remain unchanged','nextest_exit_code':summary['exit_code'],'passed':31,'filtered_skipped':2242,'new_cases_verified':summary['required_new_tests'],'actual_passed_test_names':names,'source_unchanged':True,'source_tree_sha256':source['tree_sha256'],'original_summary_sha256':sha(root/'summary.json'),'original_stderr_sha256':sha(root/'stderr.log'),'source_before_sha256':sha(root/'source-before.json'),'source_after_sha256':sha(root/'source-after.json'),'prior_scope_correction':'The preceding Part B filter selected 3 error tests only; it did not run these nested Ghidra tests.'}
raw=(json.dumps(assessment,indent=2,sort_keys=True)+'\n').encode()
with (root/'independent-reassessment.json').open('xb') as stream:stream.write(raw);stream.flush();os.fsync(stream.fileno())
print('REA_R5_TARGETED_REASSESSMENT '+json.dumps({'path':str(root/'independent-reassessment.json'),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'passed':31,'new_cases':8}),flush=True)
script=evidence/'r5_freeze_and_matrix_r3.py';assert sha(script)=='a7297d873ef1014cb4d12092ffe623c09ad0b69d32e5d9b9b914eab40f269c31'
os.execv('/usr/bin/python3',['/usr/bin/python3','-B',str(script),'--targeted-summary-sha256','587f1dcb13efe0a039bf33f0043054264af68663b3448077080c64fddb72e369'])
PY