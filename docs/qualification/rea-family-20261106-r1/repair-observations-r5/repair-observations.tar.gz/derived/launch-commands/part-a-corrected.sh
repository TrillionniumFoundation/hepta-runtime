python3 -u - <<'PY'
from pathlib import Path
import os,json,hashlib,subprocess,fcntl,time,re,sys
repo=Path('/home/qian-qi/work/hepta-rea-family-ecb0b9d61c75-20261106');ev=Path(str(repo)+'-evidence');target=Path(str(repo)+'-target')
old=ev/'repair-checks-r5-a'
receipt={'schema':'hepta.rea.targeted-check-bootstrap-failure.v1','process_status':json.loads("{\n  \"at_unix_ms\": 1793992184826,\n  \"audit_recorded\": true,\n  \"automatic_retry\": false,\n  \"cancelled\": false,\n  \"exit_code\": 1,\n  \"job_id\": \"1a1b2444dec-fc05-7d3e\",\n  \"launch_nonce\": \"42c5bcd82162544c0c938b84202cc986\",\n  \"log_bytes\": {\n    \"stderr\": {\n      \"seen\": 248,\n      \"stored\": 248\n    },\n    \"stdout\": {\n      \"seen\": 0,\n      \"stored\": 0\n    }\n  },\n  \"log_errors\": {\n    \"stderr\": null,\n    \"stdout\": null\n  },\n  \"log_synced\": {\n    \"stderr\": true,\n    \"stdout\": true\n  },\n  \"log_truncated\": {\n    \"stderr\": false,\n    \"stdout\": false\n  },\n  \"output_complete\": true,\n  \"output_durable\": true,\n  \"state\": \"failed\",\n  \"terminal_publication_confirmed\": true,\n  \"terminal_publication_protocol\": 1,\n  \"timed_out\": false\n}"),'process_read':json.loads("{\n  \"audit_recorded\": true,\n  \"job_id\": \"1a1b2444dec-fc05-7d3e\",\n  \"stderr\": {\n    \"bytes_hex\": \"54726163656261636b20286d6f737420726563656e742063616c6c206c617374293a0a202046696c6520223c737464696e3e222c206c696e652034302c20696e203c6d6f64756c653e0a496d706f72744572726f723a2063616e6e6f7420696d706f7274206e616d652027536f7572636553656c656374696f6e272066726f6d20277265615f66756c6c5f7175616c696669636174696f6e2720282f686f6d652f7169616e2d71692f776f726b2f68657074612d7265612d66616d696c792d6563623062396436316337352d32303236313130362f736372697074732f7265615f66756c6c5f7175616c696669636174696f6e2e7079290a\",\n    \"eof\": true,\n    \"next_offset\": 248,\n    \"offset\": 0,\n    \"size\": 248,\n    \"text\": \"Traceback (most recent call last):\\n  File \\\"<stdin>\\\", line 40, in <module>\\nImportError: cannot import name 'SourceSelection' from 'rea_full_qualification' (/home/qian-qi/work/hepta-rea-family-ecb0b9d61c75-20261106/scripts/rea_full_qualification.py)\\n\"\n  },\n  \"stdout\": {\n    \"bytes_hex\": \"\",\n    \"eof\": true,\n    \"next_offset\": 0,\n    \"offset\": 0,\n    \"size\": 0,\n    \"text\": \"\"\n  }\n}"),'patches_applied':True,'test_commands_started':False,'cause':'Ad-hoc validation wrapper imported SourceSelection; actual frozen producer class is Selection. No Rust/Python test started. No patch was reapplied.','next_run':'repair-checks-r5-a-r2','qualified':False}
with (old/'bootstrap-failure.json').open('x') as h:h.write(json.dumps(receipt,sort_keys=True,indent=2)+'\n')
applied=json.loads((old/'applied.json').read_bytes())
assert subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip()==applied['source_parent']
for row in applied['files']:assert hashlib.sha256((repo/row['path']).read_bytes()).hexdigest()==row['sha256'],row['path']
assert set(subprocess.check_output(['git','-C',str(repo),'diff','--name-only'],text=True).splitlines())=={row['path'] for row in applied['files'] if row['before_sha256'] is not None}
subprocess.run(['git','-C',str(repo),'diff','--cached','--quiet'],check=True)
lock=(target/'.rea-qualification.lock').open('r+b');fcntl.flock(lock.fileno(),fcntl.LOCK_EX|fcntl.LOCK_NB)
out=ev/'repair-checks-r5-a-r2';out.mkdir()
unit=Path('/proc/self/cgroup').read_text().strip().split(':')[-1].split('/')[-1];assert re.fullmatch(r'hepta-runtime-job-[a-z0-9-]+[.]service',unit)
subprocess.run(['systemctl','--user','set-property','--runtime',unit,'CPUQuota=400%','MemoryMax=12884901888','MemorySwapMax=0'],check=True)
env=os.environ.copy();env.update({'PATH':'/home/qian-qi/.rustup/toolchains/1.95.0-x86_64-unknown-linux-gnu/bin:/home/qian-qi/.cargo/bin:/usr/bin:/bin','CARGO_HOME':'/home/qian-qi/work/hepta-rea-sixpack-ca464-20261105-cargo-home','CARGO_TARGET_DIR':str(target),'CARGO_BUILD_JOBS':'4','CARGO_NET_OFFLINE':'true','CARGO_TERM_COLOR':'never','CARGO_PROFILE_DEV_DEBUG':'0','CARGO_PROFILE_TEST_DEBUG':'0','CARGO_PROFILE_DEV_INCREMENTAL':'false','CARGO_PROFILE_TEST_INCREMENTAL':'false','NEXTEST_RETRIES':'0','NEXTEST_TEST_THREADS':'1','PYTHONDONTWRITEBYTECODE':'1','RUSTUP_TOOLCHAIN':'1.95.0-x86_64-unknown-linux-gnu','RUSTC':'/home/qian-qi/.rustup/toolchains/1.95.0-x86_64-unknown-linux-gnu/bin/rustc'})
sys.path.insert(0,str(repo/'scripts'));from rea_full_qualification import Selection,SourceMonitor
selection=Selection(repo,target,out);before=selection.snapshot();monitor=SourceMonitor(selection);monitor.start()
(out/'source-before.json').write_text(json.dumps(before,sort_keys=True,indent=2)+'\n')
cargo='/home/qian-qi/.rustup/toolchains/1.95.0-x86_64-unknown-linux-gnu/bin/cargo'
commands=[('fmt-check',[cargo,'fmt','--all','--','--check']),('python-operation-client',['/usr/bin/python3','-B','tests/rea_operation_qualification_tests.py','-v']),('rust-opaque-error-text',[cargo,'nextest','run','--offline','--locked','--all-features','--lib','--no-fail-fast','--retries','0','--test-threads','1','--ignore-default-filter','-E','test(mcp::rea_contract::tests)'])]
rows=[]
try:
 for name,argv in commands:
  print('CHECK_START',name,flush=True);started=time.monotonic()
  with (out/(name+'.stdout')).open('xb') as stdout,(out/(name+'.stderr')).open('xb') as stderr:
   result=subprocess.run(argv,cwd=repo,env=env,stdout=stdout,stderr=stderr)
  row={'name':name,'argv':argv,'exit_code':result.returncode,'elapsed_seconds':time.monotonic()-started,'stdout':{'path':name+'.stdout','sha256':hashlib.sha256((out/(name+'.stdout')).read_bytes()).hexdigest()},'stderr':{'path':name+'.stderr','sha256':hashlib.sha256((out/(name+'.stderr')).read_bytes()).hexdigest()}}
  rows.append(row);print('CHECK_END',json.dumps(row),flush=True)
  if result.returncode!=0:break
finally:
 observation=monitor.stop();after=selection.snapshot();(out/'source-after.json').write_text(json.dumps(after,sort_keys=True,indent=2)+'\n');(out/'source-events.json').write_text(json.dumps(observation,sort_keys=True,indent=2)+'\n')
 unchanged=before==after and observation['event_count']==0 and not observation['errors']
 summary={'schema':'hepta.rea.targeted-repair-checks.v1','qualified':False,'source_unchanged':unchanged,'source_tree_sha256':before['tree_sha256'],'stages':rows,'scope':'Targeted pre-freeze regression checks after corrected wrapper import, not the full final matrix or operation proof. Prior failed bootstrap retained.'}
 (out/'summary.json').write_text(json.dumps(summary,sort_keys=True,indent=2)+'\n');print('CHECKS_SUMMARY',json.dumps(summary),flush=True)
lock.close()
raise SystemExit(0 if unchanged and len(rows)==len(commands) and all(x['exit_code']==0 for x in rows) else 1)
PY