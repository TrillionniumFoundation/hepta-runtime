/usr/bin/python3 -B - <<'PY'
from pathlib import Path
import hashlib,json,os,sys,subprocess,time,fcntl,re
repo=Path('/home/qian-qi/work/hepta-rea-family-ecb0b9d61c75-20261106');target=Path(str(repo)+'-target');evidence=Path(str(repo)+'-evidence');output=evidence/'repair-checks-r5-b-r2';output.mkdir(mode=0o700,exist_ok=False)
sys.path.insert(0,str(repo/'scripts'))
from rea_full_qualification import Selection
selection=Selection(repo,target,output);before=selection.snapshot();assert before['tree_sha256']=='1a83f83cf62bf3d96e50c944722977b6971ffe686aecd131cab5e728dd802424'
(output/'source-before.json').write_text(json.dumps(before,indent=2,sort_keys=True)+'\n')
toolchain='/home/qian-qi/.rustup/toolchains/1.95.0-x86_64-unknown-linux-gnu/bin'
env=dict(os.environ,PATH=toolchain+':/home/qian-qi/.cargo/bin:/usr/bin:/bin',CARGO_HOME='/home/qian-qi/work/hepta-rea-sixpack-ca464-20261105-cargo-home',CARGO_TARGET_DIR=str(target),CARGO_BUILD_JOBS='4',CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0',CARGO_PROFILE_DEV_INCREMENTAL='false',CARGO_PROFILE_TEST_INCREMENTAL='false',CARGO_TERM_COLOR='never',PYTHONDONTWRITEBYTECODE='1')
argv=[toolchain+'/cargo','nextest','run','--offline','--locked','--all-features','--lib','--no-fail-fast','--retries','0','--test-threads','1','--ignore-default-filter','-E','test(mcp::rea_provider::ghidra_contract) | test(mcp::rea_provider::summary)']
required=['reference_spaces_use_unsigned_offsets_and_exact_utf8_percent_encoding','references_are_bound_to_actual_body_ranges_in_each_direction','raw_reference_limit_includes_synthetic_and_duplicate_observations','reference_counts_refuse_type_coercions_overflow_and_unfounded_duplicates','reference_budget_trimming_preserves_scan_facts_and_separate_omissions','reference_identity_includes_primary_but_excludes_descriptive_fields','actual_owned_original_reference_projection_fits_the_revision_four_contract','revision_four_reference_summary_distinguishes_filtering_from_output_limits']
record={'schema':'hepta.rea.corrected-targeted-filter.v1','qualified':False,'scope':'Corrected pre-freeze Ghidra nested module filter; actual prior run selected only 3 opaque-error tests, retained unchanged','prior_summary_sha256':'587f1dcb13efe0a039bf33f0043054264af68663b3448077080c64fddb72e369','source_tree_sha256':before['tree_sha256'],'argv':argv,'required_new_tests':required}
lock=(target/'.rea-qualification.lock').open('a+b');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
start=time.monotonic()
try:
    with (output/'stdout.log').open('xb') as out,(output/'stderr.log').open('xb') as err:
        completed=subprocess.run(argv,cwd=repo,env=env,stdout=out,stderr=err,timeout=300)
    record['exit_code']=completed.returncode;record['elapsed_seconds']=time.monotonic()-start
    for name in ('stdout','stderr'):
        p=output/(name+'.log');record[name]={'path':p.name,'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
    text=(output/'stderr.log').read_text();passed=[line for line in text.splitlines() if re.search(r'\\bPASS\\s',line)]
    record['required_new_tests_observed']={name:any(line.rstrip().endswith('::'+name) for line in passed) for name in required}
    record['passed_lines']=len(passed);record['verbatim_nextest_summary']=[line for line in text.splitlines() if 'Summary [' in line]
    assert completed.returncode==0 and all(record['required_new_tests_observed'].values()),record
    record['targeted_checks_passed']=True
except BaseException as error:
    record['failure']=repr(error);raise
finally:
    after=selection.snapshot();record['source_unchanged']=after==before
    (output/'source-after.json').write_text(json.dumps(after,indent=2,sort_keys=True)+'\n')
    raw=(json.dumps(record,indent=2,sort_keys=True)+'\n').encode();(output/'summary.json').write_bytes(raw)
    lock.close()
    print('REA_CORRECTED_GHIDRA_TESTS '+json.dumps({'path':str(output/'summary.json'),'sha256':hashlib.sha256(raw).hexdigest(),'bytes':len(raw),'source_unchanged':record['source_unchanged'],'exit_code':record.get('exit_code'),'new_cases':record.get('required_new_tests_observed'),'passed_lines':record.get('passed_lines')}),flush=True)
    assert after==before
PY