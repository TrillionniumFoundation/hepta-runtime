python3 -u - <<'PY'
from pathlib import Path
import os,json,hashlib,subprocess,fcntl,time,re,sys
repo=Path('/home/qian-qi/work/hepta-rea-family-ecb0b9d61c75-20261106');ev=Path(str(repo)+'-evidence');target=Path(str(repo)+'-target');stage=ev/'repair-staging-r5-a'
census=Path('/home/qian-qi/work/hepta-rea-ghidra-v4-ecb0b9-20261106-r1/c9-post-execution-owner-census.json')
assert hashlib.sha256(census.read_bytes()).hexdigest()=='4b91630b7e4d370c2c9dae02a20b1549e9a0d27a13e3fd2930d3cf301fc19037'
assert subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip()=='c9c79e27a2bf56bd204df6591ca2311dc872e317'
assert subprocess.check_output(['git','-C',str(repo),'diff','--name-only'],text=True)==''
subprocess.run(['git','-C',str(repo),'diff','--cached','--quiet'],check=True)
lock=(target/'.rea-qualification.lock').open('r+b');fcntl.flock(lock.fileno(),fcntl.LOCK_EX|fcntl.LOCK_NB)
expected={
'src/mcp/rea_contract.rs':('7dcb6e69b1fa98c6c3f1311eb560208e16c99f8d29b89e1015626efbb9f3f0ca','1ed9fd86ba337bb52fe47fe15cbb7a7f136e0f80b595026f33a024bb9a5f859e'),
'src/mcp/rea_contract_error_order.rs':(None,'71e135c8de4f6d5c8e1e9d98d30a7d8cdca0a0a2f9c601ca027eec72fe8692cc'),
'src/mcp/rea_contract_tests.rs':(None,'679633a232716abee48dcd6baf25acac5925130b63e17344f4092a2ad5535d71'),
'tests/fixtures/rea_elf_evidence_error_text.json':(None,'122fba64666692413f69f9a111f8646091626bdd75e8237340a35f8158cb3d83'),
'scripts/rea_operation_qualification.py':('6c225cea1615ac93aa8af0b941a0f398a76c766f5cee64d7448b2077174003a1','ee12a6101e296d1af00ce4a7014ae9a10a089b38808959aa55e7e91607711b58'),
'tests/rea_operation_qualification_tests.py':('a10678787cf6c93303a96e44779932f972dfc620bf5f49d51358cf094822c5d7','04b3ef858663716523cf82cb45d774aa0d8c7803a77b0877f2ca6f30d3a1e45c'),
'src/mcp/server.rs':('74dea01738989a45b959a18ddba7a94051468e737ed71652a66052c2fa38687a','bcc63feb9c61452326d099df2ea1a3329fea20d623aed56bedda10e67a12a8e1')}
for name,(old,new) in expected.items():
 p=repo/name
 assert (not p.exists()) if old is None else hashlib.sha256(p.read_bytes()).hexdigest()==old,name
for item in json.loads((ev/'final-source-r4.manifest.json').read_bytes())['files']:
 assert hashlib.sha256((repo/item['path']).read_bytes()).hexdigest()==item['sha256'],item['path']
patches={
'elf-error-order-review-r1/elf-evidence-opaque-error-order.patch':'7d0c1d94aa70c8d327e6bdd25c173f12c0616e2244ffe3e2f7d6fa8efb19abcb',
'mcp-init-cleanup-review-r1/mcp-initialization-cleanup.patch':'113d9cd77c778d6748eefdd3849ee022b1808b6ed23df4e406089213b7e1a89c',
'ghidra-selector-description-r1/selector-description.patch':'4d5cb56d882e17beab7832d306ac5b09bb96746bf8e73f7bd5d49ea270856c69'}
for name,pin in patches.items():
 assert hashlib.sha256((stage/name).read_bytes()).hexdigest()==pin
 subprocess.run(['git','-C',str(repo),'apply','--check',str(stage/name)],check=True)
for name in patches:subprocess.run(['git','-C',str(repo),'apply',str(stage/name)],check=True)
for name,(_,pin) in expected.items():assert hashlib.sha256((repo/name).read_bytes()).hexdigest()==pin,name
assert set(subprocess.check_output(['git','-C',str(repo),'diff','--name-only'],text=True).splitlines())=={name for name,(old,new) in expected.items() if old is not None}
subprocess.run(['git','-C',str(repo),'diff','--check'],check=True)
out=ev/'repair-checks-r5-a';out.mkdir()
apply={'schema':'hepta.rea.reviewed-patches-applied.v1','source_parent':'c9c79e27a2bf56bd204df6591ca2311dc872e317','c9_release_census_sha256':'4b91630b7e4d370c2c9dae02a20b1549e9a0d27a13e3fd2930d3cf301fc19037','patches':patches,'files':[{'path':n,'before_sha256':v[0],'sha256':v[1]} for n,v in expected.items()],'scope':'Uncommitted partial next candidate, targeted checks only; no final build or operation qualification.'}
(out/'applied.json').write_text(json.dumps(apply,sort_keys=True,indent=2)+'\n')
unit=Path('/proc/self/cgroup').read_text().strip().split(':')[-1].split('/')[-1];assert re.fullmatch(r'hepta-runtime-job-[a-z0-9-]+[.]service',unit)
subprocess.run(['systemctl','--user','set-property','--runtime',unit,'CPUQuota=400%','MemoryMax=12884901888','MemorySwapMax=0'],check=True)
env=os.environ.copy();env.update({'PATH':'/home/qian-qi/.rustup/toolchains/1.95.0-x86_64-unknown-linux-gnu/bin:/home/qian-qi/.cargo/bin:/usr/bin:/bin','CARGO_HOME':'/home/qian-qi/work/hepta-rea-sixpack-ca464-20261105-cargo-home','CARGO_TARGET_DIR':str(target),'CARGO_BUILD_JOBS':'4','CARGO_NET_OFFLINE':'true','CARGO_TERM_COLOR':'never','CARGO_PROFILE_DEV_DEBUG':'0','CARGO_PROFILE_TEST_DEBUG':'0','CARGO_PROFILE_DEV_INCREMENTAL':'false','CARGO_PROFILE_TEST_INCREMENTAL':'false','NEXTEST_RETRIES':'0','NEXTEST_TEST_THREADS':'1','PYTHONDONTWRITEBYTECODE':'1','RUSTUP_TOOLCHAIN':'1.95.0-x86_64-unknown-linux-gnu','RUSTC':'/home/qian-qi/.rustup/toolchains/1.95.0-x86_64-unknown-linux-gnu/bin/rustc'})
sys.path.insert(0,str(repo/'scripts'));from rea_full_qualification import SourceSelection,SourceMonitor
selection=SourceSelection(repo,target,out);before=selection.snapshot();monitor=SourceMonitor(selection);monitor.start()
(out/'source-before.json').write_text(json.dumps(before,sort_keys=True,indent=2)+'\n')
cargo='/home/qian-qi/.rustup/toolchains/1.95.0-x86_64-unknown-linux-gnu/bin/cargo'
commands=[('fmt-check',[cargo,'fmt','--all','--','--check']),('python-operation-client',['/usr/bin/python3','-B','tests/rea_operation_qualification_tests.py','-v']),('rust-opaque-error-text',[cargo,'nextest','run','--offline','--locked','--all-features','--lib','--no-fail-fast','--retries','0','--test-threads','1','--ignore-default-filter','-E','test(mcp::rea_contract::tests)'])]
rows=[]
try:
 for name,argv in commands:
  print('CHECK_START',name,flush=True);started=time.monotonic()
  with (out/(name+'.stdout')).open('xb') as stdout,(out/(name+'.stderr')).open('xb') as stderr:
   result=subprocess.run(argv,cwd=repo,env=env,stdout=stdout,stderr=stderr)
  row={'name':name,'argv':argv,'exit_code':result.returncode,'elapsed_seconds':time.monotonic()-started,'stdout':{'path':name+'.stdout','sha256':hashlib.sha256((out/(name+'.stdout')).read_bytes()).hexdigest()},'stderr':{'path':name+'.stderr','sha256':hashlib.sha256((out/(name+'.stderr')).read_bytes()).hexdigest()}}
  rows.append(row);print('CHECK_END',json.dumps(row),flush=True)
  if result.returncode!=0:break
finally:
 observation=monitor.stop();after=selection.snapshot();(out/'source-after.json').write_text(json.dumps(after,sort_keys=True,indent=2)+'\n');(out/'source-events.json').write_text(json.dumps(observation,sort_keys=True,indent=2)+'\n')
 unchanged=before==after and observation['event_count']==0 and not observation['errors']
 summary={'schema':'hepta.rea.targeted-repair-checks.v1','qualified':False,'source_unchanged':unchanged,'source_tree_sha256':before['tree_sha256'],'stages':rows,'scope':'Targeted pre-freeze regression checks, not the full final matrix or operation proof.'}
 (out/'summary.json').write_text(json.dumps(summary,sort_keys=True,indent=2)+'\n');print('CHECKS_SUMMARY',json.dumps(summary),flush=True)
lock.close()
raise SystemExit(0 if unchanged and len(rows)==len(commands) and all(x['exit_code']==0 for x in rows) else 1)
PY