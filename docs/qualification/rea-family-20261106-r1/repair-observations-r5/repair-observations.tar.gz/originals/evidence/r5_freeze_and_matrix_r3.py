#!/usr/bin/env python3
"""Freeze the reviewed implementation, then run the existing complete matrix once."""
import argparse
from datetime import datetime, timezone
import fcntl
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import time

REPO = Path('/home/qian-qi/work/hepta-rea-family-ecb0b9d61c75-20261106')
TARGET = Path(str(REPO) + '-target')
EVIDENCE = Path(str(REPO) + '-evidence')
TOOLCHAIN = Path('/home/qian-qi/.rustup/toolchains/1.95.0-x86_64-unknown-linux-gnu/bin')
CARGO_HOME = Path('/home/qian-qi/work/hepta-rea-sixpack-ca464-20261105-cargo-home')
BASE_HEAD = 'c9c79e27a2bf56bd204df6591ca2311dc872e317'
FINAL_TREE = '1a83f83cf62bf3d96e50c944722977b6971ffe686aecd131cab5e728dd802424'
PART_A = {
    'src/mcp/rea_contract.rs': '1ed9fd86ba337bb52fe47fe15cbb7a7f136e0f80b595026f33a024bb9a5f859e',
    'src/mcp/rea_contract_error_order.rs': '71e135c8de4f6d5c8e1e9d98d30a7d8cdca0a0a2f9c601ca027eec72fe8692cc',
    'src/mcp/rea_contract_tests.rs': '679633a232716abee48dcd6baf25acac5925130b63e17344f4092a2ad5535d71',
    'tests/fixtures/rea_elf_evidence_error_text.json': '122fba64666692413f69f9a111f8646091626bdd75e8237340a35f8158cb3d83',
    'scripts/rea_operation_qualification.py': 'ee12a6101e296d1af00ce4a7014ae9a10a089b38808959aa55e7e91607711b58',
    'tests/rea_operation_qualification_tests.py': '04b3ef858663716523cf82cb45d774aa0d8c7803a77b0877f2ca6f30d3a1e45c',
    'src/mcp/server.rs': 'bcc63feb9c61452326d099df2ea1a3329fea20d623aed56bedda10e67a12a8e1',
}


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write(path, value):
    raw = (json.dumps(value, indent=2, sort_keys=True, allow_nan=False) + '\n').encode()
    with path.open('xb') as stream:
        stream.write(raw)
        stream.flush()
        os.fsync(stream.fileno())
    return {'path': str(path), 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


def git(*args):
    return subprocess.run(['git', *args], cwd=REPO, check=True, capture_output=True,
                          text=True, timeout=120).stdout.strip()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--targeted-summary-sha256', required=True)
    args = parser.parse_args()
    os.umask(0o077)
    summary_path = EVIDENCE / 'repair-checks-r5-b/summary.json'
    assert re.fullmatch('[0-9a-f]{64}', args.targeted_summary_sha256)
    assert sha(summary_path) == args.targeted_summary_sha256
    short = json.loads(summary_path.read_bytes())
    assert short['applied'] is True and short['targeted_checks_passed'] is True
    assert short['source_unchanged_during_checks'] is True and short['source_tree_sha256'] == FINAL_TREE
    assert len(short['stages']) == 5 and all(stage['exit_code'] == 0 for stage in short['stages'])
    assert git('rev-parse', 'HEAD') == BASE_HEAD
    assert not git('diff', '--cached', '--name-only'), 'unrelated staged changes must not enter the source commit'
    part_b_path = EVIDENCE / 'repair-staging-r5-b/manifest.json'
    assert sha(part_b_path) == '45b9e0ff72e8c1a507cd2fafa7c52d3e19f250c40084a9462d1a5f07db70c9fa'
    part_b = json.loads(part_b_path.read_bytes())
    files = dict(PART_A)
    for item in part_b['files']:
        assert item['path'] not in files
        files[item['path']] = item['sha256']
    assert len(files) == 19
    for path, expected in files.items():
        assert sha(REPO / path) == expected, path
    sys.path.insert(0, str(REPO / 'scripts'))
    from rea_full_qualification import Selection
    selection = Selection(REPO, TARGET, EVIDENCE / 'matrix-r3')
    snapshot = selection.snapshot()
    assert snapshot['tree_sha256'] == FINAL_TREE
    changed = set(git('diff', '--name-only', 'HEAD').splitlines())
    changed.update(git('ls-files', '--others', '--exclude-standard').splitlines())
    selected_changes = {name for name in changed if selection.source(REPO / name)}
    assert selected_changes == {name for name in files if selection.source(REPO / name)}, selected_changes
    with (TARGET / '.rea-qualification.lock').open('a+b') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    paths = sorted(files)
    git('add', '--', *paths)
    assert set(git('diff', '--cached', '--name-only').splitlines()) == set(paths)
    commit_result = subprocess.run(['git', '-c', 'user.name=Codex', '-c', 'user.email=codex@openai.com',
        'commit', '-m', 'fix(rea): preserve evidence errors and align bounded Ghidra references'],
        cwd=REPO, capture_output=True, timeout=120)
    (EVIDENCE / 'source-commit-r5.stdout').write_bytes(commit_result.stdout)
    (EVIDENCE / 'source-commit-r5.stderr').write_bytes(commit_result.stderr)
    assert commit_result.returncode == 0, commit_result.stderr.decode(errors='replace')
    source_commit = git('rev-parse', 'HEAD')
    assert source_commit != BASE_HEAD and git('rev-parse', 'HEAD^') == BASE_HEAD
    assert selection.snapshot() == snapshot, 'committing must not mutate selected execution inputs'
    assert not {name for name in git('diff', '--name-only', 'HEAD').splitlines()
                if selection.source(REPO / name)}
    source_receipt = {
        'schema': 'hepta.rea.frozen-source-commit.v1', 'source_commit': source_commit,
        'parent': BASE_HEAD, 'source_tree_sha256': FINAL_TREE,
        'selected_snapshot': write(EVIDENCE / 'final-source-r5.snapshot.json', snapshot),
        'reviewed_files': [{'path': name, 'bytes': (REPO / name).stat().st_size, 'sha256': files[name]} for name in paths],
        'targeted_summary_sha256': args.targeted_summary_sha256,
        'frozen_at_utc': datetime.now(timezone.utc).isoformat(),
        'qualification_claimed': False, 'scope': 'Frozen implementation source; full matrix and operation receipts are separate',
    }
    source_ref = write(EVIDENCE / 'source-commit-r5.json', source_receipt)
    print('REA_SOURCE_R5_FROZEN ' + json.dumps(source_ref | {'source_commit': source_commit, 'tree_sha256': FINAL_TREE}), flush=True)

    unit = Path(Path('/proc/self/cgroup').read_text().strip().split(':')[-1]).name
    assert re.fullmatch(r'hepta-runtime-job-[A-Za-z0-9-]+\.service', unit), unit
    limits = subprocess.run(['systemctl', '--user', 'set-property', '--runtime', unit,
        'CPUQuota=400%', 'MemoryMax=12884901888', 'MemorySwapMax=0'], capture_output=True, timeout=30)
    (EVIDENCE / 'matrix-r3-limits.stdout').write_bytes(limits.stdout)
    (EVIDENCE / 'matrix-r3-limits.stderr').write_bytes(limits.stderr)
    assert limits.returncode == 0, limits.stderr.decode(errors='replace')
    environment = dict(os.environ, PATH=str(TOOLCHAIN) + ':/home/qian-qi/.cargo/bin:/usr/bin:/bin',
        CARGO_PROFILE_DEV_DEBUG='0', CARGO_PROFILE_TEST_DEBUG='0',
        CARGO_PROFILE_DEV_INCREMENTAL='false', CARGO_PROFILE_TEST_INCREMENTAL='false',
        PYTHONDONTWRITEBYTECODE='1')
    argv = ['/usr/bin/python3', '-B', str(REPO / 'scripts/rea_full_qualification.py'), '--repo', str(REPO),
        '--cargo-home', str(CARGO_HOME), '--target-dir', str(TARGET), '--output-dir', str(EVIDENCE / 'matrix-r3'),
        '--jobs', '4', '--cargo', str(TOOLCHAIN / 'cargo'), '--rustc', str(TOOLCHAIN / 'rustc')]
    launch = {'schema': 'hepta.rea.matrix-launch.v1', 'source_commit': source_commit, 'tree_sha256': FINAL_TREE,
        'source_commit_receipt': source_ref, 'argv': argv, 'unit': unit,
        'limits': {'CPUQuota': '400%', 'MemoryMax': 12884901888, 'MemorySwapMax': 0},
        'profile': {'DEV_DEBUG': '0', 'TEST_DEBUG': '0', 'DEV_INCREMENTAL': 'false', 'TEST_INCREMENTAL': 'false'},
        'release_build': False, 'started_at_utc': datetime.now(timezone.utc).isoformat()}
    write(EVIDENCE / 'matrix-r3-launch.json', launch)
    start = time.monotonic()
    completed = subprocess.run(argv, cwd=REPO, env=environment)
    properties = ['CPUUsageNSec', 'MemoryPeak', 'MemoryCurrent', 'IOReadBytes', 'IOWriteBytes',
                  'CPUQuotaPerSecUSec', 'MemoryMax', 'MemorySwapMax']
    resources = subprocess.run(['systemctl', '--user', 'show', unit] +
        ['--property=' + key for key in properties], capture_output=True, timeout=30)
    (EVIDENCE / 'matrix-r3-resources.stdout').write_bytes(resources.stdout)
    (EVIDENCE / 'matrix-r3-resources.stderr').write_bytes(resources.stderr)
    terminal = {'schema': 'hepta.rea.matrix-wrapper-outcome.v1', 'source_commit': source_commit,
        'exit_code': completed.returncode, 'elapsed_seconds': time.monotonic() - start,
        'finished_at_utc': datetime.now(timezone.utc).isoformat(), 'unit': unit,
        'resource_query_exit_code': resources.returncode,
        'resource_stdout_sha256': hashlib.sha256(resources.stdout).hexdigest(),
        'resource_stderr_sha256': hashlib.sha256(resources.stderr).hexdigest(),
        'resource_scope': 'Observed user-systemd build unit, bounded developer profile; not release/deployment qualification'}
    terminal_ref = write(EVIDENCE / 'matrix-r3-wrapper-outcome.json', terminal)
    print('REA_MATRIX_R3_WRAPPER ' + json.dumps(terminal_ref | {'exit_code': completed.returncode}), flush=True)
    return completed.returncode


if __name__ == '__main__':
    raise SystemExit(main())
