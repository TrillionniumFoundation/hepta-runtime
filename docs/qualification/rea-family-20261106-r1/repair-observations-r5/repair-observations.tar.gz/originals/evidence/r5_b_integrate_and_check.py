#!/usr/bin/env python3
"""Apply only the reviewed Part B bytes and retain bounded pre-freeze checks."""
import argparse
import fcntl
import hashlib
import json
import os
from pathlib import Path
import re
import stat
import subprocess
import sys
import tarfile
import time
import traceback

REPO = Path('/home/qian-qi/work/hepta-rea-family-ecb0b9d61c75-20261106')
TARGET = Path(str(REPO) + '-target')
EVIDENCE = Path(str(REPO) + '-evidence')
CARGO_HOME = Path('/home/qian-qi/work/hepta-rea-sixpack-ca464-20261105-cargo-home')
TOOLCHAIN = Path('/home/qian-qi/.rustup/toolchains/1.95.0-x86_64-unknown-linux-gnu/bin')
BASE_HEAD = 'c9c79e27a2bf56bd204df6591ca2311dc872e317'
PART_A_TREE = '844f931bc55dc786f25db81b065a35af58a6056f61127c55c72f6c41f110eaa5'


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write(path, value):
    raw = (json.dumps(value, indent=2, sort_keys=True, allow_nan=False) + '\n').encode()
    with path.open('xb') as stream:
        stream.write(raw)
        stream.flush()
        os.fsync(stream.fileno())
    return {'path': str(path), 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


def git(*args):
    return subprocess.run(['git', *args], cwd=REPO, check=True, capture_output=True,
                          text=True, timeout=60).stdout.strip()


def extract(archive, stage):
    stage.mkdir(mode=0o700, exist_ok=False)
    total = 0
    with tarfile.open(archive, 'r:gz') as source:
        members = source.getmembers()
        assert 0 < len(members) <= 256
        assert len({member.name for member in members}) == len(members)
        for member in members:
            path = Path(member.name)
            assert member.isfile() and not path.is_absolute()
            assert path.parts and all(part not in ('', '.', '..') for part in path.parts)
            assert 0 <= member.size <= 4 * 1024 * 1024
            total += member.size
            assert total <= 32 * 1024 * 1024
            target = stage / path
            target.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
            with source.extractfile(member) as reader, target.open('xb') as writer:
                size = 0
                while block := reader.read(65536):
                    size += len(block)
                    assert size <= member.size
                    writer.write(block)
                assert size == member.size


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--archive', type=Path, required=True)
    parser.add_argument('--sha256', required=True)
    args = parser.parse_args()
    os.umask(0o077)
    output = EVIDENCE / 'repair-checks-r5-b'
    output.mkdir(mode=0o700, exist_ok=False)
    result = {'schema': 'hepta.rea.reviewed-repair-integration-checks.v1', 'qualified': False,
              'scope': 'Reviewed Part B and bounded pre-freeze checks; no full build or operation qualification',
              'expected_head': BASE_HEAD, 'archive': str(args.archive), 'archive_sha256': args.sha256,
              'applied': False, 'stages': [], 'source_unchanged_during_checks': None}
    selection = None
    before_checks = None
    lock = None
    primary = None
    try:
        assert re.fullmatch('[0-9a-f]{64}', args.sha256)
        assert args.archive.is_absolute() and digest(args.archive) == args.sha256
        assert git('rev-parse', 'HEAD') == BASE_HEAD
        result['branch'] = git('branch', '--show-current')
        stage = EVIDENCE / 'repair-staging-r5-b'
        extract(args.archive, stage)
        manifest = json.loads((stage / 'manifest.json').read_bytes())
        assert manifest['schema'] == 'hepta.rea.approved-repair-part-b.v1'
        result['manifest_sha256'] = digest(stage / 'manifest.json')
        assert manifest['base_head'] == BASE_HEAD
        assert manifest['partial_source_tree_sha256'] == PART_A_TREE
        sys.path.insert(0, str(REPO / 'scripts'))
        from rea_full_qualification import Selection
        selection = Selection(REPO, TARGET, output)
        initial = selection.snapshot()
        assert initial['tree_sha256'] == PART_A_TREE, initial['tree_sha256']
        result['source_before_apply'] = write(output / 'source-before-apply.json', initial)
        patch = stage / manifest['patch']['path']
        assert digest(patch) == manifest['patch']['sha256']
        previous_modes = {}
        for item in manifest['files']:
            relative = Path(item['path'])
            assert not relative.is_absolute() and '..' not in relative.parts
            current = REPO / relative
            candidate = stage / 'files' / relative
            assert candidate.is_file() and not candidate.is_symlink()
            assert candidate.stat().st_size == item['bytes'] and digest(candidate) == item['sha256']
            if item['baseline_sha256'] is None:
                assert not current.exists(), str(relative)
            else:
                assert current.is_file() and not current.is_symlink()
                assert digest(current) == item['baseline_sha256'], str(relative)
                previous_modes[item['path']] = stat.S_IMODE(current.stat().st_mode)
        git('apply', '--check', str(patch))
        git('apply', str(patch))
        result['applied'] = True
        for item in manifest['files']:
            current = REPO / item['path']
            current.chmod(previous_modes.get(item['path'], 0o644))
            assert current.stat().st_size == item['bytes'] and digest(current) == item['sha256'], item['path']
        git('diff', '--check')
        before_checks = selection.snapshot()
        expected = {item['path']: (item['bytes'], item['sha256'], item['mode']) for item in initial['files']}
        for item in manifest['files']:
            if selection.source(REPO / item['path']):
                expected[item['path']] = (item['bytes'], item['sha256'], oct(previous_modes.get(item['path'], 0o644)))
        actual = {item['path']: (item['bytes'], item['sha256'], item['mode']) for item in before_checks['files']}
        assert actual == expected, 'selected source changed outside reviewed file set'
        result['source_before_checks'] = write(output / 'source-before-checks.json', before_checks)
        result['source_tree_sha256'] = before_checks['tree_sha256']
        result['applied_files'] = manifest['files']
        write(output / 'applied.json', result)
        print('REA_PART_B_APPLIED ' + json.dumps({'files': len(manifest['files']), 'tree_sha256': result['source_tree_sha256']}), flush=True)

        unit = Path(Path('/proc/self/cgroup').read_text().strip().split(':')[-1]).name
        assert re.fullmatch(r'hepta-runtime-job-[A-Za-z0-9-]+\.service', unit), unit
        limits = subprocess.run(['systemctl', '--user', 'set-property', '--runtime', unit,
                                 'CPUQuota=400%', 'MemoryMax=12884901888', 'MemorySwapMax=0'],
                                capture_output=True, timeout=30)
        (output / 'limits.stdout').write_bytes(limits.stdout)
        (output / 'limits.stderr').write_bytes(limits.stderr)
        assert limits.returncode == 0, limits.stderr.decode(errors='replace')
        result['unit'] = unit
        lock = (TARGET / '.rea-qualification.lock').open('a+b')
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        environment = dict(os.environ, PATH=str(TOOLCHAIN) + ':/home/qian-qi/.cargo/bin:/usr/bin:/bin',
                           CARGO_HOME=str(CARGO_HOME), CARGO_TARGET_DIR=str(TARGET), CARGO_BUILD_JOBS='4',
                           CARGO_PROFILE_DEV_DEBUG='0', CARGO_PROFILE_TEST_DEBUG='0',
                           CARGO_PROFILE_DEV_INCREMENTAL='false', CARGO_PROFILE_TEST_INCREMENTAL='false',
                           PYTHONDONTWRITEBYTECODE='1')
        cargo = str(TOOLCHAIN / 'cargo')
        stages = [
            ('fmt-check', [cargo, 'fmt', '--all', '--', '--check'], 180),
            ('python-operation-client', ['/usr/bin/python3', '-B', 'tests/rea_operation_qualification_tests.py', '-v'], 120),
            ('python-ghidra-client', ['/usr/bin/python3', '-B', 'tests/rea_ghidra_mcp_client_tests.py', '-v'], 120),
            ('python-ghidra-harness', ['/usr/bin/python3', '-B', 'tests/rea_ghidra_analysis_external_tests.py', '-v'], 120),
            ('rust-ghidra-and-error-contracts', [cargo, 'nextest', 'run', '--offline', '--locked', '--all-features',
                 '--lib', '--no-fail-fast', '--retries', '0', '--test-threads', '1', '--ignore-default-filter', '-E',
                 'test(mcp::rea_ghidra_contract) | test(mcp::rea_static_summary) | test(mcp::rea_contract::tests)'], 1200),
        ]
        for name, argv, timeout in stages:
            record = {'name': name, 'argv': argv, 'timeout_seconds': timeout}
            result['stages'].append(record)
            print('REA_PART_B_STAGE_START ' + name, flush=True)
            start = time.monotonic()
            with (output / (name + '.stdout')).open('xb') as stdout, (output / (name + '.stderr')).open('xb') as stderr:
                completed = subprocess.run(argv, cwd=REPO, env=environment, stdout=stdout, stderr=stderr, timeout=timeout)
            record['elapsed_seconds'] = time.monotonic() - start
            record['exit_code'] = completed.returncode
            for stream in ('stdout', 'stderr'):
                path = output / (name + '.' + stream)
                record[stream] = {'path': path.name, 'bytes': path.stat().st_size, 'sha256': digest(path)}
            print('REA_PART_B_STAGE_END ' + json.dumps(record), flush=True)
            assert completed.returncode == 0, name
        result['targeted_checks_passed'] = True
    except BaseException as error:
        primary = error
        result['failure'] = repr(error)
        result['traceback'] = traceback.format_exc()
        raise
    finally:
        if lock is not None:
            lock.close()
        if selection is not None and before_checks is not None:
            try:
                after = selection.snapshot()
                result['source_after_checks'] = write(output / 'source-after-checks.json', after)
                result['source_unchanged_during_checks'] = after == before_checks
                if not result['source_unchanged_during_checks']:
                    result['targeted_checks_passed'] = False
                    if primary is None:
                        primary = RuntimeError('source changed during targeted checks')
            except BaseException as error:
                result['source_snapshot_failure'] = repr(error)
                if primary is None:
                    primary = error
        receipt = write(output / 'summary.json', result)
        print('REA_PART_B_CHECK_SUMMARY ' + json.dumps(receipt), flush=True)
        if primary is not None and sys.exc_info()[0] is None:
            raise primary


if __name__ == '__main__':
    main()
