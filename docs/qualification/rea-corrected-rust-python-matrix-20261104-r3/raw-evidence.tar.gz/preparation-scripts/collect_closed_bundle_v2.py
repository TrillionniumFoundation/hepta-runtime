#!/usr/bin/env python3
"""Copy one already-closed qualification bundle without executing its commands."""
import argparse
import hashlib
import json
import re
import shutil
import stat
import subprocess
from pathlib import Path

EVIDENCE = Path("/home/qian-qi/work/hepta-rea-continuation-20261104-r2-evidence")
ARCHIVE = Path("/home/qian-qi/work/hepta-rea-matrix-archive-20261104-r3")
JOBS = Path("/home/qian-qi/.local/state/hepta-runtime-mac-worker/jobs")

def sha(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()

def regular(path):
    path = Path(path)
    st = path.lstat()
    assert stat.S_ISREG(st.st_mode) and not path.is_symlink(), str(path)
    return {"bytes": st.st_size, "sha256": sha(path)}

def dump(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("x") as stream:
        stream.write(json.dumps(value, sort_keys=True, indent=2) + "\n")

def list_files(path):
    result = subprocess.run(["rg", "--files", "--hidden", "--no-ignore", str(path)], capture_output=True, text=True)
    assert result.returncode in (0, 1), result.stderr
    return sorted(Path(item) for item in result.stdout.splitlines())

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--name", choices=("rust-r2", "rust-r3", "python-r2"), required=True)
    parser.add_argument("--matrix", required=True)
    parser.add_argument("--profile", required=True)
    parser.add_argument("--job", required=True)
    parser.add_argument("--summary-sha256", required=True)
    parser.add_argument("--profile-sha256", required=True)
    parser.add_argument("--expected-exit", type=int, choices=(0, 1), required=True)
    parser.add_argument("--expected-qualified", choices=("true", "false"), required=True)
    parser.add_argument("--public-terminal", required=True)
    args = parser.parse_args()
    matrix = Path(args.matrix)
    profile = Path(args.profile)
    assert matrix.parent == EVIDENCE and matrix.name in ("full-rust-matrix-r2", "full-rust-matrix-r3", "python-matrix-r2")
    assert profile.parent.parent == EVIDENCE and profile.parent.name in ("functional-profile-r2", "functional-profile-r3") and profile.name == "profile.json"
    assert re.fullmatch(r"[0-9a-f]+-[0-9a-f]+-[0-9a-f]+", args.job)
    assert sha(matrix / "summary.json") == args.summary_sha256
    assert sha(profile) == args.profile_sha256
    summary = json.loads((matrix / "summary.json").read_text())
    assert summary["qualified"] is (args.expected_qualified == "true")
    job_dir = JOBS / args.job
    exit_value = json.loads((job_dir / "exit.json").read_text())
    request = json.loads((job_dir / "request.json").read_text())
    public_terminal_path = Path(args.public_terminal)
    public_terminal = json.loads(public_terminal_path.read_text())
    assert public_terminal["job_id"] == exit_value["job_id"] == request["job_id"] == args.job
    assert public_terminal["launch_nonce"] == exit_value["launch_nonce"] == request["launch_nonce"]
    assert public_terminal["exit_code"] == exit_value["exit_code"] == args.expected_exit
    assert public_terminal["state"] == ("succeeded" if args.expected_exit == 0 else "failed")
    for value in (public_terminal, exit_value):
        assert value["output_complete"] is True and value["output_durable"] is True and value["timed_out"] is False and value["cancelled"] is False
    assert public_terminal["terminal_publication_confirmed"] is True
    matrix_files = list_files(matrix)
    assert matrix_files
    selected = {str(Path("matrix") / path.relative_to(matrix)): path for path in matrix_files}
    selected["environment/profile.json"] = profile
    selected["job/public-terminal.json"] = public_terminal_path
    job_files = list_files(job_dir)
    for path in job_files:
        if path.name in ("request.json", "exit.json", "stdout.log", "stderr.log") or path.name.startswith("exit."):
            selected[str(Path("job") / path.relative_to(job_dir))] = path
    assert all("job/" + name in selected for name in ("request.json", "exit.json", "stdout.log", "stderr.log"))
    descriptors = {rel: {"original_path": str(path), **regular(path)} for rel, path in selected.items()}
    dest = ARCHIVE / "raw" / args.name
    assert not dest.exists(), "reconcile existing bundle before attempting another copy"
    dest.mkdir(parents=True, mode=0o700)
    for rel, source in selected.items():
        target = dest / rel
        target.parent.mkdir(parents=True, exist_ok=True)
        with source.open("rb") as src, target.open("xb") as dst:
            shutil.copyfileobj(src, dst)
        assert regular(source) == regular(target) == {k: descriptors[rel][k] for k in ("bytes", "sha256")}
    stages = summary.get("stages", [])
    diagnostics = []
    for stage in stages:
        if not stage.get("name", "").startswith("nextest-") or stage.get("kind") != "gate":
            continue
        log = matrix / Path(stage["logs"]["stderr"]["path"]).name
        lines = log.read_text(errors="strict").splitlines()
        summaries = [line for line in lines if re.search(r"^\s*Summary\s+\[", line)]
        failures = sorted(set(re.sub(r"^.*\)\s+", "", line) for line in lines if re.search(r"^\s*FAIL\s+\[", line)))
        guard_lines = [{"line": index + 1, "text": line} for index, line in enumerate(lines) if "observation socket path is too long for OpenSSH temporary publication" in line]
        known_passes = [line for line in lines if "PASS [" in line and any(name in line for name in ("every_rea_handler_is_runtime_only", "served_tool_schemas_carry_no_generator_noise"))]
        diagnostics.append({"name": stage["name"], "exit_code": stage["exit_code"], "original_log": str(log), "log_sha256": sha(log), "summary_lines": summaries, "failed_tests": failures, "path_length_guard_lines": guard_lines, "schema_regression_pass_lines": known_passes})
    snapshots = {}
    for label in ("source-before", "source-after", "source-events"):
        path = matrix / (label + ".json")
        if path.exists():
            value = json.loads(path.read_text())
            snapshots[label] = {"descriptor": regular(path), "keys": list(value), "file_count": len(value["files"]) if isinstance(value, dict) and isinstance(value.get("files"), (dict, list)) else None}
    before_tree = summary.get("source_before", {}).get("tree_sha256")
    after_tree = summary.get("source_after", {}).get("tree_sha256")
    source_equal = (before_tree == after_tree) if before_tree is not None and after_tree is not None else None
    receipt = {"schema": "hepta.rea.closed-matrix-archive-copy.v1", "name": args.name, "source": str(matrix), "destination": str(dest), "source_summary_sha256": args.summary_sha256, "source_profile_sha256": args.profile_sha256, "job_id": args.job, "matrix_qualified": summary["qualified"], "terminal_exit_code": args.expected_exit, "all_original_bytes_preserved": True, "matrix_files": len(matrix_files), "all_copied_files": len(selected), "all_copied_bytes": sum(item["bytes"] for item in descriptors.values()), "files": descriptors, "source_summary_projection": {key: summary.get(key) for key in ("status", "qualified", "source_changed", "source_inventory_changed", "source_monitor_complete", "source_before", "source_after", "source_events", "invalid_reasons", "scope", "inputs", "environment_overrides")}, "source_tree_digest_equal": source_equal, "snapshots": snapshots, "diagnostics": diagnostics, "final_combined_qualification_claimed": False, "tests_started_by_collector": False}
    dump(dest / "copy-receipt.json", receipt)
    assert [str(path.relative_to(matrix)) for path in list_files(matrix)] == [str(path.relative_to(matrix)) for path in matrix_files]
    for rel, source in selected.items():
        assert regular(source) == regular(dest / rel) == {k: descriptors[rel][k] for k in ("bytes", "sha256")}
    print(json.dumps({key: receipt[key] for key in ("name", "destination", "matrix_qualified", "terminal_exit_code", "all_original_bytes_preserved", "matrix_files", "all_copied_files", "all_copied_bytes", "source_tree_digest_equal", "snapshots", "diagnostics", "final_combined_qualification_claimed", "tests_started_by_collector")}, sort_keys=True), flush=True)
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
