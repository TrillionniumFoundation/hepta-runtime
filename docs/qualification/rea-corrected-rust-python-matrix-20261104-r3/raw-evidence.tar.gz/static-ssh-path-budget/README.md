# Static SSH ControlPath budget for the r3 functional profile

The four SSH fixture failures in both r2 Rust feature runs have the same concrete startup rejection: the selected 30-byte TMPDIR makes the first ControlPath 91 bytes with a seven-digit process ID. Production allows at most 90 bytes and checks this before creating its private socket directory. The existing production guard and the tests remain unchanged.

## Byte calculation

The relevant limit is the encoded path length. The implementation reserves a 17-byte OpenSSH temporary-publication suffix (`.` plus 16 random characters) and one terminating NUL from Linux's 108-byte `sun_path`: **108 − 17 − 1 = 90**.

The pinned tempfile 3.27.0 source uses the ten-byte component `.tmp` plus six random characters. The socket directory name is `hp-o-` plus decimal PID, one hyphen and 32 hex characters. Let **L** be the absolute TMPDIR byte length, **D** the PID digits, and **S** the AtomicU64 sequence digits. The observed `pid_max=4194304` bounds D at 7, and u64 bounds S at 20.

| Path | Formula | With L=10, D=7, S=20 |
| --- | --- | --- |
| Private socket directory | L + 50 + D | 67 bytes |
| Initial `m-1` ControlPath | L + 54 + D | 71 bytes |
| Production `m-{sequence}` ControlPath | L + 53 + D + S | **90 bytes** |
| OpenSSH temporary published name | Previous row + 17 | 107 bytes, then one NUL |
| Direct test `retired-fixture-{sequence}` socket | L + 67 + D + S | **104 bytes**, below the direct 107-byte final-path limit |

For the original r2 TMPDIR `/run/user/1000/rea-q2-iiiwx6_w`, L=30 and the initial `m-1` path is 30+54+7=91. Merely reducing that path by one byte only addresses initial admission; reserving the full u64 production sequence range gives the conservative **L≤10** profile.

## Manual listener semantics verified

The complete relevant code confirms that `retired_generation` calls `Core::arguments(..., effective=true)`, which inserts `-G`; it waits for that original SSH child to exit successfully, then calls `tokio::net::UnixListener::bind(&socket)` itself. Its test listener therefore uses the direct final-path limit of 107 bytes. Applying an additional 17-byte OpenSSH publication suffix to this manual listener would be the wrong operation.

The JSON includes the exact source excerpts and hashes. It also binds the existing boundary test that uses real Unix listeners to distinguish the 90-byte and 91-byte ControlPaths and their 107/108-byte temporary names.

## Owned short TMPDIR

A direct single-ASCII-character child of `/dev/shm`, such as `/dev/shm/q`, has exactly ten bytes. The matrix owner must create an unused entry exclusively with mode 0700, verify UID 1000 and the actual absence of symlinks, verify the existing tmpfs and executable preflight, and pass TMPDIR only to its matrix process. An existing entry must never be adopted, overwritten or chmodded. No mount or global environment change is needed.

This agent created no such directory and ran no new test cases. The parent chose to cover the four cases through both complete r3 feature runs, preserving the original r2 failures. This note is static evidence for the profile choice, not a claim that r3 has passed or a durability qualification. No source, script, guard, deadline or dependency was changed.
