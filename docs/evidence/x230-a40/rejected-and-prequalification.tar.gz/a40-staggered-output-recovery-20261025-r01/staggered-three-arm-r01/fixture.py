
import ctypes,hashlib,json,os,pathlib,signal,subprocess,sys,threading,time
q=json.load(sys.stdin)
job=pathlib.Path(q['job'])
libc=ctypes.CDLL(None,use_errno=True)
if libc.prctl(36,1,0,0,0)!=0:
    raise OSError(ctypes.get_errno(),'fixture child-subreaper setup failed')
child_code='''import os,pathlib,signal,time
descendant=os.fork()
if descendant==0:
    signal.signal(signal.SIGTERM,signal.SIG_IGN)
    pathlib.Path('descendant').write_text(str(os.getpid()))
    time.sleep(8)
    os._exit(0)
until=time.monotonic()+2
while not pathlib.Path('descendant').exists() and time.monotonic()<until:
    time.sleep(.005)
if not pathlib.Path('descendant').exists():
    raise RuntimeError('original descendant did not start')
pathlib.Path('effect').write_bytes(b'original leader executed once\\n')
os._exit(0)
'''
if not q['ignore_term']:
    child_code=child_code.replace('signal.SIG_IGN','signal.SIG_DFL')
if q['staggered']:
    child_code=child_code.replace('    time.sleep(8)',
        "    os.write(1,b'original staggered stdout\\n')\n"
        "    os.write(2,b'original staggered stderr\\n')\n"
        "    time.sleep(1.0)\n"
        "    os.close(1)\n"
        "    time.sleep(1.5)\n"
        "    os.close(2)")
req={'job_id':'inherited-pipe-durability','job_dir':str(job),
     'launch_nonce':'c'*32,'terminal_publication_protocol':1,
     'request_fingerprint':'original-leader-exit-held-pipes',
     'executable':sys.executable,'args':['-I','-S','-c',child_code],
     'execution_mode':'operator','cwd':str(job),'timeout_seconds':10,'env':{}}
(job/'request.json').write_text(json.dumps(req))
os.chmod(job/'request.json',0o600)
info=job.stat()
binding={'device':info.st_dev,'inode':info.st_ino,'job_id':req['job_id'],
         'launch_nonce':req['launch_nonce'],'request_fingerprint':req['request_fingerprint']}
real_popen,real_killpg,real_waitid=subprocess.Popen,os.killpg,os.waitid
spawned,signals,waits,adopted,cleanup=[],[],[],[],[]
scope={'__name__':'__main__'}
state={'phase':'runner','runner_exit':None,'runner_exception':None,
       'cancel_delivered_during_drain':False}

def popen(*args,**kwargs):
    if spawned:
        raise AssertionError('fixture permits exactly one workload Popen')
    child=real_popen(*args,**kwargs)
    spawned.append(child)
    original_wait=child.wait
    def wait(timeout=None):
        event={'phase':state['phase'],'returned':False,'returncode':None}
        waits.append(event)
        result=original_wait(timeout=timeout)
        event.update(returned=True,returncode=result)
        return result
    child.wait=wait
    return child

def waitid(*args,**kwargs):
    result=real_waitid(*args,**kwargs)
    if (q['cancel_overlap'] and scope.get('leader_drain_until') is not None
            and not state['cancel_delivered_during_drain']):
        state['cancel_delivered_during_drain']=True
        os.kill(os.getpid(),signal.SIGTERM)
    return result

def killpg(group,signum):
    child=spawned[0]
    unreaped=child.returncode is None
    observed=real_waitid(os.P_PID,child.pid,os.WEXITED|os.WNOHANG|os.WNOWAIT) if unreaped else None
    event={'phase':state['phase'],'group':group,'signal':signum,
           'original_child_unreaped':unreaped,'returned':False,
           'original_leader_exited':observed is not None and observed.si_pid==child.pid,
           'leader_exit_code':None if observed is None else observed.si_status}
    signals.append(event)
    result=real_killpg(group,signum)
    event['returned']=True
    return result

def alarm(_signum,_frame):
    raise TimeoutError('fixture original 30-second cleanup trigger')

signal.signal(signal.SIGALRM,alarm)
signal.setitimer(signal.ITIMER_REAL,30)
subprocess.Popen,os.killpg,os.waitid=popen,killpg,waitid
sys.argv=['-c',str(job),json.dumps(binding),'detached']
try:
    exec(q['runner'],scope)
except SystemExit as stopped:
    state['runner_exit']=stopped.code if isinstance(stopped.code,int) else 1
except BaseException as error:
    state['runner_exception']=type(error).__name__+': '+str(error)
finally:
    signal.setitimer(signal.ITIMER_REAL,0)
    subprocess.Popen,os.killpg,os.waitid=real_popen,real_killpg,real_waitid
    readers=scope.get('readers') or []
    state['readers_alive_at_runner_return']=[r.is_alive() for r in readers]
    state['normal_drain_window_present']=scope.get('leader_drain_until') is not None
    state['cancellation_deadline']=scope.get('stop_deadline')
    state['phase']='rescue'
    # No poll/wait before the last rescue group signal: only an unreaped
    # original child permits this cleanup signal. Never signal a saved PID.
    for child in spawned:
        if child.returncode is None:
            try:
                real_killpg(child.pid,signal.SIGKILL)
                cleanup.append('fixture submitted rescue group SIGKILL')
            except ProcessLookupError:
                cleanup.append('fixture rescue group was absent')
            except BaseException as error:
                cleanup.append('fixture rescue signal: '+str(error))
            try:
                child.wait(timeout=12)
            except BaseException as error:
                cleanup.append('fixture rescue wait: '+str(error))
    # Every possible fixture workload is fixed and bounded. Adopted-child
    # collection can therefore wait for the eight-second self-exit on a red
    # baseline; it never supplies a group signal after leader reap.
    while True:
        try:
            pid,status=os.waitpid(-1,0)
        except ChildProcessError:
            break
        adopted.append({'pid':pid,'returncode':os.waitstatus_to_exitcode(status)})
    for reader in readers:
        if reader.ident is not None:
            reader.join(timeout=2)
            if reader.is_alive():
                cleanup.append('fixture reader did not stop')
    if not any(r.is_alive() for r in readers):
        for child in spawned:
            for stream in (child.stdout,child.stderr):
                if stream is not None:
                    stream.close()
        for name in ('out','err','stdin_handle'):
            stream=scope.get(name)
            if hasattr(stream,'close'):
                stream.close()
    if isinstance(scope.get('owner_fd'),int):
        os.close(scope['owner_fd'])
    for fd in scope.get('_hepta_directory_pins',[]):
        os.close(fd)

originals={}
for name in ('request.json','child.json','exit.json','exit.witness.json',
             'stdout.log','stderr.log','effect','descendant'):
    path=job/name
    raw=path.read_bytes() if path.exists() else None
    originals[name]=None if raw is None else {
        'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'utf8':raw.decode('utf-8')}
receipt=None if originals['exit.json'] is None else json.loads(originals['exit.json']['utf8'])
witness=None if originals['exit.witness.json'] is None else json.loads(originals['exit.witness.json']['utf8'])
status_scope={}
exec(q['status_function'],status_scope)
print(json.dumps({'schema':'hepta-inherited-pipe-drain-fixture/v1','state':state,
                  'workload_popen_count':len(spawned),'workload_pid':None if not spawned else spawned[0].pid,
                  'signals':signals,'waits':waits,'adopted':adopted,'cleanup':cleanup,
                  'originals':originals,'receipt':receipt,'witness':witness,
                  'final_status':None if receipt is None else status_scope['final_status'](receipt)},sort_keys=True))
