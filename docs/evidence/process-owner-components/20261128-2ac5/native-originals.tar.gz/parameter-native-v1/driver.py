from pathlib import Path
import os,sys,json,hashlib,shutil,time,subprocess,traceback,stat
r=Path('/home/qian-qi/hia-runtime-process-owner-20261128-2ac5')
s=r/'parameter-native-v1/source';q=r/'parameter-native-v1/qualification'
q.mkdir(mode=0o700);(q/'tmp').mkdir(mode=0o700)
os.environ['LC_ALL']='C';os.environ['LANG']='C';os.environ['TMPDIR']=str(q/'tmp')
pins=json.loads((r/'parameter-native-v1/pins.json').read_bytes())
def check():
 for row in pins:
  p=r/'parameter-native-v1'/row['path'];b=p.read_bytes();st=p.lstat()
  assert stat.S_ISREG(st.st_mode) and st.st_nlink==1 and len(b)==row['bytes'] and hashlib.sha256(b).hexdigest()==row['sha256'] and stat.S_IMODE(st.st_mode)==row['mode'],str(p)
check()
for name in ('cases.jsonl','reference.jsonl'):shutil.copyfile(r/'parameter-native-v1/inputs'/name,q/name)
sys.path.insert(0,str(s/'scripts'))
from hia_native_build import NativeBuild
build=q/'build';build.mkdir(mode=0o700)
peer=Path('/home/qian-qi/hia-runtime-filebytes-20261128-2ac5')
shutil.copytree(peer/'local-read-component-build-v1/build/bootstrap',build/'bootstrap',copy_function=shutil.copy2)
started=time.monotonic();rows=[];failure=None
try:
 b=NativeBuild(peer/'pinned-hepta-d3e2',build)
 for name in ('serde_json_span','process_params'):
  start=time.monotonic();path=b.compile('process-'+name.replace('_','-'),s/'native'/(name+'.hepta'),standalone=None,buffer_profile='history.v1')
  raw=path.read_bytes();meta=json.loads(raw)
  row={'name':name,'manifest':str(path),'manifest_sha256':hashlib.sha256(raw).hexdigest(),'image_sha256':meta['image_sha256'],'elapsed_seconds':time.monotonic()-start}
  rows.append(row);print(json.dumps(row),flush=True)
 (q/'compiled.json').write_text(json.dumps({'modules':rows},sort_keys=True,indent=2)+chr(10))
 cmd=[sys.executable,'-I','-B',str(s/'authoring/process_owner_v1/qualify_parameters.py'),'--source',str(s),'--qualification',str(q)]
 (q/'capture.command.json').write_text(json.dumps(cmd)+chr(10))
 with (q/'capture.stdout').open('wb') as a,(q/'capture.stderr').open('wb') as c:
  done=subprocess.run(cmd,stdout=a,stderr=c,timeout=180)
 print((q/'capture.stdout').read_text()[-9000:],flush=True)
 if done.returncode:raise RuntimeError('native parameter gate returned '+str(done.returncode))
except BaseException:
 failure=traceback.format_exc();(q/'failure.txt').write_text(failure);traceback.print_exc()
check()
report={'passed':failure is None,'elapsed_seconds':time.monotonic()-started,'modules':rows,'source_stable':True,'failure':failure}
(q/'terminal.json').write_text(json.dumps(report,sort_keys=True,indent=2)+chr(10));print(json.dumps(report),flush=True)
raise SystemExit(0 if failure is None else 1)
