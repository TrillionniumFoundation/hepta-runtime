from pathlib import Path
import sys,json,ctypes,hashlib,struct,gzip,time,stat,traceback
R=Path('/home/qian-qi/hia-runtime-process-owner-20261128-2ac5')
B=R/'record-native-compile-v3';Q=R/'record-native-boundaries-v2';Q.mkdir(mode=0o700)
I=R/'record-boundary-reference-inputs-v1';S=B/'source'
sys.path.insert(0,str(S/'scripts'))
from hia_native_loader import NativeModule
SHA=lambda b:hashlib.sha256(b).hexdigest()
U=lambda b,at:struct.unpack_from('<Q',b,at)[0]
frozen={}
def read(p):
 b=p.read_bytes();st=p.lstat();assert stat.S_ISREG(st.st_mode) and st.st_nlink==1
 row={'bytes':len(b),'sha256':SHA(b),'mode':stat.S_IMODE(st.st_mode)}
 if str(p) in frozen:assert frozen[str(p)]==row,str(p)
 frozen[str(p)]=row
 return b
metadata=json.loads(read(B/'result.json'))['module'];m=Path(metadata['manifest'])
raw=read(m);assert SHA(raw)==metadata['manifest_sha256'];meta=json.loads(raw)
for p in (m.parent/meta['image'],m.parent/meta['source'],S/'scripts/hia_native_loader.py',Path(__file__)):read(p)
module=NativeModule(m,manifest_sha256=SHA(raw));rows=[json.loads(x) for x in read(I/'cases.jsonl').splitlines()]
native=[];index=[];capture=gzip.open(Q/'calls.bin.gz','wb',compresslevel=1);offset=0;start=time.monotonic()
def call(cid,mode,wire,before,cap):
 global offset
 with module.session(output_capacity=cap,workspace_capacity=len(before)) as session:
  if before:ctypes.memmove(session._workspace,before,len(before))
  if cap:ctypes.memset(session._output,165,cap)
  code,out,after=session.invoke_raw(wire)
 ordinal=len(index)+1;header=struct.pack('<8Q',ordinal,cid,mode,code,len(wire),cap,len(before),0)
 h=hashlib.sha256();size=0
 for part in (header,wire,before,b'\xa5'*cap,out,after):capture.write(part);h.update(part);size+=len(part)
 index.append({'call':ordinal,'case':cid,'mode':mode,'return_code':code,'input_bytes':len(wire),'output_capacity':cap,'workspace_capacity':len(before),'offset':offset,'bytes':size,'sha256':h.hexdigest(),'output_sha256':SHA(out),'workspace_after_sha256':SHA(after)})
 offset+=size
 return code,out,after,ordinal
def run(cid,mode,raw):
 wire=b'HPRJRQ01'+struct.pack('<4Q',mode,111,0,len(raw))+raw
 before=bytes(65536);cap=128;calls=[]
 for attempt in range(12):
  code,out,after,ordinal=call(cid,mode,wire,before,cap);calls.append(ordinal)
  if code==0xffffffd0:
   assert out[:8]==b'HGRWS002' and U(out,24)==0 and out[32:]==b'\xa5'*(cap-32)
   kind=U(out,8);extent=U(out,16)
   if kind==1:
    assert len(before)<extent<=module.metadata['workspace_capacity'];allocated=min(module.metadata['workspace_capacity'],1 << (extent-1).bit_length());assert allocated>=extent;before=after+bytes(allocated-len(after))
   elif kind==2:
    assert cap<extent<=module.metadata['output_capacity'];cap=min(module.metadata['output_capacity'],1 << (extent-1).bit_length());assert cap>=extent;before=after
   else:raise AssertionError(('resource growth refusal',cid,kind,extent))
   continue
  if code in (0xffffffff,0xfffffffd):return {'accepted':False,'code':code,'calls':calls}
  assert code<=cap and out[code:]==b'\xa5'*(cap-code),(cid,mode,hex(code),cap)
  return {'accepted':True,'code':code,'output_hex':out[:code].hex(),'calls':calls}
 raise AssertionError(('growth attempts',cid,mode))
failure=None
try:
 for row in rows:
  raw=bytes.fromhex(row['raw_hex'])
  res={str(mode):run(row['case_id'],mode,raw) for mode in (1,2,3)}
  native.append({'case_id':row['case_id'],'name':row['name'],'input_bytes':len(raw),'result':res})
 valid_rows=[json.loads(x) for x in read(R/'record-reference-inputs-v1/cases.jsonl').splitlines()]
 base=bytes.fromhex(next(x for x in valid_rows if x['name']=='full')['raw_hex'])
 frame=b'HPRJRQ01'+struct.pack('<4Q',3,111,0,len(base))+base
 bad=[]
 bad.append(('magic',b'BADMAGIC'+frame[8:]))
 for offset,value,label in [(8,0,'mode-zero'),(8,4,'mode-unknown'),(16,110,'wrong-type'),(24,1,'nonzero-path'),(32,len(base)-1,'short-declared'),(32,len(base)+1,'long-declared')]:
  b=bytearray(frame);struct.pack_into('<Q',b,offset,value);bad.append((label,bytes(b)))
 bad.extend([('short-header',frame[:39]),('missing-last-byte',frame[:-1]),('extra-tail',frame+b' '),('empty',b'')])
 frame_controls=[]
 for i,(name,wire) in enumerate(bad):
  code,out,after,ordinal=call(1001+i,3,wire,bytes(65536),128)
  assert code in (0xffffffff,0xfffffffd) and out==b'\xa5'*128,(name,code,out[:64].hex())
  frame_controls.append({'name':name,'call':ordinal,'refused':True,'output_unchanged':True})
except BaseException:
 failure=traceback.format_exc();(Q/'failure.txt').write_text(failure);traceback.print_exc()
finally:
 capture.close();module.close()
 (Q/'native.jsonl').write_bytes(b''.join(json.dumps(x,sort_keys=True).encode()+b'\n' for x in native))
 (Q/'index.json').write_text(json.dumps(index,indent=2)+'\n')
 for p in list(frozen):read(Path(p))
 (Q/'physical-inputs.json').write_text(json.dumps(frozen,indent=2)+'\n')
 print(json.dumps({'capture_complete':failure is None,'native_cases':len(native),'calls':len(index),'raw_bytes':offset,'seconds':time.monotonic()-start,'failure':failure}),flush=True)
if failure:raise SystemExit(1)
with gzip.open(Q/'calls.bin.gz','rb') as f:
 for row in index:
  b=f.read(row['bytes']);assert len(b)==row['bytes'] and SHA(b)==row['sha256']
 assert f.read(1)==b''
reference=[json.loads(x) for x in read(I/'reference.jsonl').splitlines()];assert len(reference)==len(native)
def arena_value(raw):
 assert raw[:8]==b'HPRJRA01' and U(raw,8)==len(raw) and U(raw,16)==128 and U(raw,24)==111 and raw[32:128]==bytes(96)
 def word(at):assert 0<=at<=len(raw)-8;return U(raw,at)
 def node(at):
  assert 128<=at<=len(raw)-64 and at%8==0
  kind=word(at)
  if kind==0:return None
  if kind==1:
   p,n=word(at+32),word(at+40);assert 128<=p<=len(raw) and n<=len(raw)-p
   return raw[p:p+n].decode('utf-8')
  if kind==2:
   v=word(at+24);assert v in (0,1);return bool(v)
  if kind==3:return word(at+24)
  if kind==8:
   n=(word(at+16)<<64)|word(at+24);p,z=word(at+32),word(at+40);assert 128<=p<=len(raw) and z<=len(raw)-p and raw[p:p+z]==str(n).encode()
   return n
  if kind==11:
   v=word(at+24);assert v in (0,1);return ('isolated','operator')[v]
  if kind==201:
   p,n=word(at+16),word(at+24);assert n<=len(raw)//64
   out=[];seen=set()
   for _ in range(n):
    assert p not in seen;seen.add(p);out.append(node(p));p=word(p+8)
   assert p==0;return out
  raise AssertionError(('unknown owned record node',kind))
 fields=['execution_mode','system_jobctl','id','host','ssh_target','unit','remote_job_dir','executable','args','cwd','env_keys','created_unix_ms','idempotency_key','request_fingerprint','request_digest','launch_state','launch_error']
 assert word(128)==111 and word(152)==17
 start=word(144);result={}
 for i,name in enumerate(fields):result[name]=node(start+i*64)
 return result

diff=[]
for n,r in zip(native,reference,strict=True):
 assert (n['case_id'],n['name'])==(r['case_id'],r['name'])
 y=r['result'];read_ok=n['input_bytes']<=4194304
 for mode in (1,2,3):
  x=n['result'][str(mode)]
  expected=read_ok and y['accepted'] and (mode!=3 or len(bytes.fromhex(y['pretty_hex']))<=4194304)
  equal=x['accepted']==expected
  if expected and x['accepted']:
   if mode==1:equal=equal and x['output_hex']==y['compact_hex']
   elif mode==3:equal=equal and x['output_hex']==y['pretty_hex']
   else:equal=equal and arena_value(bytes.fromhex(x['output_hex']))==json.loads(bytes.fromhex(y['compact_hex']))
  if not equal:diff.append({'case_id':n['case_id'],'name':n['name'],'mode':mode,'expected_accepted':expected,'actual_accepted':x['accepted'],'native':x,'reference':y})
for row in index:
 if row['mode']==3 and row['return_code'] in (0xffffffff,0xfffffffd):
  assert row['output_sha256']==SHA(b'\xa5'*row['output_capacity']),row
for p in list(frozen):read(Path(p))
result={'passed':not diff,'cases':len(native),'native_calls':len(index),'differences':len(diff),'frame_controls':frame_controls,'source_terminal_stable':True,'binary_full_readback':True,'native_capture_closed_before_reference_read':True,'read_limit':4194304,'pretty_write_limit':4194304,'invalid_pretty_output_unchanged':True,'scope':'original JobRecord raw/pretty 4 MiB boundaries and compact/owned-arena/pretty exact differential; persistence and public process handlers unqualified','elapsed_seconds':time.monotonic()-start}
(Q/'differences.json').write_text(json.dumps(diff,indent=2)+'\n')
(Q/'result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)
for x in diff:print(json.dumps({k:v for k,v in x.items() if k not in ('native','reference')}),flush=True)
raise SystemExit(0 if not diff else 1)
