from pathlib import Path
import gzip,json,hashlib,struct,stat,time,tarfile
R=Path('/home/qian-qi/hia-runtime-process-owner-20261128-2ac5')
O=R/'record-native-boundaries-v2';Q=R/'record-native-boundaries-independent-readback-v1'
Q.mkdir(mode=0o700,exist_ok=False)
t=time.monotonic()
def snapshot(path):
 before=path.lstat();assert stat.S_ISREG(before.st_mode) and before.st_nlink==1
 h=hashlib.sha256();size=0
 with path.open('rb') as f:
  for chunk in iter(lambda:f.read(1<<20),b''):h.update(chunk);size+=len(chunk)
 after=path.lstat()
 def stamp(s):return (s.st_dev,s.st_ino,s.st_mode,s.st_nlink,s.st_size,s.st_mtime_ns,s.st_ctime_ns)
 assert stamp(before)==stamp(after)
 return {'bytes':size,'sha256':h.hexdigest(),'mode':stat.S_IMODE(before.st_mode)}
inputs=[O/'index.json',O/'calls.bin.gz',O/'result.json',O/'native.jsonl',O/'differences.json',O/'physical-inputs.json',
 R/'record-boundaries-geometric-v2.py',Path(__file__)]
initial={str(p):snapshot(p) for p in inputs}
rows=json.loads((O/'index.json').read_bytes());result=json.loads((O/'result.json').read_bytes())
assert len(rows)==99 and result['passed'] and result['cases']==10 and result['native_calls']==99
assert result['differences']==0 and len(result['frame_controls'])==11
corrected=[];changes=[];total=0;whole=hashlib.sha256()
with gzip.open(O/'calls.bin.gz','rb') as stream:
 for row in rows:
  frame=hashlib.sha256()
  def block(n,*,expected_hash=None,fill=None):
   digest=hashlib.sha256();remaining=n
   while remaining:
    raw=stream.read(min(1<<20,remaining));assert raw
    assert len(raw)<=remaining
    if fill is not None:assert raw==bytes([fill])*len(raw)
    frame.update(raw);whole.update(raw);digest.update(raw);remaining-=len(raw)
   value=digest.hexdigest()
   if expected_hash is not None:assert value==expected_hash
   return value
  header=stream.read(64);assert len(header)==64
  frame.update(header);whole.update(header)
  number,case,mode,code,wire,capacity,workspace,zero=struct.unpack('<8Q',header)
  assert zero==0 and (number,case,mode,code,wire,capacity,workspace)==tuple(row[k] for k in (
   'call','case','mode','return_code','input_bytes','output_capacity','workspace_capacity'))
  assert number==len(corrected)+1 and 0<capacity<=128<<20 and 0<workspace<=256<<20
  size=64+wire+workspace*2+capacity*2
  assert size==row['bytes']
  block(wire);block(workspace);block(capacity,fill=165)
  block(capacity,expected_hash=row['output_sha256'])
  block(workspace,expected_hash=row['workspace_after_sha256'])
  assert frame.hexdigest()==row['sha256']
  new=dict(row);new['offset']=total
  if row['offset']!=total:
   changes.append({'call':number,'case':case,'original_offset':row['offset'],'actual_offset':total,'frame_sha256':row['sha256']})
  corrected.append(new);total+=size
 assert stream.read(1)==b''
assert len(changes)==11 and [x['call'] for x in changes]==list(range(89,100))
assert all(corrected[i]==rows[i] for i in range(88))
assert all(x['case']>=1001 for x in changes)
old_total=rows[-1]['offset']+rows[-1]['bytes']
assert old_total==1449181,old_total
(Q/'corrected-index.json').write_text(json.dumps(corrected,indent=2)+'\n')
for p in inputs:assert snapshot(p)==initial[str(p)],str(p)
report={'schema':'hepta.runtime.job-record-independent-capture-readback.v1','scope':'DATA_ONLY_CAPTURE_INDEX_CORRECTION',
 'native_rerun':False,'original_native_cases':10,'original_calls':99,'original_frame_controls':11,
 'full_raw_frame_hashes_verified':99,'all_initial_canaries_verified':99,'all_header_fields_verified':True,
 'all_output_and_workspace_hashes_verified':True,'full_uncompressed_bytes':total,
 'full_uncompressed_sha256':whole.hexdigest(),'wrong_original_last_offset_plus_bytes':old_total,
 'actual_index_corrections':changes,
 'cause':'The module-level malformed-frame loop reused global offset, overwriting the accumulated capture position before calls 89 through 99.',
 'original_files_rewritten':False,'original_inputs_terminal_identical':True,
 'physical_inputs':initial,'elapsed_seconds':time.monotonic()-t,
 'original_product_scope':result['scope'],'public_process_handlers_qualified':False}
(Q/'report.json').write_text(json.dumps(report,indent=2,sort_keys=True)+'\n')
(Q/'README.md').write_text("""# JobRecord capture index correction

The original 99 native calls and their complete raw frames are preserved.
All frame, output and workspace SHA-256 values were independently verified
without invoking a native image. The original index's final eleven offsets
were wrong because the malformed-header preparation loop reused the global
offset variable. The original files and result are not rewritten.

The new index uses actual sequential frame boundaries. Its first 88 rows
are byte-for-byte data-equivalent to the original rows; only offset fields
of rows 89 through 99 change. This readback does not rerun or broaden the
original native qualification.
""")
archive=R/'record-native-boundaries-complete-readback-v1.tar.gz'
members=[]
for prefix,root in [('original',O),('independent-readback',Q)]:
 for path in sorted(root.rglob('*')):
  if path.is_file():
   snap=snapshot(path);members.append({'name':prefix+'/'+path.relative_to(root).as_posix(),'path':str(path),**snap})
members.append({'name':'executed-original-driver.py','path':str(R/'record-boundaries-geometric-v2.py'),**snapshot(R/'record-boundaries-geometric-v2.py')})
members.append({'name':'executed-independent-reader.py','path':str(Path(__file__)),**snapshot(Path(__file__))})
assert not archive.exists()
with tarfile.open(archive,'w:gz',compresslevel=1) as tf:
 for row in members:tf.add(row['path'],arcname=row['name'],recursive=False)
with tarfile.open(archive,'r:gz') as tf:
 info=tf.getmembers();assert len(info)==len(members)
 for item,row in zip(info,members,strict=True):
  assert item.isfile() and item.name==row['name'] and item.mode==row['mode']
  h=hashlib.sha256();size=0
  with tf.extractfile(item) as f:
   for chunk in iter(lambda:f.read(1<<20),b''):h.update(chunk);size+=len(chunk)
  assert size==row['bytes'] and h.hexdigest()==row['sha256']
for row in members:assert snapshot(Path(row['path']))=={k:row[k] for k in ('bytes','sha256','mode')}
manifest={'archive':snapshot(archive),'members':members,'full_member_readback':True,
 'source_terminal_unchanged':True,'raw_member_bytes':sum(x['bytes'] for x in members)}
indexpath=R/'record-native-boundaries-complete-readback-v1.members.json'
indexpath.write_text(json.dumps(manifest,indent=2,sort_keys=True)+'\n')
print(json.dumps({'report':str(Q/'report.json'),'archive':str(archive),'archive_pin':manifest['archive'],
 'members_index':str(indexpath),'members_index_pin':snapshot(indexpath),'member_count':len(members),
 'full_uncompressed_bytes':total,'frame_count':99,'offset_corrections':11,
 'elapsed_seconds':time.monotonic()-t,'native_rerun':False}),flush=True)
