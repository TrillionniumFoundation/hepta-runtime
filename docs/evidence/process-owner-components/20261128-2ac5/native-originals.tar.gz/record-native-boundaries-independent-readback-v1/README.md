# JobRecord capture index correction

The original 99 native calls and their complete raw frames are preserved.
All frame, output and workspace SHA-256 values were independently verified
without invoking a native image. The original index's final eleven offsets
were wrong because the malformed-header preparation loop reused the global
offset variable. The original files and result are not rewritten.

The new index uses actual sequential frame boundaries. Its first 88 rows
are byte-for-byte data-equivalent to the original rows; only offset fields
of rows 89 through 99 change. This readback does not rerun or broaden the
original native qualification.
