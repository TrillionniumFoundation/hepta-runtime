from pathlib import Path
import json,hashlib,zipfile,stat,subprocess,time
Z=Path('/tmp/hia-process-policy-v1-20261128-2ac5.zip');raw=Z.read_bytes()
assert len(raw)==614729 and hashlib.sha256(raw).hexdigest()=='0dc33b78dcb96e980ef9bdc987e4bf11e397b25a3c36d32e99fdbc8b3966c241'
R=Path('/home/qian-qi/hia-runtime-process-owner-20261128-2ac5')
D=R/'policy-native-v1';D.mkdir(mode=0o700)
with zipfile.ZipFile(Z) as z:
 pins=json.loads(z.read('pins.json'));assert set(z.namelist())=={r['path'] for r in pins}|{'pins.json'}
 for row in pins+[{'path':'pins.json','bytes':len(z.read('pins.json')),'sha256':hashlib.sha256(z.read('pins.json')).hexdigest(),'mode':384}]:
  name=row['path'];assert not name.startswith('/') and '..' not in Path(name).parts
  raw=z.read(name);assert len(raw)==row['bytes'] and hashlib.sha256(raw).hexdigest()==row['sha256']
  path=D/name;path.parent.mkdir(mode=0o700,parents=True,exist_ok=True)
  with path.open('xb') as f:f.write(raw)
  path.chmod(row['mode'])
cmd=['/usr/bin/python3','-u','-B',str(D/'driver.py')]
with (D/'driver.stdout').open('xb') as out,(D/'driver.stderr').open('xb') as err:
 p=subprocess.Popen(cmd,stdin=subprocess.DEVNULL,stdout=out,stderr=err,start_new_session=True)
receipt={'pid':p.pid,'argv':cmd,'start_ns':time.time_ns(),'directory':str(D),'scope':'DEVELOPMENT_TYPED_AND_POLICY_COMPONENT','source_full_scope':False}
(D/'launch.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt),flush=True)
