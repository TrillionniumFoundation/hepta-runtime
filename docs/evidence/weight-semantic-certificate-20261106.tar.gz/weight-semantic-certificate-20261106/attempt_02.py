import os,sys,json,pathlib,subprocess,hashlib,time,resource,shutil
root=pathlib.Path('/home/qq/hepta-runtime-wsp-semantic-join-20261106-r1')
q=root/'qualification/semantic_join_20261106'
assert subprocess.check_output(['git','-C',str(root),'rev-parse','HEAD'],text=True).strip()=='f9c121fa54c470cd001c891faaf439ac66bba23f'
assert shutil.disk_usage(root).free>=8*1024**3
tool=pathlib.Path('/home/qq/.rustup/toolchains/1.95.0-x86_64-unknown-linux-gnu/bin')
env={k:os.environ[k] for k in ['HOME','USER','LOGNAME','XDG_RUNTIME_DIR'] if k in os.environ}
env.update({'PATH':str(tool)+':/usr/bin:/bin','LANG':'C.UTF-8','LC_ALL':'C.UTF-8','CARGO_HOME':'/home/qq/.cargo','RUSTC':str(tool/'rustc'),'RUSTDOC':str(tool/'rustdoc'),'CARGO_TARGET_DIR':'/home/qq/hepta-runtime-wsp-semantic-join-target-20261106-r1','CARGO_BUILD_JOBS':'1','CARGO_INCREMENTAL':'0','CARGO_PROFILE_DEV_DEBUG':'0','CARGO_PROFILE_TEST_DEBUG':'0','CARGO_NET_OFFLINE':'true','RUSTUP_TOOLCHAIN':'1.95.0'})
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return h.hexdigest()
changed=['src/mcp/weight_semantic_certificate.rs','src/mcp/weight_semantic_certificate_tests.rs','src/mcp/weight_semantic.rs','src/mcp/weight_semantic/lib.rs','src/mcp/weight_semantic_tests.rs','src/mcp/weight_certificate.rs','src/mcp/mod.rs','src/mcp/server.rs','src/mcp/server_tests.rs','docs/weight-semantic-certificate.md']
def footprint():
 names=[str(p.relative_to(root)) for p in (root/'src').rglob('*.rs')]+['Cargo.toml','Cargo.lock','rustfmt.toml','src/mcp/weight_semantic/target_contract.json']
 return {name:sha(root/name) for name in sorted(set(names))}
def sample():
 result={}
 try:
  line=next(x for x in pathlib.Path('/proc/self/cgroup').read_text().splitlines() if x.startswith('0::'))
  p=pathlib.Path('/sys/fs/cgroup')/line[3:].lstrip('/')
  for name in ['cpu.stat','memory.peak','memory.events','pids.current']:
   result[name]=(p/name).read_text().strip()
 except Exception as e:result['error']=str(e)
 return result
steps=[
 ['cargo','fmt','--all'],
 ['cargo','fmt','--all','--','--check'],
 ['cargo','test','--locked','--offline','--lib','--all-features','weight_semantic','--','--test-threads=1'],
 ['cargo','test','--locked','--offline','--lib','--all-features','weight_certificate','--','--test-threads=1'],
 ['cargo','test','--locked','--offline','--lib','--no-default-features','weight_semantic','--','--test-threads=1'],
 ['cargo','test','--locked','--offline','--lib','--no-default-features','weight_certificate','--','--test-threads=1'],
 ['cargo','clippy','--locked','--offline','--all-targets','--all-features','--','-D','warnings'],
 ['cargo','clippy','--locked','--offline','--all-targets','--no-default-features','--','-D','warnings'],
 ['cargo','fmt','--all','--','--check']]
protocol={'schema':'hepta.semantic-join.targeted-qualification.v1','base':'f9c121fa54c470cd001c891faaf439ac66bba23f','branch':'feature/wsp-semantic-certificate-20261106-r1','steps':steps,'env':env,'tools':{n:sha(tool/n) for n in ['cargo','rustc','rustfmt','cargo-clippy']},'tool_versions':{n:subprocess.check_output([str(tool/n),'--version'],text=True,env=env).strip() for n in ['cargo','rustc','rustfmt']},'source_before_format':footprint(),'limits':{'cpu_quota_percent':200,'memory_max_bytes':6442450944,'build_jobs':1,'timeout_seconds':2300,'gpu_requested':False},'scope':'synthetic and existing targeted engineering tests only; no scientific training, production model forward, held-out evaluation, deployment, or corpus claim'}
(q/'protocol_02.json').write_text(json.dumps(protocol,indent=2)+chr(10))
start=time.monotonic(); end=start+2300; cpu_start=resource.getrusage(resource.RUSAGE_CHILDREN)
records=[]; failed=False; source=None
for index,argv in enumerate(steps):
 print(json.dumps({'event':'step_start','index':index,'argv':argv}),flush=True)
 before=time.monotonic(); use=resource.getrusage(resource.RUSAGE_CHILDREN)
 log=q/('step_02_'+str(index)+'.log')
 with log.open('wb') as out:
  try: status=subprocess.run(argv,cwd=root,env=env,stdout=out,stderr=subprocess.STDOUT,timeout=max(1,end-time.monotonic())).returncode
  except subprocess.TimeoutExpired:status=124
 after=resource.getrusage(resource.RUSAGE_CHILDREN)
 record={'index':index,'argv':argv,'exit_code':status,'wall_seconds':time.monotonic()-before,'child_cpu_seconds':after.ru_utime+after.ru_stime-use.ru_utime-use.ru_stime,'child_maxrss_kib_highwater':after.ru_maxrss,'log':log.name,'log_sha256':sha(log)}
 records.append(record);print(json.dumps({'event':'step_end',**record}),flush=True)
 if index==0:
  source=footprint()
  modified=subprocess.check_output(['git','-C',str(root),'diff','--name-only'],text=True).splitlines()
  assert set(modified).issubset(set(changed)),modified
  (q/'formatted_source_02.json').write_text(json.dumps(source,indent=2)+chr(10))
 if status!=0:failed=True;break
 if source is not None:assert footprint()==source,'source drift during qualification'
after=resource.getrusage(resource.RUSAGE_CHILDREN)
receipt={'protocol_sha256':sha(q/'protocol_02.json'),'steps':records,'complete':len(records)==len(steps) and not failed,'exit_code':1 if failed else 0,'wall_seconds':time.monotonic()-start,'child_cpu_seconds':after.ru_utime+after.ru_stime-cpu_start.ru_utime-cpu_start.ru_stime,'child_maxrss_kib_highwater':after.ru_maxrss,'source':footprint(),'cgroup_final_sample':sample(),'measurement_scope':'child rusage and wrapper monotonic through final hash; cgroup sample through this point, excludes receipt write and exit tail; durable job terminal must be joined'}
(q/'result_02.json').write_text(json.dumps(receipt,indent=2)+chr(10))
print(json.dumps({'event':'final','complete':receipt['complete'],'receipt_sha256':sha(q/'result_02.json'),'child_cpu_seconds':receipt['child_cpu_seconds'],'wall_seconds':receipt['wall_seconds'],'cgroup':receipt['cgroup_final_sample']}),flush=True)
sys.exit(receipt['exit_code'])
