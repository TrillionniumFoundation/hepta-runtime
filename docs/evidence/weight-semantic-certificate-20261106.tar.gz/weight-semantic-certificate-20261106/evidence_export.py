import pathlib,json,hashlib,re,subprocess,zlib,base64
r=pathlib.Path('/home/qq/hepta-runtime-wsp-semantic-join-20261106-r1');q=r/'qualification/semantic_join_20261106'
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return h.hexdigest()
results={n:json.loads((q/f'result_0{n}.json').read_text()) for n in [1,2,3,4]}
assert results[3]['complete'] and results[4]['complete']
assert results[3]['source']==results[4]['source']
for n,s in results[3]['source'].items():assert sha(r/n)==s,n
pins={"src/mcp/weight_semantic_certificate.rs":"caee7a6ff5af8a9cd2512771d84e942b82de30915c49174e2d0c69a6646cd20a","src/mcp/weight_semantic_certificate_tests.rs":"871e3ed040445bba8fe46e5756aaccd728db9aba028ea2ee7775c31c193a695a","src/mcp/weight_semantic.rs":"3ec391e681f76b9b7c37fa760e3549a2cd90ad814e9c33a920929ab08ee7783a","src/mcp/weight_semantic/lib.rs":"f193698d0da36f6c3170b9e4bac07dc5eb3bd88ef009a8d55eb7b40650d6e762","src/mcp/weight_semantic_tests.rs":"f84b771285a29345b79363c4fb30337de3926f647c5fc786fc31a7fdcf9cb19f","src/mcp/weight_certificate.rs":"c74140f4a64aaa1358c7bdb2f3e3700020e50d9a146ec546ae73a768b770a5b8","src/mcp/mod.rs":"e688f4551c014719e726716113c7f3b9ddaf0666793a01af12f5cba14ef9eff3","src/mcp/server.rs":"069d0a4a83e8cce5403f568ea796afe17eba1c23b23caa08e6bbb814d70ad6b2","src/mcp/server_tests.rs":"11fba684d1e7eccb9beb46895a301ce90a296c2dd505e920ab4a064f129c0ab8","docs/weight-semantic-certificate.md":"9c75dc414dc68dc6c13e402906eb47ab818b49fc658ec807e9e4ec5ecdd22c2f","README.md":"55dfe8fbf649985058e34e13473045889e2c38f5008bcd6e20112d719ef83a5e"}
for n,s in pins.items():assert sha(r/n)==s,n
protocol=json.loads((q/'protocol_03.json').read_text())
tool=pathlib.Path('/home/qq/.rustup/toolchains/1.95.0-x86_64-unknown-linux-gnu/bin')
for n,s in protocol['tools'].items():assert sha(tool/n)==s,n
assert sha(r/'Cargo.lock')=='91fd7a8a50e2cbd179b0f5bc3e6d6d9e71b95a94bce4e9eaa9fba67bbb877863'
assert sha(r/'src/mcp/weight_certificate_exact.rs')=='722b7c9402d79dfedabde3120307264376e9e04247cc52433f98101bf88e3e7f'
assert sha(r/'src/mcp/weight_semantic/target_contract.json')=='89cd37c30efb431a362480e26246877140ebc04263881d8f142cd4e5bb96c965'
binaries={}
for n,label in [(2,'all_features'),(4,'no_default_features')]:
 log=(q/f'step_03_{n}.log').read_text()
 p=pathlib.Path(re.search(r'Running unittests src/lib.rs \(([^)]+)\)',log).group(1))
 assert p.is_relative_to('/home/qq/hepta-runtime-wsp-semantic-join-target-20261106-r1/debug/deps')
 binaries[label]={'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p),'kind':'Rust test executable; actual MCP client/server test runs in its isolated child; not a release production Runtime'}
tracked=subprocess.check_output(['git','-C',str(r),'diff','--name-only'],text=True).splitlines()
assert set(tracked)<=set(pins)
untracked=subprocess.check_output(['git','-C',str(r),'ls-files','--others','--exclude-standard'],text=True).splitlines()
assert all(n in pins for n in untracked if n.startswith('src/'))
configs={str(p):{'exists':p.exists(),'sha256':sha(p) if p.is_file() else None} for p in [r/'.cargo/config',r/'.cargo/config.toml',pathlib.Path('/home/qq/.cargo/config'),pathlib.Path('/home/qq/.cargo/config.toml'),pathlib.Path('/home/.cargo/config'),pathlib.Path('/home/.cargo/config.toml'),pathlib.Path('/.cargo/config'),pathlib.Path('/.cargo/config.toml')]}
identity={'schema':'hepta.semantic-join.execution-identity.v1','base':'f9c121fa54c470cd001c891faaf439ac66bba23f','published_source_commit':'66eb0811bb8784d13666d269c470e0ea810bdd89','checkout_head':subprocess.check_output(['git','-C',str(r),'rev-parse','HEAD'],text=True).strip(),'source_sha256':pins,'binaries':binaries,'tools_after':{n:sha(tool/n) for n in protocol['tools']},'cargo_configs_observed_after':configs,'tracked_changes':tracked,'source_file_drift':False,'lock_changed':False,'arithmetic_changed':False,'target_contract_changed':False,'scope':'synthetic targeted tests and actual MCP delivery only; no scientific corpus replay, training, model checkpoint forward, hidden evaluation, promotion, deployment, or production release build'}
(q/'execution_identity_01.json').write_text(json.dumps(identity,indent=2)+chr(10))
files={p.name:{'text':p.read_text(),'sha256':sha(p),'bytes':p.stat().st_size} for p in sorted(q.iterdir()) if p.suffix in ['.json','.log'] and p.name!='stage_01.json'}
b=json.dumps({'files':files},ensure_ascii=False,separators=(',',':')).encode()
print(json.dumps({'uncompressed_bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'encoding':'base64(zlib(utf8-json))'}),flush=True)
print(base64.b64encode(zlib.compress(b,9)).decode(),flush=True)
