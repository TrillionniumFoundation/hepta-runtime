# Build r01 retained; r02 matches the existing compiler panic strategy

The parent operator reported that the first x230 standalone preparation in
`a26-hash-probe-build-r01` completed formatting but compilation exited with
status 1. The recorded job ID is `1a16cba4cf6-1b6abb-46aa`. The retained
`compile.stderr.log` SHA256 is:

`deca339d1a6ec8e37ff76239e849897832f59d6682077b8930fb2858c81b5dca`

The compiler rejected the probe's default unwind panic strategy because the
existing qualified release dependencies (`libc`, `ring`, `cfg_if`, `untrusted`,
and `getrandom`) require abort. No probe was executed in this attempt, so it
produced no measurement cells or performance result. The original frozen
bundle and the failed build directory are retained without modification.

The r02 change is restricted to `prepare_hash_probe.py`. It reads the actual
qualified source's `Cargo.toml`, requires `[profile.release] panic = "abort"`,
verifies that manifest's SHA256 against the qualification source map, binds the
manifest into the pre/post build-input receipts, and passes `-C panic=abort`
to the standalone compiler. It continues to use the existing qualified rlibs;
it does not rebuild or download dependencies, alter the runtime, or write to
the shared target directory.

`PLAN.json`, `PLAN.md`, the Rust measurement input, the one-run wrapper, the
analyzer, and its synthetic checks remain byte-for-byte identical to the
original frozen bundle. Formatting still applies only to a new standalone
copy. The parent operator will explicitly prepare a fresh build r02; there
is no automated compiler retry or measurement retry. This local revision has
not compiled or executed the probe and makes no performance claim.
