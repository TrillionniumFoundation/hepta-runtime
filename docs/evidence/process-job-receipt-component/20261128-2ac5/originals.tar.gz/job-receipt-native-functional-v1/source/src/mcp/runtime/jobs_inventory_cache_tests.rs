// Copyright 2026 Muvon Un Limited
// Copyright 2026 TrillionniumFoundation
// SPDX-License-Identifier: Apache-2.0
//! Snapshot bounds, host/root/cursor custody and original-source invalidation.
use super::*;
use std::os::unix::fs::PermissionsExt;

struct Fixture {
	_owner: tempfile::TempDir,
	root: PathBuf,
}

impl Fixture {
	fn new(count: usize) -> Self {
		let owner = tempfile::tempdir().unwrap();
		let root = owner.path().canonicalize().unwrap().join("state");
		std::fs::create_dir(&root).unwrap();
		std::fs::set_permissions(&root, std::fs::Permissions::from_mode(0o700)).unwrap();
		std::fs::create_dir(root.join("jobs")).unwrap();
		std::fs::set_permissions(root.join("jobs"), std::fs::Permissions::from_mode(0o700))
			.unwrap();
		let fixture = Self {
			_owner: owner,
			root,
		};
		for index in 0..count {
			fixture.write(index, "main", "PRIVATE_ARGUMENT");
		}
		fixture
	}

	fn path(&self, index: usize) -> PathBuf {
		self.root.join("jobs").join(format!("job-{index:05}.json"))
	}

	fn write(&self, index: usize, host: &str, argument: &str) {
		let value = json!({"id":format!("job-{index:05}"),"host":host,"created_unix_ms":index,
			"execution_mode":"operator","ssh_target":"PRIVATE_TARGET","unit":"PRIVATE_UNIT",
			"remote_job_dir":"/PRIVATE_PATH","executable":"/PRIVATE_EXECUTABLE","args":[argument],
			"cwd":null,"env_keys":[],"idempotency_key":null,"request_fingerprint":0,"launch_state":"launched"});
		std::fs::write(self.path(index), serde_json::to_vec(&value).unwrap()).unwrap();
		std::fs::set_permissions(self.path(index), std::fs::Permissions::from_mode(0o600)).unwrap();
	}
}

fn params() -> ProcessListPageParams {
	ProcessListPageParams {
		host: Some("main".into()),
		cursor: None,
		limit: Some(1),
	}
}

fn call(
	fixture: &Fixture,
	params: &ProcessListPageParams,
	cache: &Arc<Mutex<SnapshotCache>>,
) -> Value {
	serde_json::from_str(
		&page_at(&fixture.root, params, InventoryLimits::default(), cache).unwrap(),
	)
	.unwrap()
}

fn continue_from(value: &Value, params: &mut ProcessListPageParams) {
	params.cursor = value["next_cursor"].as_str().map(str::to_owned);
}

#[test]
fn complete_original_pages_reuse_one_snapshot_with_unchanged_public_binding() {
	let fixture = Fixture::new(275);
	let cache = Arc::new(Mutex::new(SnapshotCache::default()));
	let mut params = ProcessListPageParams {
		limit: Some(128),
		..params()
	};
	let original = super::super::inventory_page_rows_at(
		&fixture.root,
		Some("main"),
		InventoryLimits::default(),
	)
	.unwrap();
	let digest =
		inventory_snapshot_digest(&original, Some("main"), &fixture.root.to_string_lossy())
			.unwrap();
	let mut observed = Vec::new();
	loop {
		let page = call(&fixture, &params, &cache);
		assert_eq!(page["snapshot_sha256"], digest);
		assert_eq!(page["total"], 275);
		assert_eq!(page["status_authoritative"], false);
		assert!(!page.to_string().contains("PRIVATE_"));
		observed.extend(page["jobs"].as_array().unwrap().iter().cloned());
		continue_from(&page, &mut params);
		if params.cursor.is_none() {
			assert_eq!(page["inventory_complete"], true);
			break;
		}
	}
	assert_eq!(observed, original);
	let cache = cache.lock().unwrap();
	assert_eq!(cache.entries.len(), 1);
	assert!(cache.bytes <= MAX_SNAPSHOT_BYTES);
}

#[test]
fn every_first_page_revalidates_all_originals_before_filtering() {
	let fixture = Fixture::new(3);
	fixture.write(2, "mac", "PRIVATE_OTHER_HOST");
	let cache = Arc::new(Mutex::new(SnapshotCache::default()));
	call(&fixture, &params(), &cache);
	std::fs::write(fixture.path(2), br#"{"args":[false]}"#).unwrap();
	let error = page_at(&fixture.root, &params(), InventoryLimits::default(), &cache).unwrap_err();
	assert!(error
		.to_string()
		.contains("corrupt durable inventory metadata"));
	assert_eq!(cache.lock().unwrap().entries.len(), 1);
}

#[test]
fn continuation_refuses_private_other_host_change_and_does_not_resurrect_after_restore() {
	let fixture = Fixture::new(3);
	fixture.write(2, "mac", "PRIVATE_BEFORE");
	let original = std::fs::read(fixture.path(2)).unwrap();
	let cache = Arc::new(Mutex::new(SnapshotCache::default()));
	let mut params = params();
	let first = call(&fixture, &params, &cache);
	continue_from(&first, &mut params);
	fixture.write(2, "mac", "PRIVATE_AFTER_");
	assert!(page_at(&fixture.root, &params, InventoryLimits::default(), &cache).is_err());
	std::fs::write(fixture.path(2), original).unwrap();
	let error = page_at(&fixture.root, &params, InventoryLimits::default(), &cache).unwrap_err();
	assert!(error.to_string().contains("snapshot unavailable"));
	params.cursor = None;
	let fresh = call(&fixture, &params, &cache);
	assert_eq!(first["snapshot_sha256"], fresh["snapshot_sha256"]);
	assert_ne!(first["next_cursor"], fresh["next_cursor"]);
}

#[test]
fn continuation_is_bound_to_root_host_and_original_process_cache() {
	let fixture = Fixture::new(2);
	let other = Fixture::new(2);
	let cache = Arc::new(Mutex::new(SnapshotCache::default()));
	let mut params = params();
	let first = call(&fixture, &params, &cache);
	continue_from(&first, &mut params);
	assert!(page_at(&other.root, &params, InventoryLimits::default(), &cache).is_err());
	assert!(page_at(
		&fixture.root,
		&params,
		InventoryLimits::default(),
		&Arc::new(Mutex::new(SnapshotCache::default()))
	)
	.is_err());
	params.host = None;
	assert!(page_at(&fixture.root, &params, InventoryLimits::default(), &cache).is_err());
	params.host = Some("main".into());
	assert_eq!(call(&fixture, &params, &cache)["inventory_complete"], true);
}

#[test]
fn additions_removals_and_directory_replacements_invalidate_the_original_cursor() {
	for change in ["add", "remove", "jobs", "root"] {
		let fixture = Fixture::new(2);
		let cache = Arc::new(Mutex::new(SnapshotCache::default()));
		let mut params = params();
		continue_from(&call(&fixture, &params, &cache), &mut params);
		match change {
			"add" => fixture.write(2, "main", "ADDED"),
			"remove" => std::fs::remove_file(fixture.path(1)).unwrap(),
			"jobs" => {
				std::fs::rename(fixture.root.join("jobs"), fixture.root.join("held-jobs")).unwrap();
				std::fs::create_dir(fixture.root.join("jobs")).unwrap();
			}
			"root" => {
				std::fs::rename(&fixture.root, fixture.root.with_file_name("held-state")).unwrap();
				std::fs::create_dir(&fixture.root).unwrap();
				std::fs::set_permissions(&fixture.root, std::fs::Permissions::from_mode(0o700))
					.unwrap();
				std::fs::create_dir(fixture.root.join("jobs")).unwrap();
			}
			_ => unreachable!(),
		}
		assert!(
			page_at(&fixture.root, &params, InventoryLimits::default(), &cache).is_err(),
			"{change}"
		);
	}
}

#[test]
fn ignored_staging_files_do_not_become_committed_inventory_rows() {
	let fixture = Fixture::new(2);
	let cache = Arc::new(Mutex::new(SnapshotCache::default()));
	let mut params = params();
	continue_from(&call(&fixture, &params, &cache), &mut params);
	std::fs::write(
		fixture.root.join("jobs/unfinished.json.tmp.7"),
		b"not committed JSON",
	)
	.unwrap();
	assert_eq!(call(&fixture, &params, &cache)["total"], 2);
}

#[test]
fn expiration_does_not_uncharge_an_inflight_snapshot() {
	let fixture = Fixture::new(2);
	let cache = Arc::new(Mutex::new(SnapshotCache::default()));
	let first = call(&fixture, &params(), &cache);
	let cursor = first["next_cursor"].as_str().unwrap();
	let token = cursor.split_once(':').unwrap().0;
	let mut state = cache.lock().unwrap();
	let held = state
		.lookup(&fixture.root, Some("main"), token, Instant::now())
		.unwrap();
	let expired = held.created + SNAPSHOT_TTL;
	assert!(state
		.lookup(&fixture.root, Some("main"), token, expired)
		.is_err());
	assert_eq!(state.entries.len(), 1);
	assert!(state.bytes > 0);
	drop(held);
	state.prune(expired);
	assert!(state.entries.is_empty());
	assert_eq!(state.bytes, 0);
}

#[test]
fn idle_count_target_never_limits_active_snapshot_readers() {
	let fixture = Fixture::new(2);
	let mut cache = SnapshotCache::default();
	let mut held = Vec::new();
	for _ in 0..IDLE_SNAPSHOT_TARGET {
		let snapshot = observe(&fixture.root, Some("main"), InventoryLimits::default()).unwrap();
		let token = snapshot.token.clone();
		cache.insert(snapshot, Instant::now()).unwrap();
		held.push(
			cache
				.lookup(&fixture.root, Some("main"), &token, Instant::now())
				.unwrap(),
		);
	}
	let next = observe(&fixture.root, Some("main"), InventoryLimits::default()).unwrap();
	cache.insert(next, Instant::now()).unwrap();
	assert_eq!(cache.entries.len(), IDLE_SNAPSHOT_TARGET + 1);
	assert!(held.iter().all(|entry| {
		cache
			.entries
			.iter()
			.any(|current| Arc::ptr_eq(entry, current))
	}));
	held.pop();
	let next = observe(&fixture.root, Some("main"), InventoryLimits::default()).unwrap();
	cache.insert(next, Instant::now()).unwrap();
	assert_eq!(cache.entries.len(), IDLE_SNAPSHOT_TARGET);
	let mut oversized = observe(&fixture.root, Some("main"), InventoryLimits::default()).unwrap();
	oversized.retained_bytes = MAX_SNAPSHOT_BYTES + 1;
	assert!(cache
		.insert(oversized, Instant::now())
		.unwrap_err()
		.to_string()
		.contains("byte bound"));
}

#[test]
fn page_wire_limit_shrinks_the_slice_without_changing_the_snapshot() {
	let fixture = Fixture::new(3);
	for index in 0..3 {
		let mut record: Value =
			serde_json::from_slice(&std::fs::read(fixture.path(index)).unwrap()).unwrap();
		record["launch_state"] = json!("x".repeat(24 * 1024));
		std::fs::write(fixture.path(index), serde_json::to_vec(&record).unwrap()).unwrap();
	}
	let cache = Arc::new(Mutex::new(SnapshotCache::default()));
	let mut params = ProcessListPageParams {
		limit: Some(3),
		..params()
	};
	let first = call(&fixture, &params, &cache);
	assert_eq!(first["jobs"].as_array().unwrap().len(), 2);
	continue_from(&first, &mut params);
	let final_page = call(&fixture, &params, &cache);
	assert_eq!(first["snapshot_sha256"], final_page["snapshot_sha256"]);
	assert_eq!(final_page["inventory_complete"], true);
	assert_eq!(final_page["jobs"].as_array().unwrap().len(), 1);
}

#[test]
fn malformed_cursor_and_limit_fail_before_any_source_read() {
	let cache = Arc::new(Mutex::new(SnapshotCache::default()));
	for (limit, cursor) in [
		(0, None),
		(129, None),
		(1, Some("x".repeat(257))),
		(1, Some("bad:job-00000".into())),
	] {
		let params = ProcessListPageParams {
			host: None,
			limit: Some(limit),
			cursor,
		};
		let error = page_at(
			Path::new("/does-not-exist"),
			&params,
			InventoryLimits::default(),
			&cache,
		)
		.unwrap_err();
		assert!(error.to_string().starts_with("invalid"));
	}
}

#[test]
fn cached_pages_do_not_bypass_the_original_source_deadline() {
	let fixture = Fixture::new(2);
	let cache = Arc::new(Mutex::new(SnapshotCache::default()));
	let mut params = params();
	continue_from(&call(&fixture, &params, &cache), &mut params);
	let limits = InventoryLimits {
		time: Duration::ZERO,
		..InventoryLimits::default()
	};
	assert!(page_at(&fixture.root, &params, limits, &cache)
		.unwrap_err()
		.to_string()
		.contains("source time budget"));
}

#[tokio::test(flavor = "multi_thread", worker_threads = 2)]
async fn inventory_scans_exceed_old_two_worker_limit_without_busy_refusal() {
	let fixture = Arc::new(Fixture::new(1));
	let (locked, lock_ready) = tokio::sync::oneshot::channel();
	let (release, blocked) = std::sync::mpsc::channel();
	let blocker = std::thread::spawn(move || {
		let _cache = SNAPSHOTS
			.get_or_init(|| Arc::new(Mutex::new(SnapshotCache::default())))
			.lock()
			.unwrap();
		locked.send(()).unwrap();
		let _ = blocked.recv_timeout(Duration::from_secs(10));
	});
	tokio::time::timeout(Duration::from_secs(5), lock_ready)
		.await
		.unwrap()
		.unwrap();
	let (entered, mut started) = tokio::sync::mpsc::unbounded_channel();
	let (finished, mut completed) = tokio::sync::mpsc::unbounded_channel();
	let mut workers = Vec::new();
	for _ in 0..16 {
		let fixture = fixture.clone();
		let entered = entered.clone();
		let finished = finished.clone();
		workers.push(tokio::task::spawn_blocking(move || {
			entered.send(()).unwrap();
			let result = list(&fixture.root, &params());
			finished.send(result.is_ok()).unwrap();
			result
		}));
	}
	for _ in 0..16 {
		tokio::time::timeout(Duration::from_secs(5), started.recv())
			.await
			.unwrap()
			.unwrap();
	}
	// All scans must wait for the real cache lock, never a worker-count refusal.
	assert!(
		tokio::time::timeout(Duration::from_millis(50), completed.recv())
			.await
			.is_err()
	);
	release.send(()).unwrap();
	blocker.join().unwrap();
	for worker in workers {
		let result = tokio::time::timeout(Duration::from_secs(5), worker)
			.await
			.unwrap()
			.unwrap()
			.unwrap();
		let value: Value = serde_json::from_str(&result).unwrap();
		assert_eq!(value["validation_pending"], true);
		assert_eq!(value["jobs"], json!([]));
		assert!(value["next_cursor"]
			.as_str()
			.unwrap()
			.starts_with("pending:"));
	}
}

fn bounded_call(
	fixture: &Fixture,
	params: &ProcessListPageParams,
	cache: &Arc<Mutex<SnapshotCache>>,
	limits: InventoryLimits,
) -> Result<Value> {
	Ok(serde_json::from_str(&request_at(
		&fixture.root,
		params,
		limits,
		cache,
	)?)?)
}

#[test]
fn source_larger_than_one_step_returns_only_pending_until_every_original_is_checked() {
	let fixture = Fixture::new(9);
	let cache = Arc::new(Mutex::new(SnapshotCache::default()));
	let bytes = std::fs::metadata(fixture.path(0)).unwrap().len();
	let limits = InventoryLimits {
		bytes: bytes * 2,
		..InventoryLimits::default()
	};
	let mut request = params();
	let mut pending = 0;
	let mut ids = Vec::new();
	for _ in 0..1000 {
		let page = bounded_call(&fixture, &request, &cache, limits).unwrap();
		assert!(cache.lock().unwrap().bytes <= MAX_SNAPSHOT_BYTES);
		if page["validation_pending"] == true {
			pending += 1;
			std::thread::sleep(Duration::from_millis(1));
			assert_eq!(page["jobs"], json!([]));
			assert_eq!(page["inventory_complete"], false);
			assert_eq!(page["has_more"], true);
			assert!(page["next_cursor"]
				.as_str()
				.unwrap()
				.starts_with("pending:"));
		} else {
			assert_eq!(page["total"], 9);
			ids.extend(
				page["jobs"]
					.as_array()
					.unwrap()
					.iter()
					.map(|row| row["id"].as_str().unwrap().to_owned()),
			);
		}
		continue_from(&page, &mut request);
		if request.cursor.is_none() {
			break;
		}
	}
	assert!(
		pending >= 9,
		"continuations must also re-read complete original bytes"
	);
	assert_eq!(
		ids,
		(0..9)
			.map(|index| format!("job-{index:05}"))
			.collect::<Vec<_>>()
	);
	assert!(request.cursor.is_none());
	assert!(cache.lock().unwrap().pending.is_empty());
}

#[test]
fn pending_observation_refuses_late_corrupt_other_host_before_returning_any_row() {
	let fixture = Fixture::new(4);
	fixture.write(3, "mac", "PRIVATE_OTHER_HOST");
	let original = std::fs::read(fixture.path(3)).unwrap();
	let cache = Arc::new(Mutex::new(SnapshotCache::default()));
	let limits = InventoryLimits {
		bytes: 500,
		..InventoryLimits::default()
	};
	let mut gate = pending::tests::block_after_step(&fixture.root);
	let mut request = params();
	let page = bounded_call(&fixture, &request, &cache, limits).unwrap();
	assert_eq!(page["validation_pending"], true);
	continue_from(&page, &mut request);
	gate.wait();
	std::fs::write(fixture.path(3), br#"{"args":[false]}"#).unwrap();
	gate.release();
	let error = page_at(&fixture.root, &request, limits, &cache).unwrap_err();
	assert!(error
		.to_string()
		.contains("corrupt durable inventory metadata"));
	std::fs::write(fixture.path(3), original).unwrap();
	assert!(bounded_call(&fixture, &request, &cache, limits).is_err());
	assert!(cache.lock().unwrap().entries.is_empty());
}

#[test]
fn pending_continuation_failure_invalidates_the_original_page_cursor_after_restore() {
	let fixture = Fixture::new(4);
	fixture.write(3, "mac", "PRIVATE_OTHER_HOST");
	let original = std::fs::read(fixture.path(3)).unwrap();
	let cache = Arc::new(Mutex::new(SnapshotCache::default()));
	let mut request = params();
	continue_from(&call(&fixture, &request, &cache), &mut request);
	let original_cursor = request.cursor.clone();
	let limits = InventoryLimits {
		bytes: 500,
		..InventoryLimits::default()
	};
	let mut gate = pending::tests::block_after_step(&fixture.root);
	let first = bounded_call(&fixture, &request, &cache, limits).unwrap();
	assert_eq!(first["validation_pending"], true);
	continue_from(&first, &mut request);
	gate.wait();
	fixture.write(3, "mac", "PRIVATE_MUTATED_HOST");
	gate.release();
	assert!(page_at(&fixture.root, &request, limits, &cache).is_err());
	std::fs::write(fixture.path(3), original).unwrap();
	assert!(bounded_call(&fixture, &request, &cache, limits).is_err());
	request.cursor = original_cursor;
	assert!(bounded_call(&fixture, &request, &cache, InventoryLimits::default()).is_err());
}

#[test]
fn pending_steps_keep_bounded_projection_and_hold_reservation_through_actual_lifetime() {
	let fixture = Fixture::new(20);
	for index in 0..20 {
		fixture.write(index, "main", &"X".repeat(128 * 1024));
	}
	let cache = Arc::new(Mutex::new(SnapshotCache::default()));
	let limits = InventoryLimits {
		bytes: 200 * 1024,
		..InventoryLimits::default()
	};
	let mut gate = pending::tests::block_after_step(&fixture.root);
	let page = bounded_call(&fixture, &params(), &cache, limits).unwrap();
	assert_eq!(page["validation_pending"], true);
	gate.wait();
	let expired = Instant::now() + SNAPSHOT_TTL + Duration::from_secs(1);
	{
		let mut state = cache.lock().unwrap();
		assert!(
			state.bytes < 128 * 1024,
			"private raw bytes must not survive a step"
		);
		state.prune(expired);
		assert_eq!(state.pending.len(), 1);
		assert!(state.bytes > 0);
	}
	gate.release();
	pending::tests::wait_finished(&cache);
	let mut state = cache.lock().unwrap();
	state.prune(expired);
	assert!(state.pending.is_empty());
	assert_eq!(state.bytes, 0);
}

#[test]
fn pending_cursor_is_bound_to_scope_and_polling_never_restarts_the_observation() {
	let fixture = Fixture::new(4);
	let other = Fixture::new(4);
	let cache = Arc::new(Mutex::new(SnapshotCache::default()));
	let limits = InventoryLimits {
		bytes: 500,
		..InventoryLimits::default()
	};
	let mut gate = pending::tests::block_after_step(&fixture.root);
	let mut request = params();
	continue_from(
		&bounded_call(&fixture, &request, &cache, limits).unwrap(),
		&mut request,
	);
	gate.wait();
	let original = request.cursor.clone();
	assert!(bounded_call(&other, &request, &cache, limits).is_err());
	request.host = Some("mac".into());
	assert!(bounded_call(&fixture, &request, &cache, limits).is_err());
	request.host = Some("main".into());
	for _ in 0..4 {
		let poll = bounded_call(&fixture, &request, &cache, limits).unwrap();
		assert_eq!(poll["validation_pending"], true);
		assert_eq!(poll["next_cursor"].as_str(), original.as_deref());
	}
	assert_eq!(gate.starts(), 1);
	gate.release();
	pending::tests::wait_finished(&cache);
	assert_eq!(call(&fixture, &request, &cache)["total"], 4);
}

#[test]
#[ignore = "explicit read-only real-registry benchmark; emits aggregate measurements only"]
fn real_registry_readonly_inventory_benchmark() {
	let root = PathBuf::from(
		std::env::var_os("HEPTA_REGISTRY_BENCH_ROOT").expect("explicit benchmark root"),
	);
	let cache = Arc::new(Mutex::new(SnapshotCache::default()));
	let mut request = ProcessListPageParams {
		host: None,
		cursor: None,
		limit: Some(32),
	};
	let mut pages = 0;
	let mut steps = 0;
	let all_started = Instant::now();
	let mut pending = 0;
	for _ in 0..4000 {
		let started = Instant::now();
		let result = request_at(&root, &request, InventoryLimits::default(), &cache);
		let elapsed = started.elapsed().as_millis();
		let total_ms = all_started.elapsed().as_millis();
		steps += 1;
		let Ok(text) = result else {
			println!(
				"{}",
				json!({"benchmark":"readonly_inventory", "accepted":false,
				"steps":steps,"pending_steps":pending,"pages":pages,"total_ms":total_ms,
				"last_step_ms":elapsed,"retained_bytes":cache.lock().unwrap().bytes})
			);
			panic!("real-registry inventory was refused; inspect the aggregate result");
		};
		let value: Value = serde_json::from_str(&text).unwrap();
		if value["validation_pending"] == true {
			pending += 1;
			std::thread::sleep(Duration::from_millis(20));
		} else {
			pages += 1;
		}
		request.cursor = value["next_cursor"].as_str().map(str::to_owned);
		if pages >= 2 || request.cursor.is_none() {
			println!(
				"{}",
				json!({"benchmark":"readonly_inventory", "accepted":true,
				"steps":steps,"pending_steps":pending,"pages":pages,"total_ms":total_ms,
				"last_step_ms":elapsed,"total":value["total"],
				"all_originals_validated":value["validation_pending"] == false,
				"retained_bytes":cache.lock().unwrap().bytes})
			);
			return;
		}
	}
	panic!("bounded benchmark did not finish its first two pages");
}
