#!/usr/bin/env python3
"""Derive counts from immutable completed job logs; do not execute repository code."""
from pathlib import Path
import hashlib
import json
import re

BASE = Path(__file__).resolve().parent
HEAD = "e425d92b6a0dedf13eb3e484e76419ee756804c0"


def derive(job_id, filename, output):
    path = BASE / filename
    lines = path.read_text().splitlines()
    nextest = []
    python = []
    for i, line in enumerate(lines):
        match = re.search(r"Summary \[\s*([0-9.]+)s\] (\d+) tests run: (\d+) passed(?:, (\d+) failed)?(?:, (\d+) skipped)?", line)
        if match:
            nextest.append({"source_log_line": i + 1, "timestamp": line.split(" ", 1)[0], "test_execution_seconds": float(match[1]), "run": int(match[2]), "passed": int(match[3]), "failed": int(match[4] or 0), "skipped": int(match[5] or 0)})
        match = re.search(r"Ran (\d+) tests? in ([0-9.]+)s", line)
        if match:
            following = next((candidate for candidate in lines[i + 1:i + 6] if re.search(r"\b(?:OK|FAILED)(?: |$)", candidate)), None)
            skipped = re.search(r"skipped=(\d+)", following or "")
            python.append({"source_log_line": i + 1, "timestamp": line.split(" ", 1)[0], "run": int(match[1]), "seconds": float(match[2]), "result_line": following, "skipped": int(skipped[1]) if skipped else 0, "success": bool(following and re.search(r"\bOK(?: |$)", following))})
    report = {"schema": "hepta.hosted_job_log_counts.v1", "head": HEAD, "job_id": job_id, "log": filename, "log_sha256": hashlib.sha256(path.read_bytes()).hexdigest(), "nextest_suites": nextest, "python_unittest_summaries": python, "python_unittest_total_runs": sum(case["run"] for case in python), "python_unittest_total_skipped": sum(case["skipped"] for case in python), "all_python_unittest_summaries_success": all(case["success"] for case in python), "counting_note": "Counts are executions per feature mode/lane, not unique test identities. Python unittest Ran includes skips; nextest tests run excludes its separately reported skipped count. Only explicit unittest summaries count as Python tests; other CLI/artifact gates remain separate."}
    if report["all_python_unittest_summaries_success"]:
        report["python_unittest_total_passed"] = report["python_unittest_total_runs"] - report["python_unittest_total_skipped"]
    (BASE / output).write_text(json.dumps(report, indent=2) + "\n")
    return report


if __name__ == "__main__":
    reports = [derive(132774532555, "rust-exact-43701857912-job-132774532555.log", "rust-exact-132774532555-counts.json"), derive(132774532810, "rust-prospective-43701857912-job-132774532810.log", "rust-prospective-132774532810-counts.json"), derive(132774532159, "cloud-pr-43701857874-job-132774532159.log", "cloud-pr-132774532159-counts.json")]
    print(json.dumps([{key: value for key, value in report.items() if key not in {"python_unittest_summaries", "counting_note"}} for report in reports]))
