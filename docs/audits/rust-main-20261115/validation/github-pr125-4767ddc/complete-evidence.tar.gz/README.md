# PR #125 中间候选 4767ddc0 的历史 CI 结果

本目录保留依赖修复之前的候选 `4767ddc02e627d9c0d68e1e04fe555949a9e9c3b` 的实际结果与完整原始日志，不能用于最终候选放行。

Cloud push 与 PR 各完成 191 项且全部通过。Rust prospective-merge lane 的全特性 nextest 完成：2630 passed、44 skipped；随后 no-default 编译被取消。Rust exact-head lane 启动 2630 项、报告 44 skipped，在取消前记录 2073 条 PASS，未产生完整 suite 摘要，不能记为整套通过。两条 lane 的 release 等后续 gate 未执行。

取消发生在 2026-11-15 08:54:25 UTC，新候选 `0414c548` 同 PR run 启动之后；结合 workflow 的 `cancel-in-progress: true`，归类为候选被替代而自动取消，非观测到的代码失败。观察者未手动取消或重跑 workflow。依赖安全告警随后另行修复，最终候选证据位于独立目录。

`summary.json` 提供最终分类；`observation-timeline.json` 保留原始阶段性状态；四份 `.log` 为完整 job 日志，包含正常取消错误行与原始空白。执行路径是审计证据，不是用户路径。未运行真实 host、发布、生产或真实云任务。
