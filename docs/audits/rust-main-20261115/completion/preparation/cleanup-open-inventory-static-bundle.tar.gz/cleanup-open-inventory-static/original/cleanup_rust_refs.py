#!/usr/bin/env python3
"""One-shot PR #125 cleanup. Default: read-only. Never discovers deletion targets.

Inputs are the reviewed exact 149 original Rust tips, the owned candidate, six
protected HIA tips, a post-merge main SHA, and successful CI run IDs. No token is
read, printed, exported, or written. gh's existing authentication is used by gh
and by an invocation-scoped Git credential helper. No persistent config changes.

The atomic Git transaction covers deletion targets only. GitHub's default-branch
PATCH, PR state, retained refs, and new refs cannot share that transaction. Every
stage is therefore checked and recorded; a detected race stops without rollback,
automatic retries, or any attempt to restore/rewrite HIA or main.
"""

import argparse
import datetime as dt
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import tempfile


REPOSITORY = "TrillionniumFoundation/hepta-runtime"
REMOTE = "https://github.com/TrillionniumFoundation/hepta-runtime.git"
MAIN = "refs/heads/main"
CANDIDATE = "refs/heads/consolidate/rust-main-20261115"
ORIGINAL_DEFAULT = "hepta-runtime-base"
ORIGINAL_RUST_FINGERPRINT = (
    "a3df83a37afd68c868553f6c65e7f219352677fb3a76ce5beab0603162c090a1"
)
PROTECTED = frozenset({
    "refs/heads/codex/hia-archive-source-retention-20261111-f9aa",
    "refs/heads/codex/hia-request-context-20261114-7c666",
    "refs/heads/codex/hia-runtime-native-20261114-bd947b55",
    "refs/heads/codex/hia-shell-lifecycle-20261115-194042",
    "refs/heads/codex/hia-shell-native-20261115-194042",
    "refs/heads/recovery/hia-bd947-20261114",
})
# Both PR workflows check out the exact candidate. Cloud's push path filter
# may not match a dependency-only follow-up; a previous head's push success
# must never stand in for the candidate's Cloud PR run.
CI_REQUIREMENTS = {
    (".github/workflows/ci.yml", "pull_request"),
    (".github/workflows/cloud-compute.yml", "pull_request"),
}
SHA = re.compile(r"[0-9a-f]{40}\Z")
REF = re.compile(r"refs/heads/[A-Za-z0-9][A-Za-z0-9._/-]*\Z")


class Refusal(Exception):
    pass


def require(condition, message):
    if not condition:
        raise Refusal(message)


def utc():
    return dt.datetime.now(dt.timezone.utc).isoformat()


def fingerprint(value):
    return hashlib.sha256(json.dumps(
        value, sort_keys=True, separators=(",", ":"), ensure_ascii=True,
        allow_nan=False,
    ).encode("utf-8")).hexdigest()


def no_duplicate_keys(pairs):
    result = {}
    for key, value in pairs:
        require(key not in result, "JSON contains duplicate object keys")
        result[key] = value
    return result


def sha(value):
    require(isinstance(value, str) and SHA.fullmatch(value),
            "Expected a full, lowercase 40-character commit SHA")
    return value


def ref(value):
    require(isinstance(value, str) and REF.fullmatch(value),
            "Invalid or unsupported full branch ref")
    parts = value.split("/")
    require(".." not in value and not value.endswith(".")
            and all(part and not part.startswith(".")
                    and not part.endswith(".lock") for part in parts),
            "Unsafe branch ref spelling")
    return value


def ref_map(rows):
    require(isinstance(rows, list), "Plan ref list must be an array")
    result = {}
    for row in rows:
        require(isinstance(row, dict), "Plan ref entry must be an object")
        name = ref(row.get("ref"))
        require(name not in result, "Duplicate branch ref in plan")
        result[name] = sha(row.get("expected_sha"))
    return result


def load_plan(path, candidate_sha):
    raw = Path(path).read_bytes()
    require(len(raw) <= 2_000_000, "Plan exceeds the expected bounded size")
    plan = json.loads(raw, object_pairs_hook=no_duplicate_keys)
    require(plan.get("schema") == "hepta.cleanup-operation-plan.v1",
            "Unexpected cleanup-plan schema")
    require(plan.get("repository") == REPOSITORY, "Wrong plan repository")
    require(plan.get("candidate") == {
        "ref": CANDIDATE, "expected_sha": candidate_sha,
    }, "Plan candidate does not equal the explicit expected candidate")
    deletes = ref_map(plan.get("deletion_candidates"))
    protected = ref_map(plan.get("preserved_hia_refs"))
    require(set(protected) == PROTECTED, "Protected HIA ref set changed")
    require(not (set(deletes) & (PROTECTED | {MAIN})),
            "Protected HIA or main ref appears in deletion targets")
    require(len(deletes) == 150 and deletes.get(CANDIDATE) == candidate_sha,
            "Expected exactly 149 original Rust refs plus the owned candidate")
    original = {key: value for key, value in deletes.items() if key != CANDIDATE}
    require(fingerprint(original) == ORIGINAL_RUST_FINGERPRINT,
            "Original 149 ref/SHA pairs differ from the reviewed initial inventory")
    proof = plan.get("source_custody_verification", {})
    require(isinstance(proof, dict)
            and proof.get("schema") == "hepta.rust-consolidation-verification.v1"
            and proof.get("revision") == candidate_sha
            and proof.get("status") == "PASS"
            and proof.get("original_branches") == 155
            and proof.get("integrated_rust_refs") == 149
            and proof.get("protected_refs") == 6
            and proof.get("protected_rewrites_included") == []
            and proof.get("standalone_study_unchanged") is True
            and proof.get("native_rewrite_directory_included") is False,
            "Source-custody verification is not PASS for this exact candidate")
    require(plan.get("current_protected_rewrite_tips_in_history") == [],
            "Current HIA rewrite tips must not appear in candidate history")
    return plan, deletes, protected, hashlib.sha256(raw).hexdigest()


def isolate_subprocess_configuration():
    # Inspect environment variable names only; never inspect credential values.
    # Existing gh authentication remains inherited by normal child processes.
    for name in tuple(os.environ):
        if name.startswith("GIT_") or name in {"GH_DEBUG", "GH_PAGER"}:
            os.environ.pop(name, None)
    os.environ["GIT_CONFIG_GLOBAL"] = "/dev/null"
    os.environ["GIT_CONFIG_SYSTEM"] = "/dev/null"
    os.environ["GIT_CONFIG_NOSYSTEM"] = "1"
    os.environ["GIT_TERMINAL_PROMPT"] = "0"
    os.environ["GIT_ASKPASS"] = "/usr/bin/false"
    os.environ["GH_PROMPT_DISABLED"] = "1"
    os.environ["GH_HOST"] = "github.com"
    os.environ["GCM_INTERACTIVE"] = "never"


def diagnostic_class(stderr):
    # Do not persist raw subprocess streams: remote errors can contain URLs or
    # authentication diagnostics. Only fixed labels enter the receipt.
    low = stderr.lower()
    for needle, label in (
        ("does not support --atomic", "server_atomic_unsupported"),
        ("stale info", "stale_lease"),
        ("atomic push failed", "atomic_push_rejected"),
        ("authentication", "authentication_failure"),
        ("protected branch", "branch_protection_rejection"),
    ):
        if needle in low:
            return label
    return "subprocess_failure"


def command(args, label, timeout=90, checked=True):
    try:
        completed = subprocess.run(
            args, text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
            timeout=timeout, check=False,
        )
    except subprocess.TimeoutExpired:
        if checked:
            raise Refusal(label + " timed out; raw output omitted") from None
        return {"returncode": None, "diagnostic": "timeout", "stdout": ""}
    except OSError:
        raise Refusal(label + " could not start; raw diagnostics omitted") from None
    result = {"returncode": completed.returncode, "stdout": completed.stdout,
              "diagnostic": None if completed.returncode == 0
              else diagnostic_class(completed.stderr)}
    if checked:
        require(completed.returncode == 0,
                label + " failed: " + str(result["diagnostic"]))
    return result


def git_prefix():
    return ["git", "-c", "credential.helper=", "-c",
            "credential.https://github.com.helper=!gh auth git-credential",
            "-c", "core.hooksPath=/dev/null"]


def gh(endpoint, selection, method="GET", fields=()):
    args = ["gh", "api", "--hostname", "github.com", "--method", method,
            endpoint, "--jq", selection]
    for name, value in fields:
        args += ["--raw-field", name + "=" + value]
    output = command(args, "GitHub " + method + " request")["stdout"]
    require(len(output) <= 2_000_000, "GitHub response exceeds bounded metadata size")
    try:
        return json.loads(output, object_pairs_hook=no_duplicate_keys)
    except (ValueError, TypeError):
        raise Refusal("GitHub returned malformed selected metadata") from None


REPO_SELECTION = (
    "{full_name,default_branch,archived,disabled,admin:.permissions.admin}"
)
PR_SELECTION = (
    "{number,state,merged,merge_commit_sha,merged_at,"
    "head:{ref:.head.ref,sha:.head.sha,repo:.head.repo.full_name},"
    "base:{ref:.base.ref,sha:.base.sha,repo:.base.repo.full_name}}"
)


def repository_state(require_main=False):
    value = gh("repos/" + REPOSITORY, REPO_SELECTION)
    require(value.get("full_name", "").lower() == REPOSITORY.lower(),
            "GitHub returned the wrong repository")
    require(value.get("admin") is True and not value.get("archived")
            and not value.get("disabled"), "Repository is not writable by its administrator")
    allowed = {"main"} if require_main else {ORIGINAL_DEFAULT, "main"}
    require(value.get("default_branch") in allowed, "Unexpected default branch")
    return value


def merged_pr(candidate_sha, main_sha):
    value = gh("repos/" + REPOSITORY + "/pulls/125", PR_SELECTION)
    require(value.get("number") == 125 and value.get("merged") is True
            and value.get("state") == "closed" and value.get("merged_at"),
            "PR #125 is not merged")
    require(value.get("head") == {
        "ref": CANDIDATE.removeprefix("refs/heads/"),
        "sha": candidate_sha, "repo": REPOSITORY,
    }, "PR #125 head differs from the exact reviewed candidate")
    base = value.get("base", {})
    require(base.get("ref") == "main" and base.get("repo") == REPOSITORY,
            "PR #125 base is not this repository's main branch")
    sha(base.get("sha"))  # Record it; GitHub may retain the pre-merge base SHA.
    require(value.get("merge_commit_sha") == main_sha,
            "Expected main is not PR #125's exact merge commit")
    return value


def candidate_ancestry(candidate_sha, main_sha):
    value = gh("repos/" + REPOSITORY + "/compare/" + candidate_sha + "..." + main_sha,
               "{status,ahead_by,behind_by,base_commit:.base_commit.sha,"
               "merge_base_commit:.merge_base_commit.sha}")
    require(value.get("status") in {"ahead", "identical"}
            and value.get("behind_by") == 0
            and value.get("base_commit") == candidate_sha
            and value.get("merge_base_commit") == candidate_sha,
            "Candidate is not an ancestor of the exact expected main; no squash/rebase cleanup")
    return value


def paginated(endpoint, selection):
    result = []
    for page in range(1, 21):
        joiner = "&" if "?" in endpoint else "?"
        batch = gh(endpoint + joiner + "per_page=100&page=" + str(page), selection)
        require(isinstance(batch, list) and len(batch) <= 100,
                "Unexpected paginated metadata shape")
        result.extend(batch)
        if len(batch) < 100:
            return result
    raise Refusal("Metadata pagination exceeded 2,000 records; refusing partial inventory")


def ci_state(run_ids, candidate_sha):
    found = set()
    runs = []
    for run_id in run_ids:
        value = gh("repos/" + REPOSITORY + "/actions/runs/" + str(run_id),
                   "{id,run_attempt,status,conclusion,head_sha,head_branch,event,path,"
                   "repository:.repository.full_name,workflow_id,html_url,updated_at}")
        require(value.get("id") == run_id
                and value.get("repository") == REPOSITORY
                and value.get("head_sha") == candidate_sha
                and value.get("head_branch") == CANDIDATE.removeprefix("refs/heads/")
                and value.get("status") == "completed"
                and value.get("conclusion") == "success",
                "Required CI run is not successful for this exact candidate")
        workflow = value.get("path", "").split("@", 1)[0]
        key = (workflow, value.get("event"))
        require(key in CI_REQUIREMENTS, "Unexpected CI workflow/event in approved run IDs")
        attempt = value.get("run_attempt")
        require(isinstance(attempt, int) and attempt > 0, "CI run attempt is missing")
        jobs = paginated(
            "repos/" + REPOSITORY + "/actions/runs/" + str(run_id)
            + "/attempts/" + str(attempt) + "/jobs",
            "[.jobs[] | {id,name,status,conclusion}]",
        )
        names = {job.get("name") for job in jobs}
        expected = ({"Rust exact-head validation", "Rust prospective-merge validation"}
                    if workflow.endswith("/ci.yml") else {"offline-tests"})
        require(expected <= names and all(
            job.get("status") == "completed" and job.get("conclusion") == "success"
            for job in jobs
        ), "CI jobs are missing, skipped, incomplete, or unsuccessful")
        value["jobs"] = jobs
        runs.append(value)
        found.add(key)
    require(found == CI_REQUIREMENTS,
            "Need successful Rust PR and Cloud PR runs for this exact candidate")
    return runs


def open_pull_requests():
    # Enumerate all PRs in creation order, then filter locally. Closing a PR
    # cannot shift records between pages as it can with state=open pagination.
    rows = paginated("repos/" + REPOSITORY
                     + "/pulls?state=all&sort=created&direction=asc",
                     "[.[] | {number,state,"
                     "head:{ref:.head.ref,sha:.head.sha,repo:.head.repo.full_name},"
                     "base:{ref:.base.ref,sha:.base.sha,repo:.base.repo.full_name}}]")
    numbers = [row.get("number") for row in rows]
    require(len(set(numbers)) == len(numbers), "Concurrent PR pagination returned duplicates")
    require(all(isinstance(number, int) for number in numbers)
            and all(row.get("state") in {"open", "closed"} for row in rows),
            "Unexpected PR inventory")
    opened = [row for row in rows if row["state"] == "open"]
    for row in opened:
        for role in ("head", "base"):
            endpoint = row.get(role)
            require(isinstance(endpoint, dict)
                    and isinstance(endpoint.get("ref"), str) and endpoint["ref"],
                    "Incomplete open PR head/base identity")
            sha(endpoint.get("sha"))
        require(str(row["base"].get("repo", "")).lower() == REPOSITORY.lower(),
                "Open PR base repository identity is unexpected")
    return opened


def pr_dependencies(prs, deletes):
    blockers = []
    for pr in prs:
        for role in ("head", "base"):
            endpoint = pr.get(role, {})
            name = "refs/heads/" + str(endpoint.get("ref", ""))
            repository = endpoint.get("repo")
            # A null repo is ambiguous, so a matching ref fails closed.
            same_repo = repository is None or str(repository).lower() == REPOSITORY.lower()
            if name in deletes and same_repo:
                blockers.append({"number": pr["number"], "role": role, "ref": name})
    return blockers


def remote_heads(bare):
    # The caller's cwd may belong to an unrelated configured repository.
    # Resolve URLs and credentials only within our new, empty bare repository.
    output = command(git_prefix() + ["-C", str(bare), "ls-remote", "--heads", "--refs", REMOTE],
                     "Complete fresh remote branch inventory")["stdout"]
    heads = {}
    for line in output.splitlines():
        parts = line.split("\t")
        require(len(parts) == 2, "Malformed ls-remote branch record")
        oid, name = parts
        # Unknown refs are evidence, not targets. Preserve their names even if
        # they use Git-valid characters outside the reviewed plan's subset.
        require(name.startswith("refs/heads/") and "\x00" not in name,
                "Malformed remote branch ref")
        sha(oid)
        require(name not in heads, "Duplicate remote branch ref")
        heads[name] = oid
    require(heads, "Remote branch inventory is empty")
    return heads


def snapshot(bare):
    # Read every branch, not just known names. Store only ref names, hashes and
    # selected public metadata; never auth details, PR bodies, or source blobs.
    value = {"observed_utc": utc(), "read_failures": {}}
    # A failure reading one endpoint must not prevent collecting main/HIA
    # evidence from the others, especially after a failed/ambiguous push.
    for key, read, empty in (
        ("repository", lambda: gh("repos/" + REPOSITORY, REPO_SELECTION), {}),
        ("open_prs", open_pull_requests, []),
        ("heads", lambda: remote_heads(bare), {}),
    ):
        try:
            value[key] = read()
        except (Refusal, ValueError, TypeError, KeyError) as error:
            value[key] = empty
            value["read_failures"][key] = (
                str(error) if isinstance(error, Refusal) else type(error).__name__
            )
    value["completed_utc"] = utc()
    return value


def snapshot_issues(value, expected, deletes, default_main=False):
    heads = value["heads"]
    issues = {
        "read_failures": value.get("read_failures", {}),
        "unknown_refs": sorted(set(heads) - set(expected)),
        "missing_refs": sorted(set(expected) - set(heads)),
        "changed_refs": [name for name in sorted(set(heads) & set(expected))
                         if heads[name] != expected[name]],
        "open_pr_dependencies": pr_dependencies(value["open_prs"], deletes),
    }
    repository = value["repository"]
    if (repository.get("full_name", "").lower() != REPOSITORY.lower()
            or repository.get("admin") is not True
            or repository.get("archived") is not False
            or repository.get("disabled") is not False):
        issues["repository_identity_or_admin_state_changed"] = True
    allowed = {"main"} if default_main else {ORIGINAL_DEFAULT, "main"}
    if repository.get("default_branch") not in allowed:
        issues["unexpected_default_branch"] = True
    return issues


def check_snapshot(evidence, stage, expected, deletes, bare, default_main=False):
    value = snapshot(bare)
    value["issues"] = snapshot_issues(value, expected, deletes, default_main)
    evidence.write(stage + ".json", value)
    require(not any(value["issues"].values()),
            stage + ": ref/default/PR state differs; inspect the sanitized snapshot")
    return value


def push_arguments(bare, targets, remote, dry_run):
    require(targets and not (set(targets) & (PROTECTED | {MAIN})),
            "Refusing an empty push or any protected/main deletion")
    for name, oid in targets.items():
        ref(name)
        sha(oid)
    args = git_prefix() + ["-C", str(bare), "push", "--atomic", "--porcelain"]
    if dry_run:
        args.append("--dry-run")
    args += ["--force-with-lease=" + name + ":" + targets[name] for name in sorted(targets)]
    args += [remote] + [":" + name for name in sorted(targets)]
    return args


class Evidence:
    def __init__(self, directory, mode):
        self.directory = Path(directory).absolute()
        self.directory.mkdir(mode=0o700, parents=False, exist_ok=False)
        self.receipt = {"schema": "hepta.rust-cleanup-receipt.v1", "mode": mode,
                        "repository": REPOSITORY, "started_utc": utc(),
                        "script_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                        "default_change_attempted": False,
                        "atomic_delete_attempted": False}

    def write(self, name, value):
        path = self.directory / name
        flags = os.O_WRONLY | os.O_CREAT | os.O_EXCL | getattr(os, "O_NOFOLLOW", 0)
        fd = os.open(path, flags, 0o600)
        with os.fdopen(fd, "w", encoding="utf-8") as stream:
            json.dump(value, stream, sort_keys=True, indent=2, ensure_ascii=True, allow_nan=False)
            stream.write("\n")
            stream.flush()
            os.fsync(stream.fileno())

    def finish(self, status, reason=None):
        self.receipt.update(status=status, finished_utc=utc())
        if reason:
            self.receipt["reason"] = reason
        self.write("receipt.json", self.receipt)


def perform(args, evidence):
    main_sha, candidate_sha = sha(args.expected_main), sha(args.expected_candidate)
    plan, deletes, protected, plan_hash = load_plan(args.plan, candidate_sha)
    require(main_sha != candidate_sha, "Expected the merge commit, not the candidate SHA")
    require(all(run_id > 0 for run_id in args.ci_run_id)
            and len(set(args.ci_run_id)) == len(args.ci_run_id),
            "Invalid or duplicate CI run ID")
    expected = {**deletes, **protected, MAIN: main_sha}
    retained = {**protected, MAIN: main_sha}
    evidence.receipt.update(expected_main=main_sha, expected_candidate=candidate_sha,
                            plan_sha256=plan_hash, delete_count=len(deletes),
                            retained_count=len(retained), ci_run_ids=args.ci_run_id,
                            protected_refs=protected)
    evidence.write("reviewed-plan.json", plan)
    with tempfile.TemporaryDirectory(prefix="hepta-rust-cleanup-") as temporary:
        bare = Path(temporary) / "empty.git"
        command(["git", "init", "--bare", "--quiet", str(bare)], "Temporary bare repository init")
        evidence.write("pr125-merged.json", merged_pr(candidate_sha, main_sha))
        evidence.write("candidate-ancestor-of-main.json", candidate_ancestry(candidate_sha, main_sha))
        evidence.write("ci-success.json", ci_state(args.ci_run_id, candidate_sha))
        check_snapshot(evidence, "01-preflight", expected, deletes, bare)
        if args.execute or args.dry_run_push:
            result = command(push_arguments(bare, deletes, REMOTE, True),
                             "Atomic push dry-run", timeout=180, checked=False)
            evidence.write("atomic-push-dry-run.json", {
                "observed_utc": utc(), "returncode": result["returncode"],
                "diagnostic": result["diagnostic"], "target_count": len(deletes),
                "per_ref_exact_lease": True, "atomic": True,
            })
            require(result["returncode"] == 0, "Atomic push dry-run failed")
        if not args.execute:
            check_snapshot(evidence, "02-dry-run-postcheck", expected, deletes, bare)
            return "DRY_RUN_READY_NO_REMOTE_MUTATIONS"

        # No interactive approvals, config writes or retries. The explicit
        # --execute flag applies only to this already-reviewed exact plan.
        evidence.write("ci-success-before-mutation.json", ci_state(args.ci_run_id, candidate_sha))
        evidence.write("pr125-before-mutation.json", merged_pr(candidate_sha, main_sha))
        before = check_snapshot(evidence, "02-before-default-change", expected, deletes, bare)
        if before["repository"]["default_branch"] != "main":
            evidence.receipt["default_change_attempted"] = True
            evidence.receipt["default_change_started_utc"] = utc()
            evidence.write("default-change-intent.json", {
                "started_utc": evidence.receipt["default_change_started_utc"],
                "expected_from": before["repository"]["default_branch"], "to": "main",
                "expected_main": main_sha,
            })
            updated = gh("repos/" + REPOSITORY, REPO_SELECTION,
                         method="PATCH", fields=(("default_branch", "main"),))
            require(updated.get("default_branch") == "main",
                    "Default-branch PATCH did not return main")
            evidence.write("default-change-response.json", updated)
        confirmed = repository_state(require_main=True)
        evidence.write("default-change-independent-readback.json", confirmed)
        evidence.receipt["default_main_confirmed_utc"] = utc()
        check_snapshot(evidence, "03-immediately-before-delete", expected, deletes, bare, True)

        evidence.receipt["atomic_delete_attempted"] = True
        evidence.receipt["atomic_delete_started_utc"] = utc()
        evidence.write("atomic-delete-intent.json", {
            "started_utc": evidence.receipt["atomic_delete_started_utc"],
            "targets": deletes, "expected_main": main_sha, "protected_refs": protected,
            "atomic": True, "per_ref_exact_lease": True,
        })
        result = command(push_arguments(bare, deletes, REMOTE, False),
                         "Atomic exact-lease branch deletion", timeout=180, checked=False)
        evidence.receipt["atomic_delete_finished_utc"] = utc()
        evidence.write("atomic-delete-result.json", {
            "returncode": result["returncode"], "diagnostic": result["diagnostic"],
            "target_count": len(deletes), "per_ref_exact_lease": True, "atomic": True,
        })
        # Always obtain post-state after any returned failure or timeout. Never
        # retry based solely on a lost acknowledgement: it may have committed.
        post = snapshot(bare)
        post["issues"] = snapshot_issues(post, retained, deletes, True)
        post["remaining_deletion_targets"] = sorted(set(deletes) & set(post["heads"]))
        evidence.write("04-after-delete.json", post)
        evidence.receipt["observed_main_after"] = post["heads"].get(MAIN)
        evidence.receipt["observed_protected_after"] = {
            name: post["heads"].get(name) for name in sorted(PROTECTED)
        }
        require(result["returncode"] == 0,
                "Delete push did not acknowledge success; post-state recorded, no retry")
        require(not any(post["issues"].values()),
                "Post-delete state differs from exactly main plus six protected refs")
        return "COMPLETE_MAIN_PLUS_SIX_HIA_REFS"


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--plan", required=True)
    parser.add_argument("--expected-main", required=True,
                        help="Full SHA of PR #125's completed merge commit on main")
    parser.add_argument("--expected-candidate", required=True)
    parser.add_argument("--ci-run-id", type=int, required=True, action="append",
                        help="Repeat for exact-candidate Rust PR and Cloud PR success runs")
    parser.add_argument("--evidence-dir", required=True,
                        help="New directory; must not already exist")
    parser.add_argument("--execute", action="store_true",
                        help="Switch default to main then delete all exact planned refs")
    parser.add_argument("--dry-run-push", action="store_true",
                        help="Also probe atomic push support without changing remote refs")
    args = parser.parse_args()
    isolate_subprocess_configuration()
    evidence = None
    try:
        evidence = Evidence(args.evidence_dir, "EXECUTE" if args.execute else "DRY_RUN")
        status = perform(args, evidence)
        evidence.finish(status)
        print(status + "; sanitized evidence: " + str(evidence.directory))
        return 0
    except (Refusal, OSError, ValueError, TypeError, KeyError, KeyboardInterrupt) as error:
        # Never include arbitrary OS/subprocess exceptions or input values.
        reason = str(error) if isinstance(error, Refusal) else type(error).__name__
        if evidence is not None:
            try:
                evidence.finish("STOPPED_REVIEW_EVIDENCE_NO_AUTOMATIC_RETRY", reason)
            except OSError:
                print("Could not complete the local receipt", file=sys.stderr)
        print("STOPPED: " + reason, file=sys.stderr)
        return 2


if __name__ == "__main__":
    sys.exit(main())
