#!/usr/bin/env python3
"""Local-only safety checks. All Git mutations target a temporary bare fixture."""

import argparse
import copy
import json
import os
from pathlib import Path
import subprocess
import tempfile
from types import SimpleNamespace
from unittest.mock import patch

import cleanup_rust_refs as cleanup


def local_git(bare, *args, input_text=None):
    result = subprocess.run(
        ["git", "-c", "user.name=Local safety fixture",
         "-c", "user.email=fixture@example.invalid", "--git-dir=" + str(bare), *args],
        input=input_text, text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
        check=False,
    )
    assert result.returncode == 0, "Local fixture git operation failed"
    return result.stdout.strip()


def fixture_heads(bare):
    output = local_git(bare, "for-each-ref", "--format=%(refname) %(objectname)", "refs/heads")
    return dict(line.split(" ") for line in output.splitlines())


def expect_refusal(callback):
    try:
        callback()
    except cleanup.Refusal:
        return
    raise AssertionError("Expected fail-closed refusal")


def check_ci_gate(candidate):
    """Exercise the real CI gate with selected synthetic GH responses only."""
    rust_id, cloud_id, old_push_id = 43696649514, 43696649526, 43692709541
    old_head = "4767ddc02e627d9c0d68e1e04fe555949a9e9c3b"
    assert candidate != old_head, "The final fixture must exercise the refreshed candidate"
    common = {
        "run_attempt": 1, "repository": cleanup.REPOSITORY,
        "head_sha": candidate,
        "head_branch": cleanup.CANDIDATE.removeprefix("refs/heads/"),
        "status": "completed", "conclusion": "success", "event": "pull_request",
    }
    runs = {
        rust_id: {**common, "id": rust_id, "path": ".github/workflows/ci.yml"},
        cloud_id: {**common, "id": cloud_id, "path": ".github/workflows/cloud-compute.yml"},
        old_push_id: {
            **common, "id": old_push_id, "path": ".github/workflows/cloud-compute.yml",
            "head_sha": old_head, "event": "push",
        },
    }
    jobs = {
        rust_id: [
            {"id": 1, "name": "Rust exact-head validation", "status": "completed",
             "conclusion": "success"},
            {"id": 2, "name": "Rust prospective-merge validation", "status": "completed",
             "conclusion": "success"},
        ],
        cloud_id: [{"id": 3, "name": "offline-tests", "status": "completed",
                    "conclusion": "success"}],
        old_push_id: [{"id": 4, "name": "offline-tests", "status": "completed",
                       "conclusion": "success"}],
    }

    def exercise(ids, changed_runs=None, changed_jobs=None, accepts=False):
        current_runs, current_jobs = copy.deepcopy(runs), copy.deepcopy(jobs)
        if changed_runs:
            current_runs.update(copy.deepcopy(changed_runs))
        if changed_jobs:
            current_jobs.update(copy.deepcopy(changed_jobs))

        def selected_gh(endpoint, selection, method="GET", fields=()):
            assert method == "GET" and not fields, "CI gate must stay read-only"
            prefix = "repos/" + cleanup.REPOSITORY + "/actions/runs/"
            assert endpoint.startswith(prefix), "Unexpected metadata endpoint"
            suffix = endpoint.removeprefix(prefix)
            if "/" not in suffix:
                return copy.deepcopy(current_runs[int(suffix)])
            run_id, tail = suffix.split("/", 1)
            assert tail == "attempts/1/jobs?per_page=100&page=1"
            return copy.deepcopy(current_jobs[int(run_id)])

        with patch.object(cleanup, "gh", side_effect=selected_gh):
            if accepts:
                result = cleanup.ci_state(ids, candidate)
                assert {row["id"] for row in result} == {rust_id, cloud_id}
                assert all(row["head_sha"] == candidate for row in result)
            else:
                expect_refusal(lambda: cleanup.ci_state(ids, candidate))

    checks = []
    exercise([rust_id, cloud_id], accepts=True)
    checks.append("Two exact-candidate PR runs pass with both Rust lanes and Cloud offline-tests")
    exercise([rust_id])
    checks.append("Missing Cloud PR fails even when both Rust lanes pass")
    exercise([cloud_id])
    checks.append("Missing Rust PR fails even when Cloud offline-tests passes")
    for missing in ("Rust exact-head validation", "Rust prospective-merge validation"):
        exercise([rust_id, cloud_id], changed_jobs={
            rust_id: [job for job in jobs[rust_id] if job["name"] != missing],
        })
        checks.append("Missing " + missing + " lane fails")
    exercise([rust_id, cloud_id], changed_jobs={cloud_id: []})
    checks.append("Missing Cloud offline-tests job fails despite a successful run envelope")
    exercise([rust_id, cloud_id], changed_runs={
        cloud_id: {**runs[cloud_id], "head_sha": old_head},
    })
    checks.append("Successful Cloud PR from a non-candidate SHA fails")
    exercise([rust_id, old_push_id])
    checks.append("Historical 4767ddc Cloud push success cannot replace the final Cloud PR")
    exercise([rust_id, cloud_id], changed_runs={
        cloud_id: {**runs[cloud_id], "event": "push"},
    })
    checks.append("Even an exact-candidate Cloud push cannot replace the required Cloud PR")
    return checks


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--plan", required=True)
    parser.add_argument("--report", required=True)
    args = parser.parse_args()
    cleanup.isolate_subprocess_configuration()
    original = json.loads(Path(args.plan).read_text())
    candidate = original["candidate"]["expected_sha"]
    plan, deletes, protected, plan_hash = cleanup.load_plan(args.plan, candidate)
    verification = json.loads(Path(plan["verification_file"]).read_text())
    assert verification == plan["source_custody_verification"]
    checks = []
    checks.append("Exact original 149 ref/SHA fingerprint and candidate-bound verifier PASS")
    checks.extend(check_ci_gate(candidate))
    assert set(deletes).isdisjoint(cleanup.PROTECTED | {cleanup.MAIN})
    assert len(deletes) == 150 and len(protected) == 6

    with tempfile.TemporaryDirectory(prefix="hepta-cleanup-local-fixture-") as tmp:
        directory = Path(tmp)
        server = directory / "server.git"
        client = directory / "empty-client.git"
        for bare in (server, client):
            completed = subprocess.run(
                ["git", "init", "--bare", "--quiet", "--initial-branch=main", str(bare)],
                stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=False,
            )
            assert completed.returncode == 0
        empty_tree = local_git(server, "mktree", input_text="")
        old = local_git(server, "commit-tree", empty_tree, "-m", "fixture initial")
        advanced = local_git(server, "commit-tree", empty_tree, "-p", old,
                             "-m", "fixture concurrent advance")
        targets = {name: old for name in deletes}
        retained = {name: old for name in cleanup.PROTECTED}
        retained[cleanup.MAIN] = advanced
        initial = {**targets, **retained}
        local_git(server, "update-ref", "--stdin", input_text="".join(
            "create " + name + " " + oid + "\n" for name, oid in initial.items()
        ))
        assert len(fixture_heads(server)) == 157

        # Real Git dry-run supports atomic and performs no deletion.
        command = cleanup.push_arguments(client, targets, str(server), True)
        assert "--atomic" in command and "--dry-run" in command
        assert sum(part.startswith("--force-with-lease=") for part in command) == 150
        assert sum(part.startswith(":refs/heads/") for part in command) == 150
        assert not any(part == ":" + name for part in command for name in cleanup.PROTECTED)
        result = cleanup.command(command, "Local fixture atomic dry-run", checked=False)
        assert result["returncode"] == 0 and fixture_heads(server) == initial
        checks.append("Real local atomic dry-run: 150 explicit leases, zero changed refs")

        # A fresh remote update after inventory makes one explicit lease stale.
        raced_ref = sorted(targets)[0]
        local_git(server, "update-ref", raced_ref, advanced, old)
        before_rejected_push = fixture_heads(server)
        result = cleanup.command(
            cleanup.push_arguments(client, targets, str(server), False),
            "Local fixture stale-lease atomic deletion", checked=False,
        )
        assert result["returncode"] != 0
        assert fixture_heads(server) == before_rejected_push
        checks.append("Real local stale lease: all 150 deletions rejected; all 157 refs retained")

        # Repair only the temporary fixture and prove the same command deletes
        # exactly the requested refs without touching the six protected refs.
        local_git(server, "update-ref", raced_ref, old, advanced)
        result = cleanup.command(
            cleanup.push_arguments(client, targets, str(server), False),
            "Local fixture matching-lease atomic deletion", checked=False,
        )
        assert result["returncode"] == 0
        assert fixture_heads(server) == retained
        checks.append("Real local matching leases: exactly 150 removed; main plus six HIA refs unchanged")

        # A caller-controlled cwd repository must not redirect the read side
        # through url.*.insteadOf. Both possible destinations are local fixtures.
        hostile = directory / "caller.git"
        wrong_server = directory / "wrong-server.git"
        for bare in (hostile, wrong_server):
            completed = subprocess.run(
                ["git", "init", "--bare", "--quiet", str(bare)],
                stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=False,
            )
            assert completed.returncode == 0
        local_git(hostile, "config", "url." + str(wrong_server) + ".insteadOf", str(server))
        saved_cwd = Path.cwd()
        try:
            os.chdir(hostile)
            with patch.object(cleanup, "REMOTE", str(server)):
                assert cleanup.remote_heads(client) == retained
        finally:
            os.chdir(saved_cwd)
        checks.append("ls-remote uses the empty bare context and ignores caller repository URL rewrites")

        # A protected ref cannot even enter command construction.
        for protected_name in cleanup.PROTECTED | {cleanup.MAIN}:
            expect_refusal(lambda name=protected_name: cleanup.push_arguments(
                client, {**targets, name: old}, str(server), False,
            ))
        checks.append("All six protected refs and main rejected from deletion argument construction")

        # Ref replacement, missing protected names, and mismatched proof fail
        # before any subprocess call or remote request.
        for index, mutation in enumerate(("protected_target", "changed_original_sha", "wrong_proof")):
            changed = copy.deepcopy(plan)
            if mutation == "protected_target":
                changed["deletion_candidates"][0] = changed["preserved_hia_refs"][0]
            elif mutation == "changed_original_sha":
                changed["deletion_candidates"][0]["expected_sha"] = "1" * 40
            else:
                changed["source_custody_verification"]["revision"] = "1" * 40
            path = directory / ("invalid-plan-" + str(index) + ".json")
            path.write_text(json.dumps(changed))
            expect_refusal(lambda path=path: cleanup.load_plan(path, candidate))
        checks.append("Modified original lease, HIA deletion injection, and stale verifier proof refused")

        # Check PR head/base dependencies independently from deletion targets.
        old_ref = sorted(deletes)[0].removeprefix("refs/heads/")
        rows = [
            {"number": 1, "head": {"ref": old_ref, "repo": cleanup.REPOSITORY},
             "base": {"ref": "main", "repo": cleanup.REPOSITORY}},
            {"number": 121, "head": {"ref": "kept", "repo": cleanup.REPOSITORY},
             "base": {"ref": old_ref, "repo": cleanup.REPOSITORY}},
            {"number": 3, "head": {"ref": old_ref, "repo": "someone/fork"},
             "base": {"ref": "main", "repo": cleanup.REPOSITORY}},
        ]
        blockers = cleanup.pr_dependencies(rows, deletes)
        assert {(row["number"], row["role"]) for row in blockers} == {(1, "head"), (121, "base")}
        checks.append("Same-repo open PR head and HIA PR base block deletion; unrelated fork names do not")

        # Default mode can exercise all read-only gates without invoking gh or
        # GitHub: mocked boundary functions reject any unexpected write command.
        expected_main = "f" * 40
        expected = {**deletes, **protected, cleanup.MAIN: expected_main}
        snap = {"observed_utc": cleanup.utc(), "repository": {
                    "full_name": cleanup.REPOSITORY, "default_branch": cleanup.ORIGINAL_DEFAULT,
                    "admin": True, "archived": False, "disabled": False,
                },
                "open_prs": [], "heads": expected}
        options = SimpleNamespace(
            expected_main=expected_main, expected_candidate=candidate, plan=args.plan,
            ci_run_id=[43696649514, 43696649526], execute=False, dry_run_push=False,
        )
        commands = []

        def no_remote_command(argv, *unused, **kwargs):
            commands.append(argv)
            assert argv[:3] == ["git", "init", "--bare"], "Unexpected mutation or remote command"
            return {"returncode": 0, "stdout": "", "diagnostic": None}

        with patch.object(cleanup, "merged_pr", return_value={"merged": True}), \
                patch.object(cleanup, "candidate_ancestry", return_value={"behind_by": 0}), \
                patch.object(cleanup, "ci_state", return_value=[]), \
                patch.object(cleanup, "snapshot", return_value=snap), \
                patch.object(cleanup, "command", side_effect=no_remote_command), \
                patch.object(cleanup, "gh", side_effect=AssertionError("Unexpected gh call")):
            evidence = cleanup.Evidence(directory / "dry-run-evidence", "DRY_RUN")
            status = cleanup.perform(options, evidence)
            evidence.finish(status)
            assert status == "DRY_RUN_READY_NO_REMOTE_MUTATIONS"
            assert not evidence.receipt["default_change_attempted"]
            assert not evidence.receipt["atomic_delete_attempted"]
        checks.append("Default perform path: no PATCH, no push, no mutation after successful read gates")

        drift = copy.deepcopy(snap)
        drift["heads"][next(iter(protected))] = "1" * 40
        assert cleanup.snapshot_issues(drift, expected, deletes)["changed_refs"]
        drift = copy.deepcopy(snap)
        drift["heads"]["refs/heads/new-concurrent-branch"] = "1" * 40
        assert cleanup.snapshot_issues(drift, expected, deletes)["unknown_refs"]
        checks.append("Concurrent protected tip advance and unknown new ref are detected, never selected for deletion")

    report = {
        "schema": "hepta.cleanup-local-fixture-check.v1",
        "finished_utc": cleanup.utc(),
        "status": "PASS",
        "checked_plan_sha256": plan_hash,
        "checked_script_sha256": cleanup.hashlib.sha256(Path(cleanup.__file__).read_bytes()).hexdigest(),
        "candidate_sha": candidate,
        "original_rust_refset_sha256": cleanup.ORIGINAL_RUST_FINGERPRINT,
        "checks": checks,
        "count": len(checks),
        "network_calls": 0,
        "real_remote_mutations": 0,
        "scope": "Real Git atomic/lease checks use temporary local bare repositories only; GH gate orchestration is mocked.",
        "ci_gate_scope": "Synthetic selected GH metadata exercises the actual gate; this does not assert that the live CI runs have completed.",
        "required_ci_workflow_events": sorted(cleanup.CI_REQUIREMENTS),
    }
    with open(args.report, "x", encoding="utf-8") as stream:
        json.dump(report, stream, indent=2)
        stream.write("\n")
    print(json.dumps({"status": "PASS", "checks": len(checks), "network_calls": 0,
                      "real_remote_mutations": 0, "report": args.report}))


if __name__ == "__main__":
    main()
