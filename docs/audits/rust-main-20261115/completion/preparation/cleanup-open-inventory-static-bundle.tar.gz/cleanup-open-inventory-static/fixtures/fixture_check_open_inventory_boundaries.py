#!/usr/bin/env python3
"""Local-only open-inventory gate checks; every GitHub call is synthetic."""
import argparse
import copy
import hashlib
import json
from pathlib import Path
from unittest.mock import patch

import cleanup_rust_refs_open_inventory as cleanup


ENDPOINT = ("repos/" + cleanup.REPOSITORY
            + "/pulls?state=open&sort=created&direction=asc&per_page=100&page=1")
DELETED_REF = "ops/rog-smu-ab-20261002"


def row(number, head=None, head_repo=None, base="main", base_repo=None):
    return {
        "number": number, "state": "open",
        "head": {"ref": head or "unrelated-" + str(number), "sha": "1" * 40,
                 "repo": head_repo or cleanup.REPOSITORY},
        "base": {"ref": base, "sha": "2" * 40,
                 "repo": base_repo or cleanup.REPOSITORY},
    }


def read_fixture(value, refuses=False):
    calls = []

    def selected_gh(endpoint, selection, method="GET", fields=()):
        calls.append(endpoint)
        assert endpoint == ENDPOINT
        assert method == "GET" and not fields
        assert "number,state" in selection and "head:" in selection and "base:" in selection
        return copy.deepcopy(value)

    with patch.object(cleanup, "gh", side_effect=selected_gh), \
            patch.object(cleanup, "command", side_effect=AssertionError("Unexpected subprocess")):
        if refuses:
            try:
                cleanup.open_pull_requests()
            except cleanup.Refusal:
                result = None
            else:
                raise AssertionError("Expected refusal, not an incomplete inventory")
        else:
            result = cleanup.open_pull_requests()
    assert calls == [ENDPOINT], "The gate must use one complete page without retries"
    return result


def complete_99_preserves_late_dependency():
    rows = [row(n) for n in range(1, 100)]
    rows[-1]["head"]["ref"] = DELETED_REF
    observed = read_fixture(rows)
    assert observed == rows and len(observed) == 99
    blockers = cleanup.pr_dependencies(observed, {"refs/heads/" + DELETED_REF: "3" * 40})
    assert [(b["number"], b["role"]) for b in blockers] == [(99, "head")]


def full_page_and_wrong_shape_refuse():
    read_fixture([row(n) for n in range(1, 101)], refuses=True)
    read_fixture({"items": [row(1)]}, refuses=True)


def closed_row_is_not_silently_filtered():
    rows = [row(1), row(2)]
    rows[1]["state"] = "closed"
    read_fixture(rows, refuses=True)


def foreign_base_refuses():
    read_fixture([row(1, base_repo="someone/other-repository")], refuses=True)


def duplicate_number_refuses():
    read_fixture([row(1), row(1, head="another-head")], refuses=True)


def full_identity_dependency_policy_is_preserved():
    rows = [
        row(1, head=DELETED_REF),
        row(121, head="codex/hia-runtime-native-20261114-bd947b55", base=DELETED_REF),
        row(3, head=DELETED_REF, head_repo="someone/fork"),
        row(4, head=DELETED_REF),
    ]
    rows[3]["head"]["repo"] = None
    observed = read_fixture(rows)
    assert observed == rows
    blockers = cleanup.pr_dependencies(observed, {"refs/heads/" + DELETED_REF: "3" * 40})
    assert {(b["number"], b["role"]) for b in blockers} == {
        (1, "head"), (121, "base"), (4, "head"),
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--report", required=True)
    args = parser.parse_args()
    source_path = Path(cleanup.__file__)
    before = hashlib.sha256(source_path.read_bytes()).hexdigest()
    cases = [
        ("99 open PRs are complete and a dependency in the last row blocks deletion",
         complete_99_preserves_late_dependency),
        ("100-row page and non-list metadata refuse instead of accepting a partial inventory",
         full_page_and_wrong_shape_refuse),
        ("A closed row in the open endpoint is refused instead of filtered away",
         closed_row_is_not_silently_filtered),
        ("A foreign base repository is refused", foreign_base_refuses),
        ("Duplicate PR numbers are refused", duplicate_number_refuses),
        ("Complete head/base custody still blocks same-repo and ambiguous dependencies while excluding unrelated fork names",
         full_identity_dependency_policy_is_preserved),
    ]
    results = []
    for name, callback in cases:
        try:
            callback()
            results.append({"name": name, "status": "PASS"})
        except Exception as error:
            results.append({"name": name, "status": "FAIL", "error": str(error)})
    after = hashlib.sha256(source_path.read_bytes()).hexdigest()
    assert before == after
    failed = sum(r["status"] == "FAIL" for r in results)
    report = {
        "schema": "hepta.cleanup-open-inventory-boundary-fixtures.v1",
        "finished_utc": cleanup.utc(), "status": "FAIL" if failed else "PASS",
        "script": str(source_path), "checked_script_sha256": before,
        "fixture_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        "checks": results, "passed": len(results) - failed, "failed": failed,
        "network_calls": 0, "real_remote_mutations": 0, "subprocess_calls": 0,
        "scope": "Actual open_pull_requests and pr_dependencies functions with synthetic GET metadata; no remote API or Git operation.",
        "closed_93_scope": "These fixtures do not replace independent verification that the fixed93 historical PRs are closed.",
    }
    with open(args.report, "x", encoding="utf-8") as stream:
        json.dump(report, stream, indent=2)
        stream.write("\n")
    print(json.dumps({"status": report["status"], "passed": report["passed"],
                      "failed": failed, "report": args.report}))
    if failed:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
