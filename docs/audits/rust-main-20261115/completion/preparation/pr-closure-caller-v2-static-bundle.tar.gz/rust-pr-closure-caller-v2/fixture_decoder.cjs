// Pure local decoder tests using captured real GET envelopes; never invokes a tool.
const fs=require('node:fs');
const path=require('node:path');
const vm=require('node:vm');
const crypto=require('node:crypto');
const assert=require('node:assert/strict');
const dir=__dirname;
const source=fs.readFileSync(path.join(dir,'reviewed-inputs/close_rust_pr_batch.js'),'utf8');
const start=source.indexOf('  function decode(value) {');
const end=source.indexOf('  async function get(path) {');
assert(start>=0&&end>start);
const decode=vm.runInThisContext('(function(){const require=(condition,message)=>{if(!condition)throw new Error(message);};'+source.slice(start,end)+'return decode;})()');
const prPath=path.join(path.dirname(dir),'rust-pr-closure-wrapper-diagnostic-20261115/actual-pr125-tool-wrapper.json');
const mainPath=path.join(path.dirname(dir),'independent-postmerge-security-20261115/github-fetch-main-envelope-observed.json');
const captured=JSON.parse(fs.readFileSync(prPath,'utf8'));
const pr=JSON.parse(captured.structuredContent.content);
const results=[];
function test(name,fn){try{fn();results.push({name,status:'PASS'});}catch(e){results.push({name,status:'FAIL',error:String(e)});process.exitCode=1;}}
test('actual PR125 envelope resolves to exactly its original REST JSON',()=>{
  assert.deepEqual(decode(captured),pr);assert.equal(pr.number,125);assert.equal(pr.merged,true);
  assert.equal(pr.merge_commit_sha,'737acf6f901e46c57b0b4374e323e0d1132e0d49');
  assert.equal(pr.head.sha,'e425d92b6a0dedf13eb3e484e76419ee756804c0');
});
test('independent reviewer captured main GET resolves exactly',()=>{
  const raw=JSON.parse(fs.readFileSync(mainPath,'utf8'));
  const actual=decode(raw);assert.equal(actual.ref,'refs/heads/main');
  assert.equal(actual.object.sha,'737acf6f901e46c57b0b4374e323e0d1132e0d49');
});
test('raw JSON string remains accepted',()=>assert.deepEqual(decode(JSON.stringify(pr)),pr));
test('content JSON string remains accepted',()=>assert.deepEqual(decode({content:JSON.stringify(pr)}),pr));
test('JSON text block remains accepted',()=>assert.deepEqual(decode({content:[{type:'text',text:JSON.stringify(pr)}]}),pr));
test('structured direct object wins over generic display acknowledgment',()=>assert.deepEqual(decode({content:[{type:'text',text:'Action completed.'}],structuredContent:pr}),pr));
test('structured nested content JSON remains accepted',()=>assert.deepEqual(decode({structuredContent:{structuredContent:{content:JSON.stringify(pr)}}}),pr));
test('known acknowledgment before a valid JSON text block is skipped',()=>assert.deepEqual(decode({content:[{type:'text',text:'Action completed.'},{type:'text',text:JSON.stringify(pr)}]}),pr));
test('acknowledgment alone is rejected',()=>assert.throws(()=>decode({content:[{type:'text',text:'Action completed.'}]}),/no JSON payload/));
test('unknown non-JSON display text is rejected',()=>assert.throws(()=>decode({content:[{type:'text',text:'other unknown banner'}]})));
test('malformed structured JSON does not fall through to otherwise-valid content',()=>assert.throws(()=>decode({structuredContent:{content:'invalid JSON'},content:JSON.stringify(pr)})));
test('outer isError cannot be hidden by a valid structured payload',()=>assert.throws(()=>decode({isError:true,structuredContent:pr}),/failed operation/));
test('nested isError cannot be hidden by a valid content payload',()=>assert.throws(()=>decode({structuredContent:{isError:true,content:JSON.stringify(pr)}}),/failed operation/));
const hash=p=>crypto.createHash('sha256').update(fs.readFileSync(p)).digest('hex');
const report={schema:'hepta.pr-closure-decoder-fixtures.v2',sampled_utc:new Date().toISOString(),
  executor_sha256:crypto.createHash('sha256').update(source).digest('hex'),
  actual_pr125_envelope:{path:prPath,sha256:hash(prPath)},actual_main_envelope:{path:mainPath,sha256:hash(mainPath)},
  tests:results,passed:results.filter(r=>r.status==='PASS').length,failed:results.filter(r=>r.status==='FAIL').length,
  network_calls:0,remote_mutations:0};
fs.writeFileSync(path.join(dir,'decoder-fixture-results.json'),JSON.stringify(report,null,2)+'\n');
console.log(JSON.stringify(report));
