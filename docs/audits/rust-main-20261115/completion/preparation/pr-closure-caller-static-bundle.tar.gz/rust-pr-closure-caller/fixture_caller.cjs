// Local fixtures only. GitHub methods below are synthetic in-memory functions.
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const crypto = require('node:crypto');
const { spawnSync } = require('node:child_process');
const assert = require('node:assert/strict');
const dir = __dirname;
const workspace = path.dirname(dir);
const helper = path.join(dir, 'closure_journal.py');
const callerPath = path.join(dir, 'run_rust_pr_closure.js');
const identityPath = path.join(workspace, 'rust-close-refresh-e425-20261115/pr-close-exact-identities.json');
const rows = JSON.parse(fs.readFileSync(identityPath, 'utf8'));
const source = fs.readFileSync(callerPath, 'utf8');
const helperSha = crypto.createHash('sha256').update(fs.readFileSync(helper)).digest('hex');
const callerSha = crypto.createHash('sha256').update(source).digest('hex');
const run = vm.runInThisContext(source, {filename: callerPath});
const candidate = 'e425d92b6a0dedf13eb3e484e76419ee756804c0';
const tree = '76652098f4b5bcad487071f2eaefd82d7fed219c';
const base = 'ba574f2a6a1b74e85191c58d7bec011720736bb9';
const main = 'aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa';
const repo = 'TrillionniumFoundation/hepta-runtime';
const go = 'CLOSE_REVIEWED_RUST_PRS_AFTER_MAIN_MERGE';
const proof = {type:'root-final-main-merge-proof',root_authorized_closure:true,
  authorized_at_utc:'2099-01-01T00:00:00Z',repository:repo,candidate_sha:candidate,
  tree_sha:tree,main_sha:main,fixture_only:true};
const fixtures = fs.mkdtempSync(path.join(dir, 'fixture-journals-'));
const pythonAdapter = `
import importlib.util,json,pathlib,sys
spec=importlib.util.spec_from_file_location('journal_fixture',sys.argv[1])
module=importlib.util.module_from_spec(spec); spec.loader.exec_module(module)
try:
 answer=module.handle(sys.argv[2],json.load(sys.stdin),pathlib.Path(sys.argv[3]))
 print(json.dumps({'ok':True,'result':answer}))
except Exception as error:
 print(json.dumps({'ok':False,'error':str(error)})); sys.exit(1)
`;
function localRaw(command,payload,journal) {
  const result = spawnSync('python3',['-I','-B','-c',pythonAdapter,helper,command,journal],
    {input:JSON.stringify(payload),encoding:'utf8',maxBuffer:1024*1024});
  assert.equal(result.error,undefined);
  return {exit_code:result.status,output:result.stdout,session_id:undefined};
}
function local(command,payload,journal) {
  const r=localRaw(command,payload,journal);
  assert.equal(r.exit_code,0,r.output);
  return JSON.parse(r.output).result;
}
function pr(row,state='open') {
  return {number:row.number,state,draft:row.expected_draft,merged:false,merged_at:null,
    merge_commit_sha:null,updated_at:'2099-01-01T00:00:01Z',
    head:{...row.head,repo:{full_name:row.head.repo}},base:{...row.base,repo:{full_name:row.base.repo}}};
}
function setup(name,fault=null) {
  const journal=path.join(fixtures,name);
  const stats={reads:0,mutations:[],local:0};
  const state=new Map(rows.map(row=>[row.number,pr(row)]));
  let faultUsed=false;
  const fakeTools={
    exec_command:async ({cmd})=>{
      stats.local++;
      assert(cmd.includes("'"+helperSha+"'"),'Caller did not pin actual helper bytes');
      const match=cmd.match(/'(inspect|bundle|begin|persist|complete|stop)' <<'HEPTA_CLOSURE_PAYLOAD'\n([^\n]*)\nHEPTA_CLOSURE_PAYLOAD$/);
      assert(match,'Unexpected shell transport shape');
      const command=match[1],payload=JSON.parse(match[2]);
      const output=localRaw(command,payload,journal);
      if(!faultUsed && fault==='intent_ack_lost' && command==='persist' && payload.name.endsWith('-close-intent.json')) {
        faultUsed=true; return {exit_code:1,output:'synthetic lost local acknowledgment'};
      }
      if(!faultUsed && fault==='complete_ack_lost' && command==='complete' && output.exit_code===0) {
        faultUsed=true; throw new Error('synthetic completed-batch acknowledgment lost');
      }
      return output;
    },
    mcp__codex_apps__github_fetch:async ({url})=>{
      stats.reads++;
      let value;
      if(url.endsWith('/pulls/125')) value={number:125,state:'closed',merged:true,merged_at:'2099-01-01T00:00:00Z',
        merge_commit_sha:main,draft:false,head:{ref:'consolidate/rust-main-20261115',sha:candidate,repo:{full_name:repo}},
        base:{ref:'main',sha:base,repo:{full_name:repo}}};
      else if(url.endsWith('/git/ref/heads/main')) value={ref:'refs/heads/main',object:{sha:main}};
      else if(url.endsWith('/git/commits/'+main)) value={sha:main,tree:{sha:tree},parents:[{sha:base},{sha:candidate}]};
      else {
        const match=url.match(/\/pulls\/(\d+)$/); assert(match,'Unexpected GitHub GET');
        const number=Number(match[1]); assert(state.has(number),'Protected or out-of-scope GET');
        if(fault==='post_read_lost' && stats.mutations.includes(number)) throw new Error('synthetic post-read failure');
        value=structuredClone(state.get(number));
        if(fault==='head_moved' && number===rows[0].number) value.head.sha='bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb';
      }
      return {content:JSON.stringify(value)};
    },
    mcp__codex_apps__github_update_pull_request:async args=>{
      assert.deepEqual(Object.keys(args).sort(),['pr_number','repository_full_name','state']);
      assert.equal(args.repository_full_name,repo); assert.equal(args.state,'closed');
      assert(state.has(args.pr_number)); assert(![121,122,124,125].includes(args.pr_number));
      assert(!stats.mutations.includes(args.pr_number),'Automatic duplicate PR mutation');
      const index=rows.findIndex(row=>row.number===args.pr_number),start=index-index%5;
      const intent=path.join(journal,`batch-${String(start).padStart(3,'0')}`,`pr-${args.pr_number}-close-intent.json`);
      assert.equal(fs.statSync(intent).mode & 0o777,0o600);
      assert.deepEqual(JSON.parse(fs.readFileSync(intent,'utf8')).mutation,{state:'closed'});
      stats.mutations.push(args.pr_number); state.get(args.pr_number).state='closed';
      if(fault==='update_ack_lost') throw new Error('synthetic GitHub acknowledgment lost');
      return {state:'closed'};
    }
  };
  return {journal,stats,state,tools:fakeTools,invoke:extra=>run({tools:fakeTools,execute:true,rootGo:go,proof,...extra})};
}
const results=[];
async function test(name,fn) {
  try {await fn(); results.push({name,status:'PASS'});}
  catch(error){results.push({name,status:'FAIL',error:String(error.stack||error)});throw error;}
}
(async()=>{
  await test('default performs no GitHub calls and creates no journal',async()=>{
    const s=setup('default');const r=await run({tools:s.tools});
    assert.equal(r.status,'PREPARED_LOCAL_INSPECTION_ONLY');assert.equal(s.stats.reads,0);assert.equal(s.stats.mutations.length,0);
    assert(!fs.existsSync(s.journal));
  });
  await test('separate root go and final proof are both mandatory before local allocation',async()=>{
    const s=setup('blocked');await assert.rejects(s.invoke({rootGo:null}));await assert.rejects(s.invoke({proof:null}));
    assert.equal(s.stats.local,0);assert.equal(s.stats.reads,0);assert(!fs.existsSync(s.journal));
  });
  await test('all 93 close once in 18 five-item batches and a final three-item batch; subsequent call has no remote activity',async()=>{
    const s=setup('full');
    for(let index=0;index<93;index+=5){const before=s.stats.mutations.length;const r=await s.invoke();
      assert.equal(r.start,index);assert.equal(r.next_start,Math.min(93,index+5));
      assert.equal(s.stats.mutations.length-before,Math.min(5,93-index));}
    assert.deepEqual(s.stats.mutations,rows.map(r=>r.number));
    const reads=s.stats.reads;assert.equal((await s.invoke()).status,'ALL_93_VERIFIED_CLOSED');assert.equal(s.stats.reads,reads);
    assert.equal(JSON.parse(fs.readFileSync(path.join(s.journal,'batch-090/pr-120-outcome.json'),'utf8')).retained_head_ref,true);
  });
  await test('matching already-closed PR is recorded without mutation',async()=>{
    const s=setup('already');s.state.get(2).state='closed';await s.invoke();assert(!s.stats.mutations.includes(2));
    assert.equal(s.stats.mutations.length,4);
  });
  for(const fault of ['update_ack_lost','post_read_lost','intent_ack_lost','head_moved']) {
    await test(fault+' stops immediately and a new invocation cannot retry or continue',async()=>{
      const s=setup(fault,fault);await assert.rejects(s.invoke());
      const mutations=s.stats.mutations.length,reads=s.stats.reads;
      assert.equal(mutations,['update_ack_lost','post_read_lost'].includes(fault)?1:0);
      await assert.rejects(s.invoke());assert.equal(s.stats.mutations.length,mutations);assert.equal(s.stats.reads,reads);
      assert.equal(local('inspect',{},s.journal).status,'STOP_REVIEW_NO_RETRY');
    });
  }
  await test('a crash after durable allocation blocks concurrent or restarted execution without a GitHub call',async()=>{
    const s=setup('crash');local('begin',{proof,explicit_root_go:go},s.journal);
    await assert.rejects(s.invoke());assert.equal(s.stats.reads,0);assert.equal(s.stats.mutations.length,0);
  });
  await test('two simultaneous callers allocate only one active batch',async()=>{
    const s=setup('concurrent');const r=await Promise.allSettled([s.invoke(),s.invoke()]);
    assert.equal(r.filter(x=>x.status==='fulfilled').length,1);assert.equal(s.stats.mutations.length,5);
  });
  await test('lost completed-batch acknowledgment resumes from durable next cursor and never repeats its PRs',async()=>{
    const s=setup('complete_ack','complete_ack_lost');await assert.rejects(s.invoke());assert.equal(s.stats.mutations.length,5);
    const r=await s.invoke();assert.equal(r.start,5);assert.equal(s.stats.mutations.length,10);
  });
  await test('receipts are exclusive and successful result cannot be fabricated without per-item custody',async()=>{
    const s=setup('exclusive');const b=local('begin',{proof,explicit_root_go:go},s.journal);
    const p={start:b.start,token:b.token,name:'batch-0-root-proof.json',value:{proof,selected:rows.slice(0,5)}};
    local('persist',p,s.journal);assert.equal(localRaw('persist',{...p,value:{changed:true}},s.journal).exit_code,1);
    assert.equal(localRaw('complete',{start:b.start,token:b.token,result:{status:'BATCH_COMPLETE'}},s.journal).exit_code,1);
    assert.deepEqual(JSON.parse(fs.readFileSync(path.join(s.journal,'batch-000/batch-0-root-proof.json'),'utf8')),p.value);
    assert.equal(local('inspect',{},s.journal).status,'STOP_REVIEW_NO_RETRY');
  });
  await test('corruption of a completed outcome blocks the next batch before a remote call',async()=>{
    const s=setup('corrupted');await s.invoke();fs.writeFileSync(path.join(s.journal,'batch-000/pr-2-outcome.json'),'{}');
    const reads=s.stats.reads;await assert.rejects(s.invoke());assert.equal(s.stats.reads,reads);assert.equal(s.stats.mutations.length,5);
  });
  await test('journal symlink cannot redirect receipt writes',async()=>{
    const s=setup('symlink');const destination=path.join(fixtures,'empty-destination');fs.mkdirSync(destination);fs.symlinkSync(destination,s.journal);
    await assert.rejects(s.invoke());assert.equal(s.stats.reads,0);assert.deepEqual(fs.readdirSync(destination),[]);
  });
  const durability=spawnSync('python3',['-I','-B','-c',`
import importlib.util,os,pathlib,tempfile
spec=importlib.util.spec_from_file_location('j',${JSON.stringify(helper)})
j=importlib.util.module_from_spec(spec);spec.loader.exec_module(j)
with tempfile.TemporaryDirectory() as root:
 fd=os.open(root,j.DIR_FLAGS); events=[]; original=os.fsync
 def tracked(target): events.append(('dir' if target==fd else 'file'));original(target)
 os.fsync=tracked
 try:
  j.write_exclusive(fd,'receipt.json',{'verified':True})
  assert events==['file','dir'],events
  try:j.write_exclusive(fd,'receipt.json',{'overwrite':True})
  except FileExistsError:pass
  else:raise AssertionError('overwrite permitted')
 finally:os.close(fd)
print('PASS')
`],{encoding:'utf8'});
  await test('real persistence fsyncs file before directory and refuses overwriting a receipt',async()=>{
    assert.equal(durability.status,0,durability.stderr);assert.equal(durability.stdout.trim(),'PASS');
  });
})().catch(error=>{process.exitCode=1;console.error(String(error));}).finally(()=>{
  const report={schema:'hepta.pr-closure-caller-fixtures.v1',sampled_utc:new Date().toISOString(),
    candidate_sha:candidate,tree_sha:tree,caller_sha256:callerSha,helper_sha256:helperSha,
    executor_sha256:'50a9079b7089f519e465a68dd10937061146500964d888a919391e45fb42877e',
    fixture_root:fixtures,tests:results,passed:results.filter(r=>r.status==='PASS').length,
    failed:results.filter(r=>r.status==='FAIL').length,real_network_calls:0,real_remote_mutations:0,
    real_operation_journal_created:false};
  fs.writeFileSync(path.join(dir,'caller-fixture-results.json'),JSON.stringify(report,null,2)+'\n');
  console.log(JSON.stringify(report));
});
