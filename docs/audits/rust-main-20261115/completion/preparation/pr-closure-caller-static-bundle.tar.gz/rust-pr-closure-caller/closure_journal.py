#!/usr/bin/env python3
"""Local-only durable journal. No network client, credential lookup, or retry mode."""
import contextlib
import datetime
import fcntl
import hashlib
import json
import os
from pathlib import Path
import re
import secrets
import stat
import sys

HERE = Path(__file__).resolve().parent
WORKSPACE = HERE.parent
ASSETS = WORKSPACE / "rust-close-refresh-e425-20261115"
JOURNAL = WORKSPACE / "rust-pr-closure-receipts-e425"
EXECUTOR_SHA = "50a9079b7089f519e465a68dd10937061146500964d888a919391e45fb42877e"
IDENTITIES_SHA = "7de95f9fb6f72218d87e469f801bfacf5ff9bb8ffd849a88679f1fced3d26b31"
REPOSITORY = "TrillionniumFoundation/hepta-runtime"
CANDIDATE = "e425d92b6a0dedf13eb3e484e76419ee756804c0"
TREE = "76652098f4b5bcad487071f2eaefd82d7fed219c"
BASE = "ba574f2a6a1b74e85191c58d7bec011720736bb9"
GO = "CLOSE_REVIEWED_RUST_PRS_AFTER_MAIN_MERGE"
TOTAL = 93
MAX_BATCH = 5
DIR_FLAGS = os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW


def need(condition, message):
    if not condition:
        raise RuntimeError(message)


def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def encoded(value):
    return (json.dumps(value, ensure_ascii=False, sort_keys=True, indent=2) + "\n").encode()


def assets():
    source = (ASSETS / "close_rust_pr_batch.js").read_bytes()
    identities_bytes = (ASSETS / "pr-close-exact-identities.json").read_bytes()
    need(hashlib.sha256(source).hexdigest() == EXECUTOR_SHA, "Executor hash changed")
    need(hashlib.sha256(identities_bytes).hexdigest() == IDENTITIES_SHA, "93 PR identities changed")
    identities = json.loads(identities_bytes)
    need(len(identities) == TOTAL and len({r["number"] for r in identities}) == TOTAL,
         "Wrong fixed identity set")
    need(not {121, 122, 124, 125} & {r["number"] for r in identities}, "Protected PR in scope")
    return source.decode(), identities


def validate_proof(proof, go):
    need(go == GO, "Separate explicit root go is required")
    need(isinstance(proof, dict) and proof.get("type") == "root-final-main-merge-proof"
         and proof.get("root_authorized_closure") is True
         and isinstance(proof.get("authorized_at_utc"), str) and proof["authorized_at_utc"]
         and proof.get("repository") == REPOSITORY and proof.get("candidate_sha") == CANDIDATE
         and proof.get("tree_sha") == TREE
         and re.fullmatch(r"[0-9a-f]{40}", proof.get("main_sha", ""))
         and proof["main_sha"] not in (BASE, CANDIDATE),
         "Final main merge proof has not been supplied or has the wrong identity")


def read_json(directory_fd, name):
    fd = os.open(name, os.O_RDONLY | os.O_NOFOLLOW, dir_fd=directory_fd)
    try:
        info = os.fstat(fd)
        need(stat.S_ISREG(info.st_mode) and info.st_size <= 8_000_000,
             "Invalid receipt type or size: " + name)
        with os.fdopen(fd, "rb", closefd=False) as stream:
            return json.load(stream)
    finally:
        os.close(fd)


def write_exclusive(directory_fd, name, value):
    need(re.fullmatch(r"[a-z0-9][a-z0-9-]*\.json", name), "Invalid receipt name")
    data = encoded(value)
    need(len(data) <= 8_000_000, "Receipt too large")
    fd = os.open(name, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW,
                 0o600, dir_fd=directory_fd)
    try:
        with os.fdopen(fd, "wb", closefd=False) as stream:
            stream.write(data)
            stream.flush()
            os.fsync(fd)
    finally:
        os.close(fd)
    os.fsync(directory_fd)
    return hashlib.sha256(data).hexdigest()


@contextlib.contextmanager
def directory(path, create=False):
    """Use a fixed sibling of the repository; never follow a journal symlink."""
    if create:
        try:
            os.mkdir(path, 0o700)
        except FileExistsError:
            pass
        else:
            parent = os.open(path.parent, DIR_FLAGS)
            try:
                os.fsync(parent)
            finally:
                os.close(parent)
    fd = os.open(path, DIR_FLAGS)
    try:
        yield fd
    finally:
        os.close(fd)


@contextlib.contextmanager
def lock(root_fd):
    fd = os.open("journal-lock.json", os.O_RDWR | os.O_CREAT | os.O_NOFOLLOW,
                 0o600, dir_fd=root_fd)
    try:
        need(stat.S_ISREG(os.fstat(fd).st_mode), "Journal lock must be a regular file")
        fcntl.flock(fd, fcntl.LOCK_EX)
        os.fsync(fd)
        os.fsync(root_fd)
        yield
    finally:
        os.close(fd)


def metadata_matches(observed, expected):
    return (isinstance(observed, dict) and observed.get("number") == expected["number"]
            and observed.get("draft") == expected["expected_draft"]
            and observed.get("head") == expected["head"]
            and observed.get("base") == expected["base"])


def check_complete(batch_fd, manifest, started, rows, result):
    start = started["start"]
    selected = rows[start:start + MAX_BATCH]
    proof_receipt = read_json(batch_fd, f"batch-{start}-root-proof.json")
    need(proof_receipt.get("proof") == manifest["proof"]
         and proof_receipt.get("selected") == selected, "Batch proof or identity scope changed")
    readback = read_json(batch_fd, f"batch-{start}-merge-readback.json")
    merge = readback.get("pr125", {})
    need(readback.get("main_sha") == manifest["proof"]["main_sha"]
         and readback.get("main_tree") == TREE and readback.get("parents") == [BASE, CANDIDATE]
         and merge.get("number") == 125 and merge.get("state") == "closed"
         and merge.get("merged") is True and merge.get("merged_at")
         and merge.get("merge_commit_sha") == manifest["proof"]["main_sha"]
         and merge.get("head") == {"ref": "consolidate/rust-main-20261115", "sha": CANDIDATE,
                                    "repo": REPOSITORY}
         and merge.get("base", {}).get("ref") == "main"
         and merge.get("base", {}).get("repo") == REPOSITORY,
         "Merge readback does not match the fixed proof")
    outcomes = []
    for expected in selected:
        number = expected["number"]
        before = read_json(batch_fd, f"pr-{number}-before.json")
        outcome = read_json(batch_fd, f"pr-{number}-outcome.json")
        need(before.get("expected") == expected and before.get("identity_issues") == []
             and metadata_matches(before.get("observed"), expected), "PR pre-state mismatch")
        need(outcome.get("number") == number
             and outcome.get("retained_head_ref") == expected["retained_head_ref"]
             and metadata_matches(outcome.get("observed"), expected)
             and outcome["observed"].get("state") == "closed", "PR post-state mismatch")
        kind = outcome.get("outcome")
        if kind == "CLOSED_AND_VERIFIED":
            intent = read_json(batch_fd, f"pr-{number}-close-intent.json")
            need(before["observed"].get("state") == "open" and not before["observed"].get("merged")
                 and intent.get("repository") == REPOSITORY and intent.get("number") == number
                 and intent.get("expected") == expected and intent.get("mutation") == {"state": "closed"}
                 and intent.get("no_branch_mutation") is True
                 and outcome.get("expected") == expected and outcome.get("update_error") is None
                 and outcome.get("post_read_error") is None and outcome.get("identity_issues") == [],
                 "Successful closure lacks matching durable intent or clear outcome")
        elif kind == "ALREADY_CLOSED_VERIFIED":
            need(before["observed"].get("state") == "closed" and outcome["observed"] == before["observed"]
                 and f"pr-{number}-close-intent.json" not in os.listdir(batch_fd),
                 "Already-closed outcome is inconsistent")
        else:
            raise RuntimeError("Uncertain PR outcome permanently blocks automatic continuation")
        outcomes.append(outcome)
    need(result == {"status": "BATCH_COMPLETE", "candidate": CANDIDATE,
                    "main": manifest["proof"]["main_sha"], "start": start,
                    "next_start": start + len(selected), "total_planned": TOTAL,
                    "outcomes": outcomes, "branch_mutations": 0, "protected_pr_mutations": 0},
         "Batch result differs from its exclusive per-item receipts")


def load_manifest(root_fd):
    manifest = read_json(root_fd, "operation.json")
    need(manifest.get("schema") == "hepta.pr-closure-journal.v1"
         and manifest.get("repository") == REPOSITORY and manifest.get("candidate_sha") == CANDIDATE
         and manifest.get("tree_sha") == TREE and manifest.get("executor_sha256") == EXECUTOR_SHA
         and manifest.get("identities_sha256") == IDENTITIES_SHA and manifest.get("total") == TOTAL
         and manifest.get("max_batch") == MAX_BATCH, "Journal binding changed")
    validate_proof(manifest.get("proof"), manifest.get("explicit_root_go"))
    return manifest


def progress_state(root_fd, manifest, rows):
    names = os.listdir(root_fd)
    need(all(n in {"operation.json", "journal-lock.json"} or re.fullmatch(r"batch-[0-9]{3}", n)
             for n in names), "Unexpected journal entry; stop for review")
    batches = sorted(n for n in names if n.startswith("batch-"))
    cursor = 0
    verified = []
    for name in batches:
        need(name == f"batch-{cursor:03d}" and cursor < TOTAL, "Journal has a gap or duplicate batch")
        batch_fd = os.open(name, DIR_FLAGS, dir_fd=root_fd)
        try:
            started = read_json(batch_fd, "started.json")
            need(started.get("start") == cursor and started.get("count") == min(MAX_BATCH, TOTAL - cursor),
                 "Batch scope changed")
            if "stopped.json" in os.listdir(batch_fd) or "complete.json" not in os.listdir(batch_fd):
                return {"status": "STOP_REVIEW_NO_RETRY", "next_start": cursor,
                        "completed_numbers": verified, "blocked_batch": name,
                        "receipts": sorted(os.listdir(batch_fd))}
            completion = read_json(batch_fd, "complete.json")
            check_complete(batch_fd, manifest, started, rows, completion["result"])
            verified.extend(r["number"] for r in rows[cursor:cursor + MAX_BATCH])
            cursor += min(MAX_BATCH, TOTAL - cursor)
        finally:
            os.close(batch_fd)
    return {"status": "ALL_93_VERIFIED_CLOSED" if cursor == TOTAL else "READY_FOR_NEXT_BATCH",
            "next_start": cursor, "completed_numbers": verified}


def active_batch(root_fd, payload):
    start = payload.get("start")
    need(type(start) is int and start in range(0, TOTAL, MAX_BATCH), "Invalid batch start")
    fd = os.open(f"batch-{start:03d}", DIR_FLAGS, dir_fd=root_fd)
    try:
        started = read_json(fd, "started.json")
        need(started.get("token") == payload.get("token") and started.get("start") == start,
             "Wrong batch ownership token")
        return fd, started
    except BaseException:
        os.close(fd)
        raise


def handle(command, payload, journal=JOURNAL):
    source, rows = assets()
    if command == "bundle":
        return {"executor_source": source, "executor_sha256": EXECUTOR_SHA,
                "identities_sha256": IDENTITIES_SHA}
    if command == "inspect" and not os.path.lexists(journal):
        return {"status": "NOT_STARTED", "next_start": 0, "completed_numbers": [],
                "next_numbers": [r["number"] for r in rows[:MAX_BATCH]], "journal": str(journal),
                "candidate_sha": CANDIDATE, "tree_sha": TREE, "total": TOTAL, "max_batch": MAX_BATCH}
    if command == "begin":
        validate_proof(payload.get("proof"), payload.get("explicit_root_go"))
    need(command in {"inspect", "begin", "persist", "complete", "stop"}, "Unknown command")
    # Inspect never creates a journal or a lock. Mutating commands only write local receipts.
    with directory(journal, create=command == "begin") as root_fd:
        manager = contextlib.nullcontext() if command == "inspect" else lock(root_fd)
        with manager:
            if command == "begin" and "operation.json" not in os.listdir(root_fd):
                need(set(os.listdir(root_fd)) == {"journal-lock.json"},
                     "Interrupted journal creation; review rather than reset")
                write_exclusive(root_fd, "operation.json", {
                    "schema": "hepta.pr-closure-journal.v1", "created_utc": now(),
                    "repository": REPOSITORY, "candidate_sha": CANDIDATE, "tree_sha": TREE,
                    "executor_sha256": EXECUTOR_SHA, "identities_sha256": IDENTITIES_SHA,
                    "helper_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                    "total": TOTAL, "max_batch": MAX_BATCH,
                    "proof": payload["proof"], "explicit_root_go": payload["explicit_root_go"]})
            manifest = load_manifest(root_fd)
            if command in {"inspect", "begin"}:
                state = progress_state(root_fd, manifest, rows)
                state.update(journal=str(journal), candidate_sha=CANDIDATE, tree_sha=TREE,
                             main_sha=manifest["proof"]["main_sha"], total=TOTAL, max_batch=MAX_BATCH)
                if command == "inspect":
                    state["next_numbers"] = [r["number"] for r in rows[state["next_start"]:state["next_start"] + MAX_BATCH]]
                    return state
                need(payload["proof"] == manifest["proof"], "Root proof differs from the original operation")
                need(state["status"] != "STOP_REVIEW_NO_RETRY", "Incomplete or stopped batch: automatic resume forbidden")
                if state["next_start"] == TOTAL:
                    return state
                start = state["next_start"]
                name = f"batch-{start:03d}"
                os.mkdir(name, 0o700, dir_fd=root_fd)
                os.fsync(root_fd)
                batch_fd = os.open(name, DIR_FLAGS, dir_fd=root_fd)
                try:
                    started = {"start": start, "count": min(MAX_BATCH, TOTAL - start),
                               "token": secrets.token_hex(24), "started_utc": now(),
                               "selected_numbers": [r["number"] for r in rows[start:start + MAX_BATCH]]}
                    write_exclusive(batch_fd, "started.json", started)
                finally:
                    os.close(batch_fd)
                return {"status": "BATCH_STARTED", **started, "journal": str(journal)}
            batch_fd, started = active_batch(root_fd, payload)
            try:
                names = os.listdir(batch_fd)
                if command == "stop" and "complete.json" in names:
                    return {"status": "BATCH_ALREADY_DURABLY_COMPLETE", "start": started["start"]}
                need("complete.json" not in names, "Completed batch is immutable")
                if command == "stop":
                    if "stopped.json" not in names:
                        write_exclusive(batch_fd, "stopped.json", {
                            "status": "STOP_REVIEW_NO_RETRY", "stopped_utc": now(),
                            "error": str(payload.get("error", "Unknown caller failure"))[:4000]})
                    return {"status": "STOP_REVIEW_NO_RETRY", "start": started["start"]}
                need("stopped.json" not in names, "Stopped batch cannot be resumed")
                if command == "persist":
                    start = started["start"]
                    allowed = {f"batch-{start}-root-proof.json", f"batch-{start}-merge-readback.json"}
                    for row in rows[start:start + MAX_BATCH]:
                        allowed.update(f"pr-{row['number']}-{suffix}.json"
                                       for suffix in ("before", "close-intent", "outcome"))
                    need(payload.get("name") in allowed, "Receipt outside the fixed five-PR batch")
                    digest = write_exclusive(batch_fd, payload["name"], payload.get("value"))
                    return {"status": "PERSISTED_AND_FSYNCED", "name": payload["name"], "sha256": digest}
                check_complete(batch_fd, manifest, started, rows, payload.get("result"))
                write_exclusive(batch_fd, "complete.json", {
                    "completed_utc": now(), "result": payload["result"]})
                return {"status": "BATCH_DURABLY_COMPLETE", "start": started["start"],
                        "next_start": payload["result"]["next_start"], "total": TOTAL,
                        "completed_numbers": [r["number"] for r in rows[:payload["result"]["next_start"]]],
                        "journal": str(journal), "candidate_sha": CANDIDATE,
                        "main_sha": manifest["proof"]["main_sha"],
                        "branch_mutations": 0, "protected_pr_mutations": 0}
            finally:
                os.close(batch_fd)


if __name__ == "__main__":
    try:
        need(len(sys.argv) == 2, "Expected one journal command")
        request = json.load(sys.stdin)
        need(isinstance(request, dict), "Expected an object payload")
        answer = handle(sys.argv[1], request)
        print(json.dumps({"ok": True, "result": answer}, ensure_ascii=False))
    except Exception as error:
        print(json.dumps({"ok": False, "error": str(error)}, ensure_ascii=False))
        sys.exit(1)
