/* Prepared caller: evaluates to a function and never invokes itself.
 * Exactly one batch per invocation. Default is local read-only inspection.
 * Only the unchanged reviewed executor can perform GitHub writes.
 */
(async function runPreparedRustPRClosure(options = {}) {
  const { tools, execute = false, rootGo = null, proof = null,
          progress = () => {} } = options;
  const HELPER = "/workspace/scratch/d72683e5e62a/rust-pr-closure-caller/closure_journal.py";
  const HELPER_SHA = "c5f7dacf6f92e230db87b9de388f7f0fdebd878d542b9c975287999f6a820e80";
  const EXECUTOR_SHA = "50a9079b7089f519e465a68dd10937061146500964d888a919391e45fb42877e";
  const IDENTITIES_SHA = "7de95f9fb6f72218d87e469f801bfacf5ff9bb8ffd849a88679f1fced3d26b31";
  const CANDIDATE = "e425d92b6a0dedf13eb3e484e76419ee756804c0";
  const TREE = "76652098f4b5bcad487071f2eaefd82d7fed219c";
  const GO = "CLOSE_REVIEWED_RUST_PRS_AFTER_MAIN_MERGE";
  const require = (condition, message) => { if (!condition) throw new Error(message); };
  const quote = value => "'" + String(value).replace(/'/g, "'\"'\"'") + "'";
  const safeProgress = value => {
    try { progress(value); } catch (_) { /* Notification failure never changes journal truth. */ }
  };
  require(tools && typeof tools.exec_command === "function", "A local exec tool is required");
  require(typeof execute === "boolean", "execute must be an explicit boolean");
  const python = [
    "import hashlib,pathlib,sys",
    "path=pathlib.Path(sys.argv[1]); data=path.read_bytes()",
    "expected=sys.argv[2]; command=sys.argv[3]",
    "if hashlib.sha256(data).hexdigest()!=expected: raise SystemExit('Journal helper hash changed')",
    "sys.argv=[str(path),command]",
    "exec(compile(data,str(path),'exec'),{'__name__':'__main__','__file__':str(path)})"
  ].join("\n");
  async function local(command, payload = {}) {
    require(["inspect", "bundle", "begin", "persist", "complete", "stop"].includes(command),
            "Unsupported journal operation");
    // JSON.stringify produces a single line: embedded newlines are escaped.
    // A quoted heredoc prevents shell expansion; every command argument is quoted separately.
    const body = JSON.stringify(payload);
    require(!body.includes("\n"), "Journal payload must remain one JSON line");
    const cmd = "python3 -I -B -c " + quote(python) + " " + quote(HELPER) + " "
      + quote(HELPER_SHA) + " " + quote(command)
      + " <<'HEPTA_CLOSURE_PAYLOAD'\n" + body + "\nHEPTA_CLOSURE_PAYLOAD";
    const reply = await tools.exec_command({
      cmd, workdir: "/workspace/scratch/d72683e5e62a", login: false,
      max_output_tokens: command === "bundle" ? 30000 : 4000, yield_time_ms: 10000
    });
    require(reply && reply.exit_code === 0 && !reply.session_id,
            "Local journal did not acknowledge completion: " + String(reply?.output || "").slice(0, 2000));
    let parsed;
    try { parsed = JSON.parse(reply.output); }
    catch (_) { throw new Error("Journal output was incomplete or invalid; stop without retry"); }
    require(parsed.ok === true, "Local journal rejected the operation: " + String(parsed.error || ""));
    return parsed.result;
  }

  if (!execute) {
    return { status: "PREPARED_LOCAL_INSPECTION_ONLY", remote_reads: 0, remote_mutations: 0,
             candidate: CANDIDATE, tree: TREE, root_merge_proof_and_explicit_go_required: true,
             journal: await local("inspect") };
  }
  require(rootGo === GO, "Blocked: root has not supplied separate explicit closure go");
  require(proof && proof.type === "root-final-main-merge-proof"
          && proof.root_authorized_closure === true
          && typeof proof.authorized_at_utc === "string" && proof.authorized_at_utc.length > 0
          && proof.repository === "TrillionniumFoundation/hepta-runtime"
          && proof.candidate_sha === CANDIDATE && proof.tree_sha === TREE
          && /^[0-9a-f]{40}$/.test(proof.main_sha || ""),
          "Blocked: final main merge proof is missing or bound to another candidate");
  require(typeof tools.mcp__codex_apps__github_fetch === "function"
          && typeof tools.mcp__codex_apps__github_update_pull_request === "function",
          "Required GitHub connector operations are unavailable");
  const bundle = await local("bundle");
  require(bundle.executor_sha256 === EXECUTOR_SHA && bundle.identities_sha256 === IDENTITIES_SHA,
          "Reviewed executor or exact 93 identities changed");
  const executor = (0, eval)(bundle.executor_source);
  require(typeof executor === "function", "Executor source is not a function");
  const batch = await local("begin", { proof, explicit_root_go: rootGo });
  if (batch.status === "ALL_93_VERIFIED_CLOSED") {
    return { status: batch.status, journal: batch, remote_reads: 0, remote_mutations: 0 };
  }
  require(batch.status === "BATCH_STARTED" && Number.isInteger(batch.start)
          && batch.start >= 0 && batch.start < 93 && batch.start % 5 === 0
          && batch.count === Math.min(5, 93 - batch.start), "Invalid durable batch allocation");
  const identity = { start: batch.start, token: batch.token };
  safeProgress({ status: "BATCH_STARTED", start: batch.start, numbers: batch.selected_numbers });
  try {
    const result = await executor({ tools, proof, execute: true,
      start: batch.start, count: batch.count,
      persist: async (name, value) => {
        const receipt = await local("persist", { ...identity, name, value });
        require(receipt.status === "PERSISTED_AND_FSYNCED" && receipt.name === name,
                "Receipt persistence was not confirmed");
      },
      progress: safeProgress
    });
    const completion = await local("complete", { ...identity, result });
    require(completion.status === "BATCH_DURABLY_COMPLETE", "Batch completion was not confirmed");
    safeProgress(completion);
    return completion;
  } catch (error) {
    let stopReceipt;
    try { stopReceipt = await local("stop", { ...identity, error: String(error).slice(0, 4000) }); }
    catch (journalError) {
      stopReceipt = { status: "STOP_RECORD_FAILED_ACTIVE_BATCH_STILL_BLOCKS",
                      error: String(journalError).slice(0, 2000) };
    }
    safeProgress({ status: "STOP_REVIEW_NO_RETRY", start: batch.start, stopReceipt });
    throw new Error("Closure batch stopped; do not reattempt uncertain PRs. "
                    + String(error).slice(0, 4000) + " Journal: " + JSON.stringify(stopReceipt));
  }
})
