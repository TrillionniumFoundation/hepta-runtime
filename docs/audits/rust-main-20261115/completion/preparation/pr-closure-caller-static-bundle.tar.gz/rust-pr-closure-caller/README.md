# Prepared durable caller for the 93 reviewed Rust PRs

This is a local operational artifact. No real PR has been closed by this caller, and no final main merge proof or execution go has been received. The fixed candidate is `e425d92b6a0dedf13eb3e484e76419ee756804c0`, with tree `76652098f4b5bcad487071f2eaefd82d7fed219c`.

`run_rust_pr_closure.js` evaluates to a function. It does not invoke itself. It calls the already reviewed, unchanged `close_rust_pr_batch.js` and supplies the real local persistence callback that executor requires. The default invocation only inspects local progress. It performs no GitHub reads or writes and does not create the operation journal.

## Invocation through functions.exec

Load the caller from its absolute path and verify the caller SHA256 from `prepared-manifest.json` before evaluating its bytes. With the resulting function bound as `run`, the read-only preparation call is:

```javascript
const status = await run({ tools });
text(status);
```

Only after root supplies the actual final main merge proof and an explicit go, invoke **one** batch:

```javascript
const result = await run({
  tools,
  execute: true,
  rootGo: "CLOSE_REVIEWED_RUST_PRS_AFTER_MAIN_MERGE",
  proof: actualRootFinalMainMergeProof,
  progress: event => notify(event)
});
text(result);
```

`actualRootFinalMainMergeProof` must come from root's observed final merge and authorization. Do not construct it from the candidate alone or substitute fixture proof values. It has the fields required by the unchanged executor: `type`, `root_authorized_closure`, `authorized_at_utc`, `repository`, `candidate_sha`, `tree_sha`, and `main_sha`. The helper additionally rejects a main SHA equal to the old base or candidate. Every batch directly rechecks PR125, main's ref and commit, exact audited tree, and the ordered parents `[ba574f2a6a1b74e85191c58d7bec011720736bb9, e425d92b6a0dedf13eb3e484e76419ee756804c0]`.

There is no start-index or batch-size override. The caller obtains the next cursor from validated durable completion receipts and allocates exactly five items, or the final remaining three. Call it again explicitly to proceed with the next batch; it never loops through all 93 in one invocation. The Python helper is hash-pinned before its verified bytes are executed, and it hash-checks the unchanged executor and exact identity file on every operation.

## Durability and stopping behavior

The real journal path is fixed at `/workspace/scratch/d72683e5e62a/rust-pr-closure-receipts-e425`. The preparation process does not create it. Each receipt is a mode0600 regular file created with `O_CREAT|O_EXCL|O_NOFOLLOW`, then flushed and fsynced, followed by an fsync of its directory. Batch directories are also created exclusively and their parent is fsynced. A local file lock serializes journal commands; a persistent batch allocation prevents simultaneous callers from starting another batch while one is active.

Each PR has independent pre-state, close intent if needed, and post-state/outcome receipts. The executor cannot issue a close before its intent persist call succeeds. A batch is marked complete only when its returned result exactly matches the stored per-item evidence and merge readback. On each later invocation, every prior complete batch is revalidated before the next cursor is allocated.

Complete acknowledged batches can resume at the next batch. If the caller loses the final local acknowledgment after the completion marker was durably written, the next invocation validates that marker and advances; it does not repeat those PRs. Any incomplete batch, uncertain update acknowledgment, failed post-read, mismatching identity, failed persistence, or explicit stopped record blocks automatic continuation. There is no reset, force, skip, or retry command. A crash before an outcome is saved leaves the active allocation in place even if no stop record could be written. Root must inspect and reconcile that situation outside this automated path before authorizing any revised procedure. Do not delete or rename the journal to bypass a stop.

The catch-path status `BATCH_ALREADY_DURABLY_COMPLETE` only reports that a completion file exists; it is not an independent success proof. The caller still throws the original error. A later normal invocation must parse and fully validate that completion and every corresponding receipt before it can advance. A truncated or corrupted completion therefore blocks continuation.

The `progress` callback is for notifications only. Durable receipts decide progress. If notification delivery throws synchronously, closure evidence remains intact. Filesystem errors do not grant permission to continue.

## Scope and limits

The 93 identities and executor are unchanged. Only `state=closed` is submitted. PR121, PR122, PR124 and PR125 cannot enter this closure set. PR120 may close while its protected head remains untouched. This caller has no branch mutation, default-branch update, retarget, title, body or comment operation.

The GitHub PR update API has no expected-head compare-and-swap. Direct pre- and post-reads detect changes but cannot eliminate the interval between GET and PATCH. A changed or uncertain result stops immediately and is retained for review; no automatic second PATCH is attempted.

The journal lives in the shared workspace. File and directory fsync protect against process crashes on this filesystem; they are not a substitute for preserving operation receipts outside a transient workspace at the end of the task. The files are intentionally separate from the repository being consolidated.

`POST_CLOSURE_REFRESH.json` lists the exact fields to refresh after all 93 closures are observed. It keeps the reviewed149 original ref/SHA leases plus the owned candidate, the six protected names, and the candidate-bound source proof unchanged. A separate proof for merged main is added rather than replacing the candidate proof expected by the cleanup script. Fresh full PR/ref snapshots, all93 closed identities, HIA dependencies, current default, and both exact-e425 PR CI runs remain required before the independent branch cleanup step.

## Local verification

`fixture_caller.cjs` uses synthetic GitHub functions and real local persistence in isolated temporary fixture directories. It covers all93 batching, already-closed PRs, update/post-read/intent-ack failures, crashes, concurrent callers, lost completion acknowledgment, exclusive writes, corruption, symlink rejection and file-before-directory fsync. `caller-fixture-results.json` records the tested hashes and outcomes. Fixture proofs use an obviously synthetic main SHA and are never passed to a live GitHub tool.
