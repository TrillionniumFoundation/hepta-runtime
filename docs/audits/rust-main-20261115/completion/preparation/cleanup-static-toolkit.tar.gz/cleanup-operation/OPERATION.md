# Rust branch cleanup after PR #125

The operation script is cleanup_rust_refs.py. It requires Python 3.9+, Git,
and an already authenticated GitHub CLI. It performs no authentication setup
and does not read, export, or persist credentials.

The script is bound to TrillionniumFoundation/hepta-runtime, PR #125, main,
the owned consolidate/rust-main-20261115 branch, and six explicitly named
protected HIA refs. It does not merge PRs, close PRs, modify CI, or cancel jobs.

## Required inputs

Use branch_scope's exact rust-cleanup-operation-plan-latest.json. It must
contain the final candidate SHA, 149 original Rust ref/SHA pairs, the owned
candidate, six current protected ref/SHA pairs, and the candidate-bound
source-custody verifier PASS result.

The original 149 ref/SHA mapping is independently pinned to this SHA-256:
a3df83a37afd68c868553f6c65e7f219352677fb3a76ce5beab0603162c090a1

Supply the exact completed merge SHA returned for PR #125 and independently
observed on main. Also supply the final candidate SHA and two successful CI
run IDs: Rust PR and Cloud PR. The script checks these inputs against fresh
API results and requires both Rust jobs plus Cloud's offline-tests job.

If dependency fixes change the candidate, refresh its verifier report, the
operation plan, and both PR CI run IDs. The script contains no hardcoded
candidate SHA or workflow-run ID.

For final candidate e425d92b6a0dedf13eb3e484e76419ee756804c0, the applicable
PR runs are Rust 43701857912 and Cloud 43701857874. Their success must still be
verified freshly at execution; listing the IDs here does not claim completion.
Cloud's push trigger filters tools/cloud-compute/** and its own workflow file.
This candidate's transport-test/audit follow-up therefore does not need
a new Cloud push run. Cloud PR evaluates the complete PR change and explicitly
checks out its exact head. Historical Cloud push 43692709541 belongs to old
candidate 4767ddc and remains historical evidence only; it cannot satisfy this
gate. No source change or extra run is manufactured to trigger a push workflow.

## Read-only readiness check

Copy the script and exact JSON plan to the execution host. Replace all quoted
placeholders with the reviewed full SHAs and numeric run IDs. The placeholders
are intentionally invalid and fail before remote mutation.

    python3 -B ./cleanup_rust_refs.py \
      --plan ./rust-cleanup-operation-plan-latest.json \
      --expected-main 'REPLACE_WITH_PR125_MERGE_SHA' \
      --expected-candidate 'REPLACE_WITH_FINAL_CANDIDATE_SHA' \
      --ci-run-id 'RUST_PR_RUN_ID' \
      --ci-run-id 'CLOUD_PR_RUN_ID' \
      --evidence-dir ./cleanup-dry-run-receipt \
      --dry-run-push

Without --execute, remote refs and settings remain unchanged. The optional
--dry-run-push probes the actual 150-ref batch with Git's atomic dry-run.
Omit that flag to use only remote read operations.

## Execution and guards

After reviewing a successful dry run and exact source/CI/PR evidence, run the
same command with --execute and a new evidence directory. Execution repeats
all checks and always performs its own atomic push dry-run.

PR #125 must be merged from the exact candidate into main, and its merge SHA
must equal the supplied expected main. GitHub compare must show the candidate
as an ancestor of that main. A squash or rebase that loses candidate ancestry
does not satisfy this gate.

All PRs are paginated in stable creation order with state=all, then open
head/base dependencies are checked locally. Closing PRs cannot shift records
between pages. Any open same-repository head or base that depends on a deletion
target blocks cleanup. Protected HIA PR bases receive the same check. PR heads
are never used to infer additional deletion targets. The separate PR-closure
receipt remains responsible for confirming all specifically requested PR
closures, including any PR externally retargeted away from deletion refs.

Every remote Git read and write runs in a new empty bare repository, with
global/system config ignored and prompts disabled. The caller's repository
cannot redirect ls-remote through local URL rewrite configuration.

The script requires the full fresh branch inventory to match every planned
old SHA, expected main, and protected SHA. Missing, changed, or unknown refs
stop the operation. It switches the default to main, independently reads it
back, then repeats the full inventory and PR dependency check before deletion.

The deletion is one atomic Git push with a separate explicit
--force-with-lease=refs/heads/NAME:EXACT_OLD_SHA and :refs/heads/NAME for each of
the 150 targets. No main or HIA ref appears in that transaction. Successful
post-state must be exactly main plus the six protected refs at their expected
SHAs, with main still the default.

## Evidence and remaining boundaries

Receipts retain selected ref/PR/CI metadata, plan and script hashes, and start
and end timestamps. Raw subprocess streams, PR bodies, source blobs, and
credentials are not logged. Durable intent files are written before each
mutation. A post-state read is attempted even after a push rejection or timeout.
The timestamps support later read-only identification of deletion-triggered
workflow runs. The script does not alter, skip, or cancel any workflow.

Atomicity covers the 150 deletion refs only. GitHub repository settings,
PR state, main, protected refs, and newly created refs cannot join that Git
transaction. A detected race stops without rollback or attempts to restore
old HIA/main SHAs. If the default switch succeeds but deletion fails, main
remains the default. A dry-run checks capability and lease readiness, but
cannot guarantee acceptance by every receive hook or branch policy.

A missing target, including an automatically deleted candidate, or an
advancing protected ref causes refusal. Refresh and review the facts rather
than silently dropping targets, splitting the transaction, or removing leases.
After interruption or a lost acknowledgement, inspect current refs and the
saved intent before another operation; the script never retries a mutation.

## Local verification

fixture_check.py uses temporary local bare repositories and synthetic commits
with the actual 150 target names and six protected names. The final report,
fixture-results-two-workflows-0414c548.json, records 19 passed checks, zero network calls, and
zero real remote mutations. Its 0414 filename records the fixture inputs when
these unchanged, candidate-parameterized script guards were checked; the live
e425 execution uses the final identities above. No fixture is live CI evidence:

1. Exact original ref manifest and candidate-bound verifier PASS.
2. Atomic dry-run changes no fixture refs.
3. One advanced target causes all 150 deletions to be rejected.
4. Matching leases remove exactly 150 refs and retain main plus six HIA refs.
5. Protected refs and main are rejected by command construction.
6. Changed original leases, protected-ref injection, and stale proof fail.
7. Open PR head/base dependencies block deletion without confusing fork refs.
8. Default operation mode invokes no PATCH or push.
9. Unknown refs and advancing protected refs are detected.
10. A caller repository's URL rewrite cannot redirect the isolated read side.

The nine additional CI-gate checks use synthetic selected GitHub responses,
with no network calls. Exactly the two required candidate PR runs can pass.
Missing Cloud PR, missing Rust PR, either missing Rust lane, a missing Cloud
offline-tests job, a Cloud PR from another SHA, the historical 4767ddc Cloud
push, and even a same-candidate Cloud push substituted for Cloud PR all fail.
These checks do not assert that any live CI run has finished.

These local checks do not replace hosted GitHub CI or the final remote dry run.
