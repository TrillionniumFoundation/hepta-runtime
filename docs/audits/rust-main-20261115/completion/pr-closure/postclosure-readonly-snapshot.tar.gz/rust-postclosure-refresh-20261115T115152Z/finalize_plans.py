import datetime
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import tarfile
import tempfile

OUT = Path(__file__).resolve().parent
ROOT = OUT.parent
REPO = ROOT / 'hepta-runtime'
CANDIDATE = 'e425d92b6a0dedf13eb3e484e76419ee756804c0'
MAIN = '737acf6f901e46c57b0b4374e323e0d1132e0d49'
TREE = '76652098f4b5bcad487071f2eaefd82d7fed219c'
REPOSITORY = 'TrillionniumFoundation/hepta-runtime'
FINGERPRINT = 'a3df83a37afd68c868553f6c65e7f219352677fb3a76ce5beab0603162c090a1'
NOW = datetime.datetime.now(datetime.timezone.utc).isoformat()
NAMES = ['rust-cleanup-operation-plan-latest.json', 'rust-pr-close-plan-latest.json', 'rust-branch-deletion-plan-latest.json']


def load(path):
    return json.loads(path.read_text())


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write(path, value):
    data = (json.dumps(value, indent=2, ensure_ascii=False) + '\n').encode()
    with path.open('xb') as stream:
        stream.write(data)
        stream.flush()
        os.fsync(stream.fileno())


prior_hashes = load(OUT / 'prior-latest-plan-hashes.json')
assert all(sha(ROOT / name) == prior_hashes[name] for name in NAMES)
plans = [load(OUT / 'previous-e425-preclosure-plans' / name) for name in NAMES]
operation, close_plan, deletion_plan = plans
identities = load(ROOT / 'rust-pr-closure-caller-v2/reviewed-inputs/pr-close-exact-identities.json')
assert len(identities) == 93
delete = {row['ref']: row['expected_sha'] for row in operation['deletion_candidates']}
candidate_ref = operation['candidate']['ref']
original = {ref: value for ref, value in delete.items() if ref != candidate_ref}
assert len(delete) == 150 and len(original) == 149 and delete[candidate_ref] == CANDIDATE
assert hashlib.sha256(json.dumps(original, sort_keys=True, separators=(',', ':')).encode()).hexdigest() == FINGERPRINT
protected_names = {row['ref'] for row in operation['preserved_hia_refs']}
assert len(protected_names) == 6 and not protected_names.intersection(delete)
refs = {}
for line in (OUT / 'remote-heads.tsv').read_text().splitlines():
    value, ref = line.split('\t')
    assert ref not in refs and len(value) == 40
    refs[ref] = value
assert load(OUT / 'remote-ref-read-receipt.json')['exit_code'] == 0
assert len(refs) == 157 and set(refs) == set(delete) | protected_names | {'refs/heads/main'}
assert all(refs[ref] == expected for ref, expected in delete.items())
assert refs['refs/heads/main'] == MAIN

snapshot = load(OUT / 'github-prs-direct.json')
prs = {row['number']: row for row in snapshot['pull_requests']}
assert len(prs) == snapshot['total'] == 109
assert sorted(number for number, row in prs.items() if row['state'] == 'open') == [121, 122, 124]
for expected in identities:
    current = prs[expected['number']]
    assert current['state'] == 'closed' and current['draft'] == expected['expected_draft']
    for role in ('head', 'base'):
        assert {key: current[role][key] for key in ('ref', 'sha', 'repo')} == expected[role]
pr125 = snapshot['pr125_direct']
assert pr125['state'] == 'closed' and pr125['merged'] and pr125['merge_commit_sha'] == MAIN
assert pr125['head']['sha'] == CANDIDATE and pr125['head']['ref'] == 'consolidate/rust-main-20261115'
assert pr125['base']['ref'] == 'main' and pr125['head']['repo'] == pr125['base']['repo'] == REPOSITORY
open_dependencies = []
for number, pr in prs.items():
    if pr['state'] != 'open':
        continue
    for role in ('head', 'base'):
        if pr[role]['repo'] == REPOSITORY and 'refs/heads/' + pr[role]['ref'] in delete:
            open_dependencies.append({'number': number, 'role': role, 'ref': pr[role]['ref']})
assert not open_dependencies

hia_prs = []
for number in (121, 122, 124):
    current = prs[number]
    assert current['state'] == 'open' and current['draft'] is True
    head, base = 'refs/heads/' + current['head']['ref'], 'refs/heads/' + current['base']['ref']
    assert head in protected_names and base in protected_names and current['head']['sha'] == refs[head]
    hia_prs.append({'number': number, 'state': current['state'], 'draft': current['draft'],
        'head': current['head']['ref'], 'api_head_sha': current['head']['sha'], 'observed_head_branch_sha': refs[head],
        'base': current['base']['ref'], 'api_base_sha': current['base']['sha'], 'observed_base_branch_sha': refs[base],
        'base_snapshot_differs_from_branch_head': current['base']['sha'] != refs[base],
        'sampled_updated_at': current['updated_at'], 'action': 'KEEP_UNTOUCHED'})
history = set(subprocess.check_output(['git', '-C', str(REPO), 'rev-list', MAIN], text=True).splitlines())
assert all(value in history for value in original.values())
assert all(expected['head']['sha'] in history for expected in identities)
frozen_base = 'refs/heads/codex/hia-archive-source-retention-20261111-f9aa'
current_rewrites_in_history = [ref for ref in protected_names if ref != frozen_base and refs[ref] in history]
assert not current_rewrites_in_history
main_proof = load(OUT / 'merged-main-source-custody-verification.json')
candidate_proof = load(OUT / 'candidate-source-custody-verification.json')
assert main_proof['status'] == candidate_proof['status'] == 'PASS'
assert main_proof['revision'] == MAIN and candidate_proof['revision'] == CANDIDATE
assert main_proof['integrated_rust_refs'] == 149 and main_proof['archive_manifests'] == 42
assert main_proof['exact_retained_blob_paths'] == 5244 and main_proof['protected_rewrites_included'] == []
assert load(OUT / 'merged-main-standalone-45-proof.json')['files'] == 45

ci = []
for run_id, workflow, required_jobs in [
    (43701857912, '.github/workflows/ci.yml', {'Rust exact-head validation', 'Rust prospective-merge validation'}),
    (43701857874, '.github/workflows/cloud-compute.yml', {'offline-tests'}),
]:
    run = load(OUT / f'rest-ci-run-{run_id}.json')
    jobs = load(OUT / f'rest-ci-jobs-{run_id}.json')
    assert run['id'] == run_id and run['head_sha'] == CANDIDATE and run['event'] == 'pull_request'
    assert run['status'] == 'completed' and run['conclusion'] == 'success' and run['path'] == workflow
    assert jobs['total_count'] == len(jobs['jobs']) and required_jobs == {j['name'] for j in jobs['jobs']}
    assert all(j['status'] == 'completed' and j['conclusion'] == 'success' for j in jobs['jobs'])
    ci.append({'run_id': run_id, 'workflow': workflow, 'event': run['event'], 'head_sha': run['head_sha'],
               'status': run['status'], 'conclusion': run['conclusion'], 'jobs': [{key: j[key] for key in ('id', 'name', 'status', 'conclusion')} for j in jobs['jobs']]})

helper = ROOT / 'rust-pr-closure-caller-v2/closure_journal.py'
spec = importlib.util.spec_from_file_location('final_journal', helper)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
journal_state = module.handle('inspect', {})
assert journal_state['status'] == 'ALL_93_VERIFIED_CLOSED' and journal_state['next_start'] == 93
journal = ROOT / 'rust-pr-closure-receipts-e425-v2'
assert len(list(journal.glob('batch-*/complete.json'))) == 19 and not list(journal.rglob('stopped.json'))
assert len(list(journal.rglob('pr-*-before.json'))) == len(list(journal.rglob('pr-*-close-intent.json'))) == len(list(journal.rglob('pr-*-outcome.json'))) == 93
observations = []
for index, expected in enumerate(identities):
    number = expected['number']
    path = journal / f'batch-{index - index % 5:03d}' / f'pr-{number}-outcome.json'
    outcome = load(path)
    assert outcome['outcome'] == 'CLOSED_AND_VERIFIED' and outcome['number'] == number
    observations.append({'number': number, 'state': 'closed', 'observed': prs[number],
        'durable_outcome': outcome['outcome'], 'outcome_receipt': str(path), 'outcome_sha256': sha(path),
        'retained_head_ref': expected['retained_head_ref']})
journal_manifest = {str(path.relative_to(journal)): {'bytes': path.stat().st_size, 'sha256': sha(path)}
                    for path in sorted(journal.rglob('*')) if path.is_file()}
write(OUT / 'closure-journal-manifest.json', journal_manifest)
with tarfile.open(OUT / 'closure-journal-v2.tar.gz', 'x:gz') as archive:
    for relative in journal_manifest:
        archive.add(journal / relative, arcname='rust-pr-closure-receipts-e425-v2/' + relative, recursive=False)
closure = {'status': 'ALL_93_VERIFIED_CLOSED', 'completed_utc': NOW, 'journal': str(journal), 'cursor': 93,
    'completed_batches': 19, 'closed_and_verified': 93, 'already_closed_skips': 0, 'uncertain_outcomes': 0,
    'branch_mutations': 0, 'protected_pr_mutations': 0, 'comments_sent': 0,
    'root_authorization_file': str(ROOT / 'root-merge-operation/09-v2-closure-authorization.json'),
    'root_authorization_sha256': sha(ROOT / 'root-merge-operation/09-v2-closure-authorization.json'),
    'root_proof_file': str(ROOT / 'root-merge-operation/root-final-main-merge-proof.json'),
    'root_proof_sha256': sha(ROOT / 'root-merge-operation/root-final-main-merge-proof.json'),
    'caller_sha256': sha(ROOT / 'rust-pr-closure-caller-v2/run_rust_pr_closure.js'), 'helper_sha256': sha(helper),
    'executor_sha256': sha(ROOT / 'rust-pr-closure-caller-v2/reviewed-inputs/close_rust_pr_batch.js'),
    'identities_sha256': sha(ROOT / 'rust-pr-closure-caller-v2/reviewed-inputs/pr-close-exact-identities.json'),
    'journal_manifest_file': str(OUT / 'closure-journal-manifest.json'),
    'journal_manifest_sha256': sha(OUT / 'closure-journal-manifest.json'),
    'archive_file': str(OUT / 'closure-journal-v2.tar.gz'), 'archive_sha256': sha(OUT / 'closure-journal-v2.tar.gz'),
    'old_zero_mutation_stop_journal_preserved': str(ROOT / 'rust-pr-closure-receipts-e425')}
write(OUT / 'closure-operation-summary.json', closure)
write(OUT / 'exact-93-closed-verification.json', {'status': 'PASS', 'sampled_utc': snapshot['sampled_at_utc'], 'observations': observations})
write(OUT / 'ci-exact-candidate-verification.json', {'status': 'PASS', 'runs': ci})
ready = {'schema': 'hepta.postclosure-readiness.v1', 'status': 'PASS_READY_FOR_ROOT_CLEANUP_DRY_RUN',
    'observed_utc': NOW, 'main_sha': MAIN, 'candidate_sha': CANDIDATE, 'tree_sha': TREE,
    'original_rust_refs_unchanged': 149, 'original_ref_sha_fingerprint': FINGERPRINT, 'deletion_target_count': 150,
    'remote_refs': 157, 'new_refs': [], 'moved_or_missing_original_refs': [], 'exact_rust_prs_closed': 93,
    'total_prs': 109, 'open_pr_numbers': [121, 122, 124], 'open_deletion_dependencies': open_dependencies,
    'protected_hia_refs': [{'ref': ref, 'expected_sha': refs[ref]} for ref in sorted(protected_names)],
    'protected_hia_prs': hia_prs, 'current_protected_rewrite_tips_in_history': [],
    'default_branch': snapshot['repository_metadata']['default_branch'], 'ci': ci,
    'source_custody_main': main_proof, 'standalone_exact_files': 45, 'candidate_bound_proof_preserved': True,
    'branch_scope_performed_branch_mutations': False, 'root_must_repeat_live_cleanup_gates': True}
write(OUT / 'postclosure-readiness.json', ready)

root_workflow_guard = {'owner': 'root', 'workflow_id': 372929360, 'workflow_file': '.github/workflows/rog-smu-ab-20261002.yml',
    'observed_prior_state_reported_by_root': 'active', 'before_atomic_delete': 'temporarily disable this historical hardware workflow',
    'after_atomic_delete': 'restore its original active setting', 'workflow_source_changes': False,
    'run_cancellation_authorized_to_branch_scope': False, 'settings_actions_performed_by_branch_scope': False,
    'evidence': 'Root manages and records these setting changes separately; this plan note is not an execution receipt.'}
for plan in plans:
    plan['status'] = 'READY_FOR_ROOT_CLEANUP_DRY_RUN_AND_GUARDED_EXECUTION'
    plan['sampled_utc'] = NOW
    plan['awaiting_root_final_main_merge_proof'] = False
    plan['ready_for_root_cleanup'] = True
    plan['execute_allowed_now'] = False
    plan['execution_owner'] = 'root; fresh cleanup dry-run and live gates must pass before ref mutation'
    plan['fresh_snapshot_directory'] = str(OUT)
    plan['closure_operation'] = closure
    plan['closure_verification_file'] = str(OUT / 'exact-93-closed-verification.json')
    plan['postclosure_readiness_file'] = str(OUT / 'postclosure-readiness.json')
    plan['ci_verified_runs'] = ci
    plan['root_extra_workflow_safety_step'] = root_workflow_guard
    plan['source_custody_verification'] = candidate_proof
    plan['verification_file'] = str(OUT / 'candidate-source-custody-verification.json')
    plan['standalone_45_proof_file'] = str(OUT / 'candidate-standalone-45-proof.json')
    plan['merged_main_source_custody_verification'] = main_proof
    plan['merged_main_verification_file'] = str(OUT / 'merged-main-source-custody-verification.json')
    plan['merged_main_standalone_45_proof_file'] = str(OUT / 'merged-main-standalone-45-proof.json')
    plan['current_protected_rewrite_tips_in_history'] = []
    plan['main'] = {'ref': 'refs/heads/main', 'observed_before_merge_sha': 'ba574f2a6a1b74e85191c58d7bec011720736bb9',
                    'required_after_merge_sha': MAIN, 'observed_after_merge_sha': MAIN, 'tree_sha': TREE}
    plan['pr125'] = {'number': 125, 'state': 'closed', 'draft': pr125['draft'], 'merged': True,
        'merged_at': pr125['merged_at'], 'merge_commit_sha': MAIN, 'expected_head_ref': 'consolidate/rust-main-20261115',
        'expected_head_sha': CANDIDATE, 'expected_base_ref': 'main', 'observed_base_sha': pr125['base']['sha']}
    for row in plan['preserved_hia_refs']:
        row['expected_sha'] = refs[row['ref']]
        if 'observed_remote_sha' in row:
            row['observed_remote_sha'] = refs[row['ref']]
            row['advanced_externally'] = refs[row['ref']] != row['initial_sha']
    plan['protected_hia_prs'] = hia_prs
    if 'sampling' in plan:
        plan['sampling'].update(plan_generated_utc=NOW, direct_rest_sample_utc=snapshot['sampled_at_utc'],
             branch_sha_sample_utc=load(OUT / 'remote-ref-read-receipt.json')['completed_utc'])
    for field in ('current_default_branch', 'observed_default_branch'):
        if field in plan:
            plan[field] = snapshot['repository_metadata']['default_branch']
    if 'remote_mutations_performed' in plan:
        plan['remote_mutations_performed'] = True
        plan['remote_mutation_scope_completed'] = '93 exact Rust PR state-only closes; no ref/default/HIA/comment mutations'
close_plan['status'] = 'COMPLETE_93_RUST_PRS_CLOSED_AND_INDEPENDENTLY_VERIFIED'
close_plan['closure_observations'] = observations
close_plan['counts'].update(current_direct_rest_total_prs=109, current_direct_rest_open_prs=3,
    rust_closed_verified=93, rust_remaining_to_close=0, protected_hia_open=3, owned_consolidation_pr=1)
for row in close_plan['close_candidates']:
    row.update(observed_after_closure_state='closed', closure_completed=True, execute_now=False)
deletion_plan.update(new_remote_refs=[], excluded_original_rust_refs=[], unclassified_open_pr_numbers=[], open_deletion_dependencies=[])
assert {r['ref']: r['expected_sha'] for r in operation['deletion_candidates']} == delete
assert {r['ref']: r['expected_sha'] for r in deletion_plan['deletion_candidates']} == delete
assert all(plan['source_custody_verification']['revision'] == CANDIDATE for plan in plans)
for name, plan in zip(NAMES, plans):
    write(OUT / name, plan)
assert all(sha(ROOT / name) == prior_hashes[name] for name in NAMES), 'Concurrent plan edit: do not overwrite'
for name in NAMES:
    fd, temporary = tempfile.mkstemp(prefix='postclosure-plan-', suffix='.json', dir=ROOT)
    try:
        with os.fdopen(fd, 'wb') as stream:
            stream.write((OUT / name).read_bytes())
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, ROOT / name)
    finally:
        if os.path.exists(temporary):
            os.unlink(temporary)
directory_fd = os.open(ROOT, os.O_RDONLY | os.O_DIRECTORY)
os.fsync(directory_fd)
os.close(directory_fd)
result = {'status': 'THREE_LATEST_PLANS_REFRESHED_READY_FOR_ROOT_DRY_RUN', 'readiness': ready['status'],
          'latest_plan_sha256': {name: sha(ROOT / name) for name in NAMES}, 'journal_archive_sha256': closure['archive_sha256'],
          'scope_fingerprint': FINGERPRINT, 'ready_for_root_cleanup': True, 'branch_mutations_by_this_agent': 0}
write(OUT / 'plan-refresh-receipt.json', result)
print(json.dumps(result, indent=2))
