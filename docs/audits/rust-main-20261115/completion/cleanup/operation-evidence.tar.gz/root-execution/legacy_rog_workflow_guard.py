#!/usr/bin/env python3
"""Pause/restore one legacy hardware workflow for the reviewed ref deletion.

No workflow file, branch, PR, existing run, or hardware host is modified here.
All remote mutations are limited to one workflow's enable/disable setting.
"""
import argparse
import datetime
import json
import os
from pathlib import Path
import subprocess

REPO = "TrillionniumFoundation/hepta-runtime"
WORKFLOW_ID = 372929360
WORKFLOW_PATH = ".github/workflows/rog-smu-ab-20261002.yml"
WORKFLOW_NAME = "ROG Strix Halo SMU A/B"
ENDPOINT = f"repos/{REPO}/actions/workflows/{WORKFLOW_ID}"

def require(condition, message):
    if not condition:
        raise RuntimeError(message)

def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()

def call(method, suffix="", selection=None):
    args = ["gh", "api", "--hostname", "github.com", "--method", method, ENDPOINT + suffix]
    if selection:
        args += ["--jq", selection]
    result = subprocess.run(args, capture_output=True, text=True, timeout=45)
    if result.returncode != 0:
        raise RuntimeError("Selected workflow API call failed; inspect state without automatic retry")
    return result.stdout

def get():
    value = json.loads(call("GET", selection="{id,name,path,state,html_url,updated_at}"))
    require(value["id"] == WORKFLOW_ID and value["path"] == WORKFLOW_PATH, "Wrong workflow identity")
    require(value["name"] == WORKFLOW_NAME, "Wrong workflow name")
    return value

def save(directory, name, value):
    fd = os.open(directory / name, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600)
    with os.fdopen(fd, "w") as stream:
        json.dump(value, stream, indent=2, sort_keys=True)
        stream.write("\n")
        stream.flush()
        os.fsync(stream.fileno())
    dfd = os.open(directory, os.O_RDONLY | os.O_DIRECTORY)
    try:
        os.fsync(dfd)
    finally:
        os.close(dfd)

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("mode", choices=["pause", "verify-paused", "restore"])
    parser.add_argument("--directory", required=True)
    args = parser.parse_args()
    directory = Path(args.directory)
    require(directory.is_dir() and not directory.is_symlink(), "Invalid evidence directory")
    initial = json.loads((directory / "rog-workflow-before.json").read_text())
    require(initial["repository"] == REPO, "Wrong initial repository")
    require(initial["workflow"]["id"] == WORKFLOW_ID, "Wrong initial workflow id")
    require(initial["workflow"]["path"] == WORKFLOW_PATH, "Wrong initial workflow path")
    current = get()
    if args.mode == "pause":
        require(initial["workflow"]["state"] == current["state"], "State changed since inspection")
        owned = current["state"] == "active"
        require(owned or current["state"].startswith("disabled_"), "Unexpected initial state")
        save(directory, "rog-pause-intent.json", {"at_utc": now(), "before": current,
             "mutation": "disable" if owned else None, "workflow_id": WORKFLOW_ID})
        if owned:
            call("PUT", "/disable")
        after = get()
        expected = "disabled_manually" if owned else current["state"]
        require(after["state"] == expected, "Workflow disabled state not confirmed")
        receipt = {"at_utc": now(), "before": current, "after": after,
                   "disabled_by_this_operation": owned, "existing_runs_cancelled": False}
        save(directory, "rog-pause-confirmed.json", receipt)
        print(json.dumps(receipt))
    elif args.mode == "verify-paused":
        pause = json.loads((directory / "rog-pause-confirmed.json").read_text())
        require(current["state"] == pause["after"]["state"], "Paused state changed")
        require(current["state"].startswith("disabled_"), "Workflow is not disabled")
        print(json.dumps({"at_utc": now(), "workflow": current, "disabled_verified": True}))
    else:
        pause = json.loads((directory / "rog-pause-confirmed.json").read_text())
        require(current["state"] == pause["after"]["state"], "State changed externally; do not overwrite")
        owned = pause["disabled_by_this_operation"]
        save(directory, "rog-restore-intent.json", {"at_utc": now(), "before": current,
             "mutation": "enable" if owned else None, "workflow_id": WORKFLOW_ID})
        if owned:
            require(pause["before"]["state"] == "active" and current["state"] == "disabled_manually", "Not an owned pause")
            call("PUT", "/enable")
        after = get()
        require(after["state"] == pause["before"]["state"], "Original workflow state not restored")
        receipt = {"at_utc": now(), "before": current, "after": after,
                   "enabled_by_this_operation": owned, "original_state_restored": True}
        save(directory, "rog-restore-confirmed.json", receipt)
        print(json.dumps(receipt))

if __name__ == "__main__":
    main()
