# 删除窗口工作流只读清点

最终查询窗口为 **2026-11-15 12:05:40Z—12:26:40Z**，涵盖 ROG 暂停、实际删除及删除后观察。ROG workflow `372929360` 在这个窗口 **没有返回任何 run**；整个仓库也没有 `created_at` 在删除开始 `12:23:12.843740Z` 及之后的 run。

实际 atomic delete 起止由 root 报告为 `12:23:12.843740Z`—`12:23:37.532618Z`，postcheck 于 `12:24:00.093645Z` 完成。此次观察只读取 GitHub，未独立执行删除或 host 操作。

## 分页与分类

最终仓库级 `created` 范围查询返回 `total_count=3`，第 1 页三个条目，第 2 页空；两页均保存全部原始 API 字段。11:00:00Z—12:25:18Z 的上下文查询 `total_count=17`，第 1 页十七条、第 2 页空。另保留 12:24:34Z、12:25:18Z 两轮较早快照与请求 URL、读取时间。

| Run | Event / branch | 创建时间 | 读取时结果 | 分类 |
| --- | --- | --- | --- | --- |
| 43712580608 | push / HIA request-context | 12:11:36Z | in_progress | HIA 外部推进 |
| 43712580679 | push / HIA request-context | 12:11:36Z | failure | HIA 外部推进，仅记元数据 |
| 43713567593 | dynamic / main | 12:23:10Z | success | 依赖 Graph Update，早于删除开始 |

HIA 两个 run 的 head 为 `035288d9b4ec3482e3498953d2c2b4d4b60da20d`，未取消、重跑、读日志或修改它们。Graph Update 的 event 是 `dynamic`，创建于删除前，不能归为删除产生的新 push run。

PR125 于 `11:33:46Z` 合入，merge commit 为 `737acf6f901e46c57b0b4374e323e0d1132e0d49`。其八个 main push run 均创建于 `11:33:49Z`，早于删除近 50 分钟；读取时 Rust 一项运行中、Chrome CDP 一项失败、其余六项成功。Chrome CDP 失败另行分析，不误归因于删除，也不改写已封存候选 e425 的 CI 结果。

专用 workflow URL 被 GitHub Fetch 的 URL 白名单拒绝，错误原文保存在 `rejected-endpoints.json`；使用受支持的仓库 runs API、精确时间过滤及全部分页，并逐条核 `workflow_id`，覆盖了相同 ROG run 查询范围。未绕过任何 runtime inventory bound。

`summary.json` 为机器可读结论；`retrieval-index.json` 记录每次请求、时间、分页与原始 JSON 文件。API JSON 字段不删改，缺失的文件末尾换行仅作文本文件规范化。`manifest.json` 对除自身外全部文件记 SHA-256。

此结论限于已返回的 GitHub API 快照和截至时间；不保证未来没有延迟出现的新 run。root 另报告在 `12:25:54Z` 开始恢复 ROG 状态，本观察者未执行或验证该状态修改。所有操作仅 GitHub GET；没有 dispatch、取消、重跑、启停 workflow 或任何 HIA/host/ref 操作。
