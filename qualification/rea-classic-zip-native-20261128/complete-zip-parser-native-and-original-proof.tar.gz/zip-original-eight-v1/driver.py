from pathlib import Path
from hashlib import sha256
import sys,json,subprocess,os,time,shutil
base=Path('/home/qian-qi/hia-runtime-rea-formats-20261128-2ac5')
out=base/'zip-original-eight-v1';out.mkdir(mode=0o700,exist_ok=False)
(out/'driver.py').write_text(sys.argv[1]);payload=json.loads(sys.argv[2])
for name,body in payload.items():(out/name).write_text(body)
source=base/'zip-native-build-v1/source';manifest=base/'zip-native-build-v1/build/modules/rea-zip-parser/manifest.json'
env=dict(os.environ,LC_ALL='C',LANG='C',PYTHONDONTWRITEBYTECODE='1',HIA_ZIP_MANIFEST=str(manifest),HIA_ZIP_MANIFEST_SHA256=sha256(manifest.read_bytes()).hexdigest())
rows=[]
def run(label,argv,cwd,timeout=300):
 started=time.monotonic()
 with(out/(label+'.stdout')).open('xb')as so,(out/(label+'.stderr')).open('xb')as se:
  p=subprocess.run(argv,cwd=cwd,env=env,stdout=so,stderr=se,timeout=timeout)
 row={'label':label,'argv':argv,'returncode':p.returncode,'seconds':time.monotonic()-started,'stdout_bytes':(out/(label+'.stdout')).stat().st_size,'stderr_bytes':(out/(label+'.stderr')).stat().st_size}
 rows.append(row);(out/'progress.json').write_text(json.dumps(rows,sort_keys=True,indent=2)+'\n')
 print(json.dumps(row,sort_keys=True),flush=True)
 if p.returncode:
  print((out/(label+'.stdout')).read_text()[-16000:],flush=True);print((out/(label+'.stderr')).read_text()[-16000:],flush=True)
 assert p.returncode==0
run('prepare',['/usr/bin/python3','-B',str(out/'prepare_zip_oracle.py'),'--source',str(source),'--output',str(out/'bindings'),'--native-driver',str(out/'zip_native_driver.rs')],out,60)
crate=out/'bindings/crate';cargo='/home/qian-qi/.cargo/bin/cargo';env['CARGO_TARGET_DIR']=str(out/'target')
run('nextest-version',[cargo,'+1.95.0','nextest','--version'],crate,30)
version=(out/'nextest-version.stdout').read_text();assert '0.9.137'in version,version
original_pins=json.loads((out/'bindings/preparation.json').read_bytes())['original_sources']
lock_before=(crate/'Cargo.lock').read_bytes()
run('original-eight',[cargo,'+1.95.0','nextest','run','--locked','--offline','--lib','--test-threads','1','--retries','0','--no-fail-fast'],crate)
run('original-cli',[cargo,'+1.95.0','build','--locked','--offline','--bin','hia-rea-zip-reference'],crate)
shutil.copy2(out/'target/debug/hia-rea-zip-reference',out/'original-oracle');(out/'original-oracle').chmod(0o500)
events=out/'native-events';events.mkdir(mode=0o700);env['HIA_ZIP_EVIDENCE_DIR']=str(events)
run('native-original-eight',[cargo,'+1.95.0','nextest','run','--locked','--offline','--lib','--features','native','--test-threads','1','--retries','0','--no-fail-fast'],crate)
assert(crate/'Cargo.lock').read_bytes()==lock_before
for name,row in original_pins.items():
 raw=(out/'bindings/original'/name).read_bytes();assert len(raw)==row['bytes']and sha256(raw).hexdigest()==row['sha256']
native_calls=0;effects=0;terminals=0
for p in events.glob('*.jsonl'):
 for line in p.read_text().splitlines():
  r=json.loads(line)
  if r['event']=='terminal':
   native_calls+=r['native_calls'];effects+=r['effects'];terminals+=1
report={'status':'ORIGINAL_EIGHT_RUST_AND_ACTUAL_HIA_METHODS_PASSED','rows':rows,'original_methods':8,'native_original_methods':8,'original_test_bytes_and_assertions_unchanged':True,'source_and_lock_bytes_stable':True,'native_invocations':native_calls,'native_effects':effects,'native_completed_calls':terminals,'full_public_route_qualified':False}
(out/'terminal.json').write_text(json.dumps(report,sort_keys=True,indent=2)+'\n');print(json.dumps(report,sort_keys=True),flush=True)
