use anyhow::{anyhow,bail,Context,Result};
use serde::{Deserialize,Serialize};
use serde_json::{json,Value};
use sha2::{Digest,Sha256};
use std::fmt::Write as _;
use super::{ArchiveFilter,MAX_DIRECTORY_BYTES};
use std::fs::File;
use std::io::{Read,Seek,SeekFrom};
#[derive(Debug,Clone,Deserialize,Serialize)]
#[serde(deny_unknown_fields)]
pub(super) struct Request {
	pub filter: ArchiveFilter,
	pub offset: usize,
	pub limit: usize,
}

pub(super) fn inspect_file(file: &mut File, request: &Request) -> Result<Value> {
    let filter = match request.filter {
        ArchiveFilter::All=>0,ArchiveFilter::Manifest=>1,ArchiveFilter::Dex=>2,
        ArchiveFilter::NativeLibrary=>3,ArchiveFilter::Resource=>4,
        ArchiveFilter::JavaClass=>5,ArchiveFilter::SignatureMarker=>6
    };
    crate::native_driver::inspect(file,filter,request.offset,request.limit)
}
fn extra_fields(bytes:&[u8])->Result<Vec<u16>> {
    serde_json::from_value(crate::native_driver::field(1,bytes,0,0,0)?)
        .context("typed native extra-field list")
}
fn member_name(bytes:&[u8],flags:u16)->Result<(String,&'static str)> {
    let value=crate::native_driver::field(2,bytes,flags,0,0)?;
    let name=value[0].as_str().context("native member name")?.to_owned();
    let encoding=match value[1].as_str() {
        Some("ascii")=>"ascii",Some("utf8")=>"utf8",_=>bail!("native encoding differs")
    };
    Ok((name,encoding))
}
fn validate_local_extra(bytes:&[u8],method:u16,flags:u16,payload_offset:u64)->Result<()> {
    let value=crate::native_driver::field(3,bytes,flags,method,payload_offset)?;
    if !value.is_null(){bail!("native local-extra result differs");}
    Ok(())
}
#[cfg(test)]
#[path="/home/qian-qi/hia-runtime-rea-formats-20261128-2ac5/zip-original-eight-v1/bindings/original/src/mcp/rea_artifact_zip_parser_tests.rs"]
mod rea_artifact_zip_parser_tests;
