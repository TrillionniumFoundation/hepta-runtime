from pathlib import Path
from hashlib import sha256
import sys,json,subprocess,os,tomllib,time,shutil,traceback
base=Path('/home/qian-qi/hia-runtime-rea-formats-20261128-2ac5');out=base/'zip-original-eight-v4';out.mkdir(mode=0o700,exist_ok=False)
(out/'driver.py').write_text(sys.argv[1])
payload=json.loads(sys.argv[2])
for name,data in payload.items():(out/name).write_text(data)
source=base/'zip-native-build-v1/source';cargo='/home/qian-qi/.cargo/bin/cargo'
manifest=base/'zip-native-build-v1/build/modules/rea-zip-parser/manifest.json'
env=dict(os.environ,LC_ALL='C',LANG='C',PYTHONDONTWRITEBYTECODE='1',CARGO_TARGET_DIR=str(out/'target'),HIA_ZIP_MANIFEST=str(manifest),HIA_ZIP_MANIFEST_SHA256=sha256(manifest.read_bytes()).hexdigest())
rows=[];crate=out
def run(label,argv,timeout=300):
 started=time.monotonic()
 with(out/(label+'.stdout')).open('xb')as so,(out/(label+'.stderr')).open('xb')as se:
  p=subprocess.run(argv,cwd=crate,env=env,stdout=so,stderr=se,timeout=timeout)
 row={'label':label,'argv':argv,'returncode':p.returncode,'seconds':time.monotonic()-started,'stdout_bytes':(out/(label+'.stdout')).stat().st_size,'stderr_bytes':(out/(label+'.stderr')).stat().st_size}
 rows.append(row);(out/'progress.json').write_text(json.dumps(rows,sort_keys=True,indent=2)+'\n');print(json.dumps(row,sort_keys=True),flush=True)
 if p.returncode:print((out/(label+'.stdout')).read_text()[-12000:]+(out/(label+'.stderr')).read_text()[-12000:],flush=True)
 assert p.returncode==0
try:
 run('prepare',[sys.executable,'-B',str(out/'prepare_zip_oracle.py'),'--source',str(source),'--output',str(out/'bindings'),'--native-driver',str(out/'zip_native_driver.rs')],60)
 bindings=out/'bindings';crate=bindings/'crate'
 canonical=(base/'zip-original-eight-v3/admitted-Cargo.lock').read_bytes();(crate/'Cargo.lock').write_bytes(canonical);(out/'admitted-Cargo.lock').write_bytes(canonical)
 run('locked-offline-metadata',[cargo,'+1.95.0','metadata','--offline','--locked','--format-version','1','--all-features','--filter-platform','x86_64-unknown-linux-gnu'],60)
 assert(crate/'Cargo.lock').read_bytes()==canonical
 original={(r['name'],r['version']):r for r in tomllib.loads((source/'Cargo.lock').read_text())['package']}
 for row in tomllib.loads(canonical.decode())['package']:
  if row['name']=='hia-rea-zip-reference':continue
  old=original[(row['name'],row['version'])];assert row.get('source')==old.get('source')and row.get('checksum')==old.get('checksum')
 run('original-eight',[cargo,'+1.95.0','nextest','run','--locked','--offline','--lib','--test-threads','1','--retries','0','--no-fail-fast'])
 run('original-cli',[cargo,'+1.95.0','build','--locked','--offline','--bin','hia-rea-zip-reference'])
 shutil.copy2(out/'target/debug/hia-rea-zip-reference',out/'original-oracle');(out/'original-oracle').chmod(0o500)
 events=out/'native-events';events.mkdir(mode=0o700);env['HIA_ZIP_EVIDENCE_DIR']=str(events)
 run('native-original-eight',[cargo,'+1.95.0','nextest','run','--locked','--offline','--lib','--features','native','--test-threads','1','--retries','0','--no-fail-fast'])
 assert(crate/'Cargo.lock').read_bytes()==canonical
 original_pins=json.loads((bindings/'preparation.json').read_bytes())['original_sources']
 for name,row in original_pins.items():
  raw=(bindings/'original'/name).read_bytes();assert len(raw)==row['bytes']and sha256(raw).hexdigest()==row['sha256']
 native_calls=0;effects=0;terminals=0
 for path in events.glob('*.jsonl'):
  for line in path.read_text().splitlines():
   r=json.loads(line)
   if r['event']=='terminal':native_calls+=r['native_calls'];effects+=r['effects'];terminals+=1
 report={'status':'ORIGINAL_EIGHT_RUST_AND_ACTUAL_HIA_METHODS_PASSED','rows':rows,'original_methods':8,'native_original_methods':8,'original_test_bytes_and_assertions_unchanged':True,'source_and_lock_bytes_stable':True,'native_invocations':native_calls,'native_effects':effects,'native_completed_calls':terminals,'full_public_route_qualified':False}
except BaseException as error:
 report={'status':'FAILED','rows':rows,'error':repr(error),'traceback':traceback.format_exc(),'full_public_route_qualified':False}
 (out/'terminal.json').write_text(json.dumps(report,sort_keys=True,indent=2)+'\n');print(json.dumps(report,sort_keys=True),flush=True);raise
(out/'terminal.json').write_text(json.dumps(report,sort_keys=True,indent=2)+'\n');print(json.dumps(report,sort_keys=True),flush=True)
