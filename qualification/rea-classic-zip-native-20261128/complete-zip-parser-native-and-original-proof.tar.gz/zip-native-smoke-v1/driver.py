from pathlib import Path
from hashlib import sha256
import sys,json,subprocess,os,time
base=Path('/home/qian-qi/hia-runtime-rea-formats-20261128-2ac5')
out=base/'zip-native-smoke-v1';out.mkdir(mode=0o700,exist_ok=False)
(out/'driver.py').write_text(sys.argv[1]);(out/'rea_zip_native_transport.py').write_text(sys.argv[2])
source=base/'zip-native-build-v1/source'
manifest=base/'zip-native-build-v1/build/modules/rea-zip-parser/manifest.json'
rows=[]
for label,path in [('zip',source/'tests/fixtures/rea_artifact_sample.zip'),('jar',source/'tests/fixtures/rea_artifact_sample.jar'),('apk',source/'tests/fixtures/rea_artifact_sample.apk'),('aapt2',source/'tests/fixtures/rea_application/owned-aapt2.apk')]:
 started=time.monotonic()
 with(out/(label+'.stdout')).open('xb')as so,(out/(label+'.stderr')).open('xb')as se:
  p=subprocess.run(['/usr/bin/python3','-B',str(out/'rea_zip_native_transport.py'),'--manifest',str(manifest),'--runtime',str(source),'--path',str(path),'--events',str(out/(label+'.events.jsonl'))],stdout=so,stderr=se,env=dict(os.environ,LC_ALL='C',LANG='C'),timeout=30)
 row={'label':label,'returncode':p.returncode,'seconds':time.monotonic()-started,'stdout':(out/(label+'.stdout')).read_text(),'stderr':(out/(label+'.stderr')).read_text()}
 rows.append(row);print(json.dumps(row,sort_keys=True),flush=True)
 assert p.returncode==0
 result=json.loads(row['stdout']);assert result['status']==0,result
 report=json.loads(result['payload'])
 expected={'zip':2,'jar':2,'apk':4,'aapt2':2}[label];assert report['entry_count']==expected
 with path.open('rb')as f:
  x=report['source'];f.seek(x['central_directory_offset']);raw=f.read(x['central_directory_bytes']);assert sha256(raw).hexdigest()==x['central_directory_sha256']
  f.seek(x['eocd_offset']);raw=f.read(x['eocd_bytes']);assert sha256(raw).hexdigest()==x['eocd_sha256']
 if label=='aapt2':
  resource=next(r for r in report['result']['rows']if r['name']=='resources.arsc')
  assert(resource['local_header_offset'],resource['payload_offset'],resource['compressed_bytes'])==(1131,1176,40)
(out/'terminal.json').write_text(json.dumps({'status':'FOUR_ORIGINAL_CONTAINER_NATIVE_SMOKE_PASSED','rows':rows,'original_eight_methods_qualified':False,'public_route_qualified':False},sort_keys=True,indent=2)+'\n')
