from pathlib import Path,PurePosixPath
from hashlib import sha256
import sys,json,subprocess,os,tarfile,stat,time,traceback
base=Path('/home/qian-qi/hia-runtime-rea-formats-20261128-2ac5');out=base/'zip-final-qa-readback-v2';out.mkdir(mode=0o700,exist_ok=False)
(out/'driver.py').write_text(sys.argv[1]);archive=base/'final-qualification-source-v2.tar.gz';raw=archive.read_bytes()
assert len(raw)==19049 and sha256(raw).hexdigest()=='3f8195ab3ae86f0baaa8ba46299f88ec6f17999953231c7f6b6e24f24c76770d'
pins=json.loads((base/'final-qualification-source-v2-pins.json').read_bytes());files=out/'source'
with tarfile.open(archive,'r:gz')as tar:
 assert set(tar.getnames())==set(pins)
 for member in tar.getmembers():
  name=member.name;assert member.isfile()and not PurePosixPath(name).is_absolute()and'..'not in PurePosixPath(name).parts
  data=tar.extractfile(member).read();pin=pins[name];assert len(data)==pin['bytes']and sha256(data).hexdigest()==pin['sha256']and member.mode==pin['mode']
  path=files/name;path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(data);path.chmod(member.mode)
qa=files/'tests/hia_native/rea_zip';source=base/'zip-native-build-v1/source'
env=dict(os.environ,LC_ALL='C',LANG='C',PYTHONDONTWRITEBYTECODE='1')
argv=[sys.executable,'-B',str(qa/'prepare_zip_oracle.py'),'--source',str(source),'--output',str(out/'bindings'),'--native-driver',str(qa/'zip_native_driver.rs')]
started=time.monotonic();rows=[]
for label,cmd,cwd in [('prepare-final-canonical',argv,out),('locked-offline-metadata',['/home/qian-qi/.cargo/bin/cargo','+1.95.0','metadata','--offline','--locked','--format-version','1','--all-features','--filter-platform','x86_64-unknown-linux-gnu'],out/'bindings/crate')]:
 p=subprocess.run(cmd,cwd=cwd,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=60);(out/(label+'.stdout')).write_bytes(p.stdout);(out/(label+'.stderr')).write_bytes(p.stderr)
 rows.append({'label':label,'returncode':p.returncode});print(json.dumps(rows[-1]),flush=True)
 if p.returncode:print(p.stderr.decode()[-10000:],flush=True)
 assert p.returncode==0
old=base/'zip-original-eight-v4/bindings';new=out/'bindings'
matched=[]
for path in sorted((old/'crate').rglob('*')):
 if not path.is_file():continue
 relative=path.relative_to(old);a=path.read_bytes();b=(new/relative).read_bytes()
 if path.suffix=='.rs':a=a.replace(str(old).encode(),str(new).encode())
 assert a==b,str(relative);matched.append(str(relative))
for name,pin in json.loads((new/'preparation.json').read_bytes())['original_sources'].items():
 data=(new/'original'/name).read_bytes();assert len(data)==pin['bytes']and sha256(data).hexdigest()==pin['sha256']
report={'status':'FINAL_QA_PREPARATION_MATCHES_ACTUAL_PASSING_CRATE','rows':rows,'exact_files_after_private_path_relocation':matched,'source_and_assertions_changed':False,'dependency_versions_and_checksums_changed':False,'seconds':time.monotonic()-started}
(out/'terminal.json').write_text(json.dumps(report,sort_keys=True,indent=2)+'\n');print(json.dumps(report,sort_keys=True),flush=True)
