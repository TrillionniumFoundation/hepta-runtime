from pathlib import Path
from hashlib import sha256
import os,sys,json,subprocess,time,tomllib
base=Path('/home/qian-qi/hia-runtime-rea-formats-20261128-2ac5');out=base/'zip-original-dependency-readiness-v1';out.mkdir(mode=0o700,exist_ok=False)
(out/'driver.py').write_text(sys.argv[1])
crate=base/'zip-original-eight-v2/bindings/crate';source=base/'zip-native-build-v1/source'
lock=(crate/'Cargo.lock').read_bytes();(out/'canonical-Cargo.lock').write_bytes(lock)
original={(r['name'],r['version']):r for r in tomllib.loads((source/'Cargo.lock').read_text())['package']}
resolved=tomllib.loads(lock.decode())['package'];matched=[]
for row in resolved:
 if row['name']=='hia-rea-zip-reference':continue
 prior=original[(row['name'],row['version'])]
 assert row.get('source')==prior.get('source')and row.get('checksum')==prior.get('checksum'),row
 matched.append({'name':row['name'],'version':row['version'],'checksum':row.get('checksum')})
(out/'exact-original-packages.json').write_text(json.dumps(matched,sort_keys=True,indent=2)+'\n')
env=dict(os.environ,LC_ALL='C',LANG='C',CARGO_HTTP_TIMEOUT='30',CARGO_NET_RETRY='0')
argv=['/home/qian-qi/.cargo/bin/cargo','+1.95.0','fetch','--locked','--target','x86_64-unknown-linux-gnu']
started=time.monotonic()
with(out/'fetch.stdout').open('xb')as so,(out/'fetch.stderr').open('xb')as se:
 p=subprocess.run(argv,cwd=crate,env=env,stdout=so,stderr=se,timeout=180)
assert(crate/'Cargo.lock').read_bytes()==lock
result={'status':'EXACT_ORIGINAL_DEPENDENCIES_READY'if p.returncode==0 else'EXACT_ORIGINAL_DEPENDENCIES_NOT_READY','returncode':p.returncode,'seconds':time.monotonic()-started,'exact_original_registry_packages':len(matched),'lock_unchanged':True,'product_tests_started':False,'stdout':(out/'fetch.stdout').read_text(),'stderr':(out/'fetch.stderr').read_text()}
(out/'terminal.json').write_text(json.dumps(result,sort_keys=True,indent=2)+'\n');print(json.dumps(result,sort_keys=True),flush=True)
