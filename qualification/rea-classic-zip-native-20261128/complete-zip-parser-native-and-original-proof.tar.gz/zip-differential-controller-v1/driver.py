from pathlib import Path
import sys,json,subprocess,time,os
base=Path('/home/qian-qi/hia-runtime-rea-formats-20261128-2ac5');out=base/'zip-differential-controller-v1';out.mkdir(mode=0o700,exist_ok=False)
(out/'driver.py').write_text(sys.argv[1])
for name,data in json.loads(sys.argv[2]).items():(out/name).write_text(data)
argv=[sys.executable,'-B',str(out/'qualify_rea_zip_differential.py'),'--source',str(base/'zip-native-build-v1/source'),'--manifest',str(base/'zip-native-build-v1/build/modules/rea-zip-parser/manifest.json'),'--oracle',str(base/'zip-original-eight-v4/original-oracle'),'--output',str(base/'zip-differential-v1')]
(out/'intent.json').write_text(json.dumps({'argv':argv,'original_test_bytes_changed':False,'public_route_qualified':False},sort_keys=True,indent=2)+'\n')
started=time.monotonic()
with(out/'stdout').open('xb')as so,(out/'stderr').open('xb')as se:p=subprocess.run(argv,cwd=out,env=dict(os.environ,LC_ALL='C',LANG='C',PYTHONDONTWRITEBYTECODE='1'),stdout=so,stderr=se,timeout=900)
report={'returncode':p.returncode,'seconds':time.monotonic()-started,'stdout_bytes':(out/'stdout').stat().st_size,'stderr_bytes':(out/'stderr').stat().st_size}
(out/'terminal.json').write_text(json.dumps(report,sort_keys=True,indent=2)+'\n');print(json.dumps(report,sort_keys=True),flush=True)
print((out/'stdout').read_text()[-12000:]);print((out/'stderr').read_text()[-12000:]);sys.exit(p.returncode)
