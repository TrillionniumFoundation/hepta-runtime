from pathlib import Path,PurePosixPath
from hashlib import sha256
import os,sys,json,tarfile,stat,subprocess,shutil,time
os.umask(0o022)
base=Path('/home/qian-qi/hia-runtime-rea-formats-20261128-2ac5')
out=base/'zip-native-build-v1';out.mkdir(mode=0o700,exist_ok=False)
(out/'driver.py').write_text(sys.argv[1]);started=time.monotonic()
archive=base/'source-input.tar.gz';raw=archive.read_bytes()
assert len(raw)==150037 and sha256(raw).hexdigest()=='fe4b7c5348d497501c73e70c38bea96628c2ca73e31817a568ac794c2580c5ac'
pins=json.loads((base/'source-input-manifest.json').read_bytes());assert len(pins)==18
source=out/'source';source.mkdir(mode=0o700)
with tarfile.open(archive,'r:gz')as tar:
 assert set(tar.getnames())==set(pins)
 for member in tar.getmembers():
  name=member.name;parts=PurePosixPath(name);assert member.isfile()and not parts.is_absolute()and '..'not in parts.parts
  raw=tar.extractfile(member).read();row=pins[name]
  assert len(raw)==row['bytes']and sha256(raw).hexdigest()==row['sha256']and member.mode==row['mode']
  target=source/name;target.parent.mkdir(parents=True,exist_ok=True)
  with target.open('xb')as stream:stream.write(raw)
  target.chmod(member.mode)
build=out/'build';build.mkdir(mode=0o700)
upstream=Path('/home/qian-qi/hia-runtime-filebytes-20261128-2ac5/local-read-component-build-v1/build/bootstrap')
shutil.copytree(upstream,build/'bootstrap',copy_function=shutil.copy2)
assert sha256((build/'bootstrap/B3.image.bin').read_bytes()).hexdigest()=='bfd603dd2b40974d2083b567b4295fb3975938da8435dd636514fc197c485de0'
env=dict(os.environ,LC_ALL='C',LANG='C',PYTHONDONTWRITEBYTECODE='1')
argv=['/usr/bin/python3','-B',str(source/'scripts/hia_native_build.py'),'--hepta','/home/qian-qi/hia-runtime-filebytes-20261128-2ac5/pinned-hepta-d3e2','--build-root',str(build),'--source',str(source/'native/rea_zip_parser.hepta'),'--name','rea-zip-parser','--transport','image','--buffer-profile','history.v1']
(out/'intent.json').write_text(json.dumps({'argv':argv,'source_pins':pins,'source_scope':'18 exact component files, not a complete Runtime checkout','qualified':False},sort_keys=True,indent=2)+'\n')
with(out/'build.stdout').open('xb')as so,(out/'build.stderr').open('xb')as se:
 p=subprocess.run(argv,cwd=source,env=env,stdout=so,stderr=se,timeout=300)
after={}
for name in pins:
 pth=source/name;st=pth.lstat();assert stat.S_ISREG(st.st_mode)and st.st_nlink==1
 raw=pth.read_bytes();after[name]={'bytes':len(raw),'sha256':sha256(raw).hexdigest(),'mode':stat.S_IMODE(st.st_mode)}
assert after==pins
report={'status':'ZIP_NATIVE_COMPONENT_COMPILED'if p.returncode==0 else'ZIP_NATIVE_COMPONENT_BUILD_FAILED','returncode':p.returncode,'seconds':time.monotonic()-started,'all_source_bytes_and_modes_stable':True,'stdout':(out/'build.stdout').read_text(),'stderr':(out/'build.stderr').read_text(),'qualified':False}
(out/'terminal.json').write_text(json.dumps(report,sort_keys=True,indent=2)+'\n');print(json.dumps(report,sort_keys=True),flush=True)
assert p.returncode==0
