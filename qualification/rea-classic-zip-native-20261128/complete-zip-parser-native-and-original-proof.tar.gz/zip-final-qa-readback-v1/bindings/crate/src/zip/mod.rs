use anyhow::{anyhow,bail,Context,Result};
use serde::{Deserialize,Serialize};
use serde_json::{json,Value};
use sha2::{Digest,Sha256};
use std::fmt::Write as _;
const MAX_DIRECTORY_BYTES:u64=16*1024*1024;
#[derive(Debug,Clone,Copy,Default,Deserialize,Serialize)]
#[serde(rename_all="snake_case")]
pub enum ArchiveFilter {
	#[default]
	All,
	Manifest,
	Dex,
	NativeLibrary,
	Resource,
	JavaClass,
	SignatureMarker,
}
impl ArchiveFilter {
	fn matches(self, role: &str) -> bool {
		match self {
			Self::All => true,
			Self::Manifest => role == "manifest",
			Self::Dex => role == "dex",
			Self::NativeLibrary => role == "native_library",
			Self::Resource => role == "resource",
			Self::JavaClass => role == "java_class",
			Self::SignatureMarker => role == "signature_marker",
		}
	}
}
fn hex(bytes: &[u8]) -> String {
	let mut value = String::with_capacity(bytes.len().saturating_mul(2));
	for byte in bytes {
		let _ = write!(value, "{byte:02x}");
	}
	value
}
fn observed_version(meta: &std::fs::Metadata) -> Result<String> {
	#[cfg(unix)]
	{
		use std::os::unix::fs::MetadataExt;
		let values = format!(
			"hepta-archive-observation-v1:{}:{}:{}:{}:{}:{}:{}:{}:{}:{}:{}",
			meta.dev(),
			meta.ino(),
			meta.len(),
			meta.mode(),
			meta.uid(),
			meta.gid(),
			meta.nlink(),
			meta.mtime(),
			meta.mtime_nsec(),
			meta.ctime(),
			meta.ctime_nsec()
		);
		Ok(format!("afv1_{}", hex(&Sha256::digest(values.as_bytes()))))
	}
	#[cfg(not(unix))]
	{
		let _ = meta;
		bail!("archive observation requires Unix descriptor metadata")
	}
}
#[cfg(not(feature="native"))]
#[path="/home/qian-qi/hia-runtime-rea-formats-20261128-2ac5/zip-final-qa-readback-v1/bindings/original/src/mcp/rea_artifact_zip_parser.rs"]
mod parser;
#[cfg(feature="native")]
#[path="native_parser.rs"]
mod parser;

pub fn inspect(request: &Value) -> Result<Value> {
    let path = request["path"].as_str().context("fixture path")?;
    let mut file = std::fs::File::open(path)?;
    let typed: parser::Request = serde_json::from_value(json!({
        "filter":request.get("filter").cloned().unwrap_or(json!("all")),
        "offset":request.get("offset").cloned().unwrap_or(json!(0)),
        "limit":request.get("limit").cloned().unwrap_or(json!(64))
    }))?;
    parser::inspect_file(&mut file, &typed)
}
