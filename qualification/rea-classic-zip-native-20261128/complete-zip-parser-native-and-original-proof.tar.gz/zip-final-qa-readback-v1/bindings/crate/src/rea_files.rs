use anyhow::{bail,Result};
pub(super) fn ensure_unchanged(
	before: &std::fs::Metadata,
	after: &std::fs::Metadata,
) -> Result<()> {
	use std::os::unix::fs::MetadataExt;
	if before.dev() != after.dev()
		|| before.ino() != after.ino()
		|| before.len() != after.len()
		|| before.mode() != after.mode()
		|| before.uid() != after.uid()
		|| before.gid() != after.gid()
		|| before.nlink() != after.nlink()
		|| before.mtime() != after.mtime()
		|| before.mtime_nsec() != after.mtime_nsec()
		|| before.ctime() != after.ctime()
		|| before.ctime_nsec() != after.ctime_nsec()
	{
		bail!("REA inspection denied: admitted artifact changed during read");
	}
	Ok(())
}
