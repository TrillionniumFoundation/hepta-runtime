
use std::io::{BufRead,Write};
use serde_json::{json,Value};
fn main()->anyhow::Result<()> {
    let stdin=std::io::stdin();
    let mut stdout=std::io::stdout().lock();
    for line in stdin.lock().lines() {
        let request:Value=serde_json::from_str(&line?)?;
        let response=match hia_rea_zip_reference::zip::inspect(&request) {
            Ok(value)=>json!({"ok":true,"value":value}),
            Err(error)=>json!({"ok":false,"error":error.to_string()})
        };
        writeln!(stdout,"{}",serde_json::to_string(&response)?)?;
        stdout.flush()?;
    }
    Ok(())
}
